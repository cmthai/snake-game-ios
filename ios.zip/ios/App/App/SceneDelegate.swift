import UIKit
import Capacitor
import WebKit

class SSLBypassNavigationDelegate: NSObject, WKNavigationDelegate {
    weak var originalDelegate: WKNavigationDelegate?
    weak var viewController: CustomBridgeViewController?

    init(original: WKNavigationDelegate?, viewController: CustomBridgeViewController?) {
        self.originalDelegate = original
        self.viewController = viewController
        super.init()
    }

    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let serverTrust = challenge.protectionSpace.serverTrust {
            // Accept SSL certificate from server (self-signed, aaPanel, or internal domain)
            completionHandler(.useCredential, URLCredential(trust: serverTrust))
            return
        }
        if let original = originalDelegate, original.responds(to: #selector(WKNavigationDelegate.webView(_:didReceive:completionHandler:))) {
            original.webView?(webView, didReceive: challenge, completionHandler: completionHandler)
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("❌ Navigation failed: \(error.localizedDescription)")
        let nsError = error as NSError
        if nsError.code == NSURLErrorCancelled {
            return
        }
        
        let errorHtml = """
        <!DOCTYPE html>
        <html lang="th">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
            <title>SnakeGame3D</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { background: radial-gradient(circle at center, #1e1b4b 0%, #0b0f19 100%); color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; padding: 24px; text-align: center; }
                .card { background: rgba(15, 23, 42, 0.85); border: 1.5px solid rgba(0, 229, 255, 0.4); border-radius: 20px; padding: 28px; max-width: 440px; box-shadow: 0 0 35px rgba(0, 229, 255, 0.25); }
                .icon { font-size: 52px; margin-bottom: 12px; }
                h2 { color: #00e5ff; font-size: 20px; font-weight: 800; margin-bottom: 10px; }
                p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 22px; }
                button { background: linear-gradient(135deg, #00e5ff, #0284c7); color: #000; font-weight: 800; border: none; padding: 12px 28px; border-radius: 12px; font-size: 15px; cursor: pointer; box-shadow: 0 4px 15px rgba(0, 229, 255, 0.4); }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="icon">🎲</div>
                <h2>เข้าสู่ระบบเกมไม่สำเร็จ</h2>
                <p>ไม่สามารถเชื่อมต่อไปยังเซิร์ฟเวอร์เกมได้<br><small style="color:#64748b;">\(error.localizedDescription)</small></p>
                <button onclick="location.href='https://pmix01.thddns.net:7175/home/snake/'">🔄 ลองเชื่อมต่อใหม่</button>
            </div>
        </body>
        </html>
        """
        webView.loadHTMLString(errorHtml, baseURL: nil)
    }

    override func forwardingTarget(for aSelector: Selector!) -> Any? {
        return originalDelegate
    }

    override func responds(to aSelector: Selector!) -> Bool {
        if aSelector == #selector(WKNavigationDelegate.webView(_:didReceive:completionHandler:)) ||
           aSelector == #selector(WKNavigationDelegate.webView(_:didFailProvisionalNavigation:withError:)) {
            return true
        }
        return originalDelegate?.responds(to: aSelector) ?? super.responds(to: aSelector)
    }
}

class CustomBridgeViewController: CAPBridgeViewController {
    private var sslProxy: SSLBypassNavigationDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        let darkColor = UIColor(red: 7/255, green: 11/255, blue: 20/255, alpha: 1.0)
        self.view.backgroundColor = darkColor
        self.webView?.backgroundColor = darkColor
        self.webView?.scrollView.backgroundColor = darkColor
        self.webView?.isOpaque = false

        if let currentDelegate = self.webView?.navigationDelegate {
            let proxy = SSLBypassNavigationDelegate(original: currentDelegate, viewController: self)
            self.sslProxy = proxy
            self.webView?.navigationDelegate = proxy
        }
    }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        // Keep screen awake while game is active
        UIApplication.shared.isIdleTimerDisabled = true

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = CustomBridgeViewController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        UIApplication.shared.isIdleTimerDisabled = true
    }

    func sceneWillResignActive(_ scene: UIScene) {
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}
