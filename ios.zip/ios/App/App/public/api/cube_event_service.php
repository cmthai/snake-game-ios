<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Bangkok');

/**
 * cube_event_service.php
 * บริการระบบอีเวนต์สุ่ม (กรอบรูป / ลูกเต๋า 3D) และระบบหมุนลูกบาศก์นำโชค (Magic Cube)
 * สไตล์เกมเศรษฐี LINE Let's Get Rich
 */

require_once __DIR__ . '/../config/database.php';

if (!function_exists('safeQueryRow')) {
    function safeQueryRow(mysqli $db, string $sql): ?array {
        $res = @$db->query($sql);
        if ($res && $res instanceof mysqli_result) {
            $row = $res->fetch_assoc();
            $res->free();
            return $row ?: null;
        }
        return null;
    }
}

if (!function_exists('safeQueryAll')) {
    function safeQueryAll(mysqli $db, string $sql): array {
        $res = @$db->query($sql);
        if ($res && $res instanceof mysqli_result) {
            $rows = $res->fetch_all(MYSQLI_ASSOC);
            $res->free();
            return $rows ?: [];
        }
        return [];
    }
}

/**
 * ตรวจสอบและสร้าง/อัปเกรดตารางฐานข้อมูลสำหรับอีเวนต์และลูกบาศก์
 */

/**
 * ตรวจสอบและสร้าง/อัปเกรดตาราง mailbox ให้รองรับของรางวัลทุกรูปแบบ (เพชร, ทอง, ลูกบาศก์, การ์ด, เต๋า)
 */
function ensureMailboxTable(mysqli $db): void {
    static $mbInitialized = false;
    if ($mbInitialized) return;
    $mbInitialized = true;

    @$db->query("
        CREATE TABLE IF NOT EXISTS `mailbox` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `event_id` INT NULL DEFAULT NULL,
            `promo_code` VARCHAR(50) NULL DEFAULT NULL,
            `title` VARCHAR(255) NOT NULL,
            `message` TEXT NOT NULL,
            `reward_diamond` BIGINT NOT NULL DEFAULT 0,
            `reward_gold` BIGINT NOT NULL DEFAULT 0,
            `reward_cube_type` VARCHAR(50) NULL DEFAULT NULL,
            `reward_cube_qty` INT NOT NULL DEFAULT 0,
            `reward_character_id` INT NULL DEFAULT NULL,
            `reward_dice_id` INT NULL DEFAULT NULL,
            `reward_gem_id` INT NULL DEFAULT NULL,
            `is_claimed` TINYINT(1) NOT NULL DEFAULT 0,
            `expires_at` DATETIME NULL DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_user_claimed` (`user_id`, `is_claimed`),
            INDEX `idx_expires` (`expires_at`),
            INDEX `idx_user_event` (`user_id`, `event_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $cols = [
        'event_id' => "INT NULL DEFAULT NULL",
        'promo_code' => "VARCHAR(50) NULL DEFAULT NULL",
        'reward_diamond' => "BIGINT NOT NULL DEFAULT 0",
        'reward_gold' => "BIGINT NOT NULL DEFAULT 0",
        'reward_cube_type' => "VARCHAR(50) NULL DEFAULT NULL",
        'reward_cube_qty' => "INT NOT NULL DEFAULT 0",
        'reward_character_id' => "INT NULL DEFAULT NULL",
        'reward_dice_id' => "INT NULL DEFAULT NULL",
        'reward_gem_id' => "INT NULL DEFAULT NULL",
        'is_claimed' => "TINYINT(1) NOT NULL DEFAULT 0",
        'expires_at' => "DATETIME NULL DEFAULT NULL"
    ];

    $existingCols = [];
    $res = @$db->query("SHOW COLUMNS FROM `mailbox`");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $existingCols[strtolower($row['Field'])] = true;
        }
        $res->close();
    }

    foreach ($cols as $colName => $colDef) {
        if (!isset($existingCols[strtolower($colName)])) {
            @$db->query("ALTER TABLE `mailbox` ADD COLUMN `{$colName}` {$colDef}");
        }
    }
    @$db->query("ALTER TABLE `mailbox` MODIFY COLUMN `reward_diamond` BIGINT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `mailbox` MODIFY COLUMN `reward_gold` BIGINT NOT NULL DEFAULT 0");

    // Ensure events & user_event_claims tables
    @$db->query("
        CREATE TABLE IF NOT EXISTS `events` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(150) NOT NULL,
            `description` TEXT DEFAULT NULL,
            `event_type` VARCHAR(50) NOT NULL DEFAULT 'ADMIN_GIVEAWAY',
            `promo_code` VARCHAR(50) DEFAULT NULL,
            `reward_diamond` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `reward_gold` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `reward_cube_type` VARCHAR(50) DEFAULT NULL,
            `reward_cube_qty` INT UNSIGNED NOT NULL DEFAULT 0,
            `max_claims_total` INT UNSIGNED DEFAULT NULL,
            `current_claims_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `start_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_by_admin` VARCHAR(100) NOT NULL DEFAULT 'Admin',
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    @$db->query("ALTER TABLE `events` ADD COLUMN IF NOT EXISTS `reward_cube_type` VARCHAR(50) DEFAULT NULL");
    @$db->query("ALTER TABLE `events` ADD COLUMN IF NOT EXISTS `reward_cube_qty` INT UNSIGNED NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `events` MODIFY COLUMN `event_type` VARCHAR(50) NOT NULL DEFAULT 'ADMIN_GIVEAWAY'");
    @$db->query("ALTER TABLE `events` MODIFY COLUMN `reward_diamond` BIGINT UNSIGNED NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `events` MODIFY COLUMN `reward_gold` BIGINT UNSIGNED NOT NULL DEFAULT 0");

    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_event_claims` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_id` INT NOT NULL,
            `user_id` INT NOT NULL,
            `claimed_diamond` BIGINT NOT NULL DEFAULT 0,
            `claimed_gold` BIGINT NOT NULL DEFAULT 0,
            `claimed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_event_user` (`event_id`, `user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
}

/**
 * ซิงค์รายการกิจกรรมที่เปิดใช้งานอยู่ (Active Events ทั้งแจกฟรีและโค้ดกิจกรรม) เข้าสู่กล่องจดหมายของผู้เล่นอัตโนมัติ
 */
function syncActiveEventsToUserMailbox(mysqli $db, int $userId): void {
    if ($userId <= 0) return;
    ensureMailboxTable($db);

    // หากกิจกรรมที่เปิดใช้งานอยู่ (is_active = 1) มีเวลาหมดอายุเท่ากับเวลาเริ่ม หรือไม่ได้ตั้งวันหมดอายุ ให้ต่ออายุอัตโนมัติ 7 วัน
    @$db->query("UPDATE `events` SET `end_time` = DATE_ADD(NOW(), INTERVAL 7 DAY) WHERE `is_active` = 1 AND (`end_time` IS NULL OR `end_time` <= '2000-01-01 00:00:00' OR `end_time` <= `start_time`)");

    $evRes = @$db->query("SELECT * FROM `events` WHERE `is_active` = 1 AND (`end_time` IS NULL OR `end_time` >= NOW()) ORDER BY `id` ASC");
    if (!$evRes) return;
    $activeEvents = $evRes->fetch_all(MYSQLI_ASSOC);
    $evRes->close();

    if (empty($activeEvents)) return;

    // ดึงรายการ event_id ที่ผู้เล่นเคยกดรับไปแล้วจาก user_event_claims
    $claimedEventIds = [];
    $cRes = @$db->query("SELECT `event_id` FROM `user_event_claims` WHERE `user_id` = {$userId}");
    if ($cRes) {
        while ($cRow = $cRes->fetch_assoc()) {
            $claimedEventIds[(int)$cRow['event_id']] = true;
        }
        $cRes->close();
    }

    // ดึงรายการจดหมายทั้งหมดของผู้เล่นเพื่อตรวจสอบไม่ให้สร้างซ้ำ
    $existingByEventId = [];
    $existingByTitle = [];
    $mRes = @$db->query("SELECT `id`, `event_id`, `title`, `is_claimed` FROM `mailbox` WHERE `user_id` = {$userId}");
    if ($mRes) {
        while ($mRow = $mRes->fetch_assoc()) {
            $eid = (int)($mRow['event_id'] ?? 0);
            if ($eid > 0) {
                $existingByEventId[$eid] = $mRow;
            }
            $tKey = trim((string)($mRow['title'] ?? ''));
            if ($tKey !== '') {
                $existingByTitle[$tKey] = $mRow;
            }
        }
        $mRes->close();
    }

    $insStmt = @$db->prepare("
        INSERT INTO `mailbox`
            (`user_id`, `event_id`, `promo_code`, `title`, `message`, `reward_diamond`, `reward_gold`, `reward_cube_type`, `reward_cube_qty`, `is_claimed`, `expires_at`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    ");
    if (!$insStmt) return;

    foreach ($activeEvents as $ev) {
        $evId = (int)$ev['id'];
        $rewardDia = max(0, (int)($ev['reward_diamond'] ?? 0));
        $rewardGold = max(0, (int)($ev['reward_gold'] ?? 0));
        $rawCube = !empty($ev['reward_cube_type']) ? strtoupper(trim((string)$ev['reward_cube_type'])) : '';
        $rewardCubeType = ($rawCube !== '' && $rawCube !== 'NONE') ? $rawCube : null;
        $rewardCubeQty = $rewardCubeType ? max(1, (int)($ev['reward_cube_qty'] ?? 1)) : 0;

        if ($rewardDia <= 0 && $rewardGold <= 0 && empty($rewardCubeType)) {
            continue;
        }

        // ถ้าเคยรับผ่านโค้ดหรือกิจกรรมนี้ไปแล้ว ไม่ต้องสร้างซ้ำ
        if (isset($claimedEventIds[$evId])) {
            if (isset($existingByEventId[$evId]) && (int)$existingByEventId[$evId]['is_claimed'] === 0) {
                $mid = (int)$existingByEventId[$evId]['id'];
                @$db->query("UPDATE `mailbox` SET `is_claimed` = 1 WHERE `id` = {$mid}");
            }
            continue;
        }

        if (isset($existingByEventId[$evId])) {
            continue;
        }

        $title = trim((string)($ev['title'] ?? '🎁 กิจกรรมแจกของรางวัลพิเศษ'));
        $promoCode = !empty($ev['promo_code']) ? strtoupper(trim((string)$ev['promo_code'])) : null;

        // หากมีจดหมายชื่อเดียวกันอยู่แล้วแต่ยังไม่ได้ผูก event_id ให้ผูก event_id แทนการสร้างซ้ำ
        if (isset($existingByTitle[$title])) {
            $mid = (int)$existingByTitle[$title]['id'];
            $escCode = $promoCode ? ("'" . $db->real_escape_string($promoCode) . "'") : "NULL";
            @$db->query("UPDATE `mailbox` SET `event_id` = {$evId}, `promo_code` = {$escCode} WHERE `id` = {$mid}");
            $existingByEventId[$evId] = $existingByTitle[$title];
            continue;
        }

        $desc = trim((string)($ev['description'] ?? ''));
        if ($desc === '') {
            $desc = $promoCode
                ? "โค้ดกิจกรรมพิเศษ: {$promoCode} (กดรับได้ทันที หรือกรอกโค้ดด้านบน)"
                : "ของขวัญกิจกรรมพิเศษจากผู้ดูแลระบบ กดรับรางวัลเข้าคลังได้ทันที!";
        }
        $endTime = !empty($ev['end_time']) && $ev['end_time'] > '2000-01-01 00:00:00'
            ? $ev['end_time']
            : date('Y-m-d H:i:s', strtotime('+7 days'));

        $insStmt->bind_param(
            "iisssiisis",
            $userId,
            $evId,
            $promoCode,
            $title,
            $desc,
            $rewardDia,
            $rewardGold,
            $rewardCubeType,
            $rewardCubeQty,
            $endTime
        );
        @$insStmt->execute();
    }

    $insStmt->close();
}

function ensureCubeAndEventTables(mysqli $db): void {
    static $initialized = false;
    if ($initialized) return;
    $initialized = true;
    ensureMailboxTable($db);

    // 0. ตาราง user_materials (สำหรับเก็บการ์ดเงา วัตถุดิบ A ~ S)
    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_materials` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `material_code` VARCHAR(50) NOT NULL,
            `quantity` INT NOT NULL DEFAULT 0,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uniq_user_mat` (`user_id`, `material_code`),
            INDEX `idx_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // 0.1 ตาราง user_inventory
    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_inventory` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `item_type` VARCHAR(30) NOT NULL DEFAULT 'CHARACTER',
            `character_id` INT NULL DEFAULT NULL,
            `dice_id` INT NULL DEFAULT NULL,
            `level` INT NOT NULL DEFAULT 1,
            `is_equipped` TINYINT(1) NOT NULL DEFAULT 0,
            `is_awakened` TINYINT(1) NOT NULL DEFAULT 0,
            `unlocked_skill_id` INT NULL DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_user_item` (`user_id`, `item_type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    @$db->query("ALTER TABLE `user_inventory` ADD COLUMN IF NOT EXISTS `dice_id` INT NULL DEFAULT NULL");
    @$db->query("ALTER TABLE `user_inventory` ADD COLUMN IF NOT EXISTS `character_id` INT NULL DEFAULT NULL");
    @$db->query("ALTER TABLE `user_inventory` ADD COLUMN IF NOT EXISTS `item_type` VARCHAR(30) NOT NULL DEFAULT 'CHARACTER'");
    @$db->query("ALTER TABLE `user_inventory` ADD COLUMN IF NOT EXISTS `level` INT NOT NULL DEFAULT 1");
        @$db->query("ALTER TABLE `user_inventory` ADD COLUMN IF NOT EXISTS `is_equipped` TINYINT(1) NOT NULL DEFAULT 0");

    // 0.2 ตาราง user_dice
    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_dice` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `dice_id` INT NOT NULL,
            `level` INT NOT NULL DEFAULT 1,
            `is_equipped` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `uniq_user_dice` (`user_id`, `dice_id`),
            INDEX `idx_user` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // 0.3 ตาราง skills
    @$db->query("
        CREATE TABLE IF NOT EXISTS `skills` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL DEFAULT '',
            `code` VARCHAR(50) NOT NULL DEFAULT '',
            `description` TEXT NULL,
            `base_power_value` DECIMAL(10,2) NOT NULL DEFAULT 10.00,
            `trigger_chance_percent` DECIMAL(5,2) NOT NULL DEFAULT 20.00,
            `power_unit` VARCHAR(20) NOT NULL DEFAULT '%',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `skill_id` INT NULL DEFAULT NULL");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `skill_id` INT NULL DEFAULT NULL");

    // 1. ตาราง gacha_events & dice_gacha_events
    @$db->query("
        CREATE TABLE IF NOT EXISTS `gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(150) NOT NULL DEFAULT '🎴 เทศกาลสุ่มการ์ดกรอบรูป ลุ้นรับกรอบแรร์เรตอัป',
            `description` TEXT NULL,
            `event_type` ENUM('FRAME', 'DICE', 'BOTH') NOT NULL DEFAULT 'FRAME',
            `cost_diamond` INT NOT NULL DEFAULT 50,
            `cards_per_pack` INT NOT NULL DEFAULT 5,
            `target_character_id` INT NOT NULL DEFAULT 1,
            `target_dice_id` INT NOT NULL DEFAULT 1,
            `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00,
            `rate_splus` DECIMAL(5,2) NOT NULL DEFAULT 3.00,
            `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `req_shadow_black` INT NOT NULL DEFAULT 15,
            `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
            `req_shadow_red` INT NOT NULL DEFAULT 15,
            `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00,
            `req_shadow_orange` INT NOT NULL DEFAULT 15,
            `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `req_shadow_blue` INT NOT NULL DEFAULT 10,
            `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `req_shadow_gold` INT NOT NULL DEFAULT 4,
            `shadow_config_json` LONGTEXT NULL,
            `exchange_tiers_json` LONGTEXT NULL,
            `start_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_date` DATETIME NOT NULL DEFAULT '2030-12-31 23:59:59',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    @$db->query("
        CREATE TABLE IF NOT EXISTS `dice_gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(150) NOT NULL DEFAULT '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป',
            `description` TEXT NULL,
            `cost_diamond` INT NOT NULL DEFAULT 50,
            `target_dice_id` INT NOT NULL DEFAULT 1,
            `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00,
            `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `req_shadow_black` INT NOT NULL DEFAULT 15,
            `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
            `req_shadow_red` INT NOT NULL DEFAULT 15,
            `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00,
            `req_shadow_orange` INT NOT NULL DEFAULT 15,
            `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `req_shadow_blue` INT NOT NULL DEFAULT 10,
            `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `req_shadow_gold` INT NOT NULL DEFAULT 4,
            `shadow_config_json` LONGTEXT NULL,
            `start_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_date` DATETIME NOT NULL DEFAULT '2030-12-31 23:59:59',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `event_type` ENUM('FRAME', 'DICE', 'BOTH') NOT NULL DEFAULT 'FRAME' COMMENT 'ประเภทอีเวนต์'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `target_dice_id` INT NOT NULL DEFAULT 1 COMMENT 'ลูกเต๋าเป้าหมายเรตอัป'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00 COMMENT 'อัตราเรตอัปเป้าหมาย (%)'");

    // ตรวจสอบแถวเริ่มต้นของอีเวนต์
    $chkEv = @$db->query("SELECT id FROM `gacha_events` LIMIT 1");
    if (!$chkEv || $chkEv->num_rows === 0) {
        @$db->query("INSERT INTO `gacha_events` (event_name, cost_diamond, cards_per_pack, target_character_id, target_dice_id, start_date, end_date, is_active) VALUES ('🎴 เทศกาลสุ่มการ์ดกรอบรูป ลุ้นรับกรอบแรร์เรตอัป', 50, 5, 1, 1, NOW(), DATE_ADD(NOW(), INTERVAL 60 DAY), 1)");
    }
    $chkDiceEv = @$db->query("SELECT id FROM `dice_gacha_events` LIMIT 1");
    if (!$chkDiceEv || $chkDiceEv->num_rows === 0) {
        @$db->query("INSERT INTO `dice_gacha_events` (event_name, cost_diamond, target_dice_id, rate_target_boost, start_date, end_date, is_active) VALUES ('🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป', 50, 1, 35.00, NOW(), DATE_ADD(NOW(), INTERVAL 60 DAY), 1)");
    }

    // 2. ตาราง cube_configs (การตั้งค่าลูกบาศก์ 4 ชนิดในหน้า Admin)
    $db->query("
        CREATE TABLE IF NOT EXISTS `cube_configs` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `cube_type` VARCHAR(30) UNIQUE NOT NULL,
            `cube_name` VARCHAR(100) NOT NULL,
            `color_hex` VARCHAR(25) NOT NULL DEFAULT '#94a3b8',
            `min_hours` INT NOT NULL DEFAULT 1,
            `max_hours` INT NOT NULL DEFAULT 3,
            `drop_rate_percent` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `rewards_json` LONGTEXT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // 3. ตาราง user_cubes (ลูกบาศก์ของผู้เล่น)
    $db->query("
        CREATE TABLE IF NOT EXISTS `user_cubes` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `cube_type` VARCHAR(30) NOT NULL,
            `status` ENUM('IDLE', 'SPINNING', 'READY', 'CLAIMED') NOT NULL DEFAULT 'IDLE',
            `slot_index` INT NULL DEFAULT NULL COMMENT 'ตำแหน่งช่องหมุน 1-4',
            `spin_cost_currency` VARCHAR(15) NULL DEFAULT 'DIAMOND',
            `spin_cost_amount` INT NOT NULL DEFAULT 0,
            `spin_hours` DECIMAL(4,2) NOT NULL DEFAULT 0.00,
            `spin_started_at` DATETIME NULL,
            `ready_at` DATETIME NULL,
            `claimed_at` DATETIME NULL,
            `reward_won` LONGTEXT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_user_status` (`user_id`, `status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // ซิงค์ Collation ป้องกันข้อผิดพลาด Collation Mismatch ในการ JOIN
    @$db->query("ALTER TABLE `cube_configs` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    @$db->query("ALTER TABLE `user_cubes` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    @$db->query("UPDATE `user_cubes` SET slot_index = NULL WHERE slot_index = 0");
    @$db->query("UPDATE `user_cubes` SET status = 'IDLE' WHERE status IS NULL OR status = ''");

    // อัปเกรดคอลัมน์สำหรับตั้งค่าค่าหมุนด้วยเพชร/ทอง และระบบช่องหมุน 4 ช่อง
    @$db->query("ALTER TABLE `cube_configs` ADD COLUMN IF NOT EXISTS `spin_cost_diamond` INT NOT NULL DEFAULT 20 COMMENT 'ค่าเพชรในการหมุน'");
    @$db->query("ALTER TABLE `cube_configs` ADD COLUMN IF NOT EXISTS `spin_cost_gold` INT NOT NULL DEFAULT 10000 COMMENT 'ค่าทองในการหมุน'");
    @$db->query("ALTER TABLE `cube_configs` ADD COLUMN IF NOT EXISTS `aura_type` VARCHAR(50) NOT NULL DEFAULT 'neon_pulse' COMMENT 'ประเภทออร่า'");
    @$db->query("ALTER TABLE `cube_configs` ADD COLUMN IF NOT EXISTS `particle_fx` VARCHAR(50) NOT NULL DEFAULT 'flare_burst' COMMENT 'ละอองอนุภาค'");
    @$db->query("ALTER TABLE `cube_configs` ADD COLUMN IF NOT EXISTS `intensity` VARCHAR(20) NOT NULL DEFAULT '2x' COMMENT 'ความเข้มแสง'");
    @$db->query("ALTER TABLE `user_cubes` ADD COLUMN IF NOT EXISTS `slot_index` INT NULL DEFAULT NULL COMMENT 'ตำแหน่งช่องหมุน 1-4'");
    @$db->query("ALTER TABLE `user_cubes` ADD COLUMN IF NOT EXISTS `spin_cost_currency` VARCHAR(15) NULL DEFAULT 'DIAMOND'");
    @$db->query("ALTER TABLE `user_cubes` ADD COLUMN IF NOT EXISTS `spin_cost_amount` INT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `user_cubes` ADD COLUMN IF NOT EXISTS `has_aura` TINYINT NOT NULL DEFAULT 0 COMMENT 'เอฟเฟกต์ออร่าเวลาหมุน (หมุนด้วยเพชรหรือทองที่ได้เวลา MAX)'");

    // อัปเดตค่าเริ่มต้นค่าเพชรและทองสำหรับลูกบาศก์ทั้ง 4 ชนิดหากยังไม่มี
    @$db->query("UPDATE `cube_configs` SET spin_cost_diamond = 10, spin_cost_gold = 5000 WHERE cube_type = 'SILVER' AND (spin_cost_diamond IS NULL OR spin_cost_diamond <= 0)");
    @$db->query("UPDATE `cube_configs` SET spin_cost_diamond = 25, spin_cost_gold = 15000 WHERE cube_type = 'GOLD' AND (spin_cost_diamond IS NULL OR spin_cost_diamond <= 0)");
    @$db->query("UPDATE `cube_configs` SET spin_cost_diamond = 50, spin_cost_gold = 35000 WHERE cube_type = 'DIAMOND' AND (spin_cost_diamond IS NULL OR spin_cost_diamond <= 0)");
    @$db->query("UPDATE `cube_configs` SET spin_cost_diamond = 100, spin_cost_gold = 80000 WHERE cube_type = 'LEGENDARY' AND (spin_cost_diamond IS NULL OR spin_cost_diamond <= 0)");

    // 4. สร้างข้อมูลเริ่มต้นของลูกบาศก์ทั้ง 4 ชนิด (ถ้ายังไม่มี)
    $cnt = $db->query("SELECT COUNT(*) as c FROM `cube_configs`")->fetch_assoc()['c'] ?? 0;
    if ((int)$cnt === 0) {
        $defaultConfigs = [
            [
                'cube_type' => 'SILVER',
                'cube_name' => 'ลูกบาศก์เงิน',
                'color_hex' => '#94a3b8',
                'min_hours' => 1,
                'max_hours' => 3,
                'drop_rate_percent' => 50.00,
                'rewards' => [
                    ['type' => 'GOLD', 'amount' => 30000, 'label' => '🪙 30,000 ทอง', 'weight' => 40],
                    ['type' => 'GOLD', 'amount' => 60000, 'label' => '🪙 60,000 ทอง', 'weight' => 30],
                    ['type' => 'DIAMOND', 'amount' => 20, 'label' => '💎 20 เพชร', 'weight' => 20],
                    ['type' => 'DIAMOND', 'amount' => 50, 'label' => '💎 50 เพชร', 'weight' => 10]
                ]
            ],
            [
                'cube_type' => 'GOLD',
                'cube_name' => 'ลูกบาศก์ทอง',
                'color_hex' => '#f59e0b',
                'min_hours' => 3,
                'max_hours' => 6,
                'drop_rate_percent' => 30.00,
                'rewards' => [
                    ['type' => 'GOLD', 'amount' => 100000, 'label' => '🪙 100,000 ทอง', 'weight' => 35],
                    ['type' => 'GOLD', 'amount' => 250000, 'label' => '🪙 250,000 ทอง', 'weight' => 25],
                    ['type' => 'DIAMOND', 'amount' => 50, 'label' => '💎 50 เพชร', 'weight' => 20],
                    ['type' => 'DIAMOND', 'amount' => 100, 'label' => '💎 100 เพชร', 'weight' => 15],
                    ['type' => 'CUBE', 'amount' => 1, 'cube_type' => 'DIAMOND', 'label' => '🧊 ลูกบาศก์เพชร', 'weight' => 5]
                ]
            ],
            [
                'cube_type' => 'DIAMOND',
                'cube_name' => 'ลูกบาศก์เพชร',
                'color_hex' => '#00e5ff',
                'min_hours' => 6,
                'max_hours' => 9,
                'drop_rate_percent' => 15.00,
                'rewards' => [
                    ['type' => 'DIAMOND', 'amount' => 200, 'label' => '💎 200 เพชร', 'weight' => 35],
                    ['type' => 'DIAMOND', 'amount' => 500, 'label' => '💎 500 เพชร', 'weight' => 25],
                    ['type' => 'GOLD', 'amount' => 500000, 'label' => '🪙 500,000 ทอง', 'weight' => 25],
                    ['type' => 'CUBE', 'amount' => 1, 'cube_type' => 'LEGENDARY', 'label' => '👑 ลูกบาศก์ในตำนาน', 'weight' => 15]
                ]
            ],
            [
                'cube_type' => 'LEGENDARY',
                'cube_name' => 'ลูกบาศก์ในตำนาน',
                'color_hex' => '#d946ef',
                'min_hours' => 9,
                'max_hours' => 14,
                'drop_rate_percent' => 5.00,
                'rewards' => [
                    ['type' => 'DIAMOND', 'amount' => 1000, 'label' => '💎 1,000 เพชร', 'weight' => 35],
                    ['type' => 'GOLD', 'amount' => 1000000, 'label' => '🪙 1,000,000 ทอง', 'weight' => 30],
                    ['type' => 'FRAME', 'character_id' => 4, 'label' => '👑 กรอบรูปจักรพรรดิ SS+', 'weight' => 20],
                    ['type' => 'DICE', 'dice_id' => 1, 'label' => '🎲 ลูกเต๋าตำนาน 3D', 'weight' => 15]
                ]
            ]
        ];

        foreach ($defaultConfigs as $cfg) {
            $stmt = $db->prepare("INSERT INTO `cube_configs` (cube_type, cube_name, color_hex, min_hours, max_hours, drop_rate_percent, rewards_json) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $rewardsJson = json_encode($cfg['rewards'], JSON_UNESCAPED_UNICODE);
            $stmt->bind_param("sssiids", $cfg['cube_type'], $cfg['cube_name'], $cfg['color_hex'], $cfg['min_hours'], $cfg['max_hours'], $cfg['drop_rate_percent'], $rewardsJson);
            $stmt->execute();
            $stmt->close();
        }
    }
}

/**
 * ดึงข้อมูลอีเวนต์สุ่มที่กำลังจัดอยู่ (หรือล่าสุด)
 */
function getActiveGachaEventData(mysqli $db, ?int $userId = null): ?array {
    ensureCubeAndEventTables($db);

    $ev = safeQueryRow($db, "
        SELECT * FROM `gacha_events` 
        WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date 
        ORDER BY id DESC LIMIT 1
    ");

    $isLive = true;
    if (!$ev) {
        $ev = safeQueryRow($db, "SELECT * FROM `gacha_events` WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    }
    if (!$ev) {
        $ev = safeQueryRow($db, "SELECT * FROM `gacha_events` ORDER BY id DESC LIMIT 1");
    }
    if (!$ev) return null;

    $nowSec = time();
    $endSec = !empty($ev['end_date']) ? strtotime($ev['end_date']) : 0;
    if (!empty($ev['is_active']) && $endSec > 0 && $nowSec > $endSec) {
        $db->query("UPDATE `gacha_events` SET end_date = DATE_ADD(NOW(), INTERVAL 14 DAY) WHERE id = {$ev['id']}");
        $ev['end_date'] = date('Y-m-d H:i:s', strtotime('+14 days'));
        $endSec = strtotime($ev['end_date']);
        $isLive = true;
    }

    $ev['is_live_now'] = $isLive;
    $ev['event_type'] = $ev['event_type'] ?? 'FRAME';
    $ev['cost_diamond'] = (int)($ev['cost_diamond'] ?? 100);

    // เช็คและซิงก์ข้อมูลกิจกรรมลูกเต๋า 3D
    $dEv = safeQueryRow($db, "SELECT * FROM `dice_gacha_events` WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    if (!$dEv) {
        $dEv = safeQueryRow($db, "SELECT * FROM `dice_gacha_events` ORDER BY id DESC LIMIT 1");
    }
    if ($dEv && !empty($dEv['is_active']) && !empty($dEv['end_date']) && strtotime($dEv['end_date']) < $nowSec) {
        $db->query("UPDATE `dice_gacha_events` SET end_date = DATE_ADD(NOW(), INTERVAL 14 DAY) WHERE id = {$dEv['id']}");
        $dEv['end_date'] = date('Y-m-d H:i:s', strtotime('+14 days'));
    }
    if ($dEv) {
        $ev['dice_start_date'] = $dEv['start_date'] ?? $ev['start_date'];
        $ev['dice_end_date'] = $dEv['end_date'] ?? $ev['end_date'];
        $ev['dice_is_expired'] = false;
    } else {
        $ev['dice_start_date'] = $ev['start_date'];
        $ev['dice_end_date'] = $ev['end_date'];
        $ev['dice_is_expired'] = false;
    }

    // ดึงข้อมูลกรอบรูปเป้าหมาย
    $targetCharId = (int)($ev['target_character_id'] ?? 1);
    $cRow = safeQueryRow($db, "SELECT c.*, s.name as skill_name, s.code as skill_code FROM characters c LEFT JOIN skills s ON c.skill_id = s.id WHERE c.id = {$targetCharId} LIMIT 1");
    if (!$cRow) {
        $cRow = safeQueryRow($db, "SELECT * FROM characters WHERE id = {$targetCharId} LIMIT 1");
    }
    $ev['target_character'] = $cRow;

    // ดึงข้อมูลลูกเต๋าเป้าหมาย
    $targetDiceId = (int)($ev['target_dice_id'] ?? 1);
    $dRow = safeQueryRow($db, "SELECT d.*, s.name as skill_name FROM dice d LEFT JOIN skills s ON d.skill_id = s.id WHERE d.id = {$targetDiceId} LIMIT 1");
    if (!$dRow) {
        $dRow = safeQueryRow($db, "SELECT * FROM dice WHERE id = {$targetDiceId} LIMIT 1");
    }
    $ev['target_dice'] = $dRow;

    // คำนวณเวลาที่เหลือเป็นวินาที และสถานะกิจกรรม
    $nowSec = time();
    $endSec = !empty($ev['end_date']) ? strtotime($ev['end_date']) : 0;
    $startSec = !empty($ev['start_date']) ? strtotime($ev['start_date']) : 0;
    $isExpired = ($endSec > 0 && $nowSec > $endSec);
    $isUpcoming = ($startSec > 0 && $nowSec < $startSec);
    $ev['is_expired'] = $isExpired;
    $ev['is_upcoming'] = $isUpcoming;
    $ev['is_live_now'] = (!$isExpired && !$isUpcoming && !empty($ev['is_active']));
    $ev['remaining_seconds'] = max(0, $endSec - $nowSec);
    $ev['server_time'] = date('Y-m-d H:i:s');
    $ev['server_timestamp'] = $nowSec;
    $ev['server_timezone'] = 'Asia/Bangkok';

    // คำนวณเงื่อนไขการแลกการ์ดเงาสำหรับเป้าหมายนี้ (Target Exchange Requirements)
    $targetGrade = strtoupper(trim($cRow['grade'] ?? 'S+'));
    $reqBlack = (int)($ev['req_shadow_black'] ?? 15);
    $reqRed = (int)($ev['req_shadow_red'] ?? 15);
    $reqOrange = (int)($ev['req_shadow_orange'] ?? 15);
    $reqBlue = (int)($ev['req_shadow_blue'] ?? 10);
    $reqGold = (int)($ev['req_shadow_gold'] ?? 4);

    $tiers = [];
    if (!empty($ev['exchange_tiers_json'])) {
        $dec = json_decode($ev['exchange_tiers_json'], true);
        if (is_array($dec)) $tiers = $dec;
    }
    if (empty($tiers) && !empty($ev['shadow_config_json'])) {
        $dec2 = json_decode($ev['shadow_config_json'], true);
        if (is_array($dec2) && isset($dec2['tiers'])) {
            $tiers = $dec2['tiers'];
        }
    }

    if ($targetGrade === 'SS+') {
        $reqs = [
            'black' => isset($tiers['SS+']['reqs']['black']) ? (int)$tiers['SS+']['reqs']['black'] : max(25, $reqBlack),
            'red' => isset($tiers['SS+']['reqs']['red']) ? (int)$tiers['SS+']['reqs']['red'] : max(25, $reqRed),
            'orange' => isset($tiers['SS+']['reqs']['orange']) ? (int)$tiers['SS+']['reqs']['orange'] : max(20, $reqOrange),
            'blue' => isset($tiers['SS+']['reqs']['blue']) ? (int)$tiers['SS+']['reqs']['blue'] : max(15, $reqBlue),
            'gold' => isset($tiers['SS+']['reqs']['gold']) ? (int)$tiers['SS+']['reqs']['gold'] : max(8, $reqGold)
        ];
    } elseif ($targetGrade === 'S') {
        $reqs = [
            'black' => isset($tiers['S']['reqs']['black']) ? (int)$tiers['S']['reqs']['black'] : 10,
            'red' => isset($tiers['S']['reqs']['red']) ? (int)$tiers['S']['reqs']['red'] : 10,
            'orange' => isset($tiers['S']['reqs']['orange']) ? (int)$tiers['S']['reqs']['orange'] : 8,
            'blue' => isset($tiers['S']['reqs']['blue']) ? (int)$tiers['S']['reqs']['blue'] : 5,
            'gold' => isset($tiers['S']['reqs']['gold']) ? (int)$tiers['S']['reqs']['gold'] : 2
        ];
    } else { // S+
        $reqs = [
            'black' => isset($tiers['S+']['reqs']['black']) ? (int)$tiers['S+']['reqs']['black'] : $reqBlack,
            'red' => isset($tiers['S+']['reqs']['red']) ? (int)$tiers['S+']['reqs']['red'] : $reqRed,
            'orange' => isset($tiers['S+']['reqs']['orange']) ? (int)$tiers['S+']['reqs']['orange'] : $reqOrange,
            'blue' => isset($tiers['S+']['reqs']['blue']) ? (int)$tiers['S+']['reqs']['blue'] : $reqBlue,
            'gold' => isset($tiers['S+']['reqs']['gold']) ? (int)$tiers['S+']['reqs']['gold'] : $reqGold
        ];
    }

    // ดึงจำนวนการ์ดเงาที่ผู้เล่นมีอยู่ในคลังเฉพาะสำหรับอีเวนต์นี้ (ไม่นำเงาจากอีเวนต์เก่ามาปน)
    $userMaterials = [
        'SHADOW_BLACK_A' => 0,
        'SHADOW_RED_A' => 0,
        'SHADOW_ORANGE_A' => 0,
        'SHADOW_BLUE_APLUS' => 0,
        'SHADOW_BLUE_A' => 0,
        'SHADOW_GOLD_S' => 0,
        'SHADOW_GOLD_APLUS' => 0,
        'SPECIAL_CARD' => 0
    ];
    $cardEvId = (int)($ev['id'] ?? 1);
    if ($userId && $userId > 0 && !$isExpired && $cardEvId > 0) {
        $stmt = $db->prepare("SELECT material_code, quantity FROM user_materials WHERE user_id = ? AND event_id = ? AND event_type = 'FRAME'");
        if ($stmt) {
            $stmt->bind_param("ii", $userId, $cardEvId);
            $stmt->execute();
            $matRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            foreach ($matRows as $row) {
                $userMaterials[$row['material_code']] = (int)$row['quantity'];
            }
        }
    }
    if ($userId && $userId > 0) {
        $spCardRes = @$db->query("SELECT COALESCE(SUM(quantity), 0) AS qty FROM user_materials WHERE user_id = " . (int)$userId . " AND material_code = 'SPECIAL_CARD'");
        if ($spCardRes && ($spCardRow = $spCardRes->fetch_assoc())) {
            $userMaterials['SPECIAL_CARD'] = (int)$spCardRow['qty'];
        }
    }

    $haveBlack = $userMaterials['SHADOW_BLACK_A'] ?? 0;
    $haveRed = $userMaterials['SHADOW_RED_A'] ?? 0;
    $haveOrange = $userMaterials['SHADOW_ORANGE_A'] ?? 0;
    $haveBlue = ($userMaterials['SHADOW_BLUE_APLUS'] ?? 0) + ($userMaterials['SHADOW_BLUE_A'] ?? 0);
    $haveGold = ($userMaterials['SHADOW_GOLD_S'] ?? 0) + ($userMaterials['SHADOW_GOLD_APLUS'] ?? 0);

    $shadowList = [
        [
            'key' => 'black',
            'code' => 'SHADOW_BLACK_A',
            'name' => 'เงาดำ A',
            'full_name' => 'การ์ดเงาสีดำ ระดับ A',
            'grade' => 'A',
            'icon' => '⬛',
            'color' => '#64748b',
            'required' => $reqs['black'],
            'owned' => $haveBlack,
            'is_ready' => ($haveBlack >= $reqs['black']),
            'event_id' => $cardEvId,
            'start_date' => $ev['start_date'] ?? null,
            'end_date' => $ev['end_date'] ?? null,
            'is_expired' => $isExpired
        ],
        [
            'key' => 'red',
            'code' => 'SHADOW_RED_A',
            'name' => 'เงาแดง A',
            'full_name' => 'การ์ดเงาสีแดง ระดับ A',
            'grade' => 'A',
            'icon' => '🟥',
            'color' => '#ef4444',
            'required' => $reqs['red'],
            'owned' => $haveRed,
            'is_ready' => ($haveRed >= $reqs['red']),
            'event_id' => $cardEvId,
            'start_date' => $ev['start_date'] ?? null,
            'end_date' => $ev['end_date'] ?? null,
            'is_expired' => $isExpired
        ],
        [
            'key' => 'orange',
            'code' => 'SHADOW_ORANGE_A',
            'name' => 'เงาส้ม A',
            'full_name' => 'การ์ดเงาสีส้ม ระดับ A',
            'grade' => 'A',
            'icon' => '🟧',
            'color' => '#f97316',
            'required' => $reqs['orange'],
            'owned' => $haveOrange,
            'is_ready' => ($haveOrange >= $reqs['orange']),
            'event_id' => $cardEvId,
            'start_date' => $ev['start_date'] ?? null,
            'end_date' => $ev['end_date'] ?? null,
            'is_expired' => $isExpired
        ],
        [
            'key' => 'blue',
            'code' => 'SHADOW_BLUE_APLUS',
            'name' => 'เงาฟ้า A+',
            'full_name' => 'การ์ดเงาสีฟ้า ระดับ A+',
            'grade' => 'A+',
            'icon' => '🟦',
            'color' => '#38bdf8',
            'required' => $reqs['blue'],
            'owned' => $haveBlue,
            'is_ready' => ($haveBlue >= $reqs['blue']),
            'event_id' => $cardEvId,
            'start_date' => $ev['start_date'] ?? null,
            'end_date' => $ev['end_date'] ?? null,
            'is_expired' => $isExpired
        ],
        [
            'key' => 'gold',
            'code' => 'SHADOW_GOLD_S',
            'name' => 'เงาทอง S',
            'full_name' => 'การ์ดเงาสีทอง ระดับ S',
            'grade' => 'S',
            'icon' => '🟨',
            'color' => '#ffd700',
            'required' => $reqs['gold'],
            'owned' => $haveGold,
            'is_ready' => ($haveGold >= $reqs['gold']),
            'event_id' => $cardEvId,
            'start_date' => $ev['start_date'] ?? null,
            'end_date' => $ev['end_date'] ?? null,
            'is_expired' => $isExpired
        ]
    ];

    $readyCount = 0;
    foreach ($shadowList as $s) {
        if ($s['is_ready']) $readyCount++;
    }

    $ev['target_requirements'] = $reqs;
    $ev['reqs'] = $reqs;
    $ev['shadow_materials'] = $shadowList;
    $ev['user_materials'] = $userMaterials;
    $cCheck = safeQueryRow($db, "SELECT id FROM user_inventory WHERE user_id = {$userId} AND character_id = {$targetCharId} LIMIT 1");
    $userHasTargetChar = !empty($cCheck);
    $ev['user_has_target_character'] = $userHasTargetChar;

    $ev['exchange_progress'] = [
        'ready_count' => $readyCount,
        'total_types' => count($shadowList),
        'can_exchange' => ($readyCount === count($shadowList) && !$isExpired),
        'target_grade' => $targetGrade,
        'target_character_id' => $targetCharId,
        'target_name' => $cRow['name'] ?? '',
        'already_owned' => $userHasTargetChar,
        'is_expired' => $isExpired
    ];

    // คำนวณเงื่อนไขการสะสมการ์ดเงาสำหรับลูกเต๋า (Dice Shadow Exchange)
    $diceReqBlack = 15;
    $diceReqRed = 15;
    $diceReqOrange = 15;
    $diceReqBlue = 10;
    $diceReqGold = 4;
    $diceReqBlack = 15;
    $diceReqRed = 15;
    $diceReqOrange = 15;
    $diceReqBlue = 10;
    $diceReqGold = 4;
    $diceEvId = 1;
    $diceStartDate = null;
    $diceEndDate = null;
    $diceIsExpired = false;
    try {
        $dEvRes = $db->query("SELECT * FROM dice_gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1");
        if (!$dEvRes || $dEvRes->num_rows === 0) {
            $dEvRes = $db->query("SELECT * FROM dice_gacha_events ORDER BY id DESC LIMIT 1");
        }
        if ($dEvRes && $dEv = $dEvRes->fetch_assoc()) {
            $diceEvId = (int)$dEv['id'];
            $diceStartDate = $dEv['start_date'] ?? null;
            $diceEndDate = $dEv['end_date'] ?? null;
            $diceIsExpired = (!empty($diceEndDate) && time() > strtotime($diceEndDate));
            $diceReqBlack = (int)($dEv['req_shadow_black'] ?? 15);
            $diceReqRed = (int)($dEv['req_shadow_red'] ?? 15);
            $diceReqOrange = (int)($dEv['req_shadow_orange'] ?? 15);
            $diceReqBlue = (int)($dEv['req_shadow_blue'] ?? 10);
            $diceReqGold = (int)($dEv['req_shadow_gold'] ?? 4);
        }
    } catch (Throwable $e) {}

    // ดึงเงาของกิจกรรมลูกเต๋าโดยเฉพาะ (แยกกับกรอบรูป ไม่ใช้ปนกัน)
    $diceMaterials = [];
    if ($userId && $userId > 0 && $diceEvId > 0 && !$diceIsExpired) {
        $stmtD = $db->prepare("SELECT material_code, quantity FROM user_materials WHERE user_id = ? AND event_id = ? AND event_type = 'DICE'");
        if ($stmtD) {
            $stmtD->bind_param("ii", $userId, $diceEvId);
            $stmtD->execute();
            $dRows = $stmtD->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmtD->close();
            foreach ($dRows as $row) {
                $diceMaterials[$row['material_code']] = (int)$row['quantity'];
            }
        }
    }
    if ($userId && $userId > 0) {
        $spDiceRes = @$db->query("SELECT COALESCE(SUM(quantity), 0) AS qty FROM user_materials WHERE user_id = " . (int)$userId . " AND material_code = 'SPECIAL_DICE_CARD'");
        if ($spDiceRes && ($spDiceRow = $spDiceRes->fetch_assoc())) {
            $diceMaterials['SPECIAL_DICE_CARD'] = (int)$spDiceRow['qty'];
        }
    }
    $haveDiceBlack = $diceMaterials['SHADOW_BLACK_A'] ?? 0;
    $haveDiceRed = $diceMaterials['SHADOW_RED_A'] ?? 0;
    $haveDiceOrange = $diceMaterials['SHADOW_ORANGE_A'] ?? 0;
    $haveDiceBlue = ($diceMaterials['SHADOW_BLUE_APLUS'] ?? 0) + ($diceMaterials['SHADOW_BLUE_A'] ?? 0);
    $haveDiceGold = ($diceMaterials['SHADOW_GOLD_S'] ?? 0) + ($diceMaterials['SHADOW_GOLD_APLUS'] ?? 0);

    $diceShadowList = [
        [
            'key' => 'black', 'code' => 'SHADOW_BLACK_A', 'name' => 'เงาดำ A',
            'grade' => 'A', 'icon' => '⬛', 'color' => '#94a3b8',
            'required' => $diceReqBlack, 'owned' => $haveDiceBlack,
            'is_ready' => ($haveDiceBlack >= $diceReqBlack),
            'event_id' => $diceEvId,
            'start_date' => $diceStartDate,
            'end_date' => $diceEndDate,
            'is_expired' => $diceIsExpired
        ],
        [
            'key' => 'red', 'code' => 'SHADOW_RED_A', 'name' => 'เงาแดง A',
            'grade' => 'A', 'icon' => '🟥', 'color' => '#ef4444',
            'required' => $diceReqRed, 'owned' => $haveDiceRed,
            'is_ready' => ($haveDiceRed >= $diceReqRed),
            'event_id' => $diceEvId,
            'start_date' => $diceStartDate,
            'end_date' => $diceEndDate,
            'is_expired' => $diceIsExpired
        ],
        [
            'key' => 'orange', 'code' => 'SHADOW_ORANGE_A', 'name' => 'เงาส้ม A',
            'grade' => 'A', 'icon' => '🟧', 'color' => '#f97316',
            'required' => $diceReqOrange, 'owned' => $haveDiceOrange,
            'is_ready' => ($haveDiceOrange >= $diceReqOrange),
            'event_id' => $diceEvId,
            'start_date' => $diceStartDate,
            'end_date' => $diceEndDate,
            'is_expired' => $diceIsExpired
        ],
        [
            'key' => 'blue', 'code' => 'SHADOW_BLUE_APLUS', 'name' => 'เงาฟ้า A+',
            'grade' => 'A+', 'icon' => '🟦', 'color' => '#38bdf8',
            'required' => $diceReqBlue, 'owned' => $haveDiceBlue,
            'is_ready' => ($haveDiceBlue >= $diceReqBlue),
            'event_id' => $diceEvId,
            'start_date' => $diceStartDate,
            'end_date' => $diceEndDate,
            'is_expired' => $diceIsExpired
        ],
        [
            'key' => 'gold', 'code' => 'SHADOW_GOLD_S', 'name' => 'เงาทอง S',
            'grade' => 'S', 'icon' => '🟨', 'color' => '#ffd700',
            'required' => $diceReqGold, 'owned' => $haveDiceGold,
            'is_ready' => ($haveDiceGold >= $diceReqGold),
            'event_id' => $diceEvId,
            'start_date' => $diceStartDate,
            'end_date' => $diceEndDate,
            'is_expired' => $diceIsExpired
        ]
    ];
    $diceReadyCount = 0;
    foreach ($diceShadowList as $ds) {
        if ($ds['is_ready']) $diceReadyCount++;
    }
    $userHasTargetDice = false;
    if ($userId && $userId > 0) {
        $chkD = safeQueryRow($db, "SELECT id FROM user_inventory WHERE user_id = {$userId} AND item_type = 'DICE' AND dice_id = {$targetDiceId} LIMIT 1");
        if (!$chkD) {
            $chkD = safeQueryRow($db, "SELECT id FROM user_dice WHERE user_id = {$userId} AND dice_id = {$targetDiceId} LIMIT 1");
        }
        $userHasTargetDice = (bool)$chkD;
    }

    $ev['user_has_target_dice'] = $userHasTargetDice;
    $ev['dice_event_id'] = $diceEvId;
    $ev['dice_start_date'] = $diceStartDate;
    $ev['dice_end_date'] = $diceEndDate;
    $ev['dice_is_expired'] = $diceIsExpired;
    $ev['dice_shadow_materials'] = $diceShadowList;
    $ev['dice_exchange_progress'] = [
        'ready_count' => $diceReadyCount,
        'total_types' => count($diceShadowList),
        'can_exchange' => ($diceReadyCount === count($diceShadowList) && !$userHasTargetDice && !$diceIsExpired),
        'target_dice_id' => $targetDiceId,
        'target_name' => $dRow['name'] ?? 'ลูกเต๋า 3D แรร์',
        'already_owned' => $userHasTargetDice,
        'is_expired' => $diceIsExpired
    ];

    return $ev;
}

/**
 * สุ่มเปิดอีเวนต์พิเศษ (Event Gacha Pull)
 */
function executeEventGachaPull(mysqli $db, int $userId, int $packCount = 1, string $category = 'ALL', string $currency = 'DIAMOND', string $packTier = 'SPECIAL'): array {
    ensureCubeAndEventTables($db);

    $event = getActiveGachaEventData($db, $userId);
    if (!$event) {
        return ['status' => 'error', 'message' => "ขณะนี้ไม่มีกิจกรรมอีเวนต์ที่เปิดอยู่"];
    }

    // หากเป็นการสุ่มลูกเต๋า และผู้เล่นได้ทำภารกิจสำเร็จได้รับลูกเต๋าไปแล้ว ให้ล็อคไม่ให้สุ่มเพิ่ม
    if ($category === 'DICE' && !empty($event['user_has_target_dice'])) {
        return [
            'status' => 'error',
            'message' => 'คุณทำภารกิจสำเร็จและได้รับลูกเต๋านี้แล้ว (ล็อคการสุ่ม ไม่สามารถสุ่มเพิ่มได้)',
            'already_completed' => true
        ];
    }

    $totalCards = max(1, min(10, $packCount));
    $costPerSingle = max(10, (int)($event['cost_diamond'] ?? 50));

    $diamondsSpent = 0;
    $goldSpent = 0;

    if ($currency === 'GOLD') {
        $totalCost = ($totalCards === 5) ? 120000 : (30000 * $totalCards);
        $uRow = safeQueryRow($db, "SELECT diamond, gold FROM users WHERE id = {$userId} FOR UPDATE");
        $curGold = (int)($uRow['gold'] ?? 0);
        if (!$uRow || $curGold < $totalCost) {
            return [
                'status' => 'error',
                'message' => "ทองของคุณไม่เพียงพอ ต้องการ " . number_format($totalCost) . " ทอง (คุณมี " . number_format($curGold) . " ทอง)"
            ];
        }
        @$db->query("UPDATE users SET gold = gold - {$totalCost} WHERE id = {$userId}");
        $goldSpent = $totalCost;
    } else {
        if ($packTier === 'PREMIUM') {
            if ($totalCards === 10) {
                $totalCost = (int)round($costPerSingle * 10 * 1.35);
            } elseif ($totalCards === 5) {
                $totalCost = (int)round($costPerSingle * 5 * 1.45);
            } else {
                $totalCost = (int)round($costPerSingle * 1.6 * $totalCards);
            }
        } else {
            if ($totalCards === 5) {
                $totalCost = (int)round($costPerSingle * 5 * 0.9);
            } else {
                $totalCost = $costPerSingle * $totalCards;
            }
        }

        $uRow = safeQueryRow($db, "SELECT diamond, gold FROM users WHERE id = {$userId} FOR UPDATE");
        $curDia = (int)($uRow['diamond'] ?? 0);
        if (!$uRow || $curDia < $totalCost) {
            return [
                'status' => 'error',
                'message' => "เพชรของคุณไม่เพียงพอ ต้องการ " . number_format($totalCost) . " เพชร (คุณมี " . number_format($curDia) . " เพชร)"
            ];
        }
        @$db->query("UPDATE users SET diamond = diamond - {$totalCost} WHERE id = {$userId}");
        $diamondsSpent = $totalCost;
    }

    $drops = [];
    for ($i = 0; $i < $totalCards; $i++) {
        if (function_exists('performSingleGachaCardDrop')) {
            $drops[] = performSingleGachaCardDrop($db, $userId, $event, $category, $packTier);
        } else {
            $drops[] = [
                'type' => 'MATERIAL',
                'category' => ($category === 'DICE') ? 'DICE' : 'FRAME',
                'material_code' => 'SHADOW_BLACK_A',
                'name' => ($category === 'DICE') ? 'เงาลูกเต๋าดำ ระดับ A' : 'เงากรอบรูปดำ ระดับ A',
                'rarity' => 'A',
                'icon' => ($category === 'DICE') ? '🎲' : '⬛',
                'color' => '#64748b'
            ];
        }
    }

    // ดึงข้อมูลผู้เล่นล่าสุด
    $uUpd = safeQueryRow($db, "SELECT diamond, gold FROM users WHERE id = {$userId}") ?? ['diamond' => 0, 'gold' => 0];
    $updatedEvent = getActiveGachaEventData($db, $userId);

    return [
        'status' => 'success',
        'message' => "เปิดสุ่มสำเร็จ {$totalCards} ใบ!",
        'category' => $category,
        'currency' => $currency,
        'pack_tier' => $packTier,
        'pack_count' => $totalCards,
        'total_cards' => $totalCards,
        'cost_spent' => ($currency === 'GOLD') ? $goldSpent : $diamondsSpent,
        'diamonds_spent' => $diamondsSpent,
        'gold_spent' => $goldSpent,
        'drops' => $drops,
        'user' => [
            'diamond' => (int)$uUpd['diamond'],
            'gold' => (int)$uUpd['gold']
        ],
        'event' => $updatedEvent
    ];
}

/**
 * ดึงรายการลูกบาศก์ทั้งหมดของผู้เล่น พร้อมข้อมูลการตั้งค่าและช่องหมุน 4 ช่อง
 */
function getUserCubesList(mysqli $db, int $userId): array {
    ensureCubeAndEventTables($db);

    // ตรวจสอบลูกบาศก์ที่กำลังหมุนอยู่ หากครบเวลาแล้วให้อัปเดตเป็น READY อัตโนมัติ
    $db->query("
        UPDATE `user_cubes` 
        SET status = 'READY' 
        WHERE user_id = {$userId} AND status = 'SPINNING' AND ready_at <= NOW()
    ");

    $res = $db->query("
        SELECT uc.*, 
               COALESCE(cc.cube_name, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN 'ลูกบาศก์ในตำนาน'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN 'ลูกบาศก์เพชร'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN 'ลูกบาศก์ทอง'
                   ELSE 'ลูกบาศก์เงิน'
               END) as cube_name,
               COALESCE(cc.color_hex, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN '#a855f7'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN '#00e5ff'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN '#f59e0b'
                   ELSE '#94a3b8'
               END) as color_hex,
               COALESCE(cc.min_hours, 1) as min_hours,
               COALESCE(cc.max_hours, 3) as max_hours,
               COALESCE(cc.spin_cost_diamond, 20) as spin_cost_diamond,
               COALESCE(cc.spin_cost_gold, 10000) as spin_cost_gold,
               COALESCE(cc.aura_type, 'neon_pulse') as aura_type,
               COALESCE(cc.particle_fx, 'flare_burst') as particle_fx,
               COALESCE(cc.intensity, '2x') as intensity,
               TIMESTAMPDIFF(SECOND, NOW(), uc.ready_at) as remaining_seconds
        FROM `user_cubes` uc
        LEFT JOIN `cube_configs` cc ON uc.cube_type COLLATE utf8mb4_unicode_ci = cc.cube_type COLLATE utf8mb4_unicode_ci
        WHERE uc.user_id = {$userId} AND uc.status != 'CLAIMED'
        ORDER BY FIELD(uc.status, 'READY', 'SPINNING', 'IDLE'), uc.id DESC
    ");

    $cubes = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    foreach ($cubes as &$c) {
        $c['remaining_seconds'] = max(0, (int)($c['remaining_seconds'] ?? 0));
        $minsLeft = ceil($c['remaining_seconds'] / 300);
        $c['instant_open_diamond'] = max(5, (int)$minsLeft);
        $c['spin_cost_diamond'] = max(1, (int)($c['spin_cost_diamond'] ?? 20));
        $c['spin_cost_gold'] = max(100, (int)($c['spin_cost_gold'] ?? 10000));
        $c['slot_index'] = ($c['slot_index'] !== null && (int)$c['slot_index'] > 0) ? (int)$c['slot_index'] : null;
        $c['has_aura'] = (int)($c['has_aura'] ?? 0);
    }

    // ดึง cube_configs ทั้งหมดแนบไปด้วย
    $configs = $db->query("SELECT * FROM `cube_configs` ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
    foreach ($configs as &$cfg) {
        $cfg['rewards'] = !empty($cfg['rewards_json']) ? json_decode($cfg['rewards_json'], true) : [];
        $cfg['spin_cost_diamond'] = max(1, (int)($cfg['spin_cost_diamond'] ?? 20));
        $cfg['spin_cost_gold'] = max(100, (int)($cfg['spin_cost_gold'] ?? 10000));
    }

    return [
        'cubes' => $cubes,
        'configs' => $configs
    ];
}

/**
 * ใส่ลูกบาศก์จากกระเป๋าลงในช่องหมุน (1 - 4)
 */
function equipCubeToSlotAction(mysqli $db, int $userId, int $userCubeId, int $slotIndex): array {
    ensureCubeAndEventTables($db);
    $slotIndex = max(1, min(4, $slotIndex));

    // ตรวจสอบว่ามีลูกบาศก์หมุนอยู่หรือพร้อมเปิดในช่องนี้หรือไม่
    $occupied = $db->query("
        SELECT id, cube_type, status FROM `user_cubes` 
        WHERE user_id = {$userId} AND slot_index = {$slotIndex} AND status != 'CLAIMED' AND id != {$userCubeId}
        LIMIT 1
    ")->fetch_assoc();

    if ($occupied && in_array($occupied['status'], ['SPINNING', 'READY'], true)) {
        throw new Exception("ช่องที่ {$slotIndex} มีลูกบาศก์กำลังหมุนหรือพร้อมเปิดอยู่แล้ว");
    }

    // หากช่องนั้นมีลูกบาศก์ IDLE วางอยู่ ให้ปลดออกจากช่องก่อน
    if ($occupied && $occupied['status'] === 'IDLE') {
        $db->query("UPDATE `user_cubes` SET slot_index = NULL WHERE id = {$occupied['id']}");
    }

    // ตรวจสอบว่า userCubeId เป็นของ user นี้และ IDLE
    $cube = $db->query("
        SELECT uc.*, 
               COALESCE(cc.cube_name, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN 'ลูกบาศก์ในตำนาน'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN 'ลูกบาศก์เพชร'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN 'ลูกบาศก์ทอง'
                   ELSE 'ลูกบาศก์เงิน'
               END) as cube_name 
        FROM `user_cubes` uc 
        LEFT JOIN `cube_configs` cc ON uc.cube_type COLLATE utf8mb4_unicode_ci = cc.cube_type COLLATE utf8mb4_unicode_ci 
        WHERE uc.id = {$userCubeId} AND uc.user_id = {$userId} AND uc.status = 'IDLE'
    ")->fetch_assoc();

    if (!$cube) {
        throw new Exception("ไม่พบลูกบาศก์หรือลูกบาศก์ไม่ได้อยู่ในสถานะพร้อมใส่ช่อง");
    }

    $db->query("UPDATE `user_cubes` SET slot_index = {$slotIndex} WHERE id = {$userCubeId}");

    return [
        'status' => 'success',
        'cube_id' => $userCubeId,
        'slot_index' => $slotIndex,
        'cube_name' => $cube['cube_name'],
        'message' => "ใส่ {$cube['cube_name']} ลงในช่องที่ {$slotIndex} สำเร็จ!"
    ];
}

/**
 * นำลูกบาศก์ออกจากช่องหมุน (ก่อนเริ่มหมุน)
 */
function removeCubeFromSlotAction(mysqli $db, int $userId, int $userCubeId): array {
    ensureCubeAndEventTables($db);

    $cube = $db->query("
        SELECT uc.*, 
               COALESCE(cc.cube_name, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN 'ลูกบาศก์ในตำนาน'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN 'ลูกบาศก์เพชร'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN 'ลูกบาศก์ทอง'
                   ELSE 'ลูกบาศก์เงิน'
               END) as cube_name 
        FROM `user_cubes` uc 
        LEFT JOIN `cube_configs` cc ON uc.cube_type COLLATE utf8mb4_unicode_ci = cc.cube_type COLLATE utf8mb4_unicode_ci 
        WHERE uc.id = {$userCubeId} AND uc.user_id = {$userId}
    ")->fetch_assoc();

    if (!$cube) {
        throw new Exception("ไม่พบลูกบาศก์");
    }
    if ($cube['status'] !== 'IDLE') {
        throw new Exception("ไม่สามารถนำออกได้เนื่องจากลูกบาศก์กำลังหมุนหรือพร้อมเปิดแล้ว");
    }

    $db->query("UPDATE `user_cubes` SET slot_index = NULL WHERE id = {$userCubeId}");

    return [
        'status' => 'success',
        'cube_id' => $userCubeId,
        'message' => "นำ {$cube['cube_name']} ออกจากช่องหมุนเรียบร้อย คุณสามารถเลือกลูกบาศก์อันใหม่ได้"
    ];
}

/**
 * สุ่มเริ่มหมุนลูกบาศก์ โดยเลือกว่าจะใช้เพชรหรือทองในการหมุน
 */
function startSpinningCubeAction(mysqli $db, int $userId, int $userCubeId, string $currency = 'DIAMOND', int $targetSlot = 0): array {
    ensureCubeAndEventTables($db);
    $currency = (strtoupper($currency) === 'GOLD') ? 'GOLD' : 'DIAMOND';

    // ดึงข้อมูลลูกบาศก์
    $cube = $db->query("
        SELECT uc.*, 
               COALESCE(cc.min_hours, 1) as min_hours, 
               COALESCE(cc.max_hours, 3) as max_hours, 
               COALESCE(cc.cube_name, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN 'ลูกบาศก์ในตำนาน'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN 'ลูกบาศก์เพชร'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN 'ลูกบาศก์ทอง'
                   ELSE 'ลูกบาศก์เงิน'
               END) as cube_name, 
               COALESCE(cc.spin_cost_diamond, 20) as spin_cost_diamond, 
               COALESCE(cc.spin_cost_gold, 10000) as spin_cost_gold 
        FROM `user_cubes` uc 
        LEFT JOIN `cube_configs` cc ON uc.cube_type COLLATE utf8mb4_unicode_ci = cc.cube_type COLLATE utf8mb4_unicode_ci 
        WHERE uc.id = {$userCubeId} AND uc.user_id = {$userId} FOR UPDATE
    ")->fetch_assoc();

    if (!$cube) {
        throw new Exception("ไม่พบลูกบาศก์ที่ระบุ");
    }
    if ($cube['status'] !== 'IDLE') {
        throw new Exception("ลูกบาศก์นี้ไม่ได้อยู่ในสถานะพร้อมหมุน");
    }

    // กำหนด slot_index (1-4)
    $slotIndex = (int)($cube['slot_index'] ?? 0);
    if ($slotIndex < 1 || $slotIndex > 4) {
        if ($targetSlot >= 1 && $targetSlot <= 4) {
            $slotIndex = $targetSlot;
        } else {
            // หาช่องว่าง 1-4
            $usedSlotsRes = $db->query("SELECT slot_index FROM `user_cubes` WHERE user_id = {$userId} AND slot_index IS NOT NULL AND status != 'CLAIMED' AND id != {$userCubeId}")->fetch_all(MYSQLI_ASSOC);
            $usedSlots = array_map('intval', array_column($usedSlotsRes, 'slot_index'));
            for ($s = 1; $s <= 4; $s++) {
                if (!in_array($s, $usedSlots, true)) {
                    $slotIndex = $s;
                    break;
                }
            }
            if ($slotIndex < 1 || $slotIndex > 4) $slotIndex = 1;
        }
    }

    // ตรวจสอบว่าช่องนี้กำลังหมุนอยู่หรือไม่
    $spinningInSlot = $db->query("
        SELECT id FROM `user_cubes` 
        WHERE user_id = {$userId} AND slot_index = {$slotIndex} AND status IN ('SPINNING', 'READY') AND id != {$userCubeId}
    ")->fetch_assoc();
    if ($spinningInSlot) {
        throw new Exception("ช่องที่ {$slotIndex} มีลูกบาศก์กำลังหมุนอยู่แล้ว");
    }

    // ดึงค่าใช้จ่ายตาม Currency ที่เลือก
    $cost = ($currency === 'GOLD') 
        ? max(0, (int)($cube['spin_cost_gold'] ?? 10000))
        : max(0, (int)($cube['spin_cost_diamond'] ?? 20));

    // ตรวจสอบและหักเงิน/เพชรของผู้เล่น
    $uRow = $db->query("SELECT gold, diamond FROM users WHERE id = {$userId} FOR UPDATE")->fetch_assoc();
    if (!$uRow) {
        throw new Exception("ไม่พบข้อมูลผู้ใช้");
    }

    if ($currency === 'GOLD') {
        if ((int)$uRow['gold'] < $cost) {
            throw new Exception("ทองของคุณไม่เพียงพอสำหรับการหมุน (ต้องการ " . number_format($cost) . " ทอง)");
        }
        $db->query("UPDATE users SET gold = gold - {$cost} WHERE id = {$userId}");
    } else {
        if ((int)$uRow['diamond'] < $cost) {
            throw new Exception("เพชรของคุณไม่เพียงพอสำหรับการหมุน (ต้องการ " . number_format($cost) . " เพชร)");
        }
        $db->query("UPDATE users SET diamond = diamond - {$cost} WHERE id = {$userId}");
    }

    $minH = (int)($cube['min_hours'] ?? 1);
    $maxH = (int)($cube['max_hours'] ?? 3);
    if ($maxH < $minH) {
        $maxH = $minH;
    }

    $hasAura = 0;
    if ($currency === 'DIAMOND') {
        // หมุนด้วยเพชร: หมุนแบบเต็มเวลา max เสมอ และมีแสดงเอฟเฟกต์ออร่าตอนลูกบาศก์หมุน
        $baseHours = $maxH;
        $extraMins = 0;
        $totalSeconds = $maxH * 3600;
        $hasAura = 1;
    } else {
        // หมุนด้วยทอง: สุ่มเวลาหมุนระหว่าง minH ถึง maxH
        // หากสุ่มได้เวลาสูงสุด (maxH เช่น 2 ชม.) ให้มีแสดงเออร่าตอนลูกบาศก์หมุนด้วย
        $baseHours = mt_rand($minH, $maxH);
        if ($baseHours >= $maxH) {
            $extraMins = 0;
            $totalSeconds = $maxH * 3600;
            $hasAura = 1;
        } else {
            $extraMins = mt_rand(0, 3) * 15;
            $totalSeconds = ($baseHours * 3600) + ($extraMins * 60);
            $hasAura = 0;
        }
    }
    $spinHoursDecimal = round($totalSeconds / 3600, 2);

    $stmt = $db->prepare("
        UPDATE `user_cubes` 
        SET status = 'SPINNING',
            spin_hours = ?,
            slot_index = ?,
            spin_cost_currency = ?,
            spin_cost_amount = ?,
            has_aura = ?,
            spin_started_at = NOW(),
            ready_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
        WHERE id = ?
    ");
    $stmt->bind_param("disiiii", $spinHoursDecimal, $slotIndex, $currency, $cost, $hasAura, $totalSeconds, $userCubeId);
    $stmt->execute();
    $stmt->close();

    $updatedUser = $db->query("SELECT gold, diamond FROM users WHERE id = {$userId}")->fetch_assoc();

    $spinMsg = ($currency === 'DIAMOND')
        ? "💎 ใช้ {$cost} เพชร เริ่มหมุน {$cube['cube_name']} (ช่องที่ {$slotIndex}) เต็มเวลา MAX ({$spinHoursDecimal} ชม.) พร้อมรับออร่าพลังเวทเรืองแสง!"
        : ($hasAura 
            ? "✨ โชคดีมาก! ใช้ " . number_format($cost) . " ทอง สุ่มได้เวลาสูงสุด MAX ({$spinHoursDecimal} ชม.) พร้อมปลุกพลังออร่าหมุนสำเร็จ!"
            : "🪙 ใช้ " . number_format($cost) . " ทอง เริ่มหมุน {$cube['cube_name']} (ช่องที่ {$slotIndex}) สุ่มเวลาได้ {$spinHoursDecimal} ชม.");

    return [
        'status' => 'success',
        'cube_id' => $userCubeId,
        'cube_type' => $cube['cube_type'],
        'cube_name' => $cube['cube_name'],
        'slot_index' => $slotIndex,
        'currency_used' => $currency,
        'cost_paid' => $cost,
        'has_aura' => $hasAura,
        'user_gold' => (int)$updatedUser['gold'],
        'user_diamond' => (int)$updatedUser['diamond'],
        'spin_hours' => $spinHoursDecimal,
        'duration_seconds' => $totalSeconds,
        'message' => $spinMsg
    ];
}

/**
 * เร่งเวลาลูกบาศก์เปิดทันทีด้วยเพชร
 */
function instantSpeedupCube(mysqli $db, int $userId, int $userCubeId): array {
    ensureCubeAndEventTables($db);

    $cube = $db->query("
        SELECT uc.*, TIMESTAMPDIFF(SECOND, NOW(), uc.ready_at) as remaining_seconds 
        FROM `user_cubes` uc 
        WHERE uc.id = {$userCubeId} AND uc.user_id = {$userId} FOR UPDATE
    ")->fetch_assoc();

    if (!$cube) {
        throw new Exception("ไม่พบลูกบาศก์ที่ระบุ");
    }
    if ($cube['status'] !== 'SPINNING') {
        throw new Exception("ลูกบาศก์นี้ไม่ได้อยู่ในสถานะกำลังหมุน");
    }

    $remSec = max(0, (int)$cube['remaining_seconds']);
    $minsLeft = ceil($remSec / 300);
    $diaCost = max(5, (int)$minsLeft);

    // ตรวจสอบเพชร
    $uRow = $db->query("SELECT diamond FROM users WHERE id = {$userId} FOR UPDATE")->fetch_assoc();
    if (!$uRow || (int)$uRow['diamond'] < $diaCost) {
        throw new Exception("เพชรของคุณไม่เพียงพอสำหรับการเปิดทันที (ต้องการ {$diaCost} เพชร)");
    }

    // หักเพชรและอัปเดตเป็น READY
    $db->query("UPDATE users SET diamond = diamond - {$diaCost} WHERE id = {$userId}");
    $db->query("UPDATE `user_cubes` SET status = 'READY', ready_at = NOW() WHERE id = {$userCubeId}");

    // เปิดรับรางวัลทันทีเหมือนสุ่มการ์ดตามที่ผู้เล่นต้องการ
    $claimRes = claimCubeRewardAction($db, $userId, $userCubeId);
    $claimRes['diamond_cost'] = $diaCost;
    $claimRes['instant_opened'] = true;
    $claimRes['message'] = "ใช้ {$diaCost} เพชรเปิดลูกบาศก์สำเร็จ! คุณได้รับรางวัลเรียบร้อยแล้ว";
    return $claimRes;
}

/**
 * เปิดรับรางวัลจากลูกบาศก์ (สุ่มของรางวัลตามเวลาที่หมุนได้และเรต Admin)
 */
function claimCubeRewardAction(mysqli $db, int $userId, int $userCubeId): array {
    ensureCubeAndEventTables($db);

    $cube = $db->query("
        SELECT uc.*, 
               COALESCE(cc.cube_name, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN 'ลูกบาศก์ในตำนาน'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN 'ลูกบาศก์เพชร'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN 'ลูกบาศก์ทอง'
                   ELSE 'ลูกบาศก์เงิน'
               END) as cube_name, 
               cc.rewards_json, 
               COALESCE(cc.color_hex, CASE 
                   WHEN UPPER(uc.cube_type) = 'LEGENDARY' THEN '#a855f7'
                   WHEN UPPER(uc.cube_type) = 'DIAMOND' THEN '#00e5ff'
                   WHEN UPPER(uc.cube_type) = 'GOLD' THEN '#f59e0b'
                   ELSE '#94a3b8'
               END) as color_hex 
        FROM `user_cubes` uc 
        LEFT JOIN `cube_configs` cc ON uc.cube_type COLLATE utf8mb4_unicode_ci = cc.cube_type COLLATE utf8mb4_unicode_ci 
        WHERE uc.id = {$userCubeId} AND uc.user_id = {$userId} FOR UPDATE
    ")->fetch_assoc();

    if (!$cube) {
        throw new Exception("ไม่พบลูกบาศก์ที่ระบุ");
    }
    if ($cube['status'] === 'SPINNING') {
        // ตรวจสอบว่าครบเวลาหรือยัง
        $isReady = $db->query("SELECT (NOW() >= '{$cube['ready_at']}') as r")->fetch_assoc()['r'] ?? 0;
        if (!$isReady) {
            throw new Exception("ลูกบาศก์ยังหมุนไม่เสร็จ กรุณารอหรือใช้เพชรเร่งเวลา");
        }
        $cube['status'] = 'READY';
    }

    if ($cube['status'] !== 'READY') {
        throw new Exception("ลูกบาศก์นี้เปิดรับรางวัลไปแล้วหรือไม่พร้อมเปิด");
    }

    // คำนวณรางวัลจาก rewards_json
    $rewards = json_decode($cube['rewards_json'] ?? '[]', true);
    if (empty($rewards)) {
        $rewards = [
            ['type' => 'GOLD', 'amount' => 50000, 'label' => '🪙 50,000 ทอง', 'weight' => 70],
            ['type' => 'DIAMOND', 'amount' => 50, 'label' => '💎 50 เพชร', 'weight' => 30]
        ];
    }

    // ยิ่งสุ่มเวลาหมุนได้นาน (เช่น >= 8 ชม.) ยิ่งเพิ่มน้ำหนักให้รางวัลหายาก
    $spinHours = (float)($cube['spin_hours'] ?? 2.0);
    $totalWeight = 0;
    foreach ($rewards as &$r) {
        $w = (float)($r['weight'] ?? 10);
        if ($spinHours >= 8.0 && ($r['type'] === 'DIAMOND' || $r['type'] === 'FRAME' || $r['type'] === 'CUBE')) {
            $w *= 1.6; // โบนัสเวลาหมุนนาน
        }
        $r['_effective_weight'] = $w;
        $totalWeight += $w;
    }

    $rnd = mt_rand(1, max(1, (int)($totalWeight * 100))) / 100;
    $picked = $rewards[0];
    foreach ($rewards as $r) {
        $rnd -= $r['_effective_weight'];
        if ($rnd <= 0) {
            $picked = $r;
            break;
        }
    }

    // มอบของรางวัลให้ผู้เล่น พร้อมจัดกลุ่ม rewards_list เพื่อแสดงผลเหมือนสุ่มการ์ด
    $rType = strtoupper($picked['type'] ?? 'GOLD');
    $rAmount = (int)($picked['amount'] ?? 10000);

    $rewardsList = [];
    $totalGoldWon = 0;
    $totalDiaWon = 0;

    if ($rType === 'GOLD') {
        $totalGoldWon += $rAmount;
        $rewardsList[] = [
            'type' => 'GOLD',
            'amount' => $rAmount,
            'title' => '+' . number_format($rAmount) . ' ทอง',
            'subtitle' => 'เหรียญทองเข้าคลัง',
            'grade' => ($rAmount >= 500000 ? 'SS+' : ($rAmount >= 100000 ? 'S' : 'A+')),
            'icon' => '🪙',
            'color' => '#f59e0b'
        ];
        $bonusDia = ($spinHours >= 8.0) ? 50 : 20;
        $totalDiaWon += $bonusDia;
        $rewardsList[] = [
            'type' => 'DIAMOND',
            'amount' => $bonusDia,
            'title' => '+' . number_format($bonusDia) . ' เพชร',
            'subtitle' => 'เพชรโบนัสพิเศษ',
            'grade' => 'A+',
            'icon' => '💎',
            'color' => '#00e5ff'
        ];
    } elseif ($rType === 'DIAMOND') {
        $totalDiaWon += $rAmount;
        $rewardsList[] = [
            'type' => 'DIAMOND',
            'amount' => $rAmount,
            'title' => '+' . number_format($rAmount) . ' เพชร',
            'subtitle' => 'เพชรล้ำค่าเข้าคลัง',
            'grade' => ($rAmount >= 500 ? 'SS+' : ($rAmount >= 100 ? 'S' : 'A+')),
            'icon' => '💎',
            'color' => '#00e5ff'
        ];
        $bonusGold = ($spinHours >= 8.0) ? 150000 : 50000;
        $totalGoldWon += $bonusGold;
        $rewardsList[] = [
            'type' => 'GOLD',
            'amount' => $bonusGold,
            'title' => '+' . number_format($bonusGold) . ' ทอง',
            'subtitle' => 'เหรียญทองโบนัส',
            'grade' => 'A+',
            'icon' => '🪙',
            'color' => '#f59e0b'
        ];
    } elseif ($rType === 'FRAME' && !empty($picked['character_id'])) {
        $cId = (int)$picked['character_id'];
        $db->query("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES ({$userId}, 'CHARACTER', {$cId}, 1, 0)");
        $rewardsList[] = [
            'type' => 'FRAME',
            'amount' => 1,
            'title' => $picked['label'] ?? 'กรอบรูปตัวละคร SS+',
            'subtitle' => 'กรอบรูปตัวละครระดับ SS+',
            'grade' => 'SS+',
            'icon' => '👑',
            'color' => '#ec4899'
        ];
        $bonusDia = 200;
        $totalDiaWon += $bonusDia;
        $rewardsList[] = [
            'type' => 'DIAMOND',
            'amount' => $bonusDia,
            'title' => '+' . number_format($bonusDia) . ' เพชร',
            'subtitle' => 'เพชรโบนัสแจ็คพอต',
            'grade' => 'S',
            'icon' => '💎',
            'color' => '#00e5ff'
        ];
    } elseif ($rType === 'DICE' && !empty($picked['dice_id'])) {
        $dId = (int)$picked['dice_id'];
        $db->query("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES ({$userId}, 'DICE', {$dId}, 1, 0)");
        $rewardsList[] = [
            'type' => 'DICE',
            'amount' => 1,
            'title' => $picked['label'] ?? 'ลูกเต๋า 3D ตำนาน',
            'subtitle' => 'ลูกเต๋า 3D ส่งเข้าคลัง',
            'grade' => 'SS+',
            'icon' => '🎲',
            'color' => '#8b5cf6'
        ];
        $bonusGold = 300000;
        $totalGoldWon += $bonusGold;
        $rewardsList[] = [
            'type' => 'GOLD',
            'amount' => $bonusGold,
            'title' => '+' . number_format($bonusGold) . ' ทอง',
            'subtitle' => 'ทองโบนัสแจ็คพอต',
            'grade' => 'S',
            'icon' => '🪙',
            'color' => '#f59e0b'
        ];
    } elseif ($rType === 'CUBE' && !empty($picked['cube_type'])) {
        $nextCubeType = $picked['cube_type'];
        $db->query("INSERT INTO `user_cubes` (user_id, cube_type, status) VALUES ({$userId}, '{$nextCubeType}', 'IDLE')");
        $rewardsList[] = [
            'type' => 'CUBE',
            'amount' => 1,
            'title' => $picked['label'] ?? 'ลูกบาศก์ใบใหม่',
            'subtitle' => 'ส่งเข้าแท่นหมุนลูกบาศก์',
            'grade' => 'S',
            'icon' => '🧊',
            'color' => '#38bdf8'
        ];
        $bonusGold = 100000;
        $totalGoldWon += $bonusGold;
        $rewardsList[] = [
            'type' => 'GOLD',
            'amount' => $bonusGold,
            'title' => '+' . number_format($bonusGold) . ' ทอง',
            'subtitle' => 'ทองโบนัส',
            'grade' => 'A+',
            'icon' => '🪙',
            'color' => '#f59e0b'
        ];
    }

    if ($totalGoldWon > 0) {
        $db->query("UPDATE users SET gold = gold + {$totalGoldWon} WHERE id = {$userId}");
    }
    if ($totalDiaWon > 0) {
        $db->query("UPDATE users SET diamond = diamond + {$totalDiaWon} WHERE id = {$userId}");
    }

    // มาร์กว่าเคลมแล้ว
    $wonJson = json_encode($picked, JSON_UNESCAPED_UNICODE);
    $db->query("UPDATE `user_cubes` SET status = 'CLAIMED', slot_index = NULL, claimed_at = NOW(), reward_won = '{$db->real_escape_string($wonJson)}' WHERE id = {$userCubeId}");

    // ดึงยอดเงินคงเหลือล่าสุดของผู้เล่น
    $uRow = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId}")->fetch_assoc();

    return [
        'status' => 'success',
        'cube_id' => $userCubeId,
        'cube_type' => $cube['cube_type'],
        'cube_name' => $cube['cube_name'],
        'color_hex' => $cube['color_hex'] ?? '#00e5ff',
        'spin_hours' => $spinHours,
        'reward' => $picked,
        'rewards_list' => $rewardsList,
        'reward_gold' => $totalGoldWon,
        'reward_diamond' => $totalDiaWon,
        'user' => [
            'diamond' => (int)($uRow['diamond'] ?? 0),
            'gold' => (int)($uRow['gold'] ?? 0)
        ],
        'message' => "ยินดีด้วย! คุณได้รับรางวัลจาก {$cube['cube_name']}"
    ];
}

/**
 * สุ่มดรอปลูกบาศก์เมื่อเล่นชนะการแข่งขัน (Drop Cube On Match Win)
 */
function dropCubeForMatchWinner(mysqli $db, int $userId): ?array {
    ensureCubeAndEventTables($db);

    // ตรวจสอบจำนวนลูกบาศก์ที่ยังไม่ได้เปิด (จำกัดสูงสุด 7 ช่อง)
    $activeCount = $db->query("SELECT COUNT(*) as c FROM `user_cubes` WHERE user_id = {$userId} AND status != 'CLAIMED'")->fetch_assoc()['c'] ?? 0;
    if ((int)$activeCount >= 7) {
        return null; // ช่องเต็ม
    }

    // สุ่มว่าชนะแล้วดรอปลูกบาศก์หรือไม่ (โอกาส 75% เมื่อชนะการแข่งขัน)
    if (mt_rand(1, 100) > 75) {
        return null;
    }

    // ดึงเรตดรอปของลูกบาศก์แต่ละเกรดจาก cube_configs
    $configs = $db->query("SELECT cube_type, cube_name, color_hex, drop_rate_percent FROM `cube_configs` ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
    if (empty($configs)) return null;

    $totalW = 0;
    foreach ($configs as $c) {
        $totalW += (float)$c['drop_rate_percent'];
    }

    $rnd = mt_rand(1, max(1, (int)($totalW * 100))) / 100;
    $picked = $configs[0];
    foreach ($configs as $c) {
        $rnd -= (float)$c['drop_rate_percent'];
        if ($rnd <= 0) {
            $picked = $c;
            break;
        }
    }

    $cubeType = $picked['cube_type'];
    $stmt = $db->prepare("INSERT INTO `user_cubes` (user_id, cube_type, status) VALUES (?, ?, 'IDLE')");
    $stmt->bind_param("is", $userId, $cubeType);
    $stmt->execute();
    $newId = $stmt->insert_id;
    $stmt->close();

    return [
        'user_cube_id' => $newId,
        'cube_type' => $cubeType,
        'cube_name' => $picked['cube_name'],
        'color_hex' => $picked['color_hex']
    ];
}

