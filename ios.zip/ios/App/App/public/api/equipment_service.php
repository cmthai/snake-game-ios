<?php
/**
 * api/equipment_service.php
 * Comprehensive Equipment & Pendant System Service
 * Features:
 *  - Equipment Items management (Name, Icon, Grade, Skill Category, Skill Name, Description, Trigger %, Shadow Requirements)
 *  - Card Grade slot constraints (Grade S = 1 slot, S+ = 2 slots, SS+ = 3 slots, < S = 0 slots)
 *  - Duplicate / Similar Skill validation (Cannot equip multiple items with identical skill category)
 *  - Pendant Gacha (Draw items directly or get shadow fragments)
 *  - Shadow Fragment Crafting (Collect e.g. 5 shadows to forge the real item)
 *  - In-Game Skill Activation support for 3D Board
 */

declare(strict_types=0);
date_default_timezone_set('Asia/Bangkok');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database.php';

function resolveEquipmentUserId(mysqli $db, int $reqId = 0): int {
    if ($reqId > 0) {
        return $reqId;
    }
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ($_GET['token'] ?? ($_POST['token'] ?? ($_COOKIE['snake_auth_token'] ?? ($_COOKIE['game_session_token'] ?? ''))))));
    $token = '';
    if (is_string($authHeader) && str_starts_with($authHeader, 'Bearer ')) {
        $token = substr($authHeader, 7);
    } elseif (is_string($authHeader)) {
        $token = $authHeader;
    }

    if (!empty($token) && function_exists('verifyAuthToken')) {
        $uid = verifyAuthToken($token);
        if ($uid) return (int)$uid;
    }
    if (!empty($token)) {
        $uStmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? LIMIT 1");
        if ($uStmt) {
            $uStmt->bind_param("s", $token);
            $uStmt->execute();
            $row = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();
            if ($row) return (int)$row['id'];
        }
    }

    return 0;
}

function ensureEquipmentTables(mysqli $db): void {
    @$db->query("
        CREATE TABLE IF NOT EXISTS `equipment_items` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `item_code` VARCHAR(60) NOT NULL UNIQUE,
            `name` VARCHAR(100) NOT NULL,
            `icon_url` VARCHAR(255) NOT NULL DEFAULT 'assets/items/item_shield.png',
            `grade` ENUM('B', 'A', 'A+', 'S', 'S+', 'SS+') NOT NULL DEFAULT 'S',
            `grade` VARCHAR(16) NOT NULL DEFAULT 'S',
            `skill_category` VARCHAR(50) NOT NULL DEFAULT 'BLOCK_CITY',
            `skill_name` VARCHAR(100) NOT NULL DEFAULT '',
            `skill_description` TEXT NOT NULL,
            `trigger_rate_percent` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `shadow_material_code` VARCHAR(60) NOT NULL,
            `shadow_required_count` INT NOT NULL DEFAULT 5,
            `cost_diamond` INT NOT NULL DEFAULT 0,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_grade` (`grade`),
            INDEX `idx_skill` (`skill_category`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_equipment` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `item_id` INT NOT NULL,
            `level` INT NOT NULL DEFAULT 1,
            `is_equipped` TINYINT(1) NOT NULL DEFAULT 0,
            `slot_index` INT NULL DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_user_eq` (`user_id`, `is_equipped`),
            INDEX `idx_item_id` (`item_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    @$db->query("
        CREATE TABLE IF NOT EXISTS `user_materials` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `material_code` VARCHAR(50) NOT NULL,
            `quantity` INT NOT NULL DEFAULT 0,
            `event_id` INT NOT NULL DEFAULT 1,
            `event_type` VARCHAR(20) NOT NULL DEFAULT 'FRAME',
            `start_date` DATETIME NULL DEFAULT NULL,
            `end_date` DATETIME NULL DEFAULT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uniq_user_mat_event` (`user_id`, `material_code`, `event_id`),
            INDEX `idx_user` (`user_id`),
            INDEX `idx_user_event` (`user_id`, `event_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Ensure event columns exist on user_materials
    try {
        @$db->query("ALTER TABLE `user_materials` ADD COLUMN IF NOT EXISTS `event_id` INT NOT NULL DEFAULT 1");
        @$db->query("ALTER TABLE `user_materials` ADD COLUMN IF NOT EXISTS `event_type` VARCHAR(20) NOT NULL DEFAULT 'FRAME'");
        @$db->query("ALTER TABLE `user_materials` ADD COLUMN IF NOT EXISTS `start_date` DATETIME NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `user_materials` ADD COLUMN IF NOT EXISTS `end_date` DATETIME NULL DEFAULT NULL");
    } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `user_materials` ADD COLUMN `event_id` INT NOT NULL DEFAULT 1"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `user_materials` ADD COLUMN `event_type` VARCHAR(20) NOT NULL DEFAULT 'FRAME'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `user_materials` ADD COLUMN `start_date` DATETIME NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `user_materials` ADD COLUMN `end_date` DATETIME NULL DEFAULT NULL"); } catch (\Throwable $e) {}

    // Migrate UNIQUE key on user_materials to include event_id
    try {
        @$db->query("ALTER TABLE `user_materials` DROP INDEX `uniq_user_mat`");
    } catch (\Throwable $e) {}
    try {
        @$db->query("ALTER TABLE `user_materials` ADD UNIQUE KEY `uniq_user_mat_event` (`user_id`, `material_code`, `event_id`)");
    } catch (\Throwable $e) {}

    // Add shape and other required columns if they don't exist (migration)
    try {
        @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `target_item_id` INT NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `start_date` DATETIME NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `end_date` DATETIME NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL");
        @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `featured_shadow_slot` VARCHAR(20) DEFAULT '5'");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `shape` ENUM('triangle','square','pentagon') NOT NULL DEFAULT 'triangle'");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `gem_color` VARCHAR(30) NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `skill_effects_json` TEXT NULL DEFAULT NULL");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `aura_type` VARCHAR(50) NOT NULL DEFAULT 'pulse'");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `particle_fx` VARCHAR(50) NOT NULL DEFAULT 'spark'");
        @$db->query("ALTER TABLE `equipment_items` ADD COLUMN IF NOT EXISTS `aura_intensity` VARCHAR(30) NOT NULL DEFAULT 'high'");
    } catch (\Throwable $e) {}
    // Also try standard ALTER TABLE without IF NOT EXISTS for standard MySQL compatibility
    try { @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN `target_item_id` INT NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN `start_date` DATETIME NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN `end_date` DATETIME NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN `shadow_config_json` LONGTEXT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN `featured_shadow_slot` VARCHAR(20) DEFAULT '5'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `shape` ENUM('triangle','square','pentagon') NOT NULL DEFAULT 'triangle'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `gem_color` VARCHAR(30) NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` MODIFY COLUMN `grade` VARCHAR(16) NOT NULL DEFAULT 'S'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `skill_effects_json` TEXT NULL DEFAULT NULL"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `aura_type` VARCHAR(50) NOT NULL DEFAULT 'pulse'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `particle_fx` VARCHAR(50) NOT NULL DEFAULT 'spark'"); } catch (\Throwable $e) {}
    try { @$db->query("ALTER TABLE `equipment_items` ADD COLUMN `aura_intensity` VARCHAR(30) NOT NULL DEFAULT 'high'"); } catch (\Throwable $e) {}

    // Create gem_gacha_events table
    @$db->query("
        CREATE TABLE IF NOT EXISTS `gem_gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(255) NOT NULL DEFAULT 'กิจกรรมสุ่มอัญมณี',
            `cost_diamond` INT NOT NULL DEFAULT 100,
            `target_item_id` INT NULL DEFAULT NULL,
            `start_date` DATETIME NULL DEFAULT NULL,
            `end_date` DATETIME NULL DEFAULT NULL,
            `shadow_rate_1` FLOAT NOT NULL DEFAULT 40,
            `shadow_rate_2` FLOAT NOT NULL DEFAULT 30,
            `shadow_rate_3` FLOAT NOT NULL DEFAULT 15,
            `shadow_rate_4` FLOAT NOT NULL DEFAULT 10,
            `shadow_rate_5` FLOAT NOT NULL DEFAULT 5,
            `is_active` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Event Isolation Check & Auto Migration:
    // If gem_gacha_events has only 1 row, and that row is for the new event (e.g. "โล่ศักดิ์สิทธิ์พญานาคินทร์" starting 2026-11-16),
    // but user_materials contains shadow cards from previous event (updated before 2026-11-16) attached to event_id = 1:
    // Insert a new event row for the active event (giving it a unique ID e.g. 2), and set row 1 to inactive so previous cards are isolated to event 1.
    try {
        $chkCount = $db->query("SELECT COUNT(*) as c FROM gem_gacha_events");
        $evCount = $chkCount ? (int)$chkCount->fetch_assoc()['c'] : 0;
        if ($evCount === 1) {
            $e1Res = $db->query("SELECT * FROM gem_gacha_events WHERE id = 1 LIMIT 1");
            $e1 = $e1Res ? $e1Res->fetch_assoc() : null;
            if ($e1 && !empty($e1['start_date']) && strtotime($e1['start_date']) >= strtotime('2026-11-16 00:00:00')) {
                $evName = $e1['event_name'];
                $cDia = (int)$e1['cost_diamond'];
                $tId = (int)$e1['target_item_id'];
                $tDrop = (float)($e1['target_drop_rate'] ?? 1.0);
                $pMult = (float)($e1['premium_rate_multiplier'] ?? 1.5);
                $gMult = (float)($e1['gold_rate_multiplier'] ?? 0.5);
                $sDate = $e1['start_date'];
                $eDate = $e1['end_date'];
                $r1 = (float)$e1['shadow_rate_1'];
                $r2 = (float)$e1['shadow_rate_2'];
                $r3 = (float)$e1['shadow_rate_3'];
                $r4 = (float)$e1['shadow_rate_4'];
                $r5 = (float)$e1['shadow_rate_5'];
                $sJson = $e1['shadow_config_json'];
                $fSlot = $e1['featured_shadow_slot'] ?? '5';
                $cDelay = (float)($e1['card_reveal_delay'] ?? 0.1);

                $insStmt = $db->prepare("
                    INSERT INTO gem_gacha_events (event_name, cost_diamond, target_item_id, target_drop_rate, premium_rate_multiplier, gold_rate_multiplier, start_date, end_date, is_active, shadow_rate_1, shadow_rate_2, shadow_rate_3, shadow_rate_4, shadow_rate_5, shadow_config_json, featured_shadow_slot, card_reveal_delay)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                if ($insStmt) {
                    $insStmt->bind_param("siidddssdddddssd", $evName, $cDia, $tId, $tDrop, $pMult, $gMult, $sDate, $eDate, $r1, $r2, $r3, $r4, $r5, $sJson, $fSlot, $cDelay);
                    if ($insStmt->execute()) {
                        // Successfully created row 2 for the active event! Now archive row 1 as the previous round
                        $db->query("UPDATE gem_gacha_events SET is_active = 0, event_name = 'กิจกรรมสุ่มอัญมณี (รอบก่อนหน้า)', start_date = '2026-11-11 14:00:00', end_date = '2026-11-15 07:50:00' WHERE id = 1");
                    }
                    $insStmt->close();
                }
            }
        }
    } catch (\Throwable $e) {}

    // Strict Event Isolation:
    // Move legacy shadow gem cards (Event 1, ended on 2026-11-15) back to event_id = 1 (expired).
    // This ensures active Event 2 starts fresh at 0 cards (0/15, 0/15, 0/15, 0/10, 0/4)
    // and older cards appear in inventory under "การ์ดที่หมดอายุแล้ว" to be sold for diamonds/gold.
    try {
        @$db->query("UPDATE user_materials SET event_id = 1, end_date = '2026-11-15 07:50:00' WHERE material_code LIKE 'SHADOW_GEM_%' AND event_id = 2");
    } catch (\Throwable $e) {}

    // Seed default starter items if empty
    $countRes = $db->query("SELECT COUNT(*) as c FROM equipment_items");
    $cnt = $countRes ? (int)$countRes->fetch_assoc()['c'] : 0;
    if ($cnt === 0) {
        $seeds = [
            [
                'item_code' => 'pendant_block_city_01',
                'name' => 'ตราสัญลักษณ์มหาปราการ',
                'icon_url' => 'assets/items/item_shield.png',
                'grade' => 'SS+',
                'skill_category' => 'BLOCK_CITY',
                'skill_name' => 'ยกเมืองกั้นทางเดิน 90%',
                'skill_description' => 'เมื่อเริ่มตาเดิน มีโอกาส 90% ยกเมืองใดก็ได้เพื่อกั้นไม่ให้คู่แข่งเดินผ่าน',
                'trigger_rate_percent' => 90.00,
                'shadow_material_code' => 'shadow_pendant_block_01',
                'shadow_required_count' => 5,
                'cost_diamond' => 1200
            ],
            [
                'item_code' => 'pendant_shield_snake_01',
                'name' => 'โล่ศักดิ์สิทธิ์พญานาคินทร์',
                'icon_url' => 'assets/items/item_dragon_shield.png',
                'grade' => 'S+',
                'skill_category' => 'SHIELD_SNAKE',
                'skill_name' => 'เกราะคุ้มกันหัวงู 80%',
                'skill_description' => 'เมื่อตกหัวงู มีโอกาส 80% ป้องกันการสไลด์ตกลงหางงู',
                'trigger_rate_percent' => 80.00,
                'shadow_material_code' => 'shadow_shield_snake_01',
                'shadow_required_count' => 5,
                'cost_diamond' => 800
            ],
            [
                'item_code' => 'pendant_double_dice_01',
                'name' => 'ลูกเต๋าพันหน้ามหาโชค',
                'icon_url' => 'assets/items/item_dice.png',
                'grade' => 'S+',
                'skill_category' => 'DICE_DOUBLE',
                'skill_name' => 'ทอยเบิ้ลรับเทิร์น 75%',
                'skill_description' => 'เมื่อเริ่มทอยเต๋า มีโอกาส 75% ออกแต้มเบิ้ลเพื่อรับเทิร์นพิเศษเดินต่อทันที',
                'trigger_rate_percent' => 75.00,
                'shadow_material_code' => 'shadow_double_dice_01',
                'shadow_required_count' => 5,
                'cost_diamond' => 800
            ],
            [
                'item_code' => 'pendant_toll_pass_01',
                'name' => 'ตราพญาหงส์ทองยกเว้นผ่านทาง',
                'icon_url' => 'assets/items/item_feather.png',
                'grade' => 'S',
                'skill_category' => 'TOLL_DISCOUNT',
                'skill_name' => 'ส่วนลดค่าผ่านทาง 100%',
                'skill_description' => 'เมื่อตกเมืองคู่แข่ง มีโอกาส 85% ยกเว้นค่าผ่านทางทั้งหมดทันที',
                'trigger_rate_percent' => 85.00,
                'shadow_material_code' => 'shadow_toll_pass_01',
                'shadow_required_count' => 5,
                'cost_diamond' => 500
            ],
            [
                'item_code' => 'pendant_steal_gold_01',
                'name' => 'ถุงมือแม่เหล็กดูดทองคำ',
                'icon_url' => 'assets/items/item_ring.png',
                'grade' => 'S',
                'skill_category' => 'STEAL_GOLD',
                'skill_name' => 'ขโมยทองคู่แข่ง 30%',
                'skill_description' => 'เมื่อตกช่องเดียวกับคู่แข่ง มีโอกาส 85% ดูดทองคู่แข่ง 30% ทันที',
                'trigger_rate_percent' => 85.00,
                'shadow_material_code' => 'shadow_steal_gold_01',
                'shadow_required_count' => 5,
                'cost_diamond' => 500
            ]
        ];

        foreach ($seeds as $s) {
            $stmt = $db->prepare("
                INSERT IGNORE INTO equipment_items 
                (item_code, name, icon_url, grade, skill_category, skill_name, skill_description, trigger_rate_percent, shadow_material_code, shadow_required_count, cost_diamond, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            ");
            if ($stmt) {
                $stmt->bind_param(
                    "sssssssdsii",
                    $s['item_code'],
                    $s['name'],
                    $s['icon_url'],
                    $s['grade'],
                    $s['skill_category'],
                    $s['skill_name'],
                    $s['skill_description'],
                    $s['trigger_rate_percent'],
                    $s['shadow_material_code'],
                    $s['shadow_required_count'],
                    $s['cost_diamond']
                );
                $stmt->execute();
                $stmt->close();
            }
        }
    }
}

function getSlotLimitForCardGrade(string $grade): int {
    $grade = strtoupper(trim($grade));
    // Default rules: S = 1, S+ = 2, SS+ = 3, Below S = 0
    if ($grade === 'SS+' || $grade === 'SS') return 3;
    if ($grade === 'S+') return 2;
    if ($grade === 'S') return 1;
    return 0; // Cards below S (C, B, A, A+) cannot equip items!
}

$db = getDbConnection();
ensureEquipmentTables($db);

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$inputJSON = file_get_contents('php://input');
$inputData = json_decode($inputJSON, true) ?? [];
$action = !empty($inputData['action']) ? $inputData['action'] : $action;

// 1. GET ALL ITEMS (Public & In-Game)
if ($action === 'get_items') {
    $res = $db->query("SELECT * FROM equipment_items WHERE is_active = 1 ORDER BY FIELD(grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), id ASC");
    $items = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    echo json_encode(['status' => 'success', 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. GET ADMIN ITEMS & SETTINGS
if ($action === 'get_admin_items') {
    $res = $db->query("SELECT * FROM equipment_items ORDER BY id DESC");
    $items = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    echo json_encode(['status' => 'success', 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

function autoDetectSkillEffects(string $category, string $desc, string $name = ''): array {
    $text = mb_strtolower($name . ' ' . $desc . ' ' . $category, 'UTF-8');
    $effects = [
        'shield_on_roll' => false,
        'shield_min' => 1,
        'shield_max' => 3,
        'immune_kick' => false,
        'immune_steal' => false,
        'immune_snake' => false,
        'steal_gold' => false,
        'toll_discount' => false,
        'pass_kick' => false,
        'dice_double' => false,
        'pull_opponents_4' => false,
        'pull_opponents_6' => false,
        'pull_opponents_line' => false,
        'black_hole_generator' => false,
        'instant_landmark_3city' => false,
        'toll_multiplier_random' => false
    ];

    // Shield on roll
    if (str_contains($text, 'สร้างโล่') || str_contains($text, 'โล่') || str_contains($text, 'เกราะ') || str_contains($text, 'shield')) {
        $effects['shield_on_roll'] = true;
        if (preg_match('/(\d+)\s*[-–ถึง]\s*(\d+)\s*ชั้น/', $text, $m)) {
            $effects['shield_min'] = (int)$m[1];
            $effects['shield_max'] = (int)$m[2];
        } elseif (preg_match('/(\d+)\s*ชั้น/', $text, $m)) {
            $effects['shield_min'] = 1;
            $effects['shield_max'] = (int)$m[1];
        }
    }

    // Immune kick
    if (str_contains($text, 'ป้องกันการเตะ') || str_contains($text, 'กันเตะ') || str_contains($text, 'ไม่โดนดึง') || str_contains($text, 'กันการเตะ') || str_contains($text, 'ต้านการเตะ') || str_contains($text, 'immune_kick')) {
        $effects['immune_kick'] = true;
    }

    // Immune steal
    if (str_contains($text, 'ป้องกันการดูดเงิน') || str_contains($text, 'กันดูดเงิน') || str_contains($text, 'กันขโมยเงิน') || str_contains($text, 'ป้องกันการขโมย') || str_contains($text, 'immune_steal')) {
        $effects['immune_steal'] = true;
    }

    // Immune snake
    if (str_contains($text, 'ป้องกันงู') || str_contains($text, 'คุ้มกันหัวงู') || str_contains($text, 'กันงู') || $category === 'SHIELD_SNAKE') {
        $effects['immune_snake'] = true;
    }

    // Pass kick
    if ($category === 'PASS_OPPONENT_KICK' || str_contains($text, 'เตะคู่แข่ง') || str_contains($text, 'ผลักคู่แข่ง') || str_contains($text, 'ก้าวผ่าน') || str_contains($text, 'เตะส่ง') || str_contains($text, 'สะบัดหาง') || str_contains($text, 'ดีดตัว') || str_contains($text, 'ผลักไส')) {
        $effects['pass_kick'] = true;
    }

    // Steal gold
    if ($category === 'STEAL_GOLD' || str_contains($text, 'ขโมยทอง') || str_contains($text, 'ดูดเงิน') || str_contains($text, 'ปล้นทอง')) {
        $effects['steal_gold'] = true;
    }

    // Toll discount
    if ($category === 'TOLL_DISCOUNT' || str_contains($text, 'ส่วนลดค่าผ่านทาง') || str_contains($text, 'ลดค่าผ่านทาง')) {
        $effects['toll_discount'] = true;
    }

    // Dice double
    if ($category === 'DICE_DOUBLE' || str_contains($text, 'ทอยเบิ้ล') || str_contains($text, 'ดับเบิ้ล')) {
        $effects['dice_double'] = true;
    }

    // Pull 4 tiles front/back
    if (str_contains($text, '4 ช่อง') || str_contains($text, '4ช่อง') || str_contains($text, 'ดึง 4')) {
        $effects['pull_opponents_4'] = true;
    }

    // Pull 6 tiles front/back
    if (str_contains($text, '6 ช่อง') || str_contains($text, '6ช่อง') || str_contains($text, 'ดึง 6')) {
        $effects['pull_opponents_6'] = true;
    }

    // Pull in row/line
    if (str_contains($text, 'ในแถว') || str_contains($text, 'ทั้งแถว') || str_contains($text, 'ดึงคู่แข่งในแถว')) {
        $effects['pull_opponents_line'] = true;
    }

    // Black Hole
    if (str_contains($text, 'หลุมดำ') || str_contains($text, 'black hole') || str_contains($text, 'blackhole')) {
        $effects['black_hole_generator'] = true;
    }

    // Instant landmark on 3 cities
    if (str_contains($text, '3 เมือง') || str_contains($text, '3เมือง') || str_contains($text, 'กระโดด') || str_contains($text, 'เสกแลนด์มาร์ค')) {
        $effects['instant_landmark_3city'] = true;
    }

    // Toll multiplier X2, X4, X6, X8, X12
    if (str_contains($text, '12') || str_contains($text, 'x12') || str_contains($text, 'คูณ 12') || str_contains($text, 'คูณ12') || str_contains($text, 'ตัวคูณ') || str_contains($text, 'คูณ 2') || str_contains($text, 'คูณ2') || str_contains($text, 'คูณ 8')) {
        $effects['toll_multiplier_random'] = true;
    }

    return $effects;
}

function getGemShapeThaiLabel(string $shape): string {
    $s = strtolower(trim($shape));
    if ($s === 'triangle') return 'สามเหลี่ยม (🔺)';
    if ($s === 'square') return 'สี่เหลี่ยม (🔷)';
    if ($s === 'pentagon') return 'ห้าเหลี่ยม (⬠)';
    return $shape ?: 'อัญมณี';
}

function getGemSkillSignatures(array $gem): array {
    $sigs = [];
    $skillName = trim((string)($gem['skill_name'] ?? ''));
    $skillDesc = trim((string)($gem['skill_description'] ?? ''));
    $skillCat  = strtoupper(trim((string)($gem['skill_category'] ?? '')));

    if ($skillName !== '') {
        // Normalize skill name by removing numbers, %, spaces, and punctuation
        $normName = mb_strtolower(preg_replace('/[0-9%\.\s\(\)\-\+\:\!\[\]\/]+/u', '', $skillName), 'UTF-8');
        if ($normName !== '') {
            $sigs[] = 'name:' . $normName;
        }
    }

    // Parse explicit skill_effects_json if present
    $fx = [];
    if (!empty($gem['skill_effects_json'])) {
        $decoded = is_array($gem['skill_effects_json'])
            ? $gem['skill_effects_json']
            : json_decode((string)$gem['skill_effects_json'], true);
        if (is_array($decoded)) {
            $fx = $decoded;
        }
    }
    $detected = autoDetectSkillEffects($skillCat, $skillDesc, $skillName);
    foreach ($detected as $k => $v) {
        if (is_bool($v) && $v) {
            $fx[$k] = true;
        }
    }

    $boolKeys = [
        'shield_on_roll', 'immune_kick', 'immune_steal', 'immune_snake',
        'steal_gold', 'toll_discount', 'pass_kick', 'dice_double',
        'pull_opponents_4', 'pull_opponents_6', 'pull_opponents_line',
        'black_hole_generator', 'instant_landmark_3city', 'toll_multiplier_random'
    ];
    $hasDetectedEffect = false;
    foreach ($boolKeys as $bk) {
        if (!empty($fx[$bk])) {
            if (in_array($bk, ['pull_opponents_4', 'pull_opponents_6', 'pull_opponents_line'], true)) {
                $sigs[] = 'fx:pull_opponents';
            } else {
                $sigs[] = 'fx:' . $bk;
            }
            $hasDetectedEffect = true;
        }
    }

    $fullText = mb_strtolower($skillName . ' ' . $skillDesc, 'UTF-8');
    if (str_contains($fullText, 'ยกเมือง') || str_contains($fullText, 'กั้นทาง') || str_contains($fullText, 'ปราการ') || str_contains($fullText, 'กำแพงเมือง')) {
        $sigs[] = 'fx:block_city';
        $hasDetectedEffect = true;
    }
    if (str_contains($fullText, 'จ่ายค่าผ่านทาง 2 เท่า') || str_contains($fullText, 'ค่าผ่านทางทวีคูณ') || str_contains($fullText, 'เก็บค่าผ่านทางสองเท่า')) {
        $sigs[] = 'fx:force_pay_toll';
        $hasDetectedEffect = true;
    }

    if ($skillCat !== '' && $skillCat !== 'CUSTOM') {
        if (!$hasDetectedEffect || in_array($skillCat, ['BLOCK_CITY', 'SHIELD_SNAKE', 'DICE_DOUBLE', 'TOLL_DISCOUNT', 'STEAL_GOLD', 'FORCE_PAY_TOLL'], true)) {
            $sigs[] = 'cat:' . $skillCat;
        } elseif ($skillCat === 'PASS_OPPONENT_KICK' && !in_array('fx:pull_opponents', $sigs, true)) {
            $sigs[] = 'cat:PASS_OPPONENT_KICK';
        }
    }

    return array_values(array_unique($sigs));
}

function areGemSkillsDuplicate(array $gemA, array $gemB): bool {
    if (!empty($gemA['item_id']) && !empty($gemB['item_id']) && (int)$gemA['item_id'] === (int)$gemB['item_id']) {
        return true;
    }
    $sigsA = getGemSkillSignatures($gemA);
    $sigsB = getGemSkillSignatures($gemB);
    foreach ($sigsA as $sa) {
        if (in_array($sa, $sigsB, true)) {
            return true;
        }
    }
    return false;
}

function sanitizeUserEquippedGems(mysqli $db, int $userId, int $slotLimit = 3): void {
    if ($userId <= 0) return;
    $res = $db->query("
        SELECT ue.id as user_eq_id, ue.slot_index, ei.id as item_id, ei.name, ei.shape,
               ei.skill_category, ei.skill_name, ei.skill_description, ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = {$userId} AND ue.is_equipped = 1 AND ei.shape IS NOT NULL
        ORDER BY COALESCE(ue.slot_index, 99) ASC, ue.id ASC
    ");
    if (!$res) return;

    $kept = [];
    $usedShapes = [];
    $usedSlots = [];
    $toUnequipIds = [];

    while ($row = $res->fetch_assoc()) {
        $eqId = (int)$row['user_eq_id'];
        $shape = strtolower(trim((string)($row['shape'] ?? '')));
        $slot = (int)($row['slot_index'] ?? 0);

        if ($slotLimit <= 0 || count($kept) >= $slotLimit) {
            $toUnequipIds[] = $eqId;
            continue;
        }
        // Check duplicate shape
        if ($shape !== '' && in_array($shape, $usedShapes, true)) {
            $toUnequipIds[] = $eqId;
            continue;
        }
        // Check duplicate skill
        $hasDupSkill = false;
        foreach ($kept as $kGem) {
            if (areGemSkillsDuplicate($row, $kGem)) {
                $hasDupSkill = true;
                break;
            }
        }
        if ($hasDupSkill) {
            $toUnequipIds[] = $eqId;
            continue;
        }

        if ($slot < 1 || $slot > $slotLimit || in_array($slot, $usedSlots, true)) {
            for ($s = 1; $s <= $slotLimit; $s++) {
                if (!in_array($s, $usedSlots, true)) {
                    $slot = $s;
                    $db->query("UPDATE user_equipment SET slot_index = {$slot} WHERE id = {$eqId} AND user_id = {$userId}");
                    break;
                }
            }
        }
        $usedShapes[] = $shape;
        $usedSlots[] = $slot;
        $kept[] = $row;
    }

    if (!empty($toUnequipIds)) {
        $idsStr = implode(',', array_map('intval', $toUnequipIds));
        $db->query("UPDATE user_equipment SET is_equipped = 0, slot_index = NULL WHERE user_id = {$userId} AND id IN ({$idsStr})");
    }
}

// 3. ADMIN: SAVE OR UPDATE ITEM
if ($action === 'save_item') {
    try {
        $id = (int)($inputData['id'] ?? 0);
        $itemCode = trim((string)($inputData['item_code'] ?? ''));
        $name = trim((string)($inputData['name'] ?? ''));
        $iconUrl = trim((string)($inputData['icon_url'] ?? 'assets/items/item_shield.png'));
        $grade = strtoupper(trim((string)($inputData['grade'] ?? 'S')));
        $skillCategory = strtoupper(trim((string)($inputData['skill_category'] ?? 'BLOCK_CITY')));
        $skillName = trim((string)($inputData['skill_name'] ?? ''));
        $skillDesc = trim((string)($inputData['skill_description'] ?? ''));
        $triggerRate = (float)($inputData['trigger_rate_percent'] ?? 90.00);
        $shadowCode = trim((string)($inputData['shadow_material_code'] ?? ''));
        $shadowReq = (int)($inputData['shadow_required_count'] ?? 5);
        $costDiamond = (int)($inputData['cost_diamond'] ?? 0);
        $isActive = isset($inputData['is_active']) ? ((int)$inputData['is_active'] ? 1 : 0) : 1;
        $shape = trim((string)($inputData['shape'] ?? 'triangle'));
        if (!in_array($shape, ['triangle', 'square', 'pentagon', 'hexagon', 'star', 'diamond'])) {
            $shape = 'triangle';
        }
        $gemColor = !empty($inputData['gem_color']) ? trim((string)$inputData['gem_color']) : null;
        $auraType = trim((string)($inputData['aura_type'] ?? 'pulse'));
        if (empty($auraType)) $auraType = 'pulse';
        $particleFx = trim((string)($inputData['particle_fx'] ?? 'spark'));
        if (empty($particleFx)) $particleFx = 'spark';
        $auraIntensity = trim((string)($inputData['aura_intensity'] ?? 'high'));
        if (empty($auraIntensity)) $auraIntensity = 'high';
        $skillEffectsJson = null;
        if (!empty($inputData['skill_effects_json'])) {
            $skillEffectsJson = is_array($inputData['skill_effects_json']) 
                ? json_encode($inputData['skill_effects_json'], JSON_UNESCAPED_UNICODE) 
                : trim((string)$inputData['skill_effects_json']);
        }
        if (empty($skillEffectsJson)) {
            $detected = autoDetectSkillEffects($skillCategory, $skillDesc, $skillName);
            $skillEffectsJson = json_encode($detected, JSON_UNESCAPED_UNICODE);
        }

        if (empty($name)) {
            echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุชื่อไอเทมอัญมณี'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (empty($itemCode)) {
            $itemCode = 'gem_' . strtolower($skillCategory) . '_' . time();
        }
        if (empty($shadowCode)) {
            $shadowCode = 'shadow_' . $itemCode;
        }
        if ($shadowReq <= 0) $shadowReq = 5;
        if ($triggerRate <= 0 || $triggerRate > 100) $triggerRate = 90.00;

        if ($id > 0) {
            // Check if item_code already used by another item
            $chkStmt = $db->prepare("SELECT id FROM equipment_items WHERE item_code = ? AND id != ? LIMIT 1");
            $chkStmt->bind_param("si", $itemCode, $id);
            $chkStmt->execute();
            $chkRes = $chkStmt->get_result();
            if ($chkRes && $chkRes->num_rows > 0) {
                $chkStmt->close();
                echo json_encode(['status' => 'error', 'message' => "รหัสไอเทม '{$itemCode}' ซ้ำกับอัญมณีอื่นในระบบ กรุณาเปลี่ยนรหัสใหม่"], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $chkStmt->close();

            $stmt = $db->prepare("
                UPDATE equipment_items SET 
                    item_code = ?, name = ?, icon_url = ?, grade = ?, skill_category = ?, skill_name = ?, 
                    skill_description = ?, trigger_rate_percent = ?, shadow_material_code = ?, 
                    shadow_required_count = ?, cost_diamond = ?, is_active = ?, shape = ?, gem_color = ?,
                    skill_effects_json = ?, aura_type = ?, particle_fx = ?, aura_intensity = ?
                WHERE id = ?
            ");
            if (!$stmt) {
                echo json_encode(['status' => 'error', 'message' => 'DB Prepare Error: ' . $db->error], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $stmt->bind_param(
                "sssssssdsiiissssssi",
                $itemCode, $name, $iconUrl, $grade, $skillCategory, $skillName,
                $skillDesc, $triggerRate, $shadowCode, $shadowReq, $costDiamond, $isActive, $shape, $gemColor, $skillEffectsJson,
                $auraType, $particleFx, $auraIntensity, $id
            );
            if (!$stmt->execute()) {
                $errMsg = $stmt->error;
                $stmt->close();
                echo json_encode(['status' => 'error', 'message' => 'DB Execute Error: ' . $errMsg], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $stmt->close();
            echo json_encode(['status' => 'success', 'message' => "อัปเดตอัญมณี '{$name}' สำเร็จแล้ว"], JSON_UNESCAPED_UNICODE);
        } else {
            // Check duplicate code on insert
            $chkStmt = $db->prepare("SELECT id FROM equipment_items WHERE item_code = ? LIMIT 1");
            $chkStmt->bind_param("s", $itemCode);
            $chkStmt->execute();
            $chkRes = $chkStmt->get_result();
            if ($chkRes && $chkRes->num_rows > 0) {
                $chkStmt->close();
                // Auto generate unique item_code to prevent failure
                $itemCode = $itemCode . '_' . substr((string)time(), -4);
            } else {
                $chkStmt->close();
            }

            $stmt = $db->prepare("
                INSERT INTO equipment_items 
                (item_code, name, icon_url, grade, skill_category, skill_name, skill_description, trigger_rate_percent, shadow_material_code, shadow_required_count, cost_diamond, is_active, shape, gem_color, skill_effects_json, aura_type, particle_fx, aura_intensity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            if (!$stmt) {
                echo json_encode(['status' => 'error', 'message' => 'DB Prepare Error: ' . $db->error], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $stmt->bind_param(
                "sssssssdsiiissssss",
                $itemCode, $name, $iconUrl, $grade, $skillCategory, $skillName,
                $skillDesc, $triggerRate, $shadowCode, $shadowReq, $costDiamond, $isActive, $shape, $gemColor, $skillEffectsJson,
                $auraType, $particleFx, $auraIntensity
            );
            if (!$stmt->execute()) {
                $errMsg = $stmt->error;
                $stmt->close();
                echo json_encode(['status' => 'error', 'message' => 'DB Execute Error: ' . $errMsg], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $newId = $stmt->insert_id;
            $stmt->close();
            echo json_encode(['status' => 'success', 'message' => "สร้างอัญมณี '{$name}' สำเร็จแล้ว", 'id' => $newId], JSON_UNESCAPED_UNICODE);
        }
    } catch (\Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// 4. ADMIN: DELETE ITEM
if ($action === 'delete_item') {
    $id = (int)($inputData['id'] ?? ($_POST['id'] ?? 0));
    if ($id > 0) {
        $db->query("DELETE FROM user_equipment WHERE item_id = {$id}");
        $db->query("DELETE FROM equipment_items WHERE id = {$id}");
        echo json_encode(['status' => 'success', 'message' => 'ลบไอเทมเรียบร้อยแล้ว'], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไอเทมที่ต้องการลบ'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// 5. GET USER'S EQUIPMENT, EQUIPPED SLOTS & SHADOW FRAGMENTS
if ($action === 'get_user_equipment') {
    $reqId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : (isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0);
    $userId = resolveEquipmentUserId($db, $reqId);
    if ($userId <= 0) {
        echo json_encode([
            'status' => 'success',
            'character_grade' => 'SS+',
            'slot_limit' => 3,
            'equipment' => [],
            'owned_items' => [],
            'equipped_slots' => [],
            'bag_items' => [],
            'shadow_materials' => []
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Get equipped character card grade
    $uRes = $db->query("SELECT id, username, diamond, gold, level, character_grade, equipped_character_id FROM users WHERE id = {$userId} LIMIT 1");
    $user = $uRes ? $uRes->fetch_assoc() : null;
    $charGrade = $user['character_grade'] ?? 'SS+';
    $slotLimit = getSlotLimitForCardGrade($charGrade);

    // Enforce 1 gem per shape and no duplicate skills
    sanitizeUserEquippedGems($db, $userId, $slotLimit);

    // Get user owned items
    $eqRes = $db->query("
        SELECT ue.id as user_eq_id, ue.level, ue.is_equipped, ue.slot_index, ue.created_at,
               ei.id as item_id, ei.item_code, ei.name, ei.icon_url, ei.grade, ei.skill_category,
               ei.skill_name, ei.skill_description, ei.trigger_rate_percent, ei.shadow_material_code, ei.shadow_required_count,
               ei.shape, ei.gem_color, ei.aura_type, ei.particle_fx, ei.aura_intensity, ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = {$userId}
        ORDER BY ue.is_equipped DESC, FIELD(ei.grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), ue.id DESC
    ");
    $ownedItems = $eqRes ? $eqRes->fetch_all(MYSQLI_ASSOC) : [];

    // Separate into equipped items and bag
    $equippedSlots = [];
    $bagItems = [];
    $equippedSkillCategories = [];

    foreach ($ownedItems as $it) {
        if (!empty($it['is_equipped'])) {
            $slot = (int)($it['slot_index'] ?: (count($equippedSlots) + 1));
            $equippedSlots[$slot] = $it;
            $equippedSkillCategories[] = $it['skill_category'];
        } else {
            $bagItems[] = $it;
        }
    }

    // Get shadow materials count
    $matRes = $db->query("SELECT material_code, quantity FROM user_materials WHERE user_id = {$userId}");
    $matMap = [];
    if ($matRes) {
        while ($m = $matRes->fetch_assoc()) {
            $matMap[$m['material_code']] = (int)$m['quantity'];
        }
    }

    // List all craftable items with current shadow progress
    $allItemsRes = $db->query("SELECT * FROM equipment_items WHERE is_active = 1 ORDER BY FIELD(grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), id ASC");
    $craftableList = [];
    if ($allItemsRes) {
        while ($item = $allItemsRes->fetch_assoc()) {
            $sCode = $item['shadow_material_code'];
            $req = (int)$item['shadow_required_count'];
            $ownedShadows = $matMap[$sCode] ?? 0;
            $item['owned_shadow_count'] = $ownedShadows;
            $item['is_ready_to_craft'] = ($ownedShadows >= $req);
            $craftableList[] = $item;
        }
    }

    echo json_encode([
        'status' => 'success',
        'character_grade' => $charGrade,
        'slot_limit' => $slotLimit,
        'can_equip' => ($slotLimit > 0),
        'equipped_slots' => $equippedSlots,
        'equipped_skill_categories' => array_values(array_unique($equippedSkillCategories)),
        'equipment' => $ownedItems,
        'owned_items' => $ownedItems,
        'bag_items' => $bagItems,
        'craftable_items' => $craftableList,
        'shadow_materials' => $matMap
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 6. EQUIP ITEM (WITH GRADE RESTRICTIONS & DUPLICATE SKILL CHECK)
if ($action === 'equip_item') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $userEqId = (int)($inputData['user_eq_id'] ?? 0);
    $targetSlot = (int)($inputData['slot_index'] ?? 1);

    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนสวมใส่ไอเทม'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($userEqId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไอเทมที่เลือกสวมใส่'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 1) Verify user's equipped character card grade
    $uRes = $db->query("SELECT character_grade FROM users WHERE id = {$userId} LIMIT 1");
    $uRow = $uRes ? $uRes->fetch_assoc() : null;
    $charGrade = strtoupper(trim((string)($uRow['character_grade'] ?? 'SS+')));
    $slotLimit = getSlotLimitForCardGrade($charGrade);

    if ($slotLimit <= 0) {
        echo json_encode([
            'status' => 'error',
            'message' => "❌ ไม่สามารถสวมใส่ไอเทมได้: การ์ดตัวละครของคุณ (เกรด {$charGrade}) ไม่รองรับการสวมใส่ไอเทม ต้องใช้การ์ดเกรด S ขึ้นไปเท่านั้น!"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($targetSlot < 1 || $targetSlot > $slotLimit) {
        echo json_encode([
            'status' => 'error',
            'message' => "❌ การ์ดเกรด {$charGrade} สวมใส่ได้สูงสุด {$slotLimit} ไอเทมเท่านั้น (ไม่สามารถใส่ในช่อง {$targetSlot} ได้)"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 2) Get item to equip
    $itemRes = $db->query("
        SELECT ue.id as user_eq_id, ue.is_equipped, ei.name, ei.skill_category, ei.skill_name, ei.trigger_rate_percent
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.id = {$userEqId} AND ue.user_id = {$userId}
        LIMIT 1
    ");
    $targetItem = $itemRes ? $itemRes->fetch_assoc() : null;
    if (!$targetItem) {
        echo json_encode(['status' => 'error', 'message' => 'คุณไม่ได้เป็นเจ้าของไอเทมนี้'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $targetCategory = $targetItem['skill_category'];

    // 3) Check duplicate/similar skill category constraint!
    $dupSkillRes = $db->query("
        SELECT ue.id, ei.name, ei.skill_name, ei.skill_category
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = {$userId} AND ue.is_equipped = 1 AND ue.id != {$userEqId} AND ei.skill_category = '{$targetCategory}'
        LIMIT 1
    ");
    $dupSkill = $dupSkillRes ? $dupSkillRes->fetch_assoc() : null;
    if ($dupSkill) {
        echo json_encode([
            'status' => 'error',
            'message' => "❌ ไม่สามารถสวมใส่ได้: คุณได้สวมใส่ไอเทม '{$dupSkill['name']}' ซึ่งมีสกิลประเภท '{$dupSkill['skill_name']}' อยู่แล้ว (กฎของเกม: ห้ามสวมใส่ไอเทมที่มีสกิลเหมือนหรือคล้ายกัน)"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 4) Unequip any item currently in targetSlot
    $db->query("UPDATE user_equipment SET is_equipped = 0, slot_index = NULL WHERE user_id = {$userId} AND slot_index = {$targetSlot}");

    // 5) Equip the new item
    $db->query("UPDATE user_equipment SET is_equipped = 1, slot_index = {$targetSlot} WHERE id = {$userEqId} AND user_id = {$userId}");

    echo json_encode([
        'status' => 'success',
        'message' => "✨ สวมใส่ '{$targetItem['name']}' ในช่องที่ {$targetSlot} เรียบร้อยแล้ว! (สกิล: {$targetItem['skill_name']})",
        'slot_index' => $targetSlot,
        'item' => $targetItem
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 7. UNEQUIP ITEM
if ($action === 'unequip_item') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $userEqId = (int)($inputData['user_eq_id'] ?? 0);
    $slotIndex = (int)($inputData['slot_index'] ?? 0);

    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนถอดไอเทม'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($userEqId > 0) {
        $db->query("UPDATE user_equipment SET is_equipped = 0, slot_index = NULL WHERE id = {$userEqId} AND user_id = {$userId}");
    } elseif ($slotIndex > 0) {
        $db->query("UPDATE user_equipment SET is_equipped = 0, slot_index = NULL WHERE user_id = {$userId} AND slot_index = {$slotIndex}");
    }

    echo json_encode(['status' => 'success', 'message' => 'ถอดไอเทมเครื่องรางเรียบร้อยแล้ว'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 8. CRAFT SHADOW ITEM (COMBINE SHADOWS TO GET REAL ITEM)
if ($action === 'craft_shadow_item') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $itemId = (int)($inputData['item_id'] ?? 0);

    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนผสมไอเทม'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($itemId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไอเทมที่ต้องการผสม'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $itemRes = $db->query("SELECT * FROM equipment_items WHERE id = {$itemId} AND is_active = 1 LIMIT 1");
    $item = $itemRes ? $itemRes->fetch_assoc() : null;
    if (!$item) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไอเทมนี้ในระบบ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $shadowCode = $item['shadow_material_code'];
    $reqCount = (int)$item['shadow_required_count'];

    // Check user owned shadows
    $mRes = $db->query("SELECT quantity FROM user_materials WHERE user_id = {$userId} AND material_code = '{$shadowCode}' LIMIT 1");
    $curQty = $mRes ? (int)($mRes->fetch_assoc()['quantity'] ?? 0) : 0;

    if ($curQty < $reqCount) {
        echo json_encode([
            'status' => 'error',
            'message' => "❌ การ์ดเงาไม่เพียงพอ! คุณมี {$curQty}/{$reqCount} ชิ้น ขาดอีก " . ($reqCount - $curQty) . " ชิ้น จึงจะหลอมรวมไอเทมนี้ได้"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Deduct shadow fragments
    $db->query("UPDATE user_materials SET quantity = quantity - {$reqCount} WHERE user_id = {$userId} AND material_code = '{$shadowCode}'");

    // Grant real equipment item
    $ins = $db->prepare("INSERT INTO user_equipment (user_id, item_id, level, is_equipped, slot_index) VALUES (?, ?, 1, 0, NULL)");
    $ins->bind_param("ii", $userId, $itemId);
    $ins->execute();
    $newUserEqId = $ins->insert_id;
    $ins->close();

    echo json_encode([
        'status' => 'success',
        'message' => "🎉 ขอแสดงความยินดี! หลอมรวมการ์ดเงาสำเร็จ ได้รับไอเทม '{$item['name']}' (เกรด {$item['grade']}) เข้าสู่กระเป๋าเรียบร้อยแล้ว!",
        'item' => $item,
        'user_eq_id' => $newUserEqId
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 9. PENDANT GACHA (DRAW FOR ITEMS & SHADOWS)
if ($action === 'draw_pendant_gacha') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $drawCount = (int)($inputData['count'] ?? 1); // 1 or 5
    if ($drawCount !== 5) $drawCount = 1;
    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนสุ่มกาชา'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $costPerDraw = 60;
    $totalCost = ($drawCount === 5) ? 270 : $costPerDraw; // 10% discount on 5x

    $uRes = $db->query("SELECT diamond FROM users WHERE id = {$userId} LIMIT 1");
    $uRow = $uRes ? $uRes->fetch_assoc() : null;
    $curDia = $uRow ? (int)$uRow['diamond'] : 0;

    if ($curDia < $totalCost) {
        echo json_encode([
            'status' => 'error',
            'message' => "💎 เพชรไม่เพียงพอ! ต้องการ {$totalCost} เพชร (คุณมี {$curDia} เพชร)"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Deduct diamonds
    $db->query("UPDATE users SET diamond = diamond - {$totalCost} WHERE id = {$userId}");

    // Fetch all available active items
    $allItemsRes = $db->query("SELECT * FROM equipment_items WHERE is_active = 1");
    $allItems = $allItemsRes ? $allItemsRes->fetch_all(MYSQLI_ASSOC) : [];
    if (empty($allItems)) {
        echo json_encode(['status' => 'error', 'message' => 'ยังไม่มีรายการไอเทมในตู้สุ่ม'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $results = [];
    for ($i = 0; $i < $drawCount; $i++) {
        // Roll random type: 25% Full Item direct, 75% Shadow Fragment
        $randType = rand(1, 100);
        $randomItem = $allItems[array_rand($allItems)];

        if ($randType <= 25) {
            // Direct Item!
            $ins = $db->prepare("INSERT INTO user_equipment (user_id, item_id, level, is_equipped, slot_index) VALUES (?, ?, 1, 0, NULL)");
            $ins->bind_param("ii", $userId, $randomItem['id']);
            $ins->execute();
            $ueId = $ins->insert_id;
            $ins->close();

            $results[] = [
                'type' => 'ITEM',
                'item_id' => $randomItem['id'],
                'name' => $randomItem['name'],
                'grade' => $randomItem['grade'],
                'icon_url' => $randomItem['icon_url'],
                'skill_name' => $randomItem['skill_name'],
                'skill_description' => $randomItem['skill_description'],
                'trigger_rate_percent' => $randomItem['trigger_rate_percent'],
                'badge' => "🎉 ได้รับไอเทมจริง!",
                'user_eq_id' => $ueId
            ];
        } else {
            // Shadow Fragment!
            $sCode = $randomItem['shadow_material_code'];
            $db->query("
                INSERT INTO user_materials (user_id, material_code, quantity) 
                VALUES ({$userId}, '{$sCode}', 1) 
                ON DUPLICATE KEY UPDATE quantity = quantity + 1
            ");

            // Check new shadow total
            $mCheck = $db->query("SELECT quantity FROM user_materials WHERE user_id = {$userId} AND material_code = '{$sCode}'");
            $newShadowQty = $mCheck ? (int)$mCheck->fetch_assoc()['quantity'] : 1;

            $results[] = [
                'type' => 'SHADOW',
                'item_id' => $randomItem['id'],
                'name' => 'การ์ดเงา ' . $randomItem['name'],
                'grade' => $randomItem['grade'],
                'icon_url' => $randomItem['icon_url'],
                'shadow_material_code' => $sCode,
                'owned_shadow_count' => $newShadowQty,
                'shadow_required_count' => $randomItem['shadow_required_count'],
                'badge' => "🃏 ได้รับการ์ดเงา ({$newShadowQty}/{$randomItem['shadow_required_count']})"
            ];
        }
    }

    $newDiaRes = $db->query("SELECT diamond FROM users WHERE id = {$userId} LIMIT 1");
    $newDia = $newDiaRes ? (int)$newDiaRes->fetch_assoc()['diamond'] : ($curDia - $totalCost);

    echo json_encode([
        'status' => 'success',
        'message' => 'เปิดสุ่มจี้เครื่องรางสำเร็จ!',
        'total_cost' => $totalCost,
        'remaining_diamond' => $newDia,
        'results' => $results
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 10. GET GEM GACHA EVENT
if ($action === 'get_gem_gacha_event') {
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `target_drop_rate` DECIMAL(5,2) NOT NULL DEFAULT 1.00");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `premium_rate_multiplier` DECIMAL(4,2) NOT NULL DEFAULT 1.50");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `gold_rate_multiplier` DECIMAL(4,2) NOT NULL DEFAULT 0.50");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `featured_shadow_slot` VARCHAR(10) NOT NULL DEFAULT '5'");
    
    // Always prefer the currently active event
    $res = $db->query("SELECT * FROM gem_gacha_events WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $event = $res ? $res->fetch_assoc() : null;
    if (!$event) {
        $res = $db->query("SELECT * FROM gem_gacha_events ORDER BY id DESC LIMIT 1");
        $event = $res ? $res->fetch_assoc() : null;
    }

    if (!$event) {
        // Auto-seed starter gem gacha event if table is empty
        $db->query("
            INSERT INTO gem_gacha_events (event_name, cost_diamond, target_item_id, start_date, end_date, is_active, shadow_rate_1, shadow_rate_2, shadow_rate_3, shadow_rate_4, shadow_rate_5)
            VALUES ('กิจกรรมสุ่มอัญมณีมหาเวทย์ & เงาลึกลับ', 100, NULL, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1, 40, 30, 15, 10, 5)
        ");
        $res = $db->query("SELECT * FROM gem_gacha_events WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $event = $res ? $res->fetch_assoc() : null;
    }

    $targetItem = null;
    if ($event && !empty($event['target_item_id'])) {
        $tId = (int)$event['target_item_id'];
        $tRes = $db->query("SELECT * FROM equipment_items WHERE id = {$tId} LIMIT 1");
        $targetItem = $tRes ? $tRes->fetch_assoc() : null;
    }

    // Fallback: If no target gem assigned, find highest grade active gem
    if (!$targetItem) {
        $tRes = $db->query("SELECT * FROM equipment_items WHERE is_active = 1 ORDER BY FIELD(grade, 'B', 'A', 'A+', 'S', 'S+', 'SS+') DESC, id DESC LIMIT 1");
        $targetItem = $tRes ? $tRes->fetch_assoc() : null;
    }

    if ($targetItem && empty($targetItem['shape'])) {
        $targetItem['shape'] = 'triangle';
    }

    $isLive = false;
    $isExpired = false;
    $isUpcoming = false;
    $statusState = 'NO_EVENT';
    $statusMessage = 'ขณะนี้ยังไม่มีกิจกรรมอัญมณีเปิดใช้งาน';
    $remainingSeconds = 0;

    if ($event) {
        $isActive = (int)($event['is_active'] ?? 1) === 1;
        $now = time();
        $startTime = !empty($event['start_date']) ? strtotime($event['start_date']) : null;
        $endTime = !empty($event['end_date']) ? strtotime($event['end_date']) : null;

        if ($isActive && $endTime && $now > $endTime) {
            $db->query("UPDATE gem_gacha_events SET end_date = DATE_ADD(NOW(), INTERVAL 14 DAY) WHERE id = " . (int)$event['id']);
            $event['end_date'] = date('Y-m-d H:i:s', strtotime('+14 days'));
            $endTime = strtotime($event['end_date']);
        }

        if (!$isActive) {
            $isExpired = true;
            $statusState = 'INACTIVE';
            $statusMessage = 'กิจกรรมถูกปิดใช้งานชั่วคราว';
        } elseif ($endTime && $now > $endTime) {
            $isExpired = true;
            $statusState = 'EXPIRED';
            $statusMessage = 'กิจกรรมสิ้นสุดลงแล้ว (หมดเวลาจัดกิจกรรม)';
        } elseif ($startTime && $now < $startTime) {
            $isUpcoming = true;
            $statusState = 'UPCOMING';
            $statusMessage = 'กิจกรรมยังไม่เริ่มต้น';
            $remainingSeconds = max(0, $startTime - $now);
        } else {
            $isLive = true;
            $statusState = 'ACTIVE';
            $statusMessage = 'กิจกรรมกำลังดำเนินอยู่';
            if ($endTime) {
                $remainingSeconds = max(0, $endTime - $now);
            }
        }
    }

    $reqId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : (isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0);
    $userId = resolveEquipmentUserId($db, $reqId);
    $userShadows = [];
    $evId = (int)($event['id'] ?? 0);
    if ($evId > 0 && !$isExpired) {
        // Strict event round isolation: only count shadow cards drawn during this active event
        $mRes = $db->query("SELECT material_code, quantity FROM user_materials WHERE user_id = {$userId} AND event_id = {$evId} AND material_code LIKE 'SHADOW_GEM_%'");
        if ($mRes) {
            while ($mRow = $mRes->fetch_assoc()) {
                $userShadows[$mRow['material_code']] = (int)$mRow['quantity'];
            }
        }
        $spGemRes = $db->query("SELECT COALESCE(SUM(quantity), 0) AS qty FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD'");
        if ($spGemRes && ($spRow = $spGemRes->fetch_assoc())) {
            $userShadows['SPECIAL_GEM_CARD'] = (int)$spRow['qty'];
        }
    }

    $userHasTargetGem = false;
    if ($targetItem) {
        $gChk = $db->query("SELECT id FROM user_equipment WHERE user_id = {$userId} AND item_id = {$targetItem['id']} LIMIT 1");
        $userHasTargetGem = ($gChk && $gChk->num_rows > 0);
    }

    echo json_encode([
        'status' => 'success',
        'event' => $event,
        'target_item' => $targetItem,
        'user_has_target_gem' => $userHasTargetGem,
        'is_live' => $isLive,
        'is_expired' => $isExpired,
        'is_upcoming' => $isUpcoming,
        'remaining_seconds' => $remainingSeconds,
        'server_time' => date('Y-m-d H:i:s'),
        'server_timestamp' => $now,
        'server_timezone' => 'Asia/Bangkok',
        'status_state' => $statusState,
        'status_message' => $statusMessage,
        'user_shadows' => $userShadows
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 11. SAVE GEM GACHA EVENT (INSERT OR UPDATE)
if ($action === 'save_gem_gacha_event') {
    $id             = (int)($inputData['id'] ?? 0);
    $eventName      = trim((string)($inputData['event_name']   ?? 'กิจกรรมสุ่มอัญมณี'));
    $costDiamond    = (int)($inputData['cost_diamond']         ?? 100);
    $targetItemId   = !empty($inputData['target_item_id']) ? (int)$inputData['target_item_id'] : null;
    $targetDropRate = isset($inputData['target_drop_rate']) ? (float)$inputData['target_drop_rate'] : 1.0;
    $premRateMultiplier = isset($inputData['premium_rate_multiplier']) ? max(0.1, min(20.0, (float)$inputData['premium_rate_multiplier'])) : 1.5;
    $goldRateMultiplier = isset($inputData['gold_rate_multiplier']) ? max(0.0, min(10.0, (float)$inputData['gold_rate_multiplier'])) : 0.5;
    $startDate      = !empty($inputData['start_date']) ? $inputData['start_date'] : null;
    $endDate        = !empty($inputData['end_date'])   ? $inputData['end_date']   : null;
    $isActive       = isset($inputData['is_active']) ? (int)$inputData['is_active'] : 1;
    $r1 = (float)($inputData['shadow_rate_1'] ?? 90);
    $r2 = (float)($inputData['shadow_rate_2'] ?? 80);
    $r3 = (float)($inputData['shadow_rate_3'] ?? 70);
    $r4 = (float)($inputData['shadow_rate_4'] ?? 50);
    $r5 = (float)($inputData['shadow_rate_5'] ?? 10);
    $shadowConfigJson = !empty($inputData['shadow_config_json']) ? (is_string($inputData['shadow_config_json']) ? $inputData['shadow_config_json'] : json_encode($inputData['shadow_config_json'], JSON_UNESCAPED_UNICODE)) : null;
    $featuredSlot = !empty($inputData['featured_shadow_slot']) ? (string)$inputData['featured_shadow_slot'] : '5';

    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `target_drop_rate` DECIMAL(5,2) NOT NULL DEFAULT 1.00");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `premium_rate_multiplier` DECIMAL(4,2) NOT NULL DEFAULT 1.50");
    @$db->query("ALTER TABLE `gem_gacha_events` ADD COLUMN IF NOT EXISTS `gold_rate_multiplier` DECIMAL(4,2) NOT NULL DEFAULT 0.50");

    if ($id > 0) {
        $stmt = $db->prepare("
            UPDATE gem_gacha_events SET
                event_name=?, cost_diamond=?, target_item_id=?, target_drop_rate=?, premium_rate_multiplier=?, gold_rate_multiplier=?, start_date=?, end_date=?, is_active=?, shadow_rate_1=?, shadow_rate_2=?,
                shadow_rate_3=?, shadow_rate_4=?, shadow_rate_5=?, shadow_config_json=?, featured_shadow_slot=?
            WHERE id=?
        ");
        if (!$stmt) {
            echo json_encode(['status' => 'error', 'message' => 'DB Prepare Error: ' . $db->error], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $stmt->bind_param("siidddssdidddddssi", $eventName, $costDiamond, $targetItemId, $targetDropRate, $premRateMultiplier, $goldRateMultiplier, $startDate, $endDate, $isActive, $r1, $r2, $r3, $r4, $r5, $shadowConfigJson, $featuredSlot, $id);
        if (!$stmt->execute()) {
            echo json_encode(['status' => 'error', 'message' => 'DB Execute Error: ' . $stmt->error], JSON_UNESCAPED_UNICODE);
            $stmt->close();
            exit;
        }
        $stmt->close();
        echo json_encode(['status' => 'success', 'message' => 'อัปเดตกิจกรรมสุ่มอัญมณีสำเร็จ', 'id' => $id], JSON_UNESCAPED_UNICODE);
    } else {
        $stmt = $db->prepare("
            INSERT INTO gem_gacha_events (event_name, cost_diamond, target_item_id, target_drop_rate, premium_rate_multiplier, gold_rate_multiplier, start_date, end_date, is_active, shadow_rate_1, shadow_rate_2, shadow_rate_3, shadow_rate_4, shadow_rate_5, shadow_config_json, featured_shadow_slot)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        if (!$stmt) {
            echo json_encode(['status' => 'error', 'message' => 'DB Prepare Error: ' . $db->error], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $stmt->bind_param("siidddssdiddddds", $eventName, $costDiamond, $targetItemId, $targetDropRate, $premRateMultiplier, $goldRateMultiplier, $startDate, $endDate, $isActive, $r1, $r2, $r3, $r4, $r5, $shadowConfigJson, $featuredSlot);
        if (!$stmt->execute()) {
            echo json_encode(['status' => 'error', 'message' => 'DB Execute Error: ' . $stmt->error], JSON_UNESCAPED_UNICODE);
            $stmt->close();
            exit;
        }
        $newId = $stmt->insert_id;
        $stmt->close();
        echo json_encode(['status' => 'success', 'message' => 'สร้างกิจกรรมสุ่มอัญมณีสำเร็จ', 'id' => $newId], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// 12. TOGGLE GEM GACHA EVENT ACTIVE STATE
if ($action === 'toggle_gem_gacha_event') {
    $id       = (int)($inputData['id']        ?? 0);
    $isActive = (int)($inputData['is_active'] ?? 0) ? 1 : 0;

    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ ID กิจกรรม'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // Deactivate all, then set target
    $db->query("UPDATE gem_gacha_events SET is_active = 0");
    if ($isActive) {
        $db->query("UPDATE gem_gacha_events SET is_active = 1 WHERE id = {$id}");
    }
    echo json_encode(['status' => 'success', 'message' => $isActive ? 'เปิดใช้งานกิจกรรมสุ่มอัญมณีแล้ว' : 'ปิดกิจกรรมสุ่มอัญมณีแล้ว'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 13. GET ACTIVE GEM GACHA EVENT
if ($action === 'get_active_gem_gacha') {
    $res = $db->query("SELECT * FROM gem_gacha_events WHERE is_active = 1 LIMIT 1");
    $event = $res ? $res->fetch_assoc() : null;
    echo json_encode(['status' => 'success', 'event' => $event], JSON_UNESCAPED_UNICODE);
    exit;
}

// 14. DRAW GEM GACHA (Full Multi-Pull, Gold/Diamond, Video-Popup Drops Compatible)
if ($action === 'draw_gem_gacha') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนสุ่มอัญมณี'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Get active event
    $evRes = $db->query("SELECT * FROM gem_gacha_events WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $event = $evRes ? $evRes->fetch_assoc() : null;
    if (!$event) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีกิจกรรมสุ่มอัญมณีที่เปิดอยู่ในขณะนี้'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Check event duration
    $now = time();
    if (!empty($event['start_date']) && $now < strtotime($event['start_date'])) {
        echo json_encode(['status' => 'error', 'message' => '⏰ ยังไม่ถึงเวลาเริ่มกิจกรรมนี้!'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (!empty($event['end_date']) && $now > strtotime($event['end_date'])) {
        echo json_encode(['status' => 'error', 'message' => '🛑 กิจกรรมสุ่มอัญมณีนี้สิ้นสุดลงแล้ว (หมดเวลาจัดกิจกรรม)!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $count = max(1, min(10, (int)($inputData['count'] ?? 1)));
    $currency = strtoupper((string)($inputData['currency'] ?? 'DIAMOND'));
    $packTier = strtoupper((string)($inputData['pack_tier'] ?? ($inputData['tier'] ?? 'SPECIAL')));

    $baseCostDia = (int)($event['cost_diamond'] ?? 100);
    $totalCost = 0;
    if ($currency === 'GOLD') {
        $totalCost = ($count >= 5) ? 120000 : (30000 * $count);
    } elseif ($packTier === 'PREMIUM') {
        $totalCost = ($count >= 10) ? (int)round($baseCostDia * 10 * 1.35) : (int)round($baseCostDia * 5 * 1.45);
    } else {
        $totalCost = ($count >= 5) ? (int)round($baseCostDia * $count * 0.9) : ($baseCostDia * $count);
    }

    $uRes = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId} LIMIT 1");
    $uRow = $uRes ? $uRes->fetch_assoc() : null;
    $curDia = $uRow ? (int)$uRow['diamond'] : 0;
    $curGold = $uRow ? (int)$uRow['gold'] : 0;

    if ($currency === 'GOLD') {
        if ($curGold < $totalCost) {
            echo json_encode(['status' => 'error', 'message' => "💰 ทองไม่เพียงพอ! ต้องการ " . number_format($totalCost) . " ทอง (คุณมี " . number_format($curGold) . " ทอง)"], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $db->query("UPDATE users SET gold = gold - {$totalCost} WHERE id = {$userId}");
    } else {
        if ($curDia < $totalCost) {
            echo json_encode(['status' => 'error', 'message' => "💎 เพชรไม่เพียงพอ! ต้องการ " . number_format($totalCost) . " เพชร (คุณมี " . number_format($curDia) . " เพชร)"], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $db->query("UPDATE users SET diamond = diamond - {$totalCost} WHERE id = {$userId}");
    }

    // Fetch gem items
    $gemItemsRes = $db->query("SELECT * FROM equipment_items WHERE is_active = 1 AND shape IS NOT NULL");
    $gemItems = $gemItemsRes ? $gemItemsRes->fetch_all(MYSQLI_ASSOC) : [];
    if (empty($gemItems)) {
        // Fallback to all active equipment items
        $gemItemsRes2 = $db->query("SELECT * FROM equipment_items WHERE is_active = 1");
        $gemItems = $gemItemsRes2 ? $gemItemsRes2->fetch_all(MYSQLI_ASSOC) : [];
    }

    // Shadow rates & metadata from event's shadow_config_json (sync with Admin 5 colors)
    $shadowConfig = [];
    if (!empty($event['shadow_config_json'])) {
        $shadowConfig = is_string($event['shadow_config_json']) ? json_decode($event['shadow_config_json'], true) : $event['shadow_config_json'];
    }

    $slotOrder = ['black', 'red', 'orange', 'blue', 'gold'];
    $defaultShadowSlots = [
        'black'  => ['name' => 'เงาดำ A',  'grade' => 'A',  'shape' => 'triangle', 'color' => '#64748b', 'aura' => 'none', 'intensity' => 100, 'rate' => 90, 'req_count' => 15],
        'red'    => ['name' => 'เงาแดง A',  'grade' => 'A',  'shape' => 'triangle', 'color' => '#ef4444', 'aura' => 'none', 'intensity' => 100, 'rate' => 80, 'req_count' => 15],
        'orange' => ['name' => 'เงาส้ม A',  'grade' => 'A',  'shape' => 'triangle', 'color' => '#ff7b00', 'aura' => 'none', 'intensity' => 100, 'rate' => 70, 'req_count' => 15],
        'blue'   => ['name' => 'เงาฟ้า A+', 'grade' => 'A+', 'shape' => 'triangle', 'color' => '#38bdf8', 'aura' => 'none', 'intensity' => 100, 'rate' => 50, 'req_count' => 10],
        'gold'   => ['name' => 'เงาทอง S',  'grade' => 'S',  'shape' => 'triangle', 'color' => '#ffd700', 'aura' => 'none', 'intensity' => 100, 'rate' => 10, 'req_count' => 4],
    ];

    // Target Gem details for inheriting shape & icon
    $targetItemRes = null;
    $targetGemInfo = null;
    $targetGemId = (int)($event['target_item_id'] ?? ($event['target_gem_id'] ?? 1));
    if ($targetGemId > 0) {
        $tRes = $db->query("SELECT * FROM equipment_items WHERE id = {$targetGemId} LIMIT 1");
        if ($tRes && $tRes->num_rows > 0) {
            $targetGemInfo = $tRes->fetch_assoc();
        }
    }
    $targetShape = $targetGemInfo['shape'] ?? 'pentagon';

    $shadowRates = [];
    $shadowMetaByCode = [];

    foreach ($slotOrder as $idx => $slotKey) {
        $codeKey = "SHADOW_GEM_" . ($idx + 1);
        $sc = (is_array($shadowConfig) && isset($shadowConfig[$slotKey])) ? $shadowConfig[$slotKey] : ($defaultShadowSlots[$slotKey] ?? []);
        
        $sRate = isset($sc['rate']) ? (float)$sc['rate'] : (float)($defaultShadowSlots[$slotKey]['rate'] ?? 20);
        $shadowRates[$codeKey] = max(0.1, $sRate);

        $shadowMetaByCode[$codeKey] = [
            'slot_key'  => $slotKey,
            'name'      => !empty($sc['name']) ? $sc['name'] : ($defaultShadowSlots[$slotKey]['name']),
            'grade'     => !empty($sc['grade']) ? $sc['grade'] : ($defaultShadowSlots[$slotKey]['grade']),
            'shape'     => !empty($sc['shape']) ? $sc['shape'] : $targetShape,
            'color'     => !empty($sc['color']) ? $sc['color'] : ($defaultShadowSlots[$slotKey]['color']),
            'aura'      => !empty($sc['aura_type']) ? $sc['aura_type'] : (!empty($sc['aura']) ? $sc['aura'] : 'none'),
            'intensity' => isset($sc['aura_intensity']) ? (int)$sc['aura_intensity'] : (isset($sc['intensity']) ? (int)$sc['intensity'] : 100),
            'req_count' => isset($sc['req']) ? (int)$sc['req'] : (isset($sc['req_count']) ? (int)$sc['req_count'] : ($defaultShadowSlots[$slotKey]['req_count'] ?? 10)),
            'target_gem_id' => $targetGemId
        ];
    }

    $drops = [];
    // 🎯 อัตราสุ่มได้อัญมณีแท้โดยตรงต่อใบ ตามที่แอดมินตั้งค่าไว้ (เช่น 1.00% หรือ 0.5%)
    $baseTargetRate = isset($event['target_drop_rate']) ? (float)$event['target_drop_rate'] : 1.0;
    if ($baseTargetRate <= 0.0) $baseTargetRate = 1.0;
    $premRateMultiplier = isset($event['premium_rate_multiplier']) ? (float)$event['premium_rate_multiplier'] : 1.5;
    if ($premRateMultiplier <= 0.0) $premRateMultiplier = 1.5;
    $goldRateMultiplier = isset($event['gold_rate_multiplier']) ? (float)$event['gold_rate_multiplier'] : 0.5;
    if ($goldRateMultiplier < 0.0) $goldRateMultiplier = 0.5;

    $effectiveTargetRate = ($packTier === 'PREMIUM') ? ($baseTargetRate * $premRateMultiplier) : (($currency === 'GOLD') ? ($baseTargetRate * $goldRateMultiplier) : $baseTargetRate);

    for ($i = 0; $i < $count; $i++) {
        $rollPercent = (float)mt_rand(1, 10000) / 100.0;
        if ($rollPercent <= $effectiveTargetRate && !empty($gemItems)) {
            // Direct gem item! (กำหนดให้อัญมณีเป้าหมายประจำกิจกรรม $targetGemInfo เป็นรางวัลใหญ่เสมอ)
            $wonGem = $targetGemInfo ?? $gemItems[array_rand($gemItems)];
            $ins = $db->prepare("INSERT INTO user_equipment (user_id, item_id, level, is_equipped, slot_index) VALUES (?, ?, 1, 0, NULL)");
            $ins->bind_param("ii", $userId, $wonGem['id']);
            $ins->execute();
            $ueId = $ins->insert_id;
            $ins->close();

            $drops[] = [
                'type' => 'GEM_ITEM',
                'category' => 'GEM',
                'item_id' => $wonGem['id'],
                'name' => $wonGem['name'],
                'grade' => $wonGem['grade'] ?? 'SS+',
                'rarity' => $wonGem['grade'] ?? 'SS+',
                'shape' => $wonGem['shape'] ?? $targetShape,
                'color' => $wonGem['gem_color'] ?? '#a855f7',
                'icon_url' => $wonGem['icon_url'],
                'skill_name' => $wonGem['skill_name'] ?? 'สกิลพิเศษ',
                'skill_description' => $wonGem['skill_description'] ?? '',
                'trigger_rate_percent' => $wonGem['trigger_rate_percent'] ?? 90,
                'badge' => '💎 ได้รับอัญมณีแท้ประจำกิจกรรม!',
                'target_gem_id' => $targetGemId,
                'target_gem_name' => $wonGem['name'],
                'user_eq_id' => $ueId,
                'is_grand_prize' => true
            ];
        } else {
            // ตรวจสอบโอกาสออก การ์ดอัญมณีปลุกพลังพิเศษ S (SPECIAL_GEM_CARD) ตาม % ที่ตั้งไว้ใน Admin
            $gemSpecialPct = 5.0;
            $sawRes = @$db->query("SELECT setting_value FROM `game_settings` WHERE setting_key = 'special_awakening_config' LIMIT 1");
            if ($sawRes && ($sawRow = $sawRes->fetch_assoc()) && !empty($sawRow['setting_value'])) {
                $sawDec = json_decode($sawRow['setting_value'], true);
                if (isset($sawDec['gem']['drop_rate_pct'])) {
                    $gemSpecialPct = max(0, min(100, (float)$sawDec['gem']['drop_rate_pct']));
                }
            }
            if ($gemSpecialPct > 0 && ((float)mt_rand(1, 10000) / 100.0) <= $gemSpecialPct) {
                $evId = (int)($event['id'] ?? 1);
                $evStartDate = !empty($event['start_date']) ? "'{$event['start_date']}'" : "NOW()";
                $evEndDate = !empty($event['end_date']) ? "'{$event['end_date']}'" : "DATE_ADD(NOW(), INTERVAL 30 DAY)";
                $db->query("
                    INSERT INTO user_materials (user_id, material_code, quantity, event_id, event_type, start_date, end_date)
                    VALUES ({$userId}, 'SPECIAL_GEM_CARD', 1, {$evId}, 'GEM', {$evStartDate}, {$evEndDate})
                    ON DUPLICATE KEY UPDATE quantity = quantity + 1, start_date = VALUES(start_date), end_date = VALUES(end_date)
                ");
                $mCheck = $db->query("SELECT COALESCE(SUM(quantity), 0) AS q FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD'");
                $newQty = $mCheck ? (int)$mCheck->fetch_assoc()['q'] : 1;
                $drops[] = [
                    'type' => 'SHADOW_GEM',
                    'category' => 'GEM',
                    'material_code' => 'SPECIAL_GEM_CARD',
                    'shadow_material_code' => 'SPECIAL_GEM_CARD',
                    'event_id' => $evId,
                    'start_date' => $event['start_date'] ?? null,
                    'end_date' => $event['end_date'] ?? null,
                    'slot_key' => 'special',
                    'name' => 'การ์ดอัญมณีปลุกพลังพิเศษ S',
                    'grade' => 'S',
                    'rarity' => 'S',
                    'shape' => $targetShape,
                    'color' => '#fbbf24',
                    'aura' => 'gold',
                    'intensity' => 130,
                    'req_count' => 0,
                    'owned_shadow_count' => $newQty,
                    'target_gem_name' => $targetGem['name'] ?? 'อัญมณีแท้',
                    'is_jackpot' => false
                ];
                continue;
            }

            // Shadow gem material (Proper Weighted Random Roll based on Admin Rates)
            $activeShadowRates = $shadowRates;
            if ($packTier === 'PREMIUM') {
                if (isset($activeShadowRates['SHADOW_GEM_1'])) $activeShadowRates['SHADOW_GEM_1'] *= 0.35;
                if (isset($activeShadowRates['SHADOW_GEM_2'])) $activeShadowRates['SHADOW_GEM_2'] *= 0.45;
                if (isset($activeShadowRates['SHADOW_GEM_3'])) $activeShadowRates['SHADOW_GEM_3'] *= 0.70;
                if (isset($activeShadowRates['SHADOW_GEM_4'])) $activeShadowRates['SHADOW_GEM_4'] *= 1.85;
                if (isset($activeShadowRates['SHADOW_GEM_5'])) $activeShadowRates['SHADOW_GEM_5'] *= 2.50;
            }

            $totalShadowWeight = array_sum($activeShadowRates);
            if ($totalShadowWeight <= 0) $totalShadowWeight = 100.0;
            $roll = ((float)mt_rand(1, 100000) / 100000.0) * $totalShadowWeight;
            $cumulative = 0.0;
            $chosenCode = array_key_first($activeShadowRates) ?? 'SHADOW_GEM_1';
            foreach ($activeShadowRates as $code => $rate) {
                $cumulative += (float)$rate;
                if ($roll <= $cumulative) {
                    $chosenCode = $code;
                    break;
                }
            }

            $evId = (int)($event['id'] ?? 1);
            $evStartDate = !empty($event['start_date']) ? "'{$event['start_date']}'" : "NOW()";
            $evEndDate = !empty($event['end_date']) ? "'{$event['end_date']}'" : "DATE_ADD(NOW(), INTERVAL 30 DAY)";
            $db->query("
                INSERT INTO user_materials (user_id, material_code, quantity, event_id, event_type, start_date, end_date)
                VALUES ({$userId}, '{$chosenCode}', 1, {$evId}, 'GEM', {$evStartDate}, {$evEndDate})
                ON DUPLICATE KEY UPDATE quantity = quantity + 1, start_date = VALUES(start_date), end_date = VALUES(end_date)
            ");
            $mCheck = $db->query("SELECT quantity FROM user_materials WHERE user_id = {$userId} AND material_code = '{$chosenCode}' AND event_id = {$evId}");
            $newQty = $mCheck ? (int)$mCheck->fetch_assoc()['quantity'] : 1;

            $meta = $shadowMetaByCode[$chosenCode] ?? $shadowMetaByCode['SHADOW_GEM_1'];
            $drops[] = [
                'type' => 'SHADOW_GEM',
                'category' => 'GEM',
                'material_code' => $chosenCode,
                'shadow_material_code' => $chosenCode,
                'event_id' => $evId,
                'start_date' => $event['start_date'] ?? null,
                'end_date' => $event['end_date'] ?? null,
                'slot_key' => $meta['slot_key'] ?? 'black',
                'name' => $meta['name'],
                'grade' => $meta['grade'],
                'rarity' => $meta['grade'],
                'shape' => $meta['shape'] ?: $targetShape,
                'color' => $meta['color'],
                'aura' => $meta['aura'],
                'intensity' => $meta['intensity'] ?? 100,
                'owned_shadow_count' => $newQty,
                'req_count' => $meta['req_count'],
                'badge' => "ชิ้นส่วนเงา ({$newQty}/{$meta['req_count']})",
                'target_gem_id' => $targetGemId,
                'target_gem_name' => $targetGemInfo['name'] ?? 'อัญมณีวายุผลักไสคู่ต่อสู้'
            ];
        }
    }

    // Fetch all user shadows for this active event
    $evId = (int)($event['id'] ?? 1);
    $evStartTs = !empty($event['start_date']) ? strtotime($event['start_date']) : 0;
    $now = time();
    $mRes = $db->query("SELECT material_code, quantity, start_date, end_date FROM user_materials WHERE user_id = {$userId} AND event_id = {$evId} AND material_code LIKE 'SHADOW_GEM_%'");
    $allUserShadows = [];
    if ($mRes) {
        while ($mRow = $mRes->fetch_assoc()) {
            $rowEndTs = !empty($mRow['end_date']) ? strtotime($mRow['end_date']) : 0;
            if ($rowEndTs > 0 && $rowEndTs < $now) continue;
            if ($evStartTs > 0 && $rowEndTs > 0 && $rowEndTs < $evStartTs) continue;
            $allUserShadows[$mRow['material_code']] = (int)$mRow['quantity'];
        }
    }
    $spGemRes2 = $db->query("SELECT COALESCE(SUM(quantity), 0) AS qty FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD'");
    if ($spGemRes2 && ($spRow2 = $spGemRes2->fetch_assoc())) {
        $allUserShadows['SPECIAL_GEM_CARD'] = (int)$spRow2['qty'];
    }

    $newURes = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId} LIMIT 1");
    $newURow = $newURes ? $newURes->fetch_assoc() : null;
    $finalDia = $newURow ? (int)$newURow['diamond'] : 0;
    $finalGold = $newURow ? (int)$newURow['gold'] : 0;

    echo json_encode([
        'status' => 'success',
        'message' => 'สุ่มอัญมณีสำเร็จ!',
        'currency' => $currency,
        'cost_spent' => $totalCost,
        'total_cards' => count($drops),
        'drops' => $drops,
        'user' => [
            'diamond' => $finalDia,
            'gold' => $finalGold
        ],
        'user_shadows' => $allUserShadows
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 14.5. EXCHANGE 5 SHADOW GEMS FOR EVENT TARGET GEM
if ($action === 'exchange_gem_gacha_event') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนแลกรับอัญมณี'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $evRes = $db->query("SELECT * FROM gem_gacha_events WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $event = $evRes ? $evRes->fetch_assoc() : null;
    if (!$event) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีกิจกรรมอัญมณีที่เปิดอยู่ในขณะนี้'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $now = time();
    if (!empty($event['start_date']) && $now < strtotime($event['start_date'])) {
        echo json_encode(['status' => 'error', 'message' => '⏰ ยังไม่ถึงเวลาเริ่มกิจกรรมนี้!'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (!empty($event['end_date']) && $now > strtotime($event['end_date'])) {
        echo json_encode(['status' => 'error', 'message' => '🛑 กิจกรรมนี้สิ้นสุดลงแล้ว การ์ดเงาหมดอายุ ไม่สามารถนำมาใช้สะสมหรือแลกรับอัญมณีได้อีกต่อไป'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $evId = (int)$event['id'];
    $targetGemId = (int)($event['target_item_id'] ?? 6);
    $tRes = $db->query("SELECT * FROM equipment_items WHERE id = {$targetGemId} AND is_active = 1 LIMIT 1");
    $targetGem = $tRes ? $tRes->fetch_assoc() : null;
    if (!$targetGem) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบอัญมณีรางวัลประจำกิจกรรม'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $shadowConfig = !empty($event['shadow_config_json']) ? (is_string($event['shadow_config_json']) ? json_decode($event['shadow_config_json'], true) : $event['shadow_config_json']) : [];
    $slotOrder = ['black', 'red', 'orange', 'blue', 'gold'];
    $defaultReqs = [15, 15, 15, 10, 4];

    $needed = [];
    $canExchange = true;
    foreach ($slotOrder as $idx => $slotKey) {
        $codeKey = "SHADOW_GEM_" . ($idx + 1);
        $sc = $shadowConfig[$slotKey] ?? [];
        $req = isset($sc['req']) ? (int)$sc['req'] : $defaultReqs[$idx];

        $mCheck = $db->query("SELECT quantity, end_date FROM user_materials WHERE user_id = {$userId} AND material_code = '{$codeKey}' AND event_id = {$evId} LIMIT 1");
        $mRow = $mCheck ? $mCheck->fetch_assoc() : null;
        $curQty = (int)($mRow['quantity'] ?? 0);
        $cardEndTs = !empty($mRow['end_date']) ? strtotime($mRow['end_date']) : 0;
        if ($cardEndTs > 0 && $cardEndTs < $now) {
            $curQty = 0;
        }
        if ($curQty < $req) {
            $canExchange = false;
        }
        $needed[$codeKey] = $req;
    }

    if (!$canExchange) {
        echo json_encode(['status' => 'error', 'message' => '❌ ชิ้นส่วนเงาอัญมณียังไม่ครบตามเงื่อนไขทั้ง 5 ชนิด กรุณาสะสมให้ครบ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Deduct all 5 shadow materials for this event
    foreach ($needed as $codeKey => $reqQty) {
        $db->query("UPDATE user_materials SET quantity = quantity - {$reqQty} WHERE user_id = {$userId} AND material_code = '{$codeKey}' AND event_id = {$evId}");
    }

    // Grant target gem item
    $ins = $db->prepare("INSERT INTO user_equipment (user_id, item_id, level, is_equipped, slot_index) VALUES (?, ?, 1, 0, NULL)");
    $ins->bind_param("ii", $userId, $targetGemId);
    $ins->execute();
    $newUserEqId = $ins->insert_id;
    $ins->close();

    // Fetch updated user shadows for this event
    $evStartTs = !empty($event['start_date']) ? strtotime($event['start_date']) : 0;
    $mRes = $db->query("SELECT material_code, quantity, start_date, end_date FROM user_materials WHERE user_id = {$userId} AND event_id = {$evId} AND material_code LIKE 'SHADOW_GEM_%'");
    $allUserShadows = [];
    if ($mRes) {
        while ($mRow = $mRes->fetch_assoc()) {
            $rowEndTs = !empty($mRow['end_date']) ? strtotime($mRow['end_date']) : 0;
            if ($rowEndTs > 0 && $rowEndTs < $now) continue;
            if ($evStartTs > 0 && $rowEndTs > 0 && $rowEndTs < $evStartTs) continue;
            $allUserShadows[$mRow['material_code']] = (int)$mRow['quantity'];
        }
    }
    $spGemRes2 = $db->query("SELECT COALESCE(SUM(quantity), 0) AS qty FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD'");
    if ($spGemRes2 && ($spRow2 = $spGemRes2->fetch_assoc())) {
        $allUserShadows['SPECIAL_GEM_CARD'] = (int)$spRow2['qty'];
    }

    echo json_encode([
        'status' => 'success',
        'message' => "🎉 ขอแสดงความยินดี! แลกรับอัญมณีแท้ '{$targetGem['name']}' (เกรด {$targetGem['grade']}) สำเร็จแล้ว!",
        'item' => $targetGem,
        'user_eq_id' => $newUserEqId,
        'user_shadows' => $allUserShadows
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 15. GET USER GEMS (all gem-type equipment owned by user)
if ($action === 'get_user_gems') {
    $reqId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : (isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0);
    $userId = resolveEquipmentUserId($db, $reqId);
    if ($userId <= 0) {
        echo json_encode([
            'status' => 'success',
            'character_grade' => 'SS+',
            'slot_limit' => 3,
            'gems' => [],
            'equipped_slots' => []
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $uRes = $db->query("SELECT character_grade FROM users WHERE id = {$userId} LIMIT 1");
    $uRow = $uRes ? $uRes->fetch_assoc() : null;
    $charGrade = $uRow['character_grade'] ?? 'SS+';
    $slotLimit = getSlotLimitForCardGrade($charGrade);

    sanitizeUserEquippedGems($db, $userId, $slotLimit);

    $eqRes = $db->query("
        SELECT ue.id as user_eq_id, ue.level, ue.is_equipped, ue.slot_index, ue.created_at,
               ei.id as item_id, ei.item_code, ei.name, ei.icon_url, ei.grade, ei.shape, ei.gem_color,
               ei.skill_category, ei.skill_name, ei.skill_description,
               ei.trigger_rate_percent, ei.shadow_material_code, ei.shadow_required_count,
               ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = {$userId} AND ei.shape IS NOT NULL
        ORDER BY ue.is_equipped DESC, FIELD(ei.grade,'SS+','S+','S','A+','A','B'), ue.id DESC
    ");
    $gems = $eqRes ? $eqRes->fetch_all(MYSQLI_ASSOC) : [];

    $equipped = [];
    $bag      = [];
    foreach ($gems as $g) {
        if (!empty($g['is_equipped'])) {
            $equipped[(int)($g['slot_index'] ?: count($equipped) + 1)] = $g;
        } else {
            $bag[] = $g;
        }
    }

    echo json_encode([
        'status'          => 'success',
        'character_grade' => $charGrade,
        'slot_limit'      => $slotLimit,
        'equipped_gems'   => $equipped,
        'bag_gems'        => $bag,
        'all_gems'        => $gems
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 16. EQUIP GEM (validates gem slots by card grade + 1 per shape + no duplicate skill)
if ($action === 'equip_gem') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $userEqId   = (int)($inputData['user_eq_id']   ?? 0);
    $targetSlot = (int)($inputData['slot_index']   ?? 0);
    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนสวมใส่อัญมณี'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($userEqId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบอัญมณีที่เลือกสวมใส่'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $uRes = $db->query("SELECT character_grade FROM users WHERE id = {$userId} LIMIT 1");
    $uRow = $uRes ? $uRes->fetch_assoc() : null;
    $charGrade = strtoupper(trim((string)($uRow['character_grade'] ?? 'SS+')));
    $slotLimit = getSlotLimitForCardGrade($charGrade);

    if ($slotLimit <= 0) {
        echo json_encode([
            'status'  => 'error',
            'message' => "❌ การ์ดเกรด {$charGrade} ไม่รองรับการสวมใส่อัญมณี ต้องการการ์ดเกรด S ขึ้นไป"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Ensure existing equipped gems are sanitized first
    sanitizeUserEquippedGems($db, $userId, $slotLimit);

    // Verify item is a gem and belongs to user
    $itemRes = $db->query("
        SELECT ue.id as user_eq_id, ue.is_equipped, ue.slot_index,
               ei.id as item_id, ei.name, ei.shape, ei.skill_category,
               ei.skill_name, ei.skill_description, ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.id = {$userEqId} AND ue.user_id = {$userId} AND ei.shape IS NOT NULL
        LIMIT 1
    ");
    $targetGem = $itemRes ? $itemRes->fetch_assoc() : null;
    if (!$targetGem) {
        echo json_encode(['status' => 'error', 'message' => 'คุณไม่ได้เป็นเจ้าของอัญมณีนี้หรือไม่ใช่อัญมณี'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $targetShape = strtolower(trim((string)($targetGem['shape'] ?? 'triangle')));
    $targetShapeLabel = getGemShapeThaiLabel($targetShape);

    // Fetch all other currently equipped gems of this user
    $eqRes = $db->query("
        SELECT ue.id as user_eq_id, ue.slot_index,
               ei.id as item_id, ei.name, ei.shape, ei.skill_category,
               ei.skill_name, ei.skill_description, ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = {$userId} AND ue.is_equipped = 1 AND ue.id != {$userEqId} AND ei.shape IS NOT NULL
        ORDER BY COALESCE(ue.slot_index, 99) ASC
    ");
    $otherEquipped = $eqRes ? $eqRes->fetch_all(MYSQLI_ASSOC) : [];

    $usedSlots = [];
    foreach ($otherEquipped as $eq) {
        $eqShape = strtolower(trim((string)($eq['shape'] ?? '')));
        $eqSlot  = (int)($eq['slot_index'] ?? 1);
        $usedSlots[] = $eqSlot;

        // กฎที่ 1: ห้ามสวมใส่อัญมณีรูปทรงซ้ำกัน (สามเหลี่ยม, สี่เหลี่ยม, ห้าเหลี่ยม ใส่ได้อย่างละ 1 ชิ้นเท่านั้น)
        if ($eqShape !== '' && $eqShape === $targetShape) {
            echo json_encode([
                'status'  => 'error',
                'message' => "❌ ไม่สามารถสวมใส่ซ้ำรูปทรงได้!\nคุณได้สวมใส่อัญมณีรูปทรง{$targetShapeLabel} ('{$eq['name']}') อยู่แล้วในช่องที่ {$eqSlot}\n(กฎอัญมณี: รูปทรงสามเหลี่ยม, สี่เหลี่ยม, ห้าเหลี่ยม สวมใส่ได้อย่างละ 1 ชิ้นเท่านั้น กรุณาถอดชิ้นเดิมออกก่อน)"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // กฎที่ 2: ห้ามสวมใส่อัญมณีที่มีสกิลซ้ำกัน แม้รูปทรงต่างกันก็ตาม
        if (areGemSkillsDuplicate($targetGem, $eq)) {
            $eqShapeLabel = getGemShapeThaiLabel($eqShape);
            echo json_encode([
                'status'  => 'error',
                'message' => "❌ ไม่สามารถสวมใส่สกิลซ้ำกันได้!\nอัญมณี '{$targetGem['name']}' มีสกิล '{$targetGem['skill_name']}' ซ้ำกับ '{$eq['name']}' ({$eqShapeLabel}) ที่สวมใส่อยู่ในช่องที่ {$eqSlot}\n(กฎอัญมณี: ห้ามสวมใส่อัญมณีที่มีสกิลซ้ำกัน แม้จะมีรูปทรงต่างกันก็ตาม)"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // Find an available unlocked slot (1..$slotLimit)
    if ($targetSlot < 1 || $targetSlot > $slotLimit || in_array($targetSlot, $usedSlots, true)) {
        $foundFreeSlot = 0;
        for ($s = 1; $s <= $slotLimit; $s++) {
            if (!in_array($s, $usedSlots, true)) {
                $foundFreeSlot = $s;
                break;
            }
        }
        if ($foundFreeSlot <= 0) {
            echo json_encode([
                'status'  => 'error',
                'message' => "❌ ช่องสวมใส่อัญมณีเต็มแล้ว ({$slotLimit}/{$slotLimit} ช่อง) กรุณาถอดอัญมณีออกก่อน"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $targetSlot = $foundFreeSlot;
    }

    // Equip gem into targetSlot
    $db->query("UPDATE user_equipment SET is_equipped = 1, slot_index = {$targetSlot} WHERE id = {$userEqId} AND user_id = {$userId}");

    echo json_encode([
        'status'     => 'success',
        'message'    => "💎 สวมใส่อัญมณี '{$targetGem['name']}' ({$targetShapeLabel}) ในช่องที่ {$targetSlot} เรียบร้อยแล้ว!",
        'slot_index' => $targetSlot,
        'gem'        => $targetGem
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 17. UNEQUIP GEM
if ($action === 'unequip_gem') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $userEqId = (int)($inputData['user_eq_id'] ?? 0);
    $slotIndex = (int)($inputData['slot_index'] ?? 0);
    if ($userId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบก่อนถอดอัญมณี'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($userEqId > 0) {
        $db->query("
            UPDATE user_equipment ue
            JOIN equipment_items ei ON ue.item_id = ei.id
            SET ue.is_equipped = 0, ue.slot_index = NULL
            WHERE ue.id = {$userEqId} AND ue.user_id = {$userId} AND ei.shape IS NOT NULL
        ");
    } elseif ($slotIndex > 0) {
        $db->query("
            UPDATE user_equipment ue
            JOIN equipment_items ei ON ue.item_id = ei.id
            SET ue.is_equipped = 0, ue.slot_index = NULL
            WHERE ue.user_id = {$userId} AND ue.slot_index = {$slotIndex} AND ei.shape IS NOT NULL
        ");
    }

    echo json_encode(['status' => 'success', 'message' => 'ถอดอัญมณีเรียบร้อยแล้ว'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 18. UPGRADE GEM LEVEL (Lv.1 -> Lv.30)
if ($action === 'upgrade_gem') {
    $reqId = isset($inputData['user_id']) ? (int)$inputData['user_id'] : 0;
    $userId = resolveEquipmentUserId($db, $reqId);
    $userEqId = (int)($inputData['user_eq_id'] ?? 0);
    if ($userId <= 0 || $userEqId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูลอัญมณีไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $q = $db->query("
        SELECT ue.id, ue.level, ei.name, ei.grade
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.id = {$userEqId} AND ue.user_id = {$userId}
        LIMIT 1
    ");
    $row = $q ? $q->fetch_assoc() : null;
    if (!$row) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบอัญมณีนี้ในคลังของคุณ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $curLv = max(1, (int)($row['level'] ?? 1));
    if ($curLv >= 30) {
        echo json_encode(['status' => 'error', 'message' => 'อัญมณีนี้อัปเกรดถึงเลเวลสูงสุด (Lv.30) แล้ว!'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $gUpT1 = 100; $gUpT2 = 150; $gUpT3 = 200; $gUpT4 = 500;
    $gemGrade = strtoupper(trim((string)($row['grade'] ?? 'S')));
    $matrixRow = null;
    $gUpRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key = 'upgrade_diamond_matrix' OR setting_key LIKE 'gem_upgrade_dia_%'");
    if ($gUpRes) {
        while ($gUpRow = $gUpRes->fetch_assoc()) {
            $k = $gUpRow['setting_key'];
            if ($k === 'upgrade_diamond_matrix' && !empty($gUpRow['setting_value'])) {
                $mJson = json_decode($gUpRow['setting_value'], true);
                if (isset($mJson['gem'][$gemGrade]) && is_array($mJson['gem'][$gemGrade])) {
                    $matrixRow = $mJson['gem'][$gemGrade];
                }
            } else {
                $v = max(0, (int)$gUpRow['setting_value']);
                if ($k === 'gem_upgrade_dia_t1') $gUpT1 = $v;
                elseif ($k === 'gem_upgrade_dia_t2') $gUpT2 = $v;
                elseif ($k === 'gem_upgrade_dia_t3') $gUpT3 = $v;
                elseif ($k === 'gem_upgrade_dia_t4') $gUpT4 = $v;
            }
        }
    }
    if (is_array($matrixRow)) {
        $gUpT1 = max(0, (int)($matrixRow['t1'] ?? $gUpT1));
        $gUpT2 = max(0, (int)($matrixRow['t2'] ?? $gUpT2));
        $gUpT3 = max(0, (int)($matrixRow['t3'] ?? $gUpT3));
        $gUpT4 = max(0, (int)($matrixRow['t4'] ?? $gUpT4));
    }
    $reqTargetLevel = isset($inputData['target_level']) ? (int)$inputData['target_level'] : 0;
    $isJumpTo29 = ($reqTargetLevel === 29 && $curLv < 29);

    if ($isJumpTo29) {
        $diaCost = 0;
        for ($lv = $curLv; $lv < 29; $lv++) {
            $diaCost += ($lv < 10 ? $gUpT1 : ($lv < 20 ? $gUpT2 : $gUpT3));
        }
        $newLv = 29;
    } else {
        $diaCost = $curLv < 10 ? $gUpT1 : ($curLv < 20 ? $gUpT2 : ($curLv < 29 ? $gUpT3 : $gUpT4));
        $newLv = $curLv + 1;
    }
    $db->begin_transaction();
    try {
        $uRes = $db->query("SELECT diamond FROM users WHERE id = {$userId} FOR UPDATE");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        $curDia = (int)($uRow['diamond'] ?? 0);
        if ($curDia < $diaCost) {
            $db->rollback();
            echo json_encode([
                'status' => 'error',
                'message' => "เพชรไม่พอ! ต้องใช้ " . number_format($diaCost) . " เพชร (คุณมี " . number_format($curDia) . " เพชร)"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if ($newLv === 30) {
            $reqSpecialQty = 5;
            $gemSawActive = true;
            $sawRes = @$db->query("SELECT setting_value FROM `game_settings` WHERE setting_key = 'special_awakening_config' ORDER BY id DESC LIMIT 1");
            if ($sawRes && ($sawRow = $sawRes->fetch_assoc()) && !empty($sawRow['setting_value'])) {
                $sawDec = json_decode($sawRow['setting_value'], true);
                if (isset($sawDec['req_qty_lv30'])) $reqSpecialQty = max(1, (int)$sawDec['req_qty_lv30']);
                if (isset($sawDec['gem']) && is_array($sawDec['gem'])) {
                    if (isset($sawDec['gem']['is_active']) && (int)$sawDec['gem']['is_active'] === 0) $gemSawActive = false;
                    $gEnd = trim((string)($sawDec['gem']['end_date'] ?? ''));
                    if ($gEnd !== '' && ($ts = strtotime($gEnd)) !== false && time() > $ts) $gemSawActive = false;
                }
            }
            if (!$gemSawActive) {
                $db->rollback();
                echo json_encode(['status' => 'error', 'message' => 'การ์ดอัญมณีปลุกพลังพิเศษรอบนี้หมดอายุแล้ว หรือปิดกิจกรรมแล้ว ไม่สามารถใช้ปลุกพลัง Lv.30 ได้'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $mRes = $db->query("SELECT COALESCE(SUM(quantity), 0) AS total_qty FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD' FOR UPDATE");
            $hasSpecialQty = $mRes ? (int)$mRes->fetch_assoc()['total_qty'] : 0;
            if ($hasSpecialQty < $reqSpecialQty) {
                $db->rollback();
                echo json_encode([
                    'status' => 'error',
                    'message' => "ต้องใช้ \"การ์ดอัญมณีปลุกพลังพิเศษ S\" {$reqSpecialQty} ใบในการปลุกพลัง Lv.30 (คุณมี {$hasSpecialQty}/{$reqSpecialQty} ใบ • ซื้อได้ที่ร้านค้าหรือสุ่มในกิจกรรม)"
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $remDeduct = $reqSpecialQty;
            $rowsRes = $db->query("SELECT id, quantity FROM user_materials WHERE user_id = {$userId} AND material_code = 'SPECIAL_GEM_CARD' AND quantity > 0 ORDER BY id ASC FOR UPDATE");
            if ($rowsRes) {
                while (($mr = $rowsRes->fetch_assoc()) && $remDeduct > 0) {
                    $take = min($remDeduct, (int)$mr['quantity']);
                    $mrId = (int)$mr['id'];
                    $db->query("UPDATE user_materials SET quantity = quantity - {$take} WHERE id = {$mrId}");
                    $remDeduct -= $take;
                }
            }
        }
        $newDia = $curDia - $diaCost;
        $db->query("UPDATE users SET diamond = {$newDia} WHERE id = {$userId}");
        $db->query("UPDATE user_equipment SET level = {$newLv} WHERE id = {$userEqId} AND user_id = {$userId}");
        $db->commit();

        echo json_encode([
            'status' => 'success',
            'message' => "⬆️ อัปเกรด '{$row['name']}' เป็น Lv.{$newLv}/30 สำเร็จ!",
            'user_eq_id' => $userEqId,
            'level' => $newLv,
            'diamond' => $newDia,
            'cost' => $diaCost,
            'currency' => 'DIAMOND'
        ], JSON_UNESCAPED_UNICODE);
    } catch (\Throwable $e) {
        $db->rollback();
        echo json_encode(['status' => 'error', 'message' => 'อัปเกรดไม่สำเร็จ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// Default response
echo json_encode(['status' => 'success', 'message' => 'Equipment service is active']);
