<?php
declare(strict_types=1);

/**
 * shop.php - In-Game Shop, Gacha, S+ Crafting, Card Upgrades (1-30), Inventory & Mailbox API
 * PHP 8.4.25 / Nginx 1.31.6
 * Features:
 *  - Purchase Characters & Dice with Gold/Diamond
 *  - Gacha Pull: 200 Diamonds per roll (drops characters, dice, shadow cards, special card)
 *  - S+ Card Exchange: 15 Red Shadow A + 15 Blue Shadow A + 15 Black Shadow A + 8 Gold Shadow A+ -> 1 S+ Card
 *  - Card Upgrade:
 *      * Lvl 1-10: 100 Diamonds / lvl
 *      * Lvl 11-20: 150 Diamonds / lvl
 *      * Lvl 21-29: 200 Diamonds / lvl
 *      * Lvl 30 (Awaken): Special Card + 500 Diamonds -> Unlock special skill (e.g. Pull back 8 tiles) + Golden Sparkle Aura
 *  - Storage / Inventory: View owned cards, dice, shadow materials
 *  - Mailbox: Claim attached diamonds, gold, items
 *  - Event messages & announcements
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/cube_event_service.php';
require_once __DIR__ . '/shop_menus_service.php';

$db = getDbConnection();

function ensureFrameColumns(mysqli $db): void {
    static $done = false;
    if ($done) return;
    $done = true;
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `win_rate_bonus` DECIMAL(5,2) NOT NULL DEFAULT 5.00 COMMENT 'อัตราชนะเพิ่มเติม (%)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `roll_rate` DECIMAL(5,2) NOT NULL DEFAULT 20.00 COMMENT 'อัตราการทอย / คุมเต๋า (%)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `play_skill_rate` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT 'อัตราการเล่นเก่ง / ฝีมือ'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `aura_type` VARCHAR(30) NOT NULL DEFAULT 'none' COMMENT 'none, white, cyan, yellow, gold, orange, crimson, purple, rainbow'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `aura_intensity` INT NOT NULL DEFAULT 100 COMMENT 'ระดับแสงเออร่า 10-100%'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `frame_fx` VARCHAR(40) NOT NULL DEFAULT 'pulse_breathe' COMMENT 'ลูกเล่นแอนิเมชันกรอบ'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `frame_scale` INT NOT NULL DEFAULT 120 COMMENT 'ขนาดสวมกรอบ %'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `avatar_url` MEDIUMTEXT NULL COMMENT 'รูปตัวอย่างกรอบรูป (PNG วงแหวนโปร่งใส)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ตั้งค่าชุดเงา AI (สี, เออร่า, อัตราสุ่ม, รูปวงแหวนเงา)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `color_hex` VARCHAR(25) NOT NULL DEFAULT '#FFD700' COMMENT 'สีขอบ'");
    @$db->query("ALTER TABLE `characters` MODIFY COLUMN `grade` ENUM('B', 'A', 'A+', 'S', 'S+', 'SS+') NOT NULL DEFAULT 'A'");

    // Ensure gacha_events columns
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `cards_per_pack` INT NOT NULL DEFAULT 5 COMMENT 'จำนวนการ์ดต่อแพ็ค'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `target_character_id` INT NOT NULL DEFAULT 1 COMMENT 'กรอบรูปเป้าหมายที่ได้รับจากการแลก'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00 COMMENT '% ออกเงาดำ A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_black` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาดำที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00 COMMENT '% ออกเงาแดง A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_red` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาแดงที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00 COMMENT '% ออกเงาส้ม A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_orange` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาส้มที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00 COMMENT '% ออกเงาฟ้า A+'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_blue` INT NOT NULL DEFAULT 10 COMMENT 'จำนวนเงาฟ้าที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT '% ออกเงาทอง S'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_gold` INT NOT NULL DEFAULT 4 COMMENT 'จำนวนเงาทองที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'JSON รายละเอียดชุดเงา 5 แบบ (รูปเงา, สี, เออร่า, % ออก)'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `exchange_tiers_json` LONGTEXT NULL COMMENT 'JSON อัตราจำนวนเงาแลกกรอบ SS+, S+, S'");

    // Ensure dice_gacha_events table & columns for the 5 shadow system (A to S)
    $db->query("
        CREATE TABLE IF NOT EXISTS `dice_gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(150) NOT NULL DEFAULT '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป',
            `description` TEXT NULL,
            `cost_diamond` INT NOT NULL DEFAULT 100,
            `target_dice_id` INT NOT NULL DEFAULT 1,
            `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00,
            `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `req_shadow_black` INT NOT NULL DEFAULT 15,
            `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
            `req_shadow_red` INT NOT NULL DEFAULT 15,
            `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00,
            `req_shadow_orange` INT NOT NULL DEFAULT 15,
            `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `req_shadow_blue` INT NOT NULL DEFAULT 10,
            `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `req_shadow_gold` INT NOT NULL DEFAULT 4,
            `shadow_config_json` LONGTEXT NULL,
            `start_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_date` DATETIME NOT NULL DEFAULT '2030-12-31 23:59:59',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `cost_diamond` INT NOT NULL DEFAULT 100 COMMENT 'จำนวนเพชรที่ใช้สุ่ม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00 COMMENT '% ออกเงาดำ A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_black` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาดำที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00 COMMENT '% ออกเงาแดง A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_red` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาแดงที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00 COMMENT '% ออกเงาส้ม A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_orange` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาส้มที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00 COMMENT '% ออกเงาฟ้า A+'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_blue` INT NOT NULL DEFAULT 10 COMMENT 'จำนวนเงาฟ้าที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT '% ออกเงาทอง S'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_gold` INT NOT NULL DEFAULT 4 COMMENT 'จำนวนเงาทองที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ตั้งค่าข้อมูลการ์ดเงา 5 สี'");

    // Check if SS+ frame exists
    $chkSS = $db->query("SELECT id FROM `characters` WHERE `grade` = 'SS+' LIMIT 1");
    if (!$chkSS || $chkSS->num_rows === 0) {
        $db->query("INSERT INTO `characters` (name, grade, description, model_prefab_name, win_rate_bonus, roll_rate, play_skill_rate, aura_type, price_diamond, color_hex, is_available) VALUES 
            ('เทพมังกรทองนาคราช', 'SS+', 'กรอบรูปทองคำเปล่งประกายบารมี พลังสูงสุดแห่งจักรวาล', 'hero_dragon_gold', 85.00, 90.00, 45.00, 'gold', 2500, '#FFD700', 1),
            ('พญาหงส์เพลิงมหาเวทย์', 'S+', 'กรอบรูปประกายแสงสีเหลืองทองคำเปล่งประกายทั่วทิศ', 'hero_phoenix', 55.00, 65.00, 30.00, 'yellow', 1200, '#FACC15', 1),
            ('มังกรฟ้ามหาสมุทร', 'S', 'กรอบรูปประกายแสงสีฟ้าน้ำทะเล ลึกลับทรงพลัง', 'hero_dragon_blue', 30.00, 45.00, 20.00, 'cyan', 600, '#00E5FF', 1),
            ('วานรน้อยนักผจญภัย', 'A+', 'กรอบรูปประกายแสงสีขาวนวลตา ก้าวแรกสู่ยอดฝีมือ', 'hero_monkey', 15.00, 30.00, 12.00, 'white', 300, '#FFFFFF', 1)
        ");
    }
}
ensureFrameColumns($db);

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true) ?? [];
$action = $_GET['action'] ?? ($input['action'] ?? '');

switch ($action) {

    // -------------------------------------------------------------
    // EQUIP ITEM (CHARACTER / PROFILE FRAME / DICE)
    // -------------------------------------------------------------
    case 'equip_item':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $itemType = strtoupper(trim($input['item_type'] ?? 'CHARACTER'));
        $inventoryId = (int)($input['inventory_id'] ?? 0);

        if ($itemType === 'CHARACTER') {
            $invRow = $db->query("SELECT ui.*, c.id as char_id, c.name as char_name, c.grade as char_grade, c.avatar_url, c.win_rate_bonus, c.roll_rate, c.play_skill_rate, COALESCE(c.aura_type, 'none') as aura_type, COALESCE(c.aura_intensity, 100) as aura_intensity, COALESCE(c.frame_fx, 'pulse_breathe') as frame_fx, COALESCE(c.frame_scale, 120) as frame_scale FROM user_inventory ui JOIN characters c ON ui.character_id = c.id WHERE ui.id = {$inventoryId} AND ui.user_id = {$userId}")->fetch_assoc();
            if (!$invRow) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบกรอบรูปตัวละครในคลังของคุณ'], 404);
            }
            $charId = (int)$invRow['char_id'];
            $db->query("UPDATE user_inventory SET is_equipped = 0 WHERE user_id = {$userId} AND item_type = 'CHARACTER'");
            $db->query("UPDATE user_inventory SET is_equipped = 1 WHERE id = {$inventoryId} AND user_id = {$userId}");
            $db->query("UPDATE users SET equipped_character_id = {$charId} WHERE id = {$userId}");

            jsonResponse([
                'status' => 'success',
                'message' => "สวมใส่กรอบรูป '{$invRow['char_name']}' (เกรด {$invRow['char_grade']}) เรียบร้อยแล้ว!",
                'equipped_character' => $invRow
            ]);
        } elseif ($itemType === 'DICE') {
            $invRow = $db->query("SELECT ui.*, d.id as d_id, d.name as dice_name, d.grade FROM user_inventory ui JOIN dice d ON ui.dice_id = d.id WHERE ui.id = {$inventoryId} AND ui.user_id = {$userId}")->fetch_assoc();
            if (!$invRow) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบลูกเต๋าในคลังของคุณ'], 404);
            }
            $diceId = (int)$invRow['d_id'];
            $db->query("UPDATE user_inventory SET is_equipped = 0 WHERE user_id = {$userId} AND item_type = 'DICE'");
            $db->query("UPDATE user_inventory SET is_equipped = 1 WHERE id = {$inventoryId} AND user_id = {$userId}");
            $db->query("UPDATE users SET equipped_dice_id = {$diceId} WHERE id = {$userId}");

            jsonResponse([
                'status' => 'success',
                'message' => "สวมใส่ลูกเต๋า '{$invRow['dice_name']}' เรียบร้อยแล้ว!"
            ]);
        } else {
            jsonResponse(['status' => 'error', 'message' => 'ประเภทไอเทมไม่ถูกต้อง'], 400);
        }
        break;

    // -------------------------------------------------------------
    // DISBAND CLAN (ลบบ้าน / ยุบครอบครัว - สมาชิกต้องเหลือคนเดียวถึงยุบได้)
    // -------------------------------------------------------------
    case 'disband_clan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $uRow = $db->query("SELECT clan_id FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        if (!$clanId) {
            jsonResponse(['status' => 'error', 'message' => 'คุณยังไม่ได้สังกัดบ้านใดๆ'], 400);
        }

        $cRow = $db->query("SELECT leader_id, name FROM clans WHERE id = {$clanId}")->fetch_assoc();
        if (!$cRow || (int)$cRow['leader_id'] !== $userId) {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าบ้านเท่านั้นที่มีสิทธิ์ยุบบ้าน'], 403);
        }

        $memberCount = (int)$db->query("SELECT COUNT(*) as cnt FROM users WHERE clan_id = {$clanId}")->fetch_assoc()['cnt'];
        if ($memberCount > 1) {
            jsonResponse(['status' => 'error', 'message' => "ไม่สามารถยุบบ้านได้เนื่องจากยังมีสมาชิกอื่นอยู่ในบ้าน ({$memberCount} คน) ต้องให้สมาชิกออกจากบ้านจนเหลือเพียงคนเดียวก่อนจึงจะยุบบ้านได้"], 400);
        }

        $db->begin_transaction();
        try {
            $db->query("UPDATE users SET clan_id = NULL, clan_role = 'member' WHERE clan_id = {$clanId}");
            $db->query("DELETE FROM clan_messages WHERE clan_id = {$clanId}");
            $db->query("DELETE FROM clan_requests WHERE clan_id = {$clanId}");
            $db->query("DELETE FROM clans WHERE id = {$clanId}");
            $db->commit();
            jsonResponse(['status' => 'success', 'message' => "ยุบบ้าน '{$cRow['name']}' เรียบร้อยแล้ว"]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Disband failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 1. ร้านค้า: แสดงรายการขาย และการสั่งซื้อด้วยทอง/เพชร
    // -------------------------------------------------------------
    case 'get_catalog':
        $chars = $db->query("SELECT c.id, c.name, c.grade, c.description, c.model_prefab_name, c.win_rate_bonus, c.roll_rate, c.play_skill_rate, c.aura_type, c.aura_intensity, c.frame_fx, c.frame_scale, c.avatar_url, c.price_diamond, c.price_gold, c.color_hex, c.is_available, s.name as skill_name, s.code as skill_code FROM characters c LEFT JOIN skills s ON c.skill_id = s.id WHERE c.is_available = 1")->fetch_all(MYSQLI_ASSOC);
        $dice = $db->query("SELECT d.*, s.name as skill_name FROM dice d LEFT JOIN skills s ON d.skill_id = s.id WHERE d.is_available = 1")->fetch_all(MYSQLI_ASSOC);
        $packages = $db->query("SELECT * FROM topup_packages WHERE is_active = 1 ORDER BY price_thb ASC")->fetch_all(MYSQLI_ASSOC);

        $gachaEvent = $db->query("SELECT * FROM gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$gachaEvent) {
            $gachaEvent = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }

        // Attach target character information + custom AI shadow configs + multi-grade exchange tiers (SS+, S+, S)
        if ($gachaEvent) {
            if (!empty($gachaEvent['target_character_id'])) {
                $tStmt = $db->prepare("SELECT * FROM characters WHERE id = ?");
                $tStmt->bind_param("i", $gachaEvent['target_character_id']);
                $tStmt->execute();
                $gachaEvent['target_character'] = $tStmt->get_result()->fetch_assoc();
                $tStmt->close();
            }

            $shadowConfigs = [];
            if (!empty($gachaEvent['shadow_config_json'])) {
                $decoded = json_decode($gachaEvent['shadow_config_json'], true);
                if (is_array($decoded)) $shadowConfigs = $decoded;
            } elseif (!empty($gachaEvent['target_character']['shadow_config_json'])) {
                $bundle = json_decode($gachaEvent['target_character']['shadow_config_json'], true);
                if (isset($bundle['shadows']) && is_array($bundle['shadows'])) {
                    $shadowConfigs = $bundle['shadows'];
                }
            }
            $gachaEvent['shadow_configs'] = $shadowConfigs;

            $rawTiers = [];
            if (!empty($gachaEvent['exchange_tiers_json'])) {
                $decodedTiers = json_decode($gachaEvent['exchange_tiers_json'], true);
                if (is_array($decodedTiers)) $rawTiers = $decodedTiers;
            } elseif (!empty($gachaEvent['target_character']['shadow_config_json'])) {
                $bundle = json_decode($gachaEvent['target_character']['shadow_config_json'], true);
                if (isset($bundle['tiers']) && is_array($bundle['tiers'])) {
                    $rawTiers = $bundle['tiers'];
                }
            }

            // Build character lookup by id and by grade
            $charsById = [];
            $charsByGrade = [];
            foreach ($chars as $cRow) {
                $cid = (int)$cRow['id'];
                $cGrade = strtoupper(trim($cRow['grade'] ?? 'A'));
                $charsById[$cid] = $cRow;
                if (!isset($charsByGrade[$cGrade])) {
                    $charsByGrade[$cGrade] = $cRow;
                }
            }
            if (!empty($gachaEvent['target_character'])) {
                $tc = $gachaEvent['target_character'];
                unset($tc['shadow_config_json']);
                $gachaEvent['target_character'] = $tc;
                $charsById[(int)$tc['id']] = $tc;
                $charsByGrade[strtoupper(trim($tc['grade'] ?? 'S+'))] = $tc;
            }

            $defaultTiers = [
                'SS+' => [
                    'enabled' => true,
                    'character_id' => isset($charsByGrade['SS+']) ? (int)$charsByGrade['SS+']['id'] : 0,
                    'reqs' => ['black' => 25, 'red' => 25, 'orange' => 20, 'blue' => 15, 'gold' => 8]
                ],
                'S+' => [
                    'enabled' => true,
                    'character_id' => (int)($gachaEvent['target_character_id'] ?? (isset($charsByGrade['S+']) ? $charsByGrade['S+']['id'] : 1)),
                    'reqs' => [
                        'black' => (int)($gachaEvent['req_shadow_black'] ?? 15),
                        'red' => (int)($gachaEvent['req_shadow_red'] ?? 15),
                        'orange' => (int)($gachaEvent['req_shadow_orange'] ?? 15),
                        'blue' => (int)($gachaEvent['req_shadow_blue'] ?? 10),
                        'gold' => (int)($gachaEvent['req_shadow_gold'] ?? 4)
                    ]
                ],
                'S' => [
                    'enabled' => true,
                    'character_id' => isset($charsByGrade['S']) ? (int)$charsByGrade['S']['id'] : 0,
                    'reqs' => ['black' => 10, 'red' => 10, 'orange' => 8, 'blue' => 5, 'gold' => 1]
                ]
            ];

            $resolvedTiers = [];
            foreach (['SS+', 'S+', 'S'] as $tGrade) {
                $tCfg = isset($rawTiers[$tGrade]) && is_array($rawTiers[$tGrade]) ? $rawTiers[$tGrade] : $defaultTiers[$tGrade];
                $enabled = isset($tCfg['enabled']) ? (bool)$tCfg['enabled'] : true;
                $cid = (int)($tCfg['character_id'] ?? 0);
                $charObj = ($cid > 0 && isset($charsById[$cid])) ? $charsById[$cid] : ($charsByGrade[$tGrade] ?? ($gachaEvent['target_character'] ?? null));
                if (!$charObj && $cid > 0) {
                    $qChar = $db->query("SELECT id, name, grade, win_rate_bonus, roll_rate, play_skill_rate, aura_type, aura_intensity, frame_fx, frame_scale, avatar_url, color_hex FROM characters WHERE id = {$cid} LIMIT 1")->fetch_assoc();
                    if ($qChar) $charObj = $qChar;
                }
                $reqs = isset($tCfg['reqs']) && is_array($tCfg['reqs']) ? $tCfg['reqs'] : $defaultTiers[$tGrade]['reqs'];
                $resolvedTiers[$tGrade] = [
                    'grade' => $tGrade,
                    'enabled' => $enabled,
                    'character_id' => $charObj ? (int)$charObj['id'] : $cid,
                    'character' => $charObj,
                    'reqs' => [
                        'black' => max(0, (int)($reqs['black'] ?? 0)),
                        'red' => max(0, (int)($reqs['red'] ?? 0)),
                        'orange' => max(0, (int)($reqs['orange'] ?? 0)),
                        'blue' => max(0, (int)($reqs['blue'] ?? 0)),
                        'gold' => max(0, (int)($reqs['gold'] ?? 0))
                    ]
                ];
            }
            $gachaEvent['exchange_tiers'] = $resolvedTiers;
            unset($gachaEvent['shadow_config_json'], $gachaEvent['exchange_tiers_json']);
        }

        // Fetch active 3D dice gacha campaign event with 5 shadows requirements
        $diceGachaEvent = $db->query("SELECT * FROM dice_gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$diceGachaEvent) {
            $diceGachaEvent = $db->query("SELECT * FROM dice_gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }
        if ($diceGachaEvent && !empty($diceGachaEvent['target_dice_id'])) {
            $tDiceStmt = $db->prepare("SELECT * FROM dice WHERE id = ?");
            $tDiceStmt->bind_param("i", $diceGachaEvent['target_dice_id']);
            $tDiceStmt->execute();
            $diceGachaEvent['target_dice'] = $tDiceStmt->get_result()->fetch_assoc();
            $tDiceStmt->close();
        }

        // Optional user ID for purchase limit counters
        $optUserId = 0;
        $hdrs = function_exists('getallheaders') ? getallheaders() : [];
        $rawAuth = $hdrs['Authorization'] ?? $hdrs['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_GET['token'] ?? ''));
        $tok = strpos((string)$rawAuth, 'Bearer ') === 0 ? substr((string)$rawAuth, 7) : (string)$rawAuth;
        if ($tok !== '' && function_exists('verifyAuthToken')) {
            $optUserId = (int)(verifyAuthToken($tok) ?: 0);
        }
        $shopMenusData = getShopMenusAndItems($db, $optUserId, false);

        // Fetch payment gateway settings (PromptPay & ShopeePay)
        $paymentSettings = [
            'promptpay' => ['id' => '', 'name' => '', 'bank' => ''],
            'shopeepay' => ['id' => '', 'name' => '', 'qr_url' => '', 'is_active' => 1]
        ];
        $settRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('payment_promptpay_id', 'payment_promptpay_name', 'payment_promptpay_bank', 'payment_shopeepay_id', 'payment_shopeepay_name', 'payment_shopeepay_qr_url', 'payment_shopeepay_active')");
        if ($settRes) {
            while ($sRow = $settRes->fetch_assoc()) {
                if ($sRow['setting_key'] === 'payment_promptpay_id') $paymentSettings['promptpay']['id'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_promptpay_name') $paymentSettings['promptpay']['name'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_promptpay_bank') $paymentSettings['promptpay']['bank'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_id') $paymentSettings['shopeepay']['id'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_name') $paymentSettings['shopeepay']['name'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_qr_url') $paymentSettings['shopeepay']['qr_url'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_active') $paymentSettings['shopeepay']['is_active'] = (int)$sRow['setting_value'];
            }
        }

        jsonResponse([
            'status' => 'success',
            'catalog' => [
                'characters' => $chars,
                'dice' => $dice,
                'topup_packages' => $packages,
                'shop_menus' => $shopMenusData['menus'],
                'shop_custom_items' => $shopMenusData['custom_items'],
                'gacha_cost_diamond' => (int)($gachaEvent['cost_diamond'] ?? 100),
                'gacha_cards_per_pack' => (int)($gachaEvent['cards_per_pack'] ?? 5),
                'gacha_event' => $gachaEvent,
                'dice_gacha_event' => $diceGachaEvent,
                'payment_settings' => $paymentSettings
            ]
        ]);
        break;

    case 'buy_shop_custom_item':
        $user = requireAuth($db);
        $shopItemId = (int)($input['shop_item_id'] ?? 0);
        if ($shopItemId <= 0) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสสินค้าที่ต้องการซื้อ'], 400);
        }
        $buyRes = purchaseShopCustomItem($db, (int)$user['id'], $shopItemId);
        $httpCode = isset($buyRes['code']) ? (int)$buyRes['code'] : 200;
        unset($buyRes['code']);
        jsonResponse($buyRes, $httpCode);
        break;

    case 'buy_item':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $itemType = strtoupper($input['item_type'] ?? '');
        $itemId = (int)($input['item_id'] ?? 0);
        $currency = strtoupper($input['currency'] ?? 'GOLD'); // 'GOLD' or 'DIAMOND'

        // Allow buying CHARACTER in Shop when price_diamond > 0 or price_gold > 0

        if (!in_array($itemType, ['CHARACTER', 'DICE']) || !$itemId) {
            jsonResponse(['status' => 'error', 'message' => 'ข้อมูลไอเทมไม่ถูกต้อง'], 400);
        }

        // Fetch item details
        $table = ($itemType === 'CHARACTER') ? 'characters' : 'dice';
        $stmt = $db->prepare("SELECT * FROM {$table} WHERE id = ? AND is_available = 1");
        $stmt->bind_param("i", $itemId);
        $stmt->execute();
        $item = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$item) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบไอเทมในร้านค้า'], 404);
        }

        // Check price
        $price = ($currency === 'DIAMOND') ? (int)$item['price_diamond'] : (int)$item['price_gold'];
        if ($price <= 0) {
            jsonResponse(['status' => 'error', 'message' => 'ไอเทมนี้ไม่เปิดขายด้วยสกุลเงินที่เลือก'], 400);
        }

        // Check if user already owns item
        $col = ($itemType === 'CHARACTER') ? 'character_id' : 'dice_id';
        $checkStmt = $db->prepare("SELECT id FROM user_inventory WHERE user_id = ? AND {$col} = ?");
        $checkStmt->bind_param("ii", $userId, $itemId);
        $checkStmt->execute();
        if ($checkStmt->get_result()->fetch_assoc()) {
            $checkStmt->close();
            jsonResponse(['status' => 'error', 'message' => 'คุณครอบครองไอเทมนี้อยู่แล้ว'], 400);
        }
        $checkStmt->close();

        // Check user balance
        $db->begin_transaction();
        try {
            $uStmt = $db->prepare("SELECT diamond, gold FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $currUser = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();

            if ($currency === 'DIAMOND' && $currUser['diamond'] < $price) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'เพชรของคุณไม่เพียงพอ'], 400);
            } elseif ($currency === 'GOLD' && $currUser['gold'] < $price) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ทองของคุณไม่เพียงพอ'], 400);
            }

            // Deduct balance
            $deductField = ($currency === 'DIAMOND') ? 'diamond' : 'gold';
            $updateU = $db->prepare("UPDATE users SET {$deductField} = {$deductField} - ? WHERE id = ?");
            $updateU->bind_param("ii", $price, $userId);
            $updateU->execute();
            $updateU->close();

            // Insert into inventory
            $invStmt = $db->prepare("INSERT INTO user_inventory (user_id, item_type, {$col}, level, is_equipped) VALUES (?, ?, ?, 1, 0)");
            $invStmt->bind_param("isi", $userId, $itemType, $itemId);
            $invStmt->execute();
            $invStmt->close();

            $uRes = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId}")->fetch_assoc();
            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "ซื้อ {$item['name']} สำเร็จเรียบร้อย!",
                'item' => $item,
                'new_diamond' => (int)($uRes['diamond'] ?? 0),
                'new_gold' => (int)($uRes['gold'] ?? 0),
                'deducted_field' => $deductField,
                'deducted_amount' => $price
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Purchase failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 2. ระบบสุ่มกาชาปองแพ็คการ์ด 5 ใบ (Gacha Pack Pull)
    // 1 แพ็ค = 5 ใบ (ราคา 100 หรือ 200 เพชรตามที่ Admin กำหนด)
    // สุ่มเปิด 5 ใบต่อแพ็ค ได้การ์ดเงาดำ A, เงาแดง A, เงาส้ม A, เงาฟ้า A+, เงาทอง S, การ์ดพิเศษ หรือกรอบ S+ แจ็คพอต
    // -------------------------------------------------------------
    case 'gacha_roll':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        
        // Fetch active gacha event
        $gachaEvent = $db->query("SELECT * FROM gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$gachaEvent) {
            $gachaEvent = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }
        if (!$gachaEvent) {
            jsonResponse(['status' => 'error', 'message' => 'ขณะนี้ไม่มีกิจกรรมสุ่มการ์ดที่เปิดใช้งาน'], 400);
        }

        $packCount = !empty($input['count']) && (int)$input['count'] === 10 ? 10 : 1;
        $costPerPack = (int)($gachaEvent['cost_diamond'] ?? 100);
        $totalCost = $costPerPack * $packCount;
        $cardsPerPack = max(1, (int)($gachaEvent['cards_per_pack'] ?? 5));
        $totalCardsToOpen = $cardsPerPack * $packCount;

        $db->begin_transaction();
        try {
            $uStmt = $db->prepare("SELECT diamond FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $currentDia = (int)$uStmt->get_result()->fetch_assoc()['diamond'];
            $uStmt->close();

            if ($currentDia < $totalCost) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "เพชรไม่พอ ต้องการ {$totalCost} เพชร (คุณมี {$currentDia} เพชร)"], 400);
            }

            // Deduct diamond
            $deduct = $db->prepare("UPDATE users SET diamond = diamond - ? WHERE id = ?");
            $deduct->bind_param("ii", $totalCost, $userId);
            $deduct->execute();
            $deduct->close();

            $results = [];
            for ($i = 0; $i < $totalCardsToOpen; $i++) {
                $rollResult = performSingleGachaCardDrop($db, $userId, $gachaEvent);
                $results[] = $rollResult;
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "เปิดแพ็คสุ่มการ์ดสำเร็จ {$packCount} แพ็ค (เปิดทั้งหมด {$totalCardsToOpen} ใบ)!",
                'pack_count' => $packCount,
                'cards_per_pack' => $cardsPerPack,
                'total_cards' => $totalCardsToOpen,
                'diamonds_spent' => $totalCost,
                'drops' => $results
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Gacha failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 3. แลกกรอบรูป S+ จากการสะสมการ์ดเงาครบ 5 สี (Crafting / Exchange)
    // เงื่อนไขตามที่ Admin กำหนด:
    // - เงาสีดำ A: 15 ใบ (req_shadow_black)
    // - เงาสีแดง A: 15 ใบ (req_shadow_red)
    // - เงาสีส้ม A: 15 ใบ (req_shadow_orange)
    // - เงาสีฟ้า A+: 10 ใบ (req_shadow_blue)
    // - เงาสีทอง S: 4 ใบ (req_shadow_gold)
    // แลกรับกรอบรูปเป้าหมายระดับ S+ ได้ 1 ใบ เพื่อสวมใส่และอัพเลเวลต่อไป!
    // -------------------------------------------------------------
    case 'exchange_splus_card':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        
        $gachaEvent = $db->query("SELECT * FROM gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$gachaEvent) {
            $gachaEvent = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }

        $tierGrade = strtoupper(trim($input['tier_grade'] ?? ''));
        $targetCharacterId = (int)($input['target_character_id'] ?? 0);

        // Required materials based on admin settings (supports SS+, S+, S tiers!)
        $reqBlack = (int)($gachaEvent['req_shadow_black'] ?? 15);
        $reqRed = (int)($gachaEvent['req_shadow_red'] ?? 15);
        $reqOrange = (int)($gachaEvent['req_shadow_orange'] ?? 15);
        $reqBlue = (int)($gachaEvent['req_shadow_blue'] ?? 10);
        $reqGold = (int)($gachaEvent['req_shadow_gold'] ?? 4);

        // Custom shadow display names (if configured in AI Frame Studio)
        $shadowNames = [
            'black' => 'เงาสีดำ A',
            'red' => 'เงาสีแดง A',
            'orange' => 'เงาสีส้ม A',
            'blue' => 'เงาสีฟ้า A+',
            'gold' => 'เงาสีทอง S'
        ];
        if (!empty($gachaEvent['shadow_config_json'])) {
            $sArr = json_decode($gachaEvent['shadow_config_json'], true);
            if (is_array($sArr)) {
                foreach ($sArr as $sObj) {
                    if (!empty($sObj['slot']) && !empty($sObj['name'])) {
                        $shadowNames[$sObj['slot']] = $sObj['name'];
                    }
                }
            }
        }

        $rawTiers = [];
        if (!empty($gachaEvent['exchange_tiers_json'])) {
            $decT = json_decode($gachaEvent['exchange_tiers_json'], true);
            if (is_array($decT)) $rawTiers = $decT;
        }

        if (in_array($tierGrade, ['SS+', 'S+', 'S'], true)) {
            $defaultTierReqs = [
                'SS+' => ['black' => 25, 'red' => 25, 'orange' => 20, 'blue' => 15, 'gold' => 8],
                'S+'  => ['black' => $reqBlack, 'red' => $reqRed, 'orange' => $reqOrange, 'blue' => $reqBlue, 'gold' => $reqGold],
                'S'   => ['black' => 10, 'red' => 10, 'orange' => 8, 'blue' => 5, 'gold' => 1]
            ];
            $tCfg = isset($rawTiers[$tierGrade]) && is_array($rawTiers[$tierGrade]) ? $rawTiers[$tierGrade] : ['enabled' => true, 'character_id' => 0, 'reqs' => $defaultTierReqs[$tierGrade]];
            if (isset($tCfg['enabled']) && !$tCfg['enabled']) {
                jsonResponse(['status' => 'error', 'message' => "การแลกกรอบระดับ {$tierGrade} ปิดใช้งานอยู่ในขณะนี้"], 400);
            }
            $tReqs = isset($tCfg['reqs']) && is_array($tCfg['reqs']) ? $tCfg['reqs'] : $defaultTierReqs[$tierGrade];
            $reqBlack = max(0, (int)($tReqs['black'] ?? 0));
            $reqRed = max(0, (int)($tReqs['red'] ?? 0));
            $reqOrange = max(0, (int)($tReqs['orange'] ?? 0));
            $reqBlue = max(0, (int)($tReqs['blue'] ?? 0));
            $reqGold = max(0, (int)($tReqs['gold'] ?? 0));

            if ($targetCharacterId <= 0 && !empty($tCfg['character_id'])) {
                $targetCharacterId = (int)$tCfg['character_id'];
            }
            if ($targetCharacterId <= 0) {
                $gStmt = $db->prepare("SELECT id FROM characters WHERE grade = ? AND is_available = 1 ORDER BY id DESC LIMIT 1");
                $gStmt->bind_param("s", $tierGrade);
                $gStmt->execute();
                $gRow = $gStmt->get_result()->fetch_assoc();
                $gStmt->close();
                if ($gRow) $targetCharacterId = (int)$gRow['id'];
            }
        }

        if ($targetCharacterId <= 0) {
            $targetCharacterId = (int)($gachaEvent['target_character_id'] ?? 1);
        }

        $db->begin_transaction();
        try {
            // Check materials
            $stmt = $db->prepare("SELECT material_code, quantity FROM user_materials WHERE user_id = ? FOR UPDATE");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $matRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $materials = [];
            foreach ($matRows as $row) {
                $materials[$row['material_code']] = (int)$row['quantity'];
            }

            // Consolidate legacy codes
            $haveBlack = $materials['SHADOW_BLACK_A'] ?? 0;
            $haveRed = $materials['SHADOW_RED_A'] ?? 0;
            $haveOrange = $materials['SHADOW_ORANGE_A'] ?? 0;
            $haveBlue = ($materials['SHADOW_BLUE_APLUS'] ?? 0) + ($materials['SHADOW_BLUE_A'] ?? 0);
            $haveGold = ($materials['SHADOW_GOLD_S'] ?? 0) + ($materials['SHADOW_GOLD_APLUS'] ?? 0);

            $missing = [];
            if ($reqBlack > 0 && $haveBlack < $reqBlack) $missing[] = "{$shadowNames['black']} (มี {$haveBlack}/{$reqBlack})";
            if ($reqRed > 0 && $haveRed < $reqRed) $missing[] = "{$shadowNames['red']} (มี {$haveRed}/{$reqRed})";
            if ($reqOrange > 0 && $haveOrange < $reqOrange) $missing[] = "{$shadowNames['orange']} (มี {$haveOrange}/{$reqOrange})";
            if ($reqBlue > 0 && $haveBlue < $reqBlue) $missing[] = "{$shadowNames['blue']} (มี {$haveBlue}/{$reqBlue})";
            if ($reqGold > 0 && $haveGold < $reqGold) $missing[] = "{$shadowNames['gold']} (มี {$haveGold}/{$reqGold})";

            if (!empty($missing)) {
                $db->rollback();
                jsonResponse([
                    'status' => 'error',
                    'message' => 'วัตถุดิบการ์ดเงายังไม่ครบตามที่กำหนด: ' . implode(', ', $missing)
                ], 400);
            }

            // Deduct materials
            $deductMat = $db->prepare("UPDATE user_materials SET quantity = quantity - ? WHERE user_id = ? AND material_code = ?");
            if ($reqBlack > 0) {
                $c = 'SHADOW_BLACK_A';
                $deductMat->bind_param("iis", $reqBlack, $userId, $c);
                $deductMat->execute();
            }
            if ($reqRed > 0) {
                $c = 'SHADOW_RED_A';
                $deductMat->bind_param("iis", $reqRed, $userId, $c);
                $deductMat->execute();
            }
            if ($reqOrange > 0) {
                $c = 'SHADOW_ORANGE_A';
                $deductMat->bind_param("iis", $reqOrange, $userId, $c);
                $deductMat->execute();
            }
            if ($reqBlue > 0) {
                $leftBlue = $reqBlue;
                $qAplus = $materials['SHADOW_BLUE_APLUS'] ?? 0;
                if ($qAplus > 0) {
                    $take = min($qAplus, $leftBlue);
                    $c = 'SHADOW_BLUE_APLUS';
                    $deductMat->bind_param("iis", $take, $userId, $c);
                    $deductMat->execute();
                    $leftBlue -= $take;
                }
                if ($leftBlue > 0) {
                    $c = 'SHADOW_BLUE_A';
                    $deductMat->bind_param("iis", $leftBlue, $userId, $c);
                    $deductMat->execute();
                }
            }
            if ($reqGold > 0) {
                $leftGold = $reqGold;
                $qGoldS = $materials['SHADOW_GOLD_S'] ?? 0;
                if ($qGoldS > 0) {
                    $take = min($qGoldS, $leftGold);
                    $c = 'SHADOW_GOLD_S';
                    $deductMat->bind_param("iis", $take, $userId, $c);
                    $deductMat->execute();
                    $leftGold -= $take;
                }
                if ($leftGold > 0) {
                    $c = 'SHADOW_GOLD_APLUS';
                    $deductMat->bind_param("iis", $leftGold, $userId, $c);
                    $deductMat->execute();
                }
            }
            $deductMat->close();

            // Grant Target Frame character (SS+ / S+ / S)
            $charStmt = $db->prepare("SELECT * FROM characters WHERE id = ?");
            $charStmt->bind_param("i", $targetCharacterId);
            $charStmt->execute();
            $charData = $charStmt->get_result()->fetch_assoc();
            $charStmt->close();

            if (!$charData) {
                $charData = $db->query("SELECT * FROM characters WHERE grade IN ('SS+','S+','S') ORDER BY id DESC LIMIT 1")->fetch_assoc();
                $targetCharacterId = (int)$charData['id'];
            }
            unset($charData['shadow_config_json']);

            // Check if already in user_inventory
            $checkInv = $db->prepare("SELECT id FROM user_inventory WHERE user_id = ? AND character_id = ?");
            $checkInv->bind_param("ii", $userId, $targetCharacterId);
            $checkInv->execute();
            $exists = $checkInv->get_result()->fetch_assoc();
            $checkInv->close();

            if (!$exists) {
                $addInv = $db->prepare("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES (?, 'CHARACTER', ?, 1, 0)");
                $addInv->bind_param("ii", $userId, $targetCharacterId);
                $addInv->execute();
                $addInv->close();
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "🎉 ยินดีด้วย! คุณแลกรับกรอบรูป '{$charData['name']}' ระดับ {$charData['grade']} สำเร็จ 1 ใบ! สามารถนำไปสวมใส่และอัปเลเวล 1-30 ได้ทันที",
                'reward_character' => $charData
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Exchange failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 3.1 แลกรับลูกเต๋า 3D จากการสะสมการ์ดเงาครบ 5 สี (A ถึง S)
    // เงื่อนไขตามที่ Admin กำหนดใน dice_gacha_events:
    // - เงาสีดำ A: req_shadow_black ใบ
    // - เงาสีแดง A: req_shadow_red ใบ
    // - เงาสีส้ม A: req_shadow_orange ใบ
    // - เงาสีฟ้า A+: req_shadow_blue ใบ
    // - เงาสีทอง S: req_shadow_gold ใบ
    // -------------------------------------------------------------
    case 'exchange_dice_from_shadows':
    case 'exchange_dice_card':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $diceEvent = $db->query("SELECT * FROM dice_gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$diceEvent) {
            $diceEvent = $db->query("SELECT * FROM dice_gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }
        if (!$diceEvent) {
            jsonResponse(['status' => 'error', 'message' => 'ขณะนี้ไม่มีกิจกรรมแลกลูกเต๋าจากเงาที่เปิดใช้งาน'], 400);
        }

        $targetDiceId = (int)($input['target_dice_id'] ?? ($diceEvent['target_dice_id'] ?? 1));
        $diceRow = $db->query("SELECT * FROM dice WHERE id = {$targetDiceId}")->fetch_assoc();
        if (!$diceRow) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลลูกเต๋าเป้าหมาย'], 404);
        }

        $reqBlack = max(0, (int)($diceEvent['req_shadow_black'] ?? 15));
        $reqRed = max(0, (int)($diceEvent['req_shadow_red'] ?? 15));
        $reqOrange = max(0, (int)($diceEvent['req_shadow_orange'] ?? 15));
        $reqBlue = max(0, (int)($diceEvent['req_shadow_blue'] ?? 10));
        $reqGold = max(0, (int)($diceEvent['req_shadow_gold'] ?? 4));

        $db->begin_transaction();
        try {
            $stmt = $db->prepare("SELECT material_code, quantity FROM user_materials WHERE user_id = ? FOR UPDATE");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $matRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $materials = [];
            foreach ($matRows as $row) {
                $materials[$row['material_code']] = (int)$row['quantity'];
            }

            $haveBlack = $materials['SHADOW_BLACK_A'] ?? 0;
            $haveRed = $materials['SHADOW_RED_A'] ?? 0;
            $haveOrange = $materials['SHADOW_ORANGE_A'] ?? 0;
            $haveBlue = ($materials['SHADOW_BLUE_APLUS'] ?? 0) + ($materials['SHADOW_BLUE_A'] ?? 0);
            $haveGold = ($materials['SHADOW_GOLD_S'] ?? 0) + ($materials['SHADOW_GOLD_APLUS'] ?? 0);

            $missing = [];
            if ($reqBlack > 0 && $haveBlack < $reqBlack) $missing[] = "เงาสีดำ A (มี {$haveBlack}/{$reqBlack})";
            if ($reqRed > 0 && $haveRed < $reqRed) $missing[] = "เงาสีแดง A (มี {$haveRed}/{$reqRed})";
            if ($reqOrange > 0 && $haveOrange < $reqOrange) $missing[] = "เงาสีส้ม A (มี {$haveOrange}/{$reqOrange})";
            if ($reqBlue > 0 && $haveBlue < $reqBlue) $missing[] = "เงาสีฟ้า A+ (มี {$haveBlue}/{$reqBlue})";
            if ($reqGold > 0 && $haveGold < $reqGold) $missing[] = "เงาสีทอง S (มี {$haveGold}/{$reqGold})";

            if (!empty($missing)) {
                $db->rollback();
                jsonResponse([
                    'status' => 'error',
                    'message' => 'วัตถุดิบการ์ดเงายังไม่ครบตามที่กำหนดเพื่อแลกลูกเต๋า: ' . implode(', ', $missing)
                ], 400);
            }

            // Deduct materials
            $deductMat = $db->prepare("UPDATE user_materials SET quantity = quantity - ? WHERE user_id = ? AND material_code = ?");
            if ($reqBlack > 0) {
                $c = 'SHADOW_BLACK_A';
                $deductMat->bind_param("iis", $reqBlack, $userId, $c);
                $deductMat->execute();
            }
            if ($reqRed > 0) {
                $c = 'SHADOW_RED_A';
                $deductMat->bind_param("iis", $reqRed, $userId, $c);
                $deductMat->execute();
            }
            if ($reqOrange > 0) {
                $c = 'SHADOW_ORANGE_A';
                $deductMat->bind_param("iis", $reqOrange, $userId, $c);
                $deductMat->execute();
            }
            if ($reqBlue > 0) {
                $remBlue = $reqBlue;
                $curBlueAPlus = $materials['SHADOW_BLUE_APLUS'] ?? 0;
                $useBlueAPlus = min($curBlueAPlus, $remBlue);
                if ($useBlueAPlus > 0) {
                    $c = 'SHADOW_BLUE_APLUS';
                    $deductMat->bind_param("iis", $useBlueAPlus, $userId, $c);
                    $deductMat->execute();
                    $remBlue -= $useBlueAPlus;
                }
                if ($remBlue > 0) {
                    $c = 'SHADOW_BLUE_A';
                    $deductMat->bind_param("iis", $remBlue, $userId, $c);
                    $deductMat->execute();
                }
            }
            if ($reqGold > 0) {
                $remGold = $reqGold;
                $curGoldS = $materials['SHADOW_GOLD_S'] ?? 0;
                $useGoldS = min($curGoldS, $remGold);
                if ($useGoldS > 0) {
                    $c = 'SHADOW_GOLD_S';
                    $deductMat->bind_param("iis", $useGoldS, $userId, $c);
                    $deductMat->execute();
                    $remGold -= $useGoldS;
                }
                if ($remGold > 0) {
                    $c = 'SHADOW_GOLD_APLUS';
                    $deductMat->bind_param("iis", $remGold, $userId, $c);
                    $deductMat->execute();
                }
            }
            $deductMat->close();

            // Clean up 0 quantity materials
            $db->query("DELETE FROM user_materials WHERE user_id = {$userId} AND quantity <= 0");

            // Grant Dice to user
            $hasDice = $db->query("SELECT id FROM user_dice WHERE user_id = {$userId} AND dice_id = {$targetDiceId}")->fetch_assoc();
            if (!$hasDice) {
                $insD = $db->prepare("INSERT INTO user_dice (user_id, dice_id, is_equipped) VALUES (?, ?, 1)");
                $insD->bind_param("ii", $userId, $targetDiceId);
                $insD->execute();
                $insD->close();
                // Unequip others and equip this dice
                $db->query("UPDATE user_dice SET is_equipped = 0 WHERE user_id = {$userId} AND dice_id != {$targetDiceId}");
                $db->query("UPDATE users SET dice_id = {$targetDiceId} WHERE id = {$userId}");
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "🎉 ยินดีด้วย! คุณสะสมเงา A ถึง S ครบทั้ง 5 เงา แลกรับลูกเต๋า '{$diceRow['name']}' [{$diceRow['grade']}] สำเร็จเรียบร้อย!",
                'reward_dice' => $diceRow
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Dice exchange failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 4. ระบบอัปเลเวลการ์ด (Card Upgrade 1-30 & Awakening)
    // เวล 1-10: 100 เพชร/เวล
    // เวล 11-20: 150 เพชร/เวล
    // เวล 21-29: 200 เพชร/เวล
    // เวล 30 (Awaken): การ์ดพิเศษ 1 ใบ + 500 เพชร -> ปลดล็อกสกิลพิเศษ + ออร่าสีทองวับวาว
    // -------------------------------------------------------------
    case 'upgrade_card':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $invId = (int)($input['inventory_id'] ?? 0);

        if (!$invId) {
            jsonResponse(['status' => 'error', 'message' => 'Missing inventory ID'], 400);
        }

        $db->begin_transaction();
        try {
            $stmt = $db->prepare("
                SELECT ui.*, c.name as char_name, c.grade as char_grade, c.skill_id
                FROM user_inventory ui
                LEFT JOIN characters c ON ui.character_id = c.id
                WHERE ui.id = ? AND ui.user_id = ? FOR UPDATE
            ");
            $stmt->bind_param("ii", $invId, $userId);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$item) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบไอเทมในกระเป๋าของคุณ'], 404);
            }

            $currentLevel = (int)$item['level'];
            if ($currentLevel >= 30) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'การ์ดนี้เลเวลสูงสุด (Level 30 MAX Awakening) แล้ว'], 400);
            }

            $nextLevel = $currentLevel + 1;
            $requiredDiamonds = 100;
            $needSpecialCard = false;

            if ($nextLevel >= 1 && $nextLevel <= 10) {
                $requiredDiamonds = 100;
            } elseif ($nextLevel >= 11 && $nextLevel <= 20) {
                $requiredDiamonds = 150;
            } elseif ($nextLevel >= 21 && $nextLevel <= 29) {
                $requiredDiamonds = 200;
            } elseif ($nextLevel === 30) {
                $requiredDiamonds = 500;
                $needSpecialCard = true;
            }

            // Check diamonds
            $uStmt = $db->prepare("SELECT diamond FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $userDia = (int)$uStmt->get_result()->fetch_assoc()['diamond'];
            $uStmt->close();

            if ($userDia < $requiredDiamonds) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "เพชรไม่พอ ต้องการ {$requiredDiamonds} เพชร (คุณมี {$userDia} เพชร)"], 400);
            }

            // If level 30, check Special Card
            if ($needSpecialCard) {
                $matStmt = $db->prepare("SELECT quantity FROM user_materials WHERE user_id = ? AND material_code = 'SPECIAL_CARD' FOR UPDATE");
                $matStmt->bind_param("i", $userId);
                $matStmt->execute();
                $specialCardQty = (int)($matStmt->get_result()->fetch_assoc()['quantity'] ?? 0);
                $matStmt->close();

                if ($specialCardQty < 1) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ต้องใช้ "การ์ดพิเศษ (Special Card)" 1 ใบในการปลุกพลัง Level 30 (หาได้จากกาชาปอง)'], 400);
                }

                // Deduct special card
                $deductMat = $db->prepare("UPDATE user_materials SET quantity = quantity - 1 WHERE user_id = ? AND material_code = 'SPECIAL_CARD'");
                $deductMat->bind_param("i", $userId);
                $deductMat->execute();
                $deductMat->close();
            }

            // Deduct diamonds
            $deductD = $db->prepare("UPDATE users SET diamond = diamond - ? WHERE id = ?");
            $deductD->bind_param("ii", $requiredDiamonds, $userId);
            $deductD->execute();
            $deductD->close();

            // Update inventory
            $isAwakened = ($nextLevel === 30) ? 1 : (int)$item['is_awakened'];
            $unlockedSkillId = ($nextLevel === 30) ? 3 : $item['unlocked_skill_id']; // Skill 3 = ดึงถอยหลัง 8 ช่อง

            $updInv = $db->prepare("UPDATE user_inventory SET level = ?, is_awakened = ?, unlocked_skill_id = ? WHERE id = ?");
            $updInv->bind_param("iiii", $nextLevel, $isAwakened, $unlockedSkillId, $invId);
            $updInv->execute();
            $updInv->close();

            $db->commit();

            $msg = ($nextLevel === 30) 
                ? "✨ ปลุกพลังสำเร็จ! การ์ดเลเวล 30 MAX เปิดใช้งานสกิลมหาเวทย์ดึงถอยหลัง 8 ช่อง พร้อมออร่าสีทองวับวาวประกายระยิบระยับ!"
                : "อัปเกรดการ์ดสำเร็จเป็นเลเวล {$nextLevel}!";

            jsonResponse([
                'status' => 'success',
                'message' => $msg,
                'new_level' => $nextLevel,
                'is_awakened' => (bool)$isAwakened,
                'aura_effect' => ($isAwakened ? 'gold_sparkle_3d' : 'normal'),
                'diamonds_spent' => $requiredDiamonds
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Upgrade failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 5. คลังเก็บของและข้อมูลการ์ดของผู้เล่น (Inventory & Materials)
    // -------------------------------------------------------------
    case 'get_inventory':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        // Characters & Dice
        $stmt = $db->prepare("
            SELECT ui.*, 
                   c.name as char_name, c.grade as char_grade, c.model_prefab_name, c.color_hex as char_color, c.avatar_url,
                   COALESCE(c.win_rate_bonus, 5.00) as win_rate_bonus,
                   COALESCE(c.roll_rate, 20.00) as roll_rate,
                   COALESCE(c.play_skill_rate, 10.00) as play_skill_rate,
                   COALESCE(c.aura_type, 'none') as aura_type,
                   COALESCE(c.aura_intensity, 100) as aura_intensity,
                   COALESCE(c.frame_fx, 'pulse_breathe') as frame_fx,
                   COALESCE(c.frame_scale, 120) as frame_scale,
                   d.name as dice_name, d.grade as dice_grade, d.dice_control_rate,
                   COALESCE(d.color_hex, '#1e1b4b') as dice_color,
                   COALESCE(d.pip_color_hex, '#ffffff') as pip_color_hex,
                   COALESCE(d.aura_type, 'none') as dice_aura_type,
                   COALESCE(d.aura_intensity, 100) as dice_aura_intensity,
                   COALESCE(d.aura_fx, 'pulse_breathe') as dice_aura_fx,
                   s.name as skill_name, s.code as skill_code, s.base_power_value, s.trigger_chance_percent
            FROM user_inventory ui
            LEFT JOIN characters c ON ui.character_id = c.id
            LEFT JOIN dice d ON ui.dice_id = d.id
            LEFT JOIN skills s ON COALESCE(ui.unlocked_skill_id, c.skill_id, d.skill_id) = s.id
            WHERE ui.user_id = ?
            ORDER BY ui.level DESC, ui.id DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $inventory = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Shadow materials
        $stmt = $db->prepare("SELECT material_code, quantity FROM user_materials WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $mats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $materialsMap = [
            'SHADOW_BLACK_A' => 0,
            'SHADOW_RED_A' => 0,
            'SHADOW_ORANGE_A' => 0,
            'SHADOW_BLUE_APLUS' => 0,
            'SHADOW_BLUE_A' => 0,
            'SHADOW_GOLD_S' => 0,
            'SHADOW_GOLD_APLUS' => 0,
            'SPECIAL_CARD' => 0
        ];
        foreach ($mats as $m) {
            $materialsMap[$m['material_code']] = (int)$m['quantity'];
        }

        jsonResponse([
            'status' => 'success',
            'inventory' => $inventory,
            'materials' => $materialsMap
        ]);
        break;

    // -------------------------------------------------------------
    // 6. กล่องจดหมายรับของรางวัล (Mailbox)
    // -------------------------------------------------------------
    case 'get_mailbox':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $stmt = $db->prepare("SELECT * FROM mailbox WHERE user_id = ? ORDER BY is_claimed ASC, id DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $mails = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        jsonResponse([
            'status' => 'success',
            'mailbox' => $mails
        ]);
        break;

    case 'claim_mail':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $mailId = (int)($input['mail_id'] ?? 0);
        $claimAll = !empty($input['claim_all']);

        $db->begin_transaction();
        try {
            if ($claimAll) {
                $stmt = $db->prepare("SELECT id, reward_diamond, reward_gold FROM mailbox WHERE user_id = ? AND is_claimed = 0 FOR UPDATE");
                $stmt->bind_param("i", $userId);
            } else {
                $stmt = $db->prepare("SELECT id, reward_diamond, reward_gold FROM mailbox WHERE id = ? AND user_id = ? AND is_claimed = 0 FOR UPDATE");
                $stmt->bind_param("ii", $mailId, $userId);
            }
            $stmt->execute();
            $claimableMails = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            if (empty($claimableMails)) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ไม่มีของรางวัลให้กดรับ'], 400);
            }

            $totalDia = 0;
            $totalGold = 0;
            $mailIds = [];

            foreach ($claimableMails as $m) {
                $totalDia += (int)$m['reward_diamond'];
                $totalGold += (int)$m['reward_gold'];
                $mailIds[] = (int)$m['id'];
            }

            // Update user balance
            $updUser = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
            $updUser->bind_param("iii", $totalDia, $totalGold, $userId);
            $updUser->execute();
            $updUser->close();

            // Mark mails as claimed
            $inIds = implode(',', $mailIds);
            $db->query("UPDATE mailbox SET is_claimed = 1 WHERE id IN ({$inIds})");

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "กดรับรางวัลสำเร็จ! ได้รับ {$totalDia} เพชร และ " . number_format((int)$totalGold) . " ทอง",
                'claimed_diamond' => $totalDia,
                'claimed_gold' => $totalGold
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Claim mail failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 7. ข้อความกิจกรรม & รับรางวัลโปรโมชั่นโค้ด (Event Announcements)
    // -------------------------------------------------------------
    case 'get_events':
        $res = $db->query("SELECT id, title, description, reward_diamond, reward_gold, promo_code, start_time, end_time FROM events WHERE is_active = 1 AND NOW() BETWEEN start_time AND end_time ORDER BY id DESC");
        $events = $res->fetch_all(MYSQLI_ASSOC);

        jsonResponse([
            'status' => 'success',
            'events' => $events
        ]);
        break;

    case 'redeem_code':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $code = strtoupper(trim($input['promo_code'] ?? ''));

        if (empty($code)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกรหัสโค้ดกิจกรรม'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM events WHERE promo_code = ? AND is_active = 1 AND NOW() BETWEEN start_time AND end_time LIMIT 1");
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $event = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$event) {
            jsonResponse(['status' => 'error', 'message' => 'รหัสโค้ดไม่ถูกต้องหรือหมดอายุแล้ว'], 404);
        }

        $eventId = (int)$event['id'];

        // Check if already claimed
        $check = $db->prepare("SELECT id FROM user_event_claims WHERE event_id = ? AND user_id = ?");
        $check->bind_param("ii", $eventId, $userId);
        $check->execute();
        if ($check->get_result()->fetch_assoc()) {
            $check->close();
            jsonResponse(['status' => 'error', 'message' => 'คุณเคยรับรางวัลจากโค้ดนี้ไปแล้ว'], 400);
        }
        $check->close();

        $dia = (int)$event['reward_diamond'];
        $gold = (int)$event['reward_gold'];

        $db->begin_transaction();
        try {
            $claim = $db->prepare("INSERT INTO user_event_claims (event_id, user_id, claimed_diamond, claimed_gold) VALUES (?, ?, ?, ?)");
            $claim->bind_param("iiii", $eventId, $userId, $dia, $gold);
            $claim->execute();
            $claim->close();

            $upd = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
            $upd->bind_param("iii", $dia, $gold, $userId);
            $upd->execute();
            $upd->close();

            $db->query("UPDATE events SET current_claims_count = current_claims_count + 1 WHERE id = {$eventId}");

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => "แลกโค้ดสำเร็จ! ได้รับ {$dia} เพชร และ " . number_format((int)$gold) . " ทอง",
                'reward' => ['diamond' => $dia, 'gold' => $gold]
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Redeem failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 8. ซื้อแพ็กเกจเพชร/ทอง (จำลองระบบเติมเงิน เช่น 500 เพชร 30 บาท)
    // -------------------------------------------------------------
    case 'topup_purchase':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $packageId = (int)($input['package_id'] ?? 0);

        $stmt = $db->prepare("SELECT * FROM topup_packages WHERE id = ? AND is_active = 1");
        $stmt->bind_param("i", $packageId);
        $stmt->execute();
        $pkg = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$pkg) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบแพ็กเกจเติมเงิน'], 404);
        }

        $dia = (int)$pkg['reward_diamond'];
        $gold = (int)$pkg['reward_gold'];

        $upd = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
        $upd->bind_param("iii", $dia, $gold, $userId);
        $upd->execute();
        $upd->close();

        // Send confirmation receipt to mail
        $mTitle = "ใบเสร็จเติมเงินสำเร็จ: {$pkg['name']}";
        $mMsg = "คุณได้ชำระเงิน {$pkg['price_thb']} บาท และได้รับเพชร {$dia} เม็ด พร้อมทอง " . number_format((int)$gold) . " ทองเข้าบัญชีเรียบร้อยแล้ว";
        $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
        $m->bind_param("iss", $userId, $mTitle, $mMsg);
        $m->execute();
        $m->close();

        $uRes = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId}")->fetch_assoc();

        jsonResponse([
            'status' => 'success',
            'message' => "เติมเงินสำเร็จ! ได้รับ {$dia} เพชร และ " . number_format((int)$gold) . " ทอง",
            'added_diamond' => $dia,
            'added_gold' => $gold,
            'new_diamond' => (int)($uRes['diamond'] ?? 0),
            'new_gold' => (int)($uRes['gold'] ?? 0),
            'package_name' => $pkg['name']
        ]);
        break;

    // -------------------------------------------------------------
    // 8.1 สร้างใบสั่งซื้อ PromptPay QR Code (Countdown 60s)
    // -------------------------------------------------------------
    case 'create_payment_order':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $packageId = (int)($input['package_id'] ?? 0);
        $method = trim((string)($input['payment_method'] ?? 'promptpay'));

        $stmt = $db->prepare("SELECT * FROM topup_packages WHERE id = ? AND is_active = 1");
        $stmt->bind_param("i", $packageId);
        $stmt->execute();
        $pkg = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$pkg) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบแพ็กเกจเติมเงิน'], 404);
        }

        $orderNo = 'ORD-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $amount = (float)$pkg['price_thb'];
        $dia = (int)$pkg['reward_diamond'];
        $gold = (int)$pkg['reward_gold'];
        $name = (string)$pkg['name'];
        $expiresIn = 180; // 180 seconds (3 minutes) countdown
        $expiredAt = date('Y-m-d H:i:s', time() + $expiresIn);

        $ins = $db->prepare("INSERT INTO payment_orders (order_no, user_id, package_id, item_type, item_name, amount_thb, reward_diamond, reward_gold, payment_method, status, is_fulfilled, expired_at) VALUES (?, ?, ?, 'TOPUP', ?, ?, ?, ?, ?, 'pending', 0, ?)");
        $ins->bind_param("siisdiiss", $orderNo, $userId, $packageId, $name, $amount, $dia, $gold, $method, $expiredAt);
        $ins->execute();
        $orderId = $ins->insert_id;
        $ins->close();

        // Also record in orders table for unified dashboard tracking
        $uname = (string)($user['username'] ?? ('User #' . $userId));
        $pkgIdStr = (string)$packageId;
        $zeroBonus = 0;
        $ordStmt = $db->prepare("INSERT INTO `orders` (`order_no`, `user_id`, `username`, `package_id`, `package_name`, `amount_thb`, `diamond_amount`, `bonus_diamonds`, `payment_method`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING') ON DUPLICATE KEY UPDATE `status` = 'PENDING'");
        if ($ordStmt) {
            $ordStmt->bind_param("sisssdiis", $orderNo, $userId, $uname, $pkgIdStr, $name, $amount, $dia, $zeroBonus, $method);
            $ordStmt->execute();
            $ordStmt->close();
        }

        // Fetch payment settings
        $shopeeSettings = ['id' => '', 'name' => '', 'qr_url' => ''];
        $ppSettings = ['id' => '', 'name' => '', 'bank' => ''];
        $settRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('payment_promptpay_id', 'payment_promptpay_name', 'payment_promptpay_bank', 'payment_shopeepay_id', 'payment_shopeepay_name', 'payment_shopeepay_qr_url')");
        if ($settRes) {
            while ($sRow = $settRes->fetch_assoc()) {
                if ($sRow['setting_key'] === 'payment_promptpay_id') $ppSettings['id'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_promptpay_name') $ppSettings['name'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_promptpay_bank') $ppSettings['bank'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_id') $shopeeSettings['id'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_name') $shopeeSettings['name'] = $sRow['setting_value'];
                if ($sRow['setting_key'] === 'payment_shopeepay_qr_url') $shopeeSettings['qr_url'] = $sRow['setting_value'];
            }
        }

        jsonResponse([
            'status' => 'success',
            'order_id' => $orderId,
            'order_no' => $orderNo,
            'item_name' => $name,
            'amount_thb' => $amount,
            'reward_diamond' => $dia,
            'reward_gold' => $gold,
            'payment_method' => $method,
            'expires_in' => $expiresIn,
            'expired_at' => $expiredAt,
            'promptpay_qr_ref' => $orderNo,
            'shopeepay_id' => $shopeeSettings['id'],
            'shopeepay_name' => $shopeeSettings['name'],
            'shopeepay_qr_url' => $shopeeSettings['qr_url'],
            'promptpay_id' => $ppSettings['id'],
            'promptpay_name' => $ppSettings['name']
        ]);
        break;


    // -------------------------------------------------------------
    // 9. กำหนดราคาขายไอเทมแลกเป็นเพชร หรือ ทอง (Configurable Item Sell Prices & Currency)
    // -------------------------------------------------------------
    case 'get_sell_prices':
        $sellCatalog = buildSellPriceCatalog($db);
        jsonResponse([
            'status' => 'success',
            'prices' => $sellCatalog['prices'],
            'currencies' => $sellCatalog['currencies'],
            'items' => $sellCatalog['items']
        ]);
        break;

    case 'sell_item':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $itemType = strtoupper(trim($input['item_type'] ?? '')); // 'CHARACTER', 'DICE', 'MATERIAL'
        $invId = (int)($input['inventory_id'] ?? 0);
        $matCode = strtoupper(trim($input['material_code'] ?? ''));
        $quantity = max(1, (int)($input['quantity'] ?? 1));

        $sellCatalog = buildSellPriceCatalog($db);
        $itemsCfg = $sellCatalog['items'];

        $earnedAmount = 0;
        $sellCurrency = 'DIAMOND';
        $itemName = '';

        $db->begin_transaction();
        try {
            if ($itemType === 'CHARACTER') {
                $stmt = $db->prepare("
                    SELECT ui.*, c.name as char_name, c.grade
                    FROM user_inventory ui
                    JOIN characters c ON ui.character_id = c.id
                    WHERE ui.id = ? AND ui.user_id = ? AND ui.item_type = 'CHARACTER'
                    FOR UPDATE
                ");
                $stmt->bind_param("ii", $invId, $userId);
                $stmt->execute();
                $item = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$item) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ไม่พบกรอบรูปตัวละครนี้ในคลังของคุณ'], 404);
                }
                if ($item['is_equipped']) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถขายกรอบรูปที่กำลังสวมใส่อยู่ได้ กรุณาเปลี่ยนกรอบรูปก่อน'], 400);
                }

                $grade = strtoupper($item['grade'] ?? 'A');
                $codeKey = 'CHAR_' . str_replace('+', 'PLUS', $grade);
                $cfg = $itemsCfg[$codeKey] ?? ['amount' => 100, 'currency' => 'DIAMOND'];
                $earnedAmount = (int)$cfg['amount'];
                $sellCurrency = $cfg['currency'];
                $itemName = "กรอบรูป {$item['char_name']} (เกรด {$grade})";

                $del = $db->prepare("DELETE FROM user_inventory WHERE id = ?");
                $del->bind_param("i", $invId);
                $del->execute();
                $del->close();

            } elseif ($itemType === 'DICE') {
                $stmt = $db->prepare("
                    SELECT ui.*, d.name as dice_name, d.grade
                    FROM user_inventory ui
                    JOIN dice d ON ui.dice_id = d.id
                    WHERE ui.id = ? AND ui.user_id = ? AND ui.item_type = 'DICE'
                    FOR UPDATE
                ");
                $stmt->bind_param("ii", $invId, $userId);
                $stmt->execute();
                $item = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$item) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ไม่พบลูกเต๋านี้ในคลังของคุณ'], 404);
                }
                if ($item['is_equipped']) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถขายลูกเต๋าที่กำลังสวมใส่อยู่ได้'], 400);
                }

                $grade = strtoupper($item['grade'] ?? 'NORMAL');
                $codeKey = 'DICE_' . str_replace('+', 'PLUS', $grade);
                $cfg = $itemsCfg[$codeKey] ?? ['amount' => 30, 'currency' => 'DIAMOND'];
                $earnedAmount = (int)$cfg['amount'];
                $sellCurrency = $cfg['currency'];
                $itemName = "ลูกเต๋า {$item['dice_name']} (ระดับ {$grade})";

                $del = $db->prepare("DELETE FROM user_inventory WHERE id = ?");
                $del->bind_param("i", $invId);
                $del->execute();
                $del->close();

            } elseif ($itemType === 'MATERIAL') {
                if (empty($matCode)) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ระบุประเภทการ์ดเงาไม่ถูกต้อง'], 400);
                }

                // Map paired codes (e.g. SHADOW_BLUE_APLUS + SHADOW_BLUE_A, SHADOW_GOLD_S + SHADOW_GOLD_APLUS)
                $pairedCodes = [$matCode];
                if ($matCode === 'SHADOW_BLUE_APLUS' || $matCode === 'SHADOW_BLUE_A') {
                    $pairedCodes = ['SHADOW_BLUE_APLUS', 'SHADOW_BLUE_A'];
                } elseif ($matCode === 'SHADOW_GOLD_S' || $matCode === 'SHADOW_GOLD_APLUS') {
                    $pairedCodes = ['SHADOW_GOLD_S', 'SHADOW_GOLD_APLUS'];
                }

                $matBalances = [];
                $currQty = 0;
                $stmt = $db->prepare("SELECT quantity FROM user_materials WHERE user_id = ? AND material_code = ? FOR UPDATE");
                foreach ($pairedCodes as $pCode) {
                    $stmt->bind_param("is", $userId, $pCode);
                    $stmt->execute();
                    $r = $stmt->get_result()->fetch_assoc();
                    $q = (int)($r['quantity'] ?? 0);
                    $matBalances[$pCode] = $q;
                    $currQty += $q;
                }
                $stmt->close();

                if ($currQty < $quantity) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => "คุณมีจำนวนการ์ดไม่เพียงพอ (มี {$currQty} ใบ)"], 400);
                }

                $matNames = [
                    'SHADOW_BLACK_A' => 'การ์ดเงาสีดำ A',
                    'SHADOW_RED_A' => 'การ์ดเงาสีแดง A',
                    'SHADOW_ORANGE_A' => 'การ์ดเงาสีส้ม A',
                    'SHADOW_BLUE_APLUS' => 'การ์ดเงาสีฟ้า A+',
                    'SHADOW_BLUE_A' => 'การ์ดเงาสีฟ้า A+',
                    'SHADOW_GOLD_S' => 'การ์ดเงาสีทอง S',
                    'SHADOW_GOLD_APLUS' => 'การ์ดเงาสีทอง S',
                    'SPECIAL_CARD' => 'การ์ดพิเศษ (Special Card)'
                ];

                $lookupKey = $matCode;
                if ($matCode === 'SHADOW_BLUE_A') $lookupKey = 'SHADOW_BLUE_APLUS';
                if ($matCode === 'SHADOW_GOLD_APLUS') $lookupKey = 'SHADOW_GOLD_S';

                $cfg = $itemsCfg[$lookupKey] ?? ['amount' => 20, 'currency' => 'DIAMOND'];
                $pricePerUnit = (int)$cfg['amount'];
                $sellCurrency = $cfg['currency'];
                $earnedAmount = $pricePerUnit * $quantity;
                $label = $matNames[$matCode] ?? "การ์ดเงา {$matCode}";
                $itemName = "{$label} จำนวน {$quantity} ใบ";

                // Deduct across paired codes if needed
                $remainingToDeduct = $quantity;
                $updMat = $db->prepare("UPDATE user_materials SET quantity = quantity - ? WHERE user_id = ? AND material_code = ?");
                foreach ($pairedCodes as $pCode) {
                    if ($remainingToDeduct <= 0) break;
                    $avail = $matBalances[$pCode] ?? 0;
                    if ($avail > 0) {
                        $take = min($avail, $remainingToDeduct);
                        $updMat->bind_param("iis", $take, $userId, $pCode);
                        $updMat->execute();
                        $remainingToDeduct -= $take;
                    }
                }
                $updMat->close();
            } else {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ประเภทไอเทมไม่ถูกต้อง'], 400);
            }

            // Credit configured currency (DIAMOND or GOLD) to user
            $diamondEarned = 0;
            $goldEarned = 0;
            if ($sellCurrency === 'GOLD') {
                $goldEarned = $earnedAmount;
                $updUser = $db->prepare("UPDATE users SET gold = gold + ? WHERE id = ?");
                $updUser->bind_param("ii", $goldEarned, $userId);
                $updUser->execute();
                $updUser->close();
            } else {
                $sellCurrency = 'DIAMOND';
                $diamondEarned = $earnedAmount;
                $updUser = $db->prepare("UPDATE users SET diamond = diamond + ? WHERE id = ?");
                $updUser->bind_param("ii", $diamondEarned, $userId);
                $updUser->execute();
                $updUser->close();
            }

            // Get new user balance
            $uStmt = $db->prepare("SELECT diamond, gold FROM users WHERE id = ?");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $userBal = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();

            $db->commit();

            $unitText = ($sellCurrency === 'GOLD')
                ? '+' . number_format($goldEarned) . ' 🪙 ทอง'
                : '+' . number_format($diamondEarned) . ' 💎 เพชร';

            jsonResponse([
                'status' => 'success',
                'message' => "ขาย {$itemName} สำเร็จ! ได้รับ {$unitText}",
                'currency' => $sellCurrency,
                'earned_amount' => $earnedAmount,
                'diamond_earned' => $diamondEarned,
                'gold_earned' => $goldEarned,
                'new_diamond' => (int)$userBal['diamond'],
                'new_gold' => (int)$userBal['gold']
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Sell failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 10. กิจกรรมประจำวัน: สุ่มจับคู่แผ่นป้าย 4x2 (8 ช่อง) รีเซ็ต 21:00 น.
    // -------------------------------------------------------------
    case 'get_daily_match_status':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $now = new DateTime('now', new DateTimeZone('Asia/Bangkok'));
        $resetToday = new DateTime('today 21:00:00', new DateTimeZone('Asia/Bangkok'));
        if ($now < $resetToday) {
            $periodStart = (clone $resetToday)->modify('-1 day');
            $nextReset = $resetToday;
        } else {
            $periodStart = $resetToday;
            $nextReset = (clone $resetToday)->modify('+1 day');
        }

        $periodStartStr = $periodStart->format('Y-m-d H:i:s');
        $secondsToReset = max(0, $nextReset->getTimestamp() - $now->getTimestamp());

        // Check if user has played in this period
        $stmt = $db->prepare("SELECT last_played_at, last_rewards_json FROM user_daily_match WHERE user_id = ? LIMIT 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $record = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $canPlay = true;
        $lastPlayedAt = null;
        $lastRewards = [];
        if ($record && !empty($record['last_played_at'])) {
            $lastPlayedAt = $record['last_played_at'];
            if ($lastPlayedAt >= $periodStartStr) {
                $canPlay = false;
                if (!empty($record['last_rewards_json'])) {
                    $lastRewards = json_decode($record['last_rewards_json'], true) ?? [];
                }
            }
        }

        // Fetch active rewards pool
        $res = $db->query("SELECT * FROM daily_match_rewards WHERE is_active = 1 ORDER BY RAND()");
        $pool = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        if (count($pool) < 4) {
            // Fallback default rewards
            $pool = [
                ['id' => 1, 'name' => '100 เพชร', 'reward_type' => 'DIAMOND', 'reward_value' => 100, 'material_code' => null, 'icon' => '💎'],
                ['id' => 2, 'name' => '300 เพชร', 'reward_type' => 'DIAMOND', 'reward_value' => 300, 'material_code' => null, 'icon' => '💎'],
                ['id' => 3, 'name' => '50,000 ทอง', 'reward_type' => 'GOLD', 'reward_value' => 50000, 'material_code' => null, 'icon' => '🪙'],
                ['id' => 4, 'name' => 'การ์ดเงาทอง A+', 'reward_type' => 'MATERIAL', 'reward_value' => 1, 'material_code' => 'SHADOW_GOLD_APLUS', 'icon' => '🎴']
            ];
        }

        // Pick 4 rewards to make 4 pairs (total 8 tiles)
        $selectedRewards = array_slice($pool, 0, 4);
        $tiles = [];
        $pairId = 1;
        foreach ($selectedRewards as $rew) {
            $itemInfo = [
                'reward_id' => (int)$rew['id'],
                'pair_id' => $pairId,
                'name' => $rew['name'],
                'reward_type' => $rew['reward_type'],
                'reward_value' => (int)$rew['reward_value'],
                'material_code' => $rew['material_code'] ?? null,
                'icon' => $rew['icon'] ?? '🎁'
            ];
            // Duplicate to make a pair
            $tiles[] = array_merge($itemInfo, ['tile_uid' => 't_' . $pairId . '_a']);
            $tiles[] = array_merge($itemInfo, ['tile_uid' => 't_' . $pairId . '_b']);
            $pairId++;
        }
        // Shuffle tiles
        shuffle($tiles);

        jsonResponse([
            'status' => 'success',
            'can_play' => $canPlay,
            'seconds_until_reset' => $secondsToReset,
            'next_reset_time_th' => '21:00 น. วันนี้',
            'last_played_at' => $lastPlayedAt,
            'last_rewards' => $lastRewards,
            'tiles' => $tiles,
            'max_chances' => 3,
            'user_diamond' => (int)$user['diamond'],
            'user_gold' => (int)$user['gold']
        ]);
        break;

    case 'claim_daily_match':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $matchedPairs = $input['matched_pairs'] ?? ($_POST['matched_pairs'] ?? []);
        if (is_string($matchedPairs)) { $matchedPairs = json_decode($matchedPairs, true) ?? []; }

        $now = new DateTime('now', new DateTimeZone('Asia/Bangkok'));
        $resetToday = new DateTime('today 21:00:00', new DateTimeZone('Asia/Bangkok'));
        if ($now < $resetToday) {
            $periodStart = (clone $resetToday)->modify('-1 day');
        } else {
            $periodStart = $resetToday;
        }
        $periodStartStr = $periodStart->format('Y-m-d H:i:s');

        // Check if user already played
        $stmt = $db->prepare("SELECT last_played_at FROM user_daily_match WHERE user_id = ? LIMIT 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $record = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($record && !empty($record['last_played_at']) && $record['last_played_at'] >= $periodStartStr) {
            jsonResponse(['status' => 'error', 'message' => 'คุณใช้สิทธิ์กิจกรรมของวันนี้แล้ว รอบใหม่จะรีเซ็ตเวลา 21:00 น. หลัง 3 ทุ่ม'], 400);
        }

        // Maximum 3 pairs allowed (since player has 3 turns)
                $matchedPairs = array_slice($matchedPairs, 0, 3);

        $totalDia = 0;
        $totalGold = 0;
        $materialsAwarded = [];

        $db->begin_transaction();
        try {
            foreach ($matchedPairs as $p) {
                $type = strtoupper($p['reward_type'] ?? 'DIAMOND');
                $val = (int)($p['reward_value'] ?? 0);
                $matCode = $p['material_code'] ?? null;

                if ($type === 'DIAMOND') {
                    $totalDia += $val;
                } elseif ($type === 'GOLD') {
                    $totalGold += $val;
                } elseif ($type === 'MATERIAL' && $matCode) {
                    $mStmt = $db->prepare("
                        INSERT INTO user_materials (user_id, material_code, quantity) 
                        VALUES (?, ?, ?) 
                        ON DUPLICATE KEY UPDATE quantity = quantity + ?
                    ");
                    $mStmt->bind_param("isii", $userId, $matCode, $val, $val);
                    $mStmt->execute();
                    $mStmt->close();
                    $materialsAwarded[] = "{$val}x {$matCode}";
                }
            }

            // Update user diamond & gold
            if ($totalDia > 0 || $totalGold > 0) {
                $upd = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
                $upd->bind_param("iii", $totalDia, $totalGold, $userId);
                $upd->execute();
                $upd->close();
            }

            // Record daily match play
            $rewardsJson = json_encode($matchedPairs, JSON_UNESCAPED_UNICODE);
            $db->query("
                INSERT INTO user_daily_match (user_id, last_played_at, last_rewards_json) 
                VALUES ({$userId}, NOW(), '{$db->real_escape_string($rewardsJson)}') 
                ON DUPLICATE KEY UPDATE last_played_at = NOW(), last_rewards_json = VALUES(last_rewards_json)
            ");

            // Get updated balances
            $uStmt = $db->prepare("SELECT diamond, gold FROM users WHERE id = ?");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $newBal = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();

            $db->commit();

            jsonResponse([
                'status' => 'success',
                'message' => 'ยินดีด้วย! คุณได้รับของรางวัลจากกิจกรรมสุ่มจับคู่ประจำวันเรียบร้อยแล้ว!',
                'awarded_diamond' => $totalDia,
                'awarded_gold' => $totalGold,
                'awarded_materials' => $materialsAwarded,
                'new_diamond' => (int)$newBal['diamond'],
                'new_gold' => (int)$newBal['gold']
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Claim failed: ' . $e->getMessage()], 500);
        }
        break;

    case 'set_offline':
        try {
            $user = requireAuth($db);
            $userId = (int)$user['id'];
            $db->query("UPDATE users SET last_active_at = DATE_SUB(NOW(), INTERVAL 1 HOUR) WHERE id = {$userId}");
            jsonResponse(['status' => 'success', 'message' => 'User set to offline']);
        } catch (\Throwable $e) {
            jsonResponse(['status' => 'success']);
        }
        break;

    // -------------------------------------------------------------
    // 11. ระบบครอบครัว / สังกัดบ้าน (Clan / House System - Max 30 Members)
    // -------------------------------------------------------------
    case 'get_clan_info':
        // Clean up orphan clans where leader is in another clan or 0 members
        @$db->query("DELETE FROM clans WHERE id NOT IN (SELECT DISTINCT clan_id FROM users WHERE clan_id IS NOT NULL)");

        $user = requireAuth($db);
        $userId = (int)$user['id'];

        // Touch last_active_at
        $db->query("UPDATE users SET last_active_at = NOW() WHERE id = {$userId}");

        // Get user's current clan
        $stmt = $db->prepare("
            SELECT u.clan_id, u.clan_role as my_user_role, c.id as clan_id_real, c.name as clan_name, c.tag, c.description, c.badge_icon, c.leader_id, 
                   c.total_score, c.clan_level, c.max_members, c.join_type,
                   leader.username as leader_name, leader.avatar_url as leader_avatar
            FROM users u
            LEFT JOIN clans c ON u.clan_id = c.id
            LEFT JOIN users leader ON c.leader_id = leader.id
            WHERE u.id = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $clanData = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $clanId = $clanData['clan_id'] ? (int)$clanData['clan_id'] : null;
        $members = [];
        $currentCount = 0;
        $onlineCount = 0;
        $myRole = $clanData['my_user_role'] ?? 'member';
        $pendingRequests = [];
        $recentMessages = [];

        if ($clanId) {
            $leaderId = (int)$clanData['leader_id'];
            if ($userId === $leaderId) {
                $myRole = 'leader';
            }

            // Get members list with online status & roles
            $mStmt = $db->prepare("
                SELECT id, username, avatar_url, level, clan_role,
                       (id = ?) as is_leader,
                       (last_active_at IS NOT NULL AND TIMESTAMPDIFF(MINUTE, last_active_at, NOW()) <= 3) as is_online,
                       last_active_at
                FROM users 
                WHERE clan_id = ? 
                ORDER BY (id = ?) DESC, (clan_role = 'co_leader') DESC, (clan_role = 'elder') DESC, level DESC, id ASC 
                LIMIT 30
            ");
            $mStmt->bind_param("iii", $leaderId, $clanId, $leaderId);
            $mStmt->execute();
            $rawMembers = $mStmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $mStmt->close();

            foreach ($rawMembers as $rm) {
                $isOnline = (bool)$rm['is_online'];
                if ($isOnline) $onlineCount++;
                $role = $rm['clan_role'] ?? 'member';
                if ((int)$rm['id'] === $leaderId) $role = 'leader';
                $members[] = [
                    'id' => (int)$rm['id'],
                    'username' => $rm['username'],
                    'avatar_url' => $rm['avatar_url'] ?: 'avatars/google_avatar.png',
                    'level' => (int)$rm['level'],
                    'clan_role' => $role,
                    'is_leader' => (bool)$rm['is_leader'],
                    'is_online' => $isOnline,
                    'last_active_at' => $rm['last_active_at']
                ];
            }
            $currentCount = count($members);

            // Fetch pending requests if leader or co_leader
            if ($myRole === 'leader' || $myRole === 'co_leader') {
                $rStmt = $db->prepare("
                    SELECT r.id as request_id, r.user_id, r.created_at, u.username, u.avatar_url, u.level
                    FROM clan_requests r
                    JOIN users u ON r.user_id = u.id
                    WHERE r.clan_id = ? AND r.status = 'pending'
                    ORDER BY r.created_at DESC
                    LIMIT 20
                ");
                $rStmt->bind_param("i", $clanId);
                $rStmt->execute();
                $pendingRequests = $rStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                $rStmt->close();
            }

            // Fetch recent clan messages
            $msgStmt = $db->prepare("
                SELECT m.id, m.clan_id, m.user_id, m.message, m.created_at, u.username, u.avatar_url, u.clan_role
                FROM clan_messages m
                JOIN users u ON m.user_id = u.id
                WHERE m.clan_id = ?
                ORDER BY m.id DESC LIMIT 40
            ");
            $msgStmt->bind_param("i", $clanId);
            $msgStmt->execute();
            $recentMessages = array_reverse($msgStmt->get_result()->fetch_all(MYSQLI_ASSOC));
            $msgStmt->close();
        } else {
            // ดึงข้อความแชทล่าสุดของบ้านพักส่วนกลาง (Public Lounge: clan_id = 0) สำหรับทุกคน
            $msgStmt = $db->prepare("
                SELECT m.id, m.clan_id, m.user_id, m.message, m.created_at, u.username, u.avatar_url, u.clan_role
                FROM clan_messages m
                JOIN users u ON m.user_id = u.id
                WHERE m.clan_id = 0
                ORDER BY m.id DESC LIMIT 40
            ");
            if ($msgStmt) {
                $msgStmt->execute();
                $recentMessages = array_reverse($msgStmt->get_result()->fetch_all(MYSQLI_ASSOC));
                $msgStmt->close();
            }
        }

        // List available clans to join
        $res = $db->query("
            SELECT c.id, c.name, c.tag, c.description, c.badge_icon, c.clan_level, c.total_score, c.max_members, 
                   COALESCE(c.join_type, 'free') as join_type,
                   u.username as leader_name, u.avatar_url as leader_avatar, COUNT(m.id) as current_members,
                   EXISTS(SELECT 1 FROM clan_requests cr WHERE cr.clan_id = c.id AND cr.user_id = {$userId} AND cr.status = 'pending') as has_pending
            FROM clans c
            LEFT JOIN users u ON c.leader_id = u.id
            LEFT JOIN users m ON c.id = m.clan_id
            GROUP BY c.id, u.username, u.avatar_url
            HAVING current_members < 30
            ORDER BY c.total_score DESC
            LIMIT 20
        ");
        $rawClans = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        $availableClans = [];

        foreach ($rawClans as $cRow) {
            $cId = (int)$cRow['id'];
            $mRes = $db->query("
                SELECT id, username, avatar_url, level, clan_role,
                       (id = (SELECT leader_id FROM clans WHERE id = {$cId})) as is_leader
                FROM users
                WHERE clan_id = {$cId}
                ORDER BY (id = (SELECT leader_id FROM clans WHERE id = {$cId})) DESC,
                         (clan_role = 'co_leader') DESC,
                         (clan_role = 'elder') DESC,
                         level DESC, id ASC
                LIMIT 8
            ");
            $cMembers = [];
            if ($mRes) {
                while ($mr = $mRes->fetch_assoc()) {
                    $r = $mr['clan_role'] ?? 'member';
                    if (!empty($mr['is_leader'])) $r = 'leader';
                    $cMembers[] = [
                        'id' => (int)$mr['id'],
                        'username' => $mr['username'],
                        'avatar_url' => $mr['avatar_url'] ?: 'avatars/google_avatar.png',
                        'level' => (int)$mr['level'],
                        'clan_role' => $r
                    ];
                }
            }
            if (empty($cMembers) && !empty($cRow['leader_name'])) {
                $cMembers[] = [
                    'id' => 0,
                    'username' => $cRow['leader_name'],
                    'avatar_url' => $cRow['leader_avatar'] ?: 'avatars/google_avatar.png',
                    'level' => 1,
                    'clan_role' => 'leader'
                ];
            }
            $cRow['members'] = $cMembers;
            $cRow['has_pending'] = (!empty($cRow['has_pending']) && ((string)$cRow['has_pending'] === '1' || $cRow['has_pending'] === 1 || $cRow['has_pending'] === true));
            $cRow['current_members'] = (int)$cRow['current_members'];
            $cRow['max_members'] = (int)($cRow['max_members'] ?? 30);
            $cRow['clan_level'] = (int)($cRow['clan_level'] ?? 1);
            $availableClans[] = $cRow;
        }

        jsonResponse([
            'status' => 'success',
            'has_clan' => !empty($clanId),
            'clan' => $clanData,
            'my_role' => $myRole,
            'members' => $members,
            'members_count' => $currentCount,
            'online_count' => $onlineCount,
            'max_members' => 30,
            'join_type' => $clanData['join_type'] ?? 'free',
            'pending_requests' => $pendingRequests,
            'recent_messages' => $recentMessages,
            'available_clans' => $availableClans
        ]);
        break;

    case 'send_clan_message':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $uRow = $db->query("SELECT clan_id, clan_role, username, avatar_url FROM users WHERE id = {$userId}")->fetch_assoc();
        // clan_id = 0 คือบ้านพักส่วนกลาง (Public Lounge) สำหรับทุกคนที่ยังไม่มีบ้านประจำ
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $msg = trim($input['message'] ?? '');
        if (empty($msg)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกข้อความ'], 400);
        }
        if (mb_strlen($msg) > 300) {
            jsonResponse(['status' => 'error', 'message' => 'ข้อความยาวเกินไป (ไม่เกิน 300 ตัวอักษร)'], 400);
        }

        $stmt = $db->prepare("INSERT INTO clan_messages (clan_id, user_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $clanId, $userId, $msg);
        $stmt->execute();
        $msgId = $stmt->insert_id;
        $stmt->close();

        $db->query("UPDATE users SET last_active_at = NOW() WHERE id = {$userId}");

        jsonResponse([
            'status' => 'success',
            'message' => 'ส่งข้อความเรียบร้อย',
            'data' => [
                'id' => $msgId,
                'clan_id' => $clanId,
                'user_id' => $userId,
                'username' => $uRow['username'],
                'avatar_url' => $uRow['avatar_url'] ?: 'avatars/google_avatar.png',
                'clan_role' => $clanId ? ($uRow['clan_role'] ?? 'member') : 'guest',
                'message' => $msg,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ]);
        break;

    case 'get_clan_messages':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $uRow = $db->query("SELECT clan_id FROM users WHERE id = {$userId}")->fetch_assoc();
        // clan_id = 0 คือบ้านพักส่วนกลาง (Public Lounge)
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $afterId = (int)($input['after_id'] ?? ($_GET['after_id'] ?? 0));
        if ($afterId > 0) {
            $stmt = $db->prepare("
                SELECT m.id, m.clan_id, m.user_id, m.message, m.created_at, u.username, u.avatar_url, u.clan_role
                FROM clan_messages m
                JOIN users u ON m.user_id = u.id
                WHERE m.clan_id = ? AND m.id > ?
                ORDER BY m.id ASC LIMIT 50
            ");
            $stmt->bind_param("ii", $clanId, $afterId);
            $stmt->execute();
            $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } else {
            $stmt = $db->prepare("
                SELECT m.id, m.clan_id, m.user_id, m.message, m.created_at, u.username, u.avatar_url, u.clan_role
                FROM clan_messages m
                JOIN users u ON m.user_id = u.id
                WHERE m.clan_id = ?
                ORDER BY m.id DESC LIMIT 40
            ");
            $stmt->bind_param("i", $clanId);
            $stmt->execute();
            $messages = array_reverse($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
            $stmt->close();
        }
        jsonResponse(['status' => 'success', 'messages' => $messages]);
        break;

    case 'update_member_role':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $targetId = (int)($input['target_user_id'] ?? 0);
        $newRole = trim($input['new_role'] ?? ''); // 'co_leader', 'elder', 'member'

        if (!in_array($newRole, ['co_leader', 'elder', 'member'])) {
            jsonResponse(['status' => 'error', 'message' => 'ตำแหน่งที่เลือกไม่ถูกต้อง'], 400);
        }

        $uRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $myRole = $uRow['clan_role'] ?? 'member';

        // Check clan leader
        $cRow = $db->query("SELECT leader_id FROM clans WHERE id = {$clanId}")->fetch_assoc();
        $isLeader = ($cRow && (int)$cRow['leader_id'] === $userId);
        if ($isLeader) $myRole = 'leader';

        if ($myRole !== 'leader' && $myRole !== 'co_leader') {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าหรือรองหัวหน้าบ้านเท่านั้นที่มีสิทธิ์ปรับตำแหน่ง'], 403);
        }

        $target = $db->query("SELECT id, username, clan_id, clan_role FROM users WHERE id = {$targetId}")->fetch_assoc();
        if (!$target || (int)$target['clan_id'] !== $clanId) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบสมาชิกในบ้านนี้'], 404);
        }

        if ((int)$target['id'] === (int)$cRow['leader_id']) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถเปลี่ยนตำแหน่งของหัวหน้าบ้านได้'], 400);
        }
        if ($myRole === 'co_leader' && ($target['clan_role'] === 'co_leader' || $newRole === 'co_leader')) {
            jsonResponse(['status' => 'error', 'message' => 'รองหัวหน้าไม่สามารถแต่งตั้งหรือปลดรองหัวหน้าด้วยกันได้'], 403);
        }

        $db->query("UPDATE users SET clan_role = '{$newRole}' WHERE id = {$targetId}");

        $roleLabels = [
            'co_leader' => '🥈 รองหัวหน้า',
            'elder' => '🥉 สมาชิกอาวุโส',
            'member' => '👤 สมาชิกทั่วไป'
        ];
        $roleName = $roleLabels[$newRole] ?? $newRole;

        // System message in clan chat
        $sysMsg = "📢 หัวหน้าได้ปรับตำแหน่งของ '{$target['username']}' เป็น {$roleName}";
        $sysStmt = $db->prepare("INSERT INTO clan_messages (clan_id, user_id, message) VALUES (?, ?, ?)");
        $sysStmt->bind_param("iis", $clanId, $userId, $sysMsg);
        $sysStmt->execute();
        $sysStmt->close();

        jsonResponse([
            'status' => 'success',
            'message' => "ปรับระดับลูกทีม '{$target['username']}' เป็น {$roleName} เรียบร้อยแล้ว!"
        ]);
        break;

    case 'kick_clan_member':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $targetId = (int)($input['target_user_id'] ?? 0);

        $uRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $myRole = $uRow['clan_role'] ?? 'member';

        $cRow = $db->query("SELECT leader_id FROM clans WHERE id = {$clanId}")->fetch_assoc();
        $isLeader = ($cRow && (int)$cRow['leader_id'] === $userId);
        if ($isLeader) $myRole = 'leader';

        if ($myRole !== 'leader' && $myRole !== 'co_leader') {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าหรือรองหัวหน้าบ้านเท่านั้นที่มีสิทธิ์เตะสมาชิก'], 403);
        }

        $target = $db->query("SELECT id, username, clan_id, clan_role FROM users WHERE id = {$targetId}")->fetch_assoc();
        if (!$target || (int)$target['clan_id'] !== $clanId) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบสมาชิกในบ้านนี้'], 404);
        }

        if ((int)$target['id'] === (int)$cRow['leader_id']) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถเตะหัวหน้าบ้านได้'], 400);
        }
        if ($myRole === 'co_leader' && $target['clan_role'] === 'co_leader') {
            jsonResponse(['status' => 'error', 'message' => 'รองหัวหน้าไม่สามารถเตะรองหัวหน้าด้วยกันได้'], 403);
        }

        $db->query("UPDATE users SET clan_id = NULL, clan_role = 'member' WHERE id = {$targetId}");

        // หากมีคนออกหรือถูกเตะจนเหลือสมาชิกคนเดียว สมาชิกคนนั้นจะกลายเป็นหัวหน้าบ้านทันที
        $remMembers = $db->query("SELECT id FROM users WHERE clan_id = {$clanId} ORDER BY level DESC, id ASC")->fetch_all(MYSQLI_ASSOC);
        if (count($remMembers) === 1) {
            $soleId = (int)$remMembers[0]['id'];
            $db->query("UPDATE clans SET leader_id = {$soleId} WHERE id = {$clanId}");
            $db->query("UPDATE users SET clan_role = 'leader' WHERE id = {$soleId}");
        }

        // System message in clan chat
        $sysMsg = "🚪 '{$target['username']}' ถูกเตะออกจากบ้าน";
        $sysStmt = $db->prepare("INSERT INTO clan_messages (clan_id, user_id, message) VALUES (?, ?, ?)");
        $sysStmt->bind_param("iis", $clanId, $userId, $sysMsg);
        $sysStmt->execute();
        $sysStmt->close();

        jsonResponse([
            'status' => 'success',
            'message' => "เตะ {$target['username']} ออกจากครอบครัวเรียบร้อยแล้ว"
        ]);
        break;

    case 'set_clan_join_type':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $joinType = ($input['join_type'] ?? '') === 'approval' ? 'approval' : 'free';

        $uRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $cRow = $db->query("SELECT leader_id FROM clans WHERE id = {$clanId}")->fetch_assoc();
        $isLeader = ($cRow && (int)$cRow['leader_id'] === $userId);

        if (!$isLeader) {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าบ้านเท่านั้นที่มีสิทธิ์ตั้งค่าเงื่อนไขการรับสมาชิก'], 403);
        }

        $db->query("UPDATE clans SET join_type = '{$joinType}' WHERE id = {$clanId}");
        $label = ($joinType === 'free') ? '🟢 เข้าอิสระได้ทันที' : '🟡 ต้องรออนุมัติ';
        jsonResponse([
            'status' => 'success',
            'message' => "ตั้งค่ารูปแบบการรับสมาชิกเป็น '{$label}' เรียบร้อยแล้ว",
            'join_type' => $joinType
        ]);
        break;

    case 'respond_clan_request':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $requestId = (int)($input['request_id'] ?? 0);
        $decision = trim($input['decision'] ?? ''); // 'approve' or 'reject'

        $uRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        $cRow = $db->query("SELECT leader_id FROM clans WHERE id = {$clanId}")->fetch_assoc();
        $isLeader = ($cRow && (int)$cRow['leader_id'] === $userId);
        $myRole = $isLeader ? 'leader' : ($uRow['clan_role'] ?? 'member');

        if ($myRole !== 'leader' && $myRole !== 'co_leader') {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าหรือรองหัวหน้าบ้านเท่านั้นที่มีสิทธิ์อนุมัติคำขอ'], 403);
        }

        $req = $db->query("SELECT * FROM clan_requests WHERE id = {$requestId} AND clan_id = {$clanId} AND status = 'pending'")->fetch_assoc();
        if (!$req) {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบคำขอเข้าร่วม หรือคำขอนี้ได้รับการดำเนินการแล้ว'], 404);
        }

        $applicantId = (int)$req['user_id'];
        $appUser = $db->query("SELECT id, username, clan_id FROM users WHERE id = {$applicantId}")->fetch_assoc();

        if ($decision === 'approve') {
            // Check member count strictly <= 30
            $chkCount = $db->query("SELECT COUNT(*) as c FROM users WHERE clan_id = {$clanId}")->fetch_assoc();
            if ((int)$chkCount['c'] >= 30) {
                jsonResponse(['status' => 'error', 'message' => 'บ้านนี้สมาชิกเต็ม 30 คนแล้ว ไม่สามารถรับเพิ่มได้'], 400);
            }

            if (!empty($appUser['clan_id'])) {
                $db->query("UPDATE clan_requests SET status = 'rejected' WHERE id = {$requestId}");
                jsonResponse(['status' => 'error', 'message' => 'ผู้เล่นนี้ได้สังกัดบ้านอื่นไปแล้ว'], 400);
            }

            $db->query("UPDATE users SET clan_id = {$clanId}, clan_role = 'member' WHERE id = {$applicantId}");
            $db->query("UPDATE clan_requests SET status = 'approved' WHERE id = {$requestId}");

            // System chat message
            $sysMsg = "👋 ยินดีต้อนรับ '{$appUser['username']}' เข้าสู่ครอบครัว!";
            $sysStmt = $db->prepare("INSERT INTO clan_messages (clan_id, user_id, message) VALUES (?, ?, ?)");
            $sysStmt->bind_param("iis", $clanId, $userId, $sysMsg);
            $sysStmt->execute();
            $sysStmt->close();

            jsonResponse([
                'status' => 'success',
                'message' => "อนุมัติรับ '{$appUser['username']}' เข้าบ้านเรียบร้อยแล้ว!"
            ]);
        } else {
            $db->query("UPDATE clan_requests SET status = 'rejected' WHERE id = {$requestId}");
            jsonResponse([
                'status' => 'success',
                'message' => "ปฏิเสธคำขอเข้าร่วมของ '{$appUser['username']}' แล้ว"
            ]);
        }
        break;

    case 'create_clan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $name = trim($input['name'] ?? '');
        $tag = strtoupper(trim($input['tag'] ?? ''));
        $desc = trim($input['description'] ?? '');
        $badge = trim($input['badge_icon'] ?? 'badge_naga.png');

        if (empty($name)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกชื่อบ้าน / ครอบครัว'], 400);
        }
        if (mb_strlen($name) > 30) {
            jsonResponse(['status' => 'error', 'message' => 'ชื่อบ้านต้องไม่เกิน 30 ตัวอักษร'], 400);
        }
        if (empty($tag)) {
            $tag = mb_substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 4) ?: 'HOME';
        }

        // Check if user is already in a clan
        $chk = $db->query("SELECT clan_id FROM users WHERE id = {$userId}")->fetch_assoc();
        if (!empty($chk['clan_id'])) {
            jsonResponse(['status' => 'error', 'message' => 'คุณสังกัดบ้านอื่นอยู่แล้ว ต้องออกจากบ้านเดิมก่อนสร้างใหม่'], 400);
        }

        // Check if clan name already exists
        $nChk = $db->prepare("SELECT id FROM clans WHERE name = ?");
        $nChk->bind_param("s", $name);
        $nChk->execute();
        if ($nChk->get_result()->fetch_assoc()) {
            $nChk->close();
            jsonResponse(['status' => 'error', 'message' => "มีบ้านชื่อ '{$name}' อยู่แล้ว กรุณาตั้งชื่ออื่น"], 400);
        }
        $nChk->close();

        $db->begin_transaction();
        try {
            // Insert clan with strictly 30 max_members
            $stmt = $db->prepare("
                INSERT INTO clans (name, tag, description, badge_icon, leader_id, total_score, clan_level, max_members) 
                VALUES (?, ?, ?, ?, ?, 1000, 1, 30)
            ");
            $stmt->bind_param("ssssi", $name, $tag, $desc, $badge, $userId);
            $stmt->execute();
            $clanId = $db->insert_id;
            $stmt->close();

            // Set user's clan_id
            $db->query("UPDATE users SET clan_id = {$clanId} WHERE id = {$userId}");

            $db->commit();

            jsonResponse([
                'status' => 'success',
                'message' => "สร้างบ้าน '{$name}' สำเร็จ! คุณคือหัวหน้าครอบครัว ยินดีต้อนรับสมาชิกสูงสุด 30 คน",
                'clan_id' => $clanId,
                'clan_name' => $name
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Create clan failed: ' . $e->getMessage()], 500);
        }
        break;

    case 'cancel_clan_request':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $clanId = (int)($input['clan_id'] ?? 0);
        if ($clanId > 0) {
            $db->query("DELETE FROM clan_requests WHERE user_id = {$userId} AND clan_id = {$clanId} AND status = 'pending'");
        } else {
            $db->query("DELETE FROM clan_requests WHERE user_id = {$userId} AND status = 'pending'");
        }
        jsonResponse(['status' => 'success', 'message' => 'ยกเลิกคำขอเข้าร่วมบ้านเรียบร้อยแล้ว']);
        break;

    case 'join_clan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $clanId = (int)($input['clan_id'] ?? 0);

        if (!$clanId) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณาระบุรหัสบ้านที่ต้องการเข้าร่วม'], 400);
        }

        // Check if user is already in a clan (เข้าบ้านได้หลังเดียวเท่านั้น)
        if (!empty($input['leave_previous'])) {
            $prevRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
            $prevClanId = (int)($prevRow['clan_id'] ?? 0);
            if ($prevClanId) {
                $db->query("UPDATE users SET clan_id = NULL, clan_role = 'member' WHERE id = {$userId}");

                // หากบ้านเดิมเหลือสมาชิกคนเดียว สมาชิกคนนั้นจะกลายเป็นหัวหน้าบ้านทันที
                $remMembers = $db->query("SELECT id FROM users WHERE clan_id = {$prevClanId} ORDER BY level DESC, id ASC")->fetch_all(MYSQLI_ASSOC);
                $remCount = count($remMembers);
                if ($remCount === 1) {
                    $soleId = (int)$remMembers[0]['id'];
                    $db->query("UPDATE clans SET leader_id = {$soleId} WHERE id = {$prevClanId}");
                    $db->query("UPDATE users SET clan_role = 'leader' WHERE id = {$soleId}");
                } elseif ($remCount === 0) {
                    $db->query("DELETE FROM clan_messages WHERE clan_id = {$prevClanId}");
                    $db->query("DELETE FROM clan_requests WHERE clan_id = {$prevClanId}");
                    $db->query("DELETE FROM clans WHERE id = {$prevClanId}");
                }
            }
        } else {
            $chk = $db->query("SELECT clan_id FROM users WHERE id = {$userId}")->fetch_assoc();
            if (!empty($chk['clan_id'])) {
                $curClan = $db->query("SELECT name FROM clans WHERE id = {$chk['clan_id']}")->fetch_assoc();
                $curName = $curClan['name'] ?? 'บ้านเดิม';
                jsonResponse([
                    'status' => 'error', 
                    'message' => "คุณสังกัด '{$curName}' อยู่แล้ว (สามารถเข้าบ้านได้หลังเดียวเท่านั้น) หากต้องการย้ายเข้าบ้านนี้ กรุณายืนยันการย้ายบ้าน",
                    'has_clan' => true,
                    'current_clan_name' => $curName
                ], 400);
            }
        }

        // Check clan existence & member count (strictly <= 30)
        $cStmt = $db->prepare("
            SELECT c.*, COUNT(m.id) as current_members
            FROM clans c
            LEFT JOIN users m ON c.id = m.clan_id
            WHERE c.id = ?
            GROUP BY c.id
        ");
        $cStmt->bind_param("i", $clanId);
        $cStmt->execute();
        $clan = $cStmt->get_result()->fetch_assoc();
        $cStmt->close();

        if (!$clan) {
            jsonResponse(['status' => 'error', 'message' => 'ครอบครัวนี้เป็นบ้านระบบ (AI/บอท) ปิดรับสมัครสมาชิกบ้าน หรือไม่พบบ้านที่เลือก'], 404);
        }

        $count = (int)$clan['current_members'];
        if ($count >= 30) {
            jsonResponse(['status' => 'error', 'message' => 'บ้านนี้มีสมาชิกเต็ม 30 คนแล้ว ไม่สามารถรับสมาชิกเพิ่มได้'], 400);
        }

        $joinType = $clan['join_type'] ?? 'free';
        if ($joinType === 'approval') {
            // Check if already requested
            $pendingChk = $db->query("SELECT id FROM clan_requests WHERE clan_id = {$clanId} AND user_id = {$userId} AND status = 'pending'")->fetch_assoc();
            if ($pendingChk) {
                jsonResponse(['status' => 'error', 'message' => 'คุณได้ส่งคำขอเข้าร่วมบ้านนี้ไปแล้ว โปรดรอการอนุมัติจากหัวหน้าบ้าน'], 400);
            }

            $rStmt = $db->prepare("INSERT INTO clan_requests (clan_id, user_id, status) VALUES (?, ?, 'pending')");
            $rStmt->bind_param("ii", $clanId, $userId);
            $rStmt->execute();
            $rStmt->close();

            jsonResponse([
                'status' => 'success',
                'requires_approval' => true,
                'message' => "ส่งคำขอเข้าร่วมบ้าน '{$clan['name']}' เรียบร้อยแล้ว! โปรดรอหัวหน้าบ้านอนุมัติ",
                'clan_id' => $clanId,
                'clan_name' => $clan['name']
            ]);
            break;
        }

        // Free join immediately
        $db->query("UPDATE users SET clan_id = {$clanId}, clan_role = 'member' WHERE id = {$userId}");

        // System message in clan chat
        $uName = $user['username'] ?? 'สมาชิกใหม่';
        $sysMsg = "👋 ยินดีต้อนรับ '{$uName}' เข้าสู่ครอบครัว!";
        $sysStmt = $db->prepare("INSERT INTO clan_messages (clan_id, user_id, message) VALUES (?, ?, ?)");
        $sysStmt->bind_param("iis", $clanId, $userId, $sysMsg);
        $sysStmt->execute();
        $sysStmt->close();

        jsonResponse([
            'status' => 'success',
            'requires_approval' => false,
            'message' => "ยินดีด้วย! คุณเข้าร่วมครอบครัว '{$clan['name']}' เรียบร้อยแล้ว",
            'clan_id' => $clanId,
            'clan_name' => $clan['name']
        ]);
        break;

    case 'leave_clan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $uRow = $db->query("SELECT clan_id, clan_role FROM users WHERE id = {$userId}")->fetch_assoc();
        $clanId = (int)($uRow['clan_id'] ?? 0);
        if (!$clanId) {
            jsonResponse(['status' => 'error', 'message' => 'คุณยังไม่ได้สังกัดบ้านใดๆ'], 400);
        }

        // Check if user is leader
        $cRow = $db->query("SELECT leader_id FROM clans WHERE id = {$clanId}")->fetch_assoc();
        $isLeader = ($cRow && (int)$cRow['leader_id'] === $userId);

        $memberCount = (int)$db->query("SELECT COUNT(*) as cnt FROM users WHERE clan_id = {$clanId}")->fetch_assoc()['cnt'];

        // If user is leader AND there are other members left, leader cannot disband without members leaving first
        if ($isLeader && $memberCount > 1 && !empty($input['disband'])) {
            jsonResponse(['status' => 'error', 'message' => "ไม่สามารถยุบบ้านได้เนื่องจากยังมีสมาชิกอื่นอยู่ในบ้าน ({$memberCount} คน) ต้องให้สมาชิกออกจากบ้านจนเหลือเพียงคนเดียวก่อนจึงจะยุบบ้านได้"], 400);
        }

        $db->begin_transaction();
        try {
            // Remove user from clan
            $db->query("UPDATE users SET clan_id = NULL, clan_role = 'member' WHERE id = {$userId}");

            $remMembers = $db->query("SELECT id FROM users WHERE clan_id = {$clanId} ORDER BY level DESC, id ASC")->fetch_all(MYSQLI_ASSOC);
            $remCount = count($remMembers);

            if ($remCount === 1) {
                // If only 1 member remains, that person becomes leader automatically!
                $soleId = (int)$remMembers[0]['id'];
                $db->query("UPDATE clans SET leader_id = {$soleId} WHERE id = {$clanId}");
                $db->query("UPDATE users SET clan_role = 'leader' WHERE id = {$soleId}");
            } elseif ($remCount === 0) {
                // Empty clan -> delete clan completely
                $db->query("DELETE FROM clan_messages WHERE clan_id = {$clanId}");
                $db->query("DELETE FROM clan_requests WHERE clan_id = {$clanId}");
                $db->query("DELETE FROM clans WHERE id = {$clanId}");
            } elseif ($isLeader) {
                // Leader left with >1 members -> promote highest ranking member
                $nextLeaderId = (int)$remMembers[0]['id'];
                $db->query("UPDATE clans SET leader_id = {$nextLeaderId} WHERE id = {$clanId}");
                $db->query("UPDATE users SET clan_role = 'leader' WHERE id = {$nextLeaderId}");
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => ($remCount === 0) ? 'ยุบและลบบ้านเรียบร้อยแล้ว' : 'คุณออกจากบ้านเรียบร้อยแล้ว'
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Leave clan failed: ' . $e->getMessage()], 500);
        }
        break;

    case 'invite_to_clan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $targetUsername = trim($input['target_username'] ?? '');

        if (empty($targetUsername)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกชื่อเพื่อนที่ต้องการเชิญ'], 400);
        }

        // Check user's clan
        $clan = $db->query("
            SELECT c.*, COUNT(m.id) as current_members
            FROM users u
            JOIN clans c ON u.clan_id = c.id
            LEFT JOIN users m ON c.id = m.clan_id
            WHERE u.id = {$userId}
            GROUP BY c.id
        ")->fetch_assoc();

        if (!$clan) {
            jsonResponse(['status' => 'error', 'message' => 'คุณยังไม่มีสังกัดบ้าน กรุณาสร้างบ้านหรือเข้าบ้านก่อน'], 400);
        }

        if ((int)$clan['current_members'] >= 30) {
            jsonResponse(['status' => 'error', 'message' => 'บ้านของคุณมีสมาชิกเต็ม 30 คนแล้ว'], 400);
        }

        // Find target user
        $tStmt = $db->prepare("SELECT id, username, clan_id FROM users WHERE username = ? OR id = ? LIMIT 1");
        $tId = is_numeric($targetUsername) ? (int)$targetUsername : 0;
        $tStmt->bind_param("si", $targetUsername, $tId);
        $tStmt->execute();
        $targetUser = $tStmt->get_result()->fetch_assoc();
        $tStmt->close();

        if (!$targetUser) {
            jsonResponse(['status' => 'error', 'message' => "ไม่พบบัญชีผู้เล่น '{$targetUsername}' ในระบบ"], 404);
        }

        if (!empty($targetUser['clan_id'])) {
            jsonResponse(['status' => 'error', 'message' => "ผู้เล่น '{$targetUser['username']}' มีสังกัดบ้านอยู่แล้ว"], 400);
        }

        // Send invite mail to friend's mailbox
        $invTitle = "💌 คำเชิญเข้าร่วมครอบครัว '{$clan['name']}'";
        $invMsg = "คุณ '{$user['username']}' ได้ส่งคำเชิญให้คุณเข้าร่วมบ้าน '{$clan['name']}' (แท็ก: [{$clan['tag']}]) สมาชิกปัจจุบัน {$clan['current_members']}/30 คน แตะเข้าร่วมได้ทันที!";
        $mStmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
        $tUid = (int)$targetUser['id'];
        $mStmt->bind_param("iss", $tUid, $invTitle, $invMsg);
        $mStmt->execute();
        $mStmt->close();

        jsonResponse([
            'status' => 'success',
            'message' => "ส่งคำเชิญเข้าร่วมบ้านให้คุณ '{$targetUser['username']}' เรียบร้อยแล้ว!"
        ]);
        break;

    // -------------------------------------------------------------
    // EVENT GACHA & MAGIC CUBE ACTIONS (LINE Let's Get Rich Style)
    // -------------------------------------------------------------
    case 'get_active_event_gacha':
        ensureCubeAndEventTables($db);
        $userId = null;
        try {
            $headers = function_exists('getallheaders') ? getallheaders() : [];
            $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ($_GET['token'] ?? ($_POST['token'] ?? ''))));
            $token = '';
            if (str_starts_with($authHeader, 'Bearer ')) {
                $token = substr($authHeader, 7);
            } else {
                $token = $authHeader;
            }
            if (!empty($token)) {
                $uid = verifyAuthToken($token);
                if ($uid) {
                    $userId = (int)$uid;
                } else {
                    $uStmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? LIMIT 1");
                    $uStmt->bind_param("s", $token);
                    $uStmt->execute();
                    $uRow = $uStmt->get_result()->fetch_assoc();
                    $uStmt->close();
                    if ($uRow) $userId = (int)$uRow['id'];
                }
            }
        } catch (Throwable $e) {}
        $eventData = getActiveGachaEventData($db, $userId);
        jsonResponse([
            'status' => 'success',
            'data' => $eventData
        ]);
        break;

    case 'roll_event_gacha':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $packCount = max(1, min(10, (int)($input['pack_count'] ?? 1)));
        $category = strtoupper(trim((string)($input['category'] ?? 'ALL')));
        if (!in_array($category, ['FRAME', 'DICE', 'ALL'], true)) {
            $category = 'ALL';
        }
        $currency = strtoupper(trim((string)($input['currency'] ?? 'DIAMOND')));
        if (!in_array($currency, ['DIAMOND', 'GOLD'], true)) {
            $currency = 'DIAMOND';
        }
        $packTier = strtoupper(trim((string)($input['pack_tier'] ?? 'SPECIAL')));
        if (!in_array($packTier, ['SPECIAL', 'NORMAL', 'PREMIUM'], true)) {
            $packTier = 'SPECIAL';
        }
        $result = executeEventGachaPull($db, (int)$user['id'], $packCount, $category, $currency, $packTier);
        if (($result['status'] ?? '') === 'error') {
            jsonResponse($result, 400);
        }
        jsonResponse($result);
        break;

    case 'get_user_cubes':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubesData = getUserCubesList($db, (int)$user['id']);
        jsonResponse([
            'status' => 'success',
            'data' => $cubesData
        ]);
        break;

    case 'equip_cube_to_slot':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubeId = (int)($input['user_cube_id'] ?? 0);
        $slotIndex = (int)($input['slot_index'] ?? 1);
        try {
            $result = equipCubeToSlotAction($db, (int)$user['id'], $cubeId, $slotIndex);
            jsonResponse($result);
        } catch (Exception $e) {
            jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
        break;

    case 'remove_cube_from_slot':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubeId = (int)($input['user_cube_id'] ?? 0);
        try {
            $result = removeCubeFromSlotAction($db, (int)$user['id'], $cubeId);
            jsonResponse($result);
        } catch (Exception $e) {
            jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
        break;

    case 'start_spin_cube':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubeId = (int)($input['user_cube_id'] ?? 0);
        $currency = trim($input['currency'] ?? 'DIAMOND');
        $slotIndex = (int)($input['slot_index'] ?? 0);
        try {
            $result = startSpinningCubeAction($db, (int)$user['id'], $cubeId, $currency, $slotIndex);
            jsonResponse($result);
        } catch (Exception $e) {
            jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
        break;

    case 'speedup_cube':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubeId = (int)($input['user_cube_id'] ?? 0);
        $result = instantSpeedupCube($db, (int)$user['id'], $cubeId);
        if (($result['status'] ?? '') === 'error') {
            jsonResponse($result, 400);
        }
        jsonResponse($result);
        break;

    case 'claim_cube_reward':
        ensureCubeAndEventTables($db);
        $user = requireAuth($db);
        $cubeId = (int)($input['user_cube_id'] ?? 0);
        $result = claimCubeRewardAction($db, (int)$user['id'], $cubeId);
        if (($result['status'] ?? '') === 'error') {
            jsonResponse($result, 400);
        }
        jsonResponse($result);
        break;

    default:
        jsonResponse(['status' => 'error', 'message' => 'Invalid shop action'], 400);
}

/**
 * Perform single card draw for Gacha Pack
 * Rates configured by Admin:
 * - SHADOW_BLACK_A: rate_shadow_black (default 90%)
 * - SHADOW_RED_A: rate_shadow_red (default 80%)
 * - SHADOW_ORANGE_A: rate_shadow_orange (default 70%)
 * - SHADOW_BLUE_APLUS: rate_shadow_blue (default 50%)
 * - SHADOW_GOLD_S: rate_shadow_gold (default 10%)
 * - S+ Target Frame Jackpot: rate_splus (default 3%)
 * - SPECIAL_CARD: rate_shadow_special (default 15%)
 */
function performSingleGachaCardDrop(mysqli $db, int $userId, ?array $gachaEvent = null, string $category = 'ALL', string $packTier = 'SPECIAL'): array {
    if (!$gachaEvent) {
        $gachaEvent = $db->query("SELECT * FROM gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1")->fetch_assoc();
        if (!$gachaEvent) {
            $gachaEvent = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
        }
    }

    $rBlack = max(0, (float)($gachaEvent['rate_shadow_black'] ?? 90.0));
    $rRed = max(0, (float)($gachaEvent['rate_shadow_red'] ?? 80.0));
    $rOrange = max(0, (float)($gachaEvent['rate_shadow_orange'] ?? 70.0));
    $rBlue = max(0, (float)($gachaEvent['rate_shadow_blue'] ?? 50.0));
    $rGold = max(0, (float)($gachaEvent['rate_shadow_gold'] ?? 10.0));
    $rSpecial = max(0, (float)($gachaEvent['rate_shadow_special'] ?? 15.0));
    $rSPlus = max(0, (float)($gachaEvent['rate_splus'] ?? 3.0));

    if ($packTier === 'PREMIUM') {
        $rBlack *= 0.25;
        $rRed *= 0.35;
        $rOrange *= 0.50;
        $rBlue *= 1.85;
        $rGold *= 2.50;
        $rSPlus *= 2.00;
    } elseif ($packTier === 'NORMAL') {
        $rGold *= 0.45;
        $rSPlus *= 0.25;
    }

    $customBySlot = [];
    if (!empty($gachaEvent['shadow_config_json'])) {
        $sArr = json_decode($gachaEvent['shadow_config_json'], true);
        if (is_array($sArr)) {
            foreach ($sArr as $sObj) {
                if (!empty($sObj['slot'])) {
                    $customBySlot[$sObj['slot']] = $sObj;
                }
            }
        }
    }

    $isDiceOnly = ($category === 'DICE');
    $isFrameOnly = ($category === 'FRAME');

    $slotDefs = [
        'black'  => ['code' => 'SHADOW_BLACK_A',    'name' => $isDiceOnly ? 'เงาลูกเต๋าดำ ระดับ A'   : ($isFrameOnly ? 'เงากรอบรูปดำ ระดับ A'   : 'การ์ดเงาสีดำ ระดับ A'),   'rarity' => 'A',  'icon' => $isDiceOnly ? '🎲' : '⬛', 'color' => '#64748b', 'weight' => $rBlack],
        'red'    => ['code' => 'SHADOW_RED_A',      'name' => $isDiceOnly ? 'เงาลูกเต๋าแดง ระดับ A'  : ($isFrameOnly ? 'เงากรอบรูปแดง ระดับ A'  : 'การ์ดเงาสีแดง ระดับ A'),  'rarity' => 'A',  'icon' => $isDiceOnly ? '🎲' : '🟥', 'color' => '#ef4444', 'weight' => $rRed],
        'orange' => ['code' => 'SHADOW_ORANGE_A',   'name' => $isDiceOnly ? 'เงาลูกเต๋าส้ม ระดับ A'  : ($isFrameOnly ? 'เงากรอบรูปส้ม ระดับ A'  : 'การ์ดเงาสีส้ม ระดับ A'),  'rarity' => 'A',  'icon' => $isDiceOnly ? '🎲' : '🟧', 'color' => '#ff8800', 'weight' => $rOrange],
        'blue'   => ['code' => 'SHADOW_BLUE_APLUS', 'name' => $isDiceOnly ? 'เงาลูกเต๋าฟ้า ระดับ A+' : ($isFrameOnly ? 'เงากรอบรูปฟ้า ระดับ A+' : 'การ์ดเงาสีฟ้า ระดับ A+'), 'rarity' => 'A+', 'icon' => $isDiceOnly ? '🎲' : '🟦', 'color' => '#38bdf8', 'weight' => $rBlue],
        'gold'   => ['code' => 'SHADOW_GOLD_S',     'name' => $isDiceOnly ? 'เงาลูกเต๋าทอง ระดับ S'  : ($isFrameOnly ? 'เงากรอบรูปทอง ระดับ S'  : 'การ์ดเงาสีทอง ระดับ S'),  'rarity' => 'S',  'icon' => $isDiceOnly ? '🎲' : '🟨', 'color' => '#ffd700', 'weight' => $rGold],
    ];

    $pool = [];
    foreach ($slotDefs as $slotKey => $def) {
        $cObj = $customBySlot[$slotKey] ?? [];
        $w = isset($cObj['rate']) ? max(0, (float)$cObj['rate']) : $def['weight'];
        $itemName = (!empty($cObj['name']) && !$isDiceOnly && !$isFrameOnly) ? $cObj['name'] : $def['name'];
        $pool[] = [
            'type' => 'MATERIAL',
            'category' => $isDiceOnly ? 'DICE' : 'FRAME',
            'material_code' => $def['code'],
            'name' => $itemName,
            'rarity' => !empty($cObj['grade']) ? $cObj['grade'] : $def['rarity'],
            'icon' => $def['icon'],
            'color' => !empty($cObj['color']) ? $cObj['color'] : $def['color'],
            'aura' => !empty($cObj['aura']) ? $cObj['aura'] : 'none',
            'intensity' => isset($cObj['intensity']) ? (int)$cObj['intensity'] : 100,
            'image_url' => (!$isDiceOnly && !empty($cObj['image_url'])) ? $cObj['image_url'] : '',
            'weight' => $w
        ];
    }

    $pool[] = [
        'type' => 'MATERIAL',
        'category' => $isDiceOnly ? 'DICE' : 'FRAME',
        'material_code' => 'SPECIAL_CARD',
        'name' => $isDiceOnly ? 'แกนลูกเต๋าปลุกพลังพิเศษ S' : 'การ์ดกรอบปลุกพลังพิเศษ S',
        'rarity' => 'S',
        'icon' => $isDiceOnly ? '🎲' : '✨',
        'color' => $isDiceOnly ? '#00e5ff' : '#a855f7',
        'aura' => $isDiceOnly ? 'cyan' : 'purple',
        'intensity' => 110,
        'image_url' => '',
        'weight' => $rSpecial
    ];

    if (!$isDiceOnly && $rSPlus > 0) {
        $targetCharId = (int)($gachaEvent['target_character_id'] ?? 1);
        $tChar = $db->query("SELECT id, name, grade, aura_type, aura_intensity, avatar_url FROM characters WHERE id = {$targetCharId} LIMIT 1")->fetch_assoc();
        $targetName = $tChar['name'] ?? 'พญานาคราช 3D';
        $targetGrade = $tChar['grade'] ?? 'S+';
        $pool[] = [
            'type' => 'CHARACTER',
            'category' => 'FRAME',
            'material_code' => null,
            'name' => "กรอบรูป '{$targetName}' ระดับ {$targetGrade}",
            'rarity' => $targetGrade,
            'icon' => '👑',
            'color' => '#ffd700',
            'aura' => $tChar['aura_type'] ?? 'gold',
            'intensity' => (int)($tChar['aura_intensity'] ?? 120),
            'image_url' => $tChar['avatar_url'] ?? '',
            'character_id' => $targetCharId,
            'weight' => $rSPlus
        ];
    }

    // กิจกรรมสุ่มลูกเต๋าเป้าหมายประจำกิจกรรม (Target Dice Drop in Dice Gacha Event)
    if (!$isFrameOnly) {
        $dEvRes = $db->query("SELECT * FROM dice_gacha_events WHERE is_active = 1 AND NOW() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1");
        $activeDiceEv = ($dEvRes && $dEvRes->num_rows > 0) ? $dEvRes->fetch_assoc() : null;
        if (!$activeDiceEv) {
            $dEvRes2 = $db->query("SELECT * FROM dice_gacha_events WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
            $activeDiceEv = ($dEvRes2 && $dEvRes2->num_rows > 0) ? $dEvRes2->fetch_assoc() : null;
        }
        $targetDiceId = $activeDiceEv ? (int)$activeDiceEv['target_dice_id'] : (int)($gachaEvent['target_dice_id'] ?? 1);
        if ($targetDiceId > 0) {
            $tDice = $db->query("SELECT * FROM dice WHERE id = {$targetDiceId} LIMIT 1")->fetch_assoc();
            if ($tDice) {
                $diceBoost = max(0.0, (float)($activeDiceEv['rate_target_boost'] ?? ($gachaEvent['rate_target_boost'] ?? 35.0)));
                $baseDiceRate = max(1.0, (float)($gachaEvent['rate_splus'] ?? 3.0));
                $diceWeight = $baseDiceRate * (1.0 + ($diceBoost / 100.0));
                $pool[] = [
                    'type' => 'DICE',
                    'category' => 'DICE',
                    'material_code' => null,
                    'name' => "ลูกเต๋า '{$tDice['name']}' ระดับ {$tDice['grade']}",
                    'rarity' => $tDice['grade'] ?? 'S+',
                    'icon' => '🎲',
                    'color' => $tDice['color_hex'] ?? '#00e5ff',
                    'aura' => $tDice['aura_type'] ?? 'cyan',
                    'intensity' => (int)($tDice['aura_intensity'] ?? 100),
                    'image_url' => $tDice['image_url'] ?? '',
                    'dice_id' => $targetDiceId,
                    'weight' => $diceWeight
                ];
            }
        }
    }

    $totalWeight = 0;
    foreach ($pool as $p) {
        $totalWeight += $p['weight'];
    }
    if ($totalWeight <= 0) $totalWeight = 100.0;

    $rand = (mt_rand(1, 100000) / 100000.0) * $totalWeight;
    $current = 0;
    $chosen = $pool[0];
    foreach ($pool as $item) {
        if ($item['weight'] <= 0) continue;
        $current += $item['weight'];
        if ($rand <= $current) {
            $chosen = $item;
            break;
        }
    }

    // Grant
    if ($chosen['type'] === 'MATERIAL' && !empty($chosen['material_code'])) {
        $stmt = $db->prepare("
            INSERT INTO user_materials (user_id, material_code, quantity) 
            VALUES (?, ?, 1) 
            ON DUPLICATE KEY UPDATE quantity = quantity + 1
        ");
        $stmt->bind_param("is", $userId, $chosen['material_code']);
        $stmt->execute();
        $stmt->close();
    } elseif ($chosen['type'] === 'CHARACTER') {
        $cId = (int)$chosen['character_id'];
        $chk = $db->prepare("SELECT id FROM user_inventory WHERE user_id = ? AND character_id = ?");
        $chk->bind_param("ii", $userId, $cId);
        $chk->execute();
        if (!$chk->get_result()->fetch_assoc()) {
            $add = $db->prepare("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES (?, 'CHARACTER', ?, 1, 0)");
            $add->bind_param("ii", $userId, $cId);
            $add->execute();
            $add->close();
        }
        $chk->close();
    } elseif ($chosen['type'] === 'DICE') {
        $dId = (int)$chosen['dice_id'];
        $chk = $db->prepare("SELECT id FROM user_inventory WHERE user_id = ? AND item_type = 'DICE' AND dice_id = ?");
        $chk->bind_param("ii", $userId, $dId);
        $chk->execute();
        $hasDice = (bool)$chk->get_result()->fetch_assoc();
        $chk->close();
        if (!$hasDice) {
            $add = $db->prepare("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES (?, 'DICE', ?, 1, 0)");
            $add->bind_param("ii", $userId, $dId);
            $add->execute();
            $add->close();
        } else {
            // โบนัสชดเชยเมื่อสุ่มได้ลูกเต๋าซ้ำ: มอบ 50,000 ทอง
            $db->query("UPDATE users SET gold = gold + 50000 WHERE id = {$userId}");
            $chosen['name'] .= " (มีแล้ว: รับชดเชย +50,000 ทอง)";
        }
    }

    return [
        'type' => $chosen['type'],
        'material_code' => $chosen['material_code'] ?? null,
        'character_id' => $chosen['character_id'] ?? null,
        'dice_id' => $chosen['dice_id'] ?? null,
        'name' => $chosen['name'],
        'rarity' => $chosen['rarity'],
        'icon' => $chosen['icon'],
        'color' => $chosen['color'],
        'aura' => $chosen['aura'] ?? 'none',
        'intensity' => $chosen['intensity'] ?? 100,
        'image_url' => $chosen['image_url'] ?? ''
    ];
}

function performGachaDrop(mysqli $db, int $userId, ?array $gachaEvent = null): array {
    return performSingleGachaCardDrop($db, $userId, $gachaEvent);
}

/**
 * โหลดค่าการขายไอเทมทุกชนิด (จำนวน + สกุลเงิน DIAMOND หรือ GOLD) ตามที่ Admin กำหนด
 */
function buildSellPriceCatalog(mysqli $db): array {
    $res = $db->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'SELL_PRICE_%' OR setting_key LIKE 'SELL_CURRENCY_%'");
    $raw = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $raw[$row['setting_key']] = $row['setting_value'];
        }
    }

    $fallbackShadowA = isset($raw['SELL_PRICE_SHADOW_A']) ? (int)$raw['SELL_PRICE_SHADOW_A'] : 20;
    $fallbackShadowAPlus = isset($raw['SELL_PRICE_SHADOW_APLUS']) ? (int)$raw['SELL_PRICE_SHADOW_APLUS'] : 50;
    $fallbackShadowCurrA = strtoupper($raw['SELL_CURRENCY_SHADOW_A'] ?? 'DIAMOND');
    $fallbackShadowCurrAPlus = strtoupper($raw['SELL_CURRENCY_SHADOW_APLUS'] ?? 'DIAMOND');

    $defaults = [
        'CHAR_SSPLUS' => ['amount' => 1000, 'currency' => 'DIAMOND'],
        'CHAR_SPLUS' => ['amount' => 400, 'currency' => 'DIAMOND'],
        'CHAR_S' => ['amount' => 250, 'currency' => 'DIAMOND'],
        'CHAR_APLUS' => ['amount' => 150, 'currency' => 'DIAMOND'],
        'CHAR_A' => ['amount' => 100, 'currency' => 'DIAMOND'],
        'CHAR_B' => ['amount' => 40, 'currency' => 'DIAMOND'],
        'DICE_SSPLUS' => ['amount' => 800, 'currency' => 'DIAMOND'],
        'DICE_SPLUS' => ['amount' => 600, 'currency' => 'DIAMOND'],
        'DICE_LEGENDARY' => ['amount' => 500, 'currency' => 'DIAMOND'],
        'DICE_EPIC' => ['amount' => 200, 'currency' => 'DIAMOND'],
        'DICE_RARE' => ['amount' => 80, 'currency' => 'DIAMOND'],
        'DICE_NORMAL' => ['amount' => 30, 'currency' => 'DIAMOND'],
        'SHADOW_BLACK_A' => ['amount' => $fallbackShadowA, 'currency' => $fallbackShadowCurrA],
        'SHADOW_RED_A' => ['amount' => $fallbackShadowA, 'currency' => $fallbackShadowCurrA],
        'SHADOW_ORANGE_A' => ['amount' => $fallbackShadowA, 'currency' => $fallbackShadowCurrA],
        'SHADOW_BLUE_APLUS' => ['amount' => isset($raw['SELL_PRICE_SHADOW_A']) ? (int)$raw['SELL_PRICE_SHADOW_A'] : 35, 'currency' => $fallbackShadowCurrA],
        'SHADOW_GOLD_S' => ['amount' => $fallbackShadowAPlus, 'currency' => $fallbackShadowCurrAPlus],
        'SPECIAL_CARD' => ['amount' => 80, 'currency' => 'DIAMOND']
    ];

    $prices = [];
    $currencies = [];
    $items = [];

    foreach ($defaults as $code => $def) {
        $pKey = 'SELL_PRICE_' . $code;
        $cKey = 'SELL_CURRENCY_' . $code;
        $amt = isset($raw[$pKey]) ? max(0, (int)$raw[$pKey]) : $def['amount'];
        $curr = strtoupper(trim($raw[$cKey] ?? $def['currency']));
        if ($curr !== 'GOLD' && $curr !== 'DIAMOND') {
            $curr = 'DIAMOND';
        }
        $prices[$pKey] = $amt;
        $currencies[$cKey] = $curr;
        $items[$code] = [
            'amount' => $amt,
            'currency' => $curr
        ];
    }

    // Preserve legacy keys for compatibility
    $prices['SELL_PRICE_SHADOW_A'] = $items['SHADOW_BLACK_A']['amount'];
    $prices['SELL_PRICE_SHADOW_APLUS'] = $items['SHADOW_GOLD_S']['amount'];
    $currencies['SELL_CURRENCY_SHADOW_A'] = $items['SHADOW_BLACK_A']['currency'];
    $currencies['SELL_CURRENCY_SHADOW_APLUS'] = $items['SHADOW_GOLD_S']['currency'];

    return [
        'prices' => $prices,
        'currencies' => $currencies,
        'items' => $items
    ];
}

