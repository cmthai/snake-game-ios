<?php
declare(strict_types=1);

/**
 * api/ota_deploy_service.php
 * Core OTA (Over-The-Air) Game Update & Cache Busting Engine for Web, Android & iOS
 */

require_once __DIR__ . '/../config/database.php';

// Polyfills for PHP 7.4 compatibility
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return $needle === '' || $needle === substr($haystack, -strlen($needle));
    }
}

function ensureOtaDeploymentsTable(mysqli $db): void {
    static $ensured = false;
    if ($ensured) return;
    $ensured = true;

    $stamp = __DIR__ . '/../config/.ota_schema_v2.stamp';
    if (@file_exists($stamp)) return;

    $db->query("CREATE TABLE IF NOT EXISTS `system_settings` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `setting_key` VARCHAR(100) NOT NULL,
        `setting_value` TEXT NULL,
        `description` VARCHAR(255) NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_sys_setting_key` (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    $db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `setting_key` VARCHAR(100) NOT NULL,
        `setting_value` TEXT NULL,
        `category` VARCHAR(50) DEFAULT 'general',
        `description` VARCHAR(255) NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_game_setting_key` (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    $db->query("CREATE TABLE IF NOT EXISTS `ota_deployments` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `version_code` VARCHAR(50) NOT NULL DEFAULT '1.0.0',
        `cache_buster` BIGINT UNSIGNED NOT NULL,
        `release_note` VARCHAR(255) NULL,
        `force_clear_cache` TINYINT(1) NOT NULL DEFAULT 0,
        `deployed_by` VARCHAR(100) NOT NULL DEFAULT 'Admin',
        `affected_files_count` INT NOT NULL DEFAULT 0,
        `affected_files_json` TEXT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_cache_buster` (`cache_buster`),
        KEY `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    @file_put_contents($stamp, (string)time());
}

function calculateOtaBundleSize(): string {
    $totalBytes = 0;
    $scanDirs = [__DIR__ . '/../css', __DIR__ . '/../js'];
    foreach ($scanDirs as $sDir) {
        if (is_dir($sDir)) {
            $files = @glob($sDir . '/*.*');
            if (is_array($files)) {
                foreach ($files as $filePath) {
                    if (is_file($filePath)) {
                        $totalBytes += (int)(@filesize($filePath) ?: 0);
                    }
                }
            }
        }
    }
    $indexPath = __DIR__ . '/../index.html';
    if (is_file($indexPath)) {
        $totalBytes += (int)(@filesize($indexPath) ?: 0);
    }
    if ($totalBytes >= 1048576) {
        return number_format($totalBytes / 1048576, 1) . ' MB';
    } elseif ($totalBytes >= 1024) {
        return number_format($totalBytes / 1024, 0) . ' KB';
    }
    return '2.8 MB';
}

function analyzeOtaUpdateSize(?mysqli $db = null): array {
    if ($db instanceof mysqli) {
        ensureOtaDeploymentsTable($db);
    }
    $totalBytes = 0;
    $breakdown = [];
    $scanDirs = ['css' => __DIR__ . '/../css', 'js' => __DIR__ . '/../js'];
    foreach ($scanDirs as $type => $sDir) {
        if (is_dir($sDir)) {
            $files = @glob($sDir . '/*.*');
            if (is_array($files)) {
                foreach ($files as $fp) {
                    if (is_file($fp)) {
                        $sz = (int)(@filesize($fp) ?: 0);
                        $totalBytes += $sz;
                        $breakdown[] = [
                            'file' => $type . '/' . basename($fp),
                            'bytes' => $sz,
                            'mtime' => (int)(@filemtime($fp) ?: 0)
                        ];
                    }
                }
            }
        }
    }
    $indexPath = __DIR__ . '/../index.html';
    if (is_file($indexPath)) {
        $sz = (int)(@filesize($indexPath) ?: 0);
        $totalBytes += $sz;
        $breakdown[] = [
            'file' => 'index.html',
            'bytes' => $sz,
            'mtime' => (int)(@filemtime($indexPath) ?: 0)
        ];
    }

    $fileCount = count($breakdown);
    $formatted = $totalBytes >= 1048576
        ? number_format($totalBytes / 1048576, 2) . ' MB'
        : number_format(max(1, (int)round($totalBytes / 1024)), 0) . ' KB';
    $fileCountText = $fileCount . ' ไฟล์';

    return [
        'total_bytes' => $totalBytes,
        'update_size' => $formatted,
        'file_count' => $fileCount,
        'files_count' => $fileCount,
        'update_files' => $fileCount,
        'update_files_text' => $fileCountText,
        'recommended_size' => $formatted,
        'previous_bundle_formatted' => $formatted,
        'current_bundle_formatted' => $formatted,
        'diff_formatted' => '0 KB',
        'analysis_summary' => 'AI คำนวณขนาดและจำนวนไฟล์อัปเดต: ' . $formatted . ' (' . $fileCountText . ')',
        'files' => $breakdown
    ];
}

function getOtaStatusInfo(mysqli $db): array {
    ensureOtaDeploymentsTable($db);

    $configJson = [];
    $configFile = __DIR__ . '/../config/ota_version.json';
    if (file_exists($configFile)) {
        $raw = @file_get_contents($configFile);
        if ($raw) {
            $configJson = json_decode($raw, true) ?: [];
        }
    }

    $settingsRes = $db->query("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN (
            'MOBILE_APP_GAME_URL',
            'MOBILE_APP_VERSION',
            'MOBILE_APP_CACHE_BUSTER',
            'MOBILE_APP_FORCE_CLEAR_CACHE',
            'MOBILE_APP_MAINTENANCE',
            'MOBILE_APP_MAINTENANCE_MSG',
            'OTA_UPDATE_SIZE',
            'OTA_UPDATE_FILES',
            'OTA_LAST_DEPLOY_TIMESTAMP',
            'OTA_LAST_DEPLOY_TIME',
            'OTA_LAST_RELEASE_NOTE'
        )
    ");

    $settings = [];
    if ($settingsRes) {
        while ($row = $settingsRes->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }

    $history = [];
    $histRes = $db->query("SELECT * FROM `ota_deployments` ORDER BY `id` DESC LIMIT 10");
    if ($histRes) {
        while ($h = $histRes->fetch_assoc()) {
            $history[] = [
                'id' => (int)$h['id'],
                'version_code' => $h['version_code'],
                'cache_buster' => (int)$h['cache_buster'],
                'release_note' => $h['release_note'],
                'force_clear_cache' => (bool)$h['force_clear_cache'],
                'deployed_by' => $h['deployed_by'],
                'affected_files_count' => (int)$h['affected_files_count'],
                'created_at' => $h['created_at']
            ];
        }
    }

    $dbBuster = isset($settings['MOBILE_APP_CACHE_BUSTER']) ? (int)$settings['MOBILE_APP_CACHE_BUSTER'] : 0;
    $jsonBuster = isset($configJson['cache_buster']) ? (int)$configJson['cache_buster'] : 0;
    $currentCacheBuster = max($dbBuster, $jsonBuster, 126);

    $aiAnalysis = analyzeOtaUpdateSize($db);
    $updateSize = $settings['OTA_UPDATE_SIZE'] ?? ($configJson['update_size'] ?? $aiAnalysis['update_size']);
    $updateFiles = isset($settings['OTA_UPDATE_FILES']) && (int)$settings['OTA_UPDATE_FILES'] > 0
        ? (int)$settings['OTA_UPDATE_FILES']
        : (isset($configJson['file_count']) ? (int)$configJson['file_count'] : $aiAnalysis['files_count']);

    return [
        'status' => 'success',
        'app_version' => $settings['MOBILE_APP_VERSION'] ?? ($configJson['version'] ?? '1.0.0'),
        'cache_buster' => $currentCacheBuster,
        'game_url' => $settings['MOBILE_APP_GAME_URL'] ?? ($configJson['game_url'] ?? 'https://pmix01.thddns.net:7175/home/snake/'),
        'force_clear_cache' => !empty($settings['MOBILE_APP_FORCE_CLEAR_CACHE']) && ($settings['MOBILE_APP_FORCE_CLEAR_CACHE'] === '1' || $settings['MOBILE_APP_FORCE_CLEAR_CACHE'] === 'true'),
        'maintenance' => !empty($settings['MOBILE_APP_MAINTENANCE']) && ($settings['MOBILE_APP_MAINTENANCE'] === '1' || $settings['MOBILE_APP_MAINTENANCE'] === 'true'),
        'maintenance_message' => $settings['MOBILE_APP_MAINTENANCE_MSG'] ?? 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง',
        'update_size' => $updateSize,
        'file_count' => $updateFiles,
        'update_files' => $updateFiles,
        'update_files_text' => $updateFiles . ' ไฟล์',
        'ai_size_analysis' => $aiAnalysis,
        'last_deploy_time' => $settings['OTA_LAST_DEPLOY_TIME'] ?? ($configJson['last_deployed_at'] ?? null),
        'last_release_note' => $settings['OTA_LAST_RELEASE_NOTE'] ?? ($configJson['release_note'] ?? 'ยังไม่มีประวัติการปล่อยอัปเดต'),
        'deploy_history' => $history,
        'server_time' => date('Y-m-d H:i:s'),
        'timestamp' => time()
    ];
}

function executeOtaDeploy(mysqli $db, array $options = []): array {
    ensureOtaDeploymentsTable($db);

    $prevInfo = getOtaStatusInfo($db);
    $prevBuster = isset($prevInfo['cache_buster']) ? (int)$prevInfo['cache_buster'] : 0;
    $timestamp = max(time(), $prevBuster + 1);

    $versionCode = trim((string)($options['app_version'] ?? '1.0.0'));
    if (empty($versionCode)) $versionCode = '1.0.0';

    $releaseNote = trim((string)($options['release_note'] ?? ''));
    if (empty($releaseNote)) {
        $releaseNote = 'Deploy Update to Mobile (OTA) #' . date('Ymd_His');
    }

    $forceClearCache = !empty($options['force_clear_cache']);
    $deployedBy = trim((string)($options['deployed_by'] ?? 'Admin'));
    if (empty($deployedBy)) $deployedBy = 'Admin';

    $analysis = analyzeOtaUpdateSize($db);
    $updateSize = trim((string)($options['update_size'] ?? ''));
    if (empty($updateSize)) {
        $updateSize = $analysis['update_size'];
    }
    $fileCount = !empty($options['file_count']) ? (int)$options['file_count'] : (
        !empty($options['update_files']) ? (int)$options['update_files'] : $analysis['files_count']
    );
    if ($fileCount <= 0) {
        $fileCount = $analysis['files_count'];
    }

    $gameUrl = trim((string)($options['game_url'] ?? 'https://pmix01.thddns.net:7175/home/snake/'));
    if (!empty($gameUrl) && !str_ends_with($gameUrl, '/')) {
        $gameUrl .= '/';
    }

    try {
        $stmt = $db->prepare("
            INSERT INTO system_settings (setting_key, setting_value, description)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");

        $items = [
            ['MOBILE_APP_GAME_URL', $gameUrl, 'URL เว็บเกมหลักสำหรับแอปมือถือ'],
            ['MOBILE_APP_VERSION', $versionCode, 'เวอร์ชันแอปมือถือ'],
            ['MOBILE_APP_CACHE_BUSTER', (string)$timestamp, 'รหัสเวอร์ชันแคช OTA (Timestamp)'],
            ['MOBILE_APP_FORCE_CLEAR_CACHE', $forceClearCache ? '1' : '0', 'บังคับแอปมือถือเคลียร์แคชทันที'],
            ['OTA_UPDATE_SIZE', $updateSize, 'ขนาดไฟล์อัปเดตสำหรับแจ้งเตือนผู้เล่น'],
            ['OTA_UPDATE_FILES', (string)$fileCount, 'จำนวนไฟล์อัปเดตสำหรับแจ้งเตือนผู้เล่น'],
            ['OTA_LAST_DEPLOY_TIMESTAMP', (string)$timestamp, 'Timestamp ที่สั่ง Deploy ล่าสุด'],
            ['OTA_LAST_DEPLOY_TIME', date('Y-m-d H:i:s'), 'วันเวลาที่สั่ง Deploy ล่าสุด'],
            ['OTA_LAST_RELEASE_NOTE', $releaseNote, 'บันทึกการปล่อยอัปเดตล่าสุด']
        ];

        if ($stmt) {
            foreach ($items as $item) {
                $stmt->bind_param("sss", $item[0], $item[1], $item[2]);
                $stmt->execute();
            }
            $stmt->close();
        }
    } catch (Throwable $e) {
        error_log("OTA system_settings warning: " . $e->getMessage());
    }

    $configDir = __DIR__ . '/../config';
    if (!is_dir($configDir)) {
        @mkdir($configDir, 0777, true);
    }
    $configFile = $configDir . '/ota_version.json';
    @chmod($configFile, 0666);
    $configPayload = [
        'status' => 'success',
        'version' => $versionCode,
        'cache_buster' => $timestamp,
        'game_url' => $gameUrl,
        'force_clear_cache' => $forceClearCache,
        'update_size' => $updateSize,
        'file_count' => $fileCount,
        'update_files' => $fileCount,
        'update_files_text' => $fileCount . ' ไฟล์',
        'bundle_bytes' => $analysis['total_bytes'],
        'last_deployed_at' => date('Y-m-d H:i:s'),
        'deployed_at' => date('Y-m-d H:i:s'),
        'deployed_by' => $deployedBy,
        'release_note' => $releaseNote,
        'target_scripts' => [
            'css/style.css',
            'js/sound_engine.js',
            'js/thai_audio_manager.js',
            'js/realistic_avatars.js',
            'js/api_client.js',
            'js/game3d.js',
            'js/clan_house3d.js',
            'js/clan_directory.js',
            'js/ota_client.js',
            'js/ui.js',
            'js/ui_events.js',
            'js/shop_showcase.js'
        ]
    ];
    $jsonEncoded = json_encode($configPayload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $tmpCfg = $configFile . '.tmp_' . getmypid();
    if (@file_put_contents($tmpCfg, $jsonEncoded) !== false) {
        @chmod($tmpCfg, 0666);
        @rename($tmpCfg, $configFile);
    } else {
        @file_put_contents($configFile, $jsonEncoded);
    }

    // ซิงก์ ota_version.json ไปยัง www และ iOS public bundle
    @mkdir(__DIR__ . '/../www/config', 0777, true);
    @copy($configFile, __DIR__ . '/../www/config/ota_version.json');
    if (@is_dir(__DIR__ . '/../ios/App/App/public')) {
        @mkdir(__DIR__ . '/../ios/App/App/public/config', 0777, true);
        @copy($configFile, __DIR__ . '/../ios/App/App/public/config/ota_version.json');
    }

    $indexPath = realpath(__DIR__ . '/../index.html');
    if (!$indexPath) {
        $indexPath = dirname(__DIR__) . '/index.html';
    }
    $affectedFiles = [];

    if (file_exists($indexPath) && is_readable($indexPath)) {
        @chmod($indexPath, 0666);
        $htmlContent = @file_get_contents($indexPath);

        if ($htmlContent !== false) {
            $rCss = preg_replace_callback(
                '/(<link[^>]+href=["\'])(css\/[a-zA-Z0-9_\-\.]+\.css)(?:\?v=[^"\']*)?(["\'])/i',
                function($matches) use ($timestamp, &$affectedFiles) {
                    $affectedFiles[] = $matches[2];
                    return $matches[1] . $matches[2] . '?v=' . $timestamp . $matches[3];
                },
                $htmlContent
            );
            if ($rCss !== null) $htmlContent = $rCss;

            $rJs = preg_replace_callback(
                '/(<script[^>]+src=["\'])(js\/[a-zA-Z0-9_\-\.]+\.js)(?:\?v=[^"\']*)?(["\'])/i',
                function($matches) use ($timestamp, &$affectedFiles) {
                    $affectedFiles[] = $matches[2];
                    return $matches[1] . $matches[2] . '?v=' . $timestamp . $matches[3];
                },
                $htmlContent
            );
            if ($rJs !== null) $htmlContent = $rJs;

            if (str_contains($htmlContent, '__GAME_OTA_VERSION__')) {
                $rV = preg_replace(
                    '/window\.__GAME_OTA_VERSION__\s*=\s*["\'][^"\']*["\'];/i',
                    'window.__GAME_OTA_VERSION__ = "' . $timestamp . '";',
                    $htmlContent
                );
                if ($rV !== null) $htmlContent = $rV;
            } else {
                $injectCode = "\n    <meta name=\"game-ota-version\" content=\"{$timestamp}\">\n    <script>window.__GAME_OTA_VERSION__ = \"{$timestamp}\";</script>";
                $rInj = preg_replace('/(<head[^>]*>)/i', '$1' . $injectCode, $htmlContent, 1);
                if ($rInj !== null) $htmlContent = $rInj;
            }

            if (str_contains($htmlContent, 'name="game-ota-version"')) {
                $rM = preg_replace(
                    '/<meta\s+name=["\']game-ota-version["\']\s+content=["\'][^"\']*["\']>/i',
                    '<meta name="game-ota-version" content="' . $timestamp . '">',
                    $htmlContent
                );
                if ($rM !== null) $htmlContent = $rM;
            }

            $tmpHtml = $indexPath . '.tmp_' . getmypid();
            if (@file_put_contents($tmpHtml, $htmlContent) !== false) {
                @chmod($tmpHtml, 0666);
                @rename($tmpHtml, $indexPath);
            } else {
                @file_put_contents($indexPath, $htmlContent);
            }
            @copy($indexPath, __DIR__ . '/../www/index.html');
            if (@is_dir(__DIR__ . '/../ios/App/App/public')) {
                @copy($indexPath, __DIR__ . '/../ios/App/App/public/index.html');
            }

            // ซิงก์ไฟล์สคริปต์และสไตล์ชีทล่าสุดไปยัง www และ iOS bundle
            $syncTargets = [
                'js/ota_client.js',
                'js/shop_showcase.js',
                'js/sound_engine.js',
                'js/thai_audio_manager.js',
                'js/game3d.js',
                'js/ui.js',
                'js/ui_events.js',
                'css/style.css',
                'api/boards.php',
                'api/board_studio_service.php',
                'admin/admin_panel.php',
                'admin/js/admin_board_studio.js'
            ];
            foreach ($syncTargets as $st) {
                $src = __DIR__ . '/../' . $st;
                if (file_exists($src)) {
                    $dstWww = __DIR__ . '/../www/' . $st;
                    @mkdir(dirname($dstWww), 0777, true);
                    @copy($src, $dstWww);
                    if (@is_dir(__DIR__ . '/../ios/App/App/public')) {
                        $dstIos = __DIR__ . '/../ios/App/App/public/' . $st;
                        @mkdir(dirname($dstIos), 0777, true);
                        @copy($src, $dstIos);
                    }
                }
            }
        }
    }

    $affectedFiles = array_values(array_unique($affectedFiles));
    $affectedCount = count($affectedFiles);
    $affectedJson = json_encode($affectedFiles, JSON_UNESCAPED_SLASHES);
    $fcInt = $forceClearCache ? 1 : 0;

    try {
        $dStmt = $db->prepare("
            INSERT INTO `ota_deployments` 
            (version_code, cache_buster, release_note, force_clear_cache, deployed_by, affected_files_count, affected_files_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        if ($dStmt) {
            $dStmt->bind_param("sisisis", $versionCode, $timestamp, $releaseNote, $fcInt, $deployedBy, $affectedCount, $affectedJson);
            $dStmt->execute();
            $dStmt->close();
        }
    } catch (Throwable $e) {
        error_log("OTA ota_deployments warning: " . $e->getMessage());
    }

    return [
        'status' => 'success',
        'message' => "🚀 ปล่อยอัปเดตระบบเกมส์ขึ้นแอปมือถือเรียบร้อยแล้ว! (รหัสเวอร์ชัน: {$timestamp})",
        'version_code' => $versionCode,
        'cache_buster' => $timestamp,
        'update_size' => $updateSize,
        'file_count' => $fileCount,
        'update_files' => $fileCount,
        'update_files_text' => $fileCount . ' ไฟล์',
        'last_deployed_at' => date('Y-m-d H:i:s'),
        'deployed_by' => $deployedBy,
        'release_note' => $releaseNote,
        'force_clear_cache' => $forceClearCache,
        'affected_files' => $affectedFiles,
        'affected_files_count' => $fileCount > 0 ? $fileCount : $affectedCount
    ];
}
