<?php
declare(strict_types=1);

/**
 * matchmaking.php - Matchmaking, Room Lobby, Turn Selection (5s), AI Bot Fallback (30s) & Win Rewards
 * PHP 8.4.25 / Nginx 1.31.6
 * Features:
 *  - Room entry gold fee: 2M (2,000,000), 5M (5,000,000), 10M (10,000,000)
 *  - Modes: 2 Players (1v1), 4 Players (FFA), Team Mode (2v2)
 *  - Friend invite via Room Code
 *  - Turn order card selection (5 seconds countdown, auto-assigned if timeout)
 *  - Matchmaking queue with 30s timeout -> spawns AI Bot(s)
 *  - Win payout: 200 Diamonds & 100,000 Gold (2M room) or admin-configured tiers
 *  - Updates clan score and leaderboards
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/cube_event_service.php';
require_once __DIR__ . '/level_config_helper.php';

$db = getDbConnection();
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true) ?? [];
$action = $_GET['action'] ?? ($input['action'] ?? '');

/**
 * Ensure room_settings table exists and return associative map keyed by room_tier
 */
function ensureRoomSettingsTable(mysqli $db): array {
    $db->query("
        CREATE TABLE IF NOT EXISTS `room_settings` (
            `room_tier` VARCHAR(16) NOT NULL PRIMARY KEY,
            `room_title` VARCHAR(80) NOT NULL,
            `entry_fee_gold` INT NOT NULL DEFAULT 2000 COMMENT 'ค่าผ่านทางเข้าห้อง (ทอง)',
            `start_match_gold` BIGINT NOT NULL DEFAULT 2000000 COMMENT 'เงินทองเริ่มต้นในกระดาน (Match Gold)',
            `reward_diamond` INT NOT NULL DEFAULT 200 COMMENT 'รางวัลเพชรเมื่อชนะ',
            `reward_gold` INT NOT NULL DEFAULT 100000 COMMENT 'รางวัลทองเข้ากระเป๋าหลักเมื่อชนะ',
            `tax_amount` BIGINT NOT NULL DEFAULT 50000 COMMENT 'ฐานภาษีขั้นต่ำช่อง TAX (เมื่อไม่มีเมือง)',
            `tax_percent` INT NOT NULL DEFAULT 20 COMMENT 'อัตราภาษีตามค่าก่อสร้างเมืองรวม (%)',
            `city_base_cost` BIGINT NOT NULL DEFAULT 120000 COMMENT 'ราคาสร้างเมืองเริ่มต้นต่อหลัง',
            `landmark_cost` BIGINT NOT NULL DEFAULT 320000 COMMENT 'ราคาอัปเกรดแลนด์มาร์ค',
            `toll_percent` INT NOT NULL DEFAULT 85 COMMENT 'อัตราค่าผ่านทาง (% ของมูลค่าเมือง)',
            `buyout_percent` INT NOT NULL DEFAULT 160 COMMENT 'อัตราซื้อต่อเมือง (% ของมูลค่าเมือง ยกเว้นแลนด์มาร์ค)',
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Auto-migrate tax_percent column if upgrading from earlier schema
    $colChk = $db->query("SHOW COLUMNS FROM `room_settings` LIKE 'tax_percent'");
    if ($colChk && $colChk->num_rows === 0) {
        $db->query("ALTER TABLE `room_settings` ADD COLUMN `tax_percent` INT NOT NULL DEFAULT 20 COMMENT 'อัตราภาษีตามค่าก่อสร้างเมืองรวม (%)' AFTER `tax_amount`");
    }
    $colOddChk = $db->query("SHOW COLUMNS FROM `room_settings` LIKE 'odd_even_diamond_cost'");
    if ($colOddChk && $colOddChk->num_rows === 0) {
        $db->query("ALTER TABLE `room_settings` ADD COLUMN `odd_even_diamond_cost` INT NOT NULL DEFAULT 5 COMMENT 'ค่าเพชรซื้อสิทธิ์ คู่/คี่ เพิ่มหลังใช้ครบ 3 ครั้ง' AFTER `buyout_percent`");
    }

    // Ensure game_rooms table supports 3P mode (1v1, 3P FFA, 4P FFA, TEAM 2v2)
    @$db->query("ALTER TABLE `game_rooms` MODIFY COLUMN `game_mode` ENUM('2P', '3P', '4P', 'TEAM') NOT NULL DEFAULT '2P'");

    // Ensure is_friend_room column exists in game_rooms
    $fColChk = $db->query("SHOW COLUMNS FROM `game_rooms` LIKE 'is_friend_room'");
    if ($fColChk && $fColChk->num_rows === 0) {
        @$db->query("ALTER TABLE `game_rooms` ADD COLUMN `is_friend_room` TINYINT(1) NOT NULL DEFAULT 0 AFTER `board_theme`");
    }

    $defaults = [
        '2M' => [
            'room_tier' => '2M', 'room_title' => 'ห้อง 2M (ยอดนิยม)',
            'entry_fee_gold' => 2000, 'start_match_gold' => 2000000,
            'reward_diamond' => 200, 'reward_gold' => 100000,
            'tax_amount' => 50000, 'tax_percent' => 20,
            'city_base_cost' => 120000, 'landmark_cost' => 320000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ],
        '5M' => [
            'room_tier' => '5M', 'room_title' => 'ห้อง 5M (ระดับเซียน)',
            'entry_fee_gold' => 5000, 'start_match_gold' => 5000000,
            'reward_diamond' => 500, 'reward_gold' => 300000,
            'tax_amount' => 120000, 'tax_percent' => 22,
            'city_base_cost' => 300000, 'landmark_cost' => 800000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ],
        '10M' => [
            'room_tier' => '10M', 'room_title' => 'ห้อง 10M (มหาเศรษฐี)',
            'entry_fee_gold' => 10000, 'start_match_gold' => 10000000,
            'reward_diamond' => 1200, 'reward_gold' => 800000,
            'tax_amount' => 250000, 'tax_percent' => 25,
            'city_base_cost' => 600000, 'landmark_cost' => 1600000,
            'toll_percent' => 90, 'buyout_percent' => 160
        ],
        'PRACTICE' => [
            'room_tier' => 'PRACTICE', 'room_title' => 'โหมดทดลองเล่น (ฝึกซ้อม)',
            'entry_fee_gold' => 0, 'start_match_gold' => 2000000,
            'reward_diamond' => 0, 'reward_gold' => 0,
            'tax_amount' => 50000, 'tax_percent' => 20,
            'city_base_cost' => 120000, 'landmark_cost' => 320000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ]
    ];

    $res = $db->query("SELECT * FROM `room_settings`");
    $existing = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $t = strtoupper($row['room_tier']);
            $existing[$t] = [
                'room_tier' => $t,
                'room_title' => $row['room_title'],
                'entry_fee_gold' => (int)$row['entry_fee_gold'],
                'start_match_gold' => (int)$row['start_match_gold'],
                'reward_diamond' => (int)$row['reward_diamond'],
                'reward_gold' => (int)$row['reward_gold'],
                'tax_amount' => (int)$row['tax_amount'],
                'tax_percent' => isset($row['tax_percent']) ? (int)$row['tax_percent'] : 20,
                'city_base_cost' => (int)$row['city_base_cost'],
                'landmark_cost' => (int)$row['landmark_cost'],
                'toll_percent' => (int)$row['toll_percent'],
                'buyout_percent' => (int)$row['buyout_percent'],
                'odd_even_diamond_cost' => isset($row['odd_even_diamond_cost']) ? (int)$row['odd_even_diamond_cost'] : 5
            ];
        }
    }

    foreach ($defaults as $tierKey => $d) {
        if (!isset($existing[$tierKey])) {
            $ins = $db->prepare("
                INSERT IGNORE INTO `room_settings`
                (room_tier, room_title, entry_fee_gold, start_match_gold, reward_diamond, reward_gold, tax_amount, tax_percent, city_base_cost, landmark_cost, toll_percent, buyout_percent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $ins->bind_param(
                "ssiiiiiiiiii",
                $d['room_tier'], $d['room_title'], $d['entry_fee_gold'], $d['start_match_gold'],
                $d['reward_diamond'], $d['reward_gold'], $d['tax_amount'], $d['tax_percent'],
                $d['city_base_cost'], $d['landmark_cost'], $d['toll_percent'], $d['buyout_percent']
            );
            $ins->execute();
            $ins->close();
            $existing[$tierKey] = $d;
        }
    }

    // Order consistently
    $ordered = [];
    foreach (['2M', '5M', '10M', 'PRACTICE'] as $k) {
        if (isset($existing[$k])) $ordered[$k] = $existing[$k];
    }
    foreach ($existing as $k => $v) {
        if (!isset($ordered[$k])) $ordered[$k] = $v;
    }
    return $ordered;
}

$roomSettings = ensureRoomSettingsTable($db);
$roomFeeConfig = [];
foreach ($roomSettings as $tKey => $rCfg) {
    if ($tKey === 'PRACTICE') continue;
    $roomFeeConfig[$tKey] = [
        'fee' => (int)$rCfg['entry_fee_gold'],
        'win_dia' => (int)$rCfg['reward_diamond'],
        'win_gold' => (int)$rCfg['reward_gold'],
        'start_match_gold' => (int)$rCfg['start_match_gold']
    ];
}

switch ($action) {
    // -------------------------------------------------------------
    // 0. ดึงค่าตั้งค่าห้องแข่งขันทั้งหมด (Room Configs & Match Economy)
    // -------------------------------------------------------------
    case 'get_room_configs':
        jsonResponse([
            'status' => 'success',
            'rooms' => $roomSettings
        ]);
        break;

    // -------------------------------------------------------------
    // 1. สร้างห้องเล่นเกม (Create Room)
    // -------------------------------------------------------------
    case 'create_room':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $tier = strtoupper($input['room_tier'] ?? '2M');
        $mode = strtoupper($input['game_mode'] ?? '2P');
        $boardTheme = $input['board_theme'] ?? 'classic';
        $isFriendRoom = !empty($input['is_friend_room']) || ($tier === 'FRIEND_ROOM');

        if (!isset($roomFeeConfig[$tier])) $tier = '2M';
        if (!in_array($mode, ['2P', '3P', '4P', 'TEAM'])) $mode = '2P';

        $maxPlayers = ($mode === '2P') ? 2 : (($mode === '3P') ? 3 : 4);
        $fee = $isFriendRoom ? 0 : $roomFeeConfig[$tier]['fee'];
        $rewardDia = $roomFeeConfig[$tier]['win_dia'];
        $rewardGold = $roomFeeConfig[$tier]['win_gold'];

        // Check gold (only if fee > 0)
        $db->begin_transaction();
        try {
            if ($fee > 0) {
                $uStmt = $db->prepare("SELECT gold FROM users WHERE id = ? FOR UPDATE");
                $uStmt->bind_param("i", $userId);
                $uStmt->execute();
                $currGold = (int)($uStmt->get_result()->fetch_assoc()['gold'] ?? 0);
                $uStmt->close();

                if ($currGold < $fee) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => "ทองไม่พอจ่ายค่าเข้าเล่นห้อง {$tier} (ต้องการ " . number_format((int)$fee) . " ทอง)"], 400);
                }

                // Deduct gold fee
                $deduct = $db->prepare("UPDATE users SET gold = gold - ? WHERE id = ?");
                $deduct->bind_param("ii", $fee, $userId);
                $deduct->execute();
                $deduct->close();
            }

            // Generate Room Code (6 chars)
            $roomCode = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
            $isFriendInt = $isFriendRoom ? 1 : 0;

            $stmt = $db->prepare("
                INSERT INTO game_rooms 
                    (room_code, room_tier, entry_fee_gold, game_mode, max_players, board_theme, status, reward_diamond, reward_gold, created_by_user_id, is_friend_room) 
                VALUES (?, ?, ?, ?, ?, ?, 'WAITING', ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssisssiiii", $roomCode, $tier, $fee, $mode, $maxPlayers, $boardTheme, $rewardDia, $rewardGold, $userId, $isFriendInt);
            $stmt->execute();
            $roomId = $db->insert_id;
            $stmt->close();

            // Add creator into room_players
            $team = ($mode === 'TEAM') ? 'A' : 'NONE';
            $rpStmt = $db->prepare("INSERT INTO room_players (room_id, user_id, team) VALUES (?, ?, ?)");
            $rpStmt->bind_param("iis", $roomId, $userId, $team);
            $rpStmt->execute();
            $rpStmt->close();

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => $isFriendRoom ? "สร้างห้องเล่นกับเพื่อนสำเร็จ! รหัสห้อง: {$roomCode}" : "สร้างห้อง {$tier} สำเร็จ! รหัสห้อง: {$roomCode}",
                'room_id' => $roomId,
                'room_code' => $roomCode,
                'tier' => $tier,
                'mode' => $mode,
                'is_friend_room' => $isFriendRoom,
                'is_host' => true,
                'entry_fee_gold' => $fee,
                'room_config' => $roomSettings[$tier] ?? $roomSettings['2M']
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Failed to create room: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 2. เข้าร่วมห้องผ่าน Room Code (Friend Invite Join)
    // -------------------------------------------------------------
    case 'join_room_by_code':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $code = strtoupper(trim($input['room_code'] ?? ''));

        if (empty($code)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกรหัสห้อง'], 400);
        }

        $db->begin_transaction();
        try {
            $stmt = $db->prepare("SELECT * FROM game_rooms WHERE room_code = ? FOR UPDATE");
            $stmt->bind_param("s", $code);
            $stmt->execute();
            $room = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$room) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "ไม่พบห้องรหัส \"{$code}\" กรุณาตรวจสอบรหัสเชิญใหม่อีกครั้ง"], 404);
            }

            if (!in_array($room['status'], ['WAITING', 'READY_TO_START'])) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ห้องนี้กำลังเล่นอยู่หรือปิดไปแล้ว'], 400);
            }

            $roomId = (int)$room['id'];
            $isFriendRoom = !empty($room['is_friend_room']);
            $fee = (int)$room['entry_fee_gold'];
            $maxPlayers = (int)$room['max_players'];
            $rTier = strtoupper($room['room_tier'] ?? '2M');
            $isHost = ((int)$room['created_by_user_id'] === $userId);

            // Check if user is already in the room
            $checkExisting = $db->prepare("SELECT id FROM room_players WHERE room_id = ? AND user_id = ?");
            $checkExisting->bind_param("ii", $roomId, $userId);
            $checkExisting->execute();
            $alreadyIn = $checkExisting->get_result()->fetch_assoc();
            $checkExisting->close();

            if (!$alreadyIn) {
                // Check player count
                $cntStmt = $db->prepare("SELECT COUNT(*) as cnt FROM room_players WHERE room_id = ?");
                $cntStmt->bind_param("i", $roomId);
                $cntStmt->execute();
                $currentCount = (int)$cntStmt->get_result()->fetch_assoc()['cnt'];
                $cntStmt->close();

                if ($currentCount >= $maxPlayers) {
                    $db->rollback();
                    jsonResponse(['status' => 'error', 'message' => 'ห้องนี้มีผู้เล่นครบแล้ว'], 400);
                }

                if ($fee > 0) {
                    $uStmt = $db->prepare("SELECT gold FROM users WHERE id = ? FOR UPDATE");
                    $uStmt->bind_param("i", $userId);
                    $uStmt->execute();
                    $currGold = (int)($uStmt->get_result()->fetch_assoc()['gold'] ?? 0);
                    $uStmt->close();

                    if ($currGold < $fee) {
                        $db->rollback();
                        jsonResponse(['status' => 'error', 'message' => "ทองไม่พอจ่ายค่าเข้าเล่น (ต้องการ " . number_format((int)$fee) . " ทอง)"], 400);
                    }

                    $deduct = $db->prepare("UPDATE users SET gold = gold - ? WHERE id = ?");
                    $deduct->bind_param("ii", $fee, $userId);
                    $deduct->execute();
                    $deduct->close();
                }

                $team = ($room['game_mode'] === 'TEAM') ? (($currentCount % 2 === 0) ? 'A' : 'B') : 'NONE';
                $rpStmt = $db->prepare("INSERT INTO room_players (room_id, user_id, team) VALUES (?, ?, ?)");
                $rpStmt->bind_param("iis", $roomId, $userId, $team);
                $rpStmt->execute();
                $rpStmt->close();
            }

            // For non-friend rooms, start turn selection if full
            if (!$isFriendRoom) {
                $cntStmt = $db->prepare("SELECT COUNT(*) as cnt FROM room_players WHERE room_id = ?");
                $cntStmt->bind_param("i", $roomId);
                $cntStmt->execute();
                $cCount = (int)$cntStmt->get_result()->fetch_assoc()['cnt'];
                $cntStmt->close();
                if ($cCount >= $maxPlayers) {
                    initiateTurnSelection($db, $roomId);
                }
            }

            // Fetch all players currently in room
            $playerSelectSql = "
                SELECT rp.*,
                       COALESCE(NULLIF(rp.bot_name, ''), u.username) AS username,
                       COALESCE(NULLIF(u.avatar_url, ''), 'avatars/google_avatar.png') AS avatar_url,
                       COALESCE(u.level, 1) AS level,
                       c.name as char_name, c.grade as char_grade, c.color_hex,
                       c.win_rate_bonus, c.roll_rate, c.play_skill_rate,
                       d.name as dice_name, d.dice_control_rate,
                       s.code as skill_code, s.base_power_value
                FROM room_players rp
                LEFT JOIN users u ON rp.user_id = u.id
                LEFT JOIN characters c ON u.equipped_character_id = c.id
                LEFT JOIN dice d ON u.equipped_dice_id = d.id
                LEFT JOIN skills s ON c.skill_id = s.id
                WHERE rp.room_id = ?
                ORDER BY rp.assigned_order ASC, rp.id ASC
            ";
            $stmt = $db->prepare($playerSelectSql);
            $stmt->bind_param("i", $roomId);
            $stmt->execute();
            $players = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $hostPlayer = null;
            foreach ($players as $pl) {
                if ((int)$pl['user_id'] === (int)$room['created_by_user_id']) {
                    $hostPlayer = $pl;
                    break;
                }
            }
            if (!$hostPlayer && count($players) > 0) {
                $hostPlayer = $players[0];
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => 'เข้าร่วมห้องสำเร็จ!',
                'room_id' => $roomId,
                'room_code' => $code,
                'is_host' => $isHost,
                'is_friend_room' => $isFriendRoom,
                'board_theme' => $room['board_theme'],
                'host' => $hostPlayer,
                'players' => $players,
                'room_config' => $roomSettings[$rTier] ?? $roomSettings['2M']
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Join room failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 2.5 เริ่มเกมห้องเพื่อน (Start Friend Room - Host Only)
    // -------------------------------------------------------------
    case 'start_friend_room':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $roomId = (int)($input['room_id'] ?? ($_GET['room_id'] ?? 0));
        if (!$roomId) {
            jsonResponse(['status' => 'error', 'message' => 'Missing room ID'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM game_rooms WHERE id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $room = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$room) {
            jsonResponse(['status' => 'error', 'message' => 'Room not found'], 404);
        }

        if ((int)$room['created_by_user_id'] !== $userId) {
            jsonResponse(['status' => 'error', 'message' => 'เฉพาะหัวหน้าห้องเท่านั้นที่กดเริ่มเกมส์ได้'], 403);
        }

        initiateTurnSelection($db, $roomId);

        jsonResponse([
            'status' => 'success',
            'message' => 'เริ่มเกมส์แล้ว! เข้าสู่หน้าสุ่มใครเริ่มก่อน',
            'room_id' => $roomId,
            'status' => 'SELECTING_TURN'
        ]);
        break;

    // -------------------------------------------------------------
    // 2.6 ออกจากห้องเพื่อน (Leave Friend Room)
    // -------------------------------------------------------------
    case 'leave_friend_room':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $roomId = (int)($input['room_id'] ?? ($_GET['room_id'] ?? 0));
        if ($roomId) {
            $stmt = $db->prepare("SELECT created_by_user_id FROM game_rooms WHERE id = ?");
            $stmt->bind_param("i", $roomId);
            $stmt->execute();
            $room = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($room) {
                if ((int)$room['created_by_user_id'] === $userId) {
                    $upd = $db->prepare("UPDATE game_rooms SET status = 'CANCELLED' WHERE id = ?");
                    $upd->bind_param("i", $roomId);
                    $upd->execute();
                    $upd->close();
                } else {
                    $del = $db->prepare("DELETE FROM room_players WHERE room_id = ? AND user_id = ?");
                    $del->bind_param("ii", $roomId, $userId);
                    $del->execute();
                    $del->close();
                }
            }
        }
        jsonResponse(['status' => 'success', 'message' => 'ออกจากห้องแล้ว']);
        break;

    // -------------------------------------------------------------
    // 3. ระบบค้นหาห้องด่วน (Quick Match) พร้อมระบบบอทเมื่อเกิน 30 วินาที
    // -------------------------------------------------------------
    case 'quick_match':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $tier = strtoupper($input['room_tier'] ?? '2M');
        $mode = strtoupper($input['game_mode'] ?? '2P');
        $boardTheme = $input['board_theme'] ?? 'classic';

        if (!isset($roomFeeConfig[$tier])) $tier = '2M';
        if (!in_array($mode, ['2P', '3P', '4P', 'TEAM'])) $mode = '2P';

        $maxPlayers = ($mode === '2P') ? 2 : (($mode === '3P') ? 3 : 4);
        $fee = $roomFeeConfig[$tier]['fee'];

        $db->begin_transaction();
        try {
            // Check user gold first
            $uStmt = $db->prepare("SELECT gold FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $currGold = (int)($uStmt->get_result()->fetch_assoc()['gold'] ?? 0);
            $uStmt->close();

            if ($currGold < $fee) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "ทองไม่พอจ่ายค่าผ่านทางเข้าห้อง {$tier} (ต้องการ " . number_format((int)$fee) . " ทอง)"], 400);
            }

            // Find existing waiting room
            $stmt = $db->prepare("
                SELECT r.*, TIMESTAMPDIFF(SECOND, r.created_at, NOW()) AS search_duration_sec,
                       (SELECT COUNT(*) FROM room_players rp WHERE rp.room_id = r.id) AS current_players
                FROM game_rooms r
                WHERE r.room_tier = ? AND r.game_mode = ? AND r.status = 'WAITING' AND (r.is_friend_room IS NULL OR r.is_friend_room = 0)
                ORDER BY r.id ASC LIMIT 1 FOR UPDATE
            ");
            $stmt->bind_param("ss", $tier, $mode);
            $stmt->execute();
            $room = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($room && (int)$room['current_players'] < $maxPlayers) {
                $roomId = (int)$room['id'];

                // Deduct entry fee
                $deduct = $db->prepare("UPDATE users SET gold = gold - ? WHERE id = ?");
                $deduct->bind_param("ii", $fee, $userId);
                $deduct->execute();
                $deduct->close();

                $team = ($mode === 'TEAM') ? (((int)$room['current_players'] % 2 === 0) ? 'A' : 'B') : 'NONE';
                $rp = $db->prepare("INSERT INTO room_players (room_id, user_id, team) VALUES (?, ?, ?)");
                $rp->bind_param("iis", $roomId, $userId, $team);
                $rp->execute();
                $rp->close();

                $newCount = (int)$room['current_players'] + 1;
                if ($newCount >= $maxPlayers) {
                    initiateTurnSelection($db, $roomId);
                }

                $db->commit();
                jsonResponse([
                    'status' => 'success',
                    'message' => 'พบห้องเล่นแล้ว กำลังเข้าสู่เกม!',
                    'room_id' => $roomId,
                    'room_code' => $room['room_code'],
                    'entry_fee_gold' => $fee,
                    'room_config' => $roomSettings[$tier] ?? $roomSettings['2M']
                ]);
            } else {
                // No open room, create a new one
                $roomCode = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
                $rewardDia = $roomFeeConfig[$tier]['win_dia'];
                $rewardGold = $roomFeeConfig[$tier]['win_gold'];

                // Deduct fee
                $deduct = $db->prepare("UPDATE users SET gold = gold - ? WHERE id = ?");
                $deduct->bind_param("ii", $fee, $userId);
                $deduct->execute();
                $deduct->close();

                $createStmt = $db->prepare("
                    INSERT INTO game_rooms 
                        (room_code, room_tier, entry_fee_gold, game_mode, max_players, board_theme, status, reward_diamond, reward_gold, created_by_user_id) 
                    VALUES (?, ?, ?, ?, ?, ?, 'WAITING', ?, ?, ?)
                ");
                $createStmt->bind_param("ssisssiii", $roomCode, $tier, $fee, $mode, $maxPlayers, $boardTheme, $rewardDia, $rewardGold, $userId);
                $createStmt->execute();
                $roomId = $db->insert_id;
                $createStmt->close();

                $team = ($mode === 'TEAM') ? 'A' : 'NONE';
                $rp = $db->prepare("INSERT INTO room_players (room_id, user_id, team) VALUES (?, ?, ?)");
                $rp->bind_param("iis", $roomId, $userId, $team);
                $rp->execute();
                $rp->close();

                $db->commit();
                jsonResponse([
                    'status' => 'success',
                    'message' => 'กำลังค้นหาคู่แข่งเข้าสู่ห้องแข่งขัน...',
                    'room_id' => $roomId,
                    'room_code' => $roomCode,
                    'entry_fee_gold' => $fee,
                    'room_config' => $roomSettings[$tier] ?? $roomSettings['2M']
                ]);
            }
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Quick match error: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 4. ตรวจสอบสถานะห้อง & ทำการเติมบอทเมื่อเกิน 30 วินาที
    // -------------------------------------------------------------
    case 'check_room_status':
        $roomId = (int)($input['room_id'] ?? ($_GET['room_id'] ?? 0));
        if (!$roomId) {
            jsonResponse(['status' => 'error', 'message' => 'Missing room ID'], 400);
        }

        $stmt = $db->prepare("SELECT *, TIMESTAMPDIFF(SECOND, created_at, NOW()) AS search_seconds FROM game_rooms WHERE id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $room = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$room) {
            jsonResponse(['status' => 'error', 'message' => 'Room not found'], 404);
        }

        // Ensure character columns exist safely
        @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `win_rate_bonus` DECIMAL(5,2) NOT NULL DEFAULT 5.00");
        @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `roll_rate` DECIMAL(5,2) NOT NULL DEFAULT 20.00");
        @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `play_skill_rate` DECIMAL(5,2) NOT NULL DEFAULT 10.00");

        $playerSelectSql = "
            SELECT rp.*,
                   COALESCE(NULLIF(rp.bot_name, ''), u.username) AS username,
                   COALESCE(NULLIF(u.avatar_url, ''), 'avatars/google_avatar.png') AS avatar_url,
                   COALESCE(u.level, 1) AS level,
                   c.name as char_name, c.grade as char_grade, c.color_hex,
                   c.win_rate_bonus, c.roll_rate, c.play_skill_rate,
                   d.name as dice_name, d.dice_control_rate,
                   s.code as skill_code, s.base_power_value
            FROM room_players rp
            LEFT JOIN users u ON rp.user_id = u.id
            LEFT JOIN characters c ON u.equipped_character_id = c.id
            LEFT JOIN dice d ON u.equipped_dice_id = d.id
            LEFT JOIN skills s ON c.skill_id = s.id
            WHERE rp.room_id = ?
            ORDER BY rp.assigned_order ASC, rp.id ASC
        ";

        // Fetch current players
        $stmt = $db->prepare($playerSelectSql);
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $players = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $maxPlayers = (int)$room['max_players'];
        $currentCount = count($players);

        $searchSec = (int)$room['search_seconds'];
        $forceBots = !empty($input['force_bots']) || !empty($_GET['force_bots']) || !empty($input['fast_match']) || !empty($_GET['fast_match']);

        // --- ทยอยดึงบอทเข้าสู่ห้องแข่งขันตามเวลาที่กำหนด: ---
        // 45 วินาที: หากยังไม่มีคนเข้ามา ให้ดึงบอทมา 1 คน
        // 1.20 นาที (80 วินาที): หากยังไม่มีคนเพิ่ม ให้ดึงบอทมาอีก 1 คน
        // 1.50 นาที (110 วินาที): หากยังไม่มีคนเล่น ดึงมาอีก 1 คน (หรือเติมให้เต็มห้อง)
        // เมื่อครบคน: initiateTurnSelection ($db, $roomId)
        // สำหรับห้องเพื่อน (is_friend_room) จะไม่มีการสุ่มบอทเสริมเด็ดขาด ให้รอเพื่อนเข้าห้องจริงเท่านั้น
        $isFriendRoom = !empty($room['is_friend_room']);
        if ($isFriendRoom) {
            $botsToAdd = 0;
        } else if ($room['status'] === 'WAITING' && $currentCount < $maxPlayers) {
            $neededBots = $maxPlayers - $currentCount;
            $botsToAdd = 0;

            if ($forceBots) {
                // เติมจนเต็มทันทีเมื่อกดค้นหาด่วน
                $botsToAdd = $neededBots;
            } else {
                if ($searchSec >= 110) {
                    // รอถึง 1.50 น (110 วิ): ดึงบอทจนครบห้อง
                    $botsToAdd = $neededBots;
                } else if ($searchSec >= 80) {
                    // รอถึง 1.20 น (80 วิ): ถ้ายังไม่มีคนเพิ่ม (มีผู้เล่นไม่ถึง 3 คน ในห้อง 3-4 คน) ให้ดึงบอทมาอีก 1 คน
                    if ($currentCount < 3 && $maxPlayers >= 3) {
                        $botsToAdd = 1;
                    }
                } else if ($searchSec >= 45) {
                    // ค้นหานานถึง 45 วิ: ถ้ายังมีแค่ 1 คน ให้ดึงบอทมา 1 คน
                    if ($currentCount === 1) {
                        $botsToAdd = 1;
                    }
                }
            }

            if ($botsToAdd > 0) {
                $botNames = [
                    'ภัทร สายฟ้า', 'Alex Thunder', 'แพรวา พารวย', 'Luna Star',
                    'ต้นกล้า นาคราช', 'Leo Richman', 'มินตรา ดาวเหนือ', 'Bella Lucky',
                    'นนท์ เซียนเต๋า', 'Maximus Pro', 'พลอย ประกายเพชร', 'Chloe Viper',
                    'กานต์ อัศวิน', 'Ryan Phoenix', 'ออมสิน มังกรทอง', 'Sophia Crown'
                ];
                shuffle($botNames);

                for ($b = 0; $b < $botsToAdd; $b++) {
                    $bName = $botNames[$b % count($botNames)];
                    $team = ($room['game_mode'] === 'TEAM') ? (($currentCount + $b) % 2 === 0 ? 'A' : 'B') : 'NONE';
                    $botUserId = getOrCreateBotUser($db, $bName);

                    // Insert bot into room_players with distinct user_id
                    $botStmt = $db->prepare("INSERT IGNORE INTO room_players (room_id, user_id, team, is_bot, bot_name) VALUES (?, ?, ?, 1, ?)");
                    $botStmt->bind_param("iiss", $roomId, $botUserId, $team, $bName);
                    $botStmt->execute();
                    $botStmt->close();
                }

                // Reload players with full stats
                $stmt = $db->prepare($playerSelectSql);
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $players = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
                $currentCount = count($players);

                // If room is now full -> Initiate 5s Turn Order Selection!
                if ($currentCount >= $maxPlayers) {
                    initiateTurnSelection($db, $roomId);
                    $room['status'] = 'SELECTING_TURN';
                }
            }
        }

        // Check if 5-second turn selection deadline expired
        if ($room['status'] === 'SELECTING_TURN') {
            $now = time();
            $deadline = strtotime($room['turn_selection_deadline'] ?? '');
            if ($now >= $deadline) {
                // Finalize turn order automatically
                finalizeTurnOrder($db, $roomId);
                $room['status'] = 'PLAYING';
                // Reload sorted players
                $stmt = $db->prepare($playerSelectSql);
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $players = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
            }
        }

        // กำหนดข้อมูลผู้เล่นบอท AI: เกรดการ์ดระดับ S ขึ้นไป (S, S+, SS, SS+) และเลเวลสุ่ม 20-30
        $sGradesPool = ['S', 'S+', 'SS', 'SS+'];
        foreach ($players as &$pl) {
            if (!empty($pl['is_bot'])) {
                if (empty($pl['level']) || (int)$pl['level'] < 20 || (int)$pl['level'] > 30) {
                    $pl['level'] = rand(20, 30);
                }
                if (empty($pl['char_grade']) || !in_array($pl['char_grade'], ['S', 'S+', 'SS', 'SS+'])) {
                    $pl['char_grade'] = $sGradesPool[array_rand($sGradesPool)];
                }
                $pl['grade'] = $pl['char_grade'];
                $pl['character_grade'] = $pl['char_grade'];
                if (empty($pl['dice_control_rate']) || (int)$pl['dice_control_rate'] < 50) {
                    $pl['dice_control_rate'] = rand(65, 80);
                }
                if (empty($pl['win_rate_bonus']) || (int)$pl['win_rate_bonus'] < 20) {
                    $pl['win_rate_bonus'] = rand(25, 40);
                }
                if (empty($pl['roll_rate']) || (int)$pl['roll_rate'] < 50) {
                    $pl['roll_rate'] = rand(70, 85);
                }
                if (empty($pl['play_skill_rate']) || (int)$pl['play_skill_rate'] < 25) {
                    $pl['play_skill_rate'] = rand(30, 45);
                }
            }
        }
        unset($pl);

        $rTier = strtoupper($room['room_tier'] ?? '2M');
        jsonResponse([
            'status' => 'success',
            'room' => $room,
            'room_config' => $roomSettings[$rTier] ?? $roomSettings['2M'],
            'players' => $players
        ]);
        break;

    // -------------------------------------------------------------
    // 4.5 จับคู่ด่วนทันที (Fast Match - Spawns Bots Instantly)
    // -------------------------------------------------------------
    case 'fast_match':
    case 'force_bots':
        $roomId = (int)($input['room_id'] ?? ($_GET['room_id'] ?? 0));
        $stmt = $db->prepare("SELECT * FROM game_rooms WHERE id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $room = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($room && $room['status'] === 'WAITING') {
            $cntStmt = $db->prepare("SELECT COUNT(*) as cnt FROM room_players WHERE room_id = ?");
            $cntStmt->bind_param("i", $roomId);
            $cntStmt->execute();
            $currentCount = (int)$cntStmt->get_result()->fetch_assoc()['cnt'];
            $cntStmt->close();

            $maxPlayers = (int)$room['max_players'];
            if ($currentCount < $maxPlayers) {
                $neededBots = $maxPlayers - $currentCount;
                $botNames = [
                    'ภัทร สายฟ้า', 'Alex Thunder', 'แพรวา พารวย', 'Luna Star',
                    'ต้นกล้า นาคราช', 'Leo Richman', 'มินตรา ดาวเหนือ', 'Bella Lucky',
                    'นนท์ เซียนเต๋า', 'Maximus Pro', 'พลอย ประกายเพชร', 'Chloe Viper',
                    'กานต์ อัศวิน', 'Ryan Phoenix', 'ออมสิน มังกรทอง', 'Sophia Crown'
                ];
                shuffle($botNames);
                for ($b = 0; $b < $neededBots; $b++) {
                    $bName = $botNames[$b % count($botNames)];
                    $team = ($room['game_mode'] === 'TEAM') ? (($currentCount + $b) % 2 === 0 ? 'A' : 'B') : 'NONE';
                    $botUserId = getOrCreateBotUser($db, $bName);
                    $botStmt = $db->prepare("INSERT IGNORE INTO room_players (room_id, user_id, team, is_bot, bot_name) VALUES (?, ?, ?, 1, ?)");
                    $botStmt->bind_param("iiss", $roomId, $botUserId, $team, $bName);
                    $botStmt->execute();
                    $botStmt->close();
                }
                initiateTurnSelection($db, $roomId);
            }
        }
        jsonResponse(['status' => 'success', 'message' => 'จับคู่ด่วนสำเร็จ']);
        break;

    // -------------------------------------------------------------
    // 5. ผู้เล่นเลือกการ์ดทอยก่อน (Turn Selection Choice 1..4 - 5s limit)
    // -------------------------------------------------------------
    case 'select_turn_card':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $roomId = (int)($input['room_id'] ?? 0);
        $choice = (int)($input['turn_choice'] ?? 1); // Card 1..4

        $stmt = $db->prepare("UPDATE room_players SET turn_choice = ? WHERE room_id = ? AND user_id = ?");
        $stmt->bind_param("iii", $choice, $roomId, $userId);
        $stmt->execute();
        $stmt->close();

        // Check if all human players have picked
        $chk = $db->prepare("SELECT COUNT(*) as unpicked FROM room_players WHERE room_id = ? AND turn_choice IS NULL AND is_bot = 0");
        $chk->bind_param("i", $roomId);
        $chk->execute();
        $unpicked = (int)$chk->get_result()->fetch_assoc()['unpicked'];
        $chk->close();

        if ($unpicked === 0) {
            finalizeTurnOrder($db, $roomId);
        }

        jsonResponse([
            'status' => 'success',
            'message' => "คุณเลือกการ์ดหมายเลข {$choice} เรียบร้อยแล้ว!"
        ]);
        break;

    // -------------------------------------------------------------
    // 6. จบการแข่งขัน แจกรางวัลผู้ชนะ (Finish Match & Win Payout)
    // -------------------------------------------------------------
    case 'finish_match':
        $roomId = (int)($input['room_id'] ?? 0);
        $winnerUserId = (int)($input['winner_user_id'] ?? 0);
        $isWinnerBot = !empty($input['is_winner_bot']);

        $db->begin_transaction();
        try {
            $stmt = $db->prepare("SELECT * FROM game_rooms WHERE id = ? FOR UPDATE");
            $stmt->bind_param("i", $roomId);
            $stmt->execute();
            $room = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$room || $room['status'] === 'FINISHED') {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'ห้องจบการแข่งขันไปแล้วหรือไม่ถูกต้อง'], 400);
            }

            $diaReward = (int)$room['reward_diamond'];
            $goldReward = (int)$room['reward_gold'];

            // Mark room finished
            $updRoom = $db->prepare("UPDATE game_rooms SET status = 'FINISHED', winner_id = ? WHERE id = ?");
            $updRoom->bind_param("ii", $winnerUserId, $roomId);
            $updRoom->execute();
            $updRoom->close();

            $levelUpCfg = getLevelUpConfig($db);
            $levelUpsByUser = [];

            // Payout to human winner
            if (!$isWinnerBot && $winnerUserId > 0) {
                // Grant rewards
                $updUser = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
                $updUser->bind_param("iii", $diaReward, $goldReward, $winnerUserId);
                $updUser->execute();
                $updUser->close();

                // Send Victory Mail
                $vTitle = "🏆 ยินดีด้วยคุณชนะเลิศในห้อง {$room['room_tier']}!";
                $vMsg = "คุณคือสุดยอดนักทอยเต๋าแห่งเกมบันไดงู 3D รับรางวัลเพชร {$diaReward} และทอง " . number_format((int)$goldReward) . " เรียบร้อย!";
                $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, ?, ?, 1)");
                $m->bind_param("issii", $winnerUserId, $vTitle, $vMsg, $diaReward, $goldReward);
                $m->execute();
                $m->close();

                // Update leaderboard: +Wins, +Rank points
                $updLb = $db->prepare("
                    UPDATE leaderboards 
                    SET total_matches = total_matches + 1, 
                        total_wins = total_wins + 1, 
                        current_win_streak = current_win_streak + 1,
                        max_win_streak = GREATEST(max_win_streak, current_win_streak + 1),
                        rank_points = rank_points + 25,
                        last_match_at = NOW()
                    WHERE user_id = ?
                ");
                $updLb->bind_param("i", $winnerUserId);
                $updLb->execute();
                $updLb->close();

                // Update clan ranking score (+500 points for clan victory)
                $clanStmt = $db->prepare("SELECT clan_id FROM users WHERE id = ?");
                $clanStmt->bind_param("i", $winnerUserId);
                $clanStmt->execute();
                $userClanId = $clanStmt->get_result()->fetch_assoc()['clan_id'] ?? null;
                $clanStmt->close();

                if ($userClanId) {
                    $updClan = $db->prepare("UPDATE clans SET total_score = total_score + 500 WHERE id = ?");
                    $updClan->bind_param("i", $userClanId);
                    $updClan->execute();
                    $updClan->close();
                }

                // Check player match EXP and Level Up
                $winnerLvUp = checkAndLevelUpUser($db, $winnerUserId, $levelUpCfg);
                if ($winnerLvUp) {
                    $levelUpsByUser[$winnerUserId] = $winnerLvUp;
                }

                // สุ่มดรอปลูกบาศก์นำโชค (Magic Cube) ให้ผู้ชนะ (เงิน, ทอง, เพชร, ในตำนาน)
                ensureCubeAndEventTables($db);
                $rewardCube = dropCubeForMatchWinner($db, $winnerUserId);
            } else {
                $rewardCube = null;
            }

            // Update losses for other human players in room
            $losers = $db->prepare("SELECT user_id FROM room_players WHERE room_id = ? AND user_id != ? AND is_bot = 0");
            $losers->bind_param("ii", $roomId, $winnerUserId);
            $losers->execute();
            $loserRows = $losers->get_result()->fetch_all(MYSQLI_ASSOC);
            $losers->close();

            foreach ($loserRows as $l) {
                $uid = (int)$l['user_id'];
                $db->query("
                    UPDATE leaderboards 
                    SET total_matches = total_matches + 1, 
                        total_losses = total_losses + 1, 
                        current_win_streak = 0,
                        rank_points = GREATEST(0, rank_points - 10),
                        last_match_at = NOW()
                    WHERE user_id = {$uid}
                ");
                $loserLvUp = checkAndLevelUpUser($db, $uid, $levelUpCfg);
                if ($loserLvUp) {
                    $levelUpsByUser[$uid] = $loserLvUp;
                }
            }

            $authUserIdForLv = 0;
            try {
                if (function_exists('getBearerToken')) {
                    $tok = getBearerToken();
                    if ($tok) {
                        $uAuth = getUserByToken($db, $tok);
                        if ($uAuth && !empty($uAuth['id'])) {
                            $authUserIdForLv = (int)$uAuth['id'];
                        }
                    }
                }
            } catch (Throwable $ignored) {}

            $clientLevelUp = null;
            if ($authUserIdForLv > 0 && isset($levelUpsByUser[$authUserIdForLv])) {
                $clientLevelUp = $levelUpsByUser[$authUserIdForLv];
            } elseif (!$isWinnerBot && $winnerUserId > 0 && isset($levelUpsByUser[$winnerUserId])) {
                $clientLevelUp = $levelUpsByUser[$winnerUserId];
            }

            $db->commit();
            jsonResponse([
                'status' => 'success',
                'message' => 'บันทึกผลการแข่งขันและมอบรางวัลเรียบร้อย!',
                'winner_id' => $winnerUserId,
                'reward_diamond' => $diaReward,
                'reward_gold' => $goldReward,
                'reward_cube' => $rewardCube,
                'level_up' => $clientLevelUp,
                'level_ups' => $levelUpsByUser
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Finish match failed: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    // 8. ซื้อสิทธิ์การ์ด คู่/คี่ เพิ่มด้วยเพชร (หลังใช้ครบ 3 ครั้งฟรี)
    // -------------------------------------------------------------
    case 'buy_odd_even_charge':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $body = getJsonBody();
        $tier = strtoupper(trim((string)($body['room_tier'] ?? '2M')));
        $rCfg = $roomSettings[$tier] ?? ($roomSettings['2M'] ?? []);
        $cost = max(0, (int)($rCfg['odd_even_diamond_cost'] ?? 5));

        $db->begin_transaction();
        try {
            $uStmt = $db->prepare("SELECT diamond FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $uRow = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();

            $curDia = (int)($uRow['diamond'] ?? 0);
            if ($cost > 0 && $curDia < $cost) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "เพชรไม่พอ (ต้องการ {$cost} เพชร)", 'required' => $cost, 'diamond' => $curDia], 400);
            }
            $newDia = $curDia - $cost;
            if ($cost > 0) {
                $upd = $db->prepare("UPDATE users SET diamond = diamond - ? WHERE id = ?");
                $upd->bind_param("ii", $cost, $userId);
                $upd->execute();
                $upd->close();
            }
            $db->commit();
            jsonResponse([
                'status' => 'success',
                'cost' => $cost,
                'diamond' => $newDia
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถหักเพชรได้: ' . $e->getMessage()], 500);
        }
        break;

    // -------------------------------------------------------------
    case 'emergency_loan':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $body = getJsonBody();
        $method = strtolower(trim((string)($body['method'] ?? 'gold')));
        if (!in_array($method, ['gold', 'diamond'], true)) {
            jsonResponse(['status' => 'error', 'message' => 'รูปแบบการกู้ไม่ถูกต้อง'], 400);
        }

        $loanGoldCost = 5000;
        $loanDiaCost = 20;
        $grRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('loan_gold_cost', 'loan_diamond_cost')");
        if ($grRes) {
            while ($grRow = $grRes->fetch_assoc()) {
                if ($grRow['setting_key'] === 'loan_gold_cost') $loanGoldCost = max(0, (int)$grRow['setting_value']);
                if ($grRow['setting_key'] === 'loan_diamond_cost') $loanDiaCost = max(0, (int)$grRow['setting_value']);
            }
        }
        $cost = ($method === 'diamond') ? $loanDiaCost : $loanGoldCost;
        $col = ($method === 'diamond') ? 'diamond' : 'gold';
        $label = ($method === 'diamond') ? 'เพชร' : 'ทอง';

        $db->begin_transaction();
        try {
            $uStmt = $db->prepare("SELECT gold, diamond FROM users WHERE id = ? FOR UPDATE");
            $uStmt->bind_param("i", $userId);
            $uStmt->execute();
            $uRow = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();

            $curGold = (int)($uRow['gold'] ?? 0);
            $curDia = (int)($uRow['diamond'] ?? 0);
            $curVal = ($method === 'diamond') ? $curDia : $curGold;

            if ($cost > 0 && $curVal < $cost) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => "{$label}ในระบบไม่พอ (ต้องการ {$cost} {$label})", 'required' => $cost, 'gold' => $curGold, 'diamond' => $curDia], 400);
            }
            if ($cost > 0) {
                $upd = $db->prepare("UPDATE users SET {$col} = {$col} - ? WHERE id = ?");
                $upd->bind_param("ii", $cost, $userId);
                $upd->execute();
                $upd->close();
            }
            $newGold = ($method === 'gold') ? ($curGold - $cost) : $curGold;
            $newDia = ($method === 'diamond') ? ($curDia - $cost) : $curDia;
            $db->commit();
            jsonResponse([
                'status' => 'success',
                'method' => $method,
                'cost' => $cost,
                'gold' => $newGold,
                'diamond' => $newDia
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถกู้เงินฉุกเฉินได้: ' . $e->getMessage()], 500);
        }
        break;

    default:
        jsonResponse(['status' => 'error', 'message' => 'Invalid matchmaking action'], 400);
}

/**
 * ดึงหรือสร้าง User record สำหรับคู่แข่งบอท กำหนดเลเวล 20-30 และการ์ดระดับ S ขึ้นไป
 */
function getOrCreateBotUser(mysqli $db, string $botName): int {
    $stmt = $db->prepare("SELECT id, level FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param("s", $botName);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $randLevel = rand(20, 30);
    // สุ่มตัวละครเกรด S ขึ้นไป (S, S+, SS, SS+)
    $sChar = $db->query("SELECT id FROM characters WHERE grade IN ('S', 'S+', 'SS', 'SS+') ORDER BY RAND() LIMIT 1");
    $charId = ($sChar && $row = $sChar->fetch_assoc()) ? (int)$row['id'] : null;

    if ($res && !empty($res['id'])) {
        $botId = (int)$res['id'];
        $lvl = (int)($res['level'] ?? 0);
        $finalLvl = ($lvl < 20 || $lvl > 30) ? $randLevel : $lvl;
        $updSql = "UPDATE users SET level = {$finalLvl}";
        if ($charId) {
            $updSql .= ", equipped_character_id = {$charId}";
        }
        $updSql .= " WHERE id = {$botId}";
        $db->query($updSql);
        return $botId;
    }

    $avatarUrl = 'avatars/google_avatar.png';
    $stmt = $db->prepare("INSERT INTO users (username, avatar_url, diamond, gold, level, equipped_character_id) VALUES (?, ?, 10000, 10000000, ?, ?)");
    $stmt->bind_param("ssii", $botName, $avatarUrl, $randLevel, $charId);
    $stmt->execute();
    $newId = $stmt->insert_id;
    $stmt->close();
    return (int)$newId;
}

/**
 * Start 5-second countdown timer for turn order card selection
 */
function initiateTurnSelection(mysqli $db, int $roomId): void {
    $start = date('Y-m-d H:i:s');
    $deadline = date('Y-m-d H:i:s', time() + 5);

    $stmt = $db->prepare("UPDATE game_rooms SET status = 'SELECTING_TURN', turn_selection_start = ?, turn_selection_deadline = ? WHERE id = ?");
    $stmt->bind_param("ssi", $start, $deadline, $roomId);
    $stmt->execute();
    $stmt->close();
}

/**
 * Finalize turn order and start game
 */
function finalizeTurnOrder(mysqli $db, int $roomId): void {
    $stmt = $db->prepare("SELECT id, user_id, is_bot, turn_choice FROM room_players WHERE room_id = ? ORDER BY id ASC");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $players = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $count = count($players);
    $orders = range(1, $count);
    shuffle($orders); // Randomize turn order or resolve ties

    $turnOrderMap = [];
    $upd = $db->prepare("UPDATE room_players SET assigned_order = ? WHERE id = ?");
    foreach ($players as $idx => $p) {
        $assigned = $orders[$idx];
        $rpId = (int)$p['id'];
        $upd->bind_param("ii", $assigned, $rpId);
        $upd->execute();
        $turnOrderMap[] = ['player_id' => $rpId, 'order' => $assigned];
    }
    $upd->close();

    $jsonOrder = json_encode($turnOrderMap);
    $updRoom = $db->prepare("UPDATE game_rooms SET status = 'PLAYING', turn_order = ? WHERE id = ?");
    $updRoom->bind_param("si", $jsonOrder, $roomId);
    $updRoom->execute();
    $updRoom->close();
}

/**
 * Check user match exp and trigger level up using Admin-configured max_level & rewards
 * (Diamond, Gold, Magic Cubes)
 */
function checkAndLevelUpUser(mysqli $db, int $userId, ?array $levelUpConfig = null): ?array {
    $cfg = $levelUpConfig ?? getLevelUpConfig($db);
    $maxLevel = max(2, (int)($cfg['max_level'] ?? 100));

    $stmt = $db->prepare("SELECT level, exp_matches FROM users WHERE id = ? FOR UPDATE");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $u = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$u) return null;

    $level = (int)$u['level'];
    if ($level >= $maxLevel) {
        return null; // ถึงเลเวลตันตามที่แอดมินตั้งค่าแล้ว
    }

    $exp = (int)$u['exp_matches'] + 1; // +1 match
    $neededMatches = ($level <= 5) ? 5 : 10;

    if ($exp >= $neededMatches) {
        $newLevel = min($maxLevel, $level + 1);
        $remainExp = ($newLevel >= $maxLevel) ? 0 : ($exp - $neededMatches);

        $rw = resolveLevelUpReward($cfg, $newLevel);
        $rewardDia = (int)$rw['diamond'];
        $rewardGold = (int)$rw['gold'];
        $rewardCubes = is_array($rw['cubes'] ?? null) ? $rw['cubes'] : [];
        $rewardCubeType = (string)($rw['cube_type'] ?? '');
        $rewardCubeQty = (int)($rw['cube_qty'] ?? 0);
        $rewardCubeName = (string)($rw['cube_name'] ?? '');

        $upd = $db->prepare("UPDATE users SET level = ?, exp_matches = ? WHERE id = ?");
        $upd->bind_param("iii", $newLevel, $remainExp, $userId);
        $upd->execute();
        $upd->close();

        // Level up reward mail (sent to Mailbox with is_claimed = 0 for player to claim)
        $rewardParts = [];
        if ($rewardDia > 0) $rewardParts[] = number_format($rewardDia) . " เพชร";
        if ($rewardGold > 0) $rewardParts[] = number_format($rewardGold) . " ทอง";
        $normalizedCubes = [];
        foreach ($rewardCubes as $rc) {
            $cType = strtoupper(trim((string)($rc['cube_type'] ?? '')));
            $cQty = max(0, (int)($rc['qty'] ?? 0));
            if ($cType === '' || $cQty <= 0) continue;
            $cName = (string)($rc['cube_name'] ?? getLevelCubeDisplayName($cType));
            $rewardParts[] = "{$cName} x{$cQty}";
            $normalizedCubes[] = ['cube_type' => $cType, 'qty' => $cQty, 'cube_name' => $cName];
        }
        if (empty($normalizedCubes) && $rewardCubeType !== '' && $rewardCubeQty > 0) {
            $cName = $rewardCubeName !== '' ? $rewardCubeName : getLevelCubeDisplayName($rewardCubeType);
            $normalizedCubes[] = ['cube_type' => strtoupper($rewardCubeType), 'qty' => $rewardCubeQty, 'cube_name' => $cName];
        }
        $rewardSummary = !empty($rewardParts) ? implode(' + ', $rewardParts) : 'โบนัสพิเศษ';

        $title = "🎉 ยินดีด้วย เลเวลอัปสู่เลเวล {$newLevel}!";
        $msg = "คุณเล่นสะสมครบตามกำหนดและเลเวลอัปสำเร็จ! กรุณากดรับรางวัล {$rewardSummary} ที่กล่องจดหมายของคุณ";

        if (!empty($normalizedCubes)) {
            $firstCube = $normalizedCubes[0];
            $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, reward_cube_type, reward_cube_qty, is_claimed) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
            if ($m) {
                $m->bind_param("issiisi", $userId, $title, $msg, $rewardDia, $rewardGold, $firstCube['cube_type'], $firstCube['qty']);
                $m->execute();
                $m->close();
            }
            for ($ci = 1; $ci < count($normalizedCubes); $ci++) {
                $extraCube = $normalizedCubes[$ci];
                $extraTitle = "🎁 รางวัลลูกบาศก์เลเวลอัป Lv.{$newLevel}";
                $extraMsg = "ของรางวัลเพิ่มเติมจากการเลเวลอัปสู่เลเวล {$newLevel}: {$extraCube['cube_name']} x{$extraCube['qty']}";
                $zero = 0;
                $mExtra = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, reward_cube_type, reward_cube_qty, is_claimed) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
                if ($mExtra) {
                    $mExtra->bind_param("issiisi", $userId, $extraTitle, $extraMsg, $zero, $zero, $extraCube['cube_type'], $extraCube['qty']);
                    $mExtra->execute();
                    $mExtra->close();
                }
            }
        } else {
            $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, ?, ?, 0)");
            if ($m) {
                $m->bind_param("issii", $userId, $title, $msg, $rewardDia, $rewardGold);
                $m->execute();
                $m->close();
            }
        }

        return [
            'leveled_up' => true,
            'old_level' => $level,
            'new_level' => $newLevel,
            'max_level' => $maxLevel,
            'is_max_level' => ($newLevel >= $maxLevel),
            'reward_diamond' => $rewardDia,
            'reward_gold' => $rewardGold,
            'reward_cubes' => $rewardCubes,
            'reward_cube_type' => $rewardCubeType,
            'reward_cube_name' => $rewardCubeName,
            'reward_cube_qty' => $rewardCubeQty,
        ];
    } else {
        $upd = $db->prepare("UPDATE users SET exp_matches = ? WHERE id = ?");
        $upd->bind_param("ii", $exp, $userId);
        $upd->execute();
        $upd->close();
        return null;
    }
}

