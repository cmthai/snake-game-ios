<?php
// api/proxy_avatar.php - Fast, secure CORS avatar image proxy
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$imgUrl = trim($_GET['url'] ?? '');

// If URL is empty, fallback
if (empty($imgUrl)) {
    fallbackAvatar();
}

// 1. If it's a relative/local URL
if (!preg_match('/^https?:\/\//i', $imgUrl)) {
    $cleanPath = ltrim($imgUrl, '/');
    $localFile = __DIR__ . '/../' . $cleanPath;
    if (file_exists($localFile) && is_file($localFile)) {
        serveFile($localFile);
    } else {
        fallbackAvatar();
    }
}

// 2. If it's a remote URL
$ch = curl_init($imgUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_CONNECTTIMEOUT => 4,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
]);
$data = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'image/jpeg';
curl_close($ch);

if ($code === 200 && !empty($data)) {
    header('Content-Type: ' . $contentType);
    header('Cache-Control: public, max-age=86400');
    echo $data;
    exit;
}

// 3. Fallback to default avatar
fallbackAvatar();

function fallbackAvatar() {
    $fb = __DIR__ . '/../avatars/google_avatar.png';
    if (file_exists($fb)) {
        header('Content-Type: image/png');
        header('Cache-Control: public, max-age=86400');
        readfile($fb);
    } else {
        header('Content-Type: image/svg+xml');
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="#00e5ff"><circle cx="12" cy="8" r="4"/><path d="M12 14c-6.1 0-8 4-8 4v2h16v-2s-1.9-4-8-4z"/></svg>';
    }
    exit;
}

function serveFile($filePath) {
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    $mimes = [
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'svg' => 'image/svg+xml',
        'webp' => 'image/webp',
        'gif' => 'image/gif'
    ];
    $mime = $mimes[$ext] ?? 'image/png';
    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=86400');
    readfile($filePath);
    exit;
}

