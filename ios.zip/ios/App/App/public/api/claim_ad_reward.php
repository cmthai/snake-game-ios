<?php
declare(strict_types=1);

/**
 * api/claim_ad_reward.php
 * Handles Rewarded Video Ad Diamond Claims (0/1 daily limit)
 * Compatible with Capacitor Native iOS AdMob & Web Simulator
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$db = getDbConnection();

// Auto-create ad reward tracking table if not exists
@$db->query("
    CREATE TABLE IF NOT EXISTS `user_ad_rewards` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `reward_type` VARCHAR(30) NOT NULL DEFAULT 'diamond',
        `reward_amount` INT NOT NULL DEFAULT 30,
        `claim_date` DATE NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_user_date` (`user_id`, `claim_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Get settings for ad reward diamonds (default: 30)
$rewardDiamonds = 30;
$adEnabled = 1;
$adUnitId = 'ca-app-pub-3940256099942544/1712485313'; // Test AdMob Rewarded ID

$settRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('admob_reward_diamonds', 'admob_reward_enabled', 'admob_reward_unit_id')");
if ($settRes) {
    while ($row = $settRes->fetch_assoc()) {
        if ($row['setting_key'] === 'admob_reward_diamonds') {
            $rewardDiamonds = max(1, (int)$row['setting_value']);
        } elseif ($row['setting_key'] === 'admob_reward_enabled') {
            $adEnabled = (int)$row['setting_value'];
        } elseif ($row['setting_key'] === 'admob_reward_unit_id') {
            if (!empty($row['setting_value'])) $adUnitId = trim($row['setting_value']);
        }
    }
}

// Authenticate user
$user = null;
try {
    $user = requireAuth($db);
} catch (Throwable $e) {
    // If not authenticated, return 401
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'กรุณาเข้าสู่ระบบก่อนรับรางวัล', 'status' => 'unauthorized']);
    exit;
}

$userId = (int)$user['id'];
$today = date('Y-m-d');

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $_GET['action'] ?? ($input['action'] ?? 'status');

// Check today's claims
$claimChk = $db->prepare("SELECT id, reward_amount, created_at FROM `user_ad_rewards` WHERE `user_id` = ? AND `claim_date` = ? LIMIT 1");
$claimChk->bind_param("is", $userId, $today);
$claimChk->execute();
$claimRes = $claimChk->get_result();
$alreadyClaimed = ($claimRes && $claimRes->num_rows > 0);
$claimRow = $alreadyClaimed ? $claimRes->fetch_assoc() : null;
$claimChk->close();

if ($action === 'status') {
    echo json_encode([
        'success' => true,
        'enabled' => ($adEnabled === 1),
        'reward_diamonds' => $rewardDiamonds,
        'ad_unit_id' => $adUnitId,
        'claimed_today' => $alreadyClaimed ? 1 : 0,
        'max_per_day' => 1,
        'can_claim' => (!$alreadyClaimed && $adEnabled === 1),
        'claimed_at' => $claimRow ? $claimRow['created_at'] : null
    ]);
    exit;
}

if ($action === 'claim') {
    if ($adEnabled !== 1) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'ระบบโฆษณารางวัลถูกปิดใช้งานชั่วคราวโดยแอดมิน']);
        exit;
    }

    if ($alreadyClaimed) {
        echo json_encode([
            'success' => false,
            'status' => 'already_claimed',
            'message' => 'คุณได้รับเพชรฟรีจากโฆษณาของวันนี้ไปแล้ว (สิทธิ์ฟรี 1/1 รีเซ็ตทุกเที่ยงคืน)'
        ]);
        exit;
    }

    // Insert claim record
    $ins = $db->prepare("INSERT INTO `user_ad_rewards` (`user_id`, `reward_type`, `reward_amount`, `claim_date`) VALUES (?, 'diamond', ?, ?)");
    $ins->bind_param("iis", $userId, $rewardDiamonds, $today);
    $ins->execute();
    $ins->close();

    // Add diamonds to user
    $upd = $db->prepare("UPDATE `users` SET `diamonds` = `diamonds` + ? WHERE `id` = ?");
    $upd->bind_param("ii", $rewardDiamonds, $userId);
    $upd->execute();
    $upd->close();

    // Get updated diamond balance
    $balRes = $db->query("SELECT diamonds FROM `users` WHERE id = {$userId}");
    $newDiamonds = $balRes ? (int)($balRes->fetch_assoc()['diamonds'] ?? 0) : 0;

    echo json_encode([
        'success' => true,
        'status' => 'claimed',
        'reward_diamonds' => $rewardDiamonds,
        'new_diamonds' => $newDiamonds,
        'claimed_today' => 1,
        'max_per_day' => 1,
        'message' => "🎉 ยินดีด้วย! คุณได้รับ {$rewardDiamonds} เพชรฟรีจากการรับชมโฆษณา"
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid action']);

