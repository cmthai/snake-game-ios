<?php
declare(strict_types=1);

/**
 * Game Authentication API (PHP 8.4.25)
 * รองรับ LINE Login API (v2.1) และ Google OAuth 2.0 API
 * จัดการฐานข้อมูล MariaDB/MySQL ด้วย mysqli และ cURL
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_USER', 'root');
define('DB_PASS', '@Nbthai01ccs');
define('DB_NAME', 'snake');

define('LINE_CHANNEL_ID', '2012374389'); // แทนที่ด้วย LINE Channel ID จริง
define('LINE_CHANNEL_SECRET', 'secret_line_key');
define('LINE_CALLBACK_URL', 'https://pmix01.thddns.net:7175/home/snake/');

define('GOOGLE_CLIENT_ID', '497403948772-1dlhn0uck8o3dla16sf9rmainmk3hiek.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_CALLBACK_URL', 'https://pmix01.thddns.net:7175/home/snake');

define('TOKEN_SECRET_KEY', 'snake3d_super_secret_game_token_key_32');

function getDatabaseConnection(): mysqli {
    mysqli_report(MYSQLI_REPORT_OFF);
    $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    
    if ($conn->connect_errno) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้: ' . $conn->connect_error
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}

function curlRequest(string $url, string $method = 'GET', array $params = [], array $headers = []): ?array {
    $ch = curl_init();
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        if (isset($headers['Content-Type']) && str_contains($headers['Content-Type'], 'application/json')) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        } else {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        }
    } else {
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        curl_setopt($ch, CURLOPT_URL, $url);
    }

    $headerList = [];
    foreach ($headers as $k => $v) {
        $headerList[] = "$k: $v";
    }

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $headerList,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_CONNECTTIMEOUT => 5
    ]);

    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($err || $httpCode >= 400 || !$raw) {
        return null;
    }

    return json_decode($raw, true);
}

function getLineAuthUrl(string $state = ''): string {
    if (empty($state)) {
        $state = bin2hex(random_bytes(16));
    }
    $params = [
        'response_type' => 'code',
        'client_id'     => LINE_CHANNEL_ID,
        'redirect_uri'  => LINE_CALLBACK_URL,
        'state'         => $state,
        'scope'         => 'profile openid',
        'bot_prompt'    => 'normal',
        'prompt'        => 'consent',
        'openexternal'  => 'true' // บังคับให้เปิดแอป LINE ในมือถือเพื่อกดยืนยันอัตโนมัติ
    ];
    return 'https://access.line.me/oauth2/v2.1/authorize?' . http_build_query($params);
}

function getGoogleAuthUrl(string $state = ''): string {
    if (empty($state)) {
        $state = bin2hex(random_bytes(16));
    }
    $params = [
        'response_type' => 'code',
        'client_id'     => GOOGLE_CLIENT_ID,
        'redirect_uri'  => GOOGLE_CALLBACK_URL,
        'state'         => $state,
        'scope'         => 'openid profile email',
        'access_type'   => 'offline',
        'prompt'        => 'select_account' // ป๊อปอัปให้เลือกบัญชี Gmail ที่ล็อกอินค้างไว้บนเครื่องทันที
    ];
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
}

function handleUserBinding(mysqli $db, string $platform, string $socialId, string $displayName, ?string $avatarUrl): array {
    $column = ($platform === 'LINE') ? 'line_id' : 'google_id';
    $defaultAvatar = ($platform === 'LINE') ? 'avatars/avatar_01.png' : 'avatars/avatar_02.png';
    $avatar = !empty($avatarUrl) ? $avatarUrl : $defaultAvatar;

    $sql = "
        SELECT 
            u.id, u.username, u.avatar_url, u.diamond, u.gold, u.level, u.is_banned,
            u.equipped_character_id, u.equipped_dice_id,
            c.name AS clan_name, c.emblem_icon AS clan_icon,
            ch.name AS character_name, ch.skill_code, ch.skill_name, ch.skill_description,
            d.name AS dice_name
        FROM users u
        LEFT JOIN clans c ON u.clan_id = c.id
        LEFT JOIN characters ch ON u.equipped_character_id = ch.id
        LEFT JOIN dice d ON u.equipped_dice_id = d.id
        WHERE u.{$column} = ?
        LIMIT 1
    ";

    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $socialId);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $userId = 0;
    $isNewPlayer = false;

    if ($existing) {
        $userId = (int)$existing['id'];
        if (!empty($existing['is_banned'])) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'บัญชีนี้ถูกระงับการใช้งาน'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $db->query("UPDATE users SET last_login_at = NOW() WHERE id = {$userId}");

        if (!empty($displayName) && !in_array($displayName, ['LINE Player', 'Google Player'], true) && !str_starts_with($displayName, 'LINE Player ')) {
            $stmt = $db->prepare("UPDATE users SET username = ? WHERE id = ?");
            $stmt->bind_param("si", $displayName, $userId);
            $stmt->execute();
            $stmt->close();
        }

        if (!empty($avatar) && !str_starts_with($avatar, 'avatars/avatar_')) {
            $updateStmt = $db->prepare("UPDATE users SET avatar_url = ? WHERE id = ?");
            $updateStmt->bind_param("si", $avatar, $userId);
            $updateStmt->execute();
            $updateStmt->close();
        }

        $playerData = $existing;
        $playerData['avatar_url'] = $avatar;
        $message = "ยินดีต้อนรับกลับ {$playerData['username']}!";
    } else {
        $isNewPlayer = true;
        $bonusDiamond = 2000;
        $bonusGold = 20000;
        $defaultLevel = 1;
        $defaultCharId = 1;
        $defaultDiceId = 1;

        $db->begin_transaction();
        try {
            $insertSql = "
                INSERT INTO users 
                    ({$column}, username, avatar_url, diamond, gold, level, equipped_character_id, equipped_dice_id, last_login_at, created_at)
                VALUES 
                    (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ";
            $insStmt = $db->prepare($insertSql);
            $insStmt->bind_param("sssiiiii", $socialId, $displayName, $avatar, $bonusDiamond, $bonusGold, $defaultLevel, $defaultCharId, $defaultDiceId);
            $insStmt->execute();
            $userId = (int)$db->insert_id;
            $insStmt->close();

            $invC = $db->prepare("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES (?, 'CHARACTER', ?, 1, 1)");
            $invC->bind_param("ii", $userId, $defaultCharId);
            $invC->execute();
            $invC->close();

            $invD = $db->prepare("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES (?, 'DICE', ?, 1, 1)");
            $invD->bind_param("ii", $userId, $defaultDiceId);
            $invD->execute();
            $invD->close();

            $mailTitle = "ยินดีต้อนรับผู้เล่นใหม่!";
            $mailBody = "รับโบนัสเริ่มต้นผจญภัย: 2,000 เพชร และ 20,000 ทอง เรียบร้อยแล้ว!";
            $mailStmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
            $mailStmt->bind_param("iss", $userId, $mailTitle, $mailBody);
            $mailStmt->execute();
            $mailStmt->close();

            $db->commit();
        } catch (Exception $e) {
            $db->rollback();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'สร้างบัญชีผู้เล่นไม่สำเร็จ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $fetchStmt = $db->prepare($sql);
        $fetchStmt->bind_param("s", $socialId);
        $fetchStmt->execute();
        $playerData = $fetchStmt->get_result()->fetch_assoc();
        $fetchStmt->close();

        $message = "ยินดีต้อนรับผู้เล่นใหม่! ได้รับโบนัส 2,000 เพชร และ 20,000 ทอง";
    }

    $tokenPayload = json_encode(['uid' => $userId, 'time' => time(), 'nonce' => bin2hex(random_bytes(6))]);
    $authToken = base64_encode($tokenPayload) . '.' . hash_hmac('sha256', $tokenPayload, TOKEN_SECRET_KEY);

    $tokStmt = $db->prepare("UPDATE users SET auth_token = ? WHERE id = ?");
    $tokStmt->bind_param("si", $authToken, $userId);
    $tokStmt->execute();
    $tokStmt->close();

    return [
        'status'       => 'success',
        'is_new_player'=> $isNewPlayer,
        'message'      => $message,
        'token'        => $authToken,
        'player'       => [
            'id'             => (int)$playerData['id'],
            'username'       => $playerData['username'],
            'avatar_url'     => $playerData['avatar_url'],
            'diamond'        => (int)$playerData['diamond'],
            'gold'           => (int)$playerData['gold'],
            'level'          => (int)$playerData['level'],
            'clan_name'      => $playerData['clan_name'] ?? 'บ้านพญานาคราช',
            'clan_icon'      => $playerData['clan_icon'] ?? '🐉',
            'character_name' => $playerData['character_name'] ?? 'พญานาคราช',
            'skill_name'     => $playerData['skill_name'] ?? 'ดึงถอยหลัง 8 ช่อง',
            'skill_desc'     => $playerData['skill_description'] ?? 'เมื่อตกช่องเดียวกัน ดึงคู่แข่งถอยหลัง 8 ช่อง',
            'dice_name'      => $playerData['dice_name'] ?? 'นีออนไซเบอร์'
        ]
    ];
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$db = getDatabaseConnection();

switch ($action) {
    case 'get_line_url':
        echo json_encode([
            'status' => 'success',
            'auth_url' => getLineAuthUrl()
        ], JSON_UNESCAPED_SLASHES);
        break;

    case 'get_google_url':
        echo json_encode([
            'status' => 'success',
            'auth_url' => getGoogleAuthUrl()
        ], JSON_UNESCAPED_SLASHES);
        break;

    case 'line_callback':
        $code = $_GET['code'] ?? '';
        if (empty($code)) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Authorization Code จาก LINE'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $tokenRes = curlRequest('https://api.line.me/oauth2/v2.1/token', 'POST', [
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'redirect_uri'  => LINE_CALLBACK_URL,
            'client_id'     => LINE_CHANNEL_ID,
            'client_secret' => LINE_CHANNEL_SECRET
        ], ['Content-Type' => 'application/x-www-form-urlencoded']);

        if (!$tokenRes || empty($tokenRes['access_token'])) {
            echo json_encode(['status' => 'error', 'message' => 'แลกเปลี่ยน LINE Token ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $profileRes = curlRequest('https://api.line.me/v2/profile', 'GET', [], [
            'Authorization' => 'Bearer ' . $tokenRes['access_token']
        ]);

        if (!$profileRes || empty($profileRes['userId'])) {
            echo json_encode(['status' => 'error', 'message' => 'ดึงโปรไฟล์ LINE ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $result = handleUserBinding(
            $db,
            'LINE',
            $profileRes['userId'],
            $profileRes['displayName'] ?? 'ผู้เล่น LINE',
            $profileRes['pictureUrl'] ?? null
        );

        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        break;

    case 'google_callback':
        $code = $_GET['code'] ?? '';
        if (empty($code)) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบ Authorization Code จาก Google'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $tokenRes = curlRequest('https://oauth2.googleapis.com/token', 'POST', [
            'code'          => $code,
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_CALLBACK_URL,
            'grant_type'    => 'authorization_code'
        ], ['Content-Type' => 'application/x-www-form-urlencoded']);

        if (!$tokenRes || empty($tokenRes['access_token'])) {
            echo json_encode(['status' => 'error', 'message' => 'แลกเปลี่ยน Google Token ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $userinfo = curlRequest('https://www.googleapis.com/oauth2/v3/userinfo', 'GET', [], [
            'Authorization' => 'Bearer ' . $tokenRes['access_token']
        ]);

        if (!$userinfo || empty($userinfo['sub'])) {
            echo json_encode(['status' => 'error', 'message' => 'ดึงโปรไฟล์ Google ไม่สำเร็จ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $result = handleUserBinding(
            $db,
            'GOOGLE',
            $userinfo['sub'],
            $userinfo['name'] ?? 'ผู้เล่น Google',
            $userinfo['picture'] ?? null
        );

        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        break;

    case 'verify_google_id_token':
        $rawPost = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $idToken = $rawPost['id_token'] ?? '';

        if (empty($idToken)) {
            echo json_encode(['status' => 'error', 'message' => 'ID Token ว่างเปล่า'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $tokenInfo = curlRequest('https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken));
        if (!$tokenInfo || empty($tokenInfo['sub'])) {
            echo json_encode(['status' => 'error', 'message' => 'Google ID Token ไม่ถูกต้องหรือหมดอายุ'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $result = handleUserBinding(
            $db,
            'GOOGLE',
            $tokenInfo['sub'],
            $tokenInfo['name'] ?? 'ผู้เล่น Google',
            $tokenInfo['picture'] ?? null
        );

        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        break;

    case 'dev_mock_login':
        $rawPost = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $platform = strtoupper(trim($rawPost['platform'] ?? 'LINE'));
        $mockId = trim($rawPost['social_id'] ?? ($platform === 'LINE' ? 'line_u_demo_01' : 'google_sub_demo_01'));
        $mockName = trim($rawPost['username'] ?? ($platform === 'LINE' ? 'เซียนเต๋าสายฟ้า' : 'Sompong Gamer'));
        $mockAvatar = trim($rawPost['avatar_url'] ?? ($platform === 'LINE' ? 'avatars/avatar_01.png' : 'avatars/avatar_02.png'));

        $result = handleUserBinding($db, $platform, $mockId, $mockName, $mockAvatar);
        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        break;

    default:
        echo json_encode([
            'status' => 'online',
            'api'    => 'Snake & Ladder 3D OAuth Login API (PHP 8.4.25)',
            'supported_actions' => [
                'get_line_url', 'get_google_url', 'line_callback', 'google_callback', 'verify_google_id_token', 'dev_mock_login'
            ]
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        break;
}

