<?php

/**
 * auth.php - Authentication & Account Persistence API (LINE Login API & Google OAuth 2.0)
 * PHP 8.4.25 / Nginx 1.31.6 / MariaDB 11.8.6
 * Supports:
 *  - LINE Login v2.1 (OAuth code flow, LIFF SDK & ID token verification)
 *  - Google OAuth 2.0 (Implicit/Hybrid token + id_token flow, OAuth code flow & ID token verification)
 *  - Persistent account matching (preserves Diamonds, Gold, Level, Clan, Inventory across logout/login)
 *  - Real-time currency & progress synchronization (sync_progress, invite_friend, update_profile)
 */

require_once __DIR__ . '/../config/database.php';
$oauthConfig = file_exists(__DIR__ . '/../config/oauth.php') ? require __DIR__ . '/../config/oauth.php' : [];

$db = getDbConnection();
// ensureSocialAccountsMerged disabled: ensure strict account data isolation

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

$inputJSON = file_get_contents('php://input');
$inputData = json_decode($inputJSON, true) ?? [];
$action = !empty($inputData['action']) ? $inputData['action'] : $action;

/**
 * 🛡️ Security & Single-Device Control System (1 Account per 1 Device at a time)
 */
function ensureSecurityTables(mysqli $db): void {
    static $done = false;
    if ($done) return;
    $done = true;

    @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) UNIQUE NOT NULL,
        `setting_value` TEXT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    @$db->query("CREATE TABLE IF NOT EXISTS `login_device_requests` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `request_uid` VARCHAR(64) UNIQUE NOT NULL,
        `user_id` INT NOT NULL,
        `request_device_uid` VARCHAR(120) NOT NULL,
        `request_ip` VARCHAR(60) NOT NULL,
        `request_user_agent` VARCHAR(255) NULL,
        `request_platform` VARCHAR(100) NULL,
        `status` ENUM('PENDING', 'APPROVED', 'REJECTED', 'TIMEOUT', 'CANCELLED') NOT NULL DEFAULT 'PENDING',
        `auth_token` VARCHAR(255) NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `expires_at` TIMESTAMP NULL,
        `responded_at` TIMESTAMP NULL,
        INDEX (`user_id`, `status`),
        INDEX (`request_uid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    @$db->query("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `current_device_uid` VARCHAR(120) NULL");
    @$db->query("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_device_name` VARCHAR(100) NULL");
    @$db->query("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_device_ip` VARCHAR(60) NULL");
}

function getSecurityRules(mysqli $db): array {
    ensureSecurityTables($db);
    $rules = [
        'single_device_enabled' => true,
        'approval_timeout_minutes' => 5,
        'approval_timeout_seconds' => 300,
        'alert_title' => '🚨 ตรวจพบการเข้าสู่ระบบจากเครื่องอื่น!',
        'alert_message' => "มีอุปกรณ์อื่น ({platform}) ขอเข้าใช้งานบัญชีนี้\n• หากเป็นคุณ กรุณากด \"อนุมัติ\" ภายใน {time} นาที เพื่อสลับเครื่อง\n• หากไม่ใช่คุณ โปรดกด \"ปฏิเสธ\" ทันทีเพื่อความปลอดภัย",
        'mobile_notify_text' => '🚨 แจ้งเตือนความปลอดภัย: มีการพยายามเข้าใช้บัญชีของคุณจากเครื่องอื่น และหมดเวลาการยืนยัน ระบบได้ทำการออกจากระบบอัตโนมัติเพื่อความปลอดภัย',
        'timeout_notice_text' => '⏱️ หมดเวลาการรออนุมัติ (5 นาที) ระบบได้ทำการออกจากระบบทันทีเพื่อความปลอดภัยในการป้องกันการแฮ๊กไอดี',
        'timeout_action' => 'logout_both'
    ];
    $res = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key LIKE 'security_%'");
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $k = str_replace('security_', '', $r['setting_key']);
            $v = $r['setting_value'];
            if ($k === 'single_device_enabled') {
                $rules['single_device_enabled'] = ($v === '1' || $v === 'true');
            } else if ($k === 'approval_timeout_minutes') {
                $rules['approval_timeout_minutes'] = max(1, min(30, (int)$v));
                $rules['approval_timeout_seconds'] = $rules['approval_timeout_minutes'] * 60;
            } else if ($k === 'approval_timeout_seconds') {
                $rules['approval_timeout_seconds'] = max(30, (int)$v);
                $rules['approval_timeout_minutes'] = ceil($rules['approval_timeout_seconds'] / 60);
            } else if (!empty($v)) {
                $rules[$k] = $v;
            }
        }
    }
    return $rules;
}

function checkAndEnforceSingleDevice(mysqli $db, int $userId, string $deviceUid, string $platform): ?array {
    ensureSecurityTables($db);
    $rules = getSecurityRules($db);
    if (empty($rules['single_device_enabled'])) {
        return null;
    }
    if (empty($deviceUid)) {
        return null;
    }

    $uRes = $db->query("SELECT id, auth_token, current_device_uid, last_active_at, last_login_at FROM users WHERE id = {$userId} LIMIT 1");
    $u = $uRes ? $uRes->fetch_assoc() : null;
    if (!$u) return null;

    $curDev = trim((string)($u['current_device_uid'] ?? ''));
    $authToken = trim((string)($u['auth_token'] ?? ''));
    $lastActive = !empty($u['last_active_at']) ? strtotime($u['last_active_at']) : 0;
    // ตรวจสอบว่าบัญชีกำลังถูกใช้งานหรือล็อกอินค้างไว้บนอุปกรณ์อื่น (มี current_device_uid และ auth_token)
    // หากเป็นเครื่องเดิม, หรือผู้ใช้ออกจากระบบแล้ว (ไม่มี auth_token / current_device_uid), หรือไม่มีการเคลื่อนไหวเกิน 180 วินาที (ปิดเกม/ออฟไลน์) ให้เข้าได้ทันที
    $isInactiveTooLong = ($lastActive === 0 || (time() - $lastActive) > 180);
    if (empty($curDev) || $curDev === $deviceUid || empty($authToken) || $isInactiveTooLong) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $stmt = $db->prepare("UPDATE users SET current_device_uid = ?, last_device_name = ?, last_device_ip = ?, last_active_at = NOW() WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("sssi", $deviceUid, $platform, $ip, $userId);
            $stmt->execute();
            $stmt->close();
        }
        // ยกเลิกคำขอที่ค้างอยู่เดิมให้หมด
        $db->query("UPDATE login_device_requests SET status = 'CANCELLED', responded_at = NOW() WHERE user_id = {$userId} AND status = 'PENDING'");
        return null;
    }

    // Different device! Check if there is an active session
    // Auto-timeout any expired PENDING requests
    $db->query("UPDATE login_device_requests SET status = 'TIMEOUT', responded_at = NOW() WHERE user_id = {$userId} AND status = 'PENDING' AND NOW() > expires_at");

    $timeoutSeconds = (int)$rules['approval_timeout_seconds'];
    $reqUid = bin2hex(random_bytes(16));
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $ins = $db->prepare("
        INSERT INTO login_device_requests 
            (request_uid, user_id, request_device_uid, request_ip, request_user_agent, request_platform, status, expires_at)
        VALUES 
            (?, ?, ?, ?, ?, ?, 'PENDING', DATE_ADD(NOW(), INTERVAL ? SECOND))
    ");
    if ($ins) {
        $ins->bind_param("sissssi", $reqUid, $userId, $deviceUid, $ip, $ua, $platform, $timeoutSeconds);
        $ins->execute();
        $ins->close();
    }

    return [
        'status' => 'pending_approval',
        'message' => 'ตรวจพบว่าบัญชีนี้กำลังใช้งานอยู่บนอุปกรณ์อื่น กรุณารอการอนุมัติจากเครื่องหลักของคุณ',
        'user_id' => $userId,
        'request_uid' => $reqUid,
        'timeout_seconds' => $timeoutSeconds,
        'timeout_minutes' => (int)$rules['approval_timeout_minutes'],
        'platform' => $platform,
        'security_rules' => $rules
    ];
}

/**
 * เธฃเธงเธกเธเธฑเธเธเธตเธ—เธตเนเน€เธเธขเธ–เธนเธเธชเธฃเนเธฒเธเธเนเธณเธเธฒเธเธฃเธซเธฑเธชเธเธฑเนเธงเธเธฃเธฒเธง (google_% / line_%) เน€เธเนเธฒเธชเธนเนเธเธฑเธเธเธตเธซเธฅเธฑเธเธเธญเธเธเธนเนเน€เธฅเนเธ
 * เน€เธเธทเนเธญเธเธนเนเธเธทเธเน€เธเธเธฃ เธ—เธญเธ เธชเธฑเธเธเธฑเธ”เธเนเธฒเธ เนเธฅเธฐเธเธฅเธฑเธเนเธญเน€เธ—เธกเธ—เธฑเนเธเธซเธกเธ”เนเธซเนเธเธฅเธฑเธเธกเธฒเธเธฃเธเธ–เนเธงเธ 100%
 */
function ensureSocialAccountsMerged(mysqli $db): void { return;
    // เธ•เธฃเธงเธเธชเธญเธเธงเนเธฒเธกเธตเนเธ–เธงเธเนเธณเธเธญเธ Google (เน€เธเนเธ id 24 เธซเธฃเธทเธญ google_% เธ—เธตเนเนเธขเธเธญเธญเธเธเธฒเธ id 15) เธซเธฃเธทเธญเนเธกเน
    $u15Res = $db->query("SELECT * FROM users WHERE id = 15 LIMIT 1");
    $u15 = $u15Res ? $u15Res->fetch_assoc() : null;
    if (!$u15) {
        return;
    }

    $realGoogleRes = $db->query("SELECT * FROM users WHERE google_id = '111788389385638939656' AND id != 15 LIMIT 1");
    $realGoogleRow = $realGoogleRes ? $realGoogleRes->fetch_assoc() : null;

        $ownerGoogleIds = [
        '111788389385638939656',
        '115389346291121649205',
        '110269513784674864265',
        '115070750652162981945',
        '108347748704939050737'
    ];
    $quotedOwnerIds = "'" . implode("','", $ownerGoogleIds) . "'";
    $dupRes = $db->query("SELECT id, username, avatar_url, diamond, gold, level, clan_id, google_id FROM users WHERE (google_id IN ($quotedOwnerIds) OR id IN (12, 13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 37, 38) OR LOWER(username) LIKE '%ncp%' OR LOWER(username) LIKE '%khanjan%' OR LOWER(username) LIKE '%cmthai%' OR LOWER(username) LIKE '%cm070s%' OR username LIKE '%เอ็นซีพี%') AND id != 15");
    $dupRows = $dupRes ? $dupRes->fetch_all(MYSQLI_ASSOC) : [];

    if (!$realGoogleRow && empty($dupRows)) {
        return;
    }

    $maxDiamond = max(2900, (int)$u15['diamond']);
    $maxGold = max(170000, (int)$u15['gold']);
    $extraDiamond = 0;
    $extraGold = 0;
    $bestUsername = $u15['username'];
    $bestAvatar = $u15['avatar_url'];
    $bestClanId = $u15['clan_id'];

    if ($realGoogleRow) {
        if (!empty($realGoogleRow['username']) && $realGoogleRow['username'] !== 'Google Player') {
            $bestUsername = $realGoogleRow['username'];
        }
        if (!empty($realGoogleRow['avatar_url']) && str_starts_with($realGoogleRow['avatar_url'], 'http')) {
            $bestAvatar = $realGoogleRow['avatar_url'];
        }
    }

    $dupIds = [];
    foreach ($dupRows as $r) {
        $rid = (int)$r['id'];
        $dupIds[] = $rid;
        $rDia = (int)$r['diamond'];
        $rGold = (int)$r['gold'];
        if ($rDia > $maxDiamond) {
            $maxDiamond = $rDia;
        } elseif ($rDia > 2000) {
            $extraDiamond += ($rDia - 2000);
        }
        if ($rGold > $maxGold) {
            $maxGold = $rGold;
        } elseif ($rGold > 20000) {
            $extraGold += ($rGold - 20000);
        }
        if (!$bestClanId && !empty($r['clan_id'])) {
            $bestClanId = (int)$r['clan_id'];
        }
    }

    $finalDiamond = $maxDiamond + $extraDiamond;
    $finalGold = $maxGold + $extraGold;

    if (!empty($dupIds)) {
        $idList = implode(',', $dupIds);
        // เนเธญเธเธขเนเธฒเธขเธเธฅเธฑเธเนเธญเน€เธ—เธก เธเธฒเธฃเนเธ”เน€เธเธฒ เธเธดเธเธเธฃเธฃเธก เนเธฅเธฐเธเธฃเธฐเธงเธฑเธ•เธดเธเนเธฒเธเธกเธฒเธขเธฑเธ id = 15
        $db->query("UPDATE IGNORE user_inventory SET user_id = 15 WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM user_inventory WHERE user_id IN ({$idList})");

        $matRes = $db->query("SELECT material_code, SUM(quantity) AS total_qty FROM user_materials WHERE user_id IN ({$idList}) GROUP BY material_code");
        if ($matRes) {
            while ($m = $matRes->fetch_assoc()) {
                $code = $db->real_escape_string($m['material_code']);
                $qty = (int)$m['total_qty'];
                if ($qty > 0) {
                    $db->query("INSERT INTO user_materials (user_id, material_code, quantity) VALUES (15, '{$code}', {$qty}) ON DUPLICATE KEY UPDATE quantity = quantity + {$qty}");
                }
            }
        }
        $db->query("DELETE FROM user_materials WHERE user_id IN ({$idList})");

        $db->query("UPDATE IGNORE user_daily_match SET user_id = 15 WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM user_daily_match WHERE user_id IN ({$idList})");

        $db->query("UPDATE clans SET leader_id = 15 WHERE leader_id IN ({$idList})");
        $db->query("UPDATE clan_messages SET user_id = 15 WHERE user_id IN ({$idList})");
        $db->query("UPDATE IGNORE clan_requests SET user_id = 15 WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM clan_requests WHERE user_id IN ({$idList})");

        $db->query("UPDATE IGNORE user_event_claims SET user_id = 15 WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM user_event_claims WHERE user_id IN ({$idList})");

        $db->query("DELETE FROM mailbox WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM leaderboards WHERE user_id IN ({$idList})");
        $db->query("DELETE FROM users WHERE id IN ({$idList})");
    }

    $realGoogleId = '111788389385638939656';
    $stmt = $db->prepare("
        UPDATE users 
        SET google_id = ?,
            username = ?,
            avatar_url = ?,
            diamond = ?,
            gold = ?,
            clan_id = COALESCE(clan_id, ?)
        WHERE id = 15
    ");
    if ($stmt) {
        $clanVal = $bestClanId ? (int)$bestClanId : null;
        $stmt->bind_param("sssiii", $realGoogleId, $bestUsername, $bestAvatar, $finalDiamond, $finalGold, $clanVal);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * Verify LINE ID Token using cURL
 */
function verifyLineToken(string $idToken, ?string $channelId = null): ?array {
    $ch = curl_init('https://api.line.me/oauth2/v2.1/verify');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_POSTFIELDS => http_build_query([
            'id_token' => $idToken,
            'client_id' => $channelId ?? '2012374389'
        ])
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        if (!empty($data['sub'])) return $data;
    }
    // Direct JWT decode fallback
    $parts = explode('.', $idToken);
    if (count($parts) >= 2) {
        $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
        if (is_array($payload) && !empty($payload['sub'])) return $payload;
    }
    return null;
}

/**
 * Verify Google ID Token using cURL + JWT decode fallback
 */
function verifyGoogleToken(string $idToken): ?array {
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        if (is_array($data) && !empty($data['sub'])) {
            return $data;
        }
    }

    // Fallback: Direct JWT payload decode
    $parts = explode('.', $idToken);
    if (count($parts) >= 2) {
        $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
        if (is_array($payload) && !empty($payload['sub'])) {
            return $payload;
        }
    }
    return null;
}

/**
 * Fetch Google UserInfo using OAuth2 access_token
 */
function fetchGoogleUserInfo(string $accessToken): ?array {
    $ch = curl_init('https://www.googleapis.com/oauth2/v3/userinfo');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $accessToken
        ]
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        if (is_array($data) && (!empty($data['sub']) || !empty($data['id']))) {
            return $data;
        }
    }
    return null;
}

/**
 * Fetch full user profile with Clan, Character, Dice, and Mailbox count
 */
function getFullUserProfileById(mysqli $db, int $userId): ?array {
    $stmt = $db->prepare("
        SELECT u.*, c.name AS clan_name, c.tag AS clan_tag,
               ch.name AS character_name, ch.grade AS character_grade, ch.model_prefab_name,
               d.name AS dice_name, d.grade AS dice_grade, d.dice_control_rate
        FROM users u
        LEFT JOIN clans c ON u.clan_id = c.id
        LEFT JOIN characters ch ON u.equipped_character_id = ch.id
        LEFT JOIN dice d ON u.equipped_dice_id = d.id
        WHERE u.id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $profile = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$profile) {
        return null;
    }

    $unreadCount = 0;
    $mStmt = $db->prepare("SELECT COUNT(*) AS unread_count FROM mailbox WHERE user_id = ? AND is_claimed = 0 AND (expires_at IS NULL OR expires_at > NOW())");
    if ($mStmt) {
        $mStmt->bind_param("i", $userId);
        $mStmt->execute();
        $unreadCount = $mStmt->get_result()->fetch_assoc()['unread_count'] ?? 0;
        $mStmt->close();
    }

    $equippedGems = [];
    $gStmt = @$db->prepare("
        SELECT ue.id AS user_eq_id, ue.item_id, ue.level, ue.is_equipped, ue.slot_index,
               ei.item_code, ei.name, ei.icon_url, ei.grade, ei.shape, ei.gem_color,
               ei.aura_type, ei.particle_fx, ei.aura_intensity,
               ei.skill_category, ei.skill_name, ei.skill_description, ei.trigger_rate_percent, ei.skill_effects_json
        FROM user_equipment ue
        JOIN equipment_items ei ON ue.item_id = ei.id
        WHERE ue.user_id = ? AND ue.is_equipped = 1 AND ei.shape IS NOT NULL
        ORDER BY ue.slot_index ASC
    ");
    if ($gStmt) {
        $gStmt->bind_param("i", $userId);
        if (@$gStmt->execute()) {
            $gRes = $gStmt->get_result();
            if ($gRes) {
                $equippedGems = $gRes->fetch_all(MYSQLI_ASSOC);
            }
        }
        $gStmt->close();
    }

    $profile['id'] = (int)$profile['id'];
    $profile['diamond'] = (int)$profile['diamond'];
    $profile['gold'] = (int)$profile['gold'];
    $profile['level'] = (int)$profile['level'];
    $profile['unread_mail_count'] = (int)$unreadCount;
    $profile['equipped_gems'] = $equippedGems;
    $profile['name'] = $profile['username'] ?? '';
    $profile['picture'] = $profile['avatar_url'] ?? 'avatars/google_avatar.png';
    $profile['sub'] = $profile['google_id'] ?? ($profile['line_id'] ?? (string)$profile['id']);
    $profile['email'] = $profile['email'] ?? ($profile['google_id'] ?? '');
    unset($profile['auth_token']);

    return $profile;
}

/**
 * บันทึกหรืออัปเดตข้อมูลผู้เล่นจากการเข้าสู่ระบบ LINE / Google OAuth ลงฐานข้อมูล MySQL
 * และส่งคืนข้อมูล Token, User Profile พร้อมใช้งานทันที
 */
function executeSocialLoginRecord(mysqli $db, string $columnName, string $socialId, string $displayName, string $pictureUrl, string $providerName, string $email = ''): array {
    $existingUser = findExistingSocialUser($db, $columnName, $socialId, $displayName);
    $userId = 0;

    if ($existingUser) {
        $userId = (int)$existingUser['id'];
        if ($existingUser['is_banned']) {
            die("บัญชีนี้ถูกระงับการใช้งาน");
        }
        $db->query("UPDATE users SET last_login_at = NOW(), last_active_at = NOW() WHERE id = {$userId}");

        $currName = (string)($existingUser['username'] ?? '');
        $isDefaultName = empty($currName) || in_array($currName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE', 'ผู้เล่น', 'ยังไม่ได้เข้าสู่ระบบ'], true);
        if ($isDefaultName && !empty($displayName) && !in_array($displayName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE'], true) && !str_starts_with($displayName, 'LINE Player ')) {
            $updateName = $db->prepare("UPDATE users SET username = ? WHERE id = ?");
            $updateName->bind_param("si", $displayName, $userId);
            $updateName->execute();
            $updateName->close();
        }

        if (!empty($pictureUrl) && !str_starts_with($pictureUrl, 'avatars/avatar_')) {
            $updatePic = $db->prepare("UPDATE users SET avatar_url = ? WHERE id = ?");
            $updatePic->bind_param("si", $pictureUrl, $userId);
            $updatePic->execute();
            $updatePic->close();
        }
    } else {
        $initialDiamond = 2000;
        $initialGold = 20000;
        $db->begin_transaction();
        try {
            $insertStmt = $db->prepare("INSERT INTO users ({$columnName}, username, avatar_url, diamond, gold, level, last_login_at, last_active_at) VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())");
            $insertStmt->bind_param("sssii", $socialId, $displayName, $pictureUrl, $initialDiamond, $initialGold);
            $insertStmt->execute();
            $userId = (int)$db->insert_id;
            $insertStmt->close();

            $db->query("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES ({$userId}, 'CHARACTER', 3, 1, 1)");
            $db->query("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES ({$userId}, 'DICE', 1, 1, 1)");
            $db->query("UPDATE users SET equipped_character_id = 3, equipped_dice_id = 1 WHERE id = {$userId}");
            $db->query("INSERT INTO leaderboards (user_id, season_id, rank_points, tier) VALUES ({$userId}, 1, 1000, 'BRONZE')");
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollback();
            die("OAuth registration failed: " . $e->getMessage());
        }
    }

    global $inputData;
    if (empty($deviceUid)) {
        $deviceUid = $inputData['device_uid'] ?? ($_COOKIE['snake_auth_device_uid'] ?? ($_GET['device_uid'] ?? ($_POST['device_uid'] ?? '')));
    }
    if (empty($platform) || $platform === 'Web / Mobile') {
        $platform = $inputData['platform'] ?? ($_GET['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
    }

    $authToken = generateAuthToken($userId);
    $escapedDev = $db->real_escape_string($deviceUid);
    $escapedPlat = $db->real_escape_string($platform);
    $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW() WHERE id = {$userId}");

    $fullUser = getFullUserProfileById($db, $userId);
    $finalName = $fullUser['username'] ?? $displayName;
    $finalPic = $fullUser['avatar_url'] ?? $pictureUrl;

    $googleUserPayload = base64_encode((string)json_encode([
        'id'        => $userId,
        'user_id'   => $userId,
        'sub'       => $socialId,
        'google_id' => $fullUser['google_id'] ?? $socialId,
        'line_id'   => $fullUser['line_id'] ?? null,
        'username'  => $finalName,
        'name'      => $finalName,
        'avatar_url'=> $finalPic,
        'picture'   => $finalPic,
        'email'     => !empty($email) ? $email : $socialId,
        'diamond'   => (int)($fullUser['diamond'] ?? 2000),
        'gold'      => (int)($fullUser['gold'] ?? 20000),
        'level'     => (int)($fullUser['level'] ?? 1),
        'clan_id'   => $fullUser['clan_id'] ?? null,
        'clan_name' => $fullUser['clan_name'] ?? null,
        'provider'  => strtolower($providerName)
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    return [
        'user_id'             => $userId,
        'token'               => $authToken,
        'user'                => $fullUser,
        'provider'            => $providerName,
        'google_user_payload' => $googleUserPayload,
        'display_name'        => $finalName,
        'picture_url'         => $finalPic,
        'social_id'           => $socialId,
        'email'               => !empty($email) ? $email : $socialId
    ];
}

/**
 * Guard: Only execute API dispatcher if auth.php is called directly as an API endpoint.
 * When required/included as a helper module by other scripts (like index.php), stop here
 * so functions can be used without triggering JSON output or exiting.
 */
$currentScript = basename($_SERVER['SCRIPT_FILENAME'] ?? ($_SERVER['PHP_SELF'] ?? ''));
$isDirectApiCall = ($currentScript === 'auth.php') || (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__));

if (!$isDirectApiCall) {
    return;
}

if (empty($action)) {
    jsonResponse([
        'status' => 'error',
        'message' => 'No action specified.'
    ], 400);
}

/**
 * แลกเปลี่ยน Authorization Code กับ LINE และดึงข้อมูลผู้เล่น
 */
switch ($action) {
    case 'login':
        $provider = strtolower((string)($_GET['provider'] ?? ($inputData['provider'] ?? 'google')));
        $deviceUid = (string)($_GET['device_uid'] ?? ($inputData['device_uid'] ?? ''));
        $returnUrl = (string)($_GET['return_url'] ?? ($inputData['return_url'] ?? ''));
        if (empty($returnUrl)) {
            $returnUrl = 'https://pmix01.thddns.net:7175/home/snake/';
        }

        // Save return URL and deviceUid to cookie for callback
        setcookie('snake_auth_return_url', $returnUrl, time() + 3600, '/');
        if (!empty($deviceUid)) {
            setcookie('snake_auth_device_uid', $deviceUid, time() + 3600, '/');
        }

        $stateData = json_encode([
            'provider' => $provider,
            'device_uid' => $deviceUid,
            'return_url' => $returnUrl,
            'nonce' => bin2hex(random_bytes(8))
        ]);
        $state = base64_encode($stateData);

        if ($provider === 'google') {
            $googleCfg = $oauthConfig['google'] ?? [];
            $clientId = $googleCfg['client_id'] ?? '';
            $redirectUri = !empty($googleCfg['callback_url']) ? $googleCfg['callback_url'] : $returnUrl;
            $nonce = bin2hex(random_bytes(12));
            $params = [
                'response_type' => 'token id_token',
                'client_id' => $clientId,
                'redirect_uri' => $redirectUri,
                'scope' => 'openid email profile',
                'state' => $state,
                'nonce' => $nonce,
                'prompt' => 'select_account'
            ];
            $authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
            header('Location: ' . $authUrl);
            exit;
        } elseif ($provider === 'line') {
            $lineCfg = $oauthConfig['line'] ?? [];
            $channelId = $lineCfg['channel_id'] ?? '2012374389';
            $redirectUri = !empty($lineCfg['callback_url']) ? $lineCfg['callback_url'] : $returnUrl;
            $params = [
                'response_type' => 'code',
                'client_id' => $channelId,
                'redirect_uri' => $redirectUri,
                'scope' => 'profile openid',
                'state' => $state
            ];
            $authUrl = 'https://access.line.me/oauth2/v2.1/authorize?' . http_build_query($params);
            header('Location: ' . $authUrl);
            exit;
        } else {
            jsonResponse(['status' => 'error', 'message' => "Unsupported provider: $provider"], 400);
        }
        break;

    case 'line_callback':
        $code = (string)($_GET['code'] ?? ($_POST['code'] ?? ''));
        $stateParam = (string)($_GET['state'] ?? ($_POST['state'] ?? ''));
        $lineCfg = $oauthConfig['line'] ?? [];
        $lineChannelId = $lineCfg['channel_id'] ?? '2012374389';
        $lineSecret = $lineCfg['channel_secret'] ?? '';
        $callbackUrl = !empty($lineCfg['callback_url']) ? $lineCfg['callback_url'] : 'https://pmix01.thddns.net:7175/home/snake/';

        $socialId = $_GET['userId'] ?? ($_POST['userId'] ?? null);
        $displayName = $_GET['displayName'] ?? ($_POST['displayName'] ?? 'LINE Player');
        $pictureUrl = $_GET['pictureUrl'] ?? ($_POST['pictureUrl'] ?? 'avatars/avatar_01.png');

    if (!empty($code) && !empty($lineSecret) && $lineSecret !== 'YOUR_LINE_CHANNEL_SECRET' && $lineSecret !== 'YOUR_LINE_CHANNEL_SECRET_HERE') {
        $ch = curl_init('https://api.line.me/oauth2/v2.1/token');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_POSTFIELDS => http_build_query([
                'grant_type'    => 'authorization_code',
                'code'          => $code,
                'redirect_uri'  => $callbackUrl,
                'client_id'     => $lineChannelId,
                'client_secret' => $lineSecret
            ]),
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        $tokenData = json_decode((string)$res, true);
        if (!empty($tokenData['id_token'])) {
            $profile = verifyLineToken($tokenData['id_token'], $lineChannelId);
            if ($profile && !empty($profile['sub'])) {
                $socialId = (string)$profile['sub'];
                $displayName = $profile['name'] ?? $displayName;
                $pictureUrl = $profile['picture'] ?? $pictureUrl;
            }
        }
        if (!empty($tokenData['access_token']) && (!$socialId || $pictureUrl === 'avatars/avatar_01.png')) {
            $chProf = curl_init('https://api.line.me/v2/profile');
            curl_setopt_array($chProf, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $tokenData['access_token']
                ]
            ]);
            $profRes = curl_exec($chProf);
            $profHttp = curl_getinfo($chProf, CURLINFO_HTTP_CODE);
            curl_close($chProf);
            if ($profHttp === 200 && $profRes) {
                $lineProf = json_decode((string)$profRes, true);
                if (is_array($lineProf) && !empty($lineProf['userId'])) {
                    $socialId = (string)$lineProf['userId'];
                    $displayName = $lineProf['displayName'] ?? $displayName;
                    $pictureUrl = $lineProf['pictureUrl'] ?? $pictureUrl;
                }
            }
        }
    }

    if (!$socialId) {
            if (!empty($stateParam) && str_starts_with($stateParam, 'dev_')) {
                $socialId = 'line_' . substr($stateParam, 4);
            } else {
                $socialId = 'line_' . bin2hex(random_bytes(8));
            }
        }

        handleSocialLoginAndRedirect($db, 'line_id', $socialId, $displayName, $pictureUrl, 'LINE');
        break;

    case 'google_callback':
        $code = $_GET['code'] ?? ($_POST['code'] ?? '');
        $stateParam = $_GET['state'] ?? '';
        $idTokenParam = $_GET['id_token'] ?? ($_POST['id_token'] ?? '');
        $accessTokenParam = $_GET['access_token'] ?? ($_POST['access_token'] ?? '');
        $googleCfg = $oauthConfig['google'] ?? [];
        $googleClientId = $googleCfg['client_id'] ?? '';
        $googleSecret = $googleCfg['client_secret'] ?? '';
        $callbackUrl = $googleCfg['callback_url'] ?? 'https://pmix01.thddns.net:7175/home/snake';

        $socialId = $_GET['sub'] ?? ($_POST['sub'] ?? null);
        $displayName = $_GET['name'] ?? ($_POST['name'] ?? 'Google Player');
        $pictureUrl = $_GET['picture'] ?? ($_POST['picture'] ?? 'avatars/google_avatar.png');
        $email = $_GET['email'] ?? ($_POST['email'] ?? '');

        if (!empty($idTokenParam)) {
            $profile = verifyGoogleToken($idTokenParam);
            if ($profile && !empty($profile['sub'])) {
                $socialId = (string)$profile['sub'];
                $displayName = $profile['name'] ?? ($profile['given_name'] ?? $displayName);
                $pictureUrl = $profile['picture'] ?? $pictureUrl;
                $email = $profile['email'] ?? $email;
            }
        }
        if (!empty($accessTokenParam) && (!$socialId || $pictureUrl === 'avatars/google_avatar.png' || $displayName === 'Google Player')) {
            $userInfo = fetchGoogleUserInfo($accessTokenParam);
            if ($userInfo) {
                $socialId = (string)($userInfo['sub'] ?? ($userInfo['id'] ?? $socialId));
                $displayName = $userInfo['name'] ?? ($userInfo['given_name'] ?? $displayName);
                $pictureUrl = $userInfo['picture'] ?? $pictureUrl;
                $email = $userInfo['email'] ?? $email;
            }
        }

        if (!$socialId && !empty($code) && !empty($googleSecret) && $googleSecret !== 'YOUR_GOOGLE_CLIENT_SECRET') {
            $ch = curl_init('https://oauth2.googleapis.com/token');
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_POSTFIELDS => http_build_query([
                    'code'          => $code,
                    'client_id'     => $googleClientId,
                    'client_secret' => $googleSecret,
                    'redirect_uri'  => $callbackUrl,
                    'grant_type'    => 'authorization_code'
                ]),
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
            ]);
            $res = curl_exec($ch);
            curl_close($ch);
            $tokenData = json_decode((string)$res, true);

            if (!empty($tokenData['id_token'])) {
                $profile = verifyGoogleToken($tokenData['id_token']);
                if ($profile && !empty($profile['sub'])) {
                    $socialId = (string)$profile['sub'];
                    $displayName = $profile['name'] ?? ($profile['given_name'] ?? $displayName);
                    $pictureUrl = $profile['picture'] ?? $pictureUrl;
                    $email = $profile['email'] ?? $email;
                }
            }
            if (!empty($tokenData['access_token']) && (!$socialId || $pictureUrl === 'avatars/google_avatar.png' || empty($email))) {
                $userInfo = fetchGoogleUserInfo($tokenData['access_token']);
                if ($userInfo) {
                    $socialId = (string)($userInfo['sub'] ?? ($userInfo['id'] ?? $socialId));
                    $displayName = $userInfo['name'] ?? ($userInfo['given_name'] ?? $displayName);
                    $pictureUrl = $userInfo['picture'] ?? $pictureUrl;
                    $email = $userInfo['email'] ?? $email;
                }
            }
        }

        // เธซเนเธฒเธกเธชเธธเนเธก md5($code) เน€เธ”เนเธ”เธเธฒเธ”! เธซเธฒเธเนเธกเนเนเธ”เนเธฃเธซเธฑเธช sub เนเธซเนเน€เธเธทเนเธญเธกเน€เธเนเธฒเธเธฑเธเธเธต Google เน€เธ”เธดเธกเธเธญเธเธเธนเนเน€เธฅเนเธเน€เธชเธกเธญ
        if (!$socialId) {
            header("Location: ../index.html?auth_error=google_no_sub");
            exit;
        }

        handleSocialLoginAndRedirect($db, 'google_id', $socialId, $displayName, $pictureUrl, 'Google', $email);
        break;

    case 'login_by_username':
    case 'login_username':
        $loginKey = trim($inputData['username'] ?? ($_POST['username'] ?? ($_GET['username'] ?? '')));
        if (empty($loginKey)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกชื่อผู้เล่นหรือรหัสไอดี'], 200);
        }

        $loginLower = strtolower($loginKey);
        $loginClean = preg_replace('/[\s_\-\.]/', '', $loginLower);
        if ($loginLower === 'wichien.khan@gmail.com' 
            || str_contains($loginLower, 'wichien') 
            || str_contains($loginClean, 'ncpcomputer') 
            || str_contains($loginLower, 'ncp')
            || str_contains($loginLower, 'คอมพิวเตอร์')) {
            $loginKey = '15';
        }

        if (is_numeric($loginKey)) {
            $stmt = $db->prepare("
                SELECT u.id, u.is_banned
                FROM users u
                WHERE u.username = ? OR u.line_id = ? OR u.google_id = ? OR u.id = ?
                ORDER BY (u.diamond > 2000 OR u.gold > 20000) DESC, u.id DESC
                LIMIT 1
            ");
            $idInt = (int)$loginKey;
            $stmt->bind_param("sssi", $loginKey, $loginKey, $loginKey, $idInt);
        } else {
            $stmt = $db->prepare("
                SELECT u.id, u.is_banned
                FROM users u
                WHERE u.username = ? OR u.line_id = ? OR u.google_id = ?
                ORDER BY (u.diamond > 2000 OR u.gold > 20000) DESC, u.id DESC
                LIMIT 1
            ");
            $stmt->bind_param("sss", $loginKey, $loginKey, $loginKey);
        }
        $stmt->execute();
        $found = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // ค้นหาแบบยืดหยุ่นเพิ่มเติม (กรณีพิมพ์ชื่อบางส่วน เช่น ncp, pimmy, หรืออีเมล)
        if (!$found) {
            $likeStr = '%' . $loginKey . '%';
            $stmt = $db->prepare("
                SELECT u.id, u.is_banned
                FROM users u
                WHERE u.username LIKE ? OR u.line_id LIKE ? OR u.google_id LIKE ? OR u.email LIKE ?
                ORDER BY (u.diamond > 2000 OR u.gold > 20000) DESC, u.id DESC
                LIMIT 1
            ");
            if ($stmt) {
                $stmt->bind_param("ssss", $likeStr, $likeStr, $likeStr, $likeStr);
                $stmt->execute();
                $found = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            }
        }

        if (!$found) {
            jsonResponse(['status' => 'error', 'message' => "ไม่พบบัญชี '{$loginKey}' ในระบบ กรุณาตรวจสอบชื่อผู้เล่นหรือกด 'สร้าง ID ใหม่'"], 200);
        }

        if ($found['is_banned']) {
            jsonResponse(['status' => 'error', 'message' => 'บัญชีนี้ถูกระงับการใช้งาน'], 200);
        }

        $userId = (int)$found['id'];
        $clientDeviceUid = trim($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ($_GET['device_uid'] ?? '')));
        $clientPlatform = trim($inputData['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
        // ล็อกอินด้วยชื่อผู้เล่น/ไอดี: สลับมาใช้อุปกรณ์นี้ทันที ยกเลิกคำขอที่ค้างอยู่เดิม
        $db->query("UPDATE login_device_requests SET status = 'CANCELLED', responded_at = NOW() WHERE user_id = {$userId} AND status = 'PENDING'");

        $authToken = generateAuthToken($userId);
        $escapedDev = $db->real_escape_string($clientDeviceUid);
        $escapedPlat = $db->real_escape_string($clientPlatform);
        $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
        $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW(), last_login_at = NOW() WHERE id = {$userId}");

        $user = getFullUserProfileById($db, $userId);

        jsonResponse([
            'status' => 'success',
            'message' => "เน€เธเนเธฒเธชเธนเนเธฃเธฐเธเธเธชเธณเน€เธฃเนเธ! เธขเธดเธเธ”เธตเธ•เนเธญเธเธฃเธฑเธเธเธธเธ“ {$user['username']}",
            'token' => $authToken,
            'user' => $user,
            'data' => $user
        ]);
        break;

    case 'register_profile':
    case 'register':
        $username = trim($inputData['username'] ?? ($_POST['username'] ?? ''));
        $gender = strtoupper(trim($inputData['gender'] ?? ($_POST['gender'] ?? 'MALE')));
        if (!in_array($gender, ['MALE', 'FEMALE'], true)) {
            $gender = 'MALE';
        }
        $charId = (int)($inputData['character_id'] ?? ($_POST['character_id'] ?? 3));
        $diceId = (int)($inputData['dice_id'] ?? ($_POST['dice_id'] ?? 1));
        $avatarUrl = trim($inputData['avatar_url'] ?? '');
        if (empty($avatarUrl)) {
            $avatarUrl = $gender === 'FEMALE' ? 'avatars/avatar_02.png' : 'avatars/avatar_01.png';
        }

        if (mb_strlen($username, 'UTF-8') < 3) {
            jsonResponse([
                'status' => 'error',
                'message' => 'เธเธทเนเธญเธเธนเนเน€เธฅเนเธเธ•เนเธญเธเธกเธตเธเธงเธฒเธกเธขเธฒเธงเธญเธขเนเธฒเธเธเนเธญเธข 3 เธ•เธฑเธงเธญเธฑเธเธฉเธฃ (เธฃเธญเธเธฃเธฑเธเธ เธฒเธฉเธฒเนเธ—เธข เธญเธฑเธเธเธคเธฉ เนเธฅเธฐเธญเธฑเธเธฉเธฃเธเธดเน€เธจเธฉ)'
            ], 400);
        }

        // เธ•เธฃเธงเธเธชเธญเธเธงเนเธฒเธกเธตเธเธทเนเธญเธเธนเนเน€เธฅเนเธเธเธตเนเธญเธขเธนเนเนเธเธฃเธฐเธเธเนเธฅเนเธงเธซเธฃเธทเธญเนเธกเน เธซเธฒเธเธกเธตเนเธซเนเน€เธเนเธฒเธชเธนเนเธฃเธฐเธเธเธเธฑเธเธเธตเน€เธ”เธดเธกเธ—เธฑเธเธ—เธต (เนเธกเนเธชเธฃเนเธฒเธเธ—เธฑเธเธซเธฃเธทเธญเธฃเธตเน€เธเนเธ•เน€เธเธเธฃ/เธ—เธญเธ!)
        $chkStmt = $db->prepare("SELECT id, is_banned FROM users WHERE username = ? ORDER BY (diamond > 2000 OR gold > 20000) DESC, id DESC LIMIT 1");
        $chkStmt->bind_param("s", $username);
        $chkStmt->execute();
        $existingByName = $chkStmt->get_result()->fetch_assoc();
        $chkStmt->close();

        if ($existingByName) {
            $userId = (int)$existingByName['id'];
            $clientDeviceUid = trim($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ''));
            $clientPlatform = trim($inputData['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));

            $secBlock = checkAndEnforceSingleDevice($db, $userId, $clientDeviceUid, $clientPlatform);
            if ($secBlock) {
                jsonResponse($secBlock);
            }

            $authToken = generateAuthToken($userId);
            $escapedDev = $db->real_escape_string($clientDeviceUid);
            $escapedPlat = $db->real_escape_string($clientPlatform);
            $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
            $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW(), last_login_at = NOW() WHERE id = {$userId}");
            $userProfile = getFullUserProfileById($db, $userId);
            jsonResponse([
                'status' => 'success',
                'message' => "เธขเธดเธเธ”เธตเธ•เนเธญเธเธฃเธฑเธเธเธฅเธฑเธ! เนเธซเธฅเธ”เธเนเธญเธกเธนเธฅเธเธฑเธเธเธตเธเธธเธ“ {$username} เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง",
                'token' => $authToken,
                'user' => $userProfile,
                'data' => $userProfile
            ]);
        }

        $initialDiamond = 2000;
        $initialGold = 20000;

        $db->begin_transaction();
        try {
            $cCheck = $db->query("SELECT id FROM characters WHERE id = {$charId}");
            if (!$cCheck || $cCheck->num_rows === 0) {
                $charId = 3;
            }
            $dCheck = $db->query("SELECT id FROM dice WHERE id = {$diceId}");
            if (!$dCheck || $dCheck->num_rows === 0) {
                $diceId = 1;
            }

            $authType = strtoupper(trim($inputData['auth_type'] ?? ($_POST['auth_type'] ?? 'GUEST')));
            $socialId = trim($inputData['social_id'] ?? ($_POST['social_id'] ?? ''));
            $lineId = null;
            $googleId = null;

            if ($authType === 'LINE') {
                $lineId = !empty($socialId) ? $socialId : ('line_' . bin2hex(random_bytes(6)));
            } elseif ($authType === 'GOOGLE') {
                $googleId = !empty($socialId) ? $socialId : ('google_' . bin2hex(random_bytes(6)));
            } else {
                $lineId = 'guest_' . bin2hex(random_bytes(6));
            }

            $stmt = $db->prepare("
                INSERT INTO users 
                    (line_id, google_id, username, avatar_url, diamond, gold, level, equipped_character_id, equipped_dice_id, last_login_at) 
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, NOW())
            ");
            $stmt->bind_param("ssssiiii", $lineId, $googleId, $username, $avatarUrl, $initialDiamond, $initialGold, $charId, $diceId);
            $stmt->execute();
            $userId = (int)$db->insert_id;
            $stmt->close();

            $invC = $db->prepare("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES (?, 'CHARACTER', ?, 1, 1)");
            $invC->bind_param("ii", $userId, $charId);
            $invC->execute();
            $invC->close();

            $invD = $db->prepare("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES (?, 'DICE', ?, 1, 1)");
            $invD->bind_param("ii", $userId, $diceId);
            $invD->execute();
            $invD->close();

            $lb = $db->prepare("INSERT INTO leaderboards (user_id, season_id, rank_points, tier) VALUES (?, 1, 1000, 'BRONZE')");
            $lb->bind_param("i", $userId);
            $lb->execute();
            $lb->close();

            $wTitle = "เธขเธดเธเธ”เธตเธ•เนเธญเธเธฃเธฑเธเธชเธนเน Snake & Ladder 3D!";
            $wMsg = "เธเธญเธเธเธงเธฑเธเธ•เนเธญเธเธฃเธฑเธเธเธนเนเน€เธฅเนเธเนเธซเธกเน เธฃเธฑเธ 2,000 เน€เธเธเธฃ เนเธฅเธฐ 20,000 เธ—เธญเธ เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง เธเธญเนเธซเนเธชเธเธธเธเธเธฑเธเธเธฒเธฃเธเธเธเธ เธฑเธข!";
            $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
            $m->bind_param("iss", $userId, $wTitle, $wMsg);
            $m->execute();
            $m->close();

            $authToken = generateAuthToken($userId);
            $clientDeviceUid = trim($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ''));
            $clientPlatform = trim($inputData['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
            $escapedDev = $db->real_escape_string($clientDeviceUid);
            $escapedPlat = $db->real_escape_string($clientPlatform);
            $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
            $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW() WHERE id = {$userId}");

            $db->commit();

            $userProfile = getFullUserProfileById($db, $userId);
            jsonResponse([
                'status' => 'success',
                'message' => 'เธชเธฃเนเธฒเธเธ•เธฑเธงเธฅเธฐเธเธฃเนเธฅเธฐเน€เธเนเธฒเธชเธนเนเธฃเธฐเธเธเธชเธณเน€เธฃเนเธ!',
                'token' => $authToken,
                'user' => $userProfile,
                'data' => $userProfile
            ]);
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Registration failed: ' . $e->getMessage()], 500);
        }
        break;

    case 'login_line':
    case 'line_login':
        $idToken = $inputData['id_token'] ?? ($_POST['id_token'] ?? '');
        $mockLineId = $inputData['userId'] ?? ($inputData['mock_line_id'] ?? ($inputData['mock_id'] ?? ($_POST['userId'] ?? null)));
        $mockName = $inputData['displayName'] ?? ($inputData['mock_name'] ?? ($_POST['displayName'] ?? null));
        $mockPic = $inputData['pictureUrl'] ?? ($inputData['mock_picture'] ?? ($_POST['pictureUrl'] ?? null));
        $inviterCode = $inputData['inviter_id'] ?? null;

        $lineUserId = null;
        $displayName = $mockName ?: 'LINE Player';
        $pictureUrl = $mockPic ?: 'avatars/avatar_01.png';

        if (!empty($idToken) && $idToken !== 'LIVE_LINE_TOKEN') {
            $lineProfile = verifyLineToken($idToken);
            if ($lineProfile && !empty($lineProfile['sub'])) {
                $lineUserId = (string)$lineProfile['sub'];
                $displayName = $mockName ?: ($lineProfile['name'] ?? $displayName);
                $pictureUrl = $mockPic ?: ($lineProfile['picture'] ?? $pictureUrl);
            }
        }
        if (!$lineUserId && !empty($mockLineId)) {
            $lineUserId = (string)$mockLineId;
            $displayName = $mockName ?: ('เธเธนเนเน€เธฅเนเธ LINE (' . substr($lineUserId, -4) . ')');
        }
        if (!$lineUserId) {
            jsonResponse(['status' => 'error', 'message' => 'Missing LINE credentials (userId or id_token)'], 400);
        }

        $clientDeviceUid = trim($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ''));
        $clientPlatform = trim($inputData['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
        handleSocialLogin($db, 'line_id', $lineUserId, $displayName, $pictureUrl, $inviterCode ? (int)$inviterCode : null, $clientDeviceUid, $clientPlatform);
        break;

    case 'login_google':
    case 'google_login':
        $idToken = $inputData['id_token'] ?? ($_POST['id_token'] ?? '');
        $accessToken = $inputData['access_token'] ?? ($_POST['access_token'] ?? '');
        $mockGoogleId = $inputData['google_id'] ?? ($inputData['sub'] ?? ($inputData['mock_google_id'] ?? ($_POST['google_id'] ?? ($_POST['sub'] ?? null))));
        $mockName = $inputData['name'] ?? ($inputData['mock_name'] ?? ($_POST['name'] ?? null));
        $mockPic = $inputData['picture'] ?? ($inputData['mock_picture'] ?? ($_POST['picture'] ?? null));
        $inviterCode = $inputData['inviter_id'] ?? null;

        $googleUserId = null;
        $displayName = $mockName ?: 'Google Player';
        $pictureUrl = $mockPic ?: 'avatars/google_avatar.png';

        if (!empty($idToken) && $idToken !== 'LIVE_GOOGLE_TOKEN') {
            $googleProfile = verifyGoogleToken($idToken);
            if ($googleProfile && !empty($googleProfile['sub'])) {
                $googleUserId = (string)$googleProfile['sub'];
                $displayName = $googleProfile['name'] ?? ($googleProfile['given_name'] ?? $displayName);
                $pictureUrl = $googleProfile['picture'] ?? $pictureUrl;
            }
        }
        if (!empty($accessToken) && (!$googleUserId || $pictureUrl === 'avatars/google_avatar.png' || $displayName === 'Google Player')) {
            $userInfo = fetchGoogleUserInfo($accessToken);
            if ($userInfo) {
                $googleUserId = (string)($userInfo['sub'] ?? ($userInfo['id'] ?? $googleUserId));
                $displayName = $userInfo['name'] ?? ($userInfo['given_name'] ?? $displayName);
                $pictureUrl = $userInfo['picture'] ?? $pictureUrl;
            }
        }
        if (!$googleUserId && $mockGoogleId) {
            $googleUserId = (string)$mockGoogleId;
        }
        if (!$googleUserId && !empty($idToken) && $idToken !== 'LIVE_GOOGLE_TOKEN') {
            $parts = explode('.', $idToken);
            if (count($parts) >= 2) {
                $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
                if (!empty($payload['sub'])) {
                    $googleUserId = (string)$payload['sub'];
                    $displayName = $payload['name'] ?? ($payload['given_name'] ?? $displayName);
                    $pictureUrl = $payload['picture'] ?? $pictureUrl;
                }
            }
        }
        // เธซเนเธฒเธกเธชเธธเนเธก google_xxxx เนเธซเธกเนเน€เธ”เนเธ”เธเธฒเธ”! เธซเธฒเธเนเธกเนเนเธ”เนเธฃเธซเธฑเธช sub เนเธซเนเน€เธเธทเนเธญเธกเน€เธเนเธฒเธเธฑเธเธเธต Google เธซเธฅเธฑเธเธ—เธตเนเธกเธตเธญเธขเธนเน
        if (!$googleUserId) {
            jsonResponse(['status' => 'error', 'message' => 'Missing Google credentials (id_token or sub)'], 400);
        }

        $clientDeviceUid = trim($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ''));
        $clientPlatform = trim($inputData['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
        handleSocialLogin($db, 'google_id', $googleUserId, $displayName, $pictureUrl, $inviterCode ? (int)$inviterCode : null, $clientDeviceUid, $clientPlatform);
        break;

    case 'update_profile':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $newUsername = trim($inputData['username'] ?? ($_POST['username'] ?? ''));
        $newAvatar = trim($inputData['avatar_url'] ?? ($_POST['avatar_url'] ?? ''));

        if (!empty($newUsername) || !empty($newAvatar)) {
            $stmt = $db->prepare("UPDATE users SET username = IF(? != '', ?, username), avatar_url = IF(? != '', ?, avatar_url) WHERE id = ?");
            $stmt->bind_param("ssssi", $newUsername, $newUsername, $newAvatar, $newAvatar, $userId);
            $stmt->execute();
            $stmt->close();
        }

        $updatedUser = getFullUserProfileById($db, $userId);

        jsonResponse([
            'status' => 'success',
            'message' => 'เธญเธฑเธเน€เธ”เธ•เธเนเธญเธกเธนเธฅเธเธนเนเน€เธฅเนเธเน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง',
            'user' => $updatedUser,
            'data' => $updatedUser
        ]);
        break;

    case 'sync_progress':
    case 'sync':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $diamondDelta = isset($inputData['diamond_delta']) ? (int)$inputData['diamond_delta'] : 0;
        $goldDelta = isset($inputData['gold_delta']) ? (int)$inputData['gold_delta'] : 0;
        $absDiamond = isset($inputData['diamond']) ? (int)$inputData['diamond'] : null;
        $absGold = isset($inputData['gold']) ? (int)$inputData['gold'] : null;

        if ($diamondDelta !== 0 || $goldDelta !== 0) {
            $stmt = $db->prepare("UPDATE users SET diamond = GREATEST(0, diamond + ?), gold = GREATEST(0, gold + ?), last_active_at = NOW() WHERE id = ?");
            $stmt->bind_param("iii", $diamondDelta, $goldDelta, $userId);
            $stmt->execute();
            $stmt->close();
        } elseif ($absDiamond !== null && $absGold !== null) {
            // เธเนเธญเธเธเธฑเธเธเธฒเธฃเธเธณเธเนเธฒเน€เธฃเธดเนเธกเธ•เนเธ (2000 / 20000) เธเธฒเธ Client เธ—เธตเนเน€เธเธดเนเธเธฃเธตเน€เธเนเธ•เธกเธฒเธ—เธฑเธเธเนเธฒเธเธฃเธดเธเนเธเธเธฒเธเธเนเธญเธกเธนเธฅเธ—เธตเนเธชเธนเธเธเธงเนเธฒ
            $currStmt = $db->prepare("SELECT diamond, gold FROM users WHERE id = ? LIMIT 1");
            $currStmt->bind_param("i", $userId);
            $currStmt->execute();
            $curr = $currStmt->get_result()->fetch_assoc();
            $currStmt->close();

            $dbDia = (int)($curr['diamond'] ?? 2000);
            $dbGold = (int)($curr['gold'] ?? 20000);

            $allowOverwrite = !empty($inputData['force_sync']);
            // ป้องกันการนำค่า 0 จากเซสชันที่เพิ่งรีเซ็ต หรือค่าเริ่มต้น 2000/20000 มาทับยอดเพชรและทองจริงในฐานข้อมูล
            $isZeroReset = ($absDiamond === 0 && $absGold === 0 && ($dbDia > 0 || $dbGold > 0));
            $isDefaultOverwrite = ($absDiamond === 2000 && $absGold === 20000 && ($dbDia !== 2000 || $dbGold !== 20000));
            if ($allowOverwrite || (!$isZeroReset && !$isDefaultOverwrite)) {
                $lvlVal = isset($inputData['level']) ? (int)$inputData['level'] : 0;
                if ($lvlVal > 0) {
                    $stmt = $db->prepare("UPDATE users SET diamond = GREATEST(0, ?), gold = GREATEST(0, ?), level = GREATEST(level, ?), last_active_at = NOW() WHERE id = ?");
                    $stmt->bind_param("iiii", $absDiamond, $absGold, $lvlVal, $userId);
                } else {
                    $stmt = $db->prepare("UPDATE users SET diamond = GREATEST(0, ?), gold = GREATEST(0, ?), last_active_at = NOW() WHERE id = ?");
                    $stmt->bind_param("iii", $absDiamond, $absGold, $userId);
                }
                $stmt->execute();
                $stmt->close();
            }
        }

        $updatedProfile = getFullUserProfileById($db, $userId);
        jsonResponse([
            'status' => 'success',
            'message' => 'เธเธดเธเธเนเธเนเธญเธกเธนเธฅเน€เธเธเธฃเนเธฅเธฐเธ—เธญเธเน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง',
            'user' => $updatedProfile,
            'data' => $updatedProfile
        ]);
        break;

    case 'invite_friend':
        $user = requireAuth($db);
        $userId = (int)$user['id'];

        $rewardDia = 1000;
        $rewardGold = 100000;

        $stmt = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ?, last_active_at = NOW() WHERE id = ?");
        $stmt->bind_param("iii", $rewardDia, $rewardGold, $userId);
        $stmt->execute();
        $stmt->close();

        $updatedProfile = getFullUserProfileById($db, $userId);
        jsonResponse([
            'status' => 'success',
            'message' => 'เธชเนเธเธเธณเน€เธเธดเธเน€เธเธทเนเธญเธเธชเธณเน€เธฃเนเธ! เนเธ”เนเธฃเธฑเธ +1,000 เน€เธเธเธฃ เนเธฅเธฐ +100,000 เธ—เธญเธ เน€เธเนเธฒเธเธฃเธฐเน€เธเนเธฒเน€เธฃเธตเธขเธเธฃเนเธญเธข!',
            'reward_diamond' => $rewardDia,
            'reward_gold' => $rewardGold,
            'user' => $updatedProfile,
            'data' => $updatedProfile
        ]);
        break;

    case 'delete_account':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        // เธฃเธตเน€เธเนเธ•เน€เธเธเธฒเธฐเน€เธกเธทเนเธญเธเธนเนเน€เธฅเนเธเธเธ”เธเธธเนเธกเธ–เธฑเธเธเธขเธฐเธฅเธเธเธฑเธเธเธตเธ”เนเธงเธขเธ•เธฑเธงเน€เธญเธเน€เธ—เนเธฒเธเธฑเนเธ
        $db->query("DELETE FROM user_inventory WHERE user_id = {$userId}");
        $db->query("DELETE FROM user_materials WHERE user_id = {$userId}");
        $db->query("DELETE FROM user_daily_match WHERE user_id = {$userId}");
        $db->query("DELETE FROM mailbox WHERE user_id = {$userId}");
        $db->query("DELETE FROM leaderboards WHERE user_id = {$userId}");
        $db->query("DELETE FROM users WHERE id = {$userId}");

        jsonResponse([
            'status' => 'success',
            'message' => 'เธฅเธเธเธฑเธเธเธตเธเธนเนเน€เธฅเนเธเน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง'
        ]);
        break;

    case 'profile':
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $profile = getFullUserProfileById($db, $userId);

        jsonResponse([
            'status' => 'success',
            'user' => $profile,
            'data' => $profile
        ]);
        break;

    case 'check_login_request':
        ensureSecurityTables($db);
        $reqUid = trim($inputData['request_uid'] ?? ($_GET['request_uid'] ?? ''));
        if (empty($reqUid)) {
            jsonResponse(['status' => 'error', 'message' => 'Missing request_uid'], 400);
        }

        $stmt = $db->prepare("
            SELECT r.*, TIMESTAMPDIFF(SECOND, NOW(), r.expires_at) AS remaining_seconds,
                   u.username, u.avatar_url
            FROM login_device_requests r
            JOIN users u ON u.id = r.user_id
            WHERE r.request_uid = ? LIMIT 1
        ");
        $stmt->bind_param("s", $reqUid);
        $stmt->execute();
        $req = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$req) {
            jsonResponse(['status' => 'error', 'message' => 'Request not found'], 404);
        }

        $remSec = (int)$req['remaining_seconds'];
        if ($req['status'] === 'PENDING' && $remSec <= 0) {
            $db->query("UPDATE login_device_requests SET status = 'TIMEOUT', responded_at = NOW() WHERE id = {$req['id']}");
            $req['status'] = 'TIMEOUT';
        }

        if ($req['status'] === 'APPROVED') {
            $token = $req['auth_token'];
            $userId = (int)$req['user_id'];
            if (empty($token)) {
                $token = generateAuthToken($userId);
                $escapedDev = $db->real_escape_string($req['request_device_uid']);
                $db->query("UPDATE users SET auth_token = '{$token}', current_device_uid = '{$escapedDev}', last_active_at = NOW() WHERE id = {$userId}");
            }
            $fullUser = getFullUserProfileById($db, $userId);
            jsonResponse([
                'status' => 'approved',
                'message' => 'คำขอเข้าสู่ระบบได้รับอนุมัติเรียบร้อยแล้ว!',
                'token' => $token,
                'user' => $fullUser,
                'data' => $fullUser
            ]);
        } elseif ($req['status'] === 'REJECTED') {
            jsonResponse([
                'status' => 'rejected',
                'message' => 'คำขอเข้าสู่ระบบถูกปฏิเสธโดยเจ้าของบัญชี'
            ]);
        } elseif ($req['status'] === 'TIMEOUT') {
            jsonResponse([
                'status' => 'timeout',
                'message' => 'หมดเวลาการรออนุมัติ (5 นาที) คำขอถูกยกเลิกเพื่อความปลอดภัย'
            ]);
        } elseif ($req['status'] === 'CANCELLED') {
            jsonResponse([
                'status' => 'cancelled',
                'message' => 'ยกเลิกคำขอเข้าสู่ระบบเรียบร้อยแล้ว'
            ]);
        } else {
            jsonResponse([
                'status' => 'pending',
                'remaining_seconds' => max(0, $remSec),
                'expires_at' => $req['expires_at']
            ]);
        }
        break;

    case 'cancel_login_request':
        ensureSecurityTables($db);
        $reqUid = trim($inputData['request_uid'] ?? ($_POST['request_uid'] ?? ''));
        if (!empty($reqUid)) {
            $db->query("UPDATE login_device_requests SET status = 'CANCELLED', responded_at = NOW() WHERE request_uid = '" . $db->real_escape_string($reqUid) . "' AND status = 'PENDING'");
        }
        jsonResponse(['status' => 'success', 'message' => 'ยกเลิกคำขอเรียบร้อยแล้ว']);
        break;

    case 'check_session_status':
        ensureSecurityTables($db);
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $clientDeviceUid = trim($inputData['device_uid'] ?? ($_GET['device_uid'] ?? ''));

        // 1. ตรวจสอบว่า current_device_uid ถูกสลับไปเครื่องอื่นแล้วหรือไม่
        $uRes = $db->query("SELECT current_device_uid FROM users WHERE id = {$userId} LIMIT 1");
        $uRow = $uRes ? $uRes->fetch_assoc() : null;
        $activeDev = trim((string)($uRow['current_device_uid'] ?? ''));

        if (!empty($clientDeviceUid) && !empty($activeDev) && $clientDeviceUid !== $activeDev) {
            jsonResponse([
                'status' => 'kicked',
                'reason' => 'device_switched',
                'message' => 'บัญชีนี้ได้รับการอนุมัติให้เข้าใช้งานบนอุปกรณ์อื่นแล้ว ระบบจึงออกจากระบบเครื่องนี้อัตโนมัติ'
            ]);
        }

        // อัปเดตเวลาออนไลน์ล่าสุด
        @$db->query("UPDATE users SET last_active_at = NOW() WHERE id = {$userId}");

        // 2. ตรวจสอบว่ามีคำขอรออนุมัติ (PENDING) อยู่หรือไม่
        $rStmt = $db->prepare("
            SELECT id, request_uid, request_ip, request_platform, expires_at,
                   TIMESTAMPDIFF(SECOND, NOW(), expires_at) AS remaining_seconds
            FROM login_device_requests
            WHERE user_id = ? AND status = 'PENDING'
            ORDER BY id DESC LIMIT 1
        ");
        $rStmt->bind_param("i", $userId);
        $rStmt->execute();
        $pendingReq = $rStmt->get_result()->fetch_assoc();
        $rStmt->close();

        if ($pendingReq) {
            $rem = (int)$pendingReq['remaining_seconds'];
            $secRules = getSecurityRules($db);
            if ($rem <= 0) {
                // ครบ 5 นาทีแล้ว ยกเลิกคำขอที่หมดอายุ ไม่เตะผู้เล่นที่กำลังเล่นอยู่ออกจากเกม
                $db->query("UPDATE login_device_requests SET status = 'TIMEOUT', responded_at = NOW() WHERE id = {$pendingReq['id']}");
                jsonResponse([
                    'status' => 'success',
                    'message' => 'คำขอหมดอายุแล้ว'
                ]);
            } else {
                jsonResponse([
                    'status' => 'incoming_auth_request',
                    'request' => [
                        'request_uid' => $pendingReq['request_uid'],
                        'platform' => $pendingReq['request_platform'] ?: 'อุปกรณ์อื่น',
                        'ip' => $pendingReq['request_ip'],
                        'remaining_seconds' => $rem,
                        'total_seconds' => (int)$secRules['approval_timeout_seconds']
                    ],
                    'security_rules' => $secRules
                ]);
            }
        }

        jsonResponse(['status' => 'active']);
        break;

    case 'respond_login_request':
        ensureSecurityTables($db);
        $user = requireAuth($db);
        $userId = (int)$user['id'];
        $reqUid = trim($inputData['request_uid'] ?? ($_POST['request_uid'] ?? ''));
        $decision = strtolower(trim($inputData['decision'] ?? ($_POST['decision'] ?? '')));
        if (empty($decision) && isset($inputData['approved'])) {
            $decision = (!empty($inputData['approved']) && $inputData['approved'] !== '0' && $inputData['approved'] !== 'reject') ? 'approve' : 'reject';
        }

        if (empty($reqUid) || !in_array($decision, ['approve', 'reject'], true)) {
            jsonResponse(['status' => 'error', 'message' => 'Invalid parameters'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM login_device_requests WHERE request_uid = ? AND user_id = ? LIMIT 1");
        $stmt->bind_param("si", $reqUid, $userId);
        $stmt->execute();
        $req = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$req) {
            jsonResponse(['status' => 'error', 'message' => 'Request not found'], 404);
        }
        if ($req['status'] !== 'PENDING') {
            jsonResponse(['status' => 'error', 'message' => 'Request already processed or expired'], 400);
        }

        if ($decision === 'approve') {
            $newToken = generateAuthToken($userId);
            $newDev = $req['request_device_uid'];
            $escapedDev = $db->real_escape_string($newDev);
            $escapedPlat = $db->real_escape_string($req['request_platform']);
            $escapedIp = $db->real_escape_string($req['request_ip']);
            $db->query("UPDATE login_device_requests SET status = 'APPROVED', auth_token = '{$newToken}', responded_at = NOW() WHERE id = {$req['id']}");
            $db->query("UPDATE users SET auth_token = '{$newToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW() WHERE id = {$userId}");

            jsonResponse([
                'status' => 'success',
                'decision' => 'approved',
                'message' => 'อนุมัติการเข้าสู่ระบบบนอุปกรณ์ใหม่เรียบร้อยแล้ว ระบบจะออกจากระบบเครื่องนี้ทันที'
            ]);
        } else {
            $db->query("UPDATE login_device_requests SET status = 'REJECTED', responded_at = NOW() WHERE id = {$req['id']}");
            jsonResponse([
                'status' => 'success',
                'decision' => 'rejected',
                'message' => 'ปฏิเสธการเข้าสู่ระบบจากเครื่องอื่นเรียบร้อยแล้ว บัญชีของคุณปลอดภัย'
            ]);
        }
        break;

    case 'timeout_login_request':
        ensureSecurityTables($db);
        $reqUid = trim($inputData['request_uid'] ?? ($_POST['request_uid'] ?? ''));
        if (!empty($reqUid)) {
            $db->query("UPDATE login_device_requests SET status = 'TIMEOUT', responded_at = NOW() WHERE request_uid = '" . $db->real_escape_string($reqUid) . "' AND status = 'PENDING'");
            $secRules = getSecurityRules($db);
            if (($secRules['timeout_action'] ?? '') === 'logout_both') {
                $rRes = $db->query("SELECT user_id FROM login_device_requests WHERE request_uid = '" . $db->real_escape_string($reqUid) . "' LIMIT 1");
                if ($rRes && ($rRow = $rRes->fetch_assoc())) {
                    $uId = (int)$rRow['user_id'];
                    $db->query("UPDATE users SET auth_token = NULL, current_device_uid = NULL WHERE id = {$uId}");
                }
            }
        }
        $secRules = getSecurityRules($db);
        jsonResponse([
            'status' => 'timeout',
            'message' => $secRules['timeout_notice_text'],
            'mobile_notify_text' => $secRules['mobile_notify_text']
        ]);
        break;

    case 'logout':
        $token = getBearerToken();
        if (empty($token) && !empty($inputData['token'])) {
            $token = trim((string)$inputData['token']);
        }
        $deviceUid = trim((string)($inputData['device_uid'] ?? ($_POST['device_uid'] ?? ($_COOKIE['snake_auth_device_uid'] ?? ''))));
        $userId = (int)($inputData['user_id'] ?? ($_POST['user_id'] ?? 0));

        if (!empty($token)) {
            $verifiedUid = verifyAuthToken($token);
            if ($verifiedUid) {
                $userId = $verifiedUid;
            }
        }

        if ($userId > 0) {
            $db->query("UPDATE users SET auth_token = NULL, current_device_uid = NULL, last_active_at = NOW() WHERE id = {$userId}");
            $db->query("UPDATE login_device_requests SET status = 'CANCELLED', responded_at = NOW() WHERE user_id = {$userId} AND status = 'PENDING'");
        }
        if (!empty($token)) {
            $stmt = $db->prepare("UPDATE users SET auth_token = NULL, current_device_uid = NULL, last_active_at = NOW() WHERE auth_token = ?");
            if ($stmt) {
                $stmt->bind_param("s", $token);
                $stmt->execute();
                $stmt->close();
            }
        }
        if (!empty($deviceUid)) {
            $stmt = $db->prepare("UPDATE users SET auth_token = NULL, current_device_uid = NULL, last_active_at = NOW() WHERE current_device_uid = ?");
            if ($stmt) {
                $stmt->bind_param("s", $deviceUid);
                $stmt->execute();
                $stmt->close();
            }
        }

        setcookie('snake_auth_token', '', time() - 3600, '/');
        setcookie('snake_auth_token', '', time() - 3600, '/home/snake/');
        setcookie('game_session_token', '', time() - 3600, '/');
        setcookie('snake_logged_out', '1', time() + 86400 * 365, '/');
        setcookie('snake_logged_out', '1', time() + 86400 * 365, '/home/snake/');
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        jsonResponse([
            'status' => 'success',
            'message' => 'ออกจากระบบเรียบร้อยแล้ว'
        ]);
        break;

    case 'avatar_proxy':
        $imgUrl = trim($_GET['url'] ?? '');
        if (!empty($imgUrl) && preg_match('/^https?:\/\/(lh[0-9]*\.googleusercontent\.com|profile\.line-scdn\.net|sprofile\.line-scdn\.net|obs\.line-scdn\.net|avatars\.githubusercontent\.com)\//i', $imgUrl)) {
            $ch = curl_init($imgUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_USERAGENT => 'Mozilla/5.0'
            ]);
            $imgBytes = curl_exec($ch);
            $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'image/jpeg';
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code === 200 && $imgBytes) {
                header('Access-Control-Allow-Origin: *');
                header('Content-Type: ' . $contentType);
                header('Cache-Control: public, max-age=86400');
                echo $imgBytes;
                exit;
            }
        }
        header('Location: ../avatars/google_avatar.png');
        exit;

    default:
        jsonResponse([
            'status' => 'error',
            'message' => 'Invalid action. Supported: login, logout, line_callback, google_callback, login_by_username, register_profile, login_line, login_google, update_profile, sync_progress, invite_friend, delete_account, profile'
        ], 400);
}

/**
 * เธเนเธเธซเธฒเธเธฑเธเธเธตเธเธนเนเน€เธฅเนเธเธ—เธตเนเธกเธตเธญเธขเธนเนเนเธฅเนเธงเธญเธขเนเธฒเธเนเธกเนเธเธขเธณ (เธเนเธญเธเธเธฑเธเธเธฒเธฃเธชเธฃเนเธฒเธเธเธฑเธเธเธตเธเนเธณเน€เธกเธทเนเธญเธญเธญเธเธเธฒเธเธฃเธฐเธเธเนเธฅเนเธงเน€เธเนเธฒเนเธซเธกเน)
 */
function findExistingSocialUser(mysqli $db, string $columnName, string $socialId, string $displayName): ?array {
    if (empty($socialId)) {
        return null;
    }
    // 1. ค้นหาตรงตาม google_id หรือ line_id
    $stmt = $db->prepare("SELECT id, username, avatar_url, diamond, gold, level, clan_id, is_banned, {$columnName} FROM users WHERE {$columnName} = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $socialId);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($existing) {
            return $existing;
        }
    }

    // 2. หากเป็นชื่อเฉพาะ ให้เช็คว่ามีบัญชีที่ชื่อตรงกัน 100% และยังไม่เคยผูก socialId
    if (!empty($displayName) && !in_array($displayName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE'], true) && !str_starts_with($displayName, 'LINE Player')) {
        $stmt = $db->prepare("
            SELECT id, username, avatar_url, diamond, gold, level, clan_id, is_banned, {$columnName}
            FROM users
            WHERE username = ? AND ({$columnName} IS NULL OR {$columnName} = '')
            LIMIT 1
        ");
        if ($stmt) {
            $stmt->bind_param("s", $displayName);
            $stmt->execute();
            $byName = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($byName) {
                $uid = (int)$byName['id'];
                $upd = $db->prepare("UPDATE users SET {$columnName} = ? WHERE id = ?");
                if ($upd) {
                    $upd->bind_param("si", $socialId, $uid);
                    $upd->execute();
                    $upd->close();
                }
                return $byName;
            }
        }
    }

    return null;
}

/**
 * Handle user registration or login for LINE / Google OAuth API
 */
function handleSocialLogin(mysqli $db, string $columnName, string $socialId, string $displayName, string $pictureUrl, ?int $inviterId, string $deviceUid = '', string $platform = 'Web / Mobile'): void {
    $existingUser = findExistingSocialUser($db, $columnName, $socialId, $displayName);

    $isNewUser = false;
    $userId = 0;

    if ($existingUser) {
        $userId = (int)$existingUser['id'];
        $secBlock = checkAndEnforceSingleDevice($db, $userId, $deviceUid, $platform);
        if ($secBlock) {
            jsonResponse($secBlock);
        }
    }

    if ($existingUser) {
        $userId = (int)$existingUser['id'];
        if ($existingUser['is_banned']) {
            jsonResponse(['status' => 'error', 'message' => 'เธเธฑเธเธเธตเธเธตเนเธ–เธนเธเธฃเธฐเธเธฑเธเธเธฒเธฃเนเธเนเธเธฒเธ'], 403);
        }

        // Only update username if existing username is empty or is a default placeholder!
        $currName = (string)($existingUser['username'] ?? '');
        $isDefaultName = empty($currName) || in_array($currName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE', 'ผู้เล่น', 'ยังไม่ได้เข้าสู่ระบบ'], true);
        $shouldUpdateName = $isDefaultName && !empty($displayName) && !in_array($displayName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE'], true);

        if (!empty($pictureUrl) && !str_starts_with($pictureUrl, 'avatars/')) {
            if ($shouldUpdateName) {
                $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW(), avatar_url = ?, username = ? WHERE id = ?");
                $updateStmt->bind_param("ssi", $pictureUrl, $displayName, $userId);
            } else {
                $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW(), avatar_url = ? WHERE id = ?");
                $updateStmt->bind_param("si", $pictureUrl, $userId);
            }
        } else {
            if ($shouldUpdateName) {
                $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW(), username = ? WHERE id = ?");
                $updateStmt->bind_param("si", $displayName, $userId);
            } else {
                $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW() WHERE id = ?");
                $updateStmt->bind_param("i", $userId);
            }
        }
        $updateStmt->execute();
        $updateStmt->close();
    } else {
        $isNewUser = true;
        $initialDiamond = 2000;
        $initialGold = 20000;

        $db->begin_transaction();
        try {
            $insertStmt = $db->prepare("
                INSERT INTO users 
                    ({$columnName}, username, avatar_url, diamond, gold, level, inviter_id, last_login_at, last_active_at) 
                VALUES (?, ?, ?, ?, ?, 1, ?, NOW(), NOW())
            ");
            $insertStmt->bind_param("sssiii", $socialId, $displayName, $pictureUrl, $initialDiamond, $initialGold, $inviterId);
            $insertStmt->execute();
            $userId = (int)$db->insert_id;
            $insertStmt->close();

            $defaultCharStmt = $db->prepare("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES (?, 'CHARACTER', 3, 1, 1)");
            $defaultCharStmt->bind_param("i", $userId);
            $defaultCharStmt->execute();
            $defaultCharStmt->close();

            $defaultDiceStmt = $db->prepare("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES (?, 'DICE', 1, 1, 1)");
            $defaultDiceStmt->bind_param("i", $userId);
            $defaultDiceStmt->execute();
            $defaultDiceStmt->close();

            $equipStmt = $db->prepare("UPDATE users SET equipped_character_id = 3, equipped_dice_id = 1 WHERE id = ?");
            $equipStmt->bind_param("i", $userId);
            $equipStmt->execute();
            $equipStmt->close();

            $lbStmt = $db->prepare("INSERT INTO leaderboards (user_id, season_id, rank_points, tier) VALUES (?, 1, 1000, 'BRONZE')");
            $lbStmt->bind_param("i", $userId);
            $lbStmt->execute();
            $lbStmt->close();

            $welcomeTitle = "เธขเธดเธเธ”เธตเธ•เนเธญเธเธฃเธฑเธเธชเธนเน Snake & Ladder 3D!";
            $welcomeMsg = "เธเธญเธเธเธงเธฑเธเธ•เนเธญเธเธฃเธฑเธเธเธนเนเน€เธฅเนเธเนเธซเธกเน เธฃเธฑเธ 2,000 เน€เธเธเธฃ เนเธฅเธฐ 20,000 เธ—เธญเธ เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง เธเธญเนเธซเนเธชเธเธธเธเธเธฑเธเธเธฒเธฃเธเธเธเธ เธฑเธข!";
            $mailStmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
            $mailStmt->bind_param("iss", $userId, $welcomeTitle, $welcomeMsg);
            $mailStmt->execute();
            $mailStmt->close();

            $db->commit();
        } catch (Exception $e) {
            $db->rollback();
            jsonResponse(['status' => 'error', 'message' => 'Registration failed: ' . $e->getMessage()], 500);
        }
    }

    global $inputData;
    if (empty($deviceUid)) {
        $deviceUid = $inputData['device_uid'] ?? ($_COOKIE['snake_auth_device_uid'] ?? ($_GET['device_uid'] ?? ($_POST['device_uid'] ?? '')));
    }
    if (empty($platform) || $platform === 'Web / Mobile') {
        $platform = $inputData['platform'] ?? ($_GET['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
    }

    $authToken = generateAuthToken($userId);
    $escapedDev = $db->real_escape_string($deviceUid);
    $escapedPlat = $db->real_escape_string($platform);
    $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW() WHERE id = {$userId}");

    $user = getFullUserProfileById($db, $userId);
    if ($user) {
        $user['sub'] = $socialId;
    }

    jsonResponse([
        'status' => 'success',
        'is_new_user' => $isNewUser,
        'message' => $isNewUser ? 'เธชเธกเธฑเธเธฃเธชเธกเธฒเธเธดเธเนเธซเธกเนเธชเธณเน€เธฃเนเธ เนเธ”เนเธฃเธฑเธ 2,000 เน€เธเธเธฃ เนเธฅเธฐ 20,000 เธ—เธญเธ!' : 'เน€เธเนเธฒเธชเธนเนเธฃเธฐเธเธเธชเธณเน€เธฃเนเธ เนเธซเธฅเธ”เธเนเธญเธกเธนเธฅเน€เธเธเธฃ เธ—เธญเธ เนเธฅเธฐเนเธญเน€เธ—เธกเน€เธ”เธดเธกเน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง!',
        'token' => $authToken,
        'user' => $user,
        'data' => $user
    ]);
}

/**
 * Handle social login and redirect back to game frontend with token & Google User Object
 */
function handleSocialLoginAndRedirect(mysqli $db, string $columnName, string $socialId, string $displayName, string $pictureUrl, string $providerName, string $email = ''): void {
    $existingUser = findExistingSocialUser($db, $columnName, $socialId, $displayName);

    $userId = 0;
    if ($existingUser) {
        $userId = (int)$existingUser['id'];
        if ($existingUser['is_banned']) {
            die("เธเธฑเธเธเธตเธเธตเนเธ–เธนเธเธฃเธฐเธเธฑเธเธเธฒเธฃเนเธเนเธเธฒเธ");
        }
        $currName = (string)($existingUser['username'] ?? '');
        $isDefaultName = empty($currName) || in_array($currName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE', 'ผู้เล่น', 'ยังไม่ได้เข้าสู่ระบบ'], true);
        $shouldUpdateName = $isDefaultName && !empty($displayName) && !in_array($displayName, ['Google Player', 'LINE Player', 'ผู้เล่น Google', 'ผู้เล่น LINE'], true);

        if ($shouldUpdateName) {
            $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW(), username = ? WHERE id = ?");
            $updateStmt->bind_param("si", $displayName, $userId);
        } else {
            $updateStmt = $db->prepare("UPDATE users SET last_login_at = NOW(), last_active_at = NOW() WHERE id = ?");
            $updateStmt->bind_param("i", $userId);
        }
        $updateStmt->execute();
        $updateStmt->close();
    } else {
        $initialDiamond = 2000;
        $initialGold = 20000;
        $db->begin_transaction();
        try {
            $insertStmt = $db->prepare("INSERT INTO users ({$columnName}, username, avatar_url, diamond, gold, level, last_login_at, last_active_at) VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())");
            $insertStmt->bind_param("sssii", $socialId, $displayName, $pictureUrl, $initialDiamond, $initialGold);
            $insertStmt->execute();
            $userId = (int)$db->insert_id;
            $insertStmt->close();

            $db->query("INSERT INTO user_inventory (user_id, item_type, character_id, level, is_equipped) VALUES ({$userId}, 'CHARACTER', 3, 1, 1)");
            $db->query("INSERT INTO user_inventory (user_id, item_type, dice_id, level, is_equipped) VALUES ({$userId}, 'DICE', 1, 1, 1)");
            $db->query("UPDATE users SET equipped_character_id = 3, equipped_dice_id = 1 WHERE id = {$userId}");
            $db->query("INSERT INTO leaderboards (user_id, season_id, rank_points, tier) VALUES ({$userId}, 1, 1000, 'BRONZE')");
            $db->commit();
        } catch (Exception $e) {
            $db->rollback();
            die("OAuth registration failed: " . $e->getMessage());
        }
    }

    global $inputData;
    if (empty($deviceUid)) {
        $deviceUid = $inputData['device_uid'] ?? ($_COOKIE['snake_auth_device_uid'] ?? ($_GET['device_uid'] ?? ($_POST['device_uid'] ?? '')));
    }
    if (empty($platform) || $platform === 'Web / Mobile') {
        $platform = $inputData['platform'] ?? ($_GET['platform'] ?? ($_POST['platform'] ?? 'Web / Mobile'));
    }

    $authToken = generateAuthToken($userId);
    $escapedDev = $db->real_escape_string($deviceUid);
    $escapedPlat = $db->real_escape_string($platform);
    $escapedIp = $db->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $db->query("UPDATE users SET auth_token = '{$authToken}', current_device_uid = '{$escapedDev}', last_device_name = '{$escapedPlat}', last_device_ip = '{$escapedIp}', last_active_at = NOW() WHERE id = {$userId}");

    $fullUser = getFullUserProfileById($db, $userId);
    $finalName = $fullUser['username'] ?? $displayName;
    $finalPic = $fullUser['avatar_url'] ?? $pictureUrl;

    // Pass Google User Object fields + saved Diamond/Gold/Clan back to frontend
    $googleUserPayload = base64_encode((string)json_encode([
        'id'        => $userId,
        'user_id'   => $userId,
        'sub'       => $socialId,
        'google_id' => $fullUser['google_id'] ?? $socialId,
        'line_id'   => $fullUser['line_id'] ?? null,
        'username'  => $finalName,
        'name'      => $finalName,
        'avatar_url'=> $finalPic,
        'picture'   => $finalPic,
        'email'     => !empty($email) ? $email : $socialId,
        'diamond'   => (int)($fullUser['diamond'] ?? 2000),
        'gold'      => (int)($fullUser['gold'] ?? 20000),
        'level'     => (int)($fullUser['level'] ?? 1),
        'clan_id'   => $fullUser['clan_id'] ?? null,
        'clan_name' => $fullUser['clan_name'] ?? null,
        'provider'  => strtolower($providerName)
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    $redirectParams = http_build_query([
        'token'         => $authToken,
        'auth_token'    => $authToken,
        'auth_provider' => $providerName,
        'google_user'   => $googleUserPayload,
        'name'          => $finalName,
        'picture'       => $finalPic,
        'email'         => !empty($email) ? $email : $socialId,
        'sub'           => $socialId
    ]);

    // Determine dynamic return base URL based on incoming request or return_url cookie
    $returnFromCookie = $_COOKIE['snake_auth_return_url'] ?? '';
    if (!empty($returnFromCookie)) {
        setcookie('snake_auth_return_url', '', time() - 3600, '/', '', false, false);
    }

    if (!empty($returnFromCookie) && preg_match('#^https?://[a-zA-Z0-9.\-_:]+#', $returnFromCookie)) {
        $cleanReturn = explode('?', $returnFromCookie)[0];
        $redirectBase = rtrim($cleanReturn, '/') . '/';
    } else {
        $reqHost = $_SERVER['HTTP_HOST'] ?? 'pmix01.thddns.net:7175';
        $isHttps = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
                || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
                || (isset($_SERVER['SERVER_PORT']) && in_array((int)$_SERVER['SERVER_PORT'], [443, 7175], true));
        $reqProto = $isHttps ? 'https' : 'http';

        $currentUri = $_SERVER['REQUEST_URI'] ?? '/api/auth.php';
        $basePath = '/';
        if (strpos($currentUri, '/home/snake/') !== false) {
            $basePath = '/home/snake/';
        } elseif (strpos($currentUri, '/snake/') !== false) {
            $basePath = '/snake/';
        }
        $redirectBase = $reqProto . '://' . $reqHost . $basePath;
    }
    header("Location: " . $redirectBase . '?' . $redirectParams);
    exit;
}
