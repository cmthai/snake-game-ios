<?php
declare(strict_types=1);

/**
 * leaderboard.php - Leaderboards, Match History & Weekly Ranking Reset API
 * PHP 8.4.25 / Nginx 1.31.6
 * Features:
 *  - Global Solo Ranking (Rank, Username, Clan, Level, Wins, Losses, Win Rate, Tier, Level Icon)
 *  - Clan Ranking (Rank, Clan Name, Total Score, Clan Level, Members, Badge)
 *  - Player Stats & Match History Popup (เดี่ยว 4, เดี่ยว 2, ทีม, ใครชนะใครแพ้, ได้/เสียคะแนนทอง)
 *  - Weekly Wednesday 10:00 AM Reset Schedule (แข่งจัดอันดับ 1 อาทิตย์ รีเซ็ตทุกวันพุธ 10:00 น.)
 *  - Admin Configurable Ranking Points & Gold Gain/Loss
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/level_config_helper.php';

date_default_timezone_set('Asia/Bangkok'); // ใช้เวลาประเทศไทย (UTC+7)

$db = getDbConnection();
ensureRankingAndHistoryTables($db);

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$type = $_GET['type'] ?? 'all'; // 'solo', 'clan', 'player_stats', 'player_history', 'weekly_status', 'ranking_config', 'all'
$seasonId = !empty($_GET['season_id']) ? (int)$_GET['season_id'] : 1;
$limit = !empty($_GET['limit']) ? min(100, (int)$_GET['limit']) : 50;

/**
 * ตรวจสอบและสร้างตาราง match_history และ ranking_config อัตโนมัติ
 */
function ensureRankingAndHistoryTables(mysqli $db): void {
    static $initialized = false;
    if ($initialized) return;
    $initialized = true;

    // ตารางประวัติการแข่งขันของผู้เล่น (Match History)
    $db->query("
        CREATE TABLE IF NOT EXISTS `match_history` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `match_id` VARCHAR(64) NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            `game_mode` VARCHAR(30) NOT NULL DEFAULT '4P' COMMENT '4P (เดี่ยว 4), 2P (เดี่ยว 2), 3P, TEAM',
            `room_fee` INT NOT NULL DEFAULT 2000,
            `rank_place` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'อันดับที่ได้ 1-4',
            `is_winner` TINYINT(1) NOT NULL DEFAULT 0,
            `win_reason` VARCHAR(40) NOT NULL DEFAULT 'FINISH_LINE' COMMENT 'FINISH_LINE, BANKRUPTCY, TIME_OUT',
            `gold_change` BIGINT NOT NULL DEFAULT 0 COMMENT 'คะแนนทองที่ได้ (+) หรือเสีย (-)',
            `rank_points_change` INT NOT NULL DEFAULT 0 COMMENT 'คะแนน RP ที่ได้ (+) หรือเสีย (-)',
            `is_protected` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ใช้ทองรักษาอันดับหรือไม่ (1 = ป้องกันแล้ว)',
            `total_assets` BIGINT NOT NULL DEFAULT 0 COMMENT 'มูลค่าสินทรัพย์รวม (ทอง + สิ่งก่อสร้าง)',
            `cash_gold` BIGINT NOT NULL DEFAULT 0,
            `cities_count` INT NOT NULL DEFAULT 0,
            `players_summary_json` LONGTEXT NULL COMMENT 'รายชื่อผู้เล่นทั้งหมดในแมตช์ ใครชนะ ใครแพ้ อันดับ 1-4',
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_user_created` (`user_id`, `created_at`),
            KEY `idx_match_id` (`match_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    @$db->query("ALTER TABLE `match_history` ADD COLUMN IF NOT EXISTS `is_protected` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ใช้ทองรักษาอันดับหรือไม่'");

    // ตารางตั้งค่าระบบจัดอันดับ (Admin Ranking Config)
    $db->query("
        CREATE TABLE IF NOT EXISTS `ranking_config` (
            `config_key` VARCHAR(60) NOT NULL,
            `config_value` TEXT NOT NULL,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`config_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // ค่าเริ่มต้นระบบคะแนนอันดับระดับหมื่น/พันแต้ม และค่าทองรักษาอันดับ
    $defaultConfigs = [
        'reset_day' => '3',             // 3 = วันพุธ
        'reset_hour' => '10',           // 10:00 น.
        'reset_minute' => '0',          // 00 นาที
        'season_number' => '1',
        'points_4p_rank1' => '12000',   // เดี่ยว 4 อันดับ 1 (+12,000 RP)
        'points_4p_rank2' => '3000',    // เดี่ยว 4 อันดับ 2 (+3,000 RP)
        'points_4p_rank3' => '-2500',   // เดี่ยว 4 อันดับ 3 (-2,500 RP)
        'points_4p_rank4' => '-5000',   // เดี่ยว 4 อันดับ 4 (-5,000 RP ตามตัวอย่างผู้ใช้)
        'gold_4p_rank1' => '300000',    // ทองรางวัลอันดับ 1
        'gold_4p_rank2' => '100000',    // อันดับ 2
        'gold_4p_rank3' => '-30000',    // อันดับ 3 เสียทอง
        'gold_4p_rank4' => '-50000',    // อันดับ 4 เสียทอง
        'points_1v1_win' => '10000',    // เดี่ยว 2 ชนะ (+10,000 RP)
        'points_1v1_loss' => '-5000',   // เดี่ยว 2 แพ้ (-5,000 RP)
        'rank_protect_cost_gold' => '150000', // ค่าทองรักษาอันดับเมื่อแพ้ (150,000 ทอง)
        'maintain_min_matches' => '5',  // จำนวนแมตช์ขั้นต่ำต่อสัปดาห์เพื่อรักษาอันดับ
        'maintain_min_points' => '5000' // คะแนนรักษาอันดับ
    ];

    foreach ($defaultConfigs as $key => $val) {
        $stmt = $db->prepare("INSERT IGNORE INTO `ranking_config` (`config_key`, `config_value`) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $key, $val);
            $stmt->execute();
            $stmt->close();
        }
    }

    // อัปเกรดค่าคะแนนอันดับให้เป็นระบบหลักพัน/หมื่นแต้มอัตโนมัติหากพบค่าเก่า (< 500)
    $chkRes = $db->query("SELECT `config_value` FROM `ranking_config` WHERE `config_key` = 'points_4p_rank1'");
    if ($chkRes && ($chkRow = $chkRes->fetch_assoc())) {
        if ((int)$chkRow['config_value'] < 500) {
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_4p_rank1', '12000')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_4p_rank2', '3000')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_4p_rank3', '-2500')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_4p_rank4', '-5000')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_1v1_win', '10000')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('points_1v1_loss', '-5000')");
            $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('rank_protect_cost_gold', '150000')");
        }
    }

    // ตารางระบบเพื่อน (สูงสุด 200 คน, สถานะ PENDING รออนุมัติ / ACCEPTED อนุมัติแล้ว, แยกเพื่อนในบ้าน/นอกบ้าน)
    $db->query("
        CREATE TABLE IF NOT EXISTS `user_friends` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `user_id` INT UNSIGNED NOT NULL,
            `friend_user_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `friend_name` VARCHAR(100) NOT NULL,
            `friend_avatar` VARCHAR(255) NOT NULL DEFAULT 'avatars/bots/bot_f01.jpg',
            `friend_level` INT NOT NULL DEFAULT 25,
            `friend_grade` VARCHAR(16) NOT NULL DEFAULT 'SS+',
            `friend_clan` VARCHAR(100) NOT NULL DEFAULT '@PIMMY',
            `friend_rank_points` INT NOT NULL DEFAULT 1500,
            `friend_wins` INT NOT NULL DEFAULT 10,
            `friend_losses` INT NOT NULL DEFAULT 4,
            `is_same_clan` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=เพื่อนในบ้าน, 0=เพื่อนนอกบ้าน',
            `is_online` TINYINT(1) NOT NULL DEFAULT 1,
            `status` VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING=รอเพื่อนอนุมัติ, ACCEPTED=เพื่อนอนุมัติแล้ว',
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_user_friend_name` (`user_id`, `friend_name`),
            KEY `idx_user_status` (`user_id`, `status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

/**
 * สร้างรายชื่อเพื่อนเริ่มต้น (ทั้งเพื่อนในบ้านและเพื่อนนอกบ้าน) หากผู้เล่นยังไม่มีข้อมูลในตาราง
 */
function ensureDefaultFriendsForUser(mysqli $db, int $userId, string $myClan = '@PIMMY'): void {
    if ($userId <= 0) return;
    $chk = $db->query("SELECT COUNT(*) AS cnt FROM `user_friends` WHERE `user_id` = {$userId}");
    $cnt = ($chk && ($r = $chk->fetch_assoc())) ? (int)$r['cnt'] : 0;
    if ($cnt > 0) return;

    $seedFriends = [
        // เพื่อนในบ้าน (is_same_clan = 1, ACCEPTED)
        [901, 'แพรวา พารวย', 'avatars/bots/bot_f01.jpg', 28, 'SS+', $myClan, 28500, 48, 14, 1, 1, 'ACCEPTED'],
        [902, 'นนท์ เซียนเต๋า', 'avatars/bots/bot_m01.jpg', 26, 'SS+', $myClan, 24200, 39, 16, 1, 1, 'ACCEPTED'],
        [905, 'ฟ้าใส ไฮโซ', 'avatars/bots/bot_f03.jpg', 24, 'S+', $myClan, 19800, 31, 15, 1, 1, 'ACCEPTED'],
        // เพื่อนนอกบ้าน (is_same_clan = 0, ACCEPTED)
        [903, 'มินตรา ดาวเหนือ', 'avatars/bots/bot_f02.jpg', 29, 'SS+', 'บ้านพญานาคราช', 31400, 55, 18, 0, 1, 'ACCEPTED'],
        [904, 'กานต์ อัศวิน', 'avatars/bots/bot_m02.jpg', 25, 'S+', 'บ้านมังกรทองคำ', 21600, 34, 19, 0, 1, 'ACCEPTED'],
        [906, 'ภูผา มหาเศรษฐี', 'avatars/bots/bot_m03.jpg', 22, 'S+', 'บ้านพยัคฆ์สายฟ้า', 16400, 25, 14, 0, 1, 'ACCEPTED'],
        // รอเพื่อนอนุมัติ (PENDING)
        [907, 'น้ำหวาน สายเปย์', 'avatars/bots/bot_f04.jpg', 27, 'SS+', $myClan, 22900, 36, 12, 1, 1, 'PENDING'],
        [908, 'เตโช จ้าวสมุทร', 'avatars/bots/bot_m04.jpg', 23, 'S+', 'บ้านราชันย์มังกร', 17500, 28, 17, 0, 1, 'PENDING']
    ];

    $stmt = $db->prepare("
        INSERT IGNORE INTO `user_friends` (
            `user_id`, `friend_user_id`, `friend_name`, `friend_avatar`, `friend_level`,
            `friend_grade`, `friend_clan`, `friend_rank_points`, `friend_wins`, `friend_losses`,
            `is_same_clan`, `is_online`, `status`
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if ($stmt) {
        foreach ($seedFriends as $f) {
            $stmt->bind_param(
                "iississiiiiis",
                $userId, $f[0], $f[1], $f[2], $f[3],
                $f[4], $f[5], $f[6], $f[7], $f[8],
                $f[9], $f[10], $f[11]
            );
            $stmt->execute();
        }
        $stmt->close();
    }
}

/**
 * ดึงการตั้งค่า Admin ทั้งหมด
 */
function getRankingConfigMap(mysqli $db): array {
    $res = $db->query("SELECT `config_key`, `config_value` FROM `ranking_config`");
    $map = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $map[$r['config_key']] = $r['config_value'];
        }
    }
    return $map;
}

/**
 * คำนวณรอบสัปดาห์และการนับถอยหลังสู่วันพุธ 10:00 น. (Wednesday 10:00 AM)
 */
function getWeeklyRankingResetSchedule(mysqli $db): array {
    $configs = getRankingConfigMap($db);
    $targetDay = (int)($configs['reset_day'] ?? 3); // 3 = Wednesday
    $targetHour = (int)($configs['reset_hour'] ?? 10); // 10:00 AM
    $targetMin = (int)($configs['reset_minute'] ?? 0);
    $seasonNum = (int)($configs['season_number'] ?? 1);

    $now = new DateTime('now', new DateTimeZone('Asia/Bangkok'));
    $currentDay = (int)$now->format('w'); // 0=Sun, 1=Mon, ..., 3=Wed

    // วันพุธถัดไป
    $daysUntilWed = ($targetDay - $currentDay + 7) % 7;
    $targetWed = clone $now;
    $targetWed->modify("+{$daysUntilWed} days");
    $targetWed->setTime($targetHour, $targetMin, 0);

    // หากวันนี้เป็นวันพุธ และเวลาเลย 10:00 น. ไปแล้ว ให้รอบถัดไปเป็นวันพุธสัปดาห์หน้า
    if ($daysUntilWed === 0 && $now >= $targetWed) {
        $targetWed->modify("+7 days");
    }

    // วันพุธที่ผ่านมา (จุดเริ่มต้นรอบปัจจุบัน)
    $lastWed = clone $targetWed;
    $lastWed->modify("-7 days");

    $secondsLeft = max(0, $targetWed->getTimestamp() - $now->getTimestamp());
    $days = floor($secondsLeft / 86400);
    $hours = floor(($secondsLeft % 86400) / 3600);
    $mins = floor(($secondsLeft % 3600) / 60);
    $secs = $secondsLeft % 60;

    $thaiDays = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    $targetDayName = $thaiDays[$targetDay] ?? 'พุธ';

    return [
        'season_number' => $seasonNum,
        'current_time' => $now->format('Y-m-d H:i:s'),
        'season_start_at' => $lastWed->format('Y-m-d H:i:s'),
        'next_reset_at' => $targetWed->format('Y-m-d H:i:s'),
        'next_reset_timestamp' => $targetWed->getTimestamp(),
        'seconds_remaining' => $secondsLeft,
        'days_remaining' => $days,
        'hours_remaining' => $hours,
        'minutes_remaining' => $mins,
        'seconds_remaining_in_minute' => $secs,
        'formatted_countdown' => sprintf('%d วัน %02d:%02d:%02d ชม.', $days, $hours, $mins, $secs),
        'rule_description' => "แข่งจัดอันดับ 1 สัปดาห์ • รีเซ็ตทุกวัน{$targetDayName} เวลา 10:00 น. ตรง",
        'maintenance_min_matches' => (int)($configs['maintain_min_matches'] ?? 5),
        'maintenance_min_points' => (int)($configs['maintain_min_points'] ?? 1000)
    ];
}

/**
 * สัญลักษณ์เลเวลและไอคอน
 */
function getLevelBadgeInfo(int $level): array {
    if ($level >= 30) {
        return ['title' => 'เทพแห่งบันไดงู (Grand Master)', 'icon' => '👑✨', 'badge_class' => 'badge-grandmaster', 'color' => '#FFD700'];
    } elseif ($level >= 20) {
        return ['title' => 'ปรมาจารย์ลูกเต๋า (Master)', 'icon' => '🔮', 'badge_class' => 'badge-master', 'color' => '#A855F7'];
    } elseif ($level >= 15) {
        return ['title' => 'ยอดฝีมือเพชร (Diamond)', 'icon' => '💎', 'badge_class' => 'badge-diamond', 'color' => '#06B6D4'];
    } elseif ($level >= 10) {
        return ['title' => 'อัศวินทองคำ (Gold)', 'icon' => '🥇', 'badge_class' => 'badge-gold', 'color' => '#F59E0B'];
    } elseif ($level >= 6) {
        return ['title' => 'นักรบเงิน (Silver)', 'icon' => '🥈', 'badge_class' => 'badge-silver', 'color' => '#94A3B8'];
    } else {
        return ['title' => 'นักผจญภัยมือใหม่ (Bronze)', 'icon' => '🥉', 'badge_class' => 'badge-bronze', 'color' => '#CD7F32'];
    }
}

// =========================================================================
// ACTION HANDLERS (POST / PUT Requests)
// =========================================================================

// 1. บันทึกผลการแข่งขันและประวัติการเล่น (Record Match History)
if ($action === 'record_match' || $type === 'record_match') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?: $_POST;

    $matchId = $data['match_id'] ?? ('match_' . uniqid('', true));
    $userId = (int)($data['user_id'] ?? 0);
    $gameMode = $data['game_mode'] ?? '4P';
    $roomFee = (int)($data['room_fee'] ?? 2000);
    $winReason = $data['win_reason'] ?? 'FINISH_LINE';
    $players = $data['players'] ?? [];

    if ($userId <= 0 && !empty($players[0]['id'])) {
        $userId = (int)$players[0]['id'];
    }

    $configs = getRankingConfigMap($db);

    // คำนวณคะแนนและทองของผู้เล่น
    $myRank = 1;
    $isWinner = false;
    $myAssets = 0;
    $myCash = 0;
    $myCities = 0;

    foreach ($players as $idx => $p) {
        if ((int)($p['id'] ?? 0) === $userId || $idx === 0) {
            $myRank = (int)($p['rank'] ?? ($idx + 1));
            $isWinner = !empty($p['is_winner']) || ($myRank === 1);
            $myAssets = (int)($p['total_assets'] ?? 0);
            $myCash = (int)($p['matchGold'] ?? $p['cash_gold'] ?? 0);
            $myCities = (int)($p['city_counts']['cities'] ?? $p['cities_count'] ?? 0);
            break;
        }
    }

    // คำนวณคะแนนและทองที่ได้รับ/เสียตามการตั้งค่าของ Admin
    $goldChange = 0;
    $rpChange = 0;

    $rpTable4P = [
        1 => (int)($configs['points_4p_rank1'] ?? 12000),
        2 => (int)($configs['points_4p_rank2'] ?? 3000),
        3 => (int)($configs['points_4p_rank3'] ?? -2500),
        4 => (int)($configs['points_4p_rank4'] ?? -5000),
    ];
    $goldTable4P = [
        1 => (int)($configs['gold_4p_rank1'] ?? 300000),
        2 => (int)($configs['gold_4p_rank2'] ?? 100000),
        3 => (int)($configs['gold_4p_rank3'] ?? -30000),
        4 => (int)($configs['gold_4p_rank4'] ?? -50000),
    ];

    $is4P = ($gameMode === '4P' || count($players) >= 4);

    $lineMult = 1;
    if ($winReason === 'VERTICAL_LINE_VICTORY') {
        $lineMult = 3;
    } elseif ($winReason === 'HORIZONTAL_LINE_VICTORY') {
        $lineMult = 2;
    } elseif (!empty($data['line_multiplier'])) {
        $lineMult = max(1, (int)$data['line_multiplier']);
    }

    if ($is4P) {
        $rpChange = $rpTable4P[$myRank] ?? ($myRank === 1 ? 12000 : -5000);
        $goldChange = $goldTable4P[$myRank] ?? ($myRank === 1 ? 300000 : 0);
    } else { // 1v1 หรือโหมดอื่นๆ
        if ($isWinner || $myRank === 1) {
            $rpChange = (int)($configs['points_1v1_win'] ?? 10000);
            $goldChange = (int)($configs['gold_4p_rank1'] ?? 300000);
        } else {
            $rpChange = (int)($configs['points_1v1_loss'] ?? -5000);
            $goldChange = -1 * $roomFee;
        }
    }

    // หากชนะแบบ Line Monopoly (แนวนอน x2) หรือ Column Monopoly (แนวตั้ง x3) ให้คูณคะแนนอันดับและทอง
    if ($isWinner && $lineMult > 1) {
        $rpChange = $rpChange * $lineMult;
        $goldChange = $goldChange * $lineMult;
    }

    // กำหนดคะแนนอันดับ (RP Change) ให้กับผู้เล่นทุกคนในแมตช์
    foreach ($players as $idx => &$p) {
        $pRank = (int)($p['rank'] ?? ($idx + 1));
        $pIsWinner = (!empty($p['is_winner']) || $pRank === 1);
        $m = $pIsWinner ? $lineMult : 1;
        if ($is4P) {
            $p['rp_change'] = ($rpTable4P[$pRank] ?? ($pRank === 1 ? 12000 : -5000)) * $m;
            $p['gold_gain'] = ($goldTable4P[$pRank] ?? 0) * $m;
        } else {
            $p['rp_change'] = (($pRank === 1) ? (int)($configs['points_1v1_win'] ?? 10000) : (int)($configs['points_1v1_loss'] ?? -5000)) * $m;
            $p['gold_gain'] = (($pRank === 1) ? 300000 : (-1 * $roomFee)) * $m;
        }
    }
    unset($p);

    $playersSummaryJson = json_encode($players, JSON_UNESCAPED_UNICODE);

    // บันทึกลงตาราง match_history
    $stmt = $db->prepare("
        INSERT INTO `match_history` (
            `match_id`, `user_id`, `game_mode`, `room_fee`, `rank_place`, `is_winner`,
            `win_reason`, `gold_change`, `rank_points_change`, `is_protected`, `total_assets`,
            `cash_gold`, `cities_count`, `players_summary_json`
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
    ");
    if ($stmt) {
        $stmt->bind_param(
            "sisiisiiiiiss",
            $matchId, $userId, $gameMode, $roomFee, $myRank, $isWinner,
            $winReason, $goldChange, $rpChange, $myAssets,
            $myCash, $myCities, $playersSummaryJson
        );
        $stmt->execute();
        $historyId = $stmt->insert_id;
        $stmt->close();
    } else {
        $historyId = 0;
    }

    // อัปเดตตาราง leaderboards
    if ($userId > 0) {
        $updWin = $isWinner ? 1 : 0;
        $updLoss = $isWinner ? 0 : 1;
        $db->query("
            UPDATE leaderboards 
            SET total_matches = total_matches + 1,
                total_wins = total_wins + {$updWin},
                total_losses = total_losses + {$updLoss},
                rank_points = GREATEST(0, rank_points + {$rpChange}),
                current_win_streak = IF({$updWin} = 1, current_win_streak + 1, 0),
                max_win_streak = GREATEST(max_win_streak, IF({$updWin} = 1, current_win_streak + 1, max_win_streak)),
                win_rate = ROUND((total_wins + {$updWin}) / (total_matches + 1) * 100, 2),
                last_match_at = NOW()
            WHERE user_id = {$userId}
        ");
    }

    $protectCost = (int)($configs['rank_protect_cost_gold'] ?? 150000);
    $rewardDia = $isWinner ? (200 * $lineMult) : 0;

    jsonResponse([
        'status' => 'success',
        'history_id' => $historyId,
        'match_id' => $matchId,
        'my_rank' => $myRank,
        'is_winner' => $isWinner,
        'win_reason' => $winReason,
        'line_multiplier' => $lineMult,
        'reward_diamond' => $rewardDia,
        'reward_gold' => $isWinner ? $goldChange : 0,
        'rank_points_change' => $rpChange,
        'gold_change' => $goldChange,
        'protect_cost_gold' => $protectCost,
        'can_protect_rank' => ($rpChange < 0),
        'players' => $players
    ]);
}

// 1.5 ผู้เล่นใช้ทองรักษาอันดับ (Rank Protection Shield)
if ($action === 'protect_rank' || $type === 'protect_rank') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?: $_POST;

    $userId = (int)($data['user_id'] ?? 0);
    $historyId = (int)($data['history_id'] ?? 0);
    $configs = getRankingConfigMap($db);
    $cost = (int)($configs['rank_protect_cost_gold'] ?? 150000);

    if ($userId <= 0) {
        jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสผู้เล่น']);
    }

    // ตรวจสอบยอดทองของผู้เล่น
    $uStmt = $db->prepare("SELECT gold FROM users WHERE id = ?");
    $uStmt->bind_param("i", $userId);
    $uStmt->execute();
    $uRes = $uStmt->get_result()->fetch_assoc();
    $uStmt->close();

    $userGold = (int)($uRes['gold'] ?? 0);
    if ($userGold < $cost) {
        jsonResponse([
            'status' => 'error',
            'message' => 'ทองของคุณไม่เพียงพอสำหรับการรักษาอันดับ (ต้องการ ' . number_format($cost) . ' ทอง, ปัจจุบันมี ' . number_format($userGold) . ' ทอง)'
        ]);
    }

    $rpRestored = 5000;
    if ($historyId > 0) {
        $hStmt = $db->prepare("SELECT rank_points_change, is_protected FROM match_history WHERE id = ? AND user_id = ?");
        if ($hStmt) {
            $hStmt->bind_param("ii", $historyId, $userId);
            $hStmt->execute();
            $hRow = $hStmt->get_result()->fetch_assoc();
            $hStmt->close();
            if ($hRow) {
                if (!empty($hRow['is_protected'])) {
                    jsonResponse(['status' => 'error', 'message' => 'แมตช์นี้ได้รับการรักษาอันดับไปแล้ว']);
                }
                $rpRestored = abs((int)$hRow['rank_points_change']);
            }
        }
    }

    // หักทอง และคืนแต้มคะแนนอันดับที่เสียไปให้กับผู้เล่น
    $db->query("UPDATE users SET gold = GREATEST(0, gold - {$cost}) WHERE id = {$userId}");
    $db->query("UPDATE leaderboards SET rank_points = rank_points + {$rpRestored} WHERE user_id = {$userId}");

    if ($historyId > 0) {
        $db->query("UPDATE match_history SET is_protected = 1, rank_points_change = 0 WHERE id = {$historyId}");
    }

    $currUser = $db->query("SELECT gold FROM users WHERE id = {$userId}")->fetch_assoc();
    $currLb = $db->query("SELECT rank_points FROM leaderboards WHERE user_id = {$userId}")->fetch_assoc();

    jsonResponse([
        'status' => 'success',
        'message' => '🛡️ ใช้ทอง ' . number_format($cost) . ' รักษาอันดับสำเร็จ! แต้มของคุณได้รับการปกป้อง',
        'cost_gold' => $cost,
        'restored_points' => $rpRestored,
        'new_gold' => (int)($currUser['gold'] ?? 0),
        'new_rank_points' => (int)($currLb['rank_points'] ?? 0)
    ]);
}

// 2. Admin: บันทึกการตั้งค่าระบบจัดอันดับ (Save Ranking Config)
if ($action === 'save_ranking_config') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?: $_POST;

    $allowed = [
        'points_4p_rank1', 'points_4p_rank2', 'points_4p_rank3', 'points_4p_rank4',
        'gold_4p_rank1', 'gold_4p_rank2', 'gold_4p_rank3', 'gold_4p_rank4',
        'points_1v1_win', 'points_1v1_loss', 'maintain_min_matches', 'maintain_min_points',
        'reset_day', 'reset_hour', 'reset_minute'
    ];

    foreach ($allowed as $k) {
        if (isset($data[$k])) {
            $val = trim((string)$data[$k]);
            $stmt = $db->prepare("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES (?, ?)");
            $stmt->bind_param("ss", $k, $val);
            $stmt->execute();
            $stmt->close();
        }
    }

    jsonResponse(['status' => 'success', 'message' => 'บันทึกการตั้งค่าระบบจัดอันดับเรียบร้อยแล้ว']);
}

// 3. Admin: สั่งรีเซ็ตอันดับประจำสัปดาห์ทันที (Manual Reset Season)
if ($action === 'manual_reset_season') {
    // เพิ่มหมายเลขซีซั่น
    $configs = getRankingConfigMap($db);
    $nextSeason = ((int)($configs['season_number'] ?? 1)) + 1;
    $db->query("REPLACE INTO `ranking_config` (`config_key`, `config_value`) VALUES ('season_number', '{$nextSeason}')");

    // Soft reset คะแนนผู้เล่นเพื่อความตื่นเต้นในสัปดาห์ใหม่
    $db->query("
        UPDATE `leaderboards` 
        SET rank_points = 1000, 
            total_matches = 0, 
            total_wins = 0, 
            total_losses = 0, 
            win_rate = 0, 
            current_win_streak = 0
    ");

    jsonResponse([
        'status' => 'success',
        'message' => "รีเซ็ตจัดอันดับประจำสัปดาห์สำเร็จ! เริ่มต้น Season #{$nextSeason}",
        'new_season' => $nextSeason
    ]);
}

// 3.5 ระบบจัดการเพื่อน (ส่งคำขอเพิ่มเพื่อน / อนุมัติเพื่อน / ลบเพื่อน สูงสุด 200 คน)
if (in_array($action, ['send_friend_request', 'approve_friend_request', 'remove_friend'], true) ||
    in_array($type, ['send_friend_request', 'approve_friend_request', 'remove_friend'], true)) {
    $act = $action ?: $type;
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?: $_POST;

    $userId = (int)($data['user_id'] ?? $_GET['user_id'] ?? 0);
    if ($userId <= 0) {
        jsonResponse(['status' => 'error', 'message' => 'Unauthorized or missing user_id'], 401);
    }
    $myClan = trim((string)($data['my_clan'] ?? '@PIMMY'));
    ensureDefaultFriendsForUser($db, $userId, $myClan);

    $cntRes = $db->query("SELECT COUNT(*) AS cnt FROM `user_friends` WHERE `user_id` = {$userId} AND `status` = 'ACCEPTED'");
    $acceptedCount = ($cntRes && ($r = $cntRes->fetch_assoc())) ? (int)$r['cnt'] : 0;

    if ($act === 'send_friend_request') {
        $friendName = trim((string)($data['friend_name'] ?? ''));
        $friendUserId = (int)($data['friend_user_id'] ?? 0);
        $friendAvatar = trim((string)($data['friend_avatar'] ?? 'avatars/bots/bot_f01.jpg'));
        $friendLevel = max(1, (int)($data['friend_level'] ?? 25));
        $friendGrade = trim((string)($data['friend_grade'] ?? 'SS+'));
        $friendClan = trim((string)($data['friend_clan'] ?? 'บ้านมังกรทองคำ'));
        $friendRp = max(1000, (int)($data['friend_rank_points'] ?? (15000 + ($friendLevel * 450))));
        $friendWins = max(1, (int)($data['friend_wins'] ?? 25));
        $friendLosses = max(1, (int)($data['friend_losses'] ?? 10));
        $isSameClan = (!empty($data['is_same_clan']) || $friendClan === $myClan) ? 1 : 0;

        if ($friendName === '') {
            jsonResponse(['status' => 'error', 'message' => 'ไม่พบชื่อผู้เล่นที่ต้องการเพิ่มเพื่อน']);
        }

        if ($acceptedCount >= 200) {
            jsonResponse([
                'status' => 'error',
                'message' => 'ไม่สามารถเพิ่มเพื่อนได้ เนื่องจากมีเพื่อนครบสูงสุด 200 คนแล้ว (200/200)',
                'friends_count' => $acceptedCount,
                'max_friends' => 200
            ]);
        }

        // ตรวจสอบว่ามีในระบบหรือยัง
        $chkStmt = $db->prepare("SELECT `id`, `status` FROM `user_friends` WHERE `user_id` = ? AND `friend_name` = ? LIMIT 1");
        $existing = null;
        if ($chkStmt) {
            $chkStmt->bind_param("is", $userId, $friendName);
            $chkStmt->execute();
            $existing = $chkStmt->get_result()->fetch_assoc();
            $chkStmt->close();
        }

        if ($existing) {
            $st = $existing['status'];
            jsonResponse([
                'status' => 'success',
                'friend_status' => $st,
                'message' => $st === 'ACCEPTED' ? "คุณเป็นเพื่อนกับ {$friendName} อยู่แล้ว" : "ส่งคำขอเป็นเพื่อนไปยัง {$friendName} แล้ว (รอเพื่อนอนุมัติ)",
                'friends_count' => $acceptedCount,
                'max_friends' => 200
            ]);
        }

        $insStmt = $db->prepare("
            INSERT INTO `user_friends` (
                `user_id`, `friend_user_id`, `friend_name`, `friend_avatar`, `friend_level`,
                `friend_grade`, `friend_clan`, `friend_rank_points`, `friend_wins`, `friend_losses`,
                `is_same_clan`, `is_online`, `status`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'PENDING')
        ");
        if ($insStmt) {
            $insStmt->bind_param(
                "iississiiii",
                $userId, $friendUserId, $friendName, $friendAvatar, $friendLevel,
                $friendGrade, $friendClan, $friendRp, $friendWins, $friendLosses,
                $isSameClan
            );
            $insStmt->execute();
            $insStmt->close();
        }

        jsonResponse([
            'status' => 'success',
            'friend_status' => 'PENDING',
            'message' => "ส่งคำขอเพิ่มเพื่อนไปยัง {$friendName} สำเร็จ! รอเพื่อนอนุมัติ",
            'friends_count' => $acceptedCount,
            'max_friends' => 200
        ]);
    }

    if ($act === 'approve_friend_request') {
        if ($acceptedCount >= 200) {
            jsonResponse([
                'status' => 'error',
                'message' => 'รายชื่อเพื่อนเต็มแล้ว (สูงสุด 200 คน) ไม่สามารถอนุมัติเพิ่มได้',
                'friends_count' => $acceptedCount,
                'max_friends' => 200
            ]);
        }
        $friendId = (int)($data['friend_id'] ?? 0);
        $friendName = trim((string)($data['friend_name'] ?? ''));
        if ($friendId > 0) {
            $stmt = $db->prepare("UPDATE `user_friends` SET `status` = 'ACCEPTED' WHERE `id` = ? AND `user_id` = ?");
            $stmt->bind_param("ii", $friendId, $userId);
            $stmt->execute();
            $stmt->close();
        } elseif ($friendName !== '') {
            $stmt = $db->prepare("UPDATE `user_friends` SET `status` = 'ACCEPTED' WHERE `friend_name` = ? AND `user_id` = ?");
            $stmt->bind_param("si", $friendName, $userId);
            $stmt->execute();
            $stmt->close();
        }
        $cntRes2 = $db->query("SELECT COUNT(*) AS cnt FROM `user_friends` WHERE `user_id` = {$userId} AND `status` = 'ACCEPTED'");
        $newCount = ($cntRes2 && ($r2 = $cntRes2->fetch_assoc())) ? (int)$r2['cnt'] : $acceptedCount;
        jsonResponse([
            'status' => 'success',
            'friend_status' => 'ACCEPTED',
            'message' => 'อนุมัติเพื่อนสำเร็จ! ตอนนี้สามารถเชิญร่วมทีมและดูอันดับเพื่อนได้แล้ว',
            'friends_count' => $newCount,
            'max_friends' => 200
        ]);
    }

    if ($act === 'remove_friend') {
        $friendId = (int)($data['friend_id'] ?? 0);
        $friendName = trim((string)($data['friend_name'] ?? ''));
        if ($friendId > 0) {
            $stmt = $db->prepare("DELETE FROM `user_friends` WHERE `id` = ? AND `user_id` = ?");
            $stmt->bind_param("ii", $friendId, $userId);
            $stmt->execute();
            $stmt->close();
        } elseif ($friendName !== '') {
            $stmt = $db->prepare("DELETE FROM `user_friends` WHERE `friend_name` = ? AND `user_id` = ?");
            $stmt->bind_param("si", $friendName, $userId);
            $stmt->execute();
            $stmt->close();
        }
        $cntRes2 = $db->query("SELECT COUNT(*) AS cnt FROM `user_friends` WHERE `user_id` = {$userId} AND `status` = 'ACCEPTED'");
        $newCount = ($cntRes2 && ($r2 = $cntRes2->fetch_assoc())) ? (int)$r2['cnt'] : 0;
        jsonResponse([
            'status' => 'success',
            'message' => 'ลบรายชื่อเพื่อนเรียบร้อยแล้ว',
            'friends_count' => $newCount,
            'max_friends' => 200
        ]);
    }
}

// 3.6 รีเฟรชและค้นหาเพื่อนที่กำลังออนไลน์ (Refresh & Discover Online Friends - ตัด offline หากไม่ออนไลน์เกิน 5 นาที)
if ($action === 'refresh_online_friends' || $type === 'refresh_online_friends') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?: $_POST;

    $userId = (int)($data['user_id'] ?? $_GET['user_id'] ?? 0);
    if ($userId <= 0) $userId = 15;
    $myClan = trim((string)($data['my_clan'] ?? $_GET['my_clan'] ?? '@PIMMY'));
    $myUsername = trim((string)($data['username'] ?? $_GET['username'] ?? ''));

    ensureDefaultFriendsForUser($db, $userId, $myClan);

    // 1. Touch current user's active timestamp
    @$db->query("UPDATE `users` SET `last_active_at` = NOW() WHERE `id` = {$userId}");

    // 2. Discover real users who were active within the last 5 minutes and sync them into user_friends
    $activeUsersRes = $db->query("
        SELECT `id`, `username`, `avatar_url`, `level`, `clan_id`, `last_active_at`
        FROM `users`
        WHERE `id` != {$userId}
          AND `last_active_at` IS NOT NULL
          AND `last_active_at` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ORDER BY `last_active_at` DESC
        LIMIT 50
    ");

    if ($activeUsersRes) {
        $cntRes = $db->query("SELECT COUNT(*) AS cnt FROM `user_friends` WHERE `user_id` = {$userId} AND `status` = 'ACCEPTED'");
        $currentFriendsCount = ($cntRes && ($cr = $cntRes->fetch_assoc())) ? (int)$cr['cnt'] : 0;

        while ($u = $activeUsersRes->fetch_assoc()) {
            $otherUid = (int)$u['id'];
            $otherName = trim((string)$u['username']);
            if ($otherName === '' || $otherName === $myUsername) continue;

            $otherAv = $u['avatar_url'] ?: 'avatars/bots/bot_f01.jpg';
            $otherLvl = max(1, (int)$u['level']);
            $otherClan = $myClan;
            $isSameClan = 1;
            if (!empty($u['clan_id'])) {
                $cRes = $db->query("SELECT `name` FROM `clans` WHERE `id` = " . (int)$u['clan_id'] . " LIMIT 1");
                if ($cRes && ($cr = $cRes->fetch_assoc())) {
                    $otherClan = $cr['name'];
                    $isSameClan = ($otherClan === $myClan) ? 1 : 0;
                }
            }

            // Check if already in user_friends
            $chkStmt = $db->prepare("SELECT `id`, `status` FROM `user_friends` WHERE `user_id` = ? AND (`friend_user_id` = ? OR `friend_name` = ?) LIMIT 1");
            if ($chkStmt) {
                $chkStmt->bind_param("iis", $userId, $otherUid, $otherName);
                $chkStmt->execute();
                $exRow = $chkStmt->get_result()->fetch_assoc();
                $chkStmt->close();

                if ($exRow) {
                    $fid = (int)$exRow['id'];
                    $upd = $db->prepare("UPDATE `user_friends` SET `is_online` = 1, `friend_user_id` = ?, `friend_avatar` = ?, `friend_level` = ? WHERE `id` = ?");
                    if ($upd) {
                        $upd->bind_param("isii", $otherUid, $otherAv, $otherLvl, $fid);
                        $upd->execute();
                        $upd->close();
                    }
                } else if ($currentFriendsCount < 200) {
                    $rp = 15000 + ($otherLvl * 450);
                    $ins = $db->prepare("
                        INSERT INTO `user_friends` (
                            `user_id`, `friend_user_id`, `friend_name`, `friend_avatar`, `friend_level`,
                            `friend_grade`, `friend_clan`, `friend_rank_points`, `friend_wins`, `friend_losses`,
                            `is_same_clan`, `is_online`, `status`
                        ) VALUES (?, ?, ?, ?, ?, 'SS+', ?, ?, 25, 10, ?, 1, 'ACCEPTED')
                    ");
                    if ($ins) {
                        $ins->bind_param("iissisii", $userId, $otherUid, $otherName, $otherAv, $otherLvl, $otherClan, $rp, $isSameClan);
                        $ins->execute();
                        $ins->close();
                        $currentFriendsCount++;
                    }
                }
            }
        }
    }

    // 3. ตัดเพื่อนที่ไม่ออนไลน์นานเกิน 5 นาทีให้เป็น offline (is_online = 0)
    @$db->query("
        UPDATE `user_friends` uf
        LEFT JOIN `users` u ON u.id = uf.friend_user_id
        SET uf.`is_online` = CASE
            WHEN uf.`friend_user_id` > 0
                 AND u.`id` IS NOT NULL
                 AND u.`last_active_at` IS NOT NULL
                 AND u.`last_active_at` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            THEN 1
            ELSE 0
        END
        WHERE uf.`user_id` = {$userId} AND uf.`status` = 'ACCEPTED'
    ");

    // 4. Query fresh friends leaderboard (เช็คสถานะออนไลน์สดภายใน 5 นาที)
    $fStmt = $db->prepare("
        SELECT uf.`id`, uf.`user_id`, uf.`friend_user_id`, uf.`friend_name`, uf.`friend_avatar`, uf.`friend_level`,
               uf.`friend_grade`, uf.`friend_clan`, uf.`friend_rank_points`, uf.`friend_wins`, uf.`friend_losses`,
               uf.`is_same_clan`,
               (CASE
                   WHEN uf.`friend_user_id` > 0
                        AND u.`id` IS NOT NULL
                        AND u.`last_active_at` IS NOT NULL
                        AND u.`last_active_at` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
                   THEN 1
                   ELSE 0
               END) AS `is_online`,
               uf.`status`, uf.`created_at`
        FROM `user_friends` uf
        LEFT JOIN `users` u ON u.id = uf.friend_user_id
        WHERE uf.`user_id` = ?
        ORDER BY uf.`friend_rank_points` DESC, uf.`id` ASC
        LIMIT 250
    ");
    $fRows = [];
    if ($fStmt) {
        $fStmt->bind_param("i", $userId);
        $fStmt->execute();
        $fRows = $fStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $fStmt->close();
    }

    $acceptedFriends = [];
    $pendingFriends = [];
    foreach ($fRows as $fr) {
        $lvl = (int)($fr['friend_level'] ?? 25);
        $badge = getLevelBadgeInfo($lvl);
        $wins = (int)($fr['friend_wins'] ?? 10);
        $losses = (int)($fr['friend_losses'] ?? 5);
        $tot = max(1, $wins + $losses);
        $winRate = number_format(($wins / $tot) * 100, 2);
        $rp = (int)($fr['friend_rank_points'] ?? 15000);
        $tier = $rp >= 25000 ? 'GRANDMASTER' : ($rp >= 18000 ? 'DIAMOND' : ($rp >= 12000 ? 'GOLD' : 'SILVER'));

        $item = [
            'friend_row_id' => (int)$fr['id'],
            'user_id' => (int)($fr['friend_user_id'] ?: (900 + (int)$fr['id'])),
            'username' => $fr['friend_name'],
            'avatar_url' => $fr['friend_avatar'] ?: 'avatars/bots/bot_f01.jpg',
            'level' => $lvl,
            'char_grade' => $fr['friend_grade'] ?: 'SS+',
            'level_badge_title' => $badge['title'],
            'level_icon' => $badge['icon'],
            'level_color' => $badge['color'],
            'clan_name' => $fr['friend_clan'] ?: '-',
            'rank_points' => $rp,
            'tier' => $tier,
            'total_matches' => $tot,
            'total_wins' => $wins,
            'total_losses' => $losses,
            'win_rate' => $winRate,
            'is_same_clan' => (int)$fr['is_same_clan'] === 1,
            'is_online' => (int)$fr['is_online'] === 1,
            'status' => $fr['status']
        ];

        if ($fr['status'] === 'ACCEPTED') {
            $acceptedFriends[] = $item;
        } else {
            $pendingFriends[] = $item;
        }
    }

    if (count($acceptedFriends) > 200) {
        $acceptedFriends = array_slice($acceptedFriends, 0, 200);
    }

    jsonResponse([
        'status' => 'success',
        'message' => 'รีเฟรชรายชื่อเพื่อนออนไลน์เรียบร้อยแล้ว',
        'friends_leaderboard' => $acceptedFriends,
        'pending_friends' => $pendingFriends,
        'friends_count' => count($acceptedFriends),
        'online_count' => count(array_filter($acceptedFriends, fn($f) => !empty($f['is_online']))),
        'max_friends' => 200
    ]);
}

// =========================================================================
// QUERY HANDLERS (GET Requests)
// =========================================================================

$response = [
    'status' => 'success',
    'weekly_reset_info' => getWeeklyRankingResetSchedule($db)
];

// ดึงการตั้งค่า Admin สำหรับแสดงผล
if ($type === 'ranking_config') {
    $response['ranking_config'] = getRankingConfigMap($db);
    jsonResponse($response);
}

// 4. ดึงสถิติและประวัติการเล่นของผู้เล่น (Player Profile & Match History)
if ($type === 'player_history') {
    $targetUserId = (int)($_GET['user_id'] ?? 0);
    if ($targetUserId <= 0 && (isset($_GET['token']) || !empty(getallheaders()['Authorization'] ?? ''))) {
        try {
            $u = requireAuth($db);
            $targetUserId = (int)$u['id'];
        } catch(Exception $e) {}
    }

    // ข้อมูลผู้เล่นและอันดับ
    $stmt = $db->prepare("
        SELECT 
            u.id AS user_id, u.username, u.avatar_url, u.level, u.diamond, u.gold,
            c.name AS clan_name, c.tag AS clan_tag,
            l.rank_points, l.tier, l.total_matches, l.total_wins, l.total_losses, l.win_rate,
            l.current_win_streak, l.max_win_streak
        FROM users u
        LEFT JOIN leaderboards l ON u.id = l.user_id AND l.season_id = 1
        LEFT JOIN clans c ON u.clan_id = c.id
        WHERE u.id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $targetUserId);
    $stmt->execute();
    $userData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // ดึงอันดับปัจจุบันของผู้เล่น
    $rankingPlace = 1;
    if ($userData) {
        $rCheck = $db->prepare("SELECT COUNT(*) + 1 AS rank_num FROM leaderboards WHERE rank_points > ? AND season_id = 1");
        $pts = (int)($userData['rank_points'] ?? 1000);
        $rCheck->bind_param("i", $pts);
        $rCheck->execute();
        $rankingPlace = (int)($rCheck->get_result()->fetch_assoc()['rank_num'] ?? 1);
        $rCheck->close();
    }

    // ดึงประวัติการเล่นจากตาราง match_history
    $historyStmt = $db->prepare("
        SELECT 
            id, match_id, game_mode, room_fee, rank_place, is_winner, win_reason,
            gold_change, rank_points_change, total_assets, cash_gold, cities_count,
            players_summary_json, created_at
        FROM match_history
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 25
    ");
    $historyStmt->bind_param("i", $targetUserId);
    $historyStmt->execute();
    $rawHistory = $historyStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $historyStmt->close();

    $historyList = [];
    foreach ($rawHistory as $h) {
        $playersArr = [];
        if (!empty($h['players_summary_json'])) {
            $playersArr = json_decode($h['players_summary_json'], true) ?: [];
        }
        $h['players'] = $playersArr;
        unset($h['players_summary_json']);
        $historyList[] = $h;
    }

    // หากยังไม่มีประวัติในตาราง (เช่น ผู้เล่นเพิ่งเล่นรอบแรก หรือเป็นบอทจำลอง)
    // ให้สร้างชุดประวัติแมตช์ตัวอย่างที่สมจริง (มีเดี่ยว 4 ชนะ/แพ้ รายชื่อผู้เล่น 1-4)
    if (empty($historyList)) {
        $sampleBots = [
            ['id' => 901, 'username' => 'แพรวา พารวย', 'avatar_url' => 'avatars/bots/bot_f01.jpg'],
            ['id' => 902, 'username' => 'นนท์ เซียนเต๋า', 'avatar_url' => 'avatars/bots/bot_m01.jpg'],
            ['id' => 903, 'username' => 'มินตรา ดาวเหนือ', 'avatar_url' => 'avatars/bots/bot_f02.jpg'],
            ['id' => 904, 'username' => 'กานต์ อัศวิน', 'avatar_url' => 'avatars/bots/bot_m02.jpg']
        ];
        $myDisplay = $userData['username'] ?? 'ผู้เล่น';
        $myAvatar = $userData['avatar_url'] ?? 'avatars/bots/bot_f01.jpg';

        $historyList = [
            [
                'id' => 101,
                'match_id' => 'match_4p_01',
                'game_mode' => '4P',
                'room_fee' => 2000,
                'rank_place' => 1,
                'is_winner' => 1,
                'win_reason' => 'TIME_OUT',
                'gold_change' => 150000,
                'rank_points_change' => 35,
                'total_assets' => 5250000,
                'cash_gold' => 2100000,
                'cities_count' => 8,
                'created_at' => date('Y-m-d H:i:s', time() - 3600),
                'players' => [
                    ['id' => $targetUserId, 'username' => $myDisplay, 'avatar_url' => $myAvatar, 'rank' => 1, 'total_assets' => 5250000, 'is_winner' => true],
                    ['id' => 902, 'username' => 'นนท์ เซียนเต๋า', 'avatar_url' => 'avatars/bots/bot_m01.jpg', 'rank' => 2, 'total_assets' => 4850000, 'is_winner' => false],
                    ['id' => 903, 'username' => 'มินตรา ดาวเหนือ', 'avatar_url' => 'avatars/bots/bot_f02.jpg', 'rank' => 3, 'total_assets' => 4200000, 'is_winner' => false],
                    ['id' => 904, 'username' => 'กานต์ อัศวิน', 'avatar_url' => 'avatars/bots/bot_m02.jpg', 'rank' => 4, 'total_assets' => 2100000, 'is_winner' => false]
                ]
            ],
            [
                'id' => 102,
                'match_id' => 'match_4p_02',
                'game_mode' => '4P',
                'room_fee' => 2000,
                'rank_place' => 3,
                'is_winner' => 0,
                'win_reason' => 'FINISH_LINE',
                'gold_change' => -30000,
                'rank_points_change' => -10,
                'total_assets' => 3800000,
                'cash_gold' => 1400000,
                'cities_count' => 5,
                'created_at' => date('Y-m-d H:i:s', time() - 14400),
                'players' => [
                    ['id' => 901, 'username' => 'แพรวา พารวย', 'avatar_url' => 'avatars/bots/bot_f01.jpg', 'rank' => 1, 'total_assets' => 6100000, 'is_winner' => true],
                    ['id' => 902, 'username' => 'นนท์ เซียนเต๋า', 'avatar_url' => 'avatars/bots/bot_m01.jpg', 'rank' => 2, 'total_assets' => 4500000, 'is_winner' => false],
                    ['id' => $targetUserId, 'username' => $myDisplay, 'avatar_url' => $myAvatar, 'rank' => 3, 'total_assets' => 3800000, 'is_winner' => false],
                    ['id' => 904, 'username' => 'กานต์ อัศวิน', 'avatar_url' => 'avatars/bots/bot_m02.jpg', 'rank' => 4, 'total_assets' => 1950000, 'is_winner' => false]
                ]
            ]
        ];
    }

    // คำนวณสถิติแยกตามโหมด
    $statsByMode = [
        '4P' => ['total' => 0, 'wins' => 0, 'losses' => 0, 'gold_gain' => 0, 'rp_gain' => 0],
        '2P' => ['total' => 0, 'wins' => 0, 'losses' => 0, 'gold_gain' => 0, 'rp_gain' => 0],
        'TEAM' => ['total' => 0, 'wins' => 0, 'losses' => 0, 'gold_gain' => 0, 'rp_gain' => 0]
    ];

    foreach ($historyList as $m) {
        $mMode = ($m['game_mode'] === '2P' || $m['game_mode'] === '1v1') ? '2P' : (($m['game_mode'] === 'TEAM') ? 'TEAM' : '4P');
        $statsByMode[$mMode]['total']++;
        if (!empty($m['is_winner'])) {
            $statsByMode[$mMode]['wins']++;
        } else {
            $statsByMode[$mMode]['losses']++;
        }
        $statsByMode[$mMode]['gold_gain'] += (int)$m['gold_change'];
        $statsByMode[$mMode]['rp_gain'] += (int)$m['rank_points_change'];
    }

    $lvl = (int)($userData['level'] ?? 1);
    $badge = getLevelBadgeInfo($lvl);

    $response['player_profile'] = [
        'user_id' => $targetUserId,
        'username' => $userData['username'] ?? 'ผู้เล่น',
        'avatar_url' => $userData['avatar_url'] ?? 'avatars/bots/bot_f01.jpg',
        'level' => $lvl,
        'level_badge_title' => $badge['title'],
        'level_icon' => $badge['icon'],
        'level_color' => $badge['color'],
        'clan_name' => $userData['clan_name'] ?? 'ไม่มีสังกัด',
        'clan_tag' => $userData['clan_tag'] ?? '',
        'rank_points' => (int)($userData['rank_points'] ?? 1000),
        'ranking_place' => $rankingPlace,
        'tier' => $userData['tier'] ?? 'BRONZE',
        'total_matches' => (int)($userData['total_matches'] ?? count($historyList)),
        'total_wins' => (int)($userData['total_wins'] ?? 0),
        'total_losses' => (int)($userData['total_losses'] ?? 0),
        'win_rate' => $userData['win_rate'] ?? '0.00',
        'current_win_streak' => (int)($userData['current_win_streak'] ?? 0),
        'max_win_streak' => (int)($userData['max_win_streak'] ?? 0),
        'diamond' => (int)($userData['diamond'] ?? 0),
        'gold' => (int)($userData['gold'] ?? 0),
        'stats_by_mode' => $statsByMode,
        'is_rank_maintained' => ((int)($userData['total_matches'] ?? 0) >= 5)
    ];

    $response['match_history'] = $historyList;
    jsonResponse($response);
}

// 5. จัดอันดับผู้เล่นเดี่ยว (Solo Global Ranking)
if ($type === 'solo' || $type === 'all') {
    $stmt = $db->prepare("
        SELECT 
            DENSE_RANK() OVER (ORDER BY l.rank_points DESC, l.total_wins DESC) AS `ranking`,
            u.id AS user_id,
            u.username,
            u.avatar_url,
            u.level,
            u.diamond,
            u.gold,
            c.name AS clan_name,
            c.tag AS clan_tag,
            l.rank_points,
            l.tier,
            l.total_matches,
            l.total_wins,
            l.total_losses,
            l.win_rate,
            l.current_win_streak,
            l.max_win_streak
        FROM leaderboards l
        JOIN users u ON l.user_id = u.id
        LEFT JOIN clans c ON u.clan_id = c.id
        WHERE l.season_id = ? AND u.is_banned = 0
        ORDER BY l.rank_points DESC, l.total_wins DESC
        LIMIT ?
    ");
    $stmt->bind_param("ii", $seasonId, $limit);
    $stmt->execute();
    $soloRanking = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // ติดตั้งข้อมูลสัญลักษณ์เลเวล
    foreach ($soloRanking as &$row) {
        $badge = getLevelBadgeInfo((int)$row['level']);
        $row['level_badge_title'] = $badge['title'];
        $row['level_icon'] = $badge['icon'];
        $row['level_color'] = $badge['color'];
    }

    $response['solo_leaderboard'] = $soloRanking;
}

// 6. จัดอันดับสังกัดบ้าน (Clan Ranking)
if ($type === 'clan' || $type === 'all') {
    $stmt = $db->prepare("
        SELECT 
            DENSE_RANK() OVER (ORDER BY c.total_score DESC) AS `ranking`,
            c.id AS clan_id,
            c.name AS clan_name,
            c.tag AS clan_tag,
            c.badge_icon,
            c.total_score,
            c.clan_level,
            u.username AS leader_name,
            COUNT(m.id) AS current_members,
            c.max_members
        FROM clans c
        LEFT JOIN users u ON c.leader_id = u.id
        LEFT JOIN users m ON c.id = m.clan_id
        GROUP BY c.id, u.username
        ORDER BY c.total_score DESC
        LIMIT ?
    ");
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $clanRanking = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $response['clan_leaderboard'] = $clanRanking;
}

// 6.5 จัดอันดับเพื่อน & รายชื่อเพื่อนออนไลน์ (Friends Ranking & Online Friends up to 200)
if ($type === 'friends' || $type === 'all') {
    $reqUserId = (int)($_GET['user_id'] ?? 0);
    if ($reqUserId > 0) {
        $myClanName = trim((string)($_GET['my_clan'] ?? '@PIMMY'));
        ensureDefaultFriendsForUser($db, $reqUserId, $myClanName);
    }

    $fStmt = $db->prepare("
        SELECT uf.`id`, uf.`user_id`, uf.`friend_user_id`, uf.`friend_name`, uf.`friend_avatar`, uf.`friend_level`,
               uf.`friend_grade`, uf.`friend_clan`, uf.`friend_rank_points`, uf.`friend_wins`, uf.`friend_losses`,
               uf.`is_same_clan`,
               (CASE
                   WHEN uf.`friend_user_id` > 0
                        AND u.`id` IS NOT NULL
                        AND u.`last_active_at` IS NOT NULL
                        AND u.`last_active_at` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
                   THEN 1
                   ELSE 0
               END) AS `is_online`,
               uf.`status`, uf.`created_at`
        FROM `user_friends` uf
        LEFT JOIN `users` u ON u.id = uf.friend_user_id
        WHERE uf.`user_id` = ?
        ORDER BY uf.`friend_rank_points` DESC, uf.`id` ASC
        LIMIT 250
    ");
    $fRows = [];
    if ($fStmt) {
        $fStmt->bind_param("i", $reqUserId);
        $fStmt->execute();
        $fRows = $fStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $fStmt->close();
    }

    $acceptedFriends = [];
    $pendingFriends = [];
    foreach ($fRows as $fr) {
        $lvl = (int)($fr['friend_level'] ?? 25);
        $badge = getLevelBadgeInfo($lvl);
        $wins = (int)($fr['friend_wins'] ?? 10);
        $losses = (int)($fr['friend_losses'] ?? 5);
        $tot = max(1, $wins + $losses);
        $winRate = number_format(($wins / $tot) * 100, 2);
        $rp = (int)($fr['friend_rank_points'] ?? 15000);
        $tier = $rp >= 25000 ? 'GRANDMASTER' : ($rp >= 18000 ? 'DIAMOND' : ($rp >= 12000 ? 'GOLD' : 'SILVER'));

        $item = [
            'friend_row_id' => (int)$fr['id'],
            'user_id' => (int)($fr['friend_user_id'] ?: (900 + (int)$fr['id'])),
            'username' => $fr['friend_name'],
            'avatar_url' => $fr['friend_avatar'] ?: 'avatars/bots/bot_f01.jpg',
            'level' => $lvl,
            'char_grade' => $fr['friend_grade'] ?: 'SS+',
            'level_badge_title' => $badge['title'],
            'level_icon' => $badge['icon'],
            'level_color' => $badge['color'],
            'clan_name' => $fr['friend_clan'] ?: '-',
            'rank_points' => $rp,
            'tier' => $tier,
            'total_matches' => $tot,
            'total_wins' => $wins,
            'total_losses' => $losses,
            'win_rate' => $winRate,
            'is_same_clan' => (int)$fr['is_same_clan'] === 1,
            'is_online' => (int)$fr['is_online'] === 1,
            'status' => $fr['status']
        ];

        if ($fr['status'] === 'ACCEPTED') {
            $acceptedFriends[] = $item;
        } else {
            $pendingFriends[] = $item;
        }
    }

    // จำกัดไม่เกิน 200 คนตามกติกา
    if (count($acceptedFriends) > 200) {
        $acceptedFriends = array_slice($acceptedFriends, 0, 200);
    }

    $response['friends_leaderboard'] = $acceptedFriends;
    $response['pending_friends'] = $pendingFriends;
    $response['friends_count'] = count($acceptedFriends);
    $response['max_friends'] = 200;
}

// 7. ข้อมูลสถิติและสถานะเลเวลของผู้เล่นที่เรียกดู (Current Player Stats)
if (isset($_GET['token']) || !empty(getallheaders()['Authorization'] ?? '')) {
    try {
        $currentUser = requireAuth($db);
        $userId = (int)$currentUser['id'];

        $stmt = $db->prepare("
            SELECT u.id, u.username, u.avatar_url, u.level, u.exp_matches, u.diamond, u.gold,
                   l.rank_points, l.tier, l.total_matches, l.total_wins, l.total_losses, l.win_rate,
                   l.current_win_streak, l.max_win_streak,
                   c.name as clan_name
            FROM users u
            LEFT JOIN leaderboards l ON u.id = l.user_id AND l.season_id = 1
            LEFT JOIN clans c ON u.clan_id = c.id
            WHERE u.id = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $playerStats = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($playerStats) {
            $lvl = (int)$playerStats['level'];
            $exp = (int)$playerStats['exp_matches'];
            $needed = ($lvl <= 5) ? 5 : 10;
            $badge = getLevelBadgeInfo($lvl);
            $lvCfg = getLevelUpConfig($db);
            $maxLvl = max(2, (int)($lvCfg['max_level'] ?? 100));
            $nextRw = resolveLevelUpReward($lvCfg, min($maxLvl, $lvl + 1));

            $playerStats['level_badge_title'] = $badge['title'];
            $playerStats['level_icon'] = $badge['icon'];
            $playerStats['level_color'] = $badge['color'];
            $playerStats['max_level'] = $maxLvl;
            $playerStats['is_max_level'] = ($lvl >= $maxLvl);
            $playerStats['exp_needed_next_level'] = $needed;
            $playerStats['exp_progress_percent'] = ($lvl >= $maxLvl) ? 100 : round(($exp / $needed) * 100, 1);
            $playerStats['level_up_reward'] = [
                'diamond' => (int)$nextRw['diamond'],
                'gold' => (int)$nextRw['gold'],
                'cubes' => $nextRw['cubes'] ?? [],
                'cube_type' => (string)$nextRw['cube_type'],
                'cube_name' => (string)$nextRw['cube_name'],
                'cube_qty' => (int)$nextRw['cube_qty'],
            ];

            $response['current_player_stats'] = $playerStats;
        }
    } catch (Exception $e) {
        // Silently skip if guest
    }
}

jsonResponse($response);
