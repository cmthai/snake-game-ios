<?php
if (!ob_start('ob_gzhandler')) {
    ob_start();
}

/**
 * api/app_config.php
 * Mobile App Dynamic Configuration & Remote Cache Buster Endpoint
 * Supports Android (Kotlin) & iOS (Swift) mobile apps.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database.php';
date_default_timezone_set('Asia/Bangkok');
require_once __DIR__ . '/board_studio_service.php';
require_once __DIR__ . '/monopoly_board_service.php';

$defaultGameUrl = 'https://pmix01.thddns.net:7175/home/snake/';
$defaultVersion = '1.0.61';
$defaultCacheBuster = 1794315200;
$defaultMaintenance = false;
$defaultMaintenanceMsg = 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง';

// ดึงค่าสำรองจาก config/ota_version.json หากมี (ลบ BOM อัตโนมัติป้องกัน json_decode ล้มเหลว)
$configJsonFile = __DIR__ . '/../config/ota_version.json';
$otaConfig = [];
if (file_exists($configJsonFile)) {
    $otaRaw = @file_get_contents($configJsonFile);
    if ($otaRaw) {
        $cleanJson = preg_replace('/^\xEF\xBB\xBF/', '', trim((string)$otaRaw));
        $otaConfig = json_decode($cleanJson, true) ?: [];
    }
}

if (!empty($otaConfig['cache_buster'])) {
    $defaultCacheBuster = (int)$otaConfig['cache_buster'];
}
if (!empty($otaConfig['version'])) {
    $defaultVersion = (string)$otaConfig['version'];
}
if (!empty($otaConfig['game_url'])) {
    $defaultGameUrl = (string)$otaConfig['game_url'];
}

try {
    $db = getDbConnection();

    // ดึงค่าการตั้งค่าจาก system_settings
    $res = $db->query("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN (
            'MOBILE_APP_GAME_URL',
            'MOBILE_APP_VERSION',
            'MOBILE_APP_CACHE_BUSTER',
            'MOBILE_APP_FORCE_CLEAR_CACHE',
            'MOBILE_APP_MAINTENANCE',
            'MOBILE_APP_MAINTENANCE_MSG',
            'OTA_UPDATE_SIZE',
            'OTA_UPDATE_FILES',
            'OTA_LAST_DEPLOY_TIME',
            'OTA_LAST_RELEASE_NOTE',
            'BOARD_SHOW_TEXT_BADGES'
        )
    ");

    $settings = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }

    $gameUrl = !empty($settings['MOBILE_APP_GAME_URL']) ? rtrim($settings['MOBILE_APP_GAME_URL'], '/') . '/' : $defaultGameUrl;
    $dbCacheBuster = isset($settings['MOBILE_APP_CACHE_BUSTER']) ? (int)$settings['MOBILE_APP_CACHE_BUSTER'] : 0;
    $isOtaJsonNewer = ($defaultCacheBuster > $dbCacheBuster);
    $cacheBuster = $isOtaJsonNewer ? $defaultCacheBuster : $dbCacheBuster;
    if ($cacheBuster <= 0) {
        $cacheBuster = $defaultCacheBuster;
    }
    if ($isOtaJsonNewer && $dbCacheBuster < $defaultCacheBuster) {
        $busterStr = (string)$defaultCacheBuster;
        $verStr = (string)$defaultVersion;
        @$db->query("UPDATE system_settings SET setting_value = '" . $db->real_escape_string($busterStr) . "' WHERE setting_key = 'MOBILE_APP_CACHE_BUSTER'");
        @$db->query("UPDATE system_settings SET setting_value = '" . $db->real_escape_string($verStr) . "' WHERE setting_key = 'MOBILE_APP_VERSION'");
    }
    $appVersion = ($isOtaJsonNewer && !empty($otaConfig['version'])) ? (string)$otaConfig['version'] : ($settings['MOBILE_APP_VERSION'] ?? $defaultVersion);
    $forceClearCache = true;
    $maintenance = !empty($settings['MOBILE_APP_MAINTENANCE']) && ($settings['MOBILE_APP_MAINTENANCE'] === '1' || $settings['MOBILE_APP_MAINTENANCE'] === 'true');
    $maintenanceMsg = $settings['MOBILE_APP_MAINTENANCE_MSG'] ?? $defaultMaintenanceMsg;
    $lastDeployTime = ($isOtaJsonNewer && !empty($otaConfig['deployed_at'])) ? (string)$otaConfig['deployed_at'] : ($settings['MOBILE_APP_LAST_DEPLOY'] ?? date('Y-m-d H:i:s'));
    $releaseNote = !empty($settings['OTA_LAST_RELEASE_NOTE'])
        ? (string)$settings['OTA_LAST_RELEASE_NOTE']
        : (!empty($settings['MOBILE_APP_RELEASE_NOTE'])
            ? (string)$settings['MOBILE_APP_RELEASE_NOTE']
            : ($otaConfig['release_note'] ?? 'อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล'));
    if (!empty($otaConfig['release_note'])) {
        $releaseNote = (string)$otaConfig['release_note'];
    } else if (!empty($settings['OTA_LAST_RELEASE_NOTE'])) {
        $releaseNote = (string)$settings['OTA_LAST_RELEASE_NOTE'];
    } else if (!empty($settings['MOBILE_APP_RELEASE_NOTE'])) {
        $releaseNote = (string)$settings['MOBILE_APP_RELEASE_NOTE'];
    } else {
        $releaseNote = 'อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล';
    }
    $updateSize = ($isOtaJsonNewer && !empty($otaConfig['update_size'])) ? (string)$otaConfig['update_size'] : ($settings['MOBILE_APP_UPDATE_SIZE'] ?? '2.5 MB');
    $fileCount = ($isOtaJsonNewer && !empty($otaConfig['file_count'])) ? (int)$otaConfig['file_count'] : (int)($settings['MOBILE_APP_FILE_COUNT'] ?? 14);
    $updateFilesText = $fileCount . ' ไฟล์';

    // ========================================================
    // 🎪 ตรวจสอบสถานะและช่วงเวลากิจกรรมสุ่ม (Frame, Dice, Gem)
    // ========================================================
    $eventsList = [];
    $upcomingTimestamps = [];
    $nowTs = time();
    $eventSigParts = [];
    $recentTransition = null;
    $latestTransitionTs = 0;

    // 1. Frame Event (gacha_events)
    $fRes = @$db->query("SELECT id, event_name, start_date, end_date, is_active FROM gacha_events ORDER BY id DESC LIMIT 1");
    if ($fRes && ($fRow = $fRes->fetch_assoc())) {
        $startTs = !empty($fRow['start_date']) ? strtotime($fRow['start_date']) : 0;
        $endTs = !empty($fRow['end_date']) ? strtotime($fRow['end_date']) : 0;
        $isLive = (!empty($fRow['is_active']) && $startTs > 0 && $endTs > 0 && $nowTs >= $startTs && $nowTs <= $endTs);
        $eventsList[] = [
            'type' => 'FRAME',
            'id' => (int)$fRow['id'],
            'name' => $fRow['event_name'] ?: 'กิจกรรมการ์ดกรอบรูป',
            'start_date' => $fRow['start_date'],
            'end_date' => $fRow['end_date'],
            'start_ts' => $startTs,
            'end_ts' => $endTs,
            'is_live' => $isLive
        ];
        $eventSigParts[] = "FRAME:" . $fRow['id'] . ":" . ($isLive ? "1" : "0");
        if ($startTs > 0 && $startTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $startTs);
        if ($endTs > 0 && $endTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $endTs);
        if ($startTs > $nowTs) $upcomingTimestamps[] = $startTs;
        if ($endTs > $nowTs) $upcomingTimestamps[] = $endTs;
        if ($isLive && abs($nowTs - $startTs) <= 600) {
            $recentTransition = ['type' => 'FRAME', 'action' => 'START', 'event_name' => $fRow['event_name'] ?: 'กิจกรรมการ์ดกรอบรูป'];
        } else if (!$isLive && $endTs > 0 && ($nowTs - $endTs) >= 0 && ($nowTs - $endTs) <= 600) {
            $recentTransition = ['type' => 'FRAME', 'action' => 'END', 'event_name' => $fRow['event_name'] ?: 'กิจกรรมการ์ดกรอบรูป'];
        }
    }

    // 2. Dice Event (dice_gacha_events)
    $dRes = @$db->query("SELECT id, event_name, start_date, end_date, is_active FROM dice_gacha_events ORDER BY id DESC LIMIT 1");
    if ($dRes && ($dRow = $dRes->fetch_assoc())) {
        $startTs = !empty($dRow['start_date']) ? strtotime($dRow['start_date']) : 0;
        $endTs = !empty($dRow['end_date']) ? strtotime($dRow['end_date']) : 0;
        $isLive = (!empty($dRow['is_active']) && $startTs > 0 && $endTs > 0 && $nowTs >= $startTs && $nowTs <= $endTs);
        $eventsList[] = [
            'type' => 'DICE',
            'id' => (int)$dRow['id'],
            'name' => $dRow['event_name'] ?: 'กิจกรรมลูกเต๋า 3D',
            'start_date' => $dRow['start_date'],
            'end_date' => $dRow['end_date'],
            'start_ts' => $startTs,
            'end_ts' => $endTs,
            'is_live' => $isLive
        ];
        $eventSigParts[] = "DICE:" . $dRow['id'] . ":" . ($isLive ? "1" : "0");
        if ($startTs > 0 && $startTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $startTs);
        if ($endTs > 0 && $endTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $endTs);
        if ($startTs > $nowTs) $upcomingTimestamps[] = $startTs;
        if ($endTs > $nowTs) $upcomingTimestamps[] = $endTs;
        if ($isLive && abs($nowTs - $startTs) <= 600) {
            $recentTransition = ['type' => 'DICE', 'action' => 'START', 'event_name' => $dRow['event_name'] ?: 'กิจกรรมลูกเต๋า 3D'];
        } else if (!$isLive && $endTs > 0 && ($nowTs - $endTs) >= 0 && ($nowTs - $endTs) <= 600) {
            $recentTransition = ['type' => 'DICE', 'action' => 'END', 'event_name' => $dRow['event_name'] ?: 'กิจกรรมลูกเต๋า 3D'];
        }
    }

    // 3. Gem Event (gem_gacha_events หรือ gem_events)
    $gRes = @$db->query("SELECT id, event_name, start_date, end_date, is_active FROM gem_gacha_events ORDER BY id DESC LIMIT 1");
    if (!$gRes || $gRes->num_rows === 0) {
        $gRes = @$db->query("SELECT id, event_name, start_date, end_date, is_active FROM gem_events ORDER BY id DESC LIMIT 1");
    }
    if ($gRes && ($gRow = $gRes->fetch_assoc())) {
        $startTs = !empty($gRow['start_date']) ? strtotime($gRow['start_date']) : 0;
        $endTs = !empty($gRow['end_date']) ? strtotime($gRow['end_date']) : 0;
        $isLive = (!empty($gRow['is_active']) && $startTs > 0 && $endTs > 0 && $nowTs >= $startTs && $nowTs <= $endTs);
        $eventsList[] = [
            'type' => 'GEM',
            'id' => (int)$gRow['id'],
            'name' => $gRow['event_name'] ?: 'กิจกรรมสุ่มอัญมณี',
            'start_date' => $gRow['start_date'],
            'end_date' => $gRow['end_date'],
            'start_ts' => $startTs,
            'end_ts' => $endTs,
            'is_live' => $isLive
        ];
        $eventSigParts[] = "GEM:" . $gRow['id'] . ":" . ($isLive ? "1" : "0");
        if ($startTs > 0 && $startTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $startTs);
        if ($endTs > 0 && $endTs <= $nowTs) $latestTransitionTs = max($latestTransitionTs, $endTs);
        if ($startTs > $nowTs) $upcomingTimestamps[] = $startTs;
        if ($endTs > $nowTs) $upcomingTimestamps[] = $endTs;
        if ($isLive && abs($nowTs - $startTs) <= 600) {
            $recentTransition = ['type' => 'GEM', 'action' => 'START', 'event_name' => $gRow['event_name'] ?: 'กิจกรรมสุ่มอัญมณี'];
        } else if (!$isLive && $endTs > 0 && ($nowTs - $endTs) >= 0 && ($nowTs - $endTs) <= 600) {
            $recentTransition = ['type' => 'GEM', 'action' => 'END', 'event_name' => $gRow['event_name'] ?: 'กิจกรรมสุ่มอัญมณี'];
        }
    }

    sort($upcomingTimestamps);
    $eventsSignature = implode('|', $eventSigParts);

    // หากมีการเปลี่ยนสถานะเริ่ม/หมดเวลากิจกรรม ให้ปรับข้อความอัปเดตอัตโนมัติ
    if ($recentTransition) {
        if ($recentTransition['action'] === 'START') {
            $releaseNote = "🎉 เริ่มเวลากิจกรรม: " . $recentTransition['event_name'] . " ระบบได้อัปเดตข้อมูลกิจกรรมล่าสุดให้เรียบร้อยแล้ว!";
        } else {
            $releaseNote = "⏳ สิ้นสุดเวลากิจกรรม: " . $recentTransition['event_name'] . " ระบบกำลังอัปเดตข้อมูลและรายการกิจกรรมล่าสุด";
        }
    }

    // หากเวลาเริ่มหรือหมดเวลากิจกรรมล่าสุดใหม่กว่าแคชเดิม ให้ใช้ค่านี้เพื่อดันให้ไคลเอนต์ทุกเครื่องตรวจพบการอัปเดตทันที
    if ($latestTransitionTs > $cacheBuster) {
        $cacheBuster = $latestTransitionTs;
    }

    // ดึงข้อมูลกระดาน AI 3D หลักสำหรับแอป iOS & Android
    $activeBoards = getAllCustomBoards($db, true);
    $defaultAiBoard = null;
    foreach ($activeBoards as $ab) {
        if (!empty($ab['is_default'])) {
            $defaultAiBoard = $ab;
            break;
        }
    }

    // 🎮 ดึงการตั้งค่ากติกาเกม & ค่าออกเกาะร้าง (Dynamic Game Rules)
    $gameRules = [
        'jail_pay_enabled' => true,
        'jail_bail_diamond' => 50,
        'jail_bail_gold' => 50000,
        'jail_max_turns' => 2,
        'jail_doubles_escape' => true,
        'jail_consecutive_doubles' => 3,
        'jail_tile_number' => 10,
        'match_duration_minutes' => 10,
        'turn_time_limit' => 15,
        'auto_play_timeout' => true,
        'lap_salary_gold' => 200000,
        'double_roll_extra_turn' => true,
        'loan_max_count' => 3,
        'loan_gold_cost' => 5000,
        'loan_gold_bonus_percent' => 25,
        'loan_diamond_cost' => 20,
        'loan_diamond_bonus_percent' => 100,
        'gem_upgrade_dia_t1' => 100,
        'gem_upgrade_dia_t2' => 150,
        'gem_upgrade_dia_t3' => 200,
        'gem_upgrade_dia_t4' => 500
    ];
    @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) UNIQUE NOT NULL,
        `setting_value` TEXT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    $grRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key LIKE 'jail_%' OR setting_key LIKE 'turn_%' OR setting_key LIKE 'match_%' OR setting_key LIKE 'lap_%' OR setting_key LIKE 'double_%' OR setting_key LIKE 'auto_%' OR setting_key LIKE 'loan_%' OR setting_key LIKE 'gem_upgrade_%' OR setting_key = 'upgrade_diamond_matrix' OR setting_key = 'special_awakening_config'");
    if ($grRes) {
        while ($grRow = $grRes->fetch_assoc()) {
            $k = $grRow['setting_key'];
            $v = $grRow['setting_value'];
            if ($k === 'upgrade_diamond_matrix' || $k === 'special_awakening_config') {
                $decoded = json_decode($v, true);
                if (is_array($decoded)) $gameRules[$k] = $decoded;
            } else if (in_array($k, ['jail_pay_enabled', 'jail_doubles_escape', 'auto_play_timeout', 'double_roll_extra_turn'], true)) {
                $gameRules[$k] = ($v === '1' || $v === 'true');
            } else if (is_numeric($v)) {
                $gameRules[$k] = (int)$v;
            } else {
                $gameRules[$k] = $v;
            }
        }
    }

    // 🛡️ ดึงการตั้งค่าความปลอดภัย ล็อกอิน 1 เครื่อง & ป้องกันแฮก (Anti-Hack / Single Device Rules)
    $securityRules = [
        'single_device_enabled' => true,
        'approval_timeout_minutes' => 5,
        'approval_timeout_seconds' => 300,
        'alert_title' => '🚨 ตรวจพบการพยายามเข้าสู่ระบบจากอุปกรณ์อื่น!',
        'alert_message' => "มีอุปกรณ์อื่น ({platform}) กำลังพยายามเข้าใช้งานบัญชีของคุณ\nหากเป็นคุณที่กำลังเปลี่ยนเครื่อง กรุณากด \"อนุมัติ\" ภายใน {time} เพื่อสลับเครื่อง\nหากไม่ใช่คุณ โปรดกด \"ปฏิเสธ\" ทันทีเพื่อความปลอดภัย",
        'mobile_notify_text' => '🚨 แจ้งเตือนความปลอดภัย: มีการพยายามเข้าใช้บัญชีของคุณจากเครื่องอื่น และหมดเวลาการยืนยัน ระบบได้ทำการออกจากระบบอัตโนมัติเพื่อความปลอดภัย',
        'timeout_notice_text' => '⏱️ หมดเวลาการรออนุมัติ (5 นาที) ระบบได้ออกจากระบบทันทีเพื่อความปลอดภัยในการป้องกันการแฮ๊กไอดี',
        'timeout_action' => 'logout_both'
    ];
    $secRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key LIKE 'security_%'");
    if ($secRes) {
        while ($sRow = $secRes->fetch_assoc()) {
            $sk = str_replace('security_', '', $sRow['setting_key']);
            $sv = $sRow['setting_value'];
            if ($sk === 'single_device_enabled') {
                $securityRules['single_device_enabled'] = ($sv === '1' || $sv === 'true');
            } else if ($sk === 'approval_timeout_minutes') {
                $securityRules['approval_timeout_minutes'] = max(1, min(30, (int)$sv));
                $securityRules['approval_timeout_seconds'] = $securityRules['approval_timeout_minutes'] * 60;
            } else if ($sk === 'approval_timeout_seconds') {
                $securityRules['approval_timeout_seconds'] = max(30, (int)$sv);
                $securityRules['approval_timeout_minutes'] = ceil($securityRules['approval_timeout_seconds'] / 60);
            } else if (!empty($sv)) {
                $securityRules[$sk] = $sv;
            }
        }
    }

    echo json_encode([
        'status' => 'success',
        'game_url' => $gameUrl,
        'app_version' => $appVersion,
        'cache_version' => $cacheBuster,
        'update_size' => $updateSize,
        'file_count' => $fileCount,
        'update_files' => $fileCount,
        'update_files_text' => $updateFilesText,
        'force_clear_cache' => $forceClearCache,
        'maintenance' => $maintenance,
        'maintenance_message' => $maintenanceMsg,
        'last_deploy_time' => $lastDeployTime,
        'release_note' => $releaseNote,
        'default_ai_board' => $defaultAiBoard,
        'active_ai_boards_count' => count($activeBoards),
        'game_rules' => $gameRules,
        'game_modes' => getGameModesConfig($db),
        'active_monopoly_board' => getActiveDefaultMonopolyBoard($db),
        'monopoly_boards' => getAllActiveMonopolyBoards($db),
        'security_rules' => $securityRules,
        'events_summary' => [
            'signature' => $eventsSignature,
            'events' => $eventsList,
            'upcoming_timestamps' => array_values(array_unique($upcomingTimestamps)),
            'recent_transition' => $recentTransition
        ],
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

} catch (\Throwable $e) {
    // กรณีฐานข้อมูลยังไม่พร้อม ใช้ค่าดีฟอลต์ที่เสถียร
    $fallbackFileCount = !empty($otaConfig['file_count']) ? (int)$otaConfig['file_count'] : 14;
    echo json_encode([
        'status' => 'success',
        'game_url' => $defaultGameUrl,
        'app_version' => $defaultVersion,
        'cache_version' => $defaultCacheBuster,
        'update_size' => $otaConfig['update_size'] ?? '2.8 MB',
        'file_count' => $fallbackFileCount,
        'update_files' => $fallbackFileCount,
        'update_files_text' => $fallbackFileCount . ' ไฟล์',
        'force_clear_cache' => true,
        'maintenance' => $defaultMaintenance,
        'maintenance_message' => $defaultMaintenanceMsg,
        'last_deploy_time' => $otaConfig['deployed_at'] ?? date('Y-m-d H:i:s'),
        'release_note' => $otaConfig['release_note'] ?? 'ระบบปรับปรุงประสิทธิภาพความลื่นไหล',
        'game_rules' => [
            'jail_pay_enabled' => true,
            'jail_bail_diamond' => 50,
            'jail_bail_gold' => 50000,
            'jail_max_turns' => 2,
            'jail_doubles_escape' => true,
            'jail_consecutive_doubles' => 3,
            'jail_tile_number' => 10,
            'match_duration_minutes' => 10,
        'turn_time_limit' => 15,
            'auto_play_timeout' => true,
            'lap_salary_gold' => 200000,
            'double_roll_extra_turn' => true,
            'loan_max_count' => 3,
            'loan_gold_cost' => 5000,
            'loan_gold_bonus_percent' => 25,
            'loan_diamond_cost' => 20,
            'loan_diamond_bonus_percent' => 100
        ],
        'security_rules' => [
            'single_device_enabled' => true,
            'approval_timeout_minutes' => 5,
            'approval_timeout_seconds' => 300,
            'alert_title' => '🚨 ตรวจพบการพยายามเข้าสู่ระบบจากอุปกรณ์อื่น!',
            'alert_message' => "มีอุปกรณ์อื่น ({platform}) กำลังพยายามเข้าใช้งานบัญชีของคุณ\nหากเป็นคุณที่กำลังเปลี่ยนเครื่อง กรุณากด \"อนุมัติ\" ภายใน {time} เพื่อสลับเครื่อง\nหากไม่ใช่คุณ โปรดกด \"ปฏิเสธ\" ทันทีเพื่อความปลอดภัย",
            'mobile_notify_text' => '🚨 แจ้งเตือนความปลอดภัย: มีการพยายามเข้าใช้บัญชีของคุณจากเครื่องอื่น และหมดเวลาการยืนยัน ระบบได้ทำการออกจากระบบอัตโนมัติเพื่อความปลอดภัย',
            'timeout_notice_text' => '⏱️ หมดเวลาการรออนุมัติ (5 นาที) ระบบได้ออกจากระบบทันทีเพื่อความปลอดภัยในการป้องกันการแฮ๊กไอดี',
            'timeout_action' => 'logout_both'
        ],
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
}
