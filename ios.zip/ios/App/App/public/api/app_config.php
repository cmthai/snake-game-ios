<?php
declare(strict_types=1);

/**
 * api/app_config.php
 * Mobile App Dynamic Configuration & Remote Cache Buster Endpoint
 * Supports Android (Kotlin) & iOS (Swift) mobile apps.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/board_studio_service.php';

$defaultGameUrl = 'https://pmix01.thddns.net:7175/home/snake/';
$defaultVersion = '1.0.0';
$defaultCacheBuster = time();
$defaultMaintenance = false;
$defaultMaintenanceMsg = 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง';

// ดึงค่าสำรองจาก config/ota_version.json หากมี
$configJsonFile = __DIR__ . '/../config/ota_version.json';
$otaConfig = [];
if (file_exists($configJsonFile)) {
    $otaRaw = @file_get_contents($configJsonFile);
    if ($otaRaw) {
        $otaConfig = json_decode($otaRaw, true) ?: [];
    }
}

if (!empty($otaConfig['cache_buster'])) {
    $defaultCacheBuster = (int)$otaConfig['cache_buster'];
}
if (!empty($otaConfig['version'])) {
    $defaultVersion = (string)$otaConfig['version'];
}
if (!empty($otaConfig['game_url'])) {
    $defaultGameUrl = (string)$otaConfig['game_url'];
}

try {
    $db = getDbConnection();

    // ดึงค่าการตั้งค่าจาก system_settings
    $res = $db->query("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN (
            'MOBILE_APP_GAME_URL',
            'MOBILE_APP_VERSION',
            'MOBILE_APP_CACHE_BUSTER',
            'MOBILE_APP_FORCE_CLEAR_CACHE',
            'MOBILE_APP_MAINTENANCE',
            'MOBILE_APP_MAINTENANCE_MSG',
            'OTA_UPDATE_SIZE',
            'OTA_UPDATE_FILES',
            'OTA_LAST_DEPLOY_TIME',
            'OTA_LAST_RELEASE_NOTE'
        )
    ");

    $settings = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }

    $gameUrl = !empty($settings['MOBILE_APP_GAME_URL']) ? rtrim($settings['MOBILE_APP_GAME_URL'], '/') . '/' : $defaultGameUrl;
    $dbCacheBuster = isset($settings['MOBILE_APP_CACHE_BUSTER']) ? (int)$settings['MOBILE_APP_CACHE_BUSTER'] : 0;
    $isOtaJsonNewer = ($defaultCacheBuster > $dbCacheBuster);
    $cacheBuster = $isOtaJsonNewer ? $defaultCacheBuster : $dbCacheBuster;
    $appVersion = ($isOtaJsonNewer && !empty($otaConfig['version'])) ? (string)$otaConfig['version'] : ($settings['MOBILE_APP_VERSION'] ?? $defaultVersion);
    $forceClearCache = true;
    $maintenance = !empty($settings['MOBILE_APP_MAINTENANCE']) && ($settings['MOBILE_APP_MAINTENANCE'] === '1' || $settings['MOBILE_APP_MAINTENANCE'] === 'true');
    $maintenanceMsg = $settings['MOBILE_APP_MAINTENANCE_MSG'] ?? $defaultMaintenanceMsg;
    $lastDeployTime = ($isOtaJsonNewer && !empty($otaConfig['deployed_at'])) ? (string)$otaConfig['deployed_at'] : ($settings['OTA_LAST_DEPLOY_TIME'] ?? ($otaConfig['last_deployed_at'] ?? null));
    $releaseNote = ($isOtaJsonNewer && !empty($otaConfig['release_note'])) ? (string)$otaConfig['release_note'] : ($settings['OTA_LAST_RELEASE_NOTE'] ?? ($otaConfig['release_note'] ?? null));
    $updateSize = ($isOtaJsonNewer && !empty($otaConfig['update_size'])) ? (string)$otaConfig['update_size'] : ($settings['OTA_UPDATE_SIZE'] ?? ($otaConfig['update_size'] ?? '2.8 MB'));

    $fileCount = 0;
    if ($isOtaJsonNewer && !empty($otaConfig['file_count'])) {
        $fileCount = (int)$otaConfig['file_count'];
    } elseif (!empty($settings['OTA_UPDATE_FILES'])) {
        $fileCount = (int)$settings['OTA_UPDATE_FILES'];
    } elseif (!empty($otaConfig['file_count'])) {
        $fileCount = (int)$otaConfig['file_count'];
    } elseif (!empty($otaConfig['update_files'])) {
        $fileCount = (int)$otaConfig['update_files'];
    } elseif (!empty($otaConfig['affected_files_count'])) {
        $fileCount = (int)$otaConfig['affected_files_count'];
    } else {
        $cssCount = count((array)@glob(__DIR__ . '/../css/*.*'));
        $jsCount = count((array)@glob(__DIR__ . '/../js/*.*'));
        $fileCount = max(1, $cssCount + $jsCount + 1);
    }
    $updateFilesText = $fileCount . ' ไฟล์';

    // ดึงข้อมูลกระดาน AI 3D หลักสำหรับแอป iOS & Android
    $activeBoards = getAllCustomBoards($db, true);
    $defaultAiBoard = null;
    foreach ($activeBoards as $ab) {
        if (!empty($ab['is_default'])) {
            $defaultAiBoard = $ab;
            break;
        }
    }

    echo json_encode([
        'status' => 'success',
        'game_url' => $gameUrl,
        'app_version' => $appVersion,
        'cache_version' => $cacheBuster,
        'update_size' => $updateSize,
        'file_count' => $fileCount,
        'update_files' => $fileCount,
        'update_files_text' => $updateFilesText,
        'force_clear_cache' => $forceClearCache,
        'maintenance' => $maintenance,
        'maintenance_message' => $maintenanceMsg,
        'last_deploy_time' => $lastDeployTime,
        'release_note' => $releaseNote,
        'default_ai_board' => $defaultAiBoard,
        'active_ai_boards_count' => count($activeBoards),
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

} catch (\Throwable $e) {
    // กรณีฐานข้อมูลยังไม่พร้อม ใช้ค่าดีฟอลต์ที่เสถียร
    $fallbackFileCount = !empty($otaConfig['file_count']) ? (int)$otaConfig['file_count'] : 14;
    echo json_encode([
        'status' => 'success',
        'game_url' => $defaultGameUrl,
        'app_version' => $defaultVersion,
        'cache_version' => $defaultCacheBuster,
        'update_size' => $otaConfig['update_size'] ?? '2.8 MB',
        'file_count' => $fallbackFileCount,
        'update_files' => $fallbackFileCount,
        'update_files_text' => $fallbackFileCount . ' ไฟล์',
        'force_clear_cache' => true,
        'maintenance' => $defaultMaintenance,
        'maintenance_message' => $defaultMaintenanceMsg,
        'last_deploy_time' => $otaConfig['deployed_at'] ?? date('Y-m-d H:i:s'),
        'release_note' => $otaConfig['release_note'] ?? 'ระบบปรับปรุงประสิทธิภาพความลื่นไหล',
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
}
