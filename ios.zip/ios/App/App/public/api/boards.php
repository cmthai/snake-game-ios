<?php
declare(strict_types=1);

/**
 * api/boards.php
 * Public & Player-facing API endpoint for fetching active AI 3D Boards & Roll Button Settings
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/board_studio_service.php';

try {
    $db = getDbConnection();
    $action = $_GET['action'] ?? ($_POST['action'] ?? 'get_active_boards');

    if ($action === 'get_board_by_id') {
        $id = (int)($_GET['id'] ?? 0);
        $boards = getAllCustomBoards($db, false);
        $found = null;
        foreach ($boards as $b) {
            if ((int)$b['id'] === $id || (string)$b['board_code'] === (string)($_GET['code'] ?? '')) {
                $found = $b;
                break;
            }
        }
        echo json_encode([
            'status' => $found ? 'success' : 'error',
            'board' => $found
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $activeBoards = getAllCustomBoards($db, true);
    $defaultBoard = null;
    foreach ($activeBoards as $b) {
        if (!empty($b['is_default'])) {
            $defaultBoard = $b;
            break;
        }
    }

    echo json_encode([
        'status' => 'success',
        'boards' => $activeBoards,
        'default_board' => $defaultBoard,
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (\Throwable $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'boards' => []
    ], JSON_UNESCAPED_UNICODE);
}

