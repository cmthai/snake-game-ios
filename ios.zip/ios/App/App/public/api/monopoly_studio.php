<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$configFile = __DIR__ . '/../config/monopoly_assets.json';
$uploadsDir = __DIR__ . '/../uploads/monopoly';
if (!is_dir($uploadsDir)) {
    @mkdir($uploadsDir, 0777, true);
}

function loadAssets($configFile) {
    if (file_exists($configFile)) {
        $json = @file_get_contents($configFile);
        $data = json_decode($json, true);
        if (is_array($data)) return $data;
    }
    return [
        'version' => '1.0.0',
        'characters' => [],
        'pendants' => [],
        'landmarks' => [],
        'map' => []
    ];
}

function saveAssets($configFile, $data) {
    $data['last_updated'] = date('Y-m-d H:i:s');
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    @file_put_contents($configFile, $json);

    // Sync to www and ios
    $wwwTarget = __DIR__ . '/../www/config/monopoly_assets.json';
    $iosTarget = __DIR__ . '/../ios/App/App/public/config/monopoly_assets.json';
    @file_put_contents($wwwTarget, $json);
    @file_put_contents($iosTarget, $json);
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'get_assets';

if ($action === 'get_assets') {
    $assets = loadAssets($configFile);
    echo json_encode([
        'status' => 'success',
        'data' => $assets
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_character') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) $input = $_POST;

    $assets = loadAssets($configFile);
    if (!isset($assets['characters'])) $assets['characters'] = [];

    $id = intval($input['id'] ?? 0);
    if ($id <= 0) {
        $maxId = 100;
        foreach ($assets['characters'] as $c) {
            if (isset($c['id']) && $c['id'] > $maxId) $maxId = $c['id'];
        }
        $id = $maxId + 1;
    }

    $char = [
        'id' => $id,
        'name' => trim($input['name'] ?? 'ตัวละคร AI ' . $id),
        'grade' => $input['grade'] ?? 'SS+',
        'avatar_url' => $input['avatar_url'] ?? 'avatars/avatar_01.svg',
        'card_image' => $input['card_image'] ?? $input['avatar_url'] ?? 'avatars/avatar_01.svg',
        'aura_effect' => $input['aura_effect'] ?? 'dragon_aura',
        'dice_control' => intval($input['dice_control'] ?? 90),
        'acquire_discount' => intval($input['acquire_discount'] ?? 85),
        'gold_bonus' => intval($input['gold_bonus'] ?? 40),
        'toll_discount' => intval($input['toll_discount'] ?? 82),
        'skills' => is_array($input['skills'] ?? null) ? $input['skills'] : [
            ['name' => 'บินด่วน AI', 'desc' => 'โอกาส 35% บินไปช่องใดก็ได้เมื่อตกเมืองตัวเอง', 'chance' => 35],
            ['name' => 'โล่คุ้มครองดวงดาว', 'desc' => 'ป้องกันการซื้อต่อและยกเว้นค่าผ่านทาง 50%', 'chance' => 50]
        ],
        'price_diamond' => intval($input['price_diamond'] ?? 1500),
        'price_gold' => intval($input['price_gold'] ?? 2000000),
        'source_type' => $input['source_type'] ?? 'ai_studio',
        'created_at' => date('Y-m-d H:i:s')
    ];

    $found = false;
    foreach ($assets['characters'] as &$existing) {
        if ($existing['id'] === $id) {
            $existing = array_merge($existing, $char);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $assets['characters'][] = $char;
    }

    saveAssets($configFile, $assets);

    echo json_encode([
        'status' => 'success',
        'message' => 'บันทึกตัวละครและเพิ่มเข้าร้านค้าสำเร็จ',
        'character' => $char
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_landmark') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) $input = $_POST;

    $assets = loadAssets($configFile);
    if (!isset($assets['landmarks'])) $assets['landmarks'] = [];

    $id = intval($input['id'] ?? 0);
    if ($id <= 0) {
        $maxId = 300;
        foreach ($assets['landmarks'] as $lm) {
            if (isset($lm['id']) && $lm['id'] > $maxId) $maxId = $lm['id'];
        }
        $id = $maxId + 1;
    }

    $landmark = [
        'id' => $id,
        'name' => trim($input['name'] ?? 'แลนด์มาร์ค AI ' . $id),
        'type' => $input['type'] ?? 'ancient_citadel',
        'color' => $input['color'] ?? '#ffd700',
        'aura' => $input['aura'] ?? 'gold_spin',
        'toll_multiplier' => intval($input['toll_multiplier'] ?? 4),
        'image_url' => $input['image_url'] ?? '',
        'created_at' => date('Y-m-d H:i:s')
    ];

    $found = false;
    foreach ($assets['landmarks'] as &$existing) {
        if ($existing['id'] === $id) {
            $existing = array_merge($existing, $landmark);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $assets['landmarks'][] = $landmark;
    }

    saveAssets($configFile, $assets);

    echo json_encode([
        'status' => 'success',
        'message' => 'บันทึกแลนด์มาร์คสำเร็จ',
        'landmark' => $landmark
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_pendant') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) $input = $_POST;

    $assets = loadAssets($configFile);
    if (!isset($assets['pendants'])) $assets['pendants'] = [];

    $id = intval($input['id'] ?? 0);
    if ($id <= 0) {
        $maxId = 200;
        foreach ($assets['pendants'] as $p) {
            if (isset($p['id']) && $p['id'] > $maxId) $maxId = $p['id'];
        }
        $id = $maxId + 1;
    }

    $pendant = [
        'id' => $id,
        'name' => trim($input['name'] ?? 'จี้เครื่องราง AI ' . $id),
        'grade' => $input['grade'] ?? 'SS+',
        'icon' => $input['icon'] ?? '🔮',
        'aura_color' => $input['aura_color'] ?? '#38bdf8',
        'type' => $input['type'] ?? 'DEFENSE',
        'trigger_chance' => intval($input['trigger_chance'] ?? 75),
        'description' => trim($input['description'] ?? 'ความสามารถจี้เครื่องรางระดับสูง'),
        'image_url' => $input['image_url'] ?? '',
        'price_diamond' => intval($input['price_diamond'] ?? 1500),
        'price_gold' => intval($input['price_gold'] ?? 2000000),
        'created_at' => date('Y-m-d H:i:s')
    ];

    $found = false;
    foreach ($assets['pendants'] as &$existing) {
        if ($existing['id'] === $id) {
            $existing = array_merge($existing, $pendant);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $assets['pendants'][] = $pendant;
    }

    saveAssets($configFile, $assets);

    echo json_encode([
        'status' => 'success',
        'message' => 'บันทึกจี้เครื่องรางและนำเข้าร้านค้าสำเร็จ',
        'pendant' => $pendant
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'upload_media') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่มีไฟล์ที่อัปโหลด หรือเกิดข้อผิดพลาด']);
        exit;
    }

    $file = $_FILES['file'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'webm', 'glb', 'gltf', 'obj'];
    if (!in_array($ext, $allowed)) {
        echo json_encode(['status' => 'error', 'message' => 'รองรับเฉพาะไฟล์รูปภาพ, วิดีโอ หรือโมเดล 3D เท่านั้น']);
        exit;
    }

    $filename = 'monopoly_' . time() . '_' . substr(md5(uniqid()), 0, 8) . '.' . $ext;
    $target = $uploadsDir . '/' . $filename;
    if (move_uploaded_file($file['tmp_name'], $target)) {
        // Also copy to www uploads
        $wwwUploadsDir = __DIR__ . '/../www/uploads/monopoly';
        if (!is_dir($wwwUploadsDir)) @mkdir($wwwUploadsDir, 0777, true);
        @copy($target, $wwwUploadsDir . '/' . $filename);

        $url = 'uploads/monopoly/' . $filename;
        echo json_encode([
            'status' => 'success',
            'url' => $url,
            'file_name' => $filename,
            'file_type' => $ext,
            'is_video' => in_array($ext, ['mp4', 'webm']),
            'is_3d' => in_array($ext, ['glb', 'gltf', 'obj'])
        ]);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'บันทึกไฟล์ไม่สำเร็จ']);
    exit;
}

if ($action === 'ai_analyze_asset') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) $input = $_POST;

    $prompt = trim($input['prompt'] ?? '');
    $targetKind = $input['target_kind'] ?? 'character'; // character | landmark | city | dice | pendant
    $mediaUrl = $input['media_url'] ?? '';

    // Advanced Procedural AI Synthesis Engine
    $seed = crc32($prompt . $mediaUrl . time());
    mt_srand($seed);

    $grades = ['S', 'S+', 'SS+'];
    $grade = $grades[mt_rand(1, 2)];

    $diceControl = mt_rand(88, 97);
    $acquireDiscount = mt_rand(80, 94);
    $goldBonus = mt_rand(35, 55);
    $tollDiscount = mt_rand(82, 95);

    $skillsPool = [
        ['name' => 'ประตูมิติวาร์ปด่วน', 'desc' => 'เมื่อตกเมืองฝ่ายตรงข้าม โอกาส 36% วาร์ปไปท่องเที่ยวสนามบินทันที', 'chance' => 36],
        ['name' => 'หลุมดำพายุไซโคลน', 'desc' => 'เมื่อสร้างแลนด์มาร์ค โอกาส 85% สร้างหลุมดำดูดผู้เล่นรอบข้าง', 'chance' => 85],
        ['name' => 'เกราะคุ้มกันราชันย์', 'desc' => 'ได้รับการยกเว้นค่าผ่านทางและป้องกันการโจมตี 50%', 'chance' => 50],
        ['name' => 'หมัดมังกรทลายเมือง', 'desc' => 'เมื่อทอยตกเมืองคู่แข่ง โอกาส 30% ทำลายเมืองคู่แข่งกลายเป็นที่ดินว่าง', 'chance' => 30],
        ['name' => 'พลังดึงดูดมหาเศรษฐี', 'desc' => 'เมื่อตกแลนด์มาร์คตัวเอง ดูดผู้เล่นในแถวเดียวกันมาที่เมืองทันที โอกาส 75%', 'chance' => 75]
    ];
    shuffle($skillsPool);
    $selectedSkills = array_slice($skillsPool, 0, 2);

    $auras = ['dragon_aura', 'galaxy_sparkle', 'cyber_neon', 'holy_golden', 'emerald_leaf'];
    $aura = $auras[mt_rand(0, count($auras) - 1)];

    $suggestedName = !empty($prompt) ? $prompt : ('จอมราชันย์ ' . ($targetKind === 'landmark' ? 'ปราสาทสวรรค์' : 'มหาเศรษฐีเวิลด์') . ' ' . $grade);

    echo json_encode([
        'status' => 'success',
        'analysis' => [
            'name' => $suggestedName,
            'grade' => $grade,
            'aura_effect' => $aura,
            'dice_control' => $diceControl,
            'acquire_discount' => $acquireDiscount,
            'gold_bonus' => $goldBonus,
            'toll_discount' => $tollDiscount,
            'skills' => $selectedSkills,
            'price_diamond' => ($grade === 'SS+' ? 1800 : 1200),
            'price_gold' => ($grade === 'SS+' ? 2500000 : 1500000),
            'ai_confidence' => 98.4
        ]
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
