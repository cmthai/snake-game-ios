<?php
declare(strict_types=1);

/**
 * api/shop_menus_service.php
 * Dynamic Shop Menus, Sub-tabs, Custom Showcase Items & Purchase Engine (PHP 7.4+ Compatible)
 */

function ensureShopMenusSchema(mysqli $db): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $stamp = __DIR__ . '/../config/.shop_menus_v1.stamp';
    if (@file_exists($stamp)) return;

    $db->query("
        CREATE TABLE IF NOT EXISTS `shop_menus` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `menu_slug` VARCHAR(60) NOT NULL,
            `title` VARCHAR(120) NOT NULL,
            `icon` VARCHAR(30) NOT NULL DEFAULT '🏪',
            `menu_type` VARCHAR(30) NOT NULL DEFAULT 'CUSTOM',
            `subtabs_csv` VARCHAR(255) NOT NULL DEFAULT '',
            `badge_text` VARCHAR(30) NOT NULL DEFAULT '',
            `sort_order` INT NOT NULL DEFAULT 10,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `is_system` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uq_shop_menu_slug` (`menu_slug`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $db->query("
        CREATE TABLE IF NOT EXISTS `shop_custom_items` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `menu_slug` VARCHAR(60) NOT NULL DEFAULT 'featured',
            `subtab_name` VARCHAR(80) NOT NULL DEFAULT '',
            `title` VARCHAR(150) NOT NULL,
            `subtitle` VARCHAR(200) NOT NULL DEFAULT '',
            `badge_text` VARCHAR(40) NOT NULL DEFAULT '',
            `card_theme` VARCHAR(30) NOT NULL DEFAULT 'blue',
            `item_kind` VARCHAR(30) NOT NULL DEFAULT 'BUNDLE',
            `reward_diamond` BIGINT NOT NULL DEFAULT 0,
            `reward_gold` BIGINT NOT NULL DEFAULT 0,
            `ref_character_id` INT NOT NULL DEFAULT 0,
            `ref_dice_id` INT NOT NULL DEFAULT 0,
            `image_url` MEDIUMTEXT NULL,
            `currency` VARCHAR(20) NOT NULL DEFAULT 'DIAMOND',
            `price` DECIMAL(12,2) NOT NULL DEFAULT 100.00,
            `purchase_limit` INT NOT NULL DEFAULT 0,
            `sort_order` INT NOT NULL DEFAULT 10,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY `idx_menu_slug` (`menu_slug`, `is_active`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $db->query("
        CREATE TABLE IF NOT EXISTS `shop_user_purchases` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `shop_item_id` INT NOT NULL,
            `buy_count` INT NOT NULL DEFAULT 0,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `uq_user_shop_item` (`user_id`, `shop_item_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Seed default menus if empty
    $cntRes = $db->query("SELECT COUNT(*) AS cnt FROM `shop_menus`");
    $cnt = $cntRes ? (int)($cntRes->fetch_assoc()['cnt'] ?? 0) : 0;
    if ($cnt === 0) {
        $defaults = [
            ['featured',     'ร้านค้าแนะนำ',       '🔥', 'FEATURED',     'ร้านค้าจำกัด,โปรโมชั่นสุดคุ้ม,แพ็กเกจ 1+1', 'HOT',     10, 1, 1],
            ['diamond',      'ร้านค้าเพชร',        '💎', 'DIAMOND',      'เพชรทั้งหมด,รับเพชรฟรี',                     '',        20, 1, 1],
            ['gold',         'ร้านค้าทอง',         '🪙', 'GOLD',         'แลกทองด้วยเพชร,แพ็กเกจทอง',                   '',        30, 1, 1],
            ['frames',       'การ์ดกรอบ',          '👑', 'FRAME',        'การ์ดกรอบทั้งหมด,ระดับ SS+ / S+,อัปเกรด Lv.30', 'SS+',  40, 1, 1],
            ['dice',         'ลูกเต๋า',            '🎲', 'DICE',         'ลูกเต๋าทั้งหมด,ลูกเต๋าระดับแรร์',             '3D',      50, 1, 1],
            ['pickup_frame', 'PICK UP การ์ดกรอบ',  '✨', 'PICKUP_FRAME', 'สุ่มแพ็คการ์ดกรอบ,แลกเงาการ์ด',               'PICK UP', 60, 1, 1],
            ['pickup_dice',  'PICK UP ลูกเต๋า',    '🎯', 'PICKUP_DICE',  'สุ่มลูกเต๋า 3D',                             'PICK UP', 70, 1, 1],
        ];
        $stmt = $db->prepare("INSERT IGNORE INTO `shop_menus` (menu_slug, title, icon, menu_type, subtabs_csv, badge_text, sort_order, is_active, is_system) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($defaults as $m) {
            $stmt->bind_param("ssssssiii", $m[0], $m[1], $m[2], $m[3], $m[4], $m[5], $m[6], $m[7], $m[8]);
            $stmt->execute();
        }
        $stmt->close();
    }

    // Seed default custom items for featured & gold exchange if empty
    $itemCntRes = $db->query("SELECT COUNT(*) AS cnt FROM `shop_custom_items`");
    $itemCnt = $itemCntRes ? (int)($itemCntRes->fetch_assoc()['cnt'] ?? 0) : 0;
    if ($itemCnt === 0) {
        $seedItems = [
            ['featured', 'ร้านค้าจำกัด',    'แพ็กเกจต้อนรับ 1+1 สุดคุ้ม!', 'รับทอง 1,500,000 + โบนัสเพชร', '1+1',     'pink',   'BUNDLE', 250, 1500000,  0, 0, 'DIAMOND', 199,  3, 10],
            ['featured', 'ร้านค้าจำกัด',    'หีบสมบัติมหาเศรษฐี',         'ทองก้อนโตพร้อมลุยห้อง 10M',     'HOT',     'purple', 'BUNDLE', 100, 5000000,  0, 0, 'DIAMOND', 450,  5, 20],
            ['featured', 'ร้านค้าจำกัด',    'เซ็ตจักรพรรดิพญานาคราช',     'รับการ์ดกรอบ S+ พร้อมทอง 3M',    'LIMITED', 'gold',   'BUNDLE', 0,   3000000,  1, 0, 'DIAMOND', 990,  1, 30],
            ['featured', 'โปรโมชั่นสุดคุ้ม', 'กล่องสุ่มเพชรนำโชค 1+1',     'เพชรคูณสองสุดคุ้มประจำสัปดาห์',  'SALE',    'blue',   'DIAMOND',600, 500000,   0, 0, 'DIAMOND', 299,  2, 40],
            ['featured', 'แพ็กเกจ 1+1',     'แพ็กเกจเต๋าคริสตัล 1+1',     'รับเต๋าคริสตัล 3D + ทอง 1M',     '1+1',     'green',  'BUNDLE', 0,   1000000,  0, 2, 'DIAMOND', 490,  1, 50],
            ['gold',     'แลกทองด้วยเพชร',  'ถุงทองนักผจญภัย',            'แลกรับ 500,000 ทองทันที',       '',        'blue',   'GOLD',   0,   500000,   0, 0, 'DIAMOND', 100,  0, 10],
            ['gold',     'แลกทองด้วยเพชร',  'หีบทองคำราชา',               'แลกรับ 2,500,000 ทองทันที',     'คุ้มค่า', 'gold',   'GOLD',   0,   2500000,  0, 0, 'DIAMOND', 400,  0, 20],
            ['gold',     'แลกทองด้วยเพชร',  'คลังสมบัติจักรพรรดิ',         'แลกรับ 10,000,000 ทองทันที!',   'HOT',     'purple', 'GOLD',   0,   10000000, 0, 0, 'DIAMOND', 1200, 0, 30],
        ];
        $iStmt = $db->prepare("INSERT INTO `shop_custom_items` (menu_slug, subtab_name, title, subtitle, badge_text, card_theme, item_kind, reward_diamond, reward_gold, ref_character_id, ref_dice_id, currency, price, purchase_limit, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
        foreach ($seedItems as $it) {
            $priceVal = (float)$it[12];
            $iStmt->bind_param(
                "sssssssiiiisdii",
                $it[0], $it[1], $it[2], $it[3], $it[4], $it[5], $it[6],
                $it[7], $it[8], $it[9], $it[10], $it[11], $priceVal, $it[13], $it[14]
            );
            $iStmt->execute();
        }
        $iStmt->close();
    }

    @file_put_contents($stamp, (string)time());
}

function getShopMenusAndItems(mysqli $db, int $userId = 0, bool $includeInactive = false): array {
    ensureShopMenusSchema($db);

    $whereMenu = $includeInactive ? "1=1" : "is_active = 1";
    $menusRes = $db->query("SELECT * FROM `shop_menus` WHERE {$whereMenu} ORDER BY sort_order ASC, id ASC");
    $menus = $menusRes ? $menusRes->fetch_all(MYSQLI_ASSOC) : [];

    foreach ($menus as &$m) {
        $csv = trim((string)($m['subtabs_csv'] ?? ''));
        $subs = [];
        if ($csv !== '') {
            foreach (explode(',', $csv) as $part) {
                $t = trim($part);
                if ($t !== '') $subs[] = $t;
            }
        }
        $m['subtabs'] = $subs;
    }
    unset($m);

    $whereItem = $includeInactive ? "1=1" : "s.is_active = 1";
    $itemsSql = "
        SELECT s.*,
               c.name AS char_name, c.grade AS char_grade, c.avatar_url AS char_avatar_url, c.aura_type AS char_aura_type, c.color_hex AS char_color_hex,
               d.name AS dice_name, d.grade AS dice_grade, d.image_url AS dice_image_url, d.color_hex AS dice_color_hex, d.pip_color_hex AS dice_pip_color_hex, d.aura_type AS dice_aura_type
        FROM `shop_custom_items` s
        LEFT JOIN `characters` c ON s.ref_character_id = c.id
        LEFT JOIN `dice` d ON s.ref_dice_id = d.id
        WHERE {$whereItem}
        ORDER BY s.sort_order ASC, s.id ASC
    ";
    $itemsRes = $db->query($itemsSql);
    $items = $itemsRes ? $itemsRes->fetch_all(MYSQLI_ASSOC) : [];

    $purchasedMap = [];
    if ($userId > 0) {
        $pRes = $db->query("SELECT shop_item_id, buy_count FROM `shop_user_purchases` WHERE user_id = " . (int)$userId);
        if ($pRes) {
            while ($row = $pRes->fetch_assoc()) {
                $purchasedMap[(int)$row['shop_item_id']] = (int)$row['buy_count'];
            }
        }
    }

    foreach ($items as &$it) {
        $iid = (int)$it['id'];
        $it['user_buy_count'] = $purchasedMap[$iid] ?? 0;
    }
    unset($it);

    return [
        'menus' => $menus,
        'custom_items' => $items
    ];
}

function saveShopMenuAdmin(mysqli $db, array $input): array {
    ensureShopMenusSchema($db);
    $id = (int)($input['id'] ?? 0);
    $title = trim((string)($input['title'] ?? ''));
    if ($title === '') {
        return ['status' => 'error', 'message' => 'กรุณาระบุชื่อเมนูร้านค้า'];
    }

    $rawSlug = strtolower(trim((string)($input['menu_slug'] ?? '')));
    $rawSlug = preg_replace('/[^a-z0-9_\-]/', '_', $rawSlug);
    if ($rawSlug === '' || $rawSlug === '_') {
        $rawSlug = 'menu_' . substr(md5($title . microtime(true)), 0, 8);
    }

    $icon = trim((string)($input['icon'] ?? '🏪')) ?: '🏪';
    $menuType = strtoupper(trim((string)($input['menu_type'] ?? 'CUSTOM')));
    $allowedTypes = ['FEATURED', 'DIAMOND', 'GOLD', 'FRAME', 'DICE', 'PICKUP_FRAME', 'PICKUP_DICE', 'CUSTOM'];
    if (!in_array($menuType, $allowedTypes, true)) {
        $menuType = 'CUSTOM';
    }
    $subtabsCsv = trim((string)($input['subtabs_csv'] ?? ''));
    $badgeText = trim((string)($input['badge_text'] ?? ''));
    $sortOrder = (int)($input['sort_order'] ?? 50);
    $isActive = isset($input['is_active']) ? ((int)$input['is_active'] ? 1 : 0) : 1;

    if ($id > 0) {
        $stmt = $db->prepare("UPDATE `shop_menus` SET title = ?, icon = ?, menu_type = ?, subtabs_csv = ?, badge_text = ?, sort_order = ?, is_active = ? WHERE id = ?");
        $stmt->bind_param("sssssiii", $title, $icon, $menuType, $subtabsCsv, $badgeText, $sortOrder, $isActive, $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok
            ? ['status' => 'success', 'message' => "บันทึกเมนูร้านค้า '{$title}' เรียบร้อยแล้ว!"]
            : ['status' => 'error', 'message' => 'ไม่สามารถอัปเดตเมนูได้: ' . $db->error];
    } else {
        // Ensure unique slug
        $chk = $db->prepare("SELECT id FROM `shop_menus` WHERE menu_slug = ? LIMIT 1");
        $chk->bind_param("s", $rawSlug);
        $chk->execute();
        if ($chk->get_result()->fetch_assoc()) {
            $rawSlug .= '_' . rand(10, 99);
        }
        $chk->close();

        $stmt = $db->prepare("INSERT INTO `shop_menus` (menu_slug, title, icon, menu_type, subtabs_csv, badge_text, sort_order, is_active, is_system) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)");
        $stmt->bind_param("ssssssii", $rawSlug, $title, $icon, $menuType, $subtabsCsv, $badgeText, $sortOrder, $isActive);
        $ok = $stmt->execute();
        $newId = (int)$stmt->insert_id;
        $stmt->close();
        return $ok
            ? ['status' => 'success', 'message' => "เพิ่มเมนูร้านค้าใหม่ '{$title}' สำเร็จ!", 'id' => $newId, 'menu_slug' => $rawSlug]
            : ['status' => 'error', 'message' => 'ไม่สามารถเพิ่มเมนูได้: ' . $db->error];
    }
}

function deleteShopMenuAdmin(mysqli $db, int $id): array {
    ensureShopMenusSchema($db);
    $row = $db->query("SELECT * FROM `shop_menus` WHERE id = " . (int)$id)->fetch_assoc();
    if (!$row) {
        return ['status' => 'error', 'message' => 'ไม่พบเมนูที่ต้องการลบ'];
    }
    if ((int)$row['is_system'] === 1) {
        return ['status' => 'error', 'message' => 'เมนูหลักของระบบไม่สามารถลบได้ (สามารถกด "ปิดการแสดงผล" แทนได้ครับ)'];
    }
    $db->query("DELETE FROM `shop_menus` WHERE id = " . (int)$id);
    return ['status' => 'success', 'message' => "ลบเมนูร้านค้า '{$row['title']}' เรียบร้อยแล้ว"];
}

function toggleShopMenuAdmin(mysqli $db, int $id, int $isActive): array {
    ensureShopMenusSchema($db);
    $val = $isActive ? 1 : 0;
    $db->query("UPDATE `shop_menus` SET is_active = {$val} WHERE id = " . (int)$id);
    return ['status' => 'success', 'message' => $val ? 'เปิดแสดงเมนูร้านค้าแล้ว' : 'ซ่อนเมนูร้านค้าแล้ว'];
}

function saveShopCustomItemAdmin(mysqli $db, array $input): array {
    ensureShopMenusSchema($db);
    $id = (int)($input['id'] ?? 0);
    $menuSlug = trim((string)($input['menu_slug'] ?? 'featured')) ?: 'featured';
    $subtabName = trim((string)($input['subtab_name'] ?? ''));
    $title = trim((string)($input['title'] ?? ''));
    if ($title === '') {
        return ['status' => 'error', 'message' => 'กรุณาระบุชื่อสินค้า/แพ็กเกจ'];
    }
    $subtitle = trim((string)($input['subtitle'] ?? ''));
    $badgeText = trim((string)($input['badge_text'] ?? ''));
    $cardTheme = trim((string)($input['card_theme'] ?? 'blue')) ?: 'blue';
    $itemKind = strtoupper(trim((string)($input['item_kind'] ?? 'BUNDLE')));
    $rewardDiamond = max(0, (int)($input['reward_diamond'] ?? 0));
    $rewardGold = max(0, (int)($input['reward_gold'] ?? 0));
    $refCharId = max(0, (int)($input['ref_character_id'] ?? 0));
    $refDiceId = max(0, (int)($input['ref_dice_id'] ?? 0));
    $imageUrl = isset($input['image_url']) ? trim((string)$input['image_url']) : '';
    $currency = strtoupper(trim((string)($input['currency'] ?? 'DIAMOND')));
    if (!in_array($currency, ['DIAMOND', 'GOLD', 'THB'], true)) {
        $currency = 'DIAMOND';
    }
    $price = max(0, (float)($input['price'] ?? 0));
    $purchaseLimit = max(0, (int)($input['purchase_limit'] ?? 0));
    $sortOrder = (int)($input['sort_order'] ?? 10);
    $isActive = isset($input['is_active']) ? ((int)$input['is_active'] ? 1 : 0) : 1;

    if ($id > 0) {
        $stmt = $db->prepare("UPDATE `shop_custom_items` SET menu_slug=?, subtab_name=?, title=?, subtitle=?, badge_text=?, card_theme=?, item_kind=?, reward_diamond=?, reward_gold=?, ref_character_id=?, ref_dice_id=?, image_url=?, currency=?, price=?, purchase_limit=?, sort_order=?, is_active=? WHERE id=?");
        $stmt->bind_param(
            "sssssssiiiissdiiii",
            $menuSlug, $subtabName, $title, $subtitle, $badgeText, $cardTheme, $itemKind,
            $rewardDiamond, $rewardGold, $refCharId, $refDiceId, $imageUrl, $currency, $price,
            $purchaseLimit, $sortOrder, $isActive, $id
        );
        $ok = $stmt->execute();
        $stmt->close();
        return $ok
            ? ['status' => 'success', 'message' => "อัปเดตสินค้า '{$title}' สำเร็จ!"]
            : ['status' => 'error', 'message' => 'อัปเดตไม่สำเร็จ: ' . $db->error];
    } else {
        $stmt = $db->prepare("INSERT INTO `shop_custom_items` (menu_slug, subtab_name, title, subtitle, badge_text, card_theme, item_kind, reward_diamond, reward_gold, ref_character_id, ref_dice_id, image_url, currency, price, purchase_limit, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "sssssssiiiissdiii",
            $menuSlug, $subtabName, $title, $subtitle, $badgeText, $cardTheme, $itemKind,
            $rewardDiamond, $rewardGold, $refCharId, $refDiceId, $imageUrl, $currency, $price,
            $purchaseLimit, $sortOrder, $isActive
        );
        $ok = $stmt->execute();
        $newId = (int)$stmt->insert_id;
        $stmt->close();
        return $ok
            ? ['status' => 'success', 'message' => "เพิ่มการ์ดสินค้า '{$title}' เข้าเมนูร้านค้าสำเร็จ!", 'id' => $newId]
            : ['status' => 'error', 'message' => 'เพิ่มสินค้าไม่สำเร็จ: ' . $db->error];
    }
}

function deleteShopCustomItemAdmin(mysqli $db, int $id): array {
    ensureShopMenusSchema($db);
    $db->query("DELETE FROM `shop_custom_items` WHERE id = " . (int)$id);
    return ['status' => 'success', 'message' => 'ลบรายการสินค้าออกจากร้านค้าเรียบร้อยแล้ว'];
}

function updateCatalogItemShopPriceAdmin(mysqli $db, array $input): array {
    $type = strtoupper(trim((string)($input['item_type'] ?? 'CHARACTER')));
    $id = (int)($input['id'] ?? 0);
    $priceDia = max(0, (int)($input['price_diamond'] ?? 0));
    $priceGold = max(0, (int)($input['price_gold'] ?? 0));
    $isAvailable = isset($input['is_available']) ? ((int)$input['is_available'] ? 1 : 0) : 1;

    if ($id <= 0) {
        return ['status' => 'error', 'message' => 'รหัสไอเทมไม่ถูกต้อง'];
    }
    $table = ($type === 'DICE') ? 'dice' : 'characters';
    $stmt = $db->prepare("UPDATE `{$table}` SET price_diamond = ?, price_gold = ?, is_available = ? WHERE id = ?");
    $stmt->bind_param("iiii", $priceDia, $priceGold, $isAvailable, $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok
        ? ['status' => 'success', 'message' => 'บันทึกราคาร้านค้าเรียบร้อยแล้ว!']
        : ['status' => 'error', 'message' => 'บันทึกราคาไม่สำเร็จ: ' . $db->error];
}

function purchaseShopCustomItem(mysqli $db, int $userId, int $shopItemId): array {
    ensureShopMenusSchema($db);
    $stmt = $db->prepare("SELECT * FROM `shop_custom_items` WHERE id = ? AND is_active = 1 LIMIT 1");
    $stmt->bind_param("i", $shopItemId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$item) {
        return ['status' => 'error', 'code' => 404, 'message' => 'ไม่พบสินค้านี้ในร้านค้า หรือสินค้าหมดเวลาจำหน่ายแล้ว'];
    }

    $limit = (int)$item['purchase_limit'];
    $currency = strtoupper((string)$item['currency']);
    $price = (float)$item['price'];
    $priceInt = (int)round($price);

    $db->begin_transaction();
    try {
        // Lock user row
        $uStmt = $db->prepare("SELECT diamond, gold FROM `users` WHERE id = ? FOR UPDATE");
        $uStmt->bind_param("i", $userId);
        $uStmt->execute();
        $uRow = $uStmt->get_result()->fetch_assoc();
        $uStmt->close();
        if (!$uRow) {
            $db->rollback();
            return ['status' => 'error', 'code' => 404, 'message' => 'ไม่พบข้อมูลผู้เล่น'];
        }

        // Check purchase limit
        $buyCount = 0;
        $pStmt = $db->prepare("SELECT buy_count FROM `shop_user_purchases` WHERE user_id = ? AND shop_item_id = ? FOR UPDATE");
        $pStmt->bind_param("ii", $userId, $shopItemId);
        $pStmt->execute();
        $pRow = $pStmt->get_result()->fetch_assoc();
        $pStmt->close();
        if ($pRow) {
            $buyCount = (int)$pRow['buy_count'];
        }
        if ($limit > 0 && $buyCount >= $limit) {
            $db->rollback();
            return ['status' => 'error', 'code' => 400, 'message' => "คุณซื้อแพ็กเกจนี้ครบจำนวนจำกัดแล้ว ({$buyCount}/{$limit})"];
        }

        // Deduct currency if DIAMOND or GOLD
        if ($currency === 'DIAMOND') {
            if ((int)$uRow['diamond'] < $priceInt) {
                $db->rollback();
                return ['status' => 'error', 'code' => 400, 'message' => 'เพชรของคุณไม่เพียงพอสำหรับซื้อรายการนี้'];
            }
            $db->query("UPDATE `users` SET diamond = diamond - {$priceInt} WHERE id = {$userId}");
        } elseif ($currency === 'GOLD') {
            if ((int)$uRow['gold'] < $priceInt) {
                $db->rollback();
                return ['status' => 'error', 'code' => 400, 'message' => 'ทองของคุณไม่เพียงพอสำหรับซื้อรายการนี้'];
            }
            $db->query("UPDATE `users` SET gold = gold - {$priceInt} WHERE id = {$userId}");
        }

        // Grant rewards
        $rewDia = (int)$item['reward_diamond'];
        $rewGold = (int)$item['reward_gold'];
        if ($rewDia > 0 || $rewGold > 0) {
            $db->query("UPDATE `users` SET diamond = diamond + {$rewDia}, gold = gold + {$rewGold} WHERE id = {$userId}");
        }

        $grantedParts = [];
        if ($rewDia > 0) $grantedParts[] = '+' . number_format($rewDia) . ' เพชร';
        if ($rewGold > 0) $grantedParts[] = '+' . number_format($rewGold) . ' ทอง';

        $refCharId = (int)$item['ref_character_id'];
        if ($refCharId > 0) {
            $chkC = $db->query("SELECT id FROM `user_inventory` WHERE user_id = {$userId} AND character_id = {$refCharId} LIMIT 1")->fetch_assoc();
            if (!$chkC) {
                $db->query("INSERT INTO `user_inventory` (user_id, item_type, character_id, level, is_equipped) VALUES ({$userId}, 'CHARACTER', {$refCharId}, 1, 0)");
            }
            $cInfo = $db->query("SELECT name FROM `characters` WHERE id = {$refCharId}")->fetch_assoc();
            if ($cInfo) $grantedParts[] = "การ์ดกรอบ '{$cInfo['name']}'";
        }

        $refDiceId = (int)$item['ref_dice_id'];
        if ($refDiceId > 0) {
            $chkD = $db->query("SELECT id FROM `user_inventory` WHERE user_id = {$userId} AND dice_id = {$refDiceId} LIMIT 1")->fetch_assoc();
            if (!$chkD) {
                $db->query("INSERT INTO `user_inventory` (user_id, item_type, dice_id, level, is_equipped) VALUES ({$userId}, 'DICE', {$refDiceId}, 1, 0)");
            }
            $dInfo = $db->query("SELECT name FROM `dice` WHERE id = {$refDiceId}")->fetch_assoc();
            if ($dInfo) $grantedParts[] = "ลูกเต๋า '{$dInfo['name']}'";
        }

        // Record purchase count
        $newCount = $buyCount + 1;
        $upP = $db->prepare("INSERT INTO `shop_user_purchases` (user_id, shop_item_id, buy_count) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE buy_count = buy_count + 1");
        $upP->bind_param("ii", $userId, $shopItemId);
        $upP->execute();
        $upP->close();

        $summary = !empty($grantedParts) ? implode(' • ', $grantedParts) : $item['title'];
        $uRes = $db->query("SELECT diamond, gold FROM `users` WHERE id = {$userId}")->fetch_assoc();
        $db->commit();

        return [
            'status' => 'success',
            'message' => "ซื้อ '{$item['title']}' สำเร็จ! ได้รับ {$summary}",
            'added_diamond' => $rewDia,
            'added_gold' => $rewGold,
            'new_diamond' => (int)($uRes['diamond'] ?? 0),
            'new_gold' => (int)($uRes['gold'] ?? 0),
            'reward_summary' => $summary,
            'user_buy_count' => $newCount,
            'purchase_limit' => $limit
        ];
    } catch (Throwable $e) {
        $db->rollback();
        return ['status' => 'error', 'code' => 500, 'message' => 'การสั่งซื้อล้มเหลว: ' . $e->getMessage()];
    }
}
