<?php
declare(strict_types=1);

/**
 * check_payment_status.php - Real-Time Payment Status Polling & Webhook / Fulfillment API
 * PHP 8.4.25 / Nginx 1.31.6 / MariaDB
 * 
 * Features:
 *  - Polls order status every 2 seconds during 60s countdown
 *  - Fulfills items (adds diamonds & gold to user) atomically when status is 'paid'
 *  - Supports simulated payment / webhook test trigger
 *  - Automatically expires orders older than 60 seconds
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$db = getDbConnection();

// Read input from GET or POST or JSON body
$rawInput = file_get_contents('php://input');
$jsonInput = !empty($rawInput) ? json_decode($rawInput, true) : [];
if (!is_array($jsonInput)) $jsonInput = [];

$orderNo = trim((string)($_GET['order_no'] ?? $_POST['order_no'] ?? $jsonInput['order_no'] ?? ''));
$orderId = (int)($_GET['order_id'] ?? $_POST['order_id'] ?? $jsonInput['order_id'] ?? 0);
$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? $jsonInput['action'] ?? 'check'));

if (empty($orderNo) && $orderId <= 0) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'กรุณาระบุรหัสใบสั่งซื้อ (order_no หรือ order_id)'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Query the order
$cleanOrderNo = preg_replace('/^REF-/', '', $orderNo);
if (!empty($orderNo)) {
    $stmt = $db->prepare("SELECT * FROM payment_orders WHERE order_no = ? OR order_no = ? LIMIT 1");
    $stmt->bind_param("ss", $orderNo, $cleanOrderNo);
} else {
    $stmt = $db->prepare("SELECT * FROM payment_orders WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $orderId);
}
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    http_response_code(404);
    echo json_encode([
        'status' => 'error',
        'message' => 'ไม่พบข้อมูลใบสั่งซื้อนี้ในระบบ'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$currentOrderNo = (string)$order['order_no'];
$currentOrderId = (int)$order['id'];
$userId = (int)$order['user_id'];
$amountThb = (float)$order['amount_thb'];
$rewardDia = (int)$order['reward_diamond'];
$rewardGold = (int)$order['reward_gold'];
$status = (string)$order['status'];
$isFulfilled = (int)($order['is_fulfilled'] ?? 0);
$expiredAtTime = strtotime((string)$order['expired_at']);
$now = time();

// Optional action: Confirm payment / Simulate payment / Admin mark paid / Webhook
if ($action === 'confirm_paid' || $action === 'simulate_pay' || $action === 'mark_paid' || $action === 'webhook') {
    if ($status === 'pending' || $status === 'expired') {
        $db->query("UPDATE payment_orders SET status = 'paid', paid_at = NOW() WHERE id = {$currentOrderId}");
        $status = 'paid';
    }
}

// Check expiration if still pending
if ($status === 'pending') {
    if ($now > $expiredAtTime) {
        $db->query("UPDATE payment_orders SET status = 'expired' WHERE id = {$currentOrderId}");
        $status = 'expired';
    }
}

// If status is paid, ensure items are fulfilled atomically
if ($status === 'paid') {
    if ($isFulfilled === 0) {
        $db->begin_transaction();
        try {
            // Lock order row
            $chk = $db->query("SELECT is_fulfilled FROM payment_orders WHERE id = {$currentOrderId} FOR UPDATE")->fetch_assoc();
            if ($chk && (int)$chk['is_fulfilled'] === 0) {
                // Credit diamonds and gold to user
                $updUser = $db->prepare("UPDATE users SET diamond = diamond + ?, gold = gold + ? WHERE id = ?");
                $updUser->bind_param("iii", $rewardDia, $rewardGold, $userId);
                $updUser->execute();
                $updUser->close();

                // Send confirmation receipt to user's mailbox
                $mailTitle = "ใบเสร็จชำระเงินสำเร็จ: {$order['item_name']}";
                $mailMsg = "ระบบได้รับยอดเงินจำนวน " . number_format($amountThb, 2) . " บาท ผ่าน PromptPay QR เรียบร้อยแล้ว! จัดส่ง {$rewardDia} เพชร และ " . number_format($rewardGold) . " ทอง เข้าตัวละครเรียบร้อยแล้วค่ะ";
                $mStmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
                $mStmt->bind_param("iss", $userId, $mailTitle, $mailMsg);
                $mStmt->execute();
                $mStmt->close();

                // Mark order as fulfilled in both payment_orders and orders tables
                $db->query("UPDATE payment_orders SET is_fulfilled = 1, paid_at = IFNULL(paid_at, NOW()) WHERE id = {$currentOrderId}");
                $db->query("UPDATE `orders` SET `status` = 'PAID' WHERE `order_no` = '{$currentOrderNo}'");
            }
            $db->commit();
            $isFulfilled = 1;
        } catch (Throwable $e) {
            $db->rollback();
        }
    }

    // Retrieve fresh user balance
    $uRes = $db->query("SELECT diamond, gold FROM users WHERE id = {$userId}")->fetch_assoc();
    $newDia = (int)($uRes['diamond'] ?? 0);
    $newGold = (int)($uRes['gold'] ?? 0);

    echo json_encode([
        'status' => 'success',
        'payment_status' => 'paid',
        'order_no' => $currentOrderNo,
        'order_id' => $currentOrderId,
        'amount_thb' => $amountThb,
        'reward_diamond' => $rewardDia,
        'reward_gold' => $rewardGold,
        'new_diamond' => $newDia,
        'new_gold' => $newGold,
        'is_fulfilled' => 1,
        'voice_text' => "ระบบได้รับเงินจำนวน " . number_format($amountThb, 2) . " บาท และส่งเพชรจำนวน " . number_format($rewardDia) . " เพชรให้เรียบร้อยแล้วค่ะ! เย้!",
        'message' => "ระบบตรวจสอบยอดเงินจำนวน {$amountThb} บาท สำเร็จแล้ว และได้ส่งมอบเพชร {$rewardDia} เพชร เรียบร้อยแล้วค่ะ"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Status is pending: return remaining seconds
if ($status === 'pending') {
    $remainingSeconds = max(0, $expiredAtTime - $now);
    echo json_encode([
        'status' => 'success',
        'payment_status' => 'pending',
        'order_no' => $currentOrderNo,
        'order_id' => $currentOrderId,
        'amount_thb' => $amountThb,
        'reward_diamond' => $rewardDia,
        'remaining_seconds' => $remainingSeconds,
        'message' => "กำลังรอการชำระเงินผ่าน PromptPay QR Code (เหลือเวลา {$remainingSeconds} วินาที)"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Status is expired or failed
echo json_encode([
    'status' => 'success',
    'payment_status' => $status,
    'order_no' => $currentOrderNo,
    'order_id' => $currentOrderId,
    'amount_thb' => $amountThb,
    'message' => $status === 'expired' ? "หมดเวลาการชำระเงิน (60 วินาที) กรุณากดทำรายการใหม่อีกครั้ง" : "การชำระเงินไม่สำเร็จ"
], JSON_UNESCAPED_UNICODE);
exit;

