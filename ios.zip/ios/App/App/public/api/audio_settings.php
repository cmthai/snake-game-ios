<?php
declare(strict_types=1);

if (!ob_start('ob_gzhandler')) {
    ob_start();
}

require_once __DIR__ . '/../config/database.php';

@ini_set('upload_max_filesize', '64M');
@ini_set('post_max_size', '64M');
@ini_set('memory_limit', '256M');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=120');

$db = getDbConnection();

$action = isset($_GET['action']) ? (string)$_GET['action'] : (isset($_POST['action']) ? (string)$_POST['action'] : '');

$DEFAULT_EVENTS = [
    'malei' => [
        'name' => 'เน€เธชเธตเธขเธเธเธฒเธเธขเนเน€เธฃเธดเนเธกเน€เธเธก ("เธกเธฒเน€เธฅเธขเน")',
        'type' => 'voice',
        'files' => ['malei.mp3'],
        'description' => 'เน€เธ”เนเธเธเธนเนเธซเธเธดเธเธเธนเธ”เธ เธฒเธฉเธฒเนเธ—เธขเธเธณเธงเนเธฒ "เธกเธฒเน€เธฅเธขเน" เน€เธกเธทเนเธญเน€เธฃเธดเนเธกเธเธฒเธฃเนเธเนเธเธเธฑเธ',
        'volume' => 1.0,
        'enabled' => true
    ],
    'yeay' => [
        'name' => 'เน€เธชเธตเธขเธเนเธ”เนเน€เธฃเธดเนเธกเธเธเนเธฃเธ ("เน€เธขเน! เนเธ”เนเธ—เธญเธขเน€เธเนเธเธเธเนเธฃเธ")',
        'type' => 'voice',
        'files' => ['yeay.mp3'],
        'description' => 'เน€เธ”เนเธเธเธนเนเธซเธเธดเธเธเธนเธ”เธ เธฒเธฉเธฒเนเธ—เธขเธเธณเธงเนเธฒ "เน€เธขเน! เนเธ”เนเธ—เธญเธขเน€เธเนเธเธเธเนเธฃเธ"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'dice_roll' => [
        'name' => 'เน€เธชเธตเธขเธเธ—เธญเธขเธฅเธนเธเน€เธ•เนเธฒ (Dice Roll)',
        'type' => 'sfx',
        'files' => ['dice.mp3'],
        'description' => 'เน€เธญเธเน€เธเธเธ•เนเธฅเธนเธเน€เธ•เนเธฒเธซเธกเธธเธเธเธฃเธฐเธ—เธเธเธทเนเธเธเธฃเธฐเธ”เธฒเธ (Dice Roll SFX)',
        'volume' => 0.9,
        'enabled' => true
    ],
    'step' => [
        'name' => 'เน€เธชเธตเธขเธเน€เธ”เธดเธเธเธฑเธเธเนเธญเธ (Step SFX)',
        'type' => 'sfx',
        'files' => ['walk.mp3'],
        'description' => 'เน€เธชเธตเธขเธเธเนเธฒเธงเน€เธ”เธดเธเธชเธฑเนเธเน เธ•เธฒเธกเธเธณเธเธงเธเนเธ•เนเธกเธฅเธนเธเน€เธ•เนเธฒเนเธเนเธ•เนเธฅเธฐเธเนเธญเธ',
        'volume' => 0.85,
        'enabled' => true
    ],
    'double' => [
        'name' => 'เน€เธชเธตเธขเธเธ—เธญเธขเนเธ”เนเนเธ•เนเธกเธ”เธฑเธเน€เธเธดเธฅ ("เธ”เธฑเธเน€เธเธดเธฅ!")',
        'type' => 'voice',
        'files' => ['double.mp3'],
        'description' => 'เน€เธ”เนเธเธเธนเนเธซเธเธดเธเธเธนเธ”เธ เธฒเธฉเธฒเนเธ—เธขเธเธฑเธ”เน€เธเธเธงเนเธฒ "เธ”เธฑเธเน€เธเธดเธฅ!"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'island_trap' => [
        'name' => 'เน€เธชเธตเธขเธเธ•เธเน€เธเธฒเธฐ / เธ•เธดเธ”เธเธธเธ ("เธซเธทเธญเนเน เธ•เธดเธ”เน€เธเธฒเธฐเธเธฐเนเธฅเนเธง")',
        'type' => 'voice',
        'files' => ['tok-koh.mp3'],
        'description' => 'เน€เธ”เนเธเธเธนเนเธซเธเธดเธเธฃเนเธญเธเนเธซเน/เธเนเธเธ เธฒเธฉเธฒเนเธ—เธขเธงเนเธฒ "เธซเธทเธญเนเน เธ•เธดเธ”เน€เธเธฒเธฐเธเธฐเนเธฅเนเธง"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'card_reveal' => [
        'name' => 'เน€เธชเธตเธขเธเน€เธเธดเธ”เธเธฒเธฃเนเธ” / เธชเธธเนเธกเน€เธ•เนเธฒเธ—เธตเธฅเธฐเนเธ ("เนเธเนเธ!")',
        'type' => 'sfx',
        'files' => ['card_zap.mp3'],
        'description' => 'เน€เธญเธเน€เธเธเธ•เนเน€เธชเธตเธขเธเน€เธเธดเธ”เธเธฒเธฃเนเธ”เธซเธฃเธทเธญเธชเธธเนเธกเน€เธ•เนเธฒเธ”เธฑเธ "เนเธเนเธ!" เธ•เนเธญเนเธ (เน€เธเนเธ 5 เนเธ = 5 เนเธเนเธ เธซเนเธฒเธเธเธฑเธเนเธเธฅเธฐ 1 เธงเธดเธเธฒเธ—เธต)',
        'volume' => 0.95,
        'enabled' => true,
        'interval_sec' => 1.0,
        'preset' => 'zap_classic'
    ],
    'card_reveal_rare' => [
        'name' => 'เน€เธชเธตเธขเธเน€เธเธดเธ”เนเธ”เนเธเธฒเธฃเนเธ”เนเธฃเธฃเน S / SS+ / เธเธดเธเธเธฃเธฃเธก ("เนเธเนเธ-เธญเธญเธฃเนเธฒ!")',
        'type' => 'sfx',
        'files' => ['card_zap_rare.mp3'],
        'description' => 'เน€เธญเธเน€เธเธเธ•เนเน€เธชเธตเธขเธเธญเธญเธฃเนเธฒเธเธดเน€เธจเธฉเน€เธกเธทเนเธญเน€เธเธดเธ”เนเธ”เนเธเธฒเธฃเนเธ”เธฃเธฐเธ”เธฑเธ S, SS+ เธซเธฃเธทเธญเธเธฒเธฃเนเธ”เธเธฑเธ”เธเธดเธเธเธฃเธฃเธก',
        'volume' => 1.0,
        'enabled' => true
    ],
        // ===== เสียงลำดับการทอย (Turn Order 1-4) =====
    'turn_order_1' => [
        'name' => 'เสียงได้ทอยเป็นคนแรก ("เย้! ได้ทอยเป็นคนแรก")',
        'type' => 'voice',
        'files' => ['0-_yo.mp3', 'yeay.mp3'],
        'description' => 'เสียงเด็กผู้หญิงดีใจเมื่อได้ทอยเป็นคนแรก (มือ 1)',
        'volume' => 1.0,
        'enabled' => true
    ],
    'turn_order_2' => [
        'name' => 'เสียงได้ทอยเป็นที่สอง ("ได้ทอยเป็นคนที่สอง")',
        'type' => 'voice',
        'files' => ['3-______________________________2.mp3'],
        'description' => 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สอง (มือ 2)',
        'volume' => 1.0,
        'enabled' => true
    ],
    'turn_order_3' => [
        'name' => 'เสียงได้ทอยเป็นที่สาม ("ได้ทอยเป็นคนที่สาม")',
        'type' => 'voice',
        'files' => ['4-______________________________3.mp3'],
        'description' => 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สาม (มือ 3)',
        'volume' => 1.0,
        'enabled' => true
    ],
    'turn_order_4' => [
        'name' => 'เสียงได้ทอยเป็นที่สี่ ("ได้ทอยเป็นคนที่สี่")',
        'type' => 'voice',
        'files' => ['5-______________________________4.mp3'],
        'description' => 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สี่ (มือ 4)',
        'volume' => 1.0,
        'enabled' => true
    ],
    // ===== เสียงเริ่มทอยตาคุณ =====
    'your_turn' => [
        'name' => 'เสียงเริ่มทอย ("ถึงตาคุณแล้ว ทอยเต๋าเลย!")',
        'type' => 'voice',
        'files' => ['3-.mp3'],
        'description' => 'เสียงเด็กผู้หญิงเตือนเมื่อถึงรอบตาของเราทอยลูกเต๋า',
        'volume' => 1.0,
        'enabled' => true
    ],
    // ===== เสียงจบเกมส์ =====
    'victory' => [
        'name' => 'เสียงจบเกมส์ - ชนะการแข่งขัน ("ชนะแล้ว เย้!")',
        'type' => 'voice',
        'files' => [],
        'description' => 'เสียงเด็กผู้หญิงแสดงความดีใจเมื่อชนะการแข่งขัน',
        'volume' => 1.0,
        'enabled' => true
    ],
    'game_over_lose' => [
        'name' => 'เสียงจบเกมส์ - แพ้การแข่งขัน ("แพ้ซะแล้ว!")',
        'type' => 'voice',
        'files' => ['game_over_lose_110620.mp3'],
        'description' => 'เสียงเด็กผู้หญิงบ่นเสียดายเมื่อแพ้การแข่งขันหรือโดนนำ',
        'volume' => 1.0,
        'enabled' => true
    ],
    'bankrupt' => [
        'name' => 'เสียงล้มละลาย ("แงๆ หมดตัวเลย")',
        'type' => 'voice',
        'files' => [],
        'description' => 'เสียงเด็กผู้หญิงร้องไห้เมื่อทองหมดตัวจนล้มละลาย',
        'volume' => 1.0,
        'enabled' => true
    ],
    // ===== เสียงเหตุการณ์ในกระดาน =====
    'buyout_city' => [
        'name' => 'เสียงเมื่อมีคนซื้อเมืองต่อ ("ซื้อเมืองต่อแล้วนะ!")',
        'type' => 'voice',
        'files' => ['buyout_city_110924.mp3'],
        'description' => 'เสียงพากย์เมื่อผู้เล่นซื้อเมืองต่อ (เทคโอเวอร์) จากคู่แข่ง',
        'volume' => 1.0,
        'enabled' => true
    ],
    'snake_bite' => [
        'name' => 'เสียงตกงู ร่วงลง ("ว้าย! ตกช่องงู ร่วงลงเลย")',
        'type' => 'voice',
        'files' => [],
        'description' => 'เสียงเด็กผู้หญิงร้องเมื่อตกช่องหัวงูและสไลด์ร่วงลงด้านล่าง',
        'volume' => 1.0,
        'enabled' => true
    ],
    'ladder_climb' => [
        'name' => 'เสียงตกบันได เลื่อนขึ้น ("เย้! ขึ้นบันไดลัด")',
        'type' => 'voice',
        'files' => [],
        'description' => 'เสียงเด็กผู้หญิงดีใจเมื่อตกช่องบันไดและไต่เลื่อนขึ้นด้านบน',
        'volume' => 1.0,
        'enabled' => true
    ],
    'build_landmark' => [
        'name' => 'เสียงสร้างแลนด์มาร์คสำเร็จ ("แลนด์มาร์คของฉัน!")',
        'type' => 'voice',
        'files' => ['build_landmark_111226.mp3'],
        'description' => 'เสียงเด็กผู้หญิงพูดเมื่อสร้างแลนด์มาร์คสำเร็จ',
        'volume' => 1.0,
        'enabled' => true
    ],
    'build_super_landmark' => [
        'name' => 'เสียงสร้างแลนด์มาร์ค Super ("ซุปเปอร์แลนด์มาร์ค!")',
        'type' => 'voice',
        'files' => ['build_super_landmark_112227.mp3'],
        'description' => 'เสียงเด็กผู้หญิงตื่นเต้นเมื่ออัปเกรดเป็นซุปเปอร์แลนด์มาร์ค (Super Landmark) ขั้นสูงสุด',
        'volume' => 1.0,
        'enabled' => true
    ],
    'build_city' => [
        'name' => 'เสียงสร้างเมือง ("สร้างเมืองละกัน")',
        'type' => 'voice',
        'files' => ['build_city_110924.mp3', 'mhm_สร้างเมืองละกัน.mp3'],
        'description' => 'เสียงเด็กผู้หญิงพูดเมื่อสร้างเมืองหรืออัปเกรดบ้านในช่องกระดาน ("สร้างเมืองละกัน")',
        'volume' => 1.0,
        'enabled' => true
    ]
];

$DEFAULT_BGM_CONFIG = [
    'lobby' => [
        'name' => 'เน€เธเธฅเธเน€เธเธดเธ”เน€เธเธกเธชเน เธฃเธฐเธซเธงเนเธฒเธเธฃเธญ (Lobby / Waiting BGM)',
        'file' => 'sound.mp3',
        'volume' => 0.25,
        'enabled' => true
    ],
    'gameplay' => [
        'name' => 'เน€เธเธฅเธเน€เธฅเนเธเน€เธเธกเธชเนเธ—เธฑเนเธงเนเธ (Default In-Game BGM)',
        'file' => 'ongame.mp3',
        'volume' => 0.20,
        'enabled' => true,
        'scope' => 'all', // 'all' เธซเธฃเธทเธญ 'selected'
        'selected_stages' => ['ancient', 'classic', 'lava', 'ice']
    ],
    'stages' => [
        // 'ancient' => ['file' => 'ongame.mp3', 'volume' => 0.20, 'enabled' => true]
    ]
];

function normalizeAudioEventsMap(array $events): array {
    $clean = [];
    foreach ($events as $k => $ev) {
        if ($k === '_schema_v' || !is_array($ev)) {
            continue;
        }
        $key = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim((string)$k));
        if ($key === '') {
            continue;
        }
        $files = [];
        if (isset($ev['files']) && is_array($ev['files'])) {
            foreach ($ev['files'] as $f) {
                $fStr = trim((string)$f);
                if ($fStr !== '' && !in_array($fStr, $files, true)) {
                    $files[] = $fStr;
                }
            }
        }
        $vol = isset($ev['volume']) ? (float)$ev['volume'] : 1.0;
        if ($vol < 0.0) $vol = 0.0;
        if ($vol > 1.0) $vol = 1.0;

        $item = [
            'name' => isset($ev['name']) && trim((string)$ev['name']) !== '' ? trim((string)$ev['name']) : $key,
            'type' => (isset($ev['type']) && $ev['type'] === 'sfx') ? 'sfx' : 'voice',
            'files' => $files,
            'description' => isset($ev['description']) ? trim((string)$ev['description']) : '',
            'volume' => round($vol, 2),
            'enabled' => isset($ev['enabled']) ? (bool)$ev['enabled'] : true
        ];

        if (isset($ev['interval_sec']) || $key === 'card_reveal') {
            $intSec = isset($ev['interval_sec']) ? (float)$ev['interval_sec'] : 1.0;
            if ($intSec < 0.08) $intSec = 0.08;
            if ($intSec > 3.0) $intSec = 3.0;
            $item['interval_sec'] = round($intSec, 2);
        }
        if (isset($ev['preset']) || $key === 'card_reveal') {
            $preset = isset($ev['preset']) && trim((string)$ev['preset']) !== '' ? trim((string)$ev['preset']) : 'zap_classic';
            $item['preset'] = $preset;
        }

        $clean[$key] = $item;
    }
    return $clean;
}

function ensureCardRevealDefaults(array $events, array $defaultEvents): array {
    foreach ($defaultEvents as $reqKey => $defVal) {
        if (!isset($events[$reqKey])) {
            $events[$reqKey] = $defVal;
        } else if (empty($events[$reqKey]['files']) && !empty($defVal['files'])) {
            $events[$reqKey]['files'] = $defVal['files'];
            $events[$reqKey]['enabled'] = true;
        }
    }
    return $events;
}

function getAudioFallbackJsonPath(): string {
    return __DIR__ . '/../config/thai_audio_events.json';
}

function getAudioFallbackBgmJsonPath(): string {
    return __DIR__ . '/../config/game_bgm_config.json';
}

function normalizeBgmConfig(array $cfg, array $defaultBgm): array {
    $res = $defaultBgm;
    if (isset($cfg['lobby']) && is_array($cfg['lobby'])) {
        $res['lobby']['name'] = isset($cfg['lobby']['name']) ? trim((string)$cfg['lobby']['name']) : $defaultBgm['lobby']['name'];
        $res['lobby']['file'] = isset($cfg['lobby']['file']) ? trim((string)$cfg['lobby']['file']) : $defaultBgm['lobby']['file'];
        $res['lobby']['volume'] = isset($cfg['lobby']['volume']) ? max(0.0, min(1.0, (float)$cfg['lobby']['volume'])) : $defaultBgm['lobby']['volume'];
        $res['lobby']['enabled'] = isset($cfg['lobby']['enabled']) ? (bool)$cfg['lobby']['enabled'] : $defaultBgm['lobby']['enabled'];
    }
    if (isset($cfg['gameplay']) && is_array($cfg['gameplay'])) {
        $res['gameplay']['name'] = isset($cfg['gameplay']['name']) ? trim((string)$cfg['gameplay']['name']) : $defaultBgm['gameplay']['name'];
        $res['gameplay']['file'] = isset($cfg['gameplay']['file']) ? trim((string)$cfg['gameplay']['file']) : $defaultBgm['gameplay']['file'];
        $res['gameplay']['volume'] = isset($cfg['gameplay']['volume']) ? max(0.0, min(1.0, (float)$cfg['gameplay']['volume'])) : $defaultBgm['gameplay']['volume'];
        $res['gameplay']['enabled'] = isset($cfg['gameplay']['enabled']) ? (bool)$cfg['gameplay']['enabled'] : $defaultBgm['gameplay']['enabled'];
        $res['gameplay']['scope'] = (isset($cfg['gameplay']['scope']) && $cfg['gameplay']['scope'] === 'selected') ? 'selected' : 'all';
        $res['gameplay']['selected_stages'] = isset($cfg['gameplay']['selected_stages']) && is_array($cfg['gameplay']['selected_stages']) ? array_values(array_unique(array_filter(array_map('strval', $cfg['gameplay']['selected_stages'])))) : ['ancient', 'classic', 'lava', 'ice'];
    }
    if (isset($cfg['stages']) && is_array($cfg['stages'])) {
        $res['stages'] = [];
        foreach ($cfg['stages'] as $stKey => $stVal) {
            if (!is_array($stVal)) continue;
            $safeKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim((string)$stKey));
            if ($safeKey === '') continue;
            $res['stages'][$safeKey] = [
                'file' => isset($stVal['file']) ? trim((string)$stVal['file']) : '',
                'volume' => isset($stVal['volume']) ? max(0.0, min(1.0, (float)$stVal['volume'])) : 0.45,
                'enabled' => isset($stVal['enabled']) ? (bool)$stVal['enabled'] : true
            ];
        }
    }
    return $res;
}

function getStoredBgmConfig($db, array $defaultBgm): array {
    try {
        $stmt = $db->prepare("SELECT setting_value FROM game_settings WHERE setting_key = 'game_bgm_config_json' LIMIT 1");
        if ($stmt) {
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $decoded = json_decode(isset($row['setting_value']) ? (string)$row['setting_value'] : '', true);
                if (is_array($decoded)) {
                    $stmt->close();
                    return normalizeBgmConfig($decoded, $defaultBgm);
                }
            }
            $stmt->close();
        }
    } catch (Throwable $e) {}

    $jsonPath = getAudioFallbackBgmJsonPath();
    if (@is_file($jsonPath)) {
        $raw = @file_get_contents($jsonPath);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            return normalizeBgmConfig($decoded, $defaultBgm);
        }
    }
    return $defaultBgm;
}

function persistBgmConfig($db, array $bgmConfig, array $defaultBgm): array {
    $clean = normalizeBgmConfig($bgmConfig, $defaultBgm);
    $jsonStr = json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    $jsonPath = getAudioFallbackBgmJsonPath();
    $dir = dirname($jsonPath);
    if (!@is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($jsonPath, $jsonStr);

    try {
        $stmt = $db->prepare("INSERT INTO game_settings (setting_key, setting_value, category, description, updated_at) VALUES ('game_bgm_config_json', ?, 'audio', 'เธเธฒเธฃเธ•เธฑเนเธเธเนเธฒเน€เธเธฅเธเน€เธเธดเธ”เน€เธเธกเธชเนเนเธฅเธฐเน€เธเธฅเธเน€เธฅเนเธเน€เธเธกเธชเน', NOW()) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()");
        if ($stmt) {
            $stmt->bind_param('s', $jsonStr);
            $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        try {
            $stmt2 = $db->prepare("INSERT INTO game_settings (setting_key, setting_value) VALUES ('game_bgm_config_json', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            if ($stmt2) {
                $stmt2->bind_param('s', $jsonStr);
                $stmt2->execute();
                $stmt2->close();
            }
        } catch (Throwable $e2) {}
    }

    return $clean;
}

function getStoredAudioState($db, array $defaultEvents): array {
    $updatedAt = time();
    try {
        $stmt = $db->prepare("SELECT setting_value, UNIX_TIMESTAMP(updated_at) AS ts FROM game_settings WHERE setting_key = 'thai_audio_events_json' LIMIT 1");
        if ($stmt) {
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                if (!empty($row['ts'])) {
                    $updatedAt = (int)$row['ts'];
                }
                $decoded = json_decode(isset($row['setting_value']) ? (string)$row['setting_value'] : '', true);
                if (is_array($decoded)) {
                    if (empty($decoded['_schema_v']) && isset($decoded['game_start']) && !isset($decoded['malei'])) {
                        $migrated = $defaultEvents;
                        foreach ($decoded as $k => $v) {
                            if ($k === 'game_start' || !is_array($v)) {
                                continue;
                            }
                            $migrated[$k] = array_merge(isset($migrated[$k]) ? $migrated[$k] : [], $v);
                        }
                        $stmt->close();
                        return [
                            'events' => normalizeAudioEventsMap(ensureCardRevealDefaults($migrated, $defaultEvents)),
                            'updatedAt' => $updatedAt
                        ];
                    }

                    $events = normalizeAudioEventsMap(ensureCardRevealDefaults($decoded, $defaultEvents));
                    $stmt->close();
                    return [
                        'events' => $events,
                        'updatedAt' => $updatedAt
                    ];
                }
            }
            $stmt->close();
        }
    } catch (Throwable $e) {
        // Fallback to JSON file or defaults
    }

    $jsonPath = getAudioFallbackJsonPath();
    if (@is_file($jsonPath)) {
        $rawJson = @file_get_contents($jsonPath);
        $decodedFile = is_string($rawJson) ? json_decode($rawJson, true) : null;
        if (is_array($decodedFile)) {
            $mtime = @filemtime($jsonPath);
            return [
                'events' => normalizeAudioEventsMap(ensureCardRevealDefaults($decodedFile, $defaultEvents)),
                'updatedAt' => $mtime ? (int)$mtime : $updatedAt
            ];
        }
    }

    return [
        'events' => normalizeAudioEventsMap($defaultEvents),
        'updatedAt' => $updatedAt
    ];
}

function persistAudioEvents($db, array $events): array {
    $cleanEvents = normalizeAudioEventsMap($events);
    $payloadToStore = $cleanEvents;
    $payloadToStore['_schema_v'] = 2;

    $jsonStr = json_encode($payloadToStore, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    $jsonPath = getAudioFallbackJsonPath();
    $cfgDir = dirname($jsonPath);
    if (!@is_dir($cfgDir)) {
        @mkdir($cfgDir, 0775, true);
    }
    @file_put_contents($jsonPath, $jsonStr);

    $savedDb = false;
    try {
        $stmt = $db->prepare("INSERT INTO game_settings (setting_key, setting_value, category, description, updated_at) VALUES ('thai_audio_events_json', ?, 'audio', 'เธฃเธฒเธขเธเธฒเธฃเน€เธชเธตเธขเธเธเธฒเธเธขเนเนเธฅเธฐ SFX เธ เธฒเธฉเธฒเนเธ—เธข', NOW()) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()");
        if ($stmt) {
            $stmt->bind_param('s', $jsonStr);
            $savedDb = $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        $savedDb = false;
    }

    if (!$savedDb) {
        try {
            $stmt2 = $db->prepare("INSERT INTO game_settings (setting_key, setting_value) VALUES ('thai_audio_events_json', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            if ($stmt2) {
                $stmt2->bind_param('s', $jsonStr);
                $savedDb = $stmt2->execute();
                $stmt2->close();
            }
        } catch (Throwable $e2) {
            // JSON mirror file already saved above
        }
    }

    return $cleanEvents;
}

if ($action === 'get_config') {
    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $bgmConfig = getStoredBgmConfig($db, $DEFAULT_BGM_CONFIG);
    echo json_encode([
        'status' => 'success',
        'basePath' => 'assets/audio/th/',
        'updatedAt' => $state['updatedAt'],
        'events' => $state['events'],
        'bgm_config' => $bgmConfig
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'get_bgm_config') {
    $bgmConfig = getStoredBgmConfig($db, $DEFAULT_BGM_CONFIG);
    echo json_encode([
        'status' => 'success',
        'bgm_config' => $bgmConfig,
        'basePath' => 'assets/audio/th/'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_bgm_config') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['bgm_config']) || !is_array($data['bgm_config'])) {
        echo json_encode(['status' => 'error', 'message' => 'เธเนเธญเธกเธนเธฅ bgm_config เนเธกเนเธ–เธนเธเธ•เนเธญเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    try {
        $saved = persistBgmConfig($db, $data['bgm_config'], $DEFAULT_BGM_CONFIG);
        echo json_encode([
            'status' => 'success',
            'message' => 'เธเธฑเธเธ—เธถเธเธเธฒเธฃเธ•เธฑเนเธเธเนเธฒเน€เธเธฅเธเน€เธเธดเธ”เน€เธเธกเธชเนเนเธฅเธฐเน€เธเธฅเธเน€เธฅเนเธเน€เธเธกเธชเนเธชเธณเน€เธฃเนเธเน€เธฃเธตเธขเธเธฃเนเธญเธข!',
            'bgm_config' => $saved
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”เนเธเธเธฒเธฃเธเธฑเธเธ—เธถเธ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'list_audio_files') {
    $audioDir = __DIR__ . '/../assets/audio/th/';
    $filesList = [];
    if (@is_dir($audioDir)) {
        $items = @scandir($audioDir) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
            if (in_array($ext, ['mp3', 'wav', 'ogg', 'm4a'], true)) {
                $fullPath = $audioDir . $item;
                $sizeBytes = @filesize($fullPath) ?: 0;
                $filesList[] = [
                    'filename' => $item,
                    'size_bytes' => $sizeBytes,
                    'size_fmt' => ($sizeBytes >= 1048576) ? round($sizeBytes / 1048576, 2) . ' MB' : round($sizeBytes / 1024, 1) . ' KB',
                    'ext' => $ext,
                    'path' => 'assets/audio/th/' . $item
                ];
            }
        }
    }
    // Sort files alphabetically
    usort($filesList, fn($a, $b) => strcasecmp($a['filename'], $b['filename']));
    echo json_encode([
        'status' => 'success',
        'files' => $filesList
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'get_stages_list') {
    $stages = [
        ['code' => 'ancient', 'name' => '๐๏ธ เธงเธดเธซเธฒเธฃเธ—เธญเธเธเธณเธเธเธฒเธเธฒเธเธฃเธฒเธ (Ancient Temple)', 'type' => 'builtin'],
        ['code' => 'classic', 'name' => '๐ฒ เธเธฃเธฐเธ”เธฒเธเธเธฅเธฒเธชเธชเธดเธ (Classic Board)', 'type' => 'builtin'],
        ['code' => 'lava',    'name' => '๐ เธฅเธฒเธงเธฒเธ เธนเน€เธเธฒเนเธ (Lava Volcano)', 'type' => 'builtin'],
        ['code' => 'ice',     'name' => 'โ๏ธ เธเนเธณเนเธเนเธเธซเธดเธกเธฐเน€เธขเธทเธญเธเนเธเนเธ (Ice Frozen)', 'type' => 'builtin']
    ];
    try {
        $res = $db->query("SELECT id, board_code, board_name, theme_config_json FROM custom_boards WHERE is_active = 1 ORDER BY is_default DESC, id DESC");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $thCfg = json_decode((string)($row['theme_config_json'] ?? '{}'), true) ?: [];
                $stages[] = [
                    'code' => (string)$row['board_code'],
                    'name' => '๐—บ๏ธ ' . (string)$row['board_name'],
                    'type' => 'custom',
                    'bgm_file' => (string)($thCfg['bgm_file'] ?? ''),
                    'bgm_volume' => isset($thCfg['bgm_volume']) ? (float)$thCfg['bgm_volume'] : 0.45
                ];
            }
        }
    } catch (Throwable $e) {}

    echo json_encode([
        'status' => 'success',
        'stages' => $stages
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'upload_audio') {
    @ini_set('upload_max_filesize', '64M');
    @ini_set('post_max_size', '64M');
    @ini_set('memory_limit', '256M');

    $eventKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($_POST['event_key']) ? (string)$_POST['event_key'] : ''));
    $customName = trim(isset($_POST['custom_name']) ? (string)$_POST['custom_name'] : '');
    $uploadMode = isset($_POST['mode']) && $_POST['mode'] === 'append' ? 'append' : 'replace';

    $primaryDir = __DIR__ . '/../assets/audio/th/';
    if (!@is_dir($primaryDir)) {
        @mkdir($primaryDir, 0777, true);
    }

    $uploadedPrimary = false;
    $finalFilename = '';

    // วิธีที่ 1: ตรวจสอบการส่งไฟล์แบบ Multipart Form-Data ปกติ ($_FILES)
    if (!empty($_FILES['audio_file']) && !empty($_FILES['audio_file']['tmp_name'])) {
        $file = $_FILES['audio_file'];
        if (!empty($file['error']) && (int)$file['error'] !== UPLOAD_ERR_OK) {
            $errCode = (int)$file['error'];
            $errMsg = "อัปโหลดไฟล์ไม่สำเร็จ (Error Code: {$errCode})";
            if ($errCode === UPLOAD_ERR_INI_SIZE || $errCode === UPLOAD_ERR_FORM_SIZE) {
                $errMsg = "ไฟล์มีขนาดใหญ่เกินกว่าที่เซิร์ฟเวอร์กำหนด (จำกัด 64 MB)";
            } elseif ($errCode === UPLOAD_ERR_PARTIAL) {
                $errMsg = "อัปโหลดไฟล์มาไม่ครบ กรุณาลองใหม่อีกครั้ง";
            } elseif ($errCode === UPLOAD_ERR_NO_TMP_DIR) {
                $errMsg = "เซิร์ฟเวอร์ไม่มีโฟลเดอร์ Temp สำหรับพักไฟล์";
            } elseif ($errCode === UPLOAD_ERR_CANT_WRITE) {
                $errMsg = "ไม่สามารถเขียนไฟล์ลงดิสก์เซิร์ฟเวอร์ได้";
            }
            echo json_encode(['status' => 'error', 'message' => $errMsg], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac'], true)) {
            echo json_encode(['status' => 'error', 'message' => 'รองรับเฉพาะไฟล์เสียง .mp3, .wav, .ogg, .m4a เท่านั้น'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $rawBase = $customName !== '' ? $customName : pathinfo((string)$file['name'], PATHINFO_FILENAME);
        $safeBase = preg_replace('/[^\p{Thai}a-zA-Z0-9_\-]/u', '_', $rawBase);
        $safeBase = trim((string)$safeBase, '_');
        if ($safeBase === '') {
            $safeBase = ($eventKey !== '' ? $eventKey : 'thai_voice') . '_' . date('His');
        }
        $finalFilename = $safeBase . '.' . $ext;
        $primaryDest = $primaryDir . $finalFilename;

        if (function_exists('is_uploaded_file') && @is_uploaded_file($file['tmp_name'])) {
            $uploadedPrimary = @move_uploaded_file($file['tmp_name'], $primaryDest);
        }
        if (!$uploadedPrimary) {
            $uploadedPrimary = @copy($file['tmp_name'], $primaryDest);
        }
    }
    // วิธีที่ 2: รองรับกรณีส่งเป็น Base64 Data URL ผ่าน POST (เพื่อ Bypass ขีดจำกัด $_FILES)
    elseif (!empty($_POST['audio_base64']) || !empty($_POST['audio_data'])) {
        $rawBase64 = (string)(!empty($_POST['audio_base64']) ? $_POST['audio_base64'] : $_POST['audio_data']);
        $ext = 'mp3';
        if (preg_match('/^data:audio\/([a-zA-Z0-9]+);base64,/', $rawBase64, $m)) {
            $ext = strtolower($m[1]);
            if ($ext === 'mpeg') $ext = 'mp3';
            if ($ext === 'x-wav') $ext = 'wav';
            $rawBase64 = substr($rawBase64, strpos($rawBase64, ',') + 1);
        }
        if (!in_array($ext, ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac'], true)) {
            $ext = 'mp3';
        }

        $binary = base64_decode($rawBase64);
        if ($binary !== false && strlen($binary) > 0) {
            $rawBase = $customName !== '' ? $customName : (!empty($_POST['file_name']) ? pathinfo((string)$_POST['file_name'], PATHINFO_FILENAME) : '');
            $safeBase = preg_replace('/[^\p{Thai}a-zA-Z0-9_\-]/u', '_', $rawBase);
            $safeBase = trim((string)$safeBase, '_');
            if ($safeBase === '') {
                $safeBase = ($eventKey !== '' ? $eventKey : 'thai_voice') . '_' . date('His');
            }
            $finalFilename = $safeBase . '.' . $ext;
            $primaryDest = $primaryDir . $finalFilename;
            $uploadedPrimary = (@file_put_contents($primaryDest, $binary) !== false);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไฟล์เสียงที่อัปโหลด หรือไฟล์มีขนาดใหญ่เกินกำหนด (จำกัด 64 MB)'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!$uploadedPrimary || empty($finalFilename)) {
        echo json_encode(['status' => 'error', 'message' => 'บันทึกไฟล์ลงเซิร์ฟเวอร์ไม่สำเร็จ กรุณาตรวจสอบสิทธิ์โฟลเดอร์ assets/audio/th/ หรือพื้นที่ว่าง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $mirrorDirs = [
        __DIR__ . '/../www/assets/audio/th/',
        __DIR__ . '/../dist/assets/audio/th/',
        __DIR__ . '/../ios/App/App/public/assets/audio/th/'
    ];
    foreach ($mirrorDirs as $mDir) {
        if (!@is_dir($mDir)) {
            @mkdir($mDir, 0777, true);
        }
        if (@is_dir($mDir)) {
            @copy($primaryDest, $mDir . $finalFilename);
        }
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    if ($eventKey !== '') {
        if (!isset($events[$eventKey])) {
            $events[$eventKey] = [
                'name' => isset($_POST['event_name']) && trim((string)$_POST['event_name']) !== '' ? trim((string)$_POST['event_name']) : $eventKey,
                'type' => (isset($_POST['event_type']) && $_POST['event_type'] === 'sfx') ? 'sfx' : 'voice',
                'files' => [$finalFilename],
                'description' => isset($_POST['event_desc']) ? trim((string)$_POST['event_desc']) : '',
                'volume' => isset($_POST['event_volume']) ? (float)$_POST['event_volume'] : 1.0,
                'enabled' => isset($_POST['event_enabled']) ? ((string)$_POST['event_enabled'] !== '0' && (string)$_POST['event_enabled'] !== 'false') : true
            ];
        } else {
            if ($uploadMode === 'replace') {
                $events[$eventKey]['files'] = [$finalFilename];
            } else {
                if (!in_array($finalFilename, $events[$eventKey]['files'], true)) {
                    $events[$eventKey]['files'][] = $finalFilename;
                }
            }
            if (isset($_POST['event_name']) && trim((string)$_POST['event_name']) !== '') {
                $events[$eventKey]['name'] = trim((string)$_POST['event_name']);
            }
            if (isset($_POST['event_desc'])) {
                $events[$eventKey]['description'] = trim((string)$_POST['event_desc']);
            }
            if (isset($_POST['event_type'])) {
                $events[$eventKey]['type'] = ($_POST['event_type'] === 'sfx') ? 'sfx' : 'voice';
            }
            if (isset($_POST['event_volume'])) {
                $events[$eventKey]['volume'] = (float)$_POST['event_volume'];
            }
            if ($eventKey === 'card_reveal') {
                $events[$eventKey]['preset'] = 'custom_file';
            }
        }

        try {
            $events = persistAudioEvents($db, $events);
        } catch (Throwable $e) {
            echo json_encode(['status' => 'error', 'message' => 'อัปโหลดไฟล์สำเร็จ แต่บันทึกฐานข้อมูลไม่สำเร็จ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    echo json_encode([
        'status' => 'success',
        'message' => "อัปโหลดไฟล์เสียง {$finalFilename} สำเร็จเรียบร้อย!",
        'filename' => $finalFilename,
        'path' => 'assets/audio/th/' . $finalFilename,
        'updatedAt' => time(),
        'events' => $events
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        echo json_encode(['status' => 'error', 'message' => 'เธเนเธญเธกเธนเธฅ JSON เนเธกเนเธ–เธนเธเธ•เนเธญเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $origKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($data['orig_key']) ? (string)$data['orig_key'] : ''));
    $eventKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($data['event_key']) ? (string)$data['event_key'] : ''));
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'เธเธฃเธธเธ“เธฒเธฃเธฐเธเธธเธฃเธซเธฑเธชเน€เธซเธ•เธธเธเธฒเธฃเธ“เน (Event Key) เน€เธเนเธ malei, victory, step_1'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    if ($origKey !== '' && $origKey !== $eventKey && isset($events[$origKey])) {
        unset($events[$origKey]);
    }

    $existingItem = isset($events[$eventKey]) && is_array($events[$eventKey]) ? $events[$eventKey] : [];
    $existingFiles = isset($existingItem['files']) ? $existingItem['files'] : [];
    $files = isset($data['files']) && is_array($data['files']) ? $data['files'] : $existingFiles;

    $newItem = [
        'name' => isset($data['name']) && trim((string)$data['name']) !== '' ? trim((string)$data['name']) : $eventKey,
        'type' => (isset($data['type']) && $data['type'] === 'sfx') ? 'sfx' : 'voice',
        'files' => $files,
        'description' => isset($data['description']) ? trim((string)$data['description']) : '',
        'volume' => isset($data['volume']) ? (float)$data['volume'] : 1.0,
        'enabled' => isset($data['enabled']) ? (bool)$data['enabled'] : true
    ];
    if (isset($data['interval_sec']) || isset($existingItem['interval_sec']) || $eventKey === 'card_reveal') {
        $newItem['interval_sec'] = isset($data['interval_sec']) ? (float)$data['interval_sec'] : (isset($existingItem['interval_sec']) ? (float)$existingItem['interval_sec'] : 1.0);
    }
    if (isset($data['preset']) || isset($existingItem['preset']) || $eventKey === 'card_reveal') {
        $newItem['preset'] = isset($data['preset']) ? (string)$data['preset'] : (isset($existingItem['preset']) ? (string)$existingItem['preset'] : 'zap_classic');
    }
    $events[$eventKey] = $newItem;

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "เธเธฑเธเธ—เธถเธเน€เธซเธ•เธธเธเธฒเธฃเธ“เนเน€เธชเธตเธขเธ '{$eventKey}' เธชเธณเน€เธฃเนเธ!",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'save_card_reveal_config') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        echo json_encode(['status' => 'error', 'message' => 'เธเนเธญเธกเธนเธฅ JSON เนเธกเนเธ–เธนเธเธ•เนเธญเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    $curReveal = isset($events['card_reveal']) && is_array($events['card_reveal']) ? $events['card_reveal'] : $DEFAULT_EVENTS['card_reveal'];
    $curRare = isset($events['card_reveal_rare']) && is_array($events['card_reveal_rare']) ? $events['card_reveal_rare'] : $DEFAULT_EVENTS['card_reveal_rare'];

    $preset = isset($data['preset']) && trim((string)$data['preset']) !== '' ? trim((string)$data['preset']) : ($curReveal['preset'] ?? 'zap_classic');
    $intervalSec = isset($data['interval_sec']) ? (float)$data['interval_sec'] : (float)($curReveal['interval_sec'] ?? 1.0);
    if ($intervalSec < 0.08) $intervalSec = 0.08;
    if ($intervalSec > 3.0) $intervalSec = 3.0;

    $vol = isset($data['volume']) ? (float)$data['volume'] : (float)($curReveal['volume'] ?? 0.95);
    $enabled = isset($data['enabled']) ? (bool)$data['enabled'] : (bool)($curReveal['enabled'] ?? true);
    $rareEnabled = isset($data['rare_enabled']) ? (bool)$data['rare_enabled'] : (bool)($curRare['enabled'] ?? true);

    $presetFileMap = [
        'zap_classic' => 'card_zap.mp3',
        'zap_magic'   => 'card_zap_magic.mp3',
        'card_whip'   => 'card_whip.mp3',
        'coin_ping'   => 'card_crystal.mp3'
    ];

    $files = isset($data['files']) && is_array($data['files']) && count($data['files']) > 0
        ? $data['files']
        : (isset($presetFileMap[$preset]) ? [$presetFileMap[$preset]] : ($curReveal['files'] ?? ['card_zap.mp3']));

    $events['card_reveal'] = [
        'name' => $curReveal['name'] ?? 'เน€เธชเธตเธขเธเน€เธเธดเธ”เธเธฒเธฃเนเธ” / เธชเธธเนเธกเน€เธ•เนเธฒเธ—เธตเธฅเธฐเนเธ ("เนเธเนเธ!")',
        'type' => 'sfx',
        'files' => $files,
        'description' => "เน€เธญเธเน€เธเธเธ•เนเน€เธชเธตเธขเธเน€เธเธดเธ”เธเธฒเธฃเนเธ”เธซเธฃเธทเธญเธชเธธเนเธกเน€เธ•เนเธฒเธ”เธฑเธ เนเธเนเธ! เธ•เนเธญเนเธ (เธซเนเธฒเธเธเธฑเธเนเธเธฅเธฐ {$intervalSec} เธงเธดเธเธฒเธ—เธต)",
        'volume' => $vol,
        'enabled' => $enabled,
        'interval_sec' => round($intervalSec, 2),
        'preset' => $preset
    ];

    $events['card_reveal_rare'] = [
        'name' => $curRare['name'] ?? 'เน€เธชเธตเธขเธเน€เธเธดเธ”เนเธ”เนเธเธฒเธฃเนเธ”เนเธฃเธฃเน S / SS+ / เธเธดเธเธเธฃเธฃเธก ("เนเธเนเธ-เธญเธญเธฃเนเธฒ!")',
        'type' => 'sfx',
        'files' => $curRare['files'] ?? ['card_zap_rare.mp3'],
        'description' => $curRare['description'] ?? 'เน€เธญเธเน€เธเธเธ•เนเน€เธชเธตเธขเธเธญเธญเธฃเนเธฒเธเธดเน€เธจเธฉเน€เธกเธทเนเธญเน€เธเธดเธ”เนเธ”เนเธเธฒเธฃเนเธ”เธฃเธฐเธ”เธฑเธ S, SS+ เธซเธฃเธทเธญเธเธฒเธฃเนเธ”เธเธฑเธ”เธเธดเธเธเธฃเธฃเธก',
        'volume' => isset($data['rare_volume']) ? (float)$data['rare_volume'] : (float)($curRare['volume'] ?? 1.0),
        'enabled' => $rareEnabled
    ];

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "เธเธฑเธเธ—เธถเธเธ•เธฑเนเธเธเนเธฒเน€เธชเธตเธขเธเน€เธเธดเธ”เธเธฒเธฃเนเธ”/เธชเธธเนเธกเน€เธ•เนเธฒ (เธซเนเธฒเธเธเธฑเธเนเธเธฅเธฐ {$intervalSec} เธงเธด) เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง!",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'toggle_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    $eventKey = is_array($data) && isset($data['event_key']) ? trim((string)$data['event_key']) : '';
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'เนเธกเนเธเธเธฃเธซเธฑเธชเน€เธซเธ•เธธเธเธฒเธฃเธ“เนเน€เธชเธตเธขเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    if (!isset($events[$eventKey])) {
        echo json_encode(['status' => 'error', 'message' => 'เนเธกเนเธเธเธฃเธฒเธขเธเธฒเธฃเน€เธชเธตเธขเธเธ—เธตเนเธ•เนเธญเธเธเธฒเธฃเน€เธเธดเธ”/เธเธดเธ”'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $events[$eventKey]['enabled'] = isset($data['enabled']) ? (bool)$data['enabled'] : !$events[$eventKey]['enabled'];

    try {
        $events = persistAudioEvents($db, $events);
        $statusTxt = $events[$eventKey]['enabled'] ? 'เน€เธเธดเธ”เนเธเนเธเธฒเธ' : 'เธเธดเธ”เน€เธชเธตเธขเธ';
        echo json_encode([
            'status' => 'success',
            'message' => "{$statusTxt} '{$events[$eventKey]['name']}' เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'delete_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    $eventKey = is_array($data) && isset($data['event_key']) ? trim((string)$data['event_key']) : '';
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'เนเธกเนเธเธเธฃเธซเธฑเธชเน€เธซเธ•เธธเธเธฒเธฃเธ“เนเน€เธชเธตเธขเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    if (!isset($events[$eventKey])) {
        echo json_encode(['status' => 'error', 'message' => 'เนเธกเนเธเธเธฃเธฒเธขเธเธฒเธฃเน€เธชเธตเธขเธเธ—เธตเนเธ•เนเธญเธเธเธฒเธฃเธฅเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $deletedName = $events[$eventKey]['name'];
    unset($events[$eventKey]);

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "เธฅเธเธฃเธฒเธขเธเธฒเธฃเน€เธชเธตเธขเธ '{$deletedName}' เน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'reset_defaults') {
    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    foreach ($DEFAULT_EVENTS as $defKey => $defVal) {
        $events[$defKey] = $defVal;
    }
    $ordered = [];
    foreach ($DEFAULT_EVENTS as $defKey => $defVal) {
        $ordered[$defKey] = $events[$defKey];
    }
    foreach ($events as $k => $v) {
        if (!isset($ordered[$k])) {
            $ordered[$k] = $v;
        }
    }

    try {
        $saved = persistAudioEvents($db, $ordered);
        echo json_encode([
            'status' => 'success',
            'message' => 'เธเธทเธเธเนเธฒเธฃเธฒเธขเธเธฒเธฃเน€เธชเธตเธขเธเน€เธฃเธดเนเธกเธ•เนเธเธเธฃเธเธ—เธธเธเธฃเธฒเธขเธเธฒเธฃเน€เธฃเธตเธขเธเธฃเนเธญเธขเนเธฅเนเธง!',
            'updatedAt' => time(),
            'events' => $saved
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'save_events') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['events']) || !is_array($data['events'])) {
        echo json_encode(['status' => 'error', 'message' => 'เธเนเธญเธกเธนเธฅ events เนเธกเนเธ–เธนเธเธ•เนเธญเธ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $events = persistAudioEvents($db, $data['events']);
        echo json_encode([
            'status' => 'success',
            'message' => 'เธเธฑเธเธ—เธถเธเธเธฒเธฃเธ•เธฑเนเธเธเนเธฒเธฃเธฐเธเธเน€เธชเธตเธขเธเธ เธฒเธฉเธฒเนเธ—เธขเธชเธณเน€เธฃเนเธ!',
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เน€เธเธดเธ”เธเนเธญเธเธดเธ”เธเธฅเธฒเธ”เนเธเธเธฒเธฃเธเธฑเธเธ—เธถเธ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
