<?php
declare(strict_types=1);

/**
 * api/board_studio_service.php
 * ระบบจัดการกระดาน 3D ด้วย AI (AI 3D Board Studio & Custom Board Manager)
 * รองรับ:
 *  - สร้างกระดาน 3D จากรูปภาพด้วย AI (สีพื้น, สีบล็อกคู่/คี่, สีขอบนีออน, แสงไฟ, เท็กซ์เจอร์พื้นหลัง)
 *  - กำหนดรูปทรงกระดาน: สี่เหลี่ยมผืนผ้า (Rectangle), สี่เหลี่ยมจัตุรัส (Square), ก้นหอย (Spiral), หกเหลี่ยม (Hexagon), วงแหวน/เพชร (Diamond/Oval)
 *  - กำหนดจำนวนช่องและขนาดกระดาน (Grid Cols x Rows เช่น 10x10=100, 12x8=96, 15x6=90, 8x8=64 ฯลฯ)
 *  - จัดการชื่อเมืองทุกช่อง (ให้ AI ตั้งชื่อตามธีมอัตโนมัติ หรือแก้ไขรายช่องได้)
 *  - กำหนดตำแหน่งและจำนวนช่องพิเศษ: การ์ดดวง (Chance), ภาษี (Tax), เสี่ยงโชค (Gamble), ลบเมือง (Destroy), เกาะร้าง/คุก (Jail), บันได (Ladders), งู (Snakes)
 *  - ตั้งค่าเอฟเฟกต์ 3D ของกระดาน (หมอก, ละอองแสง, ความสว่าง, เด้งเมื่อเดินผ่าน, ความเร็วหมุน)
 *  - ตั้งค่าตำแหน่งปุ่มทอยลูกเต๋า (Roll Button & Dice Station Position) บนหน้ากระดานได้อิสระ
 *  - เปิดใช้งานเป็นกระดานเล่นได้ทันที (Active Playable Board) หรือยกเลิก/ปิดใช้งานได้ทันที
 */

function ensureCustomBoardsTable(mysqli $db): void {
    static $ensured = false;
    if ($ensured) return;
    $ensured = true;

    $db->query("
        CREATE TABLE IF NOT EXISTS `custom_boards` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `board_code` VARCHAR(64) NOT NULL,
            `board_name` VARCHAR(160) NOT NULL DEFAULT 'กระดาน AI 3D ใหม่',
            `description` TEXT NULL,
            `shape_type` VARCHAR(40) NOT NULL DEFAULT 'rectangle' COMMENT 'rectangle, square, spiral, hexagon, diamond_ring',
            `grid_cols` INT NOT NULL DEFAULT 12 COMMENT 'จำนวนคอลัมน์แนวกว้าง',
            `grid_rows` INT NOT NULL DEFAULT 8 COMMENT 'จำนวนแถวแนวลึก',
            `total_tiles` INT NOT NULL DEFAULT 96 COMMENT 'จำนวนช่องทั้งหมดบนกระดาน',
            `tile_size` DECIMAL(5,2) NOT NULL DEFAULT 6.20,
            `tile_gap` DECIMAL(5,2) NOT NULL DEFAULT 0.40,
            `source_image_url` LONGTEXT NULL COMMENT 'รูปภาพต้นฉบับที่ใช้วิเคราะห์ด้วย AI หรือใช้เป็นพื้นกระดาน',
            `apply_board_texture` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'แสดงรูปภาพเป็นลวดลายพื้นกระดาน 3D',
            `theme_config_json` LONGTEXT NULL COMMENT 'สีพื้นหลัง, สีช่องคู่/คี่, สีขอบ, สีบันได, สีงู, แสงไฟ',
            `cities_json` LONGTEXT NULL COMMENT 'ชื่อเมืองแต่ละช่อง {1: ..., 2: ...}',
            `special_tiles_json` LONGTEXT NULL COMMENT 'ตำแหน่งการ์ดดวง, ภาษี, เสี่ยงโชค, ลบเมือง, คุก, บันได, งู',
            `effects_json` LONGTEXT NULL COMMENT 'ตั้งค่าเอฟเฟกต์กระดาน 3D (particle, fog, bloom, step_pop, aura)',
            `roll_btn_config_json` LONGTEXT NULL COMMENT 'ตำแหน่งปุ่มทอยลูกเต๋าและขนาดบนกระดาน',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=เปิดให้ผู้เล่นเลือกเล่นได้, 0=ยกเลิก/ซ่อน',
            `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=ใช้เป็นกระดานหลักทันทีเมื่อเข้าเกม',
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_board_code` (`board_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Seed 1 default AI Rectangle Board if empty so admin & players have an example right away
    $chk = $db->query("SELECT COUNT(*) AS cnt FROM `custom_boards`");
    $cnt = $chk ? (int)($chk->fetch_assoc()['cnt'] ?? 0) : 0;
    if ($cnt === 0) {
        $defaultCode = 'ai_rect_cyber_metropolis';
        $defaultName = '🏙️ มหานครไซเบอร์สี่เหลี่ยมผืนผ้า (AI Cyber Rectangle 12x8)';
        $defaultDesc = 'กระดาน 3D ทรงสี่เหลี่ยมผืนผ้าแนวกว้าง (12x8) สร้างด้วยระบบ AI พร้อมการ์ดดวงและเอฟเฟกต์นีออนเต็มรูปแบบ';
        $themeJson = json_encode([
            'bgColor' => '#060b16',
            'fogColor' => '#060b16',
            'frameColor' => '#0b1528',
            'tileEven' => '#0f203c',
            'tileOdd' => '#173058',
            'border' => '#00e5ff',
            'ambient' => '#284b7a',
            'light' => '#00e5ff',
            'ladder' => '#38bdf8',
            'snake' => '#f43f5e',
            'particle' => '#00e5ff'
        ], JSON_UNESCAPED_UNICODE);

        $defaultCities = getDefaultAiCityNames(100, 'thai_famous');
        $citiesJson = json_encode($defaultCities, JSON_UNESCAPED_UNICODE);

        $specialJson = json_encode([
            'chanceTiles' => [8, 23, 45, 67, 85],
            'taxTiles' => [18, 52, 82],
            'gambleTiles' => [14, 62, 88],
            'destroyTiles' => [28, 56, 91],
            'jailTile' => 10,
            'ladders' => [
                '4' => 16, '9' => 31, '21' => 42, '29' => 74, '40' => 59, '51' => 68, '63' => 81, '72' => 92
            ],
            'snakes' => [
                '17' => 7, '49' => 30, '61' => 19, '65' => 58, '84' => 26, '93' => 73, '96' => 76, '99' => 79
            ]
        ], JSON_UNESCAPED_UNICODE);

        $effectsJson = json_encode([
            'particleType' => 'cyber_sparks',
            'particleDensity' => 80,
            'fogDensity' => 0.006,
            'lightIntensity' => 1.5,
            'tileBounceOnStep' => true,
            'neonBorderGlow' => true,
            'floatingCrystals' => true,
            'skyboxStyle' => 'cyber_grid'
        ], JSON_UNESCAPED_UNICODE);

        $rollBtnJson = json_encode([
            'preset' => 'bottom_center',
            'offsetX' => 0,
            'offsetY' => 0,
            'scale' => 100,
            'dice3dPos' => 'front_center',
            'buttonStyle' => 'cyber_cyan'
        ], JSON_UNESCAPED_UNICODE);

        $stmt = $db->prepare("
            INSERT INTO `custom_boards`
            (`board_code`, `board_name`, `description`, `shape_type`, `grid_cols`, `grid_rows`, `total_tiles`, `tile_size`, `tile_gap`, `apply_board_texture`, `theme_config_json`, `cities_json`, `special_tiles_json`, `effects_json`, `roll_btn_config_json`, `is_active`, `is_default`)
            VALUES (?, ?, ?, 'rectangle', 12, 8, 100, 6.20, 0.40, 1, ?, ?, ?, ?, ?, 1, 0)
        ");
        if ($stmt) {
            $stmt->bind_param("ssssssss", $defaultCode, $defaultName, $defaultDesc, $themeJson, $citiesJson, $specialJson, $effectsJson, $rollBtnJson);
            $stmt->execute();
            $stmt->close();
        }
    }
}

function getDefaultAiCityNames(int $totalTiles = 100, string $style = 'thai_famous'): array {
    $pools = [
        'thai_famous' => [
            'จุดเริ่มต้นสยาม', 'กรุงเทพฯ', 'เชียงใหม่', 'ภูเก็ต', 'ขอนแก่น', 'ชลบุรี', 'นครราชสีมา', 'สงขลา', 'เชียงราย', 'เกาะร้าง',
            'สุราษฎร์ธานี', 'อยุธยา', 'นนทบุรี', 'ปทุมธานี', 'สมุทรปราการ', 'นครปฐม', 'ระยอง', 'จันทบุรี', 'ตราด', 'กระบี่',
            'พังงา', 'ตรัง', 'สตูล', 'นครศรีธรรมราช', 'พัทลุง', 'ปัตตานี', 'ยะลา', 'นราธิวาส', 'ชุมพร', 'ระนอง',
            'ประจวบฯ', 'เพชรบุรี', 'ราชบุรี', 'กาญจนบุรี', 'สุพรรณบุรี', 'สมุทรสาคร', 'สมุทรสงคราม', 'นครนายก', 'ปราจีนบุรี', 'สระแก้ว',
            'ฉะเชิงเทรา', 'สระบุรี', 'ลพบุรี', 'อ่างทอง', 'สิงห์บุรี', 'ชัยนาท', 'อุทัยธานี', 'นครสวรรค์', 'พิจิตร', 'พิษณุโลก',
            'กำแพงเพชร', 'เพชรบูรณ์', 'สุโขทัย', 'ตาก', 'อุตรดิตถ์', 'แพร่', 'น่าน', 'พะเยา', 'ลำปาง', 'ลำพูน',
            'แม่ฮ่องสอน', 'อุดรธานี', 'หนองคาย', 'บึงกาฬ', 'เลย', 'หนองบัวลำภู', 'สกลนคร', 'นครพนม', 'มุกดาหาร', 'กาฬสินธุ์',
            'มหาสารคาม', 'ร้อยเอ็ด', 'ยโสธร', 'อำนาจเจริญ', 'อุบลราชธานี', 'ศรีสะเกษ', 'สุรินทร์', 'บุรีรัมย์', 'ชัยภูมิ', 'พัทยา',
            'เกาะสมุย', 'เขาใหญ่', 'หัวหิน', 'เกาะช้าง', 'เกาะเสม็ด', 'เกาะพีพี', 'เขาค้อ', 'ภูกระดึง', 'ปาย', 'ชะอำ',
            'บางแสน', 'เกาะพะงัน', 'เกาะล้าน', 'หาดใหญ่', 'เบตง', 'ภูทับเบิก', 'ดอยอินทนนท์', 'ดอยสุเทพ', 'สยามสแควร์', 'เส้นชัยสยาม'
        ],
        'world_metropolis' => [
            'จุดปล่อยตัวโลก', 'โตเกียว', 'โซล', 'สิงคโปร์', 'ฮ่องกง', 'เซี่ยงไฮ้', 'ไทเป', 'โอซาก้า', 'เกียวโต', 'คุกอัลคาทราซ',
            'ดูไบ', 'ลอนดอน', 'ปารีส', 'โรม', 'มิลาน', 'เวนิส', 'ซูริก', 'เจนีวา', 'เวียนนา', 'ปราก',
            'เบอร์ลิน', 'มิวนิก', 'อัมสเตอร์ดัม', 'บรัสเซลส์', 'มาดริด', 'บาร์เซโลนา', 'ลิสบอน', 'เอเธนส์', 'ซานโตรินี', 'อิสตันบูล',
            'มอสโก', 'สตอกโฮล์ม', 'ออสโล', 'โคเปนเฮเกน', 'เฮลซิงกิ', 'เรคยาวิก', 'นิวยอร์ก', 'ลอสแอนเจลิส', 'ซานฟรานซิสโก', 'ลาสเวกัส',
            'ไมอามี', 'ชิคาโก', 'บอสตัน', 'ซีแอตเทิล', 'ฮาวาย', 'โตรอนโต', 'แวนคูเวอร์', 'มอนทรีออล', 'เม็กซิโกซิตี', 'แคนคูน',
            'รีโอเดจาเนโร', 'เซาเปาโล', 'บัวโนสไอเรส', 'ลิมา', 'มาชูปิกชู', 'ซานติอาโก', 'ซิดนีย์', 'เมลเบิร์น', 'โกลด์โคสต์', 'โอ๊คแลนด์',
            'ควีนส์ทาวน์', 'ไคโร', 'มาราเกช', 'เคปทาวน์', 'โจฮันเนสเบิร์ก', 'มัลดีฟส์', 'บาหลี', 'จาการ์ตา', 'กัวลาลัมเปอร์', 'ปีนัง',
            'มะนิลา', 'เซบู', 'ฮานอย', 'โฮจิมินห์', 'ดานัง', 'พนมเปญ', 'เสียมราฐ', 'เวียงจันทน์', 'หลวงพระบาง', 'ย่างกุ้ง',
            'นิวเดลี', 'มุมไบ', 'ชัยปุระ', 'โดฮา', 'อาบูดาบี', 'ริยาด', 'เยรูซาเลม', 'โมนาโก', 'มอนติคาร์โล', 'ลักเซมเบิร์ก',
            'ดับลิน', 'เอดินบะระ', 'แมนเชสเตอร์', 'ลิเวอร์พูล', 'แฟรงก์เฟิร์ต', 'ฮัมบูร์ก', 'นีซ', 'คานส์', 'เบเวอร์ลีฮิลส์', 'มหานครจักรพรรดิ'
        ],
        'cyber_galaxy' => [
            'สถานีปล่อยยาน', 'นีออนโตเกียว', 'ไซเบอร์สยาม', 'อัลฟ่าเซนทอรี', 'เนบิวลามรกต', 'วงแหวนเสาร์', 'ฐานดวงจันทร์', 'นครมาร์ส', 'พลาสม่าซิตี้', 'คุกหลุมดำ',
            'ควอนตัมเบย์', 'ไฮเปอร์เกต', 'แอนโดรเมดา', 'โอไรออนไพรม์', 'ซิริอัสโกลด์', 'เวก้าสตาร์', 'โพลาเหนือ', 'นิวเคลียร์คอร์', 'คริสตัลโดม', 'ดาร์กแมตเตอร์',
            'โซลาร์แฟลร์', 'ออโรร่าสเตชัน', 'ไททันเบส', 'ยูโรป้าไอซ์', 'แกนีมีดพอร์ต', 'คัลลิสโต', 'โฟบอสฟอร์ต', 'ดีมอสพอยต์', 'เซเรสไมน์', 'พลูโตเอาต์โพสต์',
            'ไคเปอร์เบลต์', 'ออร์ตคลาวด์', 'เวิร์มโฮล X1', 'ซูเปอร์โนวา', 'พัลซาร์บีคอน', 'ควอซาร์ซิตี้', 'สตาร์ฟอจ', 'กาแล็กติกฮับ', 'ไซบอร์กวัลเลย์', 'เอไอเซ็นทรัล',
            'โฮโลแกรมพาร์ค', 'เลเซอร์กริด', 'เมทริกซ์ทาวเวอร์', 'ซินธ์เวฟบีช', 'เรโทรอาร์เคด', 'โครเมียมพลาซ่า', 'ไทเทเนียมริง', 'โคบอลต์ฮาร์เบอร์', 'อีเธอร์เรียมเบย์', 'บิตคอยน์ซิตาเดล',
            'ดิจิทัลโอเอซิส', 'เมตาเวิร์สไพรม์', 'พิกเซลพาราไดซ์', 'ว็อกเซลเวิลด์', 'เชดเดอร์พอยต์', 'เรย์เทรซซิตี้', 'เฟรมเรตพีค', 'โอเวอร์คล็อกโซน', 'ลิควิดไนโตร', 'ไฟเบอร์ออปติก',
            'ซิลิคอนไพรม์', 'นาโนเทคแล็บ', 'ไบโอโดม 7', 'เจเนซิสอาร์ค', 'อีเดนสเตชัน', 'วัลฮัลลาเกต', 'โอลิมปัสสเปซ', 'แอตแลนติส 3000', 'เอลโดราโดนีออน', 'ชambhala ไซเบอร์',
            'นิพพานควอนตัม', 'พญานาคจักรกล', 'ครุฑสเตลท์', 'กินรีโฮโล', 'หิมพานต์ดิจิทัล', 'สุเมรุสเปซลิฟต์', 'ไกรลาสคริสตัล', 'อโยธยาไซเบอร์', 'สุโขทัยนีออน', 'ล้านนาดาราจักร',
            'ศรีวิชัยพลาสม่า', 'ทวารวดีเกต', 'ละโว้ไพรม์', 'หริภุญชัยสเตชัน', 'โยนกกาแล็กซี', 'โคตรบูรณ์คอร์', 'ศรีโคตรบูรณ์', 'ตามพรลิงค์', 'ลังกาสุกะ', 'สุวรรณภูมิ 2099',
            'สยามพารากอน X', 'ไอคอนสเปซ', 'มหานครสกาย', 'เจ้าพระยาไฮเปอร์', 'อ่าวไทยเนบิวลา', 'อันดามันคอสมิค', 'ดอยอินทนนท์สเปซ', 'ภูเก็ตไซเบอร์', 'พัทยาเมตา', 'บัลลังก์จักรวาล'
        ],
        'mythic_kingdom' => [
            'ประตูสวรรค์', 'นครหิมพานต์', 'สระอโนดาต', 'เขาพระสุเมรุ', 'วิมานฉิมพลี', 'บาดาลพญานาค', 'ปราสาททองคำ', 'นครมรกต', 'หอคอยจันทรา', 'คุกอเวจี',
            'วังสุริยัน', 'เกาะแก้วพิสดาร', 'เมืองลับแล', 'ถ้ำแก้วมณีโชติ', 'ป่ามักกะลีผล', 'นครกินรี', 'อาณาจักรครุฑา', 'วังมังกรสมุทร', 'ป้อมคชสีห์', 'นครราชสีห์',
            'หุบเขากิเลน', 'วิหารหงส์ไฟ', 'ลานเต่ามังกร', 'เสือขาวพยัคฆ์', 'มังกรฟ้าบูรพา', 'สวรรค์ชั้นจาตุม', 'ดาวดึงส์เทวโลก', 'ยามาพิมาน', 'ดุสิตธานีทิพย์', 'นิมมานรดี',
            'ปรนิมมิตฯ', 'พรหมโลกา', 'อโยธยามหานคร', 'ลงกาทวีป', 'ขีดขินนคร', 'ชมพูทวีป', 'มิถิลานคร', 'โรมคัลพัส', 'บาดาลทวีป', 'จักรวาลบรรพต',
            'สัตตบริภัณฑ์', 'ยุคนธรคีรี', 'อิสินธรบรรพต', 'กรวิกคีรี', 'สุทัศน์บรรพต', 'เนมินธรคีรี', 'วินตกบรรพต', 'อัสสกรรณคีรี', 'สีทันดรสมุทร', 'แม่น้ำคงคาสวรรค์',
            'ยมุนาทิพย์', 'อจิรวดีนคร', 'สรภูวารี', 'มหิมาสมุทร', 'สวนนันทวัน', 'สวนจิตรลดาวัน', 'สวนปารุสกวัน', 'สวนมิสกวัน', 'ปาริชาตสถาน', 'แคฝอยทิพย์',
            'เวชยันต์ปราสาท', 'สุธรรมาเทวสภา', 'เอราวัณสถาน', 'แท่นบัณฑุกัมพล', 'จุฬามณีเจดีย์', 'วิมานไพชยนต์', 'นครไกรลาส', 'อุทยานแมนสรวง', 'ทิพยสถาน', 'รัตนโกสินทร์ทิพย์',
            'สุวรรณภูมิราชธานี', 'ทวารวดีศรีนคร', 'ศรีวิชัยมณี', 'หริภุญชัยทอง', 'โยนกนาคพันธุ์', 'เวียงพิงค์ทิพย์', 'เขลางค์นคร', 'ศรีสัชนาลัย', 'สองแควพิษณุ', 'เพชรบูรณ์คีรี',
            'พริบพรีราชธานี', 'อู่ทองสุวรรณ', 'ละโว้ธานี', 'จันทบูรณี', 'ตราดมณีเกาะ', 'สมุยสวรรค์', 'ภูเก็ตไข่มุก', 'อันดามันมรกต', 'แม่โขงนาคา', 'เจ้าพระยาทองคำ',
            'บางกอกวิมาน', 'สยามเทวราช', 'มณีรัตนะ', 'เพชรจินดา', 'ทับทิมสยาม', 'บุษราคัมทอง', 'ไพลินสมุทร', 'มรกตส่องแสง', 'เพชรหน้าทั่ง', 'มหาวิหารเส้นชัย'
        ]
    ];

    $selectedPool = $pools[$style] ?? $pools['thai_famous'];
    $cities = [];
    $poolCount = count($selectedPool);
    for ($i = 1; $i <= $totalTiles; $i++) {
        if ($i === 1) {
            $cities[$i] = $selectedPool[0];
        } elseif ($i === $totalTiles) {
            $cities[$i] = $selectedPool[$poolCount - 1];
        } else {
            $idx = ($i - 1) % ($poolCount - 1);
            if ($idx === 0) $idx = 1;
            $cities[$i] = $selectedPool[$idx];
        }
    }
    return $cities;
}

function getAllCustomBoards(mysqli $db, bool $onlyActive = false): array {
    ensureCustomBoardsTable($db);
    $where = $onlyActive ? "WHERE `is_active` = 1" : "";
    $res = $db->query("SELECT * FROM `custom_boards` {$where} ORDER BY `is_default` DESC, `is_active` DESC, `id` DESC");
    $list = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $row['id'] = (int)$row['id'];
            $row['grid_cols'] = (int)$row['grid_cols'];
            $row['grid_rows'] = (int)$row['grid_rows'];
            $row['total_tiles'] = (int)$row['total_tiles'];
            $row['tile_size'] = (float)$row['tile_size'];
            $row['tile_gap'] = (float)$row['tile_gap'];
            $row['apply_board_texture'] = (int)$row['apply_board_texture'] === 1;
            $row['is_active'] = (int)$row['is_active'] === 1;
            $row['is_default'] = (int)$row['is_default'] === 1;
            $row['theme_config'] = json_decode((string)($row['theme_config_json'] ?? '{}'), true) ?: [];
            $row['cities'] = json_decode((string)($row['cities_json'] ?? '{}'), true) ?: [];
            $row['special_tiles'] = json_decode((string)($row['special_tiles_json'] ?? '{}'), true) ?: [];
            $row['effects'] = json_decode((string)($row['effects_json'] ?? '{}'), true) ?: [];
            $row['roll_btn_config'] = json_decode((string)($row['roll_btn_config_json'] ?? '{}'), true) ?: [];
            unset(
                $row['theme_config_json'],
                $row['cities_json'],
                $row['special_tiles_json'],
                $row['effects_json'],
                $row['roll_btn_config_json']
            );
            $list[] = $row;
        }
    }
    return $list;
}

