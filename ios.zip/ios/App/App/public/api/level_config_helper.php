<?php
declare(strict_types=1);

/**
 * level_config_helper.php
 * ตัวช่วยจัดการการตั้งค่าเลเวลสูงสุด (Max Level) และรางวัลเลเวลอัป (เพชร, ทอง, ลูกบาศก์)
 */

function getLevelCubeDisplayName(string $cubeType): string {
    $map = [
        'SILVER' => 'ลูกบาศก์เงิน',
        'GOLD' => 'ลูกบาศก์ทอง',
        'DIAMOND' => 'ลูกบาศก์เพชร',
        'LEGENDARY' => 'ลูกบาศก์ในตำนาน',
    ];
    $key = strtoupper(trim($cubeType));
    return $map[$key] ?? '';
}

function getDefaultLevelUpConfig(): array {
    return [
        'max_level' => 100,
        'default_reward' => [
            'diamond' => 20,
            'gold' => 2000,
            'cubes' => [],
            'cube_type' => '',
            'cube_qty' => 0,
        ],
        'level_rewards' => [
            '5' => ['diamond' => 50, 'gold' => 5000, 'cubes' => [['cube_type' => 'SILVER', 'qty' => 1]], 'cube_type' => 'SILVER', 'cube_qty' => 1],
            '10' => ['diamond' => 100, 'gold' => 10000, 'cubes' => [['cube_type' => 'GOLD', 'qty' => 1]], 'cube_type' => 'GOLD', 'cube_qty' => 1],
            '20' => ['diamond' => 200, 'gold' => 25000, 'cubes' => [['cube_type' => 'DIAMOND', 'qty' => 1]], 'cube_type' => 'DIAMOND', 'cube_qty' => 1],
            '30' => ['diamond' => 500, 'gold' => 50000, 'cubes' => [['cube_type' => 'LEGENDARY', 'qty' => 1]], 'cube_type' => 'LEGENDARY', 'cube_qty' => 1],
        ],
    ];
}

function normalizeSingleLevelReward($raw, array $fallback = ['diamond' => 20, 'gold' => 2000, 'cubes' => [], 'cube_type' => '', 'cube_qty' => 0]): array {
    if (!is_array($raw)) {
        $raw = [];
    }
    $allowedCubes = ['SILVER', 'GOLD', 'DIAMOND', 'LEGENDARY'];
    $cubeMap = [];

    if (isset($raw['cubes']) && is_array($raw['cubes'])) {
        foreach ($raw['cubes'] as $entry) {
            if (!is_array($entry)) continue;
            $ct = strtoupper(trim((string)($entry['cube_type'] ?? '')));
            $qty = max(0, (int)($entry['qty'] ?? ($entry['cube_qty'] ?? 0)));
            if (in_array($ct, $allowedCubes, true) && $qty > 0) {
                $cubeMap[$ct] = ($cubeMap[$ct] ?? 0) + $qty;
            }
        }
    } elseif (!empty($raw['cube_type'])) {
        $ct = strtoupper(trim((string)$raw['cube_type']));
        $qty = max(1, (int)($raw['cube_qty'] ?? 1));
        if (in_array($ct, $allowedCubes, true)) {
            $cubeMap[$ct] = $qty;
        }
    } elseif (empty($raw) && !empty($fallback['cubes']) && is_array($fallback['cubes'])) {
        foreach ($fallback['cubes'] as $entry) {
            if (!is_array($entry)) continue;
            $ct = strtoupper(trim((string)($entry['cube_type'] ?? '')));
            $qty = max(0, (int)($entry['qty'] ?? 0));
            if (in_array($ct, $allowedCubes, true) && $qty > 0) {
                $cubeMap[$ct] = ($cubeMap[$ct] ?? 0) + $qty;
            }
        }
    }

    $cubes = [];
    foreach ($allowedCubes as $ct) {
        if (!empty($cubeMap[$ct])) {
            $cubes[] = [
                'cube_type' => $ct,
                'cube_name' => getLevelCubeDisplayName($ct),
                'qty' => (int)$cubeMap[$ct],
            ];
        }
    }

    $firstCube = $cubes[0] ?? null;

    return [
        'diamond' => max(0, (int)($raw['diamond'] ?? ($fallback['diamond'] ?? 0))),
        'gold' => max(0, (int)($raw['gold'] ?? ($fallback['gold'] ?? 0))),
        'cubes' => $cubes,
        'cube_type' => $firstCube ? $firstCube['cube_type'] : '',
        'cube_qty' => $firstCube ? $firstCube['qty'] : 0,
    ];
}

function getLevelUpConfig(mysqli $db): array {
    $defaults = getDefaultLevelUpConfig();

    @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) UNIQUE NOT NULL,
        `setting_value` LONGTEXT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $stmt = @$db->prepare("SELECT `setting_value` FROM `game_settings` WHERE `setting_key` = 'level_up_config' LIMIT 1");
    if (!$stmt) {
        return $defaults;
    }
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || empty($row['setting_value'])) {
        return $defaults;
    }

    $decoded = json_decode((string)$row['setting_value'], true);
    if (!is_array($decoded)) {
        return $defaults;
    }

    $maxLevel = max(2, (int)($decoded['max_level'] ?? $defaults['max_level']));
    $defaultReward = normalizeSingleLevelReward($decoded['default_reward'] ?? [], $defaults['default_reward']);

    $levelRewards = [];
    if (isset($decoded['level_rewards']) && is_array($decoded['level_rewards'])) {
        foreach ($decoded['level_rewards'] as $lvlKey => $rw) {
            $lvlInt = (int)$lvlKey;
            if ($lvlInt < 2) {
                continue;
            }
            $levelRewards[(string)$lvlInt] = normalizeSingleLevelReward($rw, ['diamond' => 0, 'gold' => 0, 'cube_type' => '', 'cube_qty' => 0]);
        }
        uksort($levelRewards, function ($a, $b) {
            return (int)$a <=> (int)$b;
        });
    }

    return [
        'max_level' => $maxLevel,
        'default_reward' => $defaultReward,
        'level_rewards' => $levelRewards,
    ];
}

function resolveLevelUpReward(array $cfg, int $targetLevel): array {
    $lvlKey = (string)$targetLevel;
    $isCustom = isset($cfg['level_rewards'][$lvlKey]) && is_array($cfg['level_rewards'][$lvlKey]);
    $raw = $isCustom ? $cfg['level_rewards'][$lvlKey] : ($cfg['default_reward'] ?? []);
    $norm = normalizeSingleLevelReward($raw);
    $norm['cube_name'] = getLevelCubeDisplayName($norm['cube_type']);
    $norm['is_custom'] = $isCustom;
    return $norm;
}

/**
 * เปิดใช้งาน/ต่ออายุ การ์ดปลุกพลังพิเศษ Lv.30 สำหรับสายที่เลือกเมื่อจัดกิจกรรมแบบ "กลับมาอีกครั้ง (Rerun)"
 * เพื่อให้ผู้เล่นที่มี การ์ด/เต๋า/อัญมณี จากอีเวนต์รอบก่อนหน้า สามารถสุ่มหรือซื้อการ์ดปลุกพลังมาอัปถึง Lv.30 ได้ทันที
 */
function activateSpecialAwakeningForRerun(mysqli $db, string $catKey, string $startDate = '', string $endDate = ''): void {
    $cat = in_array($catKey, ['card', 'dice', 'gem'], true) ? $catKey : 'card';
    @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) UNIQUE NOT NULL,
        `setting_value` LONGTEXT NULL,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $cfg = [];
    $res = @$db->query("SELECT `setting_value` FROM `game_settings` WHERE `setting_key` = 'special_awakening_config' LIMIT 1");
    if ($res && ($row = $res->fetch_assoc()) && !empty($row['setting_value'])) {
        $dec = json_decode((string)$row['setting_value'], true);
        if (is_array($dec)) $cfg = $dec;
    }

    if (!isset($cfg[$cat]) || !is_array($cfg[$cat])) {
        $cfg[$cat] = [];
    }
    $cfg[$cat]['is_active'] = 1;
    $cfg[$cat]['allow_shop_buy'] = 1;
    if ((float)($cfg[$cat]['drop_rate_pct'] ?? 0) <= 0) {
        $cfg[$cat]['drop_rate_pct'] = 15;
    }
    if ($startDate !== '') {
        $cfg[$cat]['start_date'] = $startDate;
    }
    if ($endDate !== '') {
        $cfg[$cat]['end_date'] = $endDate;
    }

    $jsonStr = json_encode($cfg, JSON_UNESCAPED_UNICODE);
    @$db->query("DELETE FROM `game_settings` WHERE `setting_key` = 'special_awakening_config'");
    $stmt = @$db->prepare("INSERT INTO `game_settings` (`setting_key`, `setting_value`) VALUES ('special_awakening_config', ?)");
    if ($stmt) {
        $stmt->bind_param("s", $jsonStr);
        $stmt->execute();
        $stmt->close();
    }
}
