<?php
declare(strict_types=1);

/**
 * Database & Global Configuration for Snake & Ladder 3D Game Backend
 * PHP 8.4.25 / Nginx 1.31.6 / MariaDB 11.8.6
 */

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Alt-Svc: clear');

// Handle preflight OPTIONS request
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Database Credentials
define('DB_HOST', '127.0.0.1'); // Use 127.0.0.1 TCP to prevent open_basedir warnings
define('DB_USER', 'root');
define('DB_PASS', '@Nbthai01ccs');
define('DB_NAME', 'snake');
define('DB_SOCKET', '/var/run/mysqld/mysqld.sock');

// Sodium Secret Key for Auth Token generation & verification (32 bytes)
define('SODIUM_SECRET_KEY', 'snake3d_super_secret_master_key_'); // 32 characters

/**
 * Get MariaDB mysqli connection (supports TCP 127.0.0.1 and Unix Socket safely)
 */
function getDbConnection(): mysqli {
    static $conn = null;
    if ($conn !== null && @$conn->ping()) {
        return $conn;
    }

    // Suppress default fatal report so we can handle fallback gracefully
    mysqli_report(MYSQLI_REPORT_OFF);

    // 1. Try TCP 127.0.0.1 (safest under open_basedir)
    $conn = @new mysqli('127.0.0.1', DB_USER, DB_PASS, DB_NAME, 3306);

    // 2. Fallback to localhost socket if allowed
    if ($conn->connect_errno) {
        $sock = null;
        if (empty(ini_get('open_basedir')) && @file_exists(DB_SOCKET)) {
            $sock = DB_SOCKET;
        }

        if ($sock) {
            $conn = @new mysqli('localhost', DB_USER, DB_PASS, DB_NAME, 3306, $sock);
        } else {
            $conn = @new mysqli('localhost', DB_USER, DB_PASS, DB_NAME, 3306);
        }
    }

    if ($conn->connect_errno) {
        http_response_code(500);
        if (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'status' => 'error',
                'message' => 'Database connection failed: ' . $conn->connect_error
            ], JSON_UNESCAPED_UNICODE);
        } else {
            header('Content-Type: text/html; charset=utf-8');
            echo '<div style="font-family:sans-serif; padding:20px; color:#ef4444; background:#1e293b; border-radius:8px;">';
            echo '<h3>⚠️ ไม่สามารถเชื่อมต่อฐานข้อมูล MariaDB ได้</h3>';
            echo '<p>' . htmlspecialchars($conn->connect_error) . '</p>';
            echo '<p>โปรดตรวจสอบว่าได้สร้างฐานข้อมูล <code>snake</code> และรหัสผ่าน MariaDB ถูกต้องแล้ว</p>';
            echo '</div>';
        }
        exit;
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}

/**
 * Standard JSON response helper
 */
function jsonResponse(array $data, int $statusCode = 200): void {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Generate secure auth token using sodium HMAC
 */
function generateAuthToken(int $userId): string {
    $payload = json_encode([
        'uid' => $userId,
        'time' => time(),
        'nonce' => bin2hex(random_bytes(8))
    ]);
    $mac = sodium_crypto_auth($payload, SODIUM_SECRET_KEY);
    return base64_encode($payload) . '.' . base64_encode($mac);
}

/**
 * Verify auth token and return user ID, or false if invalid/tampered
 */
function verifyAuthToken(string $token): ?int {
    $parts = explode('.', $token);
    if (count($parts) !== 2) {
        return null;
    }
    $payload = base64_decode($parts[0], true);
    $mac = base64_decode($parts[1], true);
    if ($payload === false || $mac === false) {
        return null;
    }

    if (!sodium_crypto_auth_verify($mac, $payload, SODIUM_SECRET_KEY)) {
        return null;
    }

    $data = json_decode($payload, true);
    return isset($data['uid']) ? (int)$data['uid'] : null;
}

/**
 * Authenticate request via Authorization: Bearer <token> or ?token=
 */
function requireAuth(mysqli $db): array {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ($_GET['token'] ?? ($_POST['token'] ?? ''))));
    
    $token = '';
    if (str_starts_with($authHeader, 'Bearer ')) {
        $token = substr($authHeader, 7);
    } else {
        $token = $authHeader;
    }

    if (empty($token)) {
        jsonResponse(['status' => 'error', 'message' => 'Unauthorized: Token missing'], 401);
    }

    $userId = verifyAuthToken($token);
    if (!$userId) {
        // Fallback: check raw token in database
        $stmt = $db->prepare("SELECT id, username, avatar_url, diamond, gold, clan_id, level, is_banned FROM users WHERE auth_token = ? LIMIT 1");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$user) {
            jsonResponse(['status' => 'error', 'message' => 'Unauthorized: Invalid token'], 401);
        }
    } else {
        $stmt = $db->prepare("SELECT id, username, avatar_url, diamond, gold, clan_id, level, is_banned FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // หากบัญชีเดิมเป็นบัญชีซ้ำที่ถูกรวมเข้าสู่บัญชีหลัก (id = 15) แล้ว ให้ดึงบัญชีหลักอัตโนมัติ
        if (!$user && in_array($userId, [12, 13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24], true)) {
            $fallbackId = 15;
            $stmt = $db->prepare("SELECT id, username, avatar_url, diamond, gold, clan_id, level, is_banned FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $fallbackId);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
    }

    if (!$user) {
        jsonResponse(['status' => 'error', 'message' => 'User not found'], 404);
    }
    if ($user['is_banned']) {
        jsonResponse(['status' => 'error', 'message' => 'Account is suspended'], 403);
    }

    return $user;
}

/**
 * Ensure `orders` and `game_settings` tables exist with default seeds
 */
function ensureOrdersAndSettingsTables(mysqli $db): void {
    $db->query("CREATE TABLE IF NOT EXISTS `orders` (
        `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
        `order_no` VARCHAR(64) UNIQUE NOT NULL,
        `user_id` INT NOT NULL DEFAULT 1,
        `username` VARCHAR(100) NOT NULL,
        `package_id` VARCHAR(50) NOT NULL,
        `package_name` VARCHAR(100) NOT NULL,
        `amount_thb` DECIMAL(10,2) NOT NULL,
        `diamond_amount` INT NOT NULL,
        `bonus_diamonds` INT NOT NULL DEFAULT 0,
        `payment_method` ENUM('promptpay', 'credit_card', 'truemoney', 'paypal') NOT NULL DEFAULT 'promptpay',
        `status` ENUM('PAID', 'PENDING', 'FAILED', 'CANCELLED') NOT NULL DEFAULT 'PAID',
        `transaction_ref` VARCHAR(100) DEFAULT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_user_id` (`user_id`),
        INDEX `idx_status` (`status`),
        INDEX `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(100) UNIQUE NOT NULL,
        `setting_value` TEXT NULL,
        `category` VARCHAR(50) NOT NULL DEFAULT 'general',
        `description` VARCHAR(255) DEFAULT NULL,
        `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_key` (`setting_key`),
        INDEX `idx_cat` (`category`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Ensure dice table has shadow_config_json column
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ข้อมูลการตั้งค่าการ์ดเงา 5 สี'");

    // Ensure topup_packages table exists with all required columns
    $db->query("CREATE TABLE IF NOT EXISTS `topup_packages` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(150) NOT NULL,
        `type` VARCHAR(50) NOT NULL DEFAULT 'DIAMOND',
        `reward_diamond` INT NOT NULL DEFAULT 0,
        `reward_gold` BIGINT NOT NULL DEFAULT 0,
        `price_thb` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `type` VARCHAR(50) NOT NULL DEFAULT 'DIAMOND'");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `reward_diamond` INT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `reward_gold` BIGINT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `price_thb` DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1");
    @$db->query("ALTER TABLE `topup_packages` MODIFY COLUMN `reward_gold` BIGINT NOT NULL DEFAULT 0");

    // Ensure payment_orders table exists for PromptPay & In-Game purchases
    $db->query("CREATE TABLE IF NOT EXISTS `payment_orders` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `order_no` VARCHAR(64) NOT NULL UNIQUE,
        `user_id` INT NOT NULL,
        `package_id` INT NULL,
        `item_type` VARCHAR(50) NOT NULL DEFAULT 'TOPUP',
        `item_name` VARCHAR(150) NOT NULL DEFAULT 'แพ็กเกจเพชร',
        `amount_thb` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `reward_diamond` INT NOT NULL DEFAULT 0,
        `reward_gold` BIGINT NOT NULL DEFAULT 0,
        `payment_method` VARCHAR(50) NOT NULL DEFAULT 'promptpay',
        `status` ENUM('pending', 'paid', 'expired', 'failed') NOT NULL DEFAULT 'pending',
        `is_fulfilled` TINYINT(1) NOT NULL DEFAULT 0,
        `qr_data` TEXT NULL,
        `paid_at` DATETIME NULL,
        `expired_at` DATETIME NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_user_status` (`user_id`, `status`),
        INDEX `idx_order_no` (`order_no`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    @$db->query("ALTER TABLE `payment_orders` ADD COLUMN IF NOT EXISTS `is_fulfilled` TINYINT(1) NOT NULL DEFAULT 0");

    // Seeds for game_settings if empty
    $chkSettings = $db->query("SELECT COUNT(*) as cnt FROM `game_settings`");
    $cntSettings = ($chkSettings && ($row = $chkSettings->fetch_assoc())) ? (int)$row['cnt'] : 0;
    if ($cntSettings === 0) {
        $defaultSettings = [
            ['webview_domain', 'https://pmix01.thddns.net:7175/home/snake/', 'network', 'โดเมนหลักของเกมบน WebView (iOS/Android)'],
            ['app_version', '1.0.0', 'version', 'เวอร์ชันปัจจุบันของแอปพลิเคชัน'],
            ['payment_promptpay_enabled', '1', 'payment', 'เปิด/ปิดการชำระเงินผ่าน PromptPay QR Code'],
            ['payment_creditcard_enabled', '1', 'payment', 'เปิด/ปิดการชำระเงินผ่านบัตรเครดิต/เดบิต'],
            ['payment_truemoney_enabled', '1', 'payment', 'เปิด/ปิดการชำระเงินผ่าน TrueMoney Wallet'],
            ['payment_paypal_enabled', '1', 'payment', 'เปิด/ปิดการชำระเงินผ่าน PayPal'],
            ['maintenance_mode', '0', 'general', 'โหมดปิดปรับปรุงเซิร์ฟเวอร์ชั่วคราว'],
        ];
        $sStmt = $db->prepare("INSERT IGNORE INTO `game_settings` (`setting_key`, `setting_value`, `category`, `description`) VALUES (?, ?, ?, ?)");
        foreach ($defaultSettings as $s) {
            $sStmt->bind_param("ssss", $s[0], $s[1], $s[2], $s[3]);
            $sStmt->execute();
        }
        $sStmt->close();
    }

    // Seeds for orders if empty
    $chkOrders = $db->query("SELECT COUNT(*) as cnt FROM `orders`");
    $cntOrders = ($chkOrders && ($row = $chkOrders->fetch_assoc())) ? (int)$row['cnt'] : 0;
    if ($cntOrders === 0) {
        $sampleOrders = [
            ['ORD-20261107-1001', 1, 'เอ็นซีพี คอมพิวเตอร์', 'dia_1000', '1,000 เพชร', 10.00, 1000, 0, 'promptpay', 'PAID', 'TXN-PP-994821'],
            ['ORD-20261107-1002', 2, 'แพรวา พารวย', 'dia_promo_2plus1', 'โปรโมชัน 2 แถม 1 (3,000 เพชร)', 20.00, 2000, 1000, 'truemoney', 'PAID', 'TXN-TM-882711'],
            ['ORD-20261107-1003', 3, 'มินตรา ดาวเหนือ', 'dia_1000', '1,000 เพชร', 10.00, 1000, 0, 'credit_card', 'PAID', 'TXN-CC-773819'],
            ['ORD-20261107-1004', 1, 'เอ็นซีพี คอมพิวเตอร์', 'dia_promo_2plus1', 'โปรโมชัน 2 แถม 1 (3,000 เพชร)', 20.00, 2000, 1000, 'promptpay', 'PAID', 'TXN-PP-665511'],
            ['ORD-20261107-1005', 4, 'ต้นกล้า นาคราช', 'dia_1000', '1,000 เพชร', 10.00, 1000, 0, 'paypal', 'PAID', 'TXN-PP-554422'],
            ['ORD-20261107-1006', 5, 'นนท์ เซียนเต๋า', 'dia_promo_2plus1', 'โปรโมชัน 2 แถม 1 (3,000 เพชร)', 20.00, 2000, 1000, 'truemoney', 'PENDING', 'TXN-TM-443311']
        ];
        $oStmt = $db->prepare("INSERT IGNORE INTO `orders` (`order_no`, `user_id`, `username`, `package_id`, `package_name`, `amount_thb`, `diamond_amount`, `bonus_diamonds`, `payment_method`, `status`, `transaction_ref`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($sampleOrders as $o) {
            $oStmt->bind_param("sisssdiisss", $o[0], $o[1], $o[2], $o[3], $o[4], $o[5], $o[6], $o[7], $o[8], $o[9], $o[10]);
            $oStmt->execute();
        }
        $oStmt->close();
    }
}
