<?php
declare(strict_types=1);

/**
 * oauth.php - OAuth Configuration for LINE Login & Google OAuth 2.0
 * Snake & Ladder 3D Game Backend (PHP 8.4.25)
 * Path: /www/wwwroot/web/home/snake/config/oauth.php
 */

return [
    // =========================================================================
    // 1. LINE Login API (v2.1) - Snake Game 3D
    // =========================================================================
    'line' => [
        // 1. Channel ID (รหัสแอปใหม่)
        'channel_id' => '2012374389',

        // 2. Channel Secret ตัวล่าสุดจากหน้า Basic settings ของ Snake Game 3D
        // (กรุณาวางรหัส 32 หลักที่คัดลอกมาลงในช่องนี้)
        'channel_secret' => 'YOUR_LINE_CHANNEL_SECRET_HERE',

        // 3. Callback URL / Redirect URI ตามที่ระบุ
        'callback_url' => 'https://pmix01.thddns.net:7175/home/snake/',

        // ออปชันเปิดแอป LINE ในมือถืออัตโนมัติ (false เพื่อไม่ให้เด้งเปิดแท็บใหม่ Error 400 ในเบราว์เซอร์)
        'open_external' => false,
    ],

    // =========================================================================
    // 2. Google OAuth 2.0 API
    // =========================================================================
    'google' => [
        'client_id' => '497403948772-1dlhn0uck8o3dla16sf9rmainmk3hiek.apps.googleusercontent.com',
        'client_secret' => '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',
        'callback_url' => 'https://pmix01.thddns.net:7175/home/snake',
    ]
];
