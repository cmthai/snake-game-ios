/**
 * admin/js/admin_board_studio.js
 * AI 3D Board Studio — สร้างกระดาน 3D ด้วย AI จากรูปภาพ, กำหนดรูปทรง (สี่เหลี่ยมผืนผ้า/จัตุรัส/ก้นหอย/หกเหลี่ยม/วงแหวนเพชร),
 * จัดการชื่อเมือง (AI ตั้งชื่อได้ + แก้ไขรายช่อง), กำหนดตำแหน่งและจำนวนการ์ดดวง/ช่องพิเศษ, ตั้งค่าเอฟเฟกต์ 3D,
 * กำหนดตำแหน่งปุ่มทอยลูกเต๋า และเปิดให้เล่นได้ทันทีหรือกดยกเลิกได้
 */
(function () {
    'use strict';

    const DEFAULT_THAI_CITIES = [
        'จุดเริ่มต้นสยาม', 'กรุงเทพฯ', 'เชียงใหม่', 'ภูเก็ต', 'ขอนแก่น', 'ชลบุรี', 'นครราชสีมา', 'สงขลา', 'เชียงราย', 'เกาะร้าง',
        'สุราษฎร์ธานี', 'อยุธยา', 'นนทบุรี', 'ปทุมธานี', 'สมุทรปราการ', 'นครปฐม', 'ระยอง', 'จันทบุรี', 'ตราด', 'กระบี่',
        'พังงา', 'ตรัง', 'สตูล', 'นครศรีธรรมราช', 'พัทลุง', 'ปัตตานี', 'ยะลา', 'นราธิวาส', 'ชุมพร', 'ระนอง',
        'ประจวบฯ', 'เพชรบุรี', 'ราชบุรี', 'กาญจนบุรี', 'สุพรรณบุรี', 'สมุทรสาคร', 'สมุทรสงคราม', 'นครนายก', 'ปราจีนบุรี', 'สระแก้ว',
        'ฉะเชิงเทรา', 'สระบุรี', 'ลพบุรี', 'อ่างทอง', 'สิงห์บุรี', 'ชัยนาท', 'อุทัยธานี', 'นครสวรรค์', 'พิจิตร', 'พิษณุโลก',
        'กำแพงเพชร', 'เพชรบูรณ์', 'สุโขทัย', 'ตาก', 'อุตรดิตถ์', 'แพร่', 'น่าน', 'พะเยา', 'ลำปาง', 'ลำพูน',
        'แม่ฮ่องสอน', 'อุดรธานี', 'หนองคาย', 'บึงกาฬ', 'เลย', 'หนองบัวลำภู', 'สกลนคร', 'นครพนม', 'มุกดาหาร', 'กาฬสินธุ์',
        'มหาสารคาม', 'ร้อยเอ็ด', 'ยโสธร', 'อำนาจเจริญ', 'อุบลราชธานี', 'ศรีสะเกษ', 'สุรินทร์', 'บุรีรัมย์', 'ชัยภูมิ', 'พัทยา',
        'เกาะสมุย', 'เขาใหญ่', 'หัวหิน', 'เกาะช้าง', 'เกาะเสม็ด', 'เกาะพีพี', 'เขาค้อ', 'ภูกระดึง', 'ปาย', 'ชะอำ',
        'บางแสน', 'เกาะพะงัน', 'เกาะล้าน', 'หาดใหญ่', 'เบตง', 'ภูทับเบิก', 'ดอยอินทนนท์', 'ดอยสุเทพ', 'สยามสแควร์', 'เส้นชัยสยาม'
    ];

    let studioState = {
        initialized: false,
        boardsList: [],
        sourceImageUrl: '',
        extractedPalette: [],
        cities: {},
        specialTiles: {
            chanceTiles: [8, 23, 45, 67, 85],
            taxTiles: [18, 52, 82],
            gambleTiles: [14, 62, 88],
            destroyTiles: [28, 56, 91],
            jailTile: 10,
            ladders: { 4: 16, 9: 31, 21: 42, 29: 74, 40: 59, 51: 68, 63: 81, 72: 92 },
            snakes: { 17: 7, 49: 30, 61: 19, 65: 58, 84: 26, 93: 73, 96: 76, 99: 79 }
        },
        // Three.js Preview objects
        scene: null,
        camera: null,
        renderer: null,
        controls: null,
        boardGroup: null,
        particlesGroup: null,
        diceGroup: null,
        diceMesh1: null,
        diceMesh2: null,
        tilePositions: {},
        boardTextureObj: null,
        animFrameId: null
    };

    function esc(s) {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function initDefaultCities(total = 100) {
        const next = {};
        for (let i = 1; i <= total; i++) {
            if (i === 1) next[i] = 'จุดเริ่มต้นสยาม';
            else if (i === total) next[i] = 'เส้นชัยสยาม';
            else next[i] = studioState.cities[i] || DEFAULT_THAI_CITIES[(i - 1) % DEFAULT_THAI_CITIES.length] || `เมือง #${i}`;
        }
        studioState.cities = next;
    }

    window.initAiBoardStudioTab = async function () {
        if (!studioState.initialized) {
            studioState.initialized = true;
            initDefaultCities(100);
            setupDropzoneAndDragEvents();
            initStudioThreeJS();
        }
        await window.loadCustomBoardsListAdmin();
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
        window.updateAiBoardRollBtnPreview();
    };

    function projectClientPointToBoardXZ(clientX, clientY) {
        const viewport = document.getElementById('abs_preview_viewport');
        if (!viewport || !studioState.camera || !window.THREE) return null;
        const rect = viewport.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;

        const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
        const ndcY = -((clientY - rect.top) / rect.height) * 2 + 1;

        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), studioState.camera);
        const boardPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.2);
        const hit = new THREE.Vector3();
        if (raycaster.ray.intersectPlane(boardPlane, hit)) {
            return {
                x: Math.max(-38, Math.min(38, Math.round(hit.x * 2) / 2)),
                z: Math.max(-34, Math.min(36, Math.round(hit.z * 2) / 2))
            };
        }
        return null;
    }

    function applyStudioDiceWorldXZ(wx, wz, modeOverride = 'custom_xz') {
        const clampedX = Math.max(-38, Math.min(38, Math.round(Number(wx || 0) * 2) / 2));
        const clampedZ = Math.max(-34, Math.min(36, Math.round(Number(wz || 0) * 2) / 2));
        const posSel = document.getElementById('abs_dice3d_pos');
        if (posSel && modeOverride) posSel.value = modeOverride;
        const inX = document.getElementById('abs_dice3d_x');
        const inZ = document.getElementById('abs_dice3d_z');
        if (inX) inX.value = String(clampedX);
        if (inZ) inZ.value = String(clampedZ);
        const lblX = document.getElementById('abs_lbl_dice_x');
        const lblZ = document.getElementById('abs_lbl_dice_z');
        if (lblX) lblX.innerText = clampedX.toFixed(1);
        if (lblZ) lblZ.innerText = clampedZ.toFixed(1);

        updateStudioDice3DMeshPositionsOnly();
    }

    function setupDropzoneAndDragEvents() {
        const dz = document.getElementById('abs_image_dropzone');
        if (dz) {
            dz.addEventListener('dragover', (e) => {
                e.preventDefault();
                dz.style.borderColor = '#fde047';
                dz.style.background = 'rgba(250,204,21,0.12)';
            });
            dz.addEventListener('dragleave', () => {
                dz.style.borderColor = '#38bdf8';
                dz.style.background = 'rgba(56,189,248,0.06)';
            });
            dz.addEventListener('drop', (e) => {
                e.preventDefault();
                dz.style.borderColor = '#38bdf8';
                dz.style.background = 'rgba(56,189,248,0.06)';
                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
                    processUploadedBoardImageFile(e.dataTransfer.files[0]);
                }
            });
        }

        const viewport = document.getElementById('abs_preview_viewport');

        // 1. Draggable Roll Button inside 3D Preview Viewport (Mouse + Touch iOS/Android)
        const station = document.getElementById('abs_preview_dice_station');
        if (station && viewport) {
            let dragging = false;
            let startX = 0, startY = 0;
            let origOffsetX = 0, origOffsetY = 0;

            const onPointerDown = (e) => {
                if (e.target && e.target.tagName === 'BUTTON') return;
                dragging = true;
                station.style.cursor = 'grabbing';
                if (studioState.controls) studioState.controls.enabled = false;
                const pt = e.touches ? e.touches[0] : e;
                startX = pt.clientX;
                startY = pt.clientY;
                origOffsetX = parseInt(document.getElementById('abs_roll_offset_x')?.value || '0', 10);
                origOffsetY = parseInt(document.getElementById('abs_roll_offset_y')?.value || '0', 10);
                e.stopPropagation();
                e.preventDefault();
            };

            const onPointerMove = (e) => {
                if (!dragging) return;
                const pt = e.touches ? e.touches[0] : e;
                // Since preview scales offset by 0.45, multiply delta by ~2.0 so button follows finger 1:1
                const dx = Math.round((pt.clientX - startX) / 0.48);
                const dy = Math.round((pt.clientY - startY) / 0.48);
                const nextX = Math.max(-350, Math.min(350, origOffsetX + dx));
                const nextY = Math.max(-350, Math.min(350, origOffsetY + dy));

                const presetEl = document.getElementById('abs_roll_preset');
                if (presetEl && presetEl.value !== 'custom_xy' && presetEl.value !== 'center_board') {
                    presetEl.value = 'custom_xy';
                }
                const inX = document.getElementById('abs_roll_offset_x');
                const inY = document.getElementById('abs_roll_offset_y');
                if (inX) inX.value = String(nextX);
                if (inY) inY.value = String(nextY);
                const lblX = document.getElementById('abs_lbl_roll_x');
                const lblY = document.getElementById('abs_lbl_roll_y');
                if (lblX) lblX.innerText = String(nextX);
                if (lblY) lblY.innerText = String(nextY);

                // If "Sync 3D Dice with Roll Button" is enabled, move 3D Dice along with the Roll Button!
                const syncChk = document.getElementById('abs_sync_dice_with_btn');
                const dMode = document.getElementById('abs_dice3d_pos')?.value;
                if ((syncChk && syncChk.checked) || dMode === 'follow_button') {
                    const stRect = station.getBoundingClientRect();
                    const hitXZ = projectClientPointToBoardXZ(stRect.left + stRect.width / 2, stRect.top - 18);
                    if (hitXZ) {
                        applyStudioDiceWorldXZ(hitXZ.x, hitXZ.z, dMode === 'follow_button' ? 'follow_button' : 'custom_xz');
                    }
                }

                window.updateAiBoardRollBtnPreview();
            };

            const onPointerUp = () => {
                if (dragging) {
                    dragging = false;
                    station.style.cursor = 'grab';
                    if (studioState.controls) studioState.controls.enabled = true;
                }
            };

            station.addEventListener('mousedown', onPointerDown);
            window.addEventListener('mousemove', onPointerMove);
            window.addEventListener('mouseup', onPointerUp);
            station.addEventListener('touchstart', onPointerDown, { passive: false });
            window.addEventListener('touchmove', onPointerMove, { passive: false });
            window.addEventListener('touchend', onPointerUp);
        }

        // 2. Draggable 3D Dice Handle AND Direct 3D Mesh Raycast Dragging (Mouse + Touch iOS/Android)
        const diceHandle = document.getElementById('abs_preview_dice3d_handle');
        const canvasEl = document.getElementById('abs_three_canvas');
        if (viewport) {
            let draggingDice = false;

            const startDiceDrag = (e) => {
                draggingDice = true;
                if (diceHandle) diceHandle.style.cursor = 'grabbing';
                if (studioState.controls) studioState.controls.enabled = false;
                const pt = e.touches ? e.touches[0] : e;
                const hitXZ = projectClientPointToBoardXZ(pt.clientX, pt.clientY);
                if (hitXZ) {
                    applyStudioDiceWorldXZ(hitXZ.x, hitXZ.z, 'custom_xz');
                }
                e.stopPropagation();
                e.preventDefault();
            };

            const moveDiceDrag = (e) => {
                if (!draggingDice) return;
                const pt = e.touches ? e.touches[0] : e;
                const hitXZ = projectClientPointToBoardXZ(pt.clientX, pt.clientY);
                if (hitXZ) {
                    applyStudioDiceWorldXZ(hitXZ.x, hitXZ.z, 'custom_xz');
                }
            };

            const endDiceDrag = () => {
                if (draggingDice) {
                    draggingDice = false;
                    if (diceHandle) diceHandle.style.cursor = 'grab';
                    if (studioState.controls) studioState.controls.enabled = true;
                }
            };

            if (diceHandle) {
                diceHandle.addEventListener('mousedown', startDiceDrag);
                diceHandle.addEventListener('touchstart', startDiceDrag, { passive: false });
            }

            // Also allow clicking/touching directly on the 3D white dice meshes in the Three.js canvas!
            if (canvasEl) {
                const onCanvasDown = (e) => {
                    if (!studioState.camera || !studioState.diceMesh1 || !studioState.diceMesh2 || !window.THREE) return;
                    const pt = e.touches ? e.touches[0] : e;
                    const rect = canvasEl.getBoundingClientRect();
                    const ndcX = ((pt.clientX - rect.left) / rect.width) * 2 - 1;
                    const ndcY = -((pt.clientY - rect.top) / rect.height) * 2 + 1;
                    const rc = new THREE.Raycaster();
                    rc.setFromCamera(new THREE.Vector2(ndcX, ndcY), studioState.camera);
                    const hits = rc.intersectObjects([studioState.diceMesh1, studioState.diceMesh2], true);
                    if (hits && hits.length > 0) {
                        startDiceDrag(e);
                    }
                };
                canvasEl.addEventListener('mousedown', onCanvasDown);
                canvasEl.addEventListener('touchstart', onCanvasDown, { passive: false });
            }

            window.addEventListener('mousemove', moveDiceDrag);
            window.addEventListener('mouseup', endDiceDrag);
            window.addEventListener('touchmove', moveDiceDrag, { passive: false });
            window.addEventListener('touchend', endDiceDrag);
        }

        // 3. Resizable Center Empty Zone Handle (Mouse + Touch iOS/Android)
        const resizeHandle = document.getElementById('abs_center_zone_resize_handle');
        if (resizeHandle && viewport) {
            let resizingHole = false;
            let startX = 0, startY = 0;
            let origHoleCols = 6, origHoleRows = 3.5;

            const onResizeDown = (e) => {
                resizingHole = true;
                if (studioState.controls) studioState.controls.enabled = false;
                const pt = e.touches ? e.touches[0] : e;
                startX = pt.clientX;
                startY = pt.clientY;
                origHoleCols = parseFloat(document.getElementById('abs_hole_cols')?.value || '6');
                origHoleRows = parseFloat(document.getElementById('abs_hole_rows')?.value || '3.5');
                e.stopPropagation();
                e.preventDefault();
            };

            const onResizeMove = (e) => {
                if (!resizingHole) return;
                const pt = e.touches ? e.touches[0] : e;
                const dx = pt.clientX - startX;
                const dy = pt.clientY - startY;
                const colsMax = Math.max(2, parseInt(document.getElementById('abs_grid_cols')?.value || '12', 10) - 2);
                const rowsMax = Math.max(1.5, parseInt(document.getElementById('abs_grid_rows')?.value || '8', 10) - 2);

                const nextCols = Math.max(2, Math.min(colsMax, Math.round((origHoleCols + dx / 18) * 2) / 2));
                const nextRows = Math.max(1, Math.min(rowsMax, Math.round((origHoleRows + dy / 18) * 2) / 2));

                const inC = document.getElementById('abs_hole_cols');
                const inR = document.getElementById('abs_hole_rows');
                if (inC) inC.value = String(nextCols);
                if (inR) inR.value = String(nextRows);
                const lblC = document.getElementById('abs_lbl_hole_cols');
                const lblR = document.getElementById('abs_lbl_hole_rows');
                if (lblC) lblC.innerText = nextCols.toFixed(1);
                if (lblR) lblR.innerText = nextRows.toFixed(1);

                window.onHollowCenterConfigChange();
            };

            const onResizeUp = () => {
                if (resizingHole) {
                    resizingHole = false;
                    if (studioState.controls) studioState.controls.enabled = true;
                }
            };

            resizeHandle.addEventListener('mousedown', onResizeDown);
            window.addEventListener('mousemove', onResizeMove);
            window.addEventListener('mouseup', onResizeUp);
            resizeHandle.addEventListener('touchstart', onResizeDown, { passive: false });
            window.addEventListener('touchmove', onResizeMove, { passive: false });
            window.addEventListener('touchend', onResizeUp);
        }
    }

    // ============================================================
    // 📸 AI IMAGE PROCESSING & THEME EXTRACTION
    // ============================================================
    window.handleAiBoardImageUpload = function (event) {
        const file = event?.target?.files?.[0];
        if (!file) return;
        processUploadedBoardImageFile(file);
    };

    function rgbToHex(r, g, b) {
        const clamp = (n) => Math.max(0, Math.min(255, Math.round(n)));
        return '#' + [clamp(r), clamp(g), clamp(b)].map(x => x.toString(16).padStart(2, '0')).join('');
    }

    function rgbToHsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        const max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h = 0, s = 0, l = (max + min) / 2;
        if (max !== min) {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
        return { h: h * 360, s: s * 100, l: l * 100 };
    }

    function processUploadedBoardImageFile(file) {
        const reader = new FileReader();
        reader.onload = function (ev) {
            const rawDataUrl = ev.target.result;
            const img = new Image();
            img.onload = function () {
                // Resize image to reasonable WebGL texture size (512x512 max) so DB payload stays fast
                const texCanvas = document.createElement('canvas');
                texCanvas.width = 512;
                texCanvas.height = 512;
                const tCtx = texCanvas.getContext('2d');
                tCtx.drawImage(img, 0, 0, 512, 512);
                const compressedUrl = texCanvas.toDataURL('image/jpeg', 0.82);
                studioState.sourceImageUrl = compressedUrl;

                const prevWrap = document.getElementById('abs_image_preview_wrap');
                const prevEl = document.getElementById('abs_image_preview_el');
                if (prevWrap && prevEl) {
                    prevEl.src = compressedUrl;
                    prevWrap.style.display = 'block';
                }

                // Load into Three.js Texture
                if (window.THREE) {
                    const loader = new THREE.TextureLoader();
                    studioState.boardTextureObj = loader.load(compressedUrl, () => {
                        window.updateAiBoardStudioPreview();
                    });
                }

                // Analyze Image Pixels to Extract Dominant Color Palette & Mood
                analyzeBoardImageWithAI(img);
            };
            img.src = rawDataUrl;
        };
        reader.readAsDataURL(file);
    }

    function analyzeBoardImageWithAI(img) {
        const c = document.createElement('canvas');
        c.width = 64;
        c.height = 64;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, 64, 64);
        const data = ctx.getImageData(0, 0, 64, 64).data;

        let rSum = 0, gSum = 0, bSum = 0, count = 0;
        let vibrantSamples = [];

        for (let i = 0; i < data.length; i += 16) {
            const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
            if (a < 128) continue;
            rSum += r; gSum += g; bSum += b; count++;
            const hsl = rgbToHsl(r, g, b);
            if (hsl.s > 30 && hsl.l > 20 && hsl.l < 85) {
                vibrantSamples.push({ r, g, b, hsl, hex: rgbToHex(r, g, b) });
            }
        }

        if (count === 0) count = 1;
        const avgR = rSum / count, avgG = gSum / count, avgB = bSum / count;
        const avgHsl = rgbToHsl(avgR, avgG, avgB);

        vibrantSamples.sort((a, b) => b.hsl.s - a.hsl.s);
        const primaryAccent = vibrantSamples[0] || { r: 0, g: 229, b: 255, hex: '#00e5ff', hsl: { h: 190 } };
        const secondaryAccent = vibrantSamples[Math.floor(vibrantSamples.length * 0.35)] || { r: 56, g: 189, b: 248, hex: '#38bdf8' };
        const tertiaryAccent = vibrantSamples[Math.floor(vibrantSamples.length * 0.7)] || { r: 244, g: 63, b: 94, hex: '#f43f5e' };

        const darkBg = rgbToHex(avgR * 0.18, avgG * 0.18, avgB * 0.22);
        const tileEven = rgbToHex(avgR * 0.35, avgG * 0.35, avgB * 0.42);
        const tileOdd = rgbToHex(avgR * 0.52, avgG * 0.52, avgB * 0.60);

        studioState.extractedPalette = [
            darkBg, tileEven, tileOdd, primaryAccent.hex, secondaryAccent.hex, tertiaryAccent.hex
        ];

        // Determine AI Theme Mood & Suggest City Naming Style + Particle FX
        let moodName = '🌌 Cyber Neon Metropolis';
        let suggestedCityStyle = 'cyber_galaxy';
        let suggestedParticle = 'cyber_sparks';

        const h = primaryAccent.hsl.h || avgHsl.h;
        if (h >= 32 && h <= 68) {
            moodName = '🛕 อาณาจักรวิหารทองคำ (Golden Dynasty)';
            suggestedCityStyle = 'mythic_kingdom';
            suggestedParticle = 'golden_dust';
        } else if (h < 32 || h >= 335) {
            moodName = '🌋 สมรภูมิเพลิงลาวา (Volcanic Crimson)';
            suggestedCityStyle = 'mythic_kingdom';
            suggestedParticle = 'fire_embers';
        } else if (h > 68 && h <= 165) {
            moodName = '🌿 มหานครมรกตหิมพานต์ (Emerald Sanctuary)';
            suggestedCityStyle = 'thai_famous';
            suggestedParticle = 'emerald_orbs';
        } else if (h > 165 && h <= 250) {
            moodName = '❄️ คริสตัลไซเบอร์สเปซ (Crystal Cyber)';
            suggestedCityStyle = 'world_metropolis';
            suggestedParticle = 'snow_crystal';
        }

        // Apply to inputs
        const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
        setVal('abs_col_bg', darkBg);
        setVal('abs_col_even', tileEven);
        setVal('abs_col_odd', tileOdd);
        setVal('abs_col_border', primaryAccent.hex);
        setVal('abs_col_ladder', secondaryAccent.hex);
        setVal('abs_col_snake', tertiaryAccent.hex);
        setVal('abs_fx_particle_type', suggestedParticle);
        setVal('abs_ai_city_style', suggestedCityStyle);

        const nameInput = document.getElementById('abs_board_name');
        if (nameInput && (nameInput.value.includes('มหานครไซเบอร์') || nameInput.value.includes('กระดาน AI'))) {
            nameInput.value = `${moodName} (AI 3D)`;
        }

        // Show Analysis Box
        const box = document.getElementById('abs_ai_analysis_box');
        const moodEl = document.getElementById('abs_ai_detected_mood');
        const swatchesEl = document.getElementById('abs_ai_palette_swatches');
        if (box) box.style.display = 'block';
        if (moodEl) moodEl.innerText = moodName;
        if (swatchesEl) {
            swatchesEl.innerHTML = studioState.extractedPalette.map(hex => `
                <span style="display:inline-flex; align-items:center; gap:4px; background:rgba(0,0,0,0.45); padding:3px 7px; border-radius:6px; border:1px solid rgba(255,255,255,0.15);">
                    <i style="width:12px; height:12px; border-radius:3px; background:${hex}; display:inline-block;"></i>
                    <code style="font-size:10.5px; color:#e2e8f0;">${hex}</code>
                </span>
            `).join('');
        }

        window.updateAiBoardStudioPreview();
        if (typeof showToast === 'function') {
            showToast(`🤖 AI วิเคราะห์รูปภาพสำเร็จ! สร้างโทนสี "${moodName}" บนกระดาน 3D แล้ว`);
        }
    }

    window.aiRandomizeBoardThemeFromImage = function () {
        const randHex = () => '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        const presets = [
            { bg: '#050b16', even: '#0e1f38', odd: '#16325c', border: '#00e5ff', ladder: '#38bdf8', snake: '#f43f5e' },
            { bg: '#160d04', even: '#2c1c08', odd: '#422a0d', border: '#ffd700', ladder: '#facc15', snake: '#10b981' },
            { bg: '#170508', even: '#2e0b12', odd: '#46121d', border: '#ff3d00', ladder: '#fb923c', snake: '#c084fc' },
            { bg: '#041412', even: '#092c26', odd: '#11423a', border: '#10b981', ladder: '#34d399', snake: '#f59e0b' },
            { bg: '#11061c', even: '#230d38', odd: '#341452', border: '#d946ef', ladder: '#38bdf8', snake: '#f43f5e' }
        ];
        const pick = presets[Math.floor(Math.random() * presets.length)];
        document.getElementById('abs_col_bg').value = pick.bg;
        document.getElementById('abs_col_even').value = pick.even;
        document.getElementById('abs_col_odd').value = pick.odd;
        document.getElementById('abs_col_border').value = pick.border;
        document.getElementById('abs_col_ladder').value = pick.ladder || randHex();
        document.getElementById('abs_col_snake').value = pick.snake || randHex();
        window.updateAiBoardStudioPreview();
        if (typeof showToast === 'function') showToast('✨ AI สุ่มชุดสีและแสงนีออนใหม่ให้กระดาน 3D แล้ว!');
    };

    // ============================================================
    // 📐 BOARD SHAPE, DIMENSIONS & TILE COORDINATE GENERATOR
    // ============================================================
    window.setAiBoardDimensions = function (shape, cols, rows, total) {
        document.getElementById('abs_shape_type').value = shape;
        document.getElementById('abs_grid_cols').value = String(cols);
        document.getElementById('abs_grid_rows').value = String(rows);
        document.getElementById('abs_total_tiles').value = String(total);
        initDefaultCities(total);
        sanitizeSpecialTilesForTotal(total);
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    window.onAiBoardShapeChange = function (shape) {
        if (shape === 'rectangle') {
            document.getElementById('abs_grid_cols').value = '12';
            document.getElementById('abs_grid_rows').value = '8';
            document.getElementById('abs_total_tiles').value = '96';
        } else if (shape === 'square') {
            document.getElementById('abs_grid_cols').value = '10';
            document.getElementById('abs_grid_rows').value = '10';
            document.getElementById('abs_total_tiles').value = '100';
        } else {
            document.getElementById('abs_grid_cols').value = '10';
            document.getElementById('abs_grid_rows').value = '10';
            document.getElementById('abs_total_tiles').value = '100';
        }
        const total = parseInt(document.getElementById('abs_total_tiles').value || '100', 10);
        initDefaultCities(total);
        sanitizeSpecialTilesForTotal(total);
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    window.onAiGridSizeInputsChange = function () {
        const shape = document.getElementById('abs_shape_type').value;
        const cols = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_cols').value || '12', 10)));
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows').value || '8', 10)));
        if (shape === 'rectangle' || shape === 'square') {
            const calcTotal = Math.max(20, Math.min(200, cols * rows));
            document.getElementById('abs_total_tiles').value = String(calcTotal);
            initDefaultCities(calcTotal);
            sanitizeSpecialTilesForTotal(calcTotal);
        }
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    window.onAiTotalTilesChange = function () {
        const total = Math.max(20, Math.min(200, parseInt(document.getElementById('abs_total_tiles').value || '100', 10)));
        initDefaultCities(total);
        sanitizeSpecialTilesForTotal(total);
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    function sanitizeSpecialTilesForTotal(total) {
        const clampArr = (arr) => (arr || []).map(Number).filter(n => n > 1 && n < total);
        studioState.specialTiles.chanceTiles = clampArr(studioState.specialTiles.chanceTiles);
        studioState.specialTiles.taxTiles = clampArr(studioState.specialTiles.taxTiles);
        studioState.specialTiles.gambleTiles = clampArr(studioState.specialTiles.gambleTiles);
        studioState.specialTiles.destroyTiles = clampArr(studioState.specialTiles.destroyTiles);
        if (studioState.specialTiles.jailTile >= total) {
            studioState.specialTiles.jailTile = Math.max(2, Math.floor(total * 0.1));
        }
        populateSpecialTileInputsFromState();
    }

    // ============================================================
    // 🎁 SPECIAL TILES & CHANCE CARDS DISTRIBUTION
    // ============================================================
    function parseCsvNumbers(str, maxTile = 100) {
        return String(str || '')
            .split(',')
            .map(s => parseInt(s.trim(), 10))
            .filter(n => !isNaN(n) && n > 1 && n < maxTile);
    }

    function parsePairsString(str, maxTile = 100, isLadder = true) {
        const map = {};
        String(str || '').split(',').forEach(part => {
            const [a, b] = part.split(':').map(s => parseInt((s || '').trim(), 10));
            if (!isNaN(a) && !isNaN(b) && a > 1 && a < maxTile && b > 1 && b < maxTile && a !== b) {
                if (isLadder && b > a) map[a] = b;
                else if (!isLadder && a > b) map[a] = b;
            }
        });
        return map;
    }

    function formatPairsMap(map) {
        return Object.entries(map || {}).map(([k, v]) => `${k}:${v}`).join(', ');
    }

    function populateSpecialTileInputsFromState() {
        const st = studioState.specialTiles;
        const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
        setVal('abs_chance_count', (st.chanceTiles || []).length);
        setVal('abs_chance_tiles', (st.chanceTiles || []).join(', '));
        setVal('abs_tax_count', (st.taxTiles || []).length);
        setVal('abs_tax_tiles', (st.taxTiles || []).join(', '));
        setVal('abs_gamble_count', (st.gambleTiles || []).length);
        setVal('abs_gamble_tiles', (st.gambleTiles || []).join(', '));
        setVal('abs_destroy_count', (st.destroyTiles || []).length);
        setVal('abs_destroy_tiles', (st.destroyTiles || []).join(', '));
        setVal('abs_jail_tile', st.jailTile || 10);
        setVal('abs_ladders_text', formatPairsMap(st.ladders));
        setVal('abs_snakes_text', formatPairsMap(st.snakes));
    }

    window.syncSpecialTilesFromInputs = function () {
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        studioState.specialTiles.chanceTiles = parseCsvNumbers(document.getElementById('abs_chance_tiles')?.value, total);
        studioState.specialTiles.taxTiles = parseCsvNumbers(document.getElementById('abs_tax_tiles')?.value, total);
        studioState.specialTiles.gambleTiles = parseCsvNumbers(document.getElementById('abs_gamble_tiles')?.value, total);
        studioState.specialTiles.destroyTiles = parseCsvNumbers(document.getElementById('abs_destroy_tiles')?.value, total);
        studioState.specialTiles.jailTile = Math.max(2, Math.min(total - 1, parseInt(document.getElementById('abs_jail_tile')?.value || '10', 10)));
        studioState.specialTiles.ladders = parsePairsString(document.getElementById('abs_ladders_text')?.value, total, true);
        studioState.specialTiles.snakes = parsePairsString(document.getElementById('abs_snakes_text')?.value, total, false);

        document.getElementById('abs_chance_count').value = String(studioState.specialTiles.chanceTiles.length);
        document.getElementById('abs_tax_count').value = String(studioState.specialTiles.taxTiles.length);
        document.getElementById('abs_gamble_count').value = String(studioState.specialTiles.gambleTiles.length);
        document.getElementById('abs_destroy_count').value = String(studioState.specialTiles.destroyTiles.length);

        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    window.aiUpdateSpecialTileCount = function (type, countVal) {
        const count = Math.max(0, Math.min(25, parseInt(countVal || '0', 10)));
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        const used = new Set([1, total, studioState.specialTiles.jailTile || 10]);

        if (type !== 'chance') studioState.specialTiles.chanceTiles.forEach(t => used.add(t));
        if (type !== 'tax') studioState.specialTiles.taxTiles.forEach(t => used.add(t));
        if (type !== 'gamble') studioState.specialTiles.gambleTiles.forEach(t => used.add(t));
        if (type !== 'destroy') studioState.specialTiles.destroyTiles.forEach(t => used.add(t));

        const picked = [];
        for (let i = 0; i < count; i++) {
            const segStart = Math.max(3, Math.floor(((i + 0.2) / Math.max(1, count)) * (total - 4)));
            const segEnd = Math.min(total - 2, Math.floor(((i + 0.85) / Math.max(1, count)) * (total - 2)));
            let candidate = Math.floor((segStart + segEnd) / 2);
            let tries = 0;
            while (used.has(candidate) && tries < 50) {
                candidate = Math.floor(Math.random() * (total - 4)) + 2;
                tries++;
            }
            if (!used.has(candidate)) {
                used.add(candidate);
                picked.push(candidate);
            }
        }
        picked.sort((a, b) => a - b);

        if (type === 'chance') studioState.specialTiles.chanceTiles = picked;
        else if (type === 'tax') studioState.specialTiles.taxTiles = picked;
        else if (type === 'gamble') studioState.specialTiles.gambleTiles = picked;
        else if (type === 'destroy') studioState.specialTiles.destroyTiles = picked;

        populateSpecialTileInputsFromState();
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    window.aiAutoDistributeSpecialTiles = function () {
        const chCount = parseInt(document.getElementById('abs_chance_count')?.value || '5', 10);
        const txCount = parseInt(document.getElementById('abs_tax_count')?.value || '3', 10);
        const gmCount = parseInt(document.getElementById('abs_gamble_count')?.value || '3', 10);
        const dsCount = parseInt(document.getElementById('abs_destroy_count')?.value || '3', 10);

        window.aiUpdateSpecialTileCount('chance', chCount);
        window.aiUpdateSpecialTileCount('tax', txCount);
        window.aiUpdateSpecialTileCount('gamble', gmCount);
        window.aiUpdateSpecialTileCount('destroy', dsCount);
        if (typeof showToast === 'function') {
            showToast(`🎁 AI กระจายตำแหน่งการ์ดดวง (${chCount} ช่อง) และช่องพิเศษทั่วกระดานเรียบร้อย!`);
        }
    };

    window.aiRandomizeSnakesAndLaddersPairs = function () {
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        const used = new Set([
            1, total, studioState.specialTiles.jailTile || 10,
            ...studioState.specialTiles.chanceTiles,
            ...studioState.specialTiles.taxTiles,
            ...studioState.specialTiles.gambleTiles,
            ...studioState.specialTiles.destroyTiles
        ]);

        const ladders = {};
        const snakes = {};
        const pickFree = (min, max) => {
            const avail = [];
            for (let i = Math.max(2, min); i <= Math.min(total - 1, max); i++) {
                if (!used.has(i)) avail.push(i);
            }
            if (!avail.length) return null;
            return avail[Math.floor(Math.random() * avail.length)];
        };

        for (let i = 0; i < 7; i++) {
            const s = pickFree(Math.floor(total * (0.04 + i * 0.11)), Math.floor(total * (0.14 + i * 0.11)));
            if (!s) continue;
            used.add(s);
            const e = pickFree(s + 8, Math.min(total - 2, s + Math.floor(total * 0.28)));
            if (!e) { used.delete(s); continue; }
            used.add(e);
            ladders[s] = e;
        }

        for (let i = 0; i < 7; i++) {
            const h = pickFree(Math.floor(total * (0.25 + i * 0.10)), Math.floor(total * (0.35 + i * 0.10)));
            if (!h) continue;
            used.add(h);
            const t = pickFree(Math.max(2, h - Math.floor(total * 0.32)), h - 7);
            if (!t) { used.delete(h); continue; }
            used.add(t);
            snakes[h] = t;
        }

        studioState.specialTiles.ladders = ladders;
        studioState.specialTiles.snakes = snakes;
        populateSpecialTileInputsFromState();
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
        if (typeof showToast === 'function') showToast('🪜🐍 สุ่มตำแหน่งบันไดและงูใหม่เรียบร้อย!');
    };

    // ============================================================
    // 🏙️ AI CITY NAME GENERATOR & TILE-BY-TILE EDITOR
    // ============================================================
    window.aiGenerateBoardCityNames = async function (shuffle = false) {
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        const style = document.getElementById('abs_ai_city_style')?.value || 'thai_famous';
        const prefix = document.getElementById('abs_ai_city_prefix')?.value || '';

        try {
            const res = await fetch('admin_panel.php?api=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'ai_generate_city_names',
                    total_tiles: total,
                    style: style,
                    custom_prefix: prefix,
                    shuffle: shuffle
                })
            }).then(r => r.json());

            if (res && res.status === 'success' && res.cities) {
                studioState.cities = res.cities;
                window.renderAiBoardCityEditorGrid();
                window.updateAiBoardStudioPreview();
                if (typeof showToast === 'function') showToast(`🤖 ${res.message}`);
            }
        } catch (err) {
            console.error('aiGenerateBoardCityNames error:', err);
        }
    };

    function getTileRoleInfo(t, total) {
        const st = studioState.specialTiles;
        if (t === 1) return { role: 'START', badge: '🚩 START', color: '#00e5ff' };
        if (t === total) return { role: 'GOAL', badge: '🏆 เส้นชัย', color: '#10b981' };
        if (t === Number(st.jailTile)) return { role: 'JAIL', badge: '⛓️ คุกเกาะร้าง', color: '#94a3b8' };
        if ((st.chanceTiles || []).includes(t)) return { role: 'CHANCE', badge: '🎁 การ์ดดวง', color: '#fbbf24' };
        if ((st.taxTiles || []).includes(t)) return { role: 'TAX', badge: '💸 ภาษี', color: '#f87171' };
        if ((st.gambleTiles || []).includes(t)) return { role: 'GAMBLE', badge: '🎰 เสี่ยงโชค', color: '#c084fc' };
        if ((st.destroyTiles || []).includes(t)) return { role: 'DESTROY', badge: '💥 ลบเมือง', color: '#fb7185' };
        if (st.ladders && st.ladders[t]) return { role: 'LADDER', badge: `🪜 ขึ้น ${st.ladders[t]}`, color: '#38bdf8' };
        if (st.snakes && st.snakes[t]) return { role: 'SNAKE', badge: `🐍 ลง ${st.snakes[t]}`, color: '#f43f5e' };
        return { role: 'NORMAL', badge: '🏙️ เมือง', color: '#64748b' };
    }

    window.renderAiBoardCityEditorGrid = function () {
        const container = document.getElementById('abs_city_editor_grid');
        if (!container) return;
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        const search = (document.getElementById('abs_city_search')?.value || '').trim().toLowerCase();
        const filterType = document.getElementById('abs_city_filter_type')?.value || 'ALL';

        let html = '';
        for (let i = 1; i <= total; i++) {
            const cityName = studioState.cities[i] || `เมือง #${i}`;
            const info = getTileRoleInfo(i, total);

            if (search && !String(i).includes(search) && !cityName.toLowerCase().includes(search)) {
                continue;
            }
            if (filterType === 'CHANCE' && info.role !== 'CHANCE') continue;
            if (filterType === 'SPECIAL' && info.role === 'NORMAL') continue;
            if (filterType === 'NORMAL' && info.role !== 'NORMAL') continue;

            const isChance = info.role === 'CHANCE';
            html += `
                <div style="background:rgba(15,23,42,0.85); border:1px solid ${isChance ? '#fbbf24' : 'rgba(255,255,255,0.12)'}; border-radius:8px; padding:6px 8px; display:flex; flex-direction:column; gap:4px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:11px; font-weight:900; color:#fff;">#${i}</span>
                        <button type="button" onclick="window.toggleTileChanceCard(${i})" title="คลิกเพื่อสลับเป็นช่องการ์ดดวง"
                            style="background:rgba(0,0,0,0.4); border:1px solid ${info.color}; color:${info.color}; border-radius:999px; font-size:9.5px; padding:1px 6px; cursor:pointer; font-weight:700;">
                            ${info.badge}
                        </button>
                    </div>
                    <input type="text" value="${esc(cityName)}" onchange="window.updateSingleTileCityName(${i}, this.value)"
                        style="width:100%; padding:4px 6px; font-size:11.5px; background:rgba(0,0,0,0.45); border:1px solid rgba(255,255,255,0.12); border-radius:5px; color:#e2e8f0; font-weight:600;">
                </div>
            `;
        }
        container.innerHTML = html || '<div style="grid-column:1/-1; text-align:center; color:#94a3b8; padding:16px;">ไม่พบช่องที่ค้นหา</div>';
    };

    window.updateSingleTileCityName = function (tileNum, newName) {
        studioState.cities[tileNum] = String(newName || '').trim() || `เมือง #${tileNum}`;
        window.updateAiBoardStudioPreview();
    };

    window.toggleTileChanceCard = function (tileNum) {
        const total = parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10);
        if (tileNum <= 1 || tileNum >= total) return;
        const list = studioState.specialTiles.chanceTiles || [];
        const idx = list.indexOf(tileNum);
        if (idx >= 0) {
            list.splice(idx, 1);
            if (typeof showToast === 'function') showToast(`ยกเลิกการ์ดดวงที่ช่อง #${tileNum} แล้ว`);
        } else {
            list.push(tileNum);
            list.sort((a, b) => a - b);
            if (typeof showToast === 'function') showToast(`🎁 ตั้งช่อง #${tileNum} เป็นช่องการ์ดดวงแล้ว!`);
        }
        studioState.specialTiles.chanceTiles = list;
        populateSpecialTileInputsFromState();
        window.renderAiBoardCityEditorGrid();
        window.updateAiBoardStudioPreview();
    };

    // ============================================================
    // 🎲 ROLL BUTTON & 3D DICE POSITION PREVIEW & CONFIG
    // ============================================================
    window.onRollPresetChange = function () {
        const preset = document.getElementById('abs_roll_preset')?.value || 'bottom_center';
        const syncDice = document.getElementById('abs_sync_dice_with_btn')?.checked;
        if (preset === 'center_board' && syncDice) {
            const dSel = document.getElementById('abs_dice3d_pos');
            const xInput = document.getElementById('abs_dice3d_x');
            const zInput = document.getElementById('abs_dice3d_z');
            const xLbl = document.getElementById('abs_lbl_dice3d_x');
            const zLbl = document.getElementById('abs_lbl_dice3d_z');
            if (dSel) dSel.value = 'board_center';
            if (xInput) xInput.value = '0';
            if (zInput) zInput.value = '0';
            if (xLbl) xLbl.innerText = '0';
            if (zLbl) zLbl.innerText = '0';
            updateStudioDice3DMeshPositionsOnly();
        }
        window.updateAiBoardRollBtnPreview();
    };

    window.onDice3dPosModeChange = function () {
        const mode = document.getElementById('abs_dice3d_pos')?.value || 'front_center';
        const cols = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_cols')?.value || '12', 10)));
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows')?.value || '8', 10)));
        const tileSize = Math.max(3.5, Math.min(9.5, parseFloat(document.getElementById('abs_tile_size')?.value || '6.2')));
        const gap = 0.4;
        const totalW = cols * (tileSize + gap);
        const totalD = rows * (tileSize + gap);

        let wx = parseFloat(document.getElementById('abs_dice3d_x')?.value || '0');
        let wz = parseFloat(document.getElementById('abs_dice3d_z')?.value || '26');

        if (mode === 'front_center') {
            wx = 0;
            wz = Math.round((totalD / 2 + 4) * 2) / 2;
        } else if (mode === 'board_center') {
            wx = 0;
            wz = 0;
        } else if (mode === 'front_right') {
            wx = Math.round(totalW * 0.32 * 2) / 2;
            wz = Math.round((totalD / 2 + 3) * 2) / 2;
        } else if (mode === 'front_left') {
            wx = -Math.round(totalW * 0.32 * 2) / 2;
            wz = Math.round((totalD / 2 + 3) * 2) / 2;
        } else if (mode === 'follow_button') {
            const preset = document.getElementById('abs_roll_preset')?.value || 'bottom_center';
            if (preset === 'center_board') {
                wx = 0;
                wz = 0;
            } else {
                const offX = parseInt(document.getElementById('abs_roll_offset_x')?.value || '0', 10);
                const offY = parseInt(document.getElementById('abs_roll_offset_y')?.value || '0', 10);
                wx = Math.max(-34, Math.min(34, Math.round((offX * 0.095) * 2) / 2));
                wz = Math.max(-28, Math.min(34, Math.round((offY * 0.13) * 2) / 2));
            }
        }

        const xInput = document.getElementById('abs_dice3d_x');
        const zInput = document.getElementById('abs_dice3d_z');
        const xLbl = document.getElementById('abs_lbl_dice3d_x');
        const zLbl = document.getElementById('abs_lbl_dice3d_z');
        if (xInput) xInput.value = String(wx);
        if (zInput) zInput.value = String(wz);
        if (xLbl) xLbl.innerText = String(wx);
        if (zLbl) zLbl.innerText = String(wz);

        updateStudioDice3DMeshPositionsOnly();
    };

    window.moveDiceAndBtnToCenterNow = function () {
        const rollPreset = document.getElementById('abs_roll_preset');
        const offX = document.getElementById('abs_roll_offset_x');
        const offY = document.getElementById('abs_roll_offset_y');
        const lblX = document.getElementById('abs_lbl_roll_x');
        const lblY = document.getElementById('abs_lbl_roll_y');
        if (rollPreset) rollPreset.value = 'center_board';
        if (offX) offX.value = '0';
        if (offY) offY.value = '0';
        if (lblX) lblX.innerText = '0';
        if (lblY) lblY.innerText = '0';

        const dicePos = document.getElementById('abs_dice3d_pos');
        const dx = document.getElementById('abs_dice3d_x');
        const dz = document.getElementById('abs_dice3d_z');
        const ldx = document.getElementById('abs_lbl_dice3d_x');
        const ldz = document.getElementById('abs_lbl_dice3d_z');
        if (dicePos) dicePos.value = 'board_center';
        if (dx) dx.value = '0';
        if (dz) dz.value = '6';
        if (ldx) ldx.innerText = '0';
        if (ldz) ldz.innerText = '6';

        window.updateAiBoardRollBtnPreview();
        updateStudioDice3DMeshPositionsOnly();
        if (typeof showToast === 'function') {
            showToast('🎯 ย้ายปุ่มทอยเต๋าและลูกเต๋า 3D ทั้ง 2 ลูกมาไว้กลางกระดานแล้ว! (ลากปรับต่อได้)');
        }
    };

    window.setHollowStartRowQuick = function (rowNum) {
        const chk = document.getElementById('abs_hollow_center');
        const sel = document.getElementById('abs_hole_start_row');
        if (chk) chk.checked = true;
        if (sel) sel.value = String(rowNum);
        window.onHollowCenterConfigChange();
        if (typeof showToast === 'function') {
            showToast(rowNum > 0
                ? `📍 ตั้งค่าให้เริ่มว่างตั้งแต่ "แถวที่ ${rowNum}" เรียบร้อยแล้ว!`
                : `📍 ตั้งค่าให้เว้นว่างกึ่งกลางกระดานอัตโนมัติแล้ว!`);
        }
    };

    window.onHollowCenterConfigChange = function () {
        const isHollow = Boolean(document.getElementById('abs_hollow_center')?.checked);
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows')?.value || '10', 10)));
        const hCols = Math.round(parseFloat(document.getElementById('abs_hole_cols')?.value || '6'));
        const hRows = Math.round(parseFloat(document.getElementById('abs_hole_rows')?.value || '6'));
        const startRowVal = parseInt(document.getElementById('abs_hole_start_row')?.value || '2', 10);

        const effHoleRows = Math.max(1, Math.min(rows - 1, hRows));
        const rStart = startRowVal >= 1
            ? Math.max(0, Math.min(rows - 1, startRowVal - 1))
            : Math.max(0, Math.floor((rows - effHoleRows) / 2));
        const rEnd = Math.min(rows - 1, rStart + effHoleRows - 1);

        const summaryEl = document.getElementById('abs_hollow_range_summary');
        if (summaryEl) {
            summaryEl.innerText = isHollow
                ? `ว่างตั้งแต่ แถวที่ ${rStart + 1} ถึง แถวที่ ${rEnd + 1} (กว้าง ${hCols} ช่อง)`
                : 'ปิดโหมดเว้นว่าง (เต็มกระดาน)';
        }

        const badge = document.getElementById('abs_hollow_status_badge');
        if (badge) {
            if (isHollow) {
                badge.innerText = `🎯 ว่างแถว ${rStart + 1}-${rEnd + 1} (${hCols}x${rEnd - rStart + 1})`;
                badge.style.background = 'rgba(250,204,21,0.22)';
                badge.style.color = '#fde047';
                badge.style.borderColor = 'rgba(250,204,21,0.5)';
            } else {
                badge.innerText = '🧱 เต็มกระดาน (ไม่ว่าง)';
                badge.style.background = 'rgba(148,163,184,0.18)';
                badge.style.color = '#cbd5e1';
                badge.style.borderColor = 'rgba(148,163,184,0.3)';
            }
        }
        updateCenterZoneBoxOverlay();
        window.updateAiBoardStudioPreview();
    };

    window.quickCenterArenaSetup = function () {
        const chk = document.getElementById('abs_hollow_center');
        const hc = document.getElementById('abs_hole_cols');
        const hr = document.getElementById('abs_hole_rows');
        const lhc = document.getElementById('abs_lbl_hole_cols');
        const lhr = document.getElementById('abs_lbl_hole_rows');
        const sr = document.getElementById('abs_hole_start_row');
        if (chk) chk.checked = true;
        if (hc && parseFloat(hc.value) < 4) { hc.value = '6'; if (lhc) lhc.innerText = '6'; }
        if (hr && parseFloat(hr.value) < 3) { hr.value = '6'; if (lhr) lhr.innerText = '6'; }
        if (sr && !sr.value) sr.value = '2';

        window.moveDiceAndBtnToCenterNow();
        window.onHollowCenterConfigChange();
        if (typeof showToast === 'function') {
            showToast('✨ เปิดพื้นที่ว่างตรงกลางกระดาน + ดึงปุ่มทอย & ลูกเต๋า 3D มาไว้ตรงกลางเรียบร้อย!');
        }
    };

    window.quickSolidBoardSetup = function () {
        const chk = document.getElementById('abs_hollow_center');
        if (chk) chk.checked = false;
        window.onHollowCenterConfigChange();
        if (typeof showToast === 'function') {
            showToast('🧱 เปลี่ยนเป็นกระดานเต็มพื้นที่ (ตรงกลางไม่ว่าง) แล้ว');
        }
    };

    window.toggleHollowCenterQuick = function () {
        const chk = document.getElementById('abs_hollow_center');
        if (!chk) return;
        chk.checked = !chk.checked;
        window.onHollowCenterConfigChange();
        if (typeof showToast === 'function') {
            showToast(chk.checked ? '🔳 เปิดช่องว่างตรงกลางกระดานแล้ว (ลากมุมขวาล่างเพื่อปรับขนาดได้)' : '🧱 ปิดช่องว่างตรงกลาง (เต็มกระดาน) แล้ว');
        }
    };

    function updateCenterZoneBoxOverlay() {
        const box = document.getElementById('abs_preview_center_zone_box');
        const lbl = document.getElementById('abs_center_zone_size_lbl');
        if (!box) return;
        const isHollow = Boolean(document.getElementById('abs_hollow_center')?.checked);
        if (!isHollow) {
            box.style.display = 'none';
            return;
        }
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows')?.value || '10', 10)));
        const hCols = Math.round(parseFloat(document.getElementById('abs_hole_cols')?.value || '6'));
        const hRows = Math.round(parseFloat(document.getElementById('abs_hole_rows')?.value || '6'));
        const startRowVal = parseInt(document.getElementById('abs_hole_start_row')?.value || '2', 10);
        const effHoleRows = Math.max(1, Math.min(rows - 1, hRows));
        const rStart = startRowVal >= 1
            ? Math.max(0, Math.min(rows - 1, startRowVal - 1))
            : Math.max(0, Math.floor((rows - effHoleRows) / 2));
        const rEnd = Math.min(rows - 1, rStart + effHoleRows - 1);
        const spanRows = rEnd - rStart + 1;

        // Shift overlay vertically according to which row the hollow space starts at
        const midRowIndex = (rStart + rEnd) / 2;
        const boardMidRow = (rows - 1) / 2;
        const rowOffsetPx = Math.round((boardMidRow - midRowIndex) * 14);

        box.style.display = 'flex';
        box.style.top = `calc(51% + ${rowOffsetPx}px)`;
        box.style.width = Math.round(Math.max(100, Math.min(480, hCols * 36))) + 'px';
        box.style.height = Math.round(Math.max(54, Math.min(260, spanRows * 25))) + 'px';
        if (lbl) lbl.innerText = `แถว ${rStart + 1}-${rEnd + 1} (${hCols}x${spanRows})`;
    }

    function updateStudioDice3DMeshPositionsOnly() {
        if (!studioState.diceMesh1 || !studioState.diceMesh2) return;

        const cols = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_cols')?.value || '12', 10)));
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows')?.value || '8', 10)));
        const tileSize = Math.max(3.5, Math.min(9.5, parseFloat(document.getElementById('abs_tile_size')?.value || '6.2')));
        const gap = 0.4;
        const totalW = cols * (tileSize + gap);
        const totalD = rows * (tileSize + gap);

        const dPosMode = document.getElementById('abs_dice3d_pos')?.value || 'front_center';
        const dScalePct = parseInt(document.getElementById('abs_dice3d_scale')?.value || '100', 10);
        const dScale = Math.max(0.5, Math.min(2.0, dScalePct / 100));

        let dx = parseFloat(document.getElementById('abs_dice3d_x')?.value || '0');
        let dz = parseFloat(document.getElementById('abs_dice3d_z')?.value || '26');

        if (dPosMode === 'front_center') {
            dx = 0;
            dz = totalD / 2 + 4;
        } else if (dPosMode === 'board_center') {
            dx = 0;
            dz = 0;
        } else if (dPosMode === 'front_right') {
            dx = totalW * 0.32;
            dz = totalD / 2 + 3;
        } else if (dPosMode === 'front_left') {
            dx = -totalW * 0.32;
            dz = totalD / 2 + 3;
        } else if (dPosMode === 'follow_button') {
            const preset = document.getElementById('abs_roll_preset')?.value || 'bottom_center';
            const offX = parseInt(document.getElementById('abs_roll_offset_x')?.value || '0', 10);
            const offY = parseInt(document.getElementById('abs_roll_offset_y')?.value || '0', 10);
            if (preset === 'center_board') {
                dx = Math.max(-34, Math.min(34, offX * 0.095));
                dz = Math.max(-28, Math.min(34, offY * 0.13 + 5));
            } else {
                dx = Math.max(-34, Math.min(34, offX * 0.095));
                dz = Math.max(-28, Math.min(36, (totalD / 2 + 2) + offY * 0.11));
            }
        }

        const spacing = 2.8 * dScale;
        studioState.diceMesh1.position.set(dx - spacing, 2.2 * dScale, dz);
        studioState.diceMesh2.position.set(dx + spacing, 2.2 * dScale, dz);
        studioState.diceMesh1.scale.set(dScale, dScale, dScale);
        studioState.diceMesh2.scale.set(dScale, dScale, dScale);

        const badge = document.getElementById('abs_dice3d_pos_badge');
        if (badge) {
            const modeLabels = {
                front_center: '🎲 หน้ากระดาน',
                board_center: '🎯 กลางกระดาน 3D',
                follow_button: '🧲 เกาะติดปุ่มทอย',
                front_right: '↘️ มุมขวาล่าง',
                front_left: '↙️ มุมซ้ายล่าง',
                custom_xz: `🎲 พิกัด (${Math.round(dx)}, ${Math.round(dz)})`
            };
            badge.innerText = modeLabels[dPosMode] || `🎲 (${Math.round(dx)}, ${Math.round(dz)})`;
        }

        projectDice3DHandleOverlay();
    }

    function projectDice3DHandleOverlay() {
        const handle = document.getElementById('abs_preview_dice3d_handle');
        const viewport = document.getElementById('abs_preview_viewport');
        if (!handle || !viewport || !studioState.camera || !studioState.diceMesh1 || !studioState.diceMesh2 || !window.THREE) return;

        const mid = new THREE.Vector3()
            .addVectors(studioState.diceMesh1.position, studioState.diceMesh2.position)
            .multiplyScalar(0.5);
        mid.y += 2.6;

        const proj = mid.clone().project(studioState.camera);
        const w = viewport.clientWidth || 560;
        const h = viewport.clientHeight || 390;

        const px = (proj.x * 0.5 + 0.5) * w;
        const py = (-proj.y * 0.5 + 0.5) * h;

        const clampedX = Math.max(55, Math.min(w - 55, px));
        const clampedY = Math.max(38, Math.min(h - 18, py));
        handle.style.left = `${Math.round(clampedX)}px`;
        handle.style.top = `${Math.round(clampedY)}px`;
    }

    window.updateAiBoardRollBtnPreview = function () {
        const station = document.getElementById('abs_preview_dice_station');
        const badge = document.getElementById('abs_roll_pos_badge');
        if (!station) return;

        const preset = document.getElementById('abs_roll_preset')?.value || 'bottom_center';
        const offX = parseInt(document.getElementById('abs_roll_offset_x')?.value || '0', 10);
        const offY = parseInt(document.getElementById('abs_roll_offset_y')?.value || '0', 10);
        const scale = parseInt(document.getElementById('abs_roll_scale')?.value || '100', 10) / 100;

        // Reset positioning styles
        station.style.top = 'auto';
        station.style.bottom = 'auto';
        station.style.left = 'auto';
        station.style.right = 'auto';

        const presetLabels = {
            bottom_center: 'ล่างกึ่งกลาง',
            bottom_right: 'มุมขวาล่าง',
            bottom_left: 'มุมซ้ายล่าง',
            center_board: 'กลางกระดาน 3D',
            middle_right: 'ขอบขวากลางจอ',
            middle_left: 'ขอบซ้ายกลางจอ',
            top_center: 'บนกึ่งกลาง',
            custom_xy: `กำหนดเอง (${offX}, ${offY})`
        };
        if (badge) badge.innerText = presetLabels[preset] || preset;

        // Scale down offset slightly inside the 390px mini viewport
        const previewX = Math.round(offX * 0.45);
        const previewY = Math.round(offY * 0.45);

        if (preset === 'bottom_right') {
            station.style.bottom = '12px';
            station.style.right = '14px';
            station.style.transform = `translate(${previewX}px, ${previewY}px) scale(${scale})`;
        } else if (preset === 'bottom_left') {
            station.style.bottom = '12px';
            station.style.left = '14px';
            station.style.transform = `translate(${previewX}px, ${previewY}px) scale(${scale})`;
        } else if (preset === 'center_board') {
            station.style.top = '50%';
            station.style.left = '50%';
            station.style.transform = `translate(calc(-50% + ${previewX}px), calc(-50% + ${previewY}px)) scale(${scale})`;
        } else if (preset === 'middle_right') {
            station.style.top = '50%';
            station.style.right = '14px';
            station.style.transform = `translate(${previewX}px, calc(-50% + ${previewY}px)) scale(${scale})`;
        } else if (preset === 'middle_left') {
            station.style.top = '50%';
            station.style.left = '14px';
            station.style.transform = `translate(${previewX}px, calc(-50% + ${previewY}px)) scale(${scale})`;
        } else if (preset === 'top_center') {
            station.style.top = '42px';
            station.style.left = '50%';
            station.style.transform = `translate(calc(-50% + ${previewX}px), ${previewY}px) scale(${scale})`;
        } else {
            // bottom_center or custom_xy
            station.style.bottom = '12px';
            station.style.left = '50%';
            station.style.transform = `translate(calc(-50% + ${previewX}px), ${previewY}px) scale(${scale})`;
        }

        if ((document.getElementById('abs_dice3d_pos')?.value || '') === 'follow_button') {
            updateStudioDice3DMeshPositionsOnly();
        }
    };

    // ============================================================
    // 🌐 THREE.JS LIVE 3D BOARD PREVIEW ENGINE
    // ============================================================
    function createStudioDieFaceMaterials() {
        const pipCoords = {
            1: [[0.5, 0.5]],
            2: [[0.28, 0.28], [0.72, 0.72]],
            3: [[0.26, 0.26], [0.5, 0.5], [0.74, 0.74]],
            4: [[0.28, 0.28], [0.72, 0.28], [0.28, 0.72], [0.72, 0.72]],
            5: [[0.26, 0.26], [0.74, 0.26], [0.5, 0.5], [0.26, 0.74], [0.74, 0.74]],
            6: [[0.28, 0.24], [0.72, 0.24], [0.28, 0.5], [0.72, 0.5], [0.28, 0.76], [0.72, 0.76]]
        };
        const order = [3, 4, 1, 6, 2, 5];
        return order.map(val => {
            const c = document.createElement('canvas');
            c.width = 128;
            c.height = 128;
            const ctx = c.getContext('2d');
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, 128, 128);
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 6;
            ctx.strokeRect(3, 3, 122, 122);
            ctx.fillStyle = (val === 1 || val === 4) ? '#ef4444' : '#0f172a';
            (pipCoords[val] || []).forEach(([nx, ny]) => {
                ctx.beginPath();
                ctx.arc(nx * 128, ny * 128, val === 1 ? 16 : 11, 0, Math.PI * 2);
                ctx.fill();
            });
            return new THREE.MeshStandardMaterial({
                map: new THREE.CanvasTexture(c),
                roughness: 0.18,
                metalness: 0.1
            });
        });
    }

    function initStudioThreeJS() {
        const canvas = document.getElementById('abs_three_canvas');
        const viewport = document.getElementById('abs_preview_viewport');
        if (!canvas || !viewport || !window.THREE) return;

        const w = viewport.clientWidth || 560;
        const h = viewport.clientHeight || 390;

        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x060b16);

        const camera = new THREE.PerspectiveCamera(42, w / h, 0.1, 1000);
        camera.position.set(0, 58, 72);
        camera.lookAt(0, 0, 0);

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
        renderer.setSize(w, h);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

        let controls = null;
        if (THREE.OrbitControls) {
            controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.06;
            controls.maxPolarAngle = Math.PI / 2.08;
        }

        const ambLight = new THREE.AmbientLight(0xffffff, 0.9);
        scene.add(ambLight);
        const dirLight = new THREE.DirectionalLight(0xffffff, 1.3);
        dirLight.position.set(35, 80, 45);
        scene.add(dirLight);

        const boardGroup = new THREE.Group();
        const particlesGroup = new THREE.Group();
        const diceGroup = new THREE.Group();
        scene.add(boardGroup);
        scene.add(particlesGroup);
        scene.add(diceGroup);

        // Create 2 3D Dice inside preview with pip textures
        const dGeo = new THREE.BoxGeometry(3.4, 3.4, 3.4);
        const dMats1 = createStudioDieFaceMaterials();
        const dMats2 = createStudioDieFaceMaterials();
        const d1 = new THREE.Mesh(dGeo, dMats1);
        const d2 = new THREE.Mesh(dGeo, dMats2);
        d1.position.set(-2.8, 2.2, 26);
        d2.position.set(2.8, 2.2, 26);
        diceGroup.add(d1);
        diceGroup.add(d2);

        studioState.scene = scene;
        studioState.camera = camera;
        studioState.renderer = renderer;
        studioState.controls = controls;
        studioState.ambLight = ambLight;
        studioState.dirLight = dirLight;
        studioState.boardGroup = boardGroup;
        studioState.particlesGroup = particlesGroup;
        studioState.diceGroup = diceGroup;
        studioState.diceMesh1 = d1;
        studioState.diceMesh2 = d2;

        const animateStudio = () => {
            studioState.animFrameId = requestAnimationFrame(animateStudio);
            if (studioState.controls) studioState.controls.update();
            const t = performance.now() * 0.001;
            if (studioState.particlesGroup) {
                studioState.particlesGroup.rotation.y = t * 0.18;
            }
            projectDice3DHandleOverlay();
            renderer.render(scene, camera);
        };
        animateStudio();

        window.addEventListener('resize', () => {
            if (!viewport || !studioState.renderer || !studioState.camera) return;
            const nw = viewport.clientWidth || 560;
            const nh = viewport.clientHeight || 390;
            studioState.camera.aspect = nw / nh;
            studioState.camera.updateProjectionMatrix();
            studioState.renderer.setSize(nw, nh);
            projectDice3DHandleOverlay();
        });
    }

    function createStudioTileTexture(tileNum, cityName, roleInfo, bgHex, borderHex) {
        const c = document.createElement('canvas');
        c.width = 128;
        c.height = 128;
        const ctx = c.getContext('2d');

        ctx.fillStyle = bgHex;
        ctx.fillRect(0, 0, 128, 128);

        ctx.strokeStyle = roleInfo.role === 'NORMAL' ? borderHex : roleInfo.color;
        ctx.lineWidth = roleInfo.role === 'NORMAL' ? 4 : 7;
        ctx.strokeRect(4, 4, 120, 120);

        ctx.fillStyle = roleInfo.role === 'NORMAL' ? borderHex : roleInfo.color;
        ctx.font = 'bold 24px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(String(tileNum), 10, 28);

        if (roleInfo.role !== 'NORMAL') {
            ctx.font = 'bold 14px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(roleInfo.badge, 64, 64);
        }

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 17px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(String(cityName).slice(0, 10), 64, 114);

        return new THREE.CanvasTexture(c);
    }

    /**
     * Compute 3D (x, z, rotY, tileW) coordinates for all 1..total tiles, supporting both
     * solid boards and Hollow Center boards (`grid_cutout` with exact `holeStartRow` or `ring_loop`).
     */
    function computeStudioTileCoordinates(shape, cols, rows, total, tileSize, gap, isHollow, holeCols, holeRows, hollowMode, holeStartRow = 2) {
        const step = tileSize + gap;
        const coords = [];

        if (isHollow && hollowMode === 'ring_loop') {
            // Concentric rectangular perimeter rings outside the center hole
            const halfHoleW = Math.max(step * 1.4, (holeCols * step) / 2 + step * 0.6);
            const halfHoleD = Math.max(step * 1.1, (holeRows * step) / 2 + step * 0.6);
            const ringCount = total <= 48 ? 1 : 2;
            const ringTotals = ringCount === 1
                ? [total]
                : [Math.ceil(total * 0.56), total - Math.ceil(total * 0.56)];

            for (let rIdx = 0; rIdx < ringTotals.length; rIdx++) {
                const countInRing = ringTotals[rIdx];
                const ringOffset = (ringTotals.length - 1 - rIdx) * step * 1.05;
                const rx = halfHoleW + ringOffset;
                const rz = halfHoleD + ringOffset;
                const perim = 4 * (rx + rz);

                for (let k = 0; k < countInRing; k++) {
                    const u = k / countInRing;
                    const d = u * perim;
                    let x = 0, z = 0;
                    const wSpan = 2 * rx;
                    const dSpan = 2 * rz;
                    if (d < wSpan) {
                        x = -rx + d;
                        z = rz;
                    } else if (d < wSpan + dSpan) {
                        x = rx;
                        z = rz - (d - wSpan);
                    } else if (d < 2 * wSpan + dSpan) {
                        x = rx - (d - (wSpan + dSpan));
                        z = -rz;
                    } else {
                        x = -rx;
                        z = -rz + (d - (2 * wSpan + dSpan));
                    }
                    coords.push({ x, z, rotY: 0, tileW: tileSize });
                }
            }
            const tW = (halfHoleW + (ringTotals.length) * step) * 2;
            const tD = (halfHoleD + (ringTotals.length) * step) * 2;
            const hW = holeCols * step;
            const hD = holeRows * step;
            return {
                coords,
                totalW: tW,
                totalD: tD,
                holeW: hW,
                holeD: hD,
                holeXLeft: -hW / 2,
                holeXRight: hW / 2,
                holeZBack: -hD / 2,
                holeZFront: hD / 2
            };
        }

        if (isHollow && (shape === 'rectangle' || shape === 'square')) {
            // Exact row-based cutout: keep strictly `rows` rows (Row 1 at front, Row `rows` at back)
            // and start the hollow area at the exact row selected (`holeStartRow`, 1-indexed from front).
            const totalW = cols * step;
            const totalD = rows * step;
            const startZ = totalD / 2 - tileSize / 2;

            const effHoleCols = Math.max(2, Math.min(cols - 2, Math.round(holeCols)));
            const leftCols = Math.max(1, Math.floor((cols - effHoleCols) / 2));
            const rightCols = Math.max(1, cols - effHoleCols - leftCols);

            const effHoleRows = Math.max(1, Math.min(rows - 1, Math.round(holeRows)));
            const rStart = (holeStartRow >= 1)
                ? Math.max(0, Math.min(rows - 1, Math.round(holeStartRow) - 1))
                : Math.max(0, Math.floor((rows - effHoleRows) / 2));
            const rEnd = Math.min(rows - 1, rStart + effHoleRows - 1);

            const leftW = leftCols * step;
            const rightW = rightCols * step;
            const holeXLeft = -totalW / 2 + leftW;
            const holeXRight = totalW / 2 - rightW;
            const holeZFront = totalD / 2 - rStart * step;
            const holeZBack = totalD / 2 - (rEnd + 1) * step;

            // Allocate all `total` tiles proportionally across the `rows` rows
            const weights = [];
            let sumWeights = 0;
            for (let r = 0; r < rows; r++) {
                const isRowHollow = (r >= rStart && r <= rEnd);
                const w = isRowHollow ? (leftCols + rightCols) : cols;
                weights.push(w);
                sumWeights += w;
            }

            const rowTileCounts = [];
            let accWeight = 0;
            let prevTotal = 0;
            for (let r = 0; r < rows; r++) {
                accWeight += weights[r];
                const targetCum = Math.round((accWeight / sumWeights) * total);
                const cnt = Math.max(2, targetCum - prevTotal);
                rowTileCounts.push(cnt);
                prevTotal += cnt;
            }
            // Adjust last non-empty row so sum is exact `total`
            const diff = total - prevTotal;
            if (diff !== 0) {
                rowTileCounts[rows - 1] = Math.max(2, rowTileCounts[rows - 1] + diff);
            }

            for (let r = 0; r < rows; r++) {
                const z = startZ - r * step;
                const k = rowTileCounts[r];
                const isRowHollow = (r >= rStart && r <= rEnd);
                const rowPts = [];

                if (!isRowHollow) {
                    const sX = totalW / k;
                    const tW = Math.min(tileSize, Math.max(2.2, sX - gap));
                    for (let j = 0; j < k; j++) {
                        rowPts.push({
                            x: -totalW / 2 + sX * (j + 0.5),
                            z,
                            rotY: 0,
                            tileW: tW
                        });
                    }
                } else {
                    const kLeft = Math.max(1, Math.round(k * (leftCols / (leftCols + rightCols))));
                    const kRight = Math.max(1, k - kLeft);
                    const sLeft = leftW / kLeft;
                    const tWLeft = Math.min(tileSize, Math.max(2.2, sLeft - gap));
                    for (let m = 0; m < kLeft; m++) {
                        rowPts.push({
                            x: -totalW / 2 + sLeft * (m + 0.5),
                            z,
                            rotY: 0,
                            tileW: tWLeft
                        });
                    }
                    const sRight = rightW / kRight;
                    const tWRight = Math.min(tileSize, Math.max(2.2, sRight - gap));
                    for (let m = 0; m < kRight; m++) {
                        rowPts.push({
                            x: holeXRight + sRight * (m + 0.5),
                            z,
                            rotY: 0,
                            tileW: tWRight
                        });
                    }
                }

                if (r % 2 === 1) {
                    rowPts.reverse();
                }
                rowPts.forEach(pt => coords.push(pt));
            }

            return {
                coords,
                totalW,
                totalD,
                holeW: holeXRight - holeXLeft,
                holeD: holeZFront - holeZBack,
                holeXLeft,
                holeXRight,
                holeZBack,
                holeZFront,
                rStart,
                rEnd
            };
        }

        // Standard shapes (or hollow spiral/hexagon with inner hole radius)
        const totalW = cols * step;
        const totalD = rows * step;
        const startX = -totalW / 2 + tileSize / 2;
        const startZ = totalD / 2 - tileSize / 2;
        const minHollowRad = isHollow ? Math.max(holeCols, holeRows) * step * 0.42 : 0;

        for (let i = 1; i <= total; i++) {
            let x = 0, z = 0, rotY = 0;
            if (shape === 'spiral') {
                const u = (i - 1) / Math.max(1, total - 1);
                const angle = u * 3.8 * Math.PI * 2 - Math.PI / 2;
                const minR = isHollow ? Math.max(11, minHollowRad) : 3.2;
                const r = 35 - u * (35 - minR);
                x = r * Math.cos(angle);
                z = r * Math.sin(angle);
                rotY = -angle;
            } else if (shape === 'hexagon') {
                const r = Math.floor((i - 1) / cols);
                const cInRow = (i - 1) % cols;
                const c = (r % 2 === 0) ? cInRow : (cols - 1 - cInRow);
                const stepX = tileSize * 1.02;
                const stepZ = tileSize * 0.90;
                const stagger = (r % 2 === 1) ? stepX * 0.5 : 0;
                x = (-((cols - 1) / 2) * stepX) + c * stepX + stagger;
                z = (((rows - 1) / 2) * stepZ) - r * stepZ;
                if (isHollow && Math.abs(x) < (holeCols * tileSize * 0.48) && Math.abs(z) < (holeRows * tileSize * 0.48)) {
                    const pushAng = Math.atan2(z || 0.1, x || 0.1);
                    x = Math.cos(pushAng) * (holeCols * tileSize * 0.56);
                    z = Math.sin(pushAng) * (holeRows * tileSize * 0.56);
                }
            } else if (shape === 'diamond_ring') {
                const u = (i - 1) / Math.max(1, total);
                const angle = u * Math.PI * 2;
                const rx = totalW * 0.45 * (1 - Math.floor((i - 1) / 36) * 0.22);
                const rz = totalD * 0.45 * (1 - Math.floor((i - 1) / 36) * 0.22);
                x = Math.cos(angle) * Math.max(rx, minHollowRad);
                z = Math.sin(angle) * Math.max(rz, minHollowRad * 0.8);
            } else {
                const r = Math.floor((i - 1) / cols);
                const cInRow = (i - 1) % cols;
                const c = (r % 2 === 0) ? cInRow : (cols - 1 - cInRow);
                x = startX + c * step;
                z = startZ - r * step;
            }
            coords.push({ x, z, rotY, tileW: tileSize });
        }

        const hW = holeCols * step;
        const hD = holeRows * step;
        return {
            coords,
            totalW,
            totalD,
            holeW: hW,
            holeD: hD,
            holeXLeft: -hW / 2,
            holeXRight: hW / 2,
            holeZBack: -hD / 2,
            holeZFront: hD / 2
        };
    }

    function doesSegmentCrossHollowHole(p1, p2, holeXLeft, holeXRight, holeZBack, holeZFront) {
        const pad = 0.6;
        const x1 = holeXLeft + pad, x2 = holeXRight - pad;
        const z1 = holeZBack + pad, z2 = holeZFront - pad;
        if (x1 >= x2 || z1 >= z2) return false;
        for (let s = 1; s <= 9; s++) {
            const t = s / 10;
            const mx = p1.x + (p2.x - p1.x) * t;
            const mz = p1.z + (p2.z - p1.z) * t;
            if (mx > x1 && mx < x2 && mz > z1 && mz < z2) {
                return true;
            }
        }
        return false;
    }

    window.updateAiBoardStudioPreview = function () {
        if (!studioState.scene || !studioState.boardGroup || !window.THREE) return;

        const viewport = document.getElementById('abs_preview_viewport');
        if (viewport && studioState.renderer && viewport.clientWidth > 0) {
            studioState.camera.aspect = viewport.clientWidth / viewport.clientHeight;
            studioState.camera.updateProjectionMatrix();
            studioState.renderer.setSize(viewport.clientWidth, viewport.clientHeight);
        }

        const shape = document.getElementById('abs_shape_type')?.value || 'rectangle';
        const cols = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_cols')?.value || '12', 10)));
        const rows = Math.max(4, Math.min(20, parseInt(document.getElementById('abs_grid_rows')?.value || '8', 10)));
        const total = Math.max(20, Math.min(200, parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10)));
        const tileSize = Math.max(3.5, Math.min(9.5, parseFloat(document.getElementById('abs_tile_size')?.value || '6.2')));
        const gap = 0.4;

        const isHollow = Boolean(document.getElementById('abs_hollow_center')?.checked);
        const holeCols = Math.max(2, Math.min(16, parseFloat(document.getElementById('abs_hole_cols')?.value || '6')));
        const holeRows = Math.max(1, Math.min(14, parseFloat(document.getElementById('abs_hole_rows')?.value || '6')));
        const holeStartRow = parseInt(document.getElementById('abs_hole_start_row')?.value || '2', 10);
        const hollowMode = document.getElementById('abs_hollow_mode')?.value || 'grid_cutout';
        const hollowStyle = document.getElementById('abs_hollow_style')?.value || 'arena_tray';

        const colBg = document.getElementById('abs_col_bg')?.value || '#060b16';
        const colEven = document.getElementById('abs_col_even')?.value || '#0f203c';
        const colOdd = document.getElementById('abs_col_odd')?.value || '#173058';
        const colBorder = document.getElementById('abs_col_border')?.value || '#00e5ff';
        const colLadder = document.getElementById('abs_col_ladder')?.value || '#38bdf8';
        const colSnake = document.getElementById('abs_col_snake')?.value || '#f43f5e';
        const applyTex = document.getElementById('abs_apply_board_texture')?.checked;
        const lightPct = parseInt(document.getElementById('abs_fx_light_intensity')?.value || '150', 10) / 100;

        studioState.scene.background = new THREE.Color(colBg);
        if (studioState.dirLight) studioState.dirLight.intensity = lightPct;

        // Clear old board meshes
        while (studioState.boardGroup.children.length > 0) {
            studioState.boardGroup.remove(studioState.boardGroup.children[0]);
        }
        while (studioState.particlesGroup.children.length > 0) {
            studioState.particlesGroup.remove(studioState.particlesGroup.children[0]);
        }

        const layoutInfo = computeStudioTileCoordinates(
            shape, cols, rows, total, tileSize, gap,
            isHollow, holeCols, holeRows, hollowMode, holeStartRow
        );
        const { coords, totalW, totalD, holeXLeft, holeXRight, holeZBack, holeZFront } = layoutInfo;

        const frameMat = new THREE.MeshStandardMaterial({
            color: colEven,
            map: (applyTex && studioState.boardTextureObj) ? studioState.boardTextureObj : null,
            metalness: 0.7,
            roughness: 0.3
        });

        // 1. Base Frame (Solid vs Exact Row-Aligned Hollow Cutout Frame)
        if (isHollow && (shape === 'rectangle' || shape === 'square' || hollowMode === 'ring_loop')) {
            const outerXLeft = -totalW / 2 - 2.25;
            const outerXRight = totalW / 2 + 2.25;
            const outerZBack = -totalD / 2 - 2.25;
            const outerZFront = totalD / 2 + 2.25;
            const outerW = outerXRight - outerXLeft;

            const inX1 = Math.max(outerXLeft + 2, holeXLeft + 0.3);
            const inX2 = Math.min(outerXRight - 2, holeXRight - 0.3);
            const inZ1 = Math.max(outerZBack + 1.5, holeZBack + 0.3);
            const inZ2 = Math.min(outerZFront - 1.5, holeZFront - 0.3);

            const innerW = Math.max(4, inX2 - inX1);
            const innerD = Math.max(4, inZ2 - inZ1);
            const holeCenterX = (inX1 + inX2) / 2;
            const holeCenterZ = (inZ1 + inZ2) / 2;

            // Back frame beam (behind the hole)
            const dBack = inZ1 - outerZBack;
            if (dBack > 0.3) {
                const topBeam = new THREE.Mesh(new THREE.BoxGeometry(outerW, 2.0, dBack), frameMat);
                topBeam.position.set(0, -1.0, (outerZBack + inZ1) / 2);
                studioState.boardGroup.add(topBeam);
            }

            // Front frame beam (in front of the hole)
            const dFront = outerZFront - inZ2;
            if (dFront > 0.3) {
                const botBeam = new THREE.Mesh(new THREE.BoxGeometry(outerW, 2.0, dFront), frameMat);
                botBeam.position.set(0, -1.0, (inZ2 + outerZFront) / 2);
                studioState.boardGroup.add(botBeam);
            }

            // Left & Right frame beams
            const wLeft = inX1 - outerXLeft;
            if (wLeft > 0.3) {
                const leftBeam = new THREE.Mesh(new THREE.BoxGeometry(wLeft, 2.0, innerD), frameMat);
                leftBeam.position.set((outerXLeft + inX1) / 2, -1.0, holeCenterZ);
                studioState.boardGroup.add(leftBeam);
            }

            const wRight = outerXRight - inX2;
            if (wRight > 0.3) {
                const rightBeam = new THREE.Mesh(new THREE.BoxGeometry(wRight, 2.0, innerD), frameMat);
                rightBeam.position.set((inX2 + outerXRight) / 2, -1.0, holeCenterZ);
                studioState.boardGroup.add(rightBeam);
            }

            // Neon inner rim around the exact hollow opening
            const rimMat = new THREE.MeshBasicMaterial({ color: colBorder });
            const rimTop = new THREE.Mesh(new THREE.BoxGeometry(innerW + 0.6, 0.35, 0.35), rimMat);
            rimTop.position.set(holeCenterX, 0.15, inZ1);
            const rimBot = rimTop.clone();
            rimBot.position.set(holeCenterX, 0.15, inZ2);
            const rimLeft = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, innerD + 0.6), rimMat);
            rimLeft.position.set(inX1, 0.15, holeCenterZ);
            const rimRight = rimLeft.clone();
            rimRight.position.set(inX2, 0.15, holeCenterZ);
            studioState.boardGroup.add(rimTop, rimBot, rimLeft, rimRight);

            // Center floor style inside the hollow hole
            if (hollowStyle === 'arena_tray') {
                const trayMat = new THREE.MeshStandardMaterial({
                    color: colBg,
                    metalness: 0.85,
                    roughness: 0.2
                });
                const trayMesh = new THREE.Mesh(new THREE.BoxGeometry(innerW - 0.4, 0.5, innerD - 0.4), trayMat);
                trayMesh.position.set(holeCenterX, -0.75, holeCenterZ);
                studioState.boardGroup.add(trayMesh);
            } else if (hollowStyle === 'crystal_glass') {
                const glassMat = new THREE.MeshStandardMaterial({
                    color: colBorder,
                    transparent: true,
                    opacity: 0.22,
                    metalness: 0.9,
                    roughness: 0.1
                });
                const glassMesh = new THREE.Mesh(new THREE.BoxGeometry(innerW - 0.4, 0.3, innerD - 0.4), glassMat);
                glassMesh.position.set(holeCenterX, -0.35, holeCenterZ);
                studioState.boardGroup.add(glassMesh);
            }
        } else {
            let frameGeo;
            if (shape === 'spiral') {
                frameGeo = new THREE.CylinderGeometry(39, 41, 2.0, 48);
            } else if (shape === 'hexagon') {
                frameGeo = new THREE.CylinderGeometry(40, 42, 2.0, 6);
            } else {
                frameGeo = new THREE.BoxGeometry(totalW + 4.5, 2.0, totalD + 4.5);
            }
            const frameMesh = new THREE.Mesh(frameGeo, frameMat);
            frameMesh.position.y = -1.0;
            studioState.boardGroup.add(frameMesh);
        }

        // 2. Tiles
        studioState.tilePositions = {};
        for (let i = 1; i <= total; i++) {
            const pt = coords[i - 1] || { x: 0, z: 0, rotY: 0, tileW: tileSize };
            const { x, z, rotY } = pt;
            const tW = pt.tileW || tileSize;
            let tileGeo;

            if (shape === 'spiral' && hollowMode !== 'ring_loop') {
                tileGeo = new THREE.BoxGeometry(4.6, 0.8, 4.6);
            } else if (shape === 'hexagon' && hollowMode !== 'ring_loop') {
                tileGeo = new THREE.CylinderGeometry(tileSize * 0.52, tileSize * 0.52, 0.8, 6);
            } else if (shape === 'diamond_ring' && hollowMode !== 'ring_loop') {
                tileGeo = new THREE.BoxGeometry(tileSize * 0.82, 0.8, tileSize * 0.82);
            } else {
                tileGeo = new THREE.BoxGeometry(tW, 0.8, tileSize);
            }

            studioState.tilePositions[i] = new THREE.Vector3(x, 0, z);
            const roleInfo = getTileRoleInfo(i, total);
            const cityName = studioState.cities[i] || `เมือง #${i}`;
            const bgHex = (i % 2 === 0) ? colEven : colOdd;
            const topTex = createStudioTileTexture(i, cityName, roleInfo, bgHex, colBorder);

            const sideMat = new THREE.MeshStandardMaterial({ color: bgHex });
            const topMat = new THREE.MeshStandardMaterial({ map: topTex });

            const mesh = (shape === 'hexagon' && hollowMode !== 'ring_loop')
                ? new THREE.Mesh(tileGeo, [sideMat, topMat, sideMat])
                : new THREE.Mesh(tileGeo, [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
            mesh.position.set(x, 0, z);
            if (rotY) mesh.rotation.y = rotY;
            studioState.boardGroup.add(mesh);

            // 3D Chance Chest marker on Chance Tiles
            if (roleInfo.role === 'CHANCE') {
                const chest = new THREE.Mesh(
                    new THREE.BoxGeometry(1.6, 1.2, 1.2),
                    new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.8, roughness: 0.2 })
                );
                chest.position.set(x, 1.0, z);
                studioState.boardGroup.add(chest);
            }
        }

        // Helper to find nearest same-side tile so ladders/snakes don't cut across the hollow center
        const resolveNonCrossingTarget = (p1, p2Orig, startIdx, endIdx) => {
            if (!isHollow || !doesSegmentCrossHollowHole(p1, p2Orig, holeXLeft, holeXRight, holeZBack, holeZFront)) {
                return p2Orig;
            }
            // Pick a tile near endIdx that stays on the same side of the hollow opening
            let bestPos = p2Orig;
            let bestScore = Infinity;
            for (let cand = Math.max(2, endIdx - 12); cand <= Math.min(total - 1, endIdx + 12); cand++) {
                if (cand === startIdx) continue;
                const cp = studioState.tilePositions[cand];
                if (!cp) continue;
                if (!doesSegmentCrossHollowHole(p1, cp, holeXLeft, holeXRight, holeZBack, holeZFront)) {
                    const sc = Math.abs(cand - endIdx);
                    if (sc < bestScore) {
                        bestScore = sc;
                        bestPos = cp;
                    }
                }
            }
            return bestPos;
        };

        // 3. Ladders & Snakes 3D Connectors
        const ladderMat = new THREE.MeshStandardMaterial({ color: colLadder, emissive: colLadder, emissiveIntensity: 0.35 });
        Object.entries(studioState.specialTiles.ladders || {}).forEach(([s, e]) => {
            const p1 = studioState.tilePositions[Number(s)];
            const p2Raw = studioState.tilePositions[Number(e)];
            if (!p1 || !p2Raw) return;
            const p2 = resolveNonCrossingTarget(p1, p2Raw, Number(s), Number(e));
            if (isHollow && doesSegmentCrossHollowHole(p1, p2, holeXLeft, holeXRight, holeZBack, holeZFront)) return;
            const dist = p1.distanceTo(p2);
            const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
            const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, dist, 8), ladderMat);
            bar.position.set(mid.x, 0.75, mid.z);
            bar.lookAt(p2.x, 0.75, p2.z);
            bar.rotateX(Math.PI / 2);
            studioState.boardGroup.add(bar);
        });

        const snakeMat = new THREE.MeshStandardMaterial({ color: colSnake, emissive: colSnake, emissiveIntensity: 0.35 });
        Object.entries(studioState.specialTiles.snakes || {}).forEach(([h, t]) => {
            const p1 = studioState.tilePositions[Number(h)];
            const p2Raw = studioState.tilePositions[Number(t)];
            if (!p1 || !p2Raw) return;
            const p2 = resolveNonCrossingTarget(p1, p2Raw, Number(h), Number(t));
            if (isHollow && doesSegmentCrossHollowHole(p1, p2, holeXLeft, holeXRight, holeZBack, holeZFront)) return;
            const mid = new THREE.Vector3().lerpVectors(p1, p2, 0.5);
            mid.y = 2.8;
            const curve = new THREE.CatmullRomCurve3([
                new THREE.Vector3(p1.x, 1.0, p1.z),
                mid,
                new THREE.Vector3(p2.x, 0.6, p2.z)
            ]);
            const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 20, 0.45, 8, false), snakeMat);
            studioState.boardGroup.add(tube);
        });

        // 4. Floating Crystals / Particles FX
        const fxType = document.getElementById('abs_fx_particle_type')?.value || 'cyber_sparks';
        if (fxType !== 'none') {
            const pColorMap = {
                cyber_sparks: 0x00e5ff,
                golden_dust: 0xffd700,
                fire_embers: 0xff4500,
                snow_crystal: 0xa5f3fc,
                emerald_orbs: 0x10b981
            };
            const pCol = pColorMap[fxType] || 0x00e5ff;
            const pMat = new THREE.MeshBasicMaterial({ color: pCol });
            const pGeo = new THREE.OctahedronGeometry(0.45);
            for (let k = 0; k < 28; k++) {
                const pm = new THREE.Mesh(pGeo, pMat);
                const ang = (k / 28) * Math.PI * 2;
                const rad = 22 + (k % 3) * 10;
                pm.position.set(Math.cos(ang) * rad, 3 + (k % 5) * 2.2, Math.sin(ang) * rad);
                studioState.particlesGroup.add(pm);
            }
        }

        // 5. Reposition 3D Dice & Center Zone Box
        updateCenterZoneBoxOverlay();
        updateStudioDice3DMeshPositionsOnly();

        // Update Top Badges
        const rStartDisp = layoutInfo.rStart !== undefined ? (layoutInfo.rStart + 1) : holeStartRow;
        const rEndDisp = layoutInfo.rEnd !== undefined ? (layoutInfo.rEnd + 1) : (rStartDisp + Math.round(holeRows) - 1);
        const hollowTag = isHollow ? ` [ว่างแถว ${rStartDisp}-${rEndDisp} • กว้าง ${Math.round(holeCols)}]` : '';
        const shapeNames = {
            rectangle: `▭ สี่เหลี่ยมผืนผ้า ${cols}x${rows} (${total} ช่อง)${hollowTag}`,
            square: `🟩 สี่เหลี่ยมจัตุรัส ${cols}x${rows} (${total} ช่อง)${hollowTag}`,
            spiral: `🌀 วงกลมก้นหอย (${total} ช่อง)${hollowTag}`,
            hexagon: `⬡ หกเหลี่ยมรังผึ้ง (${total} ช่อง)${hollowTag}`,
            diamond_ring: `❖ วงแหวนเพชร (${total} ช่อง)${hollowTag}`
        };
        const tagShape = document.getElementById('abs_preview_tag_shape');
        const tagSpec = document.getElementById('abs_preview_tag_special');
        if (tagShape) tagShape.innerText = shapeNames[shape] || shape;
        if (tagSpec) tagSpec.innerText = `🎁 การ์ดดวง: ${(studioState.specialTiles.chanceTiles || []).length} ช่อง`;
    };

    window.resetStudioCameraAngle = function () {
        if (!studioState.camera || !studioState.controls) return;
        studioState.camera.position.set(0, 58, 72);
        studioState.controls.target.set(0, 0, 0);
        studioState.controls.update();
    };

    window.testRollOnStudio3DBoard = function () {
        const faces = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
        const v1 = Math.floor(Math.random() * 6) + 1;
        const v2 = Math.floor(Math.random() * 6) + 1;
        const d1El = document.getElementById('abs_sim_d1');
        const d2El = document.getElementById('abs_sim_d2');
        if (d1El) d1El.innerText = faces[v1 - 1];
        if (d2El) d2El.innerText = faces[v2 - 1];

        if (studioState.diceMesh1 && studioState.diceMesh2) {
            const baseY = studioState.diceMesh1.position.y || 2.2;
            let step = 0;
            const iv = setInterval(() => {
                step++;
                studioState.diceMesh1.rotation.x += 0.6;
                studioState.diceMesh1.rotation.y += 0.5;
                studioState.diceMesh2.rotation.x -= 0.5;
                studioState.diceMesh2.rotation.z += 0.6;
                studioState.diceMesh1.position.y = baseY + Math.sin((step / 12) * Math.PI) * 6;
                studioState.diceMesh2.position.y = baseY + Math.sin((step / 12) * Math.PI) * 6;
                if (step >= 12) {
                    clearInterval(iv);
                    studioState.diceMesh1.position.y = baseY;
                    studioState.diceMesh2.position.y = baseY;
                }
            }, 35);
        }
        if (typeof showToast === 'function') {
            showToast(`🎲 ทดสอบทอยลูกเต๋าบนกระดาน 3D: ได้แต้ม ${v1} + ${v2} = ${v1 + v2}!`);
        }
    };

    // ============================================================
    // 💾 SAVE, ACTIVATE IMMEDIATELY, CANCEL & MANAGE BOARDS
    // ============================================================
    function collectCurrentBoardPayload(forcePlayImmediately = false) {
        const total = Math.max(20, Math.min(200, parseInt(document.getElementById('abs_total_tiles')?.value || '100', 10)));
        return {
            action: 'save_custom_board',
            id: parseInt(document.getElementById('abs_board_id')?.value || '0', 10),
            board_code: document.getElementById('abs_board_code')?.value || '',
            board_name: document.getElementById('abs_board_name')?.value || 'กระดาน AI 3D ใหม่',
            shape_type: document.getElementById('abs_shape_type')?.value || 'rectangle',
            grid_cols: parseInt(document.getElementById('abs_grid_cols')?.value || '12', 10),
            grid_rows: parseInt(document.getElementById('abs_grid_rows')?.value || '8', 10),
            total_tiles: total,
            tile_size: parseFloat(document.getElementById('abs_tile_size')?.value || '6.2'),
            tile_gap: 0.4,
            source_image_url: studioState.sourceImageUrl || '',
            apply_board_texture: document.getElementById('abs_apply_board_texture')?.checked ? 1 : 0,
            theme_config: {
                bgColor: document.getElementById('abs_col_bg')?.value || '#060b16',
                fogColor: document.getElementById('abs_col_bg')?.value || '#060b16',
                tileEven: document.getElementById('abs_col_even')?.value || '#0f203c',
                tileOdd: document.getElementById('abs_col_odd')?.value || '#173058',
                border: document.getElementById('abs_col_border')?.value || '#00e5ff',
                ladder: document.getElementById('abs_col_ladder')?.value || '#38bdf8',
                snake: document.getElementById('abs_col_snake')?.value || '#f43f5e'
            },
            cities: studioState.cities,
            special_tiles: studioState.specialTiles,
            effects: {
                particleType: document.getElementById('abs_fx_particle_type')?.value || 'cyber_sparks',
                lightIntensity: parseInt(document.getElementById('abs_fx_light_intensity')?.value || '150', 10) / 100,
                tileBounceOnStep: Boolean(document.getElementById('abs_fx_step_bounce')?.checked),
                neonBorderGlow: Boolean(document.getElementById('abs_fx_neon_glow')?.checked),
                floatingCrystals: Boolean(document.getElementById('abs_fx_floating_gems')?.checked)
            },
            roll_btn_config: {
                preset: document.getElementById('abs_roll_preset')?.value || 'bottom_center',
                offsetX: parseInt(document.getElementById('abs_roll_offset_x')?.value || '0', 10),
                offsetY: parseInt(document.getElementById('abs_roll_offset_y')?.value || '0', 10),
                scale: parseInt(document.getElementById('abs_roll_scale')?.value || '100', 10),
                dice3dPos: document.getElementById('abs_dice3d_pos')?.value || 'front_center',
                diceWorldX: parseFloat(document.getElementById('abs_dice3d_x')?.value || '0'),
                diceWorldZ: parseFloat(document.getElementById('abs_dice3d_z')?.value || '26'),
                diceScale: parseInt(document.getElementById('abs_dice3d_scale')?.value || '100', 10),
                syncDiceWithBtn: Boolean(document.getElementById('abs_sync_dice_with_btn')?.checked),
                hollowCenter: Boolean(document.getElementById('abs_hollow_center')?.checked),
                centerHoleCols: parseFloat(document.getElementById('abs_hole_cols')?.value || '6'),
                centerHoleRows: parseFloat(document.getElementById('abs_hole_rows')?.value || '6'),
                holeStartRow: parseInt(document.getElementById('abs_hole_start_row')?.value || '2', 10),
                hollowMode: document.getElementById('abs_hollow_mode')?.value || 'grid_cutout',
                hollowStyle: document.getElementById('abs_hollow_style')?.value || 'arena_tray'
            },
            is_active: forcePlayImmediately ? 1 : (document.getElementById('abs_is_active')?.checked ? 1 : 0),
            is_default: forcePlayImmediately ? 1 : (document.getElementById('abs_is_default')?.checked ? 1 : 0)
        };
    }

    window.saveAiCustomBoard = async function (playImmediately = false) {
        try {
            const payload = collectCurrentBoardPayload(playImmediately);
            const res = await fetch('admin_panel.php?api=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(r => r.json());

            if (!res || res.status !== 'success') {
                if (typeof showToast === 'function') showToast('❌ ' + (res?.message || 'บันทึกกระดานไม่สำเร็จ'), 'error');
                return;
            }

            if (res.board_id) {
                document.getElementById('abs_board_id').value = String(res.board_id);
            }
            studioState.boardsList = res.boards || [];
            renderBoardsTableAndDropdown();

            if (playImmediately) {
                // Save active custom board ID into localStorage so opening index.html plays it immediately
                try {
                    localStorage.setItem('snake_active_custom_board_id', String(res.board_id));
                } catch (e) {}
                if (typeof showToast === 'function') {
                    showToast('🚀 บันทึกและเปิดใช้งานกระดาน 3D นี้เป็นกระดานหลักพร้อมเล่นทันที!');
                }
            } else {
                if (typeof showToast === 'function') showToast('✅ ' + res.message);
            }
        } catch (err) {
            console.error('saveAiCustomBoard error:', err);
            if (typeof showToast === 'function') showToast('❌ เกิดข้อผิดพลาดในการบันทึกกระดาน 3D', 'error');
        }
    };

    window.loadCustomBoardsListAdmin = async function () {
        try {
            const res = await fetch('admin_panel.php?api=1&action=get_custom_boards').then(r => r.json());
            if (res && res.status === 'success') {
                studioState.boardsList = res.boards || [];
                renderBoardsTableAndDropdown();
            }
        } catch (err) {
            console.error('loadCustomBoardsListAdmin error:', err);
        }
    };

    function renderBoardsTableAndDropdown() {
        const sel = document.getElementById('abs_existing_select');
        const curId = document.getElementById('abs_board_id')?.value || '0';
        if (sel) {
            sel.innerHTML = `<option value="0">➕ โหมด: สร้างกระดาน 3D ใหม่ด้วย AI</option>` +
                studioState.boardsList.map(b =>
                    `<option value="${b.id}" ${String(b.id) === String(curId) ? 'selected' : ''}>${b.is_default ? '⭐ ' : ''}${esc(b.board_name)} (${b.shape_type} ${b.grid_cols}x${b.grid_rows})</option>`
                ).join('');
        }

        const tbody = document.getElementById('abs_boards_table_body');
        if (!tbody) return;
        if (!studioState.boardsList.length) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#94a3b8;">ยังไม่มีกระดานที่สร้างไว้</td></tr>`;
            return;
        }

        const shapeBadgeMap = {
            rectangle: '▭ สี่เหลี่ยมผืนผ้า',
            square: '🟩 สี่เหลี่ยมจัตุรัส',
            spiral: '🌀 ก้นหอย',
            hexagon: '⬡ หกเหลี่ยม',
            diamond_ring: '❖ วงแหวนเพชร'
        };

        tbody.innerHTML = studioState.boardsList.map(b => {
            const chCount = (b.special_tiles?.chanceTiles || []).length;
            const rollPreset = b.roll_btn_config?.preset || 'bottom_center';
            const isHollow = Boolean(b.roll_btn_config?.hollowCenter);
            const hCols = b.roll_btn_config?.centerHoleCols || 6;
            const hRows = b.roll_btn_config?.centerHoleRows || 3.5;
            return `
                <tr>
                    <td>#${b.id}</td>
                    <td>
                        <div style="display:flex; align-items:center; gap:8px;">
                            ${b.source_image_url ? `<img src="${esc(b.source_image_url)}" style="width:36px; height:36px; border-radius:6px; object-fit:cover; border:1px solid #00e5ff;">` : `<div style="width:36px; height:36px; border-radius:6px; background:${esc(b.theme_config?.tileOdd || '#173058')}; border:1px solid ${esc(b.theme_config?.border || '#00e5ff')}; display:flex; align-items:center; justify-content:center;">🗺️</div>`}
                            <div>
                                <strong>${esc(b.board_name)}</strong>
                                ${b.is_default ? `<span class="badge" style="background:#facc15; color:#000; font-weight:900; margin-left:4px;">⭐ กระดานหลักตอนนี้</span>` : ''}
                                <div style="font-size:11px; color:#94a3b8;">code: ${esc(b.board_code)}</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge" style="background:rgba(56,189,248,0.18); color:#38bdf8;">${shapeBadgeMap[b.shape_type] || b.shape_type}</span>
                        ${isHollow ? `<span class="badge" style="background:rgba(250,204,21,0.2); color:#fde047; margin-left:4px;">🔳 เว้นกลาง ${hCols}x${hRows}</span>` : ''}
                        <div style="font-size:11.5px; color:#cbd5e1; margin-top:2px;">ขนาด ${b.grid_cols}x${b.grid_rows} (${b.total_tiles} ช่อง)</div>
                    </td>
                    <td style="font-size:12px;">
                        <span style="color:#fbbf24; font-weight:700;">🎁 การ์ดดวง: ${chCount} ช่อง</span>
                        <div style="font-size:11px; color:#94a3b8;">ช่อง: ${(b.special_tiles?.chanceTiles || []).slice(0, 6).join(', ')}</div>
                    </td>
                    <td style="font-size:12px; color:#00e5ff;">
                        🕹️ ปุ่ม: ${esc(rollPreset)}
                        <div style="font-size:10.5px; color:#fde047;">🎲 เต๋า 3D: ${esc(b.roll_btn_config?.dice3dPos || 'front_center')}</div>
                    </td>
                    <td>
                        ${b.is_active
                            ? `<span style="color:#34d399; font-weight:800;">🟢 เปิดใช้งาน</span>`
                            : `<span style="color:#94a3b8;">⏹️ ยกเลิก/ปิดอยู่</span>`}
                    </td>
                    <td style="white-space:nowrap;">
                        <button type="button" class="btn" style="padding:5px 10px; font-size:11.5px; background:linear-gradient(135deg,#10b981,#059669); color:#fff; font-weight:800;" onclick="window.activateAiBoardNow(${b.id}, true)">
                            🚀 ใช้เล่นทันที
                        </button>
                        ${b.is_active ? `
                            <button type="button" class="btn btn-danger" style="padding:5px 10px; font-size:11.5px;" onclick="window.toggleAiBoardStatus(${b.id}, 0, 0)">
                                ⏹️ ยกเลิก
                            </button>
                        ` : `
                            <button type="button" class="btn" style="padding:5px 10px; font-size:11.5px; background:#0284c7; color:#fff;" onclick="window.toggleAiBoardStatus(${b.id}, 1, 0)">
                                🟢 เปิดกลับ
                            </button>
                        `}
                        <button type="button" class="btn" style="padding:5px 10px; font-size:11.5px;" onclick="window.loadBoardIntoStudio(${b.id})">
                            ✏️ แก้ไข
                        </button>
                        <button type="button" class="btn btn-danger" style="padding:5px 8px; font-size:11.5px;" onclick="window.deleteAiCustomBoard(${b.id})">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    window.loadBoardIntoStudio = function (idVal) {
        const id = parseInt(idVal || '0', 10);
        if (!id) {
            window.resetAiBoardStudio();
            return;
        }
        const b = studioState.boardsList.find(x => Number(x.id) === id);
        if (!b) return;

        document.getElementById('abs_board_id').value = String(b.id);
        document.getElementById('abs_board_code').value = b.board_code || '';
        document.getElementById('abs_board_name').value = b.board_name || '';
        document.getElementById('abs_shape_type').value = b.shape_type || 'rectangle';
        document.getElementById('abs_grid_cols').value = String(b.grid_cols || 12);
        document.getElementById('abs_grid_rows').value = String(b.grid_rows || 8);
        document.getElementById('abs_total_tiles').value = String(b.total_tiles || 100);
        document.getElementById('abs_tile_size').value = String(b.tile_size || 6.2);
        document.getElementById('abs_apply_board_texture').checked = Boolean(b.apply_board_texture);
        document.getElementById('abs_is_active').checked = Boolean(b.is_active);
        document.getElementById('abs_is_default').checked = Boolean(b.is_default);

        studioState.sourceImageUrl = b.source_image_url || '';
        const prevWrap = document.getElementById('abs_image_preview_wrap');
        const prevEl = document.getElementById('abs_image_preview_el');
        if (studioState.sourceImageUrl && prevWrap && prevEl) {
            prevEl.src = studioState.sourceImageUrl;
            prevWrap.style.display = 'block';
            if (window.THREE) {
                studioState.boardTextureObj = new THREE.TextureLoader().load(studioState.sourceImageUrl, () => {
                    window.updateAiBoardStudioPreview();
                });
            }
        } else if (prevWrap) {
            prevWrap.style.display = 'none';
            studioState.boardTextureObj = null;
        }

        const th = b.theme_config || {};
        document.getElementById('abs_col_bg').value = th.bgColor || '#060b16';
        document.getElementById('abs_col_even').value = th.tileEven || '#0f203c';
        document.getElementById('abs_col_odd').value = th.tileOdd || '#173058';
        document.getElementById('abs_col_border').value = th.border || '#00e5ff';
        document.getElementById('abs_col_ladder').value = th.ladder || '#38bdf8';
        document.getElementById('abs_col_snake').value = th.snake || '#f43f5e';

        studioState.cities = Object.assign({}, b.cities || {});
        if (Object.keys(studioState.cities).length === 0) {
            initDefaultCities(b.total_tiles || 100);
        }

        studioState.specialTiles = Object.assign({
            chanceTiles: [8, 23, 45, 67, 85],
            taxTiles: [18, 52, 82],
            gambleTiles: [14, 62, 88],
            destroyTiles: [28, 56, 91],
            jailTile: 10,
            ladders: {},
            snakes: {}
        }, b.special_tiles || {});
        populateSpecialTileInputsFromState();

        const fx = b.effects || {};
        document.getElementById('abs_fx_particle_type').value = fx.particleType || 'cyber_sparks';
        const lPct = Math.round((fx.lightIntensity ?? 1.5) * 100);
        document.getElementById('abs_fx_light_intensity').value = String(lPct);
        document.getElementById('abs_lbl_light').innerText = lPct + '%';
        document.getElementById('abs_fx_step_bounce').checked = fx.tileBounceOnStep !== false;
        document.getElementById('abs_fx_neon_glow').checked = fx.neonBorderGlow !== false;
        document.getElementById('abs_fx_floating_gems').checked = fx.floatingCrystals !== false;

        const rb = b.roll_btn_config || {};
        document.getElementById('abs_roll_preset').value = rb.preset || 'bottom_center';
        document.getElementById('abs_roll_offset_x').value = String(rb.offsetX || 0);
        document.getElementById('abs_roll_offset_y').value = String(rb.offsetY || 0);
        document.getElementById('abs_roll_scale').value = String(rb.scale || 100);
        document.getElementById('abs_lbl_roll_x').innerText = String(rb.offsetX || 0);
        document.getElementById('abs_lbl_roll_y').innerText = String(rb.offsetY || 0);
        document.getElementById('abs_lbl_roll_scale').innerText = String(rb.scale || 100);

        document.getElementById('abs_dice3d_pos').value = rb.dice3dPos || 'front_center';
        const dwx = rb.diceWorldX !== undefined ? rb.diceWorldX : 0;
        const dwz = rb.diceWorldZ !== undefined ? rb.diceWorldZ : 26;
        const dsc = rb.diceScale !== undefined ? rb.diceScale : 100;
        if (document.getElementById('abs_dice3d_x')) document.getElementById('abs_dice3d_x').value = String(dwx);
        if (document.getElementById('abs_dice3d_z')) document.getElementById('abs_dice3d_z').value = String(dwz);
        if (document.getElementById('abs_dice3d_scale')) document.getElementById('abs_dice3d_scale').value = String(dsc);
        if (document.getElementById('abs_lbl_dice3d_x')) document.getElementById('abs_lbl_dice3d_x').innerText = String(dwx);
        if (document.getElementById('abs_lbl_dice3d_z')) document.getElementById('abs_lbl_dice3d_z').innerText = String(dwz);
        if (document.getElementById('abs_lbl_dice3d_scale')) document.getElementById('abs_lbl_dice3d_scale').innerText = String(dsc);
        if (document.getElementById('abs_sync_dice_with_btn')) document.getElementById('abs_sync_dice_with_btn').checked = rb.syncDiceWithBtn !== false;

        if (document.getElementById('abs_hollow_center')) document.getElementById('abs_hollow_center').checked = Boolean(rb.hollowCenter);
        const hCols = rb.centerHoleCols !== undefined ? rb.centerHoleCols : 6;
        const hRows = rb.centerHoleRows !== undefined ? rb.centerHoleRows : 6;
        const hStartRow = rb.holeStartRow !== undefined ? rb.holeStartRow : 2;
        if (document.getElementById('abs_hole_cols')) document.getElementById('abs_hole_cols').value = String(hCols);
        if (document.getElementById('abs_hole_rows')) document.getElementById('abs_hole_rows').value = String(hRows);
        if (document.getElementById('abs_hole_start_row')) document.getElementById('abs_hole_start_row').value = String(hStartRow);
        if (document.getElementById('abs_lbl_hole_cols')) document.getElementById('abs_lbl_hole_cols').innerText = String(hCols);
        if (document.getElementById('abs_lbl_hole_rows')) document.getElementById('abs_lbl_hole_rows').innerText = String(hRows);
        if (document.getElementById('abs_hollow_mode')) document.getElementById('abs_hollow_mode').value = rb.hollowMode || 'grid_cutout';
        if (document.getElementById('abs_hollow_style')) document.getElementById('abs_hollow_style').value = rb.hollowStyle || 'arena_tray';

        window.renderAiBoardCityEditorGrid();
        window.onHollowCenterConfigChange();
        window.updateAiBoardRollBtnPreview();
        if (typeof showToast === 'function') showToast(`📂 โหลดกระดาน "${b.board_name}" เข้าสู่สตูดิโอแล้ว`);
    };

    window.resetAiBoardStudio = function () {
        document.getElementById('abs_board_id').value = '0';
        document.getElementById('abs_board_code').value = '';
        document.getElementById('abs_board_name').value = '🏙️ มหานครไซเบอร์สี่เหลี่ยมผืนผ้า (AI 3D)';
        document.getElementById('abs_shape_type').value = 'rectangle';
        document.getElementById('abs_grid_cols').value = '12';
        document.getElementById('abs_grid_rows').value = '8';
        document.getElementById('abs_total_tiles').value = '100';
        if (document.getElementById('abs_hollow_center')) document.getElementById('abs_hollow_center').checked = false;
        if (document.getElementById('abs_hole_cols')) document.getElementById('abs_hole_cols').value = '6';
        if (document.getElementById('abs_hole_rows')) document.getElementById('abs_hole_rows').value = '6';
        if (document.getElementById('abs_hole_start_row')) document.getElementById('abs_hole_start_row').value = '2';
        if (document.getElementById('abs_lbl_hole_cols')) document.getElementById('abs_lbl_hole_cols').innerText = '6';
        if (document.getElementById('abs_lbl_hole_rows')) document.getElementById('abs_lbl_hole_rows').innerText = '6';
        if (document.getElementById('abs_dice3d_pos')) document.getElementById('abs_dice3d_pos').value = 'front_center';
        if (document.getElementById('abs_dice3d_x')) document.getElementById('abs_dice3d_x').value = '0';
        if (document.getElementById('abs_dice3d_z')) document.getElementById('abs_dice3d_z').value = '26';
        if (document.getElementById('abs_dice3d_scale')) document.getElementById('abs_dice3d_scale').value = '100';
        studioState.sourceImageUrl = '';
        studioState.boardTextureObj = null;
        const prevWrap = document.getElementById('abs_image_preview_wrap');
        if (prevWrap) prevWrap.style.display = 'none';
        initDefaultCities(100);
        window.renderAiBoardCityEditorGrid();
        window.onHollowCenterConfigChange();
        window.updateAiBoardRollBtnPreview();
    };

    window.toggleAiBoardStatus = async function (id, isActive, isDefault) {
        try {
            const res = await fetch('admin_panel.php?api=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'toggle_custom_board',
                    id: id,
                    is_active: isActive,
                    is_default: isDefault
                })
            }).then(r => r.json());
            if (res && res.status === 'success') {
                studioState.boardsList = res.boards || [];
                renderBoardsTableAndDropdown();
                if (!isActive) {
                    try {
                        if (localStorage.getItem('snake_active_custom_board_id') === String(id)) {
                            localStorage.removeItem('snake_active_custom_board_id');
                        }
                    } catch (e) {}
                }
                if (typeof showToast === 'function') showToast('✅ ' + res.message);
            }
        } catch (err) {
            console.error('toggleAiBoardStatus error:', err);
        }
    };

    window.activateAiBoardNow = async function (id, openGameTab = false) {
        await window.toggleAiBoardStatus(id, 1, 1);
        try {
            localStorage.setItem('snake_active_custom_board_id', String(id));
            localStorage.setItem('snake_board_layout', 'custom_' + id);
        } catch (e) {}
        if (openGameTab) {
            window.open('../index.html?custom_board=' + encodeURIComponent(id), '_blank');
        }
    };

    window.cancelAllDefaultAiBoards = async function () {
        try {
            const res = await fetch('admin_panel.php?api=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'cancel_all_default_boards' })
            }).then(r => r.json());
            if (res && res.status === 'success') {
                studioState.boardsList = res.boards || [];
                renderBoardsTableAndDropdown();
                try {
                    localStorage.removeItem('snake_active_custom_board_id');
                    if ((localStorage.getItem('snake_board_layout') || '').startsWith('custom_')) {
                        localStorage.setItem('snake_board_layout', 'square');
                    }
                } catch (e) {}
                if (typeof showToast === 'function') showToast('⏹️ ' + res.message);
            }
        } catch (err) {
            console.error('cancelAllDefaultAiBoards error:', err);
        }
    };

    window.deleteAiCustomBoard = async function (id) {
        if (!confirm('ยืนยันการลบกระดาน 3D นี้ออกจากระบบ?')) return;
        try {
            const res = await fetch('admin_panel.php?api=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete_custom_board', id: id })
            }).then(r => r.json());
            if (res && res.status === 'success') {
                studioState.boardsList = res.boards || [];
                renderBoardsTableAndDropdown();
                if (typeof showToast === 'function') showToast('🗑️ ' + res.message);
            }
        } catch (err) {
            console.error('deleteAiCustomBoard error:', err);
        }
    };
})();

