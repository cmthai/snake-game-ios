/**
 * admin/js/admin_gems.js
 * Gem & Jewelry Management Controller for Admin Panel
 */

window.currentAdminGems = [];
window.selectedCustomGemColor = null; // Custom hex color override

// Curated AI Crystal Color Palette for Randomizer
const AI_CRYSTAL_PALETTES = [
    { name: 'มรกตเทวะ (Emerald Divine)', color: '#10b981' },
    { name: 'ทับทิมเพลิงสวรรค์ (Heavenly Ruby)', color: '#ef4444' },
    { name: 'ไพลินมหาสมุทร (Ocean Sapphire)', color: '#3b82f6' },
    { name: 'อเมทิสต์มหาเวทย์ (Mystic Amethyst)', color: '#a855f7' },
    { name: 'บุษราคัมจักรพรรดิ (Imperial Topaz)', color: '#f59e0b' },
    { name: 'เพชรสีชมพูกุหลาบ (Rose Quartz)', color: '#f43f5e' },
    { name: 'ควอตซ์ฟ้านีออน (Cyber Quartz)', color: '#00e5ff' },
    { name: 'หยกหิมพานต์ (Mythic Jade)', color: '#14b8a6' },
    { name: 'อำพันเพลิงสุริยะ (Solar Amber)', color: '#f97316' },
    { name: 'เพชรดำออบซิเดียน (Obsidian Diamond)', color: '#64748b' },
    { name: 'ดวงดาราคอสมิก (Cosmic Star)', color: '#8b5cf6' },
    { name: 'ทองคำพญานาคินทร์ (Naga Gold)', color: '#ffd700' }
];

// Rich AI Gem & Skill Templates Categorized by Skill Category
const GEM_SKILL_TEMPLATES = {
    'PASS_OPPONENT_KICK': {
        names: [
            'อัญมณีเตะกระเด็นมังกรทมิฬ',
            'ผลึกพญานาคสะบัดหางมหาเวทย์',
            'คริสตัลถีบส่งข้ามมิติ',
            'มรกตเตะกระเด็นสถิตพญานาคราช',
            'อัญมณีวายุผลักไสคู่ต่อสู้',
            'ผลึกเตะส่งข้ามจักรวาล'
        ],
        codePrefix: 'gem_kick',
        skillNames: [
            'เตะคู่แข่งไปเมืองเราแบบสุ่ม เมื่อทอยผ่าน',
            'สะบัดหางกระเด็นไปเมืองสุ่ม',
            'เตะส่งข้ามมิติลงเมืองแพง',
            'วายุผลักไสลงแลนด์มาร์ค'
        ],
        descriptions: [
            'เมื่อทอยลูกเต๋าเดินผ่านตัวคู่แข่ง มีโอกาส {rate}% เตะคู่แข่งกระเด็นไปตกยังเมืองที่แพงที่สุดของเราทันที และบังคับจ่ายค่าผ่านทางเต็มจำนวน',
            'เมื่อเริ่มตาเดินหรือก้าวผ่านช่องที่มีคู่แข่ง มีโอกาส {rate}% สะบัดหางดีดตัวคู่แข่งไปตกยังแลนด์มาร์คของเราแบบสุ่ม และจ่ายค่าผ่านทาง 2 เท่า',
            'เมื่อเดินผ่านตัวหมากคู่ต่อสู้ มีโอกาส {rate}% บังคับเทเลพอร์ตคู่แข่งไปตกที่เมืองของเราแบบสุ่มทันที'
        ],
        shadowPrefix: 'shadow_gem_kick',
        suggestedShape: 'pentagon',
        suggestedColor: '#ef4444'
    },
    'FORCE_PAY_TOLL': {
        names: [
            'อัญมณีตราประทับทองคำมหาเศรษฐี',
            'ผลึกขูดรีดสัมปทานทอง',
            'คริสตัลเพิ่มค่าผ่านทางทวีคูณ',
            'บุษราคัมลงทัณฑ์เจ้าสัว',
            'อัญมณีพญานาคินทร์ทวงหนี้',
            'เพชรเรียกเก็บค่าผ่านทางสองเท่า'
        ],
        codePrefix: 'gem_force_toll',
        skillNames: [
            'บังคับจ่ายค่าผ่านทาง 2 เท่า',
            'เพิ่มค่าผ่านทางทวีคูณ',
            'ลงทัณฑ์คิดค่าปรับสองเท่า',
            'ขูดรีดสัมปทานเจ้าสัว'
        ],
        descriptions: [
            'เมื่อคู่แข่งตกเมืองของเรา มีโอกาส {rate}% เพิ่มค่าผ่านทางเป็น 2 เท่าทันที และยึดทองส่วนเกินเข้ากระเป๋าเรา',
            'เมื่อคู่แข่งเดินมาตกยังพื้นที่ของเรา มีโอกาส {rate}% บังคับเก็บค่าผ่านทางเพิ่มขึ้น 100% (2 เท่า) พร้อมยกเว้นส่วนลดของคู่แข่ง',
            'เมื่อมีผู้เล่นตกในเมืองของเรา มีโอกาส {rate}% เรียกเก็บค่าผ่านทางทวีคูณทันที'
        ],
        shadowPrefix: 'shadow_gem_toll',
        suggestedShape: 'square',
        suggestedColor: '#ffd700'
    },
    'BLOCK_CITY': {
        names: [
            'อัญมณีมหาปราการศิลาเทวะ',
            'ผลึกกำแพงเพลิงสุริยัน',
            'คริสตัลศิลาสะกัดกั้นพญานาคินทร์',
            'อัญมณียกเมืองปิดเส้นทาง',
            'หยกปราการหิรัญพิทักษ์',
            'ผลึกมหาปราการปิดกั้นขอบฟ้า'
        ],
        codePrefix: 'gem_block_city',
        skillNames: [
            'ยกเมืองกั้นทางเดิน',
            'กำแพงเมืองสกัดกั้น',
            'ปราการศิลาขวางทาง',
            'มหาปราการปิดกั้น'
        ],
        descriptions: [
            'เมื่อเริ่มตาเดิน มีโอกาส {rate}% ยกเมืองใดก็ได้ขึ้นเป็นปราการกั้นทางเดิน ไม่ให้คู่แข่งเดินผ่านได้',
            'เมื่อคู่แข่งกำลังจะเดินผ่านเมืองของเรา มีโอกาส {rate}% ก่อกำแพงเมืองปิดกั้นเพื่อบังคับให้คู่แข่งหยุดเดินที่ช่องนั้นทันที',
            'เมื่อเริ่มเทิร์น มีโอกาส {rate}% ยกสิ่งปลูกสร้างกั้นเป็นสิ่งกีดขวางบนเส้นทางเดิน'
        ],
        shadowPrefix: 'shadow_gem_block',
        suggestedShape: 'square',
        suggestedColor: '#10b981'
    },
    'SHIELD_SNAKE': {
        names: [
            'อัญมณีเกราะเพชรปราบอสรพิษ',
            'ผลึกเกล็ดมังกรทองคุ้มภัย',
            'คริสตัลโล่ศักดิ์สิทธิ์พญานาคินทร์',
            'หยกหิมพานต์ต้านพิษงู',
            'อัญมณีคุ้มกันหัวงูมหาเทวะ',
            'เพชรสลายแรงโน้มถ่วงงูยักษ์'
        ],
        codePrefix: 'gem_shield_snake',
        skillNames: [
            'เกราะคุ้มกันหัวงู',
            'เกล็ดมังกรต้านการสไลด์',
            'โล่ศักดิ์สิทธิ์สลายพิษงู',
            'คุ้มกันหัวงูไม่ไหลลง'
        ],
        descriptions: [
            'เมื่อเดินตกช่องหัวงู มีโอกาส {rate}% ป้องกันการสไลด์ตกลงหางงู และหยุดเดินที่ช่องหัวงูอย่างปลอดภัย',
            'เมื่อตกช่องกับดักงูพิษ มีโอกาส {rate}% สลายแรงดึงดูดของงูและสามารถเดินต่อในตาถัดไปได้ทันที',
            'เมื่อตกช่องหัวงูใดๆ บนกระดาน มีโอกาส {rate}% เกราะทำงาน ป้องกันการรูดลงไปช่องหาง'
        ],
        shadowPrefix: 'shadow_gem_shield',
        suggestedShape: 'triangle',
        suggestedColor: '#3b82f6'
    },
    'DICE_DOUBLE': {
        names: [
            'อัญมณีลูกเต๋าพันหน้ามหาโชค',
            'ผลึกเบิ้ลคู่สวรรค์ประทาน',
            'คริสตัลทอยเบิ้ลมหาลาภ',
            'เพชรดวงดาราทอยไม่รู้จบ',
            'อเมทิสต์ลูกเต๋าจักรวาล',
            'ลูกแก้วเบิ้ลโชคลาภเก้าทิศ'
        ],
        codePrefix: 'gem_double_dice',
        skillNames: [
            'ทอยเบิ้ลรับทองผ่านจุดสตาร์ท 200%',
            'เบิ้ลโชคดีรับโบนัสทองจุดสตาร์ท 200%',
            'แต้มคู่มหาลาภรับทองจุดสตาร์ท 200%'
        ],
        descriptions: [
            'เมื่อทอยลูกเต๋าได้แต้มเบิ้ล มีโอกาส {rate}% ได้รับทอง 200% ของจำนวนเงินเมื่อผ่านจุดสตาร์ททันที',
            'ทอยเบิ้ลมีโอกาส {rate}% รับโบนัสทอง 200% ของเงินเดือนผ่านจุดสตาร์ททันที'
        ],
        shadowPrefix: 'shadow_gem_double',
        suggestedShape: 'pentagon',
        suggestedColor: '#a855f7'
    },
    'TOLL_DISCOUNT': {
        names: [
            'อัญมณีตราผ่านทางอภัยโทษ',
            'ผลึกส่วนลดเศรษฐีมหาศาล',
            'คริสตัลยกเว้นค่าผ่านทางเทวะ',
            'เพชรเจรจาสงบศึกเจ้าเมือง',
            'อำพันลดหย่อนภาษีสวรรค์',
            'หยกประทานพรฟรีค่าผ่านทาง'
        ],
        codePrefix: 'gem_toll_discount',
        skillNames: [
            'ลดค่าผ่านทาง',
            'ขอยกเว้นค่าผ่านทาง',
            'เจรจาจ่ายครึ่งราคา',
            'ตราผ่านทางฟรี'
        ],
        descriptions: [
            'เมื่อเดินตกเมืองของคู่แข่ง มีโอกาส {rate}% ได้รับส่วนลดค่าผ่านทาง หรือยกเว้นค่าผ่านทางทั้งหมดในตานั้น',
            'เมื่อต้องจ่ายค่าผ่านทางในพื้นที่ฝ่ายตรงข้าม มีโอกาส {rate}% ลดค่าผ่านทางลงอย่างมาก',
            'เมื่อตกเมืองคู่แข่ง มีโอกาส {rate}% เจรจาสำเร็จ ไม่ต้องจ่ายค่าผ่านทางและได้รับเงินชดเชย'
        ],
        shadowPrefix: 'shadow_gem_discount',
        suggestedShape: 'triangle',
        suggestedColor: '#00e5ff'
    },
    'STEAL_GOLD': {
        names: [
            'อัญมณีแม่เหล็กดูดทรัพย์ข้ามมิติ',
            'ผลึกกรงเล็บพญามังกรฉกทอง',
            'คริสตัลโชคลาภปล้นทรัพย์',
            'อเมทิสต์มหาเวทย์ขโมยเหรียญ',
            'บุษราคัมดูดทองในกระดาน',
            'เพชรสุริยันปล้นชิงความมั่งคั่ง'
        ],
        codePrefix: 'gem_steal_gold',
        skillNames: [
            'ขโมยทองคู่แข่ง',
            'แม่เหล็กดูดทรัพย์',
            'ฉกทองเมื่อเดินชน',
            'กรงเล็บมังกรยึดทอง'
        ],
        descriptions: [
            'เมื่อเดินตกช่องเดียวกับคู่แข่ง มีโอกาส {rate}% ดูดทองของคู่แข่ง 30% มาเป็นของเราทันที',
            'เมื่อทอยผ่านหรือตกช่องเดียวกับคู่แข่ง มีโอกาส {rate}% ขโมยเงินทองในกระดานของคู่แข่งทันที',
            'เมื่อเดินชนคู่แข่ง มีโอกาส {rate}% ปล้นทองและทำให้คู่แข่งหยุดนิ่ง 1 เทิร์น'
        ],
        shadowPrefix: 'shadow_gem_steal',
        suggestedShape: 'pentagon',
        suggestedColor: '#f59e0b'
    },
    'CUSTOM': {
        names: [
            'อัญมณีมนต์ตราพญานาคราชมหาเวทย์',
            'ผลึกคริสตัลสุริยันจันทรา',
            'ดวงดาราคอสมิกเรืองรอง',
            'เพชรนิรันดร์กาลเทวะ',
            'มรกตเร้นลับหิมพานต์'
        ],
        codePrefix: 'gem_custom',
        skillNames: [
            'สกิลอัญมณีพิเศษ',
            'มนต์ตรามหาเวทย์',
            'พลังเร้นลับจักรวาล',
            'ปาฏิหาริย์ดวงดารา'
        ],
        descriptions: [
            'เมื่อเกิดเงื่อนไขในกระดาน มีโอกาส {rate}% สกิลพิเศษจะทำงานและมอบความได้เปรียบในการแข่งขันทันที',
            'ความสามารถพิเศษตามการกำหนดของผู้พัฒนา มีโอกาสทำงาน {rate}%',
            'มอบพลังเสริมพลังในการแข่งขันเมื่อทอยลูกเต๋า มีโอกาส {rate}% สกิลทำงาน'
        ],
        shadowPrefix: 'shadow_gem_custom',
        suggestedShape: 'triangle',
        suggestedColor: '#f43f5e'
    }
};

// AI Smart Generator: Analyzes skill category and auto-populates all inputs (fully editable by admin!)
window.aiAutoGenerateGemFields = function (forcedCategory = null) {
    const catEl = document.getElementById('gem-skill-category');
    const category = forcedCategory || (catEl ? catEl.value : 'PASS_OPPONENT_KICK');
    const tpl = GEM_SKILL_TEMPLATES[category] || GEM_SKILL_TEMPLATES['CUSTOM'];

    // Rate based on Grade
    const gradeEl = document.getElementById('gem-grade');
    const grade = gradeEl ? gradeEl.value : 'SS+';
    let defaultRate = 90;
    if (grade === 'SS+') defaultRate = Math.floor(Math.random() * 11) + 85; // 85-95%
    else if (grade === 'S+') defaultRate = Math.floor(Math.random() * 16) + 70; // 70-85%
    else defaultRate = Math.floor(Math.random() * 21) + 50; // 50-70%

    // Allow user existing rate if they typed one
    const rateEl = document.getElementById('gem-rate');
    const rate = (rateEl && rateEl.value) ? parseFloat(rateEl.value) : defaultRate;
    if (rateEl && !rateEl.value) rateEl.value = defaultRate;

    // Pick random name, skill name, description
    const randName = tpl.names[Math.floor(Math.random() * tpl.names.length)];
    const randSkillName = tpl.skillNames[Math.floor(Math.random() * tpl.skillNames.length)];
    const randDesc = tpl.descriptions[Math.floor(Math.random() * tpl.descriptions.length)].replace(/\{rate\}/g, rate);

    const randNum = String(Math.floor(Math.random() * 90) + 10);
    const itemCode = `${tpl.codePrefix}_${randNum}`;
    const shadowCode = `${tpl.shadowPrefix}_${randNum}`;

    // Fill form inputs (editable!)
    const nameInput = document.getElementById('gem-name');
    const codeInput = document.getElementById('gem-code');
    const skillNameInput = document.getElementById('gem-skill-name');
    const skillDescInput = document.getElementById('gem-skill-desc');
    const shadowCodeInput = document.getElementById('gem-shadow-code');
    const shapeEl = document.getElementById('gem-shape');
    const colorInput = document.getElementById('gem-custom-color');

    if (nameInput) nameInput.value = randName;
    if (codeInput) codeInput.value = itemCode;
    if (skillNameInput) skillNameInput.value = randSkillName;
    if (skillDescInput) skillDescInput.value = randDesc;
    if (shadowCodeInput) shadowCodeInput.value = shadowCode;

    // Also auto-suggest matching shape and crystal color
    if (shapeEl && tpl.suggestedShape) {
        shapeEl.value = tpl.suggestedShape;
    }
    if (tpl.suggestedColor) {
        window.selectedCustomGemColor = tpl.suggestedColor;
        if (colorInput) colorInput.value = tpl.suggestedColor;
    }

    // Auto-sync game effect checkboxes based on category
    if (document.getElementById('effect-shield-roll')) {
        document.getElementById('effect-shield-roll').checked = (category === 'CUSTOM' || category === 'SHIELD_SNAKE');
        document.getElementById('effect-immune-kick').checked = (category === 'CUSTOM' || category === 'PASS_OPPONENT_KICK');
        document.getElementById('effect-immune-steal').checked = (category === 'CUSTOM');
        document.getElementById('effect-immune-snake').checked = (category === 'CUSTOM' || category === 'SHIELD_SNAKE');
        document.getElementById('effect-steal-gold').checked = (category === 'STEAL_GOLD');
        document.getElementById('effect-toll-discount').checked = (category === 'TOLL_DISCOUNT');
    }

    updateLiveGemFormPreview();

    // Visual feedback
    if (typeof showToast === 'function') {
        showToast(`✨ AI สุ่มตั้งค่าอัญมณี: "${randName}" สำเร็จ (คุณสามารถแก้ไขข้อความในช่องต่างๆ ได้ทันที)`);
    } else {
        const hint = document.getElementById('gem-color-code-display');
        if (hint) hint.innerHTML = `<span style="color:#34d399; font-weight:800;">✨ สุ่มสร้างสำเร็จ: ${randName} (แก้ไขได้)</span>`;
    }
};

window.onAdminGemCategoryChange = function (category) {
    window.aiAutoGenerateGemFields(category);
};

// Helper to generate visual SVG gem graphic with custom color, aura, and particle FX support
window.generateGemSvgPreview = function (shape = 'triangle', grade = 'SS+', size = 52, customColor = null, auraType = 'pulse', particleFx = 'spark', auraIntensity = 'high') {
    const s = (shape || 'triangle').toLowerCase();
    const g = (grade || 'SS+').toUpperCase();
    const aura = (auraType || 'pulse').toLowerCase();
    const pfx = (particleFx || 'spark').toLowerCase();
    const intensity = (auraIntensity || 'high').toLowerCase();

    let mainColor = customColor;
    if (!mainColor) {
        if (g === 'SS+') mainColor = '#c084fc'; // Purple
        else if (g === 'S+') mainColor = '#00e5ff'; // Cyan
        else mainColor = '#ffd700'; // Gold
    }

    // Calculate light and dark facets based on mainColor
    let glowColor = mainColor + 'cc';
    let innerColor = adjustColorBrightness(mainColor, 40);
    let facetColor = adjustColorBrightness(mainColor, -40);

    const randId = 'g_' + Math.random().toString(36).substr(2, 6);

    // Intensity factors
    let blurRadius = intensity === 'ultra' ? 14 : (intensity === 'high' ? 8 : 4);
    let dropShadowSpread = intensity === 'ultra' ? '0 0 22px ' + mainColor + ', 0 0 35px ' + glowColor : (intensity === 'high' ? '0 0 14px ' + glowColor : '0 0 7px ' + glowColor);
    let auraOpacity = intensity === 'ultra' ? 1.0 : (intensity === 'high' ? 0.85 : 0.6);

    // Aura SVG Layer (rendered behind the crystal)
    let auraMarkup = '';
    if (aura === 'pulse') {
        auraMarkup = `
            <g class="gem-fx-pulse" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="42" fill="none" stroke="${mainColor}" stroke-width="2" stroke-dasharray="4 4" opacity="0.6">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="8s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="36" fill="${mainColor}" opacity="0.22" filter="url(#glow_${randId})">
                    <animate attributeName="r" values="32;42;32" dur="2s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.15;0.35;0.15" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="28" fill="${innerColor}" opacity="0.3" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'fire') {
        auraMarkup = `
            <g class="gem-fx-fire" opacity="${auraOpacity}">
                <path d="M50,8 Q60,30 68,26 Q78,40 68,58 Q78,72 65,82 Q50,94 35,82 Q22,72 32,58 Q22,40 32,26 Q40,30 50,8 Z" fill="url(#fire_grad_${randId})" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="scale" values="1;1.08;0.98;1" keyTimes="0;0.35;0.7;1" dur="1.4s" repeatCount="indefinite" transform-origin="50 50"/>
                </path>
                <circle cx="50" cy="50" r="38" fill="none" stroke="#f59e0b" stroke-width="1.8" opacity="0.5" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'electric') {
        auraMarkup = `
            <g class="gem-fx-electric" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="40" fill="none" stroke="#38bdf8" stroke-width="1.2" opacity="0.4"/>
                <polyline points="50,10 54,28 66,32 56,44 68,60 50,56 46,74 38,58 28,62 38,46 26,34 40,30 50,10" fill="none" stroke="#e0f2fe" stroke-width="2.2" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.2;0.9;0.3;1" dur="0.8s" repeatCount="indefinite"/>
                </polyline>
                <polyline points="48,16 60,34 46,48 62,64 44,82" fill="none" stroke="#67e8f9" stroke-width="1.6" opacity="0.7">
                    <animate attributeName="opacity" values="0.2;0.9;0.1;1;0.4" dur="0.6s" repeatCount="indefinite"/>
                </polyline>
            </g>
        `;
    } else if (aura === 'cosmic') {
        auraMarkup = `
            <g class="gem-fx-cosmic" opacity="${auraOpacity}">
                <ellipse cx="50" cy="50" rx="44" ry="24" fill="none" stroke="url(#cosmic_grad_${randId})" stroke-width="2.5" transform="rotate(-30 50 50)" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="-30 50 50" to="330 50 50" dur="6s" repeatCount="indefinite"/>
                </ellipse>
                <ellipse cx="50" cy="50" rx="44" ry="24" fill="none" stroke="${mainColor}" stroke-width="1.5" stroke-dasharray="6 8" transform="rotate(35 50 50)">
                    <animateTransform attributeName="transform" type="rotate" from="35 50 50" to="-325 50 50" dur="8s" repeatCount="indefinite"/>
                </ellipse>
                <circle cx="50" cy="50" r="36" fill="${facetColor}" opacity="0.35" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'rainbow') {
        auraMarkup = `
            <g class="gem-fx-rainbow" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="41" fill="none" stroke="url(#rainbow_grad_${randId})" stroke-width="3.5" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="34" fill="none" stroke="url(#rainbow_grad_${randId})" stroke-width="1.8" stroke-dasharray="8 6" opacity="0.8">
                    <animateTransform attributeName="transform" type="rotate" from="360 50 50" to="0 50 50" dur="3s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    } else if (aura === 'vortex') {
        auraMarkup = `
            <g class="gem-fx-vortex" opacity="${auraOpacity}">
                <path d="M50,50 Q65,25 80,30 Q92,42 85,60 Q72,82 50,75 Q28,70 20,50 Q18,30 35,18 Q55,10 75,20" fill="none" stroke="${mainColor}" stroke-width="2.5" stroke-dasharray="10 5" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="3.5s" repeatCount="indefinite"/>
                </path>
                <circle cx="50" cy="50" r="32" fill="${mainColor}" opacity="0.25" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'divine') {
        auraMarkup = `
            <g class="gem-fx-divine" opacity="${auraOpacity}">
                <g filter="url(#glow_${randId})">
                    <polygon points="50,6 55,38 88,24 62,48 94,50 62,54 88,76 55,62 50,94 45,62 12,76 38,54 6,50 38,48 12,24 45,38" fill="url(#divine_grad_${randId})" opacity="0.75">
                        <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="12s" repeatCount="indefinite"/>
                    </polygon>
                </g>
                <circle cx="50" cy="50" r="35" fill="#fef08a" opacity="0.2" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'dark') {
        auraMarkup = `
            <g class="gem-fx-dark" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="42" fill="#090514" stroke="#e11d48" stroke-width="2" stroke-dasharray="5 5" opacity="0.9">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="-360 50 50" dur="7s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="34" fill="#180026" opacity="0.7" filter="url(#glow_${randId})">
                    <animate attributeName="r" values="30;38;30" dur="2.2s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    }

    // Particle FX Layer (rendered on top / around crystal)
    let particleMarkup = '';
    if (pfx === 'spark') {
        particleMarkup = `
            <g class="gem-pfx-spark">
                <polygon points="20,18 22,23 27,25 22,27 20,32 18,27 13,25 18,23" fill="#ffffff" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.2;1;0.2" dur="1.2s" repeatCount="indefinite"/>
                    <animateTransform attributeName="transform" type="scale" values="0.8;1.3;0.8" dur="1.2s" repeatCount="indefinite" transform-origin="20 25"/>
                </polygon>
                <polygon points="80,22 82,26 86,28 82,30 80,34 78,30 74,28 78,26" fill="#fef08a" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite"/>
                    <animateTransform attributeName="transform" type="scale" values="1.2;0.7;1.2" dur="1.5s" repeatCount="indefinite" transform-origin="80 28"/>
                </polygon>
                <polygon points="82,72 83.5,75 87,76.5 83.5,78 82,81 80.5,78 77,76.5 80.5,75" fill="#67e8f9" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.3;1;0.3" dur="1.8s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="18,74 20,77 24,79 20,81 18,85 16,81 12,79 16,77" fill="${innerColor}" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.8;0.2;0.8" dur="1.4s" repeatCount="indefinite"/>
                </polygon>
            </g>
        `;
    } else if (pfx === 'orbit_ring') {
        particleMarkup = `
            <g class="gem-pfx-orbit">
                <ellipse cx="50" cy="50" rx="42" ry="16" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-dasharray="6 12" transform="rotate(-25 50 50)" opacity="0.8" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="-25 50 50" to="335 50 50" dur="4s" repeatCount="indefinite"/>
                </ellipse>
                <circle cx="88" cy="40" r="3" fill="#ffffff" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="12" cy="60" r="2.5" fill="${innerColor}" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    } else if (pfx === 'crystal_shard') {
        particleMarkup = `
            <g class="gem-pfx-shards">
                <polygon points="16,36 20,32 24,36 20,42" fill="${innerColor}" stroke="#fff" stroke-width="0.8" opacity="0.9" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="translate" values="0,0; 2,-6; 0,0" dur="2s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="80,62 84,58 88,62 84,68" fill="${facetColor}" stroke="#fff" stroke-width="0.8" opacity="0.9" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="translate" values="0,0; -3,6; 0,0" dur="2.4s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="76,28 79,24 83,28 79,33" fill="${mainColor}" stroke="#fff" stroke-width="0.8" opacity="0.85">
                    <animateTransform attributeName="transform" type="translate" values="0,0; 3,-4; 0,0" dur="1.8s" repeatCount="indefinite"/>
                </polygon>
            </g>
        `;
    } else if (pfx === 'energy_stream') {
        particleMarkup = `
            <g class="gem-pfx-stream">
                <line x1="36" y1="88" x2="36" y2="12" stroke="url(#stream_grad_${randId})" stroke-width="2" opacity="0.75" stroke-dasharray="8 12">
                    <animate attributeName="stroke-dashoffset" from="40" to="0" dur="1.2s" repeatCount="indefinite"/>
                </line>
                <line x1="64" y1="88" x2="64" y2="12" stroke="url(#stream_grad_${randId})" stroke-width="2" opacity="0.75" stroke-dasharray="8 12">
                    <animate attributeName="stroke-dashoffset" from="40" to="0" dur="1.5s" repeatCount="indefinite"/>
                </line>
                <line x1="50" y1="92" x2="50" y2="8" stroke="#ffffff" stroke-width="1.4" opacity="0.6" stroke-dasharray="12 16">
                    <animate attributeName="stroke-dashoffset" from="56" to="0" dur="1s" repeatCount="indefinite"/>
                </line>
            </g>
        `;
    } else if (pfx === 'flare_burst') {
        particleMarkup = `
            <g class="gem-pfx-flare">
                <circle cx="50" cy="50" r="22" fill="none" stroke="#ffffff" stroke-width="2.5" opacity="0.8">
                    <animate attributeName="r" values="16;44;16" dur="1.8s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.9;0;0.9" dur="1.8s" repeatCount="indefinite"/>
                </circle>
                <line x1="15" y1="50" x2="85" y2="50" stroke="#ffffff" stroke-width="2" opacity="0.75" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.4" dur="1.2s" repeatCount="indefinite"/>
                </line>
                <line x1="50" y1="15" x2="50" y2="85" stroke="#ffffff" stroke-width="2" opacity="0.75" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.4" dur="1.2s" repeatCount="indefinite"/>
                </line>
            </g>
        `;
    }

    let shapeMarkup = '';
    if (s === 'triangle') {
        shapeMarkup = `
            <polygon points="50,12 88,80 12,80" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,12 50,56 12,80" fill="${facetColor}" opacity="0.65"/>
            <polygon points="50,12 88,80 50,56" fill="${innerColor}" opacity="0.55"/>
            <polygon points="12,80 50,56 88,80" fill="${facetColor}" opacity="0.85"/>
            <circle cx="50" cy="54" r="3.5" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    } else if (s === 'square') {
        shapeMarkup = `
            <polygon points="50,10 90,50 50,90 10,50" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,26 74,50 50,74 26,50" fill="${innerColor}" opacity="0.5" stroke="#ffffff" stroke-width="1.2"/>
            <line x1="50" y1="10" x2="50" y2="26" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="90" y1="50" x2="74" y2="50" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="50" y1="90" x2="50" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="10" y1="50" x2="26" y2="50" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <circle cx="45" cy="45" r="3.5" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    } else {
        // Pentagon
        shapeMarkup = `
            <polygon points="50,10 88,38 74,86 26,86 12,38" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,30 72,48 64,74 36,74 28,48" fill="${innerColor}" opacity="0.45" stroke="#ffffff" stroke-width="1.2"/>
            <line x1="50" y1="10" x2="50" y2="30" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="88" y1="38" x2="72" y2="48" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="74" y1="86" x2="64" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="26" y1="86" x2="36" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="12" y1="38" x2="28" y2="48" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <circle cx="50" cy="52" r="4" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    }

    return `
        <svg viewBox="0 0 100 100" width="${size}" height="${size}" style="filter: drop-shadow(${dropShadowSpread}); vertical-align: middle; overflow: visible;">
            <defs>
                <filter id="glow_${randId}" x="-30%" y="-30%" width="160%" height="160%">
                    <feGaussianBlur stdDeviation="${blurRadius / 3}" result="blur" />
                    <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
                <linearGradient id="gem_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="${innerColor}" stop-opacity="0.95" />
                    <stop offset="50%" stop-color="${mainColor}" stop-opacity="0.85" />
                    <stop offset="100%" stop-color="${facetColor}" stop-opacity="0.95" />
                </linearGradient>
                <linearGradient id="fire_grad_${randId}" x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stop-color="#ef4444" stop-opacity="0.8" />
                    <stop offset="50%" stop-color="#f59e0b" stop-opacity="0.9" />
                    <stop offset="100%" stop-color="#fef08a" stop-opacity="0.95" />
                </linearGradient>
                <linearGradient id="cosmic_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#a855f7" />
                    <stop offset="50%" stop-color="#38bdf8" />
                    <stop offset="100%" stop-color="#ec4899" />
                </linearGradient>
                <linearGradient id="rainbow_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#ef4444" />
                    <stop offset="20%" stop-color="#f97316" />
                    <stop offset="40%" stop-color="#facc15" />
                    <stop offset="60%" stop-color="#10b981" />
                    <stop offset="80%" stop-color="#06b6d4" />
                    <stop offset="100%" stop-color="#8b5cf6" />
                </linearGradient>
                <linearGradient id="divine_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#ffffff" />
                    <stop offset="50%" stop-color="#fde047" />
                    <stop offset="100%" stop-color="#eab308" />
                </linearGradient>
                <linearGradient id="stream_grad_${randId}" x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stop-color="${mainColor}" stop-opacity="0.1" />
                    <stop offset="100%" stop-color="#ffffff" stop-opacity="0.9" />
                </linearGradient>
                <linearGradient id="grade_txt_grad_${randId}" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#ffffff" />
                    <stop offset="45%" stop-color="#ffffff" />
                    <stop offset="100%" stop-color="${mainColor}" />
                </linearGradient>
            </defs>
            ${auraMarkup}
            ${shapeMarkup}
            ${particleMarkup}
            <text x="50" y="${s === 'triangle' ? 67 : 58}" text-anchor="middle" font-family="'Arial Black','Segoe UI Black',Impact,sans-serif" font-weight="900" font-style="italic" font-size="${g.length >= 3 ? 25 : (g.length === 2 ? 29 : 33)}" fill="url(#grade_txt_grad_${randId})" stroke="rgba(0,0,0,0.92)" stroke-width="4.5" paint-order="stroke fill" style="filter:drop-shadow(0 0 4px ${mainColor}) drop-shadow(0 2px 3px rgba(0,0,0,0.95)); pointer-events:none; user-select:none;">${g}</text>
        </svg>
    `;
};

function adjustColorBrightness(hex, percent) {
    hex = (hex || '#ffd700').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let num = parseInt(hex, 16);
    let r = (num >> 16) + Math.round(255 * (percent / 100));
    let g = ((num >> 8) & 0x00FF) + Math.round(255 * (percent / 100));
    let b = (num & 0x0000FF) + Math.round(255 * (percent / 100));
    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// User manually picked color in color input
window.onCustomGemColorChange = function (hexColor) {
    window.selectedCustomGemColor = hexColor;
    updateLiveGemFormPreview();
};

// Reset to default grade color
window.resetGemColorToGradeDefault = function () {
    window.selectedCustomGemColor = null;
    const grade = document.getElementById('gem-grade') ? document.getElementById('gem-grade').value : 'SS+';
    const defColor = (grade === 'SS+') ? '#c084fc' : ((grade === 'S+') ? '#00e5ff' : '#ffd700');
    const colorInput = document.getElementById('gem-custom-color');
    if (colorInput) colorInput.value = defColor;
    updateLiveGemFormPreview();
};

// AI Color & Aura/FX Randomizer Generator
window.aiRandomGemColor = function () {
    const randomPick = AI_CRYSTAL_PALETTES[Math.floor(Math.random() * AI_CRYSTAL_PALETTES.length)];
    window.selectedCustomGemColor = randomPick.color;

    const colorInput = document.getElementById('gem-custom-color');
    if (colorInput) colorInput.value = randomPick.color;

    // Also pick synergistic aura and particle FX
    const auras = ['pulse', 'fire', 'electric', 'cosmic', 'rainbow', 'vortex', 'divine', 'dark'];
    const particles = ['spark', 'orbit_ring', 'crystal_shard', 'energy_stream', 'flare_burst'];
    const intensities = ['high', 'ultra'];

    const randAura = auras[Math.floor(Math.random() * auras.length)];
    const randParticle = particles[Math.floor(Math.random() * particles.length)];
    const randIntensity = intensities[Math.floor(Math.random() * intensities.length)];

    const auraEl = document.getElementById('gem-aura');
    if (auraEl) auraEl.value = randAura;
    const particleEl = document.getElementById('gem-particle-fx');
    if (particleEl) particleEl.value = randParticle;
    const intensityEl = document.getElementById('gem-aura-intensity');
    if (intensityEl) intensityEl.value = randIntensity;

    updateLiveGemFormPreview();

    // Show toast or hint
    const hint = document.getElementById('gem-color-code-display');
    if (hint) {
        hint.innerHTML = `<strong style="color:${randomPick.color};">✨ AI สุ่ม: ${randomPick.name} | ออร่า: ${randAura}</strong>`;
    }
};

async function loadGemItemsAdmin() {
    const tbody = document.getElementById('gem-items-table-body');
    const countBadge = document.getElementById('gem-total-count');
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:#94a3b8;">⏳ กำลังโหลดรายการอัญมณี...</td></tr>`;
    }

    try {
        const res = await fetch('../api/equipment_service.php?action=get_admin_items');
        const json = await res.json();
        if (json.status === 'success' && Array.isArray(json.items)) {
            // Filter only items that have shape or are gems
            window.currentAdminGems = json.items.filter(item => item.shape !== null && item.shape !== undefined);
            if (countBadge) countBadge.innerText = `พบ ${window.currentAdminGems.length} ชิ้น`;
            renderGemTable(window.currentAdminGems);
            populateGemEventTargetDropdown(window.currentAdminGems);
        } else {
            if (tbody) tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:#ef4444;">ไม่สามารถโหลดข้อมูลได้: ${json.message || 'Error'}</td></tr>`;
        }
    } catch (err) {
        console.error('loadGemItemsAdmin error:', err);
        if (tbody) tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:#ef4444;">เกิดข้อผิดพลาดในการเชื่อมต่อ API</td></tr>`;
    }

    // Also load gem gacha event config
    loadGemGachaEventConfigAdmin();

    updateLiveGemFormPreview();
}

function updateLiveGemFormPreview() {
    const shapeEl = document.getElementById('gem-shape');
    const gradeEl = document.getElementById('gem-grade');
    const auraEl = document.getElementById('gem-aura');
    const particleEl = document.getElementById('gem-particle-fx');
    const intensityEl = document.getElementById('gem-aura-intensity');

    const box = document.getElementById('gem-live-preview-box');
    const shapeLabel = document.getElementById('gem-live-shape-label');
    const gradeLabel = document.getElementById('gem-live-grade-label');
    const auraText = document.getElementById('gem-live-aura-text');
    const particleText = document.getElementById('gem-live-particle-text');
    const colorHint = document.getElementById('gem-color-code-display');
    if (!shapeEl || !gradeEl || !box) return;

    const shape = shapeEl.value;
    const grade = gradeEl.value;
    const aura = auraEl ? auraEl.value : 'pulse';
    const particle = particleEl ? particleEl.value : 'spark';
    const intensity = intensityEl ? intensityEl.value : 'high';
    const color = window.selectedCustomGemColor;

    box.innerHTML = window.generateGemSvgPreview(shape, grade, 92, color, aura, particle, intensity);

    const shapeNames = {
        triangle: '🔺 ทรงสามเหลี่ยม (Triangle Crystal)',
        square: '🔷 ทรงสี่เหลี่ยม (Square Diamond)',
        pentagon: '⬠ ทรงห้าเหลี่ยม (Pentagon Jewel)'
    };
    if (shapeLabel) shapeLabel.innerText = shapeNames[shape] || shape;
    if (gradeLabel) {
        gradeLabel.innerText = `ระดับ [${grade}]`;
        gradeLabel.style.color = (grade === 'SS+') ? '#c084fc' : ((grade === 'S+') ? '#00e5ff' : '#ffd700');
    }
    const auraNames = {
        pulse: '💫 ชีพจรเรืองแสง (Pulse)',
        fire: '🔥 เปลวเพลิงสุริยะ (Fire)',
        electric: '⚡ สายฟ้าฟาด (Electric)',
        cosmic: '🌌 คอสมิคกาแล็กซี (Cosmic)',
        rainbow: '🌈 สีรุ้งปริซึม (Rainbow)',
        vortex: '🌀 พายุมิติวน (Vortex)',
        divine: '🌟 เทพศักดิ์สิทธิ์ (Divine)',
        dark: '🖤 ความมืดทมิฬ (Dark Void)',
        none: '⚪ ปิดออร่า (None)'
    };
    if (auraText) auraText.innerText = auraNames[aura] || aura;

    const particleNames = {
        spark: '✨ ละอองประกายดาว (Sparkles)',
        orbit_ring: '🪐 วงแหวนหมุนวน (Orbit Rings)',
        crystal_shard: '💎 ผลึกแก้วลอยละล่อง (Shards)',
        energy_stream: '🌊 ลำแสงพวยพุ่ง (Energy Pillar)',
        flare_burst: '💥 แสงวาบระเบิดพลัง (Flare Burst)',
        none: '⚪ ไม่มีอนุภาค (None)'
    };
    if (particleText) particleText.innerText = particleNames[particle] || particle;

    if (colorHint) {
        if (color) {
            colorHint.innerHTML = `<span style="color:${color}; font-weight:800;">${color} (กำหนดเอง)</span>`;
        } else {
            colorHint.innerText = 'ค่าเริ่มต้นตามเกรด';
        }
    }
}

function renderGemTable(items) {
    const tbody = document.getElementById('gem-items-table-body');
    if (!tbody) return;

    if (!items || items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:24px; color:#94a3b8;">ยังไม่มีไอเทมอัญมณีในระบบ กด "สร้างไอเทมอัญมณีใหม่" ด้านบนเพื่อเริ่มต้น</td></tr>`;
        return;
    }

    const shapeIcons = {
        triangle: '🔺 สามเหลี่ยม',
        square: '🔷 สี่เหลี่ยม',
        pentagon: '⬠ ห้าเหลี่ยม'
    };

    const gradeColors = {
        'SS+': '#c084fc',
        'S+': '#00e5ff',
        'S': '#ffd700'
    };

    const auraIcons = {
        pulse: '💫 ชีพจร',
        fire: '🔥 เพลิง',
        electric: '⚡ สายฟ้า',
        cosmic: '🌌 คอสมิค',
        rainbow: '🌈 สีรุ้ง',
        vortex: '🌀 วอร์เทกซ์',
        divine: '🌟 เทวะ',
        dark: '🖤 ทมิฬ',
        none: '⚪ ปิด'
    };

    const particleIcons = {
        spark: '✨ ประกายดาว',
        orbit_ring: '🪐 วงแหวน',
        crystal_shard: '💎 ผลึกแก้ว',
        energy_stream: '🌊 ลำแสง',
        flare_burst: '💥 วาบพลัง',
        none: '⚪ ปิด'
    };

    tbody.innerHTML = items.map(item => {
        const sIcon = shapeIcons[item.shape] || (item.shape || '🔺');
        const gColor = gradeColors[item.grade] || '#fff';
        const displayColor = item.gem_color || null;
        const aura = item.aura_type || 'pulse';
        const pfx = item.particle_fx || 'spark';
        const intensity = item.aura_intensity || 'high';
        const svgImg = window.generateGemSvgPreview(item.shape, item.grade, 46, displayColor, aura, pfx, intensity);
        let parsedEff = {};
        try {
            parsedEff = item.skill_effects_json ? (typeof item.skill_effects_json === 'string' ? JSON.parse(item.skill_effects_json) : item.skill_effects_json) : {};
        } catch (e) { parsedEff = {}; }
        const extraSkillsList = Array.isArray(parsedEff.skills) ? parsedEff.skills.slice(1) : [];
        let extraSkillsHtml = extraSkillsList.map((sk, sIdx) => {
            const skTitle = sk.name || sk.category || `สกิล ${sIdx + 2}`;
            const skDesc = sk.description || '';
            const skRate = (sk.base_rate !== undefined && sk.max_rate !== undefined) ? ` (${sk.base_rate}%–${sk.max_rate}%)` : (sk.max_rate ? ` (${sk.max_rate}%)` : '');
            return `
                <div style="margin-top:6px; padding-top:5px; border-top:1px dashed rgba(56,189,248,0.25);">
                    <div style="color:#38bdf8; font-weight:700; font-size:11.5px;">⚡ สกิล ${sIdx + 2}: ${skTitle}${skRate}</div>
                    ${skDesc ? `<div style="font-size:10.5px; color:#94a3b8; line-height:1.3; margin-top:1px;">${skDesc}</div>` : ''}
                </div>
            `;
        }).join('');
        if (!extraSkillsHtml && parsedEff.forward_backward_move && item.skill_category !== 'FORWARD_BACKWARD_MOVE') {
            extraSkillsHtml = `
                <div style="margin-top:6px; padding-top:5px; border-top:1px dashed rgba(56,189,248,0.25);">
                    <div style="color:#38bdf8; font-weight:700; font-size:11.5px;">🧭 สกิลเสริม: เลือกทอยเดินหน้า / ถอยหลัง</div>
                </div>
            `;
        }

        return `
            <tr style="border-bottom:1px solid rgba(255,255,255,0.06); background:rgba(0,0,0,0.2);">
                <td style="padding:10px; color:#94a3b8; font-weight:700;">#${item.id}</td>
                <td style="padding:8px 10px; text-align:center;">
                    <div style="display:inline-flex; flex-direction:column; align-items:center; gap:2px;">
                        ${svgImg}
                        <span style="font-size:10px; color:${displayColor || '#a78bfa'}; font-weight:700;">
                            ${displayColor ? '● ' : ''}${sIcon}
                        </span>
                    </div>
                </td>
                <td style="padding:10px;">
                    <strong style="color:#fff; font-size:13px;">${item.name}</strong>
                    <div style="font-size:10.5px; color:#64748b; font-family:monospace;">${item.item_code}</div>
                </td>
                <td style="padding:10px;">
                    <span style="background:${gColor}22; border:1px solid ${gColor}; color:${gColor}; font-weight:800; padding:2px 8px; border-radius:10px; font-size:11px;">
                        ${item.grade}
                    </span>
                </td>
                <td style="padding:10px;">
                    <div style="display:flex; flex-direction:column; gap:3px;">
                        <span style="background:rgba(168,85,247,0.18); border:1px solid #a855f7; color:#e9d5ff; font-weight:700; padding:2px 8px; border-radius:8px; font-size:10.5px; display:inline-block; width:fit-content;">
                            ${auraIcons[aura] || aura}
                        </span>
                        <span style="background:rgba(56,189,248,0.15); border:1px solid #38bdf8; color:#7dd3fc; font-weight:700; padding:2px 8px; border-radius:8px; font-size:10px; display:inline-block; width:fit-content;">
                            ${particleIcons[pfx] || pfx}
                        </span>
                    </div>
                </td>
                <td style="padding:10px; max-width:260px;">
                    <div style="color:#fbbf24; font-weight:700;">${item.skill_name || item.skill_category}</div>
                    <div style="font-size:11px; color:#94a3b8; line-height:1.3; margin-top:2px;">${item.skill_description || '-'}</div>
                    ${extraSkillsHtml}
                </td>
                <td style="padding:10px; text-align:center;">
                    <span style="color:#34d399; font-weight:700; font-size:13px;">${parseFloat(item.trigger_rate_percent || 90)}%</span>
                </td>
                <td style="padding:10px; text-align:center;">
                    <span style="font-size:11.5px; color:#cbd5e1; font-weight:700;">${item.shadow_required_count || 5} ชิ้น</span>
                    <div style="font-size:9.5px; color:#64748b;">(${item.shadow_material_code || '-'})</div>
                </td>
                <td style="padding:10px; text-align:center; white-space:nowrap;">
                    <button type="button" class="btn" onclick="editGemItemAdmin(${item.id})" style="padding:4px 10px; font-size:11px; background:rgba(56,189,248,0.15); color:#38bdf8; border:1px solid #38bdf8; margin-right:4px; border-radius:6px; cursor:pointer;">✏️ แก้ไข</button>
                    <button type="button" class="btn btn-danger" onclick="deleteGemItemAdmin(${item.id}, '${item.name}')" style="padding:4px 10px; font-size:11px; border-radius:6px; cursor:pointer;">🗑️ ลบ</button>
                </td>
            </tr>
        `;
    }).join('');
}

window.setSkillPreset = function (preset) {
    const setCheck = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.checked = Boolean(val);
    };

    if (preset === 'god') {
        setCheck('effect-shield-roll', true);
        setCheck('effect-immune-kick', true);
        setCheck('effect-immune-steal', true);
        setCheck('effect-immune-snake', true);
        setCheck('effect-pull-4', true);
        setCheck('effect-pull-6', true);
        setCheck('effect-pull-line', true);
        setCheck('effect-black-hole', true);
        setCheck('effect-steal-gold', true);
        setCheck('effect-instant-landmark', true);
        setCheck('effect-multiplier-random', true);
        setCheck('effect-toll-discount', true);
    } else if (preset === 'magnet') {
        setCheck('effect-shield-roll', true);
        setCheck('effect-immune-kick', true);
        setCheck('effect-immune-steal', true);
        setCheck('effect-immune-snake', false);
        setCheck('effect-pull-4', true);
        setCheck('effect-pull-6', true);
        setCheck('effect-pull-line', true);
        setCheck('effect-black-hole', true);
        setCheck('effect-steal-gold', true);
        setCheck('effect-instant-landmark', true);
        setCheck('effect-multiplier-random', true);
        setCheck('effect-toll-discount', false);
    } else if (preset === 'defense') {
        setCheck('effect-shield-roll', true);
        setCheck('effect-immune-kick', true);
        setCheck('effect-immune-steal', true);
        setCheck('effect-immune-snake', true);
        setCheck('effect-pull-4', false);
        setCheck('effect-pull-6', false);
        setCheck('effect-pull-line', false);
        setCheck('effect-black-hole', false);
        setCheck('effect-steal-gold', false);
        setCheck('effect-instant-landmark', false);
        setCheck('effect-multiplier-random', false);
        setCheck('effect-toll-discount', true);
    } else if (preset === 'clear') {
        setCheck('effect-shield-roll', false);
        setCheck('effect-immune-kick', false);
        setCheck('effect-immune-steal', false);
        setCheck('effect-immune-snake', false);
        setCheck('effect-pull-4', false);
        setCheck('effect-pull-6', false);
        setCheck('effect-pull-line', false);
        setCheck('effect-black-hole', false);
        setCheck('effect-steal-gold', false);
        setCheck('effect-instant-landmark', false);
        setCheck('effect-multiplier-random', false);
        setCheck('effect-toll-discount', false);
    }
};

function resetGemForm() {
    document.getElementById('gem-form-title').innerText = '✨ สร้างไอเทมอัญมณีใหม่';
    document.getElementById('gem-item-id').value = '';
    document.getElementById('gem-name').value = '';
    document.getElementById('gem-code').value = '';
    document.getElementById('gem-shape').value = 'triangle';
    document.getElementById('gem-grade').value = 'SS+';
    document.getElementById('gem-rate').value = '90';

    const auraEl = document.getElementById('gem-aura');
    if (auraEl) auraEl.value = 'pulse';
    const particleEl = document.getElementById('gem-particle-fx');
    if (particleEl) particleEl.value = 'spark';
    const intensityEl = document.getElementById('gem-aura-intensity');
    if (intensityEl) intensityEl.value = 'high';

    document.getElementById('gem-skill-category').value = 'PASS_OPPONENT_KICK';
    document.getElementById('gem-skill-name').value = '';
    document.getElementById('gem-skill-desc').value = '';
    document.getElementById('gem-shadow-code').value = '';
    document.getElementById('gem-shadow-count').value = '5';
    window.selectedCustomGemColor = null;
    const colorInput = document.getElementById('gem-custom-color');
    if (colorInput) colorInput.value = '#c084fc';
    window.setSkillPreset('god');

    updateLiveGemFormPreview();
}

function editGemItemAdmin(id) {
    const item = window.currentAdminGems.find(g => g.id == id);
    if (!item) return;

    document.getElementById('gem-form-title').innerText = `✏️ แก้ไขอัญมณี: ${item.name}`;
    document.getElementById('gem-item-id').value = item.id;
    document.getElementById('gem-name').value = item.name || '';
    document.getElementById('gem-code').value = item.item_code || '';
    document.getElementById('gem-shape').value = item.shape || 'triangle';
    document.getElementById('gem-grade').value = item.grade || 'SS+';
    document.getElementById('gem-rate').value = parseFloat(item.trigger_rate_percent || 90);

    const auraEl = document.getElementById('gem-aura');
    if (auraEl) auraEl.value = item.aura_type || 'pulse';
    const particleEl = document.getElementById('gem-particle-fx');
    if (particleEl) particleEl.value = item.particle_fx || 'spark';
    const intensityEl = document.getElementById('gem-aura-intensity');
    if (intensityEl) intensityEl.value = item.aura_intensity || 'high';

    document.getElementById('gem-skill-category').value = item.skill_category || 'PASS_OPPONENT_KICK';
    document.getElementById('gem-skill-name').value = item.skill_name || '';
    document.getElementById('gem-skill-desc').value = item.skill_description || '';
    document.getElementById('gem-shadow-code').value = item.shadow_material_code || '';
    document.getElementById('gem-shadow-count').value = item.shadow_required_count || 5;

    let effects = null;
    if (item.skill_effects_json) {
        try {
            effects = typeof item.skill_effects_json === 'string' ? JSON.parse(item.skill_effects_json) : item.skill_effects_json;
        } catch (e) {}
    }
    if (!effects) {
        const desc = (item.skill_description || '') + ' ' + (item.skill_name || '');
        effects = {
            shield_on_roll: /สร้างโล่|โล่|เกราะ/i.test(desc),
            immune_kick: /ป้องกันการเตะ|กันเตะ/i.test(desc),
            immune_steal: /ป้องกันการดูดเงิน|กันดูดเงิน|กันขโมย/i.test(desc),
            immune_snake: /ป้องกันงู|คุ้มกันหัวงู/i.test(desc) || item.skill_category === 'SHIELD_SNAKE',
            pull_opponents_4: /4 ช่อง|4ช่อง|ดึง 4/i.test(desc),
            pull_opponents_6: /6 ช่อง|6ช่อง|ดึง 6/i.test(desc),
            pull_opponents_line: /ในแถว|ทั้งแถว/i.test(desc),
            black_hole_generator: /หลุมดำ|black hole/i.test(desc),
            instant_landmark_3city: /3 เมือง|3เมือง|กระโดด|เสกแลนด์มาร์ค/i.test(desc),
            toll_multiplier_random: /คูณ 12|คูณ12|x12|ตัวคูณ|คูณ 8|คูณ 2/i.test(desc),
            steal_gold: /ดูดเงิน|ขโมยทอง/i.test(desc) || item.skill_category === 'STEAL_GOLD',
            toll_discount: /ส่วนลดค่าผ่านทาง/i.test(desc) || item.skill_category === 'TOLL_DISCOUNT'
        };
    }
    const setCheck = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.checked = Boolean(val);
    };
    setCheck('effect-shield-roll', effects.shield_on_roll);
    setCheck('effect-immune-kick', effects.immune_kick);
    setCheck('effect-immune-steal', effects.immune_steal);
    setCheck('effect-immune-snake', effects.immune_snake);
    setCheck('effect-pull-4', effects.pull_opponents_4);
    setCheck('effect-pull-6', effects.pull_opponents_6);
    setCheck('effect-pull-line', effects.pull_opponents_line);
    setCheck('effect-black-hole', effects.black_hole_generator);
    setCheck('effect-instant-landmark', effects.instant_landmark_3city);
    setCheck('effect-multiplier-random', effects.toll_multiplier_random);
    setCheck('effect-steal-gold', effects.steal_gold);
    setCheck('effect-toll-discount', effects.toll_discount);
    setCheck('effect-forward-backward', effects.forward_backward_move || item.skill_category === 'FORWARD_BACKWARD_MOVE');

    const baseRateEl = document.getElementById('gem-base-rate');
    if (baseRateEl) {
        const maxR = parseFloat(item.trigger_rate_percent || 90);
        baseRateEl.value = effects.base_rate !== undefined ? effects.base_rate : Math.max(10, Math.round(maxR * 0.45));
    }
    if (typeof window.renderAdminExtraGemSkillSlots === 'function') {
        const extraSkills = Array.isArray(effects.skills) ? effects.skills.slice(1) : [];
        window.renderAdminExtraGemSkillSlots(extraSkills);
    }

    window.selectedCustomGemColor = item.gem_color || null;
    const colorInput = document.getElementById('gem-custom-color');
    if (colorInput && item.gem_color) {
        colorInput.value = item.gem_color;
    }

    updateLiveGemFormPreview();

    // Scroll to form smoothly
    document.getElementById('form-gem-item').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

window.getMaxSkillsForGemGrade = function (grade) {
    const g = String(grade || 'S').toUpperCase();
    if (g === 'ZZ+') return 3;
    if (g === 'ZZ' || g === 'SS+') return 2;
    return 1;
};

window.addExtraGemSkillRow = function (skillData = null) {
    const listEl = document.getElementById('gem-extra-skills-list');
    if (!listEl) return;
    const idx = listEl.children.length + 2;
    const s = skillData || { category: 'DICE_DOUBLE', name: '', description: '', base_rate: 25, max_rate: 50 };
    const row = document.createElement('div');
    row.className = 'gem-extra-skill-row';
    row.style.cssText = 'background:rgba(30,41,59,0.72); border:1px solid rgba(148,163,184,0.28); border-radius:8px; padding:8px 10px;';
    row.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <span style="font-size:11.5px; font-weight:800; color:#fde047;">สกิลที่ ${idx}</span>
            <button type="button" onclick="this.closest('.gem-extra-skill-row').remove()" style="background:rgba(239,68,68,0.2); border:1px solid #ef4444; color:#fca5a5; font-size:10px; padding:1px 7px; border-radius:5px; cursor:pointer;">ลบ</button>
        </div>
        <div style="display:grid; grid-template-columns: 1fr 1fr 110px; gap:8px; margin-bottom:6px;">
            <select class="extra-skill-cat form-control" style="padding:6px 8px; background:#0f172a; border:1px solid #334155; color:#fff; border-radius:6px; font-size:11.5px;">
                <option value="FORWARD_BACKWARD_MOVE" ${s.category === 'FORWARD_BACKWARD_MOVE' ? 'selected' : ''}>เลือกทอยหน้า-หลัง แล้วเดินตามระยะ</option>
                <option value="PASS_OPPONENT_KICK" ${s.category === 'PASS_OPPONENT_KICK' ? 'selected' : ''}>เตะคู่แข่งไปเมืองเราเมื่อทอยผ่าน</option>
                <option value="FORCE_PAY_TOLL" ${s.category === 'FORCE_PAY_TOLL' ? 'selected' : ''}>บังคับจ่ายค่าผ่านทาง 2 เท่า</option>
                <option value="BLOCK_CITY" ${s.category === 'BLOCK_CITY' ? 'selected' : ''}>ยกเมืองกั้นทางเดิน</option>
                <option value="SHIELD_SNAKE" ${s.category === 'SHIELD_SNAKE' ? 'selected' : ''}>เกราะคุ้มกันหัวงู</option>
                <option value="DICE_DOUBLE" ${s.category === 'DICE_DOUBLE' ? 'selected' : ''}>ทอยเบิ้ลรับทองจุดสตาร์ท 200%</option>
                <option value="TOLL_DISCOUNT" ${s.category === 'TOLL_DISCOUNT' ? 'selected' : ''}>ส่วนลดค่าผ่านทาง</option>
                <option value="STEAL_GOLD" ${s.category === 'STEAL_GOLD' ? 'selected' : ''}>ขโมยทองคู่แข่ง</option>
                <option value="CUSTOM" ${s.category === 'CUSTOM' ? 'selected' : ''}>สกิลกำหนดเอง</option>
            </select>
            <input type="text" class="extra-skill-name form-control" value="${String(s.name || '').replace(/"/g, '&quot;')}" placeholder="ชื่อสกิลที่ ${idx}" style="padding:6px 8px; background:#0f172a; border:1px solid #334155; color:#fff; border-radius:6px; font-size:11.5px;">
            <div style="display:flex; gap:4px; align-items:center;">
                <input type="number" class="extra-skill-base form-control" min="1" max="100" value="${Number(s.base_rate ?? 25)}" title="% Lv.1" style="width:50%; padding:6px 4px; background:#0f172a; border:1px solid #334155; color:#38bdf8; border-radius:6px; font-size:11px; font-weight:800;">
                <input type="number" class="extra-skill-max form-control" min="1" max="100" value="${Number(s.max_rate ?? 50)}" title="% Lv.30" style="width:50%; padding:6px 4px; background:#0f172a; border:1px solid #334155; color:#facc15; border-radius:6px; font-size:11px; font-weight:800;">
            </div>
        </div>
        <input type="text" class="extra-skill-desc form-control" value="${String(s.description || '').replace(/"/g, '&quot;')}" placeholder="คำอธิบายสกิลที่ ${idx} เช่น 50% เลือกทอยหน้าหลังแล้วเลือกเดินไปเมืองตามระยะที่ทอยได้" style="width:100%; padding:6px 8px; background:#0f172a; border:1px solid #334155; color:#fff; border-radius:6px; font-size:11.5px;">
    `;
    listEl.appendChild(row);
};

window.renderAdminExtraGemSkillSlots = function (existingSkills = null) {
    const listEl = document.getElementById('gem-extra-skills-list');
    if (!listEl) return;
    const grade = document.getElementById('gem-grade')?.value || 'SS+';
    const targetExtraCount = Math.max(0, window.getMaxSkillsForGemGrade(grade) - 1);
    const currentRows = Array.isArray(existingSkills) ? existingSkills : window.collectExtraGemSkills();
    listEl.innerHTML = '';
    const count = Math.max(targetExtraCount, Array.isArray(existingSkills) ? existingSkills.length : 0);
    for (let i = 0; i < count; i++) {
        window.addExtraGemSkillRow(currentRows[i] || null);
    }
};

window.collectExtraGemSkills = function () {
    const listEl = document.getElementById('gem-extra-skills-list');
    if (!listEl) return [];
    const rows = [];
    listEl.querySelectorAll('.gem-extra-skill-row').forEach(r => {
        const name = r.querySelector('.extra-skill-name')?.value?.trim() || '';
        const desc = r.querySelector('.extra-skill-desc')?.value?.trim() || '';
        const cat = r.querySelector('.extra-skill-cat')?.value || 'CUSTOM';
        const baseR = parseFloat(r.querySelector('.extra-skill-base')?.value || '25') || 25;
        const maxR = parseFloat(r.querySelector('.extra-skill-max')?.value || '50') || 50;
        if (name || desc) {
            rows.push({ category: cat, name, description: desc, base_rate: baseR, max_rate: maxR });
        }
    });
    return rows;
};

async function saveGemItemAdmin(event) {
    event.preventDefault();

    const maxRateVal = parseFloat(document.getElementById('gem-rate').value) || 90.0;
    const baseRateVal = parseFloat(document.getElementById('gem-base-rate')?.value) || Math.max(10, Math.round(maxRateVal * 0.45));
    const mainCat = document.getElementById('gem-skill-category').value;
    const mainName = document.getElementById('gem-skill-name').value.trim();
    const mainDesc = document.getElementById('gem-skill-desc').value.trim();
    const extraSkills = (typeof window.collectExtraGemSkills === 'function') ? window.collectExtraGemSkills() : [];
    const allSkills = [
        {
            category: mainCat,
            name: mainName,
            description: mainDesc,
            base_rate: baseRateVal,
            max_rate: maxRateVal
        },
        ...extraSkills
    ];

    const effects = {
        shield_on_roll: document.getElementById('effect-shield-roll')?.checked || false,
        shield_min: 1,
        shield_max: 3,
        immune_kick: document.getElementById('effect-immune-kick')?.checked || false,
        immune_steal: document.getElementById('effect-immune-steal')?.checked || false,
        immune_snake: document.getElementById('effect-immune-snake')?.checked || false,
        pull_opponents_4: document.getElementById('effect-pull-4')?.checked || false,
        pull_opponents_6: document.getElementById('effect-pull-6')?.checked || false,
        pull_opponents_line: document.getElementById('effect-pull-line')?.checked || false,
        black_hole_generator: document.getElementById('effect-black-hole')?.checked || false,
        instant_landmark_3city: document.getElementById('effect-instant-landmark')?.checked || false,
        toll_multiplier_random: document.getElementById('effect-multiplier-random')?.checked || false,
        steal_gold: document.getElementById('effect-steal-gold')?.checked || false,
        toll_discount: document.getElementById('effect-toll-discount')?.checked || false,
        forward_backward_move: document.getElementById('effect-forward-backward')?.checked || mainCat === 'FORWARD_BACKWARD_MOVE',
        base_rate: baseRateVal,
        max_rate: maxRateVal,
        skills: allSkills
    };

    const payload = {
        id: document.getElementById('gem-item-id').value,
        name: document.getElementById('gem-name').value.trim(),
        item_code: document.getElementById('gem-code').value.trim(),
        shape: document.getElementById('gem-shape').value,
        gem_color: window.selectedCustomGemColor || null,
        grade: document.getElementById('gem-grade').value,
        aura_type: document.getElementById('gem-aura') ? document.getElementById('gem-aura').value : 'pulse',
        particle_fx: document.getElementById('gem-particle-fx') ? document.getElementById('gem-particle-fx').value : 'spark',
        aura_intensity: document.getElementById('gem-aura-intensity') ? document.getElementById('gem-aura-intensity').value : 'high',
        trigger_rate_percent: parseFloat(document.getElementById('gem-rate').value) || 90.0,
        skill_category: document.getElementById('gem-skill-category').value,
        skill_name: document.getElementById('gem-skill-name').value.trim(),
        skill_description: document.getElementById('gem-skill-desc').value.trim(),
        shadow_material_code: document.getElementById('gem-shadow-code').value.trim(),
        shadow_required_count: parseInt(document.getElementById('gem-shadow-count').value) || 5,
        skill_effects_json: JSON.stringify(effects),
        is_active: 1
    };

    try {
        const res = await fetch('../api/equipment_service.php?action=save_item', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const resText = await res.text();
        let json;
        try {
            json = JSON.parse(resText);
        } catch (e) {
            console.error('saveGemItemAdmin non-JSON response:', resText);
            alert('❌ เซิร์ฟเวอร์ตอบกลับไม่ถูกต้อง: ' + resText.substring(0, 200));
            return;
        }

        if (json.status === 'success') {
            alert('✅ บันทึกไอเทมอัญมณีเรียบร้อยแล้ว!');
            resetGemForm();
            loadGemItemsAdmin();
        } else {
            alert('❌ เกิดข้อผิดพลาด: ' + (json.message || 'บันทึกไม่สำเร็จ'));
        }
    } catch (err) {
        console.error('saveGemItemAdmin error:', err);
        alert('❌ เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ' + (err.message || ''));
    }
}

async function deleteGemItemAdmin(id, name) {
    if (!confirm(`คุณต้องการลบอัญมณี "${name}" (ID: ${id}) ใช่หรือไม่?`)) return;

    try {
        const res = await fetch('../api/equipment_service.php?action=delete_item', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const json = await res.json();
        if (json.status === 'success') {
            alert('✅ ลบอัญมณีเรียบร้อยแล้ว');
            loadGemItemsAdmin();
        } else {
            alert('❌ ไม่สามารถลบได้: ' + (json.message || ''));
        }
    } catch (err) {
        console.error('deleteGemItemAdmin error:', err);
        alert('❌ ข้อผิดพลาดในการเชื่อมต่อ');
    }
}

function populateGemEventTargetDropdown(gems) {
    const sel = document.getElementById('gem-event-target-id');
    if (!sel) return;
    const curVal = sel.value;
    let html = '<option value="">-- เลือกอัญมณีที่เป็นรางวัลใหญ่ของกิจกรรม --</option>';
    (gems || []).forEach(g => {
        const shapeName = g.shape === 'triangle' ? 'สามเหลี่ยม' : (g.shape === 'square' ? 'สี่เหลี่ยม' : 'ห้าเหลี่ยม');
        html += `<option value="${g.id}">[${g.grade}] ${g.name} (${shapeName}) - ${g.skill_name || g.skill_category}</option>`;
    });
    sel.innerHTML = html;
    if (curVal && sel.querySelector(`option[value="${curVal}"]`)) {
        sel.value = curVal;
    }
}

window.onAdminSelectTargetGem = function (itemId) {
    const previewBox = document.getElementById('gem-event-target-preview');
    const badge = document.getElementById('gem-event-target-badge');
    if (!previewBox) return;

    if (!itemId) {
        previewBox.style.display = 'none';
        if (badge) badge.innerText = '';
        return;
    }

    const item = (window.currentAdminGems || []).find(g => String(g.id) === String(itemId));
    if (!item) {
        previewBox.style.display = 'none';
        if (badge) badge.innerText = '';
        return;
    }

    const svgImg = window.generateGemSvgPreview(item.shape, item.grade, 52, item.gem_color);
    const shapeNames = { triangle: 'สามเหลี่ยม', square: 'สี่เหลี่ยม', pentagon: 'ห้าเหลี่ยม' };

    previewBox.style.display = 'flex';
    previewBox.innerHTML = `
        <div style="flex-shrink:0;">${svgImg}</div>
        <div style="flex:1; min-width:0;">
            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                <span style="background:rgba(192,132,252,0.2); border:1px solid #c084fc; color:#c084fc; font-weight:800; font-size:10px; padding:1px 6px; border-radius:4px;">${item.grade}</span>
                <strong style="color:#fff; font-size:13px;">${item.name}</strong>
                <span style="font-size:10.5px; color:#38bdf8;">(${shapeNames[item.shape] || item.shape})</span>
            </div>
            <div style="font-size:11px; color:#fbbf24; margin-top:2px;">
                ⚡ ${item.skill_name || item.skill_category} (${parseFloat(item.trigger_rate_percent || 90)}%)
            </div>
            <div style="font-size:10.5px; color:#94a3b8; margin-top:2px; line-height:1.2;">
                ${item.skill_description || '-'}
            </div>
        </div>
    `;

    if (badge) {
        badge.innerHTML = `👑 รางวัลใหญ่: <strong>${item.name}</strong>`;
    }
};

// =========================================================================
// AI SHADOW GEMS SCHEME GENERATOR & VISUAL AURA CARDS EDITOR
// =========================================================================

function getDefaultGemShadowsState() {
    return [
        { slot: 1, code: 'shadow_tier_1', name: 'เศษเงามรกตศิลา A', grade: 'A', shape: 'triangle', color: '#64748b', aura: 'none', intensity: 70, rate: 40.0, req_count: 15 },
        { slot: 2, code: 'shadow_tier_2', name: 'ผลึกเงามหาเวทย์เขียว A', grade: 'A', shape: 'square', color: '#10b981', aura: 'neon', intensity: 90, rate: 30.0, req_count: 15 },
        { slot: 3, code: 'shadow_tier_3', name: 'อัญมณีเงาไซเบอร์ฟ้า A+', grade: 'A+', shape: 'pentagon', color: '#00e5ff', aura: 'cyan', intensity: 110, rate: 15.0, req_count: 10 },
        { slot: 4, code: 'shadow_tier_4', name: 'ดวงตาเงามหาเวทย์ม่วง S', grade: 'S', shape: 'hexagon', color: '#a855f7', aura: 'purple', intensity: 140, rate: 10.0, req_count: 5 },
        { slot: 5, code: 'shadow_tier_5', name: 'หัวใจเงาสุวรรณจักรพรรดิ SS+', grade: 'SS+', shape: 'star', color: '#f59e0b', aura: 'gold', intensity: 180, rate: 5.0, req_count: 2 }
    ];
}

window.aiGemShadowsState = getDefaultGemShadowsState();
window.activeFeaturedGemShadowSlot = 5;

function getGemCrystalShapeIcon(shape) {
    const map = {
        triangle: '🔺',
        square: '🔷',
        pentagon: '⬠',
        hexagon: '⬡',
        star: '⭐',
        diamond: '💎'
    };
    return map[shape] || '💎';
}

function getGemShadowAuraBoxStyle(aura, color, intensity, size = 60) {
    const baseColor = color || '#a855f7';
    const factor = Math.max(0.3, Math.min(2.5, (intensity || 100) / 100));
    const glow1 = Math.round(6 * factor);
    const glow2 = Math.round(16 * factor);
    const glow3 = Math.round(28 * factor);

    let bg = `radial-gradient(circle at 50% 50%, ${baseColor}33 0%, rgba(15,23,42,0.92) 75%)`;
    let boxShadow = `0 0 ${glow1}px ${baseColor}, 0 0 ${glow2}px ${baseColor}88`;

    if (aura === 'none') {
        boxShadow = `0 2px 8px rgba(0,0,0,0.6)`;
        bg = 'rgba(15,23,42,0.9)';
    } else if (aura === 'cyan') {
        boxShadow = `0 0 ${glow1}px #00e5ff, 0 0 ${glow2}px #00e5ff88, 0 0 ${glow3}px rgba(0,229,255,0.4)`;
        bg = `radial-gradient(circle, rgba(0,229,255,0.28) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'purple') {
        boxShadow = `0 0 ${glow1}px #c084fc, 0 0 ${glow2}px #a855f788, 0 0 ${glow3}px rgba(168,85,247,0.4)`;
        bg = `radial-gradient(circle, rgba(168,85,247,0.28) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'gold') {
        boxShadow = `0 0 ${glow1}px #ffd700, 0 0 ${glow2}px #f59e0b99, 0 0 ${glow3}px rgba(245,158,11,0.5)`;
        bg = `radial-gradient(circle, rgba(255,215,0,0.32) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'crimson') {
        boxShadow = `0 0 ${glow1}px #ef4444, 0 0 ${glow2}px #dc262688, 0 0 ${glow3}px rgba(220,38,38,0.45)`;
        bg = `radial-gradient(circle, rgba(239,68,68,0.3) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'orange') {
        boxShadow = `0 0 ${glow1}px #f97316, 0 0 ${glow2}px #ea580c88, 0 0 ${glow3}px rgba(249,115,22,0.45)`;
        bg = `radial-gradient(circle, rgba(249,115,22,0.3) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'neon') {
        boxShadow = `0 0 ${glow1}px #10b981, 0 0 ${glow2}px #05966999, 0 0 ${glow3}px rgba(16,185,129,0.4)`;
        bg = `radial-gradient(circle, rgba(16,185,129,0.28) 0%, rgba(15,23,42,0.92) 75%)`;
    } else if (aura === 'rainbow') {
        boxShadow = `0 0 ${glow1}px #f43f5e, 0 0 ${glow2}px #38bdf899, 0 0 ${glow3}px #a855f777`;
        bg = `radial-gradient(circle, rgba(244,63,94,0.28) 0%, rgba(56,189,248,0.25) 50%, rgba(15,23,42,0.92) 75%)`;
    }

    return `width:${size}px; height:${size}px; border-radius:12px; background:${bg}; box-shadow:${boxShadow}; border:2px solid ${baseColor}; display:flex; align-items:center; justify-content:center; transition:all 0.25s ease; position:relative;`;
}

function renderGemShadowsEditor() {
    const container = document.getElementById('gem-shadow-cards-editor');
    if (!container) return;

    const auraOptions = [
        { v: 'none', t: 'ไม่มีออร่า' },
        { v: 'neon', t: '🟢 นีออนมรกต' },
        { v: 'cyan', t: '🔷 ฟ้าไซเบอร์' },
        { v: 'purple', t: '🔮 ม่วงเวทมนตร์' },
        { v: 'orange', t: '🔥 ส้มอัคคี' },
        { v: 'crimson', t: '🔴 แดงเพลิง' },
        { v: 'gold', t: '👑 ทองจักรพรรดิ' },
        { v: 'rainbow', t: '🌈 รุ้งปริซึม' }
    ];

    const shapeOptions = [
        { v: 'triangle', t: '🔺 สามเหลี่ยม' },
        { v: 'square', t: '🔷 สี่เหลี่ยม' },
        { v: 'pentagon', t: '⬠ ห้าเหลี่ยม' },
        { v: 'hexagon', t: '⬡ หกเหลี่ยม' },
        { v: 'star', t: '⭐ ดาว' },
        { v: 'diamond', t: '💎 เพชร' }
    ];

    const gradeColors = {
        'A': '#94a3b8',
        'A+': '#38bdf8',
        'S': '#a855f7',
        'SS+': '#f59e0b'
    };

    container.innerHTML = window.aiGemShadowsState.map((s, idx) => {
        const isFeatured = (parseInt(s.slot, 10) === parseInt(window.activeFeaturedGemShadowSlot, 10));
        const gradeColor = gradeColors[s.grade] || '#ffd700';

        return `
            <div style="background:rgba(15,23,42,0.88); border:${isFeatured ? '2.5px solid #ffd700' : '1.5px solid rgba(255,255,255,0.12)'}; border-radius:12px; padding:10px 8px; display:flex; flex-direction:column; gap:8px; box-shadow:${isFeatured ? '0 0 18px rgba(255,215,0,0.45)' : 'none'}; transition:all 0.25s ease; position:relative;">
                <!-- Header: Slot Badge & Grade -->
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="font-size:11px; font-weight:800; color:#cbd5e1;">เงาชิ้นที่ ${s.slot}</span>
                    <span style="background:${gradeColor}22; color:${gradeColor}; border:1px solid ${gradeColor}88; font-size:10px; font-weight:900; padding:1px 6px; border-radius:4px;">
                        [${s.grade}]
                    </span>
                </div>

                <!-- Featured Pill Button -->
                <button type="button" onclick="setFeaturedGemShadowSlot(${s.slot})" 
                    style="width:100%; font-size:10px; font-weight:900; padding:4px 6px; border-radius:6px; cursor:pointer; border:none; display:flex; align-items:center; justify-content:center; gap:4px;
                    ${isFeatured
                ? 'background:linear-gradient(135deg, #ffd700, #f59e0b); color:#000; box-shadow:0 0 10px rgba(255,215,0,0.6);'
                : 'background:rgba(255,255,255,0.06); color:#94a3b8; border:1px dashed rgba(255,255,255,0.2);'}">
                    ${isFeatured ? '👑 แสดงเด่น (FEATURED)' : '⭐ ตั้งเป็นเงาเด่น'}
                </button>

                <!-- Visual Aura & Shape Preview Box -->
                <div style="display:flex; justify-content:center; align-items:center; padding:6px 0;">
                    <div id="gem-shadow-box-prev-${idx}" style="${getGemShadowAuraBoxStyle(s.aura, s.color, s.intensity, 64)}">
                        <span style="font-size:32px; filter:drop-shadow(0 0 10px ${s.color}); user-select:none;">
                            ${getGemCrystalShapeIcon(s.shape)}
                        </span>
                        ${isFeatured ? `<div style="position:absolute; top:-6px; right:-6px; font-size:14px; filter:drop-shadow(0 0 4px #ffd700);">👑</div>` : ''}
                    </div>
                </div>

                <!-- Name Input -->
                <div>
                    <label style="font-size:10px; color:#94a3b8; display:block; margin-bottom:2px;">ชื่อเงา:</label>
                    <input type="text" value="${s.name || ''}" 
                        oninput="updateGemShadowField(${idx}, 'name', this.value)" 
                        style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.45); border:1px solid #334155; border-radius:6px; color:#fff; font-size:10.5px; padding:4px 6px;">
                </div>

                <!-- Shape & Color Row -->
                <div style="display:flex; gap:4px;">
                    <div style="flex:1;">
                        <label style="font-size:9.5px; color:#94a3b8; display:block; margin-bottom:2px;">ทรง:</label>
                        <select onchange="updateGemShadowField(${idx}, 'shape', this.value)"
                            style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.45); border:1px solid #334155; border-radius:6px; color:#fff; font-size:10px; padding:3px 4px;">
                            ${shapeOptions.map(opt => `<option value="${opt.v}" ${s.shape === opt.v ? 'selected' : ''}>${opt.t}</option>`).join('')}
                        </select>
                    </div>
                    <div style="width:40px;">
                        <label style="font-size:9.5px; color:#94a3b8; display:block; margin-bottom:2px;">สี:</label>
                        <input type="color" value="${s.color || '#10b981'}" 
                            oninput="updateGemShadowField(${idx}, 'color', this.value)" 
                            style="width:100%; height:26px; border:none; border-radius:5px; cursor:pointer; background:transparent; padding:0;">
                    </div>
                </div>

                <!-- Aura Selector -->
                <div>
                    <label style="font-size:9.5px; color:#94a3b8; display:block; margin-bottom:2px;">แสงออร่า:</label>
                    <select onchange="updateGemShadowField(${idx}, 'aura', this.value)"
                        style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.45); border:1px solid #334155; border-radius:6px; color:#fff; font-size:10px; padding:3px 4px;">
                        ${auraOptions.map(opt => `<option value="${opt.v}" ${s.aura === opt.v ? 'selected' : ''}>${opt.t}</option>`).join('')}
                    </select>
                </div>

                <!-- Aura Intensity Slider -->
                <div>
                    <div style="display:flex; justify-content:space-between; font-size:9.5px; color:#94a3b8; margin-bottom:1px;">
                        <span>ความสว่าง:</span>
                        <span id="gem-shadow-int-label-${idx}" style="color:${s.color}; font-weight:700;">${s.intensity || 100}%</span>
                    </div>
                    <input type="range" min="40" max="220" value="${s.intensity || 100}" 
                        oninput="updateGemShadowField(${idx}, 'intensity', this.value)" 
                        style="width:100%; height:4px; accent-color:${s.color}; cursor:pointer;">
                </div>

                <!-- Drop Rate % & Required Count -->
                <div style="display:flex; gap:4px;">
                    <div style="flex:1;">
                        <label style="font-size:9.5px; color:#facc15; font-weight:700; display:block; margin-bottom:2px;">เรตดรอป (%):</label>
                        <input type="number" step="0.5" min="0" max="100" id="gem-rate-${s.slot}" value="${s.rate || 0}" 
                            oninput="updateGemShadowField(${idx}, 'rate', this.value)" 
                            style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.5); border:1px solid #eab308; border-radius:6px; color:#fef08a; font-size:11px; font-weight:800; padding:4px 6px; text-align:center;">
                    </div>
                    <div style="width:48px;">
                        <label style="font-size:9.5px; color:#94a3b8; display:block; margin-bottom:2px;">ใช้คราฟต์:</label>
                        <input type="number" min="1" max="99" value="${s.req_count || 5}" 
                            oninput="updateGemShadowField(${idx}, 'req_count', this.value)" 
                            style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.45); border:1px solid #334155; border-radius:6px; color:#fff; font-size:11px; font-weight:700; padding:4px 4px; text-align:center;">
                    </div>
                </div>
            </div>
        `;
    }).join('');

    // Update hidden config field
    const jsonField = document.getElementById('gem-shadow-config-json');
    if (jsonField) {
        jsonField.value = JSON.stringify(window.aiGemShadowsState);
    }
    const featField = document.getElementById('gem-featured-shadow-slot');
    if (featField) {
        featField.value = String(window.activeFeaturedGemShadowSlot);
    }
}

function updateGemShadowField(idx, field, val) {
    const s = window.aiGemShadowsState[idx];
    if (!s) return;

    if (field === 'rate') {
        s.rate = Math.max(0, Math.min(100, parseFloat(val) || 0));
    } else if (field === 'req_count') {
        s.req_count = Math.max(1, parseInt(val, 10) || 5);
    } else if (field === 'intensity') {
        s.intensity = Math.max(40, Math.min(220, parseInt(val, 10) || 100));
        const lbl = document.getElementById(`gem-shadow-int-label-${idx}`);
        if (lbl) lbl.innerText = s.intensity + '%';
    } else {
        s[field] = val;
    }

    // Refresh live box styling directly
    const box = document.getElementById(`gem-shadow-box-prev-${idx}`);
    if (box) {
        box.setAttribute('style', getGemShadowAuraBoxStyle(s.aura, s.color, s.intensity, 64));
        const span = box.querySelector('span');
        if (span) {
            span.innerHTML = getGemCrystalShapeIcon(s.shape);
            span.style.filter = `drop-shadow(0 0 10px ${s.color})`;
        }
    }

    // Update hidden config field
    const jsonField = document.getElementById('gem-shadow-config-json');
    if (jsonField) {
        jsonField.value = JSON.stringify(window.aiGemShadowsState);
    }
}

function setFeaturedGemShadowSlot(slot) {
    window.activeFeaturedGemShadowSlot = parseInt(slot, 10) || 5;
    const featField = document.getElementById('gem-featured-shadow-slot');
    if (featField) featField.value = String(window.activeFeaturedGemShadowSlot);
    renderGemShadowsEditor();
}

// Procedural AI Shadow Randomizer (click repeatedly for unlimited non-repeating variations)
function generateAiShadowGemsScheme() {
    const targetSelect = document.getElementById('gem-event-target-id');
    const selectedGemName = targetSelect && targetSelect.selectedOptions[0] ? targetSelect.selectedOptions[0].text : '';

    const THEMES = [
        {
            theme: 'นาคราช & มังกรสวรรค์ (Dragon Naga)',
            shades: ['#0f766e', '#10b981', '#06b6d4', '#6366f1', '#f59e0b'],
            auras: ['none', 'neon', 'cyan', 'purple', 'gold'],
            shapes: ['triangle', 'square', 'pentagon', 'hexagon', 'star'],
            names: [
                ['เศษเกล็ดนาคา A', 'เศษเขี้ยวมังกรศิลา A', 'เศษศิลาบาดาล A'],
                ['ผลึกมรกตนาคินทร์ A', 'ผลึกเกล็ดมังกรเขียว A', 'ผลึกวิหคพิภพ A'],
                ['แก้วสมุทรนาคราช A+', 'หินมณีวารีฟ้า A+', 'อัญมณีหยาดทิพย์ A+'],
                ['เนตรมังกรเวทมนตร์ S', 'ดวงตามรกตบรรพกาล S', 'มหาเนตรอัคคี S'],
                ['หัวใจสุวรรณนาคราชจักรพรรดิ SS+', 'ดวงใจพญามังกรทอง SS+', 'แก้วสารพัดนึกอนันตกาล SS+']
            ]
        },
        {
            theme: 'ดวงดาว & เนบิวลาคอสมิก (Cosmic Space)',
            shades: ['#475569', '#3b82f6', '#06b6d4', '#a855f7', '#f43f5e'],
            auras: ['none', 'cyan', 'neon', 'purple', 'rainbow'],
            shapes: ['triangle', 'square', 'pentagon', 'hexagon', 'diamond'],
            names: [
                ['เศษอุกกาบาตทมิฬ A', 'เศษธุลีเนบิวลา A', 'เศษสะเก็ดดาว A'],
                ['ผลึกคอสมิกเขียว A', 'ผลึกแสงเหนือออโรร่า A', 'ผลึกอุกกาบาตฟ้า A'],
                ['แก้วดารารัศมี A+', 'ปริซึมซูเปอร์โนวา A+', 'อัญมณีห้วงอวกาศ A+'],
                ['แกนพลังกาแล็กซี S', 'ดวงตามหาจักรวาล S', 'คริสตัลดวงฤกษ์ S'],
                ['หัวใจเอกภพมหาอนันต์ SS+', 'แกนดาวเนบิวลาจักรพรรดิ SS+', 'ดารารัศมีมงกุฎจักรวาล SS+']
            ]
        },
        {
            theme: 'มหาเวทย์ & อักขระรูนโบราณ (Mystic Arcana)',
            shades: ['#334155', '#14b8a6', '#38bdf8', '#c084fc', '#ffd700'],
            auras: ['none', 'neon', 'cyan', 'purple', 'gold'],
            shapes: ['triangle', 'square', 'pentagon', 'hexagon', 'star'],
            names: [
                ['เศษศิลาอักขระเวทย์ A', 'เศษหินรูนโบราณ A', 'เศษผลึกมนตรา A'],
                ['ผลึกมรกตมนตรา A', 'ผลึกวารีเวทมนตร์ A', 'ผลึกแก้ววิเศษ A'],
                ['อัญมณีรูนคราม A+', 'ดวงแก้วมนตราสวรรค์ A+', 'ศิลาเสกสรรค์ A+'],
                ['ดวงตาจอมเวทย์นิรันดร์ S', 'คทาวิเศษโบราณ S', 'มณีคาถาชั้นสูง S'],
                ['ศิลานักปราชญ์จอมจักรพรรดิ SS+', 'ผลึกมหามนตราเทวะ SS+', 'หัวใจมหาเวทย์บรรพกาล SS+']
            ]
        },
        {
            theme: 'เพลิงพิโรธ & ภูเขาไฟลาวา (Volcano Inferno)',
            shades: ['#57534e', '#f97316', '#ef4444', '#dc2626', '#eab308'],
            auras: ['none', 'orange', 'crimson', 'crimson', 'gold'],
            shapes: ['triangle', 'square', 'pentagon', 'hexagon', 'star'],
            names: [
                ['เศษเถ้าภูเขาไฟ A', 'เศษศิลาลาวาดำ A', 'เศษถ่านเพลิงหิน A'],
                ['ผลึกอัคคีลาวา A', 'ผลึกเพลิงพิโรธ A', 'ผลึกเปลวสุริยัน A'],
                ['อัญมณีเพลิงโลกันตร์ A+', 'ทับทิมเปลวสุริยะ A+', 'ผลึกแมกมาเดือด A+'],
                ['ดวงตาฟีนิกซ์เพลิง S', 'ศิลาสุริยคราสเพลิง S', 'มณีเปลวเพลิงเทวะ S'],
                ['หัวใจเพลิงสุริยันบรรพกาล SS+', 'ศิลาเพลิงสุวรรณจักรพรรดิ SS+', 'แก่นแท้เพลิงอัมรินทร์ SS+']
            ]
        },
        {
            theme: 'มหาสมุทร & คลื่นวารีคราม (Ocean Abyss)',
            shades: ['#1e293b', '#0284c7', '#06b6d4', '#6366f1', '#38bdf8'],
            auras: ['none', 'cyan', 'cyan', 'purple', 'rainbow'],
            shapes: ['triangle', 'square', 'pentagon', 'hexagon', 'diamond'],
            names: [
                ['เศษเปลือกหอยใต้สมุทร A', 'เศษปะการังศิลา A', 'เศษหินก้นมหาสมุทร A'],
                ['ผลึกวารีมรกต A', 'ผลึกคลื่นสายฟ้า A', 'ผลึกน้ำวนสีคราม A'],
                ['ไพลินหยาดน้ำตาเมอร์เมด A+', 'อัญมณีไข่มุกทะเลคราม A+', 'แก้วธาราไหลวน A+'],
                ['ดวงตาพญาวาฬวารี S', 'หัวใจมหาสมุทรน้ำลึก S', 'ผลึกคลื่นยักษ์สึนามิ S'],
                ['มณีตรีศูลโพไซดอน SS+', 'หัวใจมหาธรณีย์วารีสวรรค์ SS+', 'ดวงใจราชันย์มหาสมุทร SS+']
            ]
        }
    ];

    // Pick a random theme
    const themeObj = THEMES[Math.floor(Math.random() * THEMES.length)];

    // Randomized balanced drop rates totaling 100%
    const rateDistributions = [
        [40.0, 30.0, 15.0, 10.0, 5.0],
        [38.0, 32.0, 16.0, 9.0, 5.0],
        [42.0, 28.0, 15.0, 11.0, 4.0],
        [37.0, 31.0, 17.0, 10.0, 5.0],
        [45.0, 25.0, 15.0, 10.0, 5.0]
    ];
    const pickedRates = rateDistributions[Math.floor(Math.random() * rateDistributions.length)];

    const reqCounts = [
        [15, 15, 10, 5, 2],
        [20, 15, 10, 5, 1],
        [12, 12, 8, 4, 2],
        [15, 12, 10, 6, 2]
    ][Math.floor(Math.random() * 4)];

    const grades = ['A', 'A', 'A+', 'S', 'SS+'];
    const intensities = [
        Math.floor(60 + Math.random() * 20),
        Math.floor(85 + Math.random() * 20),
        Math.floor(110 + Math.random() * 25),
        Math.floor(140 + Math.random() * 30),
        Math.floor(175 + Math.random() * 35)
    ];

    const newShadows = [];
    for (let i = 0; i < 5; i++) {
        const nameCandidates = themeObj.names[i];
        const pickedName = nameCandidates[Math.floor(Math.random() * nameCandidates.length)];

        newShadows.push({
            slot: i + 1,
            code: `shadow_tier_${i + 1}`,
            name: pickedName,
            grade: grades[i],
            shape: themeObj.shapes[i],
            color: themeObj.shades[i],
            aura: themeObj.auras[i],
            intensity: intensities[i],
            rate: pickedRates[i],
            req_count: reqCounts[i]
        });
    }

    window.aiGemShadowsState = newShadows;
    window.activeFeaturedGemShadowSlot = 5; // Default slot 5 as the crowning SS+ featured piece

    renderGemShadowsEditor();

    // Visual feedback animation
    const editor = document.getElementById('gem-shadow-cards-editor');
    if (editor) {
        editor.style.opacity = '0.3';
        editor.style.transform = 'scale(0.98)';
        setTimeout(() => {
            editor.style.transition = 'all 0.3s ease';
            editor.style.opacity = '1';
            editor.style.transform = 'scale(1)';
        }, 80);
    }
}

async function loadGemGachaEventConfigAdmin() {
    // If the legacy event editor container is removed (now consolidated centrally in Event Manager), exit cleanly
    if (!document.getElementById('gem-event-id')) {
        return;
    }
    try {
        const res = await fetch('../api/equipment_service.php?action=get_gem_gacha_event&_t=' + Date.now());
        const json = await res.json();
        if (json.status === 'success' && json.event) {
            const ev = json.event;
            document.getElementById('gem-event-id').value = ev.id || '';
            document.getElementById('gem-event-name').value = ev.event_name || 'กิจกรรมสุ่มอัญมณีมหาเวทย์ & เงาลึกลับ';
            document.getElementById('gem-event-cost').value = ev.cost_diamond || 100;
            document.getElementById('gem-event-active').value = (ev.is_active == 1) ? '1' : '0';

            // Parse custom shadows config if stored
            if (ev.shadow_config_json) {
                try {
                    const parsed = (typeof ev.shadow_config_json === 'string') ? JSON.parse(ev.shadow_config_json) : ev.shadow_config_json;
                    if (Array.isArray(parsed) && parsed.length === 5) {
                        window.aiGemShadowsState = parsed;
                    }
                } catch (e) {
                    console.warn('loadGemGachaEventConfigAdmin parse shadow_config_json warning:', e);
                }
            } else {
                // Initialize default rates from event columns
                window.aiGemShadowsState[0].rate = parseFloat(ev.shadow_rate_1 || 40);
                window.aiGemShadowsState[1].rate = parseFloat(ev.shadow_rate_2 || 30);
                window.aiGemShadowsState[2].rate = parseFloat(ev.shadow_rate_3 || 15);
                window.aiGemShadowsState[3].rate = parseFloat(ev.shadow_rate_4 || 10);
                window.aiGemShadowsState[4].rate = parseFloat(ev.shadow_rate_5 || 5);
            }

            if (ev.featured_shadow_slot) {
                window.activeFeaturedGemShadowSlot = parseInt(ev.featured_shadow_slot, 10) || 5;
            }

            renderGemShadowsEditor();

            if (ev.start_date && document.getElementById('gem-event-start')) {
                document.getElementById('gem-event-start').value = ev.start_date.replace(' ', 'T').substring(0, 16);
            } else if (document.getElementById('gem-event-start')) {
                document.getElementById('gem-event-start').value = '';
            }
            if (ev.end_date && document.getElementById('gem-event-end')) {
                document.getElementById('gem-event-end').value = ev.end_date.replace(' ', 'T').substring(0, 16);
            } else if (document.getElementById('gem-event-end')) {
                document.getElementById('gem-event-end').value = '';
            }

            if (ev.target_item_id) {
                const sel = document.getElementById('gem-event-target-id');
                if (sel) {
                    sel.value = ev.target_item_id;
                    window.onAdminSelectTargetGem(ev.target_item_id);
                }
            }

            const badge = document.getElementById('gem-event-status-badge');
            if (badge) {
                if (ev.is_active == 1) {
                    badge.innerHTML = '🟢 เปิดกิจกรรมสุ่มอยู่';
                    badge.style.background = 'rgba(16,185,129,0.2)';
                    badge.style.color = '#34d399';
                    badge.style.borderColor = '#10b981';
                } else {
                    badge.innerHTML = '🔴 ปิดกิจกรรม';
                    badge.style.background = 'rgba(239,68,68,0.2)';
                    badge.style.color = '#ef4444';
                    badge.style.borderColor = '#ef4444';
                }
            }
        } else {
            renderGemShadowsEditor();
        }
    } catch (err) {
        console.warn('loadGemGachaEventConfigAdmin warn:', err);
        renderGemShadowsEditor();
    }
}

async function saveGemGachaEventAdmin(event) {
    if (event && event.preventDefault) event.preventDefault();

    const targetIdVal = document.getElementById('gem-event-target-id')?.value;
    const startVal = document.getElementById('gem-event-start')?.value ? document.getElementById('gem-event-start').value.replace('T', ' ') + ':00' : null;
    const endVal = document.getElementById('gem-event-end')?.value ? document.getElementById('gem-event-end').value.replace('T', ' ') + ':00' : null;

    // Rates from shadow state
    const r1 = parseFloat(window.aiGemShadowsState[0]?.rate || 40);
    const r2 = parseFloat(window.aiGemShadowsState[1]?.rate || 30);
    const r3 = parseFloat(window.aiGemShadowsState[2]?.rate || 15);
    const r4 = parseFloat(window.aiGemShadowsState[3]?.rate || 10);
    const r5 = parseFloat(window.aiGemShadowsState[4]?.rate || 5);

    const totalRate = r1 + r2 + r3 + r4 + r5;
    if (Math.abs(totalRate - 100) > 0.5) {
        if (!confirm(`⚠️ อัตราการดรอปรวม 5 ชิ้นขณะนี้เท่ากับ ${totalRate}% (ควรเท่ากับ 100%)\nคุณต้องการบันทึกต่อไปหรือไม่?`)) {
            return;
        }
    }

    const payload = {
        id: document.getElementById('gem-event-id').value,
        event_name: document.getElementById('gem-event-name').value.trim(),
        cost_diamond: parseInt(document.getElementById('gem-event-cost').value) || 100,
        target_item_id: targetIdVal ? parseInt(targetIdVal) : null,
        start_date: startVal,
        end_date: endVal,
        is_active: parseInt(document.getElementById('gem-event-active').value) || 0,
        shadow_rate_1: r1,
        shadow_rate_2: r2,
        shadow_rate_3: r3,
        shadow_rate_4: r4,
        shadow_rate_5: r5,
        shadow_config_json: JSON.stringify(window.aiGemShadowsState),
        featured_shadow_slot: String(window.activeFeaturedGemShadowSlot)
    };

    try {
        const res = await fetch('../api/equipment_service.php?action=save_gem_gacha_event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const resText = await res.text();
        let json;
        try {
            json = JSON.parse(resText);
        } catch (e) {
            console.error('saveGemGachaEventAdmin non-JSON response:', resText);
            alert('❌ เกิดข้อผิดพลาดจากเซิร์ฟเวอร์: ' + resText.substring(0, 150));
            return;
        }

        if (json.status === 'success') {
            alert('✅ บันทึกกิจกรรมสุ่มอัญมณีเรียบร้อยแล้ว!');
            loadGemGachaEventConfigAdmin();
        } else {
            alert('❌ เกิดข้อผิดพลาด: ' + (json.message || 'บันทึกไม่สำเร็จ'));
        }
    } catch (err) {
        console.error('saveGemGachaEventAdmin error:', err);
        alert('❌ เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ' + (err.message || ''));
    }
}

// Hook tab switch to auto load gems data when gems tab opened
const origSwitchTab = window.switchTab;
if (typeof origSwitchTab === 'function') {
    window.switchTab = function (tabName) {
        origSwitchTab(tabName);
        if (tabName === 'gems') {
            loadGemItemsAdmin();
        }
    };
}

// Auto render shadow cards and load gacha event on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        renderGemShadowsEditor();
        loadGemGachaEventConfigAdmin();
    });
} else {
    renderGemShadowsEditor();
    loadGemGachaEventConfigAdmin();
}
