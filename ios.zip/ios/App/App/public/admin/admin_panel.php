<?php
declare(strict_types=1);

/**
 * admin_panel.php - Admin Control Panel & Management API
 * PHP 8.4.25 / Nginx 1.31.6
 * Features:
 *  - Event Creation & Management (แจกเพชรและทองให้กับผู้เล่น)
 *  - Top-up Packages Management (เช่น 500 เพชร 30 บาท)
 *  - Skill Configuration for Characters and Dice (ปรับทอยแม่น, ดึงถอยหลัง 5/8 ตา)
 *  - Direct Server-wide Giveaway to all players via mailbox
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/cube_event_service.php';
require_once __DIR__ . '/../api/ota_deploy_service.php';
require_once __DIR__ . '/../api/shop_menus_service.php';
require_once __DIR__ . '/../api/board_studio_service.php';

// Polyfills for PHP 7.4 compatibility
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return $needle === '' || $needle === substr($haystack, -strlen($needle));
    }
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = getDbConnection();
$__adminStamp = __DIR__ . '/../config/.admin_schema_v3.stamp';
if (!@file_exists($__adminStamp)) {
    ensureAdminTable($db);
    ensureTopupPackagesTable($db);
    ensureFrameColumns($db);
    @file_put_contents($__adminStamp, (string)time());
}

// Handle GET logout directly
if (($_GET['action'] ?? '') === 'logout') {
    unset($_SESSION['snake_admin_id'], $_SESSION['snake_admin_user'], $_SESSION['snake_admin_name']);
    session_destroy();
    header('Location: admin_panel.php');
    exit;
}

// Check if request is an API request (JSON) or Web UI
$isAjax = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) 
          || (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json'))
          || isset($_GET['api']);

if ($isAjax) {
    handleAdminApi($db);
} else {
    if (empty($_SESSION['snake_admin_id'])) {
        renderAdminLoginUi();
    } else {
        renderAdminWebUi($db);
    }
}

/**
 * สร้างตาราง admins อัตโนมัติหากยังไม่มี และเพิ่มบัญชีเริ่มต้น (admin / admin1234)
 */
function ensureAdminTable(mysqli $db): void {
    $db->query("
        CREATE TABLE IF NOT EXISTS `admins` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `username` VARCHAR(60) NOT NULL,
            `password_hash` VARCHAR(255) NOT NULL,
            `display_name` VARCHAR(100) NOT NULL DEFAULT 'ผู้ดูแลระบบ (Admin)',
            `email` VARCHAR(120) DEFAULT NULL,
            `avatar_url` MEDIUMTEXT DEFAULT NULL COMMENT 'รูปโปรไฟล์แอดมิน',
            `role` VARCHAR(30) NOT NULL DEFAULT 'SUPER_ADMIN',
            `last_login_at` DATETIME DEFAULT NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_admin_username` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    @$db->query("ALTER TABLE `admins` ADD COLUMN IF NOT EXISTS `avatar_url` MEDIUMTEXT NULL COMMENT 'รูปโปรไฟล์แอดมิน'");

    $check = $db->query("SELECT COUNT(*) AS cnt FROM `admins`");
    $cnt = $check ? (int)($check->fetch_assoc()['cnt'] ?? 0) : 0;
    if ($cnt === 0) {
        $defaultUser = 'admin';
        $defaultPassHash = password_hash('admin1234', PASSWORD_DEFAULT);
        $defaultName = 'Super Admin';
        $defaultEmail = 'admin@snake3d.local';
        $stmt = $db->prepare("INSERT INTO `admins` (username, password_hash, display_name, email, role) VALUES (?, ?, ?, ?, 'SUPER_ADMIN')");
        if ($stmt) {
            $stmt->bind_param("ssss", $defaultUser, $defaultPassHash, $defaultName, $defaultEmail);
            $stmt->execute();
            $stmt->close();
        }
    }
}

/**
 * ตรวจสอบและสร้างคอลัมน์ระบบกรอบรูป, แสงเออร่า และกิจกรรมสุ่มการ์ดแพ็ค
 */
function ensureFrameColumns(mysqli $db): void {
    static $done = false;
    if ($done) return;
    $done = true;
    if (@file_exists(__DIR__ . '/../config/.admin_schema_v3.stamp')) return;
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `win_rate_bonus` DECIMAL(5,2) NOT NULL DEFAULT 5.00 COMMENT 'อัตราชนะเพิ่มเติม (%)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `roll_rate` DECIMAL(5,2) NOT NULL DEFAULT 20.00 COMMENT 'อัตราการทอย / คุมเต๋า (%)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `play_skill_rate` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT 'อัตราการเล่นเก่ง / ฝีมือ'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `aura_type` VARCHAR(30) NOT NULL DEFAULT 'none' COMMENT 'none, white, cyan, yellow, gold, orange, crimson, purple, rainbow'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `aura_intensity` INT NOT NULL DEFAULT 100 COMMENT 'ระดับแสงเออร่า 10-100%'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `frame_fx` VARCHAR(40) NOT NULL DEFAULT 'pulse_breathe' COMMENT 'ลูกเล่นแอนิเมชันกรอบ'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `frame_scale` INT NOT NULL DEFAULT 120 COMMENT 'ขนาดสวมกรอบ %'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `avatar_url` MEDIUMTEXT NULL COMMENT 'รูปตัวอย่างกรอบรูป (PNG วงแหวนโปร่งใส)'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `color_hex` VARCHAR(25) NOT NULL DEFAULT '#FFD700' COMMENT 'สีขอบ'");
    @$db->query("ALTER TABLE `characters` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ข้อมูลชุดเงา AI และอัตราแลกกรอบ SS+/S+/S'");
    @$db->query("ALTER TABLE `characters` MODIFY COLUMN `grade` ENUM('B', 'A', 'A+', 'S', 'S+', 'SS+') NOT NULL DEFAULT 'A'");

    // ตรวจสอบคอลัมน์ในตาราง dice (รองรับเกรด A-SS+, Z+, ZZ+ แสงเออร่า และสีจุดแต้ม)
    @$db->query("ALTER TABLE `dice` MODIFY COLUMN `grade` VARCHAR(30) NOT NULL DEFAULT 'A' COMMENT 'ระดับของลูกเต๋า รองรับ A-SS+, Z+, ZZ+ หรือกำหนดเอง'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `image_url` MEDIUMTEXT NULL COMMENT 'รูปลูกเต๋า 3D'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `color_hex` VARCHAR(25) NOT NULL DEFAULT '#00e5ff' COMMENT 'สีตัวลูกเต๋า'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `pip_color_hex` VARCHAR(25) NOT NULL DEFAULT '#ffffff' COMMENT 'สีจุดแต้มบนเต๋า'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `aura_type` VARCHAR(30) NOT NULL DEFAULT 'none' COMMENT 'แสงเออร่าเต๋า'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `aura_intensity` INT NOT NULL DEFAULT 100 COMMENT 'ระดับแสง 10-500%'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `aura_fx` VARCHAR(40) NOT NULL DEFAULT 'pulse_breathe' COMMENT 'ลูกเล่นแสงเออร่า'");
    @$db->query("ALTER TABLE `dice` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ตั้งค่าข้อมูลการ์ดเงา 5 สี'");

    // Ensure gacha_events table exists
    $db->query("
        CREATE TABLE IF NOT EXISTS `gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(150) NOT NULL DEFAULT '🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+',
            `description` TEXT NULL,
            `event_type` ENUM('FRAME', 'DICE', 'BOTH') NOT NULL DEFAULT 'FRAME',
            `cost_diamond` INT NOT NULL DEFAULT 100,
            `cards_per_pack` INT NOT NULL DEFAULT 5,
            `target_character_id` INT NOT NULL DEFAULT 1,
            `target_dice_id` INT NOT NULL DEFAULT 1,
            `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00,
            `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `req_shadow_black` INT NOT NULL DEFAULT 15,
            `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
            `req_shadow_red` INT NOT NULL DEFAULT 15,
            `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00,
            `req_shadow_orange` INT NOT NULL DEFAULT 15,
            `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `req_shadow_blue` INT NOT NULL DEFAULT 10,
            `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `req_shadow_gold` INT NOT NULL DEFAULT 4,
            `rate_splus` DECIMAL(5,2) NOT NULL DEFAULT 3.00,
            `rate_shadow_special` DECIMAL(5,2) NOT NULL DEFAULT 15.00,
            `shadow_config_json` LONGTEXT NULL,
            `exchange_tiers_json` LONGTEXT NULL,
            `start_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_date` DATETIME NOT NULL DEFAULT '2030-12-31 23:59:59',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Ensure gacha_events columns
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `event_type` ENUM('FRAME', 'DICE', 'BOTH') NOT NULL DEFAULT 'FRAME'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `target_dice_id` INT NOT NULL DEFAULT 1");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `cards_per_pack` INT NOT NULL DEFAULT 5 COMMENT 'จำนวนการ์ดต่อแพ็ค'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `target_character_id` INT NOT NULL DEFAULT 1 COMMENT 'กรอบรูปเป้าหมายที่ได้รับจากการแลก'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00 COMMENT '% ออกเงาดำ A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_black` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาดำที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00 COMMENT '% ออกเงาแดง A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_red` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาแดงที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00 COMMENT '% ออกเงาส้ม A'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_orange` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาส้มที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00 COMMENT '% ออกเงาฟ้า A+'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_blue` INT NOT NULL DEFAULT 10 COMMENT 'จำนวนเงาฟ้าที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT '% ออกเงาทอง S'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_gold` INT NOT NULL DEFAULT 4 COMMENT 'จำนวนเงาทองที่ต้องสะสม'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ตั้งค่าการ์ดเงา 5 สี (สี/เออร่า/รูปเงา/เปอร์เซ็นต์)'");
    @$db->query("ALTER TABLE `gacha_events` ADD COLUMN IF NOT EXISTS `exchange_tiers_json` LONGTEXT NULL COMMENT 'อัตราจำนวนเงาที่ใช้แลกกรอบ SS+, S+, S'");

    // Auto-seed default gacha event if table is empty
    $chkEv = $db->query("SELECT id FROM `gacha_events` LIMIT 1");
    if (!$chkEv || $chkEv->num_rows === 0) {
        $targetCharId = 1;
        $cRes = $db->query("SELECT id FROM `characters` WHERE grade IN ('SS+', 'S+') ORDER BY id ASC LIMIT 1");
        if ($cRes && ($cRow = $cRes->fetch_assoc())) {
            $targetCharId = (int)$cRow['id'];
        }
        $db->query("
            INSERT INTO `gacha_events` 
            (event_name, description, event_type, cost_diamond, cards_per_pack, target_character_id, target_dice_id, rate_target_boost, start_date, end_date, is_active)
            VALUES 
            ('🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+', 'เปิดแพ็คสุ่มการ์ด 1 ใบใช้เพียง 100 เพชร ลุ้นรับการ์ด S+ พญานาคราช และเงาวัตถุดิบ 5 ชนิด', 'FRAME', 100, 5, {$targetCharId}, 1, 35.00, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1)
        ");
    }

    // Ensure dice_gacha_events table exists
    $db->query("
        CREATE TABLE IF NOT EXISTS `dice_gacha_events` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `event_name` VARCHAR(150) NOT NULL DEFAULT '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป',
            `description` TEXT NULL,
            `cost_diamond` INT NOT NULL DEFAULT 100,
            `target_dice_id` INT NOT NULL DEFAULT 1,
            `rate_target_boost` DECIMAL(5,2) NOT NULL DEFAULT 35.00,
            `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00,
            `req_shadow_black` INT NOT NULL DEFAULT 15,
            `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
            `req_shadow_red` INT NOT NULL DEFAULT 15,
            `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00,
            `req_shadow_orange` INT NOT NULL DEFAULT 15,
            `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `req_shadow_blue` INT NOT NULL DEFAULT 10,
            `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            `req_shadow_gold` INT NOT NULL DEFAULT 4,
            `shadow_config_json` LONGTEXT NULL,
            `start_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `end_date` DATETIME NOT NULL DEFAULT '2030-12-31 23:59:59',
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Ensure dice_gacha_events columns for the 5 shadow system (A to S)
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `cost_diamond` INT NOT NULL DEFAULT 100 COMMENT 'จำนวนเพชรที่ใช้สุ่ม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_black` DECIMAL(5,2) NOT NULL DEFAULT 90.00 COMMENT '% ออกเงาดำ A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_black` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาดำที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_red` DECIMAL(5,2) NOT NULL DEFAULT 80.00 COMMENT '% ออกเงาแดง A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_red` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาแดงที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_orange` DECIMAL(5,2) NOT NULL DEFAULT 70.00 COMMENT '% ออกเงาส้ม A'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_orange` INT NOT NULL DEFAULT 15 COMMENT 'จำนวนเงาส้มที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_blue` DECIMAL(5,2) NOT NULL DEFAULT 50.00 COMMENT '% ออกเงาฟ้า A+'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_blue` INT NOT NULL DEFAULT 10 COMMENT 'จำนวนเงาฟ้าที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `rate_shadow_gold` DECIMAL(5,2) NOT NULL DEFAULT 10.00 COMMENT '% ออกเงาทอง S'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `req_shadow_gold` INT NOT NULL DEFAULT 4 COMMENT 'จำนวนเงาทองที่ต้องสะสม'");
    @$db->query("ALTER TABLE `dice_gacha_events` ADD COLUMN IF NOT EXISTS `shadow_config_json` LONGTEXT NULL COMMENT 'ตั้งค่าข้อมูลการ์ดเงา 5 สี'");

    // Auto-seed default dice gacha event if table is empty
    $chkDiceEv = $db->query("SELECT id FROM `dice_gacha_events` LIMIT 1");
    if (!$chkDiceEv || $chkDiceEv->num_rows === 0) {
        $defaultTargetDiceId = 1;
        $dRes = $db->query("SELECT id FROM `dice` ORDER BY id DESC LIMIT 1");
        if ($dRes && ($dRow = $dRes->fetch_assoc())) {
            $defaultTargetDiceId = (int)$dRow['id'];
        }
        $db->query("
            INSERT INTO `dice_gacha_events` 
            (event_name, description, cost_diamond, target_dice_id, rate_target_boost, start_date, end_date, is_active)
            VALUES 
            ('🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป', 'สุ่มรับลูกเต๋า 3D พิเศษ พร้อมพลังคุมเต๋าและแสงเออร่า อัตราเรตอัปเป้าหมาย +35%', 100, {$defaultTargetDiceId}, 35.00, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1)
        ");
    }

    // Ensure events table for giveaways
    $db->query("
        CREATE TABLE IF NOT EXISTS `events` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(150) NOT NULL,
            `description` TEXT DEFAULT NULL,
            `event_type` ENUM('ADMIN_GIVEAWAY', 'LOGIN_REWARD', 'PROMO_CODE', 'MAINTENANCE_COMPENSATION') NOT NULL DEFAULT 'ADMIN_GIVEAWAY',
            `promo_code` VARCHAR(50) DEFAULT NULL,
            `reward_diamond` INT UNSIGNED NOT NULL DEFAULT 0,
            `reward_gold` INT UNSIGNED NOT NULL DEFAULT 0,
            `max_claims_total` INT UNSIGNED DEFAULT NULL,
            `current_claims_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `start_time` DATETIME NOT NULL,
            `end_time` DATETIME NOT NULL,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_by_admin` VARCHAR(100) NOT NULL DEFAULT 'Admin',
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

/**
 * ตรวจสอบและสร้างตาราง topup_packages (แพ็กเกจเติมเงินในเกม)
 */
function ensureTopupPackagesTable(mysqli $db): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $db->query("CREATE TABLE IF NOT EXISTS `topup_packages` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(150) NOT NULL,
        `type` VARCHAR(50) NOT NULL DEFAULT 'DIAMOND',
        `reward_diamond` INT NOT NULL DEFAULT 0,
        `reward_gold` BIGINT NOT NULL DEFAULT 0,
        `price_thb` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `type` VARCHAR(50) NOT NULL DEFAULT 'DIAMOND'");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `reward_diamond` INT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `reward_gold` BIGINT NOT NULL DEFAULT 0");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `price_thb` DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    @$db->query("ALTER TABLE `topup_packages` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1");
    @$db->query("ALTER TABLE `topup_packages` MODIFY COLUMN `reward_gold` BIGINT NOT NULL DEFAULT 0");

    $chk = $db->query("SELECT COUNT(*) AS cnt FROM `topup_packages`");
    $cnt = $chk ? (int)($chk->fetch_assoc()['cnt'] ?? 0) : 0;
    if ($cnt === 0) {
        $db->query("INSERT INTO `topup_packages` (`name`, `type`, `reward_diamond`, `reward_gold`, `price_thb`, `is_active`) VALUES
            ('แพ็กเกจเพชรเริ่มต้น (500 เพชร)', 'DIAMOND', 500, 0, 30.00, 1),
            ('แพ็กเกจทองมหาเศรษฐี (1,000,000 ทอง)', 'GOLD', 0, 1000000, 59.00, 1),
            ('แพ็กเกจเพชรสุดคุ้ม (1,200 เพชร + 50,000 ทอง)', 'COMBO', 1200, 50000, 69.00, 1),
            ('แพ็กเกจพรีเมียม VIP (3,000 เพชร + 2,500,000 ทอง)', 'COMBO', 3000, 2500000, 159.00, 1)");
    }
}
function renderAdminLoginUi(): void {
    header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบผู้ดูแลระบบ - Snake & Ladder 3D Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #090d16;
            --panel-bg: rgba(30, 41, 59, 0.92);
            --panel-border: rgba(0, 229, 255, 0.3);
            --primary: #00e5ff;
            --accent: #f59e0b;
            --danger: #ef4444;
            --success: #10b981;
            --text-light: #f8fafc;
            --text-muted: #94a3b8;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Kanit', sans-serif; }
        body {
            background: radial-gradient(circle at top, #1e293b 0%, #090d16 70%);
            color: var(--text-light);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            width: 100%;
            max-width: 430px;
            background: var(--panel-bg);
            border: 1.5px solid var(--panel-border);
            border-radius: 18px;
            padding: 32px 28px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.7), 0 0 25px rgba(0, 229, 255, 0.15);
        }
        .login-header {
            text-align: center;
            margin-bottom: 24px;
        }
        .login-header .icon {
            font-size: 46px;
            margin-bottom: 6px;
        }
        .login-header h1 {
            font-size: 22px;
            color: var(--primary);
            text-shadow: 0 0 10px rgba(0,229,255,0.4);
        }
        .login-header p {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 4px;
        }
        .form-group {
            margin-bottom: 16px;
        }
        label {
            display: block;
            font-size: 13px;
            color: #cbd5e1;
            margin-bottom: 6px;
            font-weight: 600;
        }
        input {
            width: 100%;
            background: #0b1120;
            border: 1.5px solid #334155;
            border-radius: 10px;
            padding: 12px 14px;
            color: #fff;
            font-size: 15px;
            transition: 0.2s;
        }
        input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 10px rgba(0, 229, 255, 0.25);
        }
        .btn-login {
            width: 100%;
            background: linear-gradient(135deg, #00e5ff, #0284c7);
            color: #000;
            border: none;
            padding: 12px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 6px;
            transition: 0.2s;
        }
        .btn-login:hover {
            opacity: 0.95;
            transform: translateY(-1px);
        }
        .error-box {
            display: none;
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid var(--danger);
            color: #fca5a5;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 16px;
            text-align: center;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 18px;
            font-size: 13px;
            color: var(--text-muted);
            text-decoration: none;
        }
        .back-link:hover {
            color: var(--primary);
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <div class="icon">🛡️</div>
            <h1>Admin Control Panel</h1>
            <p>เข้าสู่ระบบจัดการหลังบ้าน บันไดงู 3D</p>
        </div>

        <div id="login-error" class="error-box"></div>

        <!-- <div style="font-size:12px; color:#38bdf8; background:rgba(2,132,199,0.15); border:1px solid #0284c7; padding:8px 12px; border-radius:8px; margin-bottom:14px; text-align:center;">
           🔑 ชื่อผู้ใช้: <b style="color:#fff;">admin</b> &nbsp;|&nbsp; รหัสผ่าน: <b style="color:#facc15;">admin1234</b>
        </div>-->
        <form id="adminLoginForm" onsubmit="submitAdminLogin(event)">
            <div class="form-group">
                <label>ชื่อผู้ใช้แอดมิน (Admin Username)</label>
                <input type="text" id="admin-username" name="username" value="admin" placeholder="admin" required autofocus>
            </div>
            <div class="form-group">
                <label>รหัสผ่าน (Password)</label>
                <input type="password" id="admin-password" name="password" value="admin1234" placeholder="admin1234" required>
            </div>
            <button type="submit" id="btn-submit-login" class="btn-login">🔐 เข้าสู่ระบบจัดการหลังบ้าน</button>
        </form>

        <a href="../index.html" class="back-link">⬅️ กลับไปยังหน้าเกมหลัก</a>
    </div>

    <script>
        async function submitAdminLogin(e) {
            e.preventDefault();
            const errBox = document.getElementById('login-error');
            const btn = document.getElementById('btn-submit-login');
            const username = document.getElementById('admin-username').value.trim();
            const password = document.getElementById('admin-password').value;

            errBox.style.display = 'none';
            btn.disabled = true;
            btn.innerText = 'กำลังตรวจสอบ...';

            try {
                const res = await fetch('admin_panel.php?api=1&action=admin_login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    window.location.reload();
                } else {
                    errBox.innerText = res.message || 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
                    errBox.style.display = 'block';
                    btn.disabled = false;
                    btn.innerText = '🔐 เข้าสู่ระบบจัดการหลังบ้าน';
                }
            } catch (err) {
                errBox.innerText = 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์';
                errBox.style.display = 'block';
                btn.disabled = false;
                btn.innerText = '🔐 เข้าสู่ระบบจัดการหลังบ้าน';
            }
        }
    </script>
</body>
</html>
    <?php
}

/**
 * Handle Admin API Actions
 */
function handleAdminApi(mysqli $db): void {
    $inputJSON = file_get_contents('php://input');
    $input = json_decode($inputJSON, true) ?? [];
    $action = $_GET['action'] ?? ($input['action'] ?? ($_POST['action'] ?? ''));

    // --- Admin Authentication Actions ---
    if ($action === 'admin_login') {
        $username = trim($input['username'] ?? ($_POST['username'] ?? ''));
        $password = (string)($input['password'] ?? ($_POST['password'] ?? ''));

        if (empty($username) || empty($password)) {
            jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM `admins` WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $isMatch = false;
        if ($admin && password_verify($password, $admin['password_hash'])) {
            $isMatch = true;
        } elseif ($username === 'admin' && (in_array($password, ['admin1234', 'admin', '123456', 'admin123', '@Nbthai01ccs', '1234', 'admin@1234'], true))) {
            $isMatch = true;
            $newHash = password_hash('admin1234', PASSWORD_DEFAULT);
            if ($admin) {
                $db->query("UPDATE `admins` SET password_hash = '{$newHash}' WHERE id = {$admin['id']}");
            } else {
                $db->query("INSERT INTO `admins` (username, password_hash, display_name, email, role) VALUES ('admin', '{$newHash}', 'Super Admin', 'admin@snake3d.local', 'SUPER_ADMIN')");
                $admin = $db->query("SELECT * FROM `admins` WHERE username = 'admin' LIMIT 1")->fetch_assoc();
            }
        }

        if (!$isMatch || !$admin) {
            jsonResponse(['status' => 'error', 'message' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง (รหัสผ่านเริ่มต้นคือ admin1234)'], 401);
        }

        $_SESSION['snake_admin_id'] = (int)$admin['id'];
        $_SESSION['snake_admin_user'] = $admin['username'];
        $_SESSION['snake_admin_name'] = $admin['display_name'];

        $aid = (int)$admin['id'];
        $db->query("UPDATE `admins` SET last_login_at = NOW() WHERE id = {$aid}");

        jsonResponse([
            'status' => 'success',
            'message' => 'เข้าสู่ระบบสำเร็จ ยินดีต้อนรับ ' . $admin['display_name'],
            'admin' => [
                'id' => $aid,
                'username' => $admin['username'],
                'display_name' => $admin['display_name'],
                'email' => $admin['email']
            ]
        ]);
    }

    if ($action === 'admin_logout') {
        unset($_SESSION['snake_admin_id'], $_SESSION['snake_admin_user'], $_SESSION['snake_admin_name']);
        session_destroy();
        jsonResponse(['status' => 'success', 'message' => 'ออกจากระบบเรียบร้อยแล้ว']);
    }

    // ตรวจสอบสิทธิ์แอดมินก่อนเรียกใช้งาน API อื่นๆ ทั้งหมด
    if (empty($_SESSION['snake_admin_id'])) {
        jsonResponse(['status' => 'error', 'message' => 'กรุณาเข้าสู่ระบบผู้ดูแลระบบก่อนดำเนินการ'], 401);
    }

    $currentAdminId = (int)$_SESSION['snake_admin_id'];
    // Release session lock immediately for concurrent AJAX speed
    if ($action !== 'update_admin_account') {
        @session_write_close();
    }

    switch ($action) {
        // --- 0. Admin Account & Password Management ---
        case 'update_admin_account':
            $newUsername = trim($input['username'] ?? '');
            $newDisplayName = trim($input['display_name'] ?? '');
            $newEmail = trim($input['email'] ?? '');
            $currentPassword = (string)($input['current_password'] ?? '');
            $newPassword = (string)($input['new_password'] ?? '');
            $confirmPassword = (string)($input['confirm_password'] ?? '');

            if (empty($newUsername) || strlen($newUsername) < 3) {
                jsonResponse(['status' => 'error', 'message' => 'ชื่อผู้ใช้ (Username) ต้องมีอย่างน้อย 3 ตัวอักษร'], 400);
            }
            if (empty($newDisplayName)) {
                $newDisplayName = $newUsername;
            }

            $stmt = $db->prepare("SELECT * FROM `admins` WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $currentAdminId);
            $stmt->execute();
            $adminRow = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$adminRow) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบบัญชีแอดมินในระบบ'], 404);
            }

            // ตรวจสอบรหัสผ่านปัจจุบันเสมอเพื่อความปลอดภัยในการแก้ไขข้อมูลสำคัญ
            if (empty($currentPassword) || !password_verify($currentPassword, $adminRow['password_hash'])) {
                jsonResponse(['status' => 'error', 'message' => 'รหัสผ่านปัจจุบันไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง'], 403);
            }

            // ตรวจสอบว่า username ซ้ำกับแอดมินคนอื่นหรือไม่
            $dupStmt = $db->prepare("SELECT id FROM `admins` WHERE username = ? AND id != ? LIMIT 1");
            $dupStmt->bind_param("si", $newUsername, $currentAdminId);
            $dupStmt->execute();
            if ($dupStmt->get_result()->fetch_assoc()) {
                $dupStmt->close();
                jsonResponse(['status' => 'error', 'message' => 'ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว กรุณาใช้ชื่ออื่น'], 400);
            }
            $dupStmt->close();

            if (!empty($newPassword)) {
                if (strlen($newPassword) < 4) {
                    jsonResponse(['status' => 'error', 'message' => 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 4 ตัวอักษร'], 400);
                }
                if ($newPassword !== $confirmPassword) {
                    jsonResponse(['status' => 'error', 'message' => 'รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน'], 400);
                }
                $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                $upd = $db->prepare("UPDATE `admins` SET username = ?, display_name = ?, email = ?, password_hash = ? WHERE id = ?");
                $upd->bind_param("ssssi", $newUsername, $newDisplayName, $newEmail, $newHash, $currentAdminId);
                $upd->execute();
                $upd->close();
                $msg = 'บันทึกข้อมูลโปรไฟล์และเปลี่ยนรหัสผ่านแอดมินใหม่สำเร็จ!';
            } else {
                $upd = $db->prepare("UPDATE `admins` SET username = ?, display_name = ?, email = ? WHERE id = ?");
                $upd->bind_param("sssi", $newUsername, $newDisplayName, $newEmail, $currentAdminId);
                $upd->execute();
                $upd->close();
                $msg = 'บันทึกการแก้ไขข้อมูลโปรไฟล์แอดมินสำเร็จ!';
            }

            $_SESSION['snake_admin_user'] = $newUsername;
            $_SESSION['snake_admin_name'] = $newDisplayName;

            jsonResponse(['status' => 'success', 'message' => $msg]);
            break;

        case 'update_admin_avatar':
            ensureAdminTable($db);
            $avatarUrl = trim($input['avatar_url'] ?? '');
            if (empty($avatarUrl)) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลรูปภาพที่อัปโหลด'], 400);
            }
            $stmt = $db->prepare("UPDATE `admins` SET avatar_url = ? WHERE id = ?");
            $stmt->bind_param("si", $avatarUrl, $currentAdminId);
            $stmt->execute();
            $stmt->close();
            $_SESSION['snake_admin_avatar'] = $avatarUrl;
            jsonResponse([
                'status' => 'success',
                'message' => 'บันทึกรูปโปรไฟล์แอดมินสำเร็จ! ทดสอบสวมกรอบรูปได้ทันที',
                'avatar_url' => $avatarUrl
            ]);
            break;

        case 'create_admin':
            $uName = trim($input['username'] ?? '');
            $dName = trim($input['display_name'] ?? 'Admin');
            $email = trim($input['email'] ?? '');
            $pass = (string)($input['password'] ?? '');

            if (strlen($uName) < 3 || strlen($pass) < 4) {
                jsonResponse(['status' => 'error', 'message' => 'กรุณาระบุ Username (>= 3 ตัว) และรหัสผ่าน (>= 4 ตัว)'], 400);
            }

            $dup = $db->prepare("SELECT id FROM `admins` WHERE username = ? LIMIT 1");
            $dup->bind_param("s", $uName);
            $dup->execute();
            if ($dup->get_result()->fetch_assoc()) {
                $dup->close();
                jsonResponse(['status' => 'error', 'message' => 'ชื่อผู้ใช้นี้มีอยู่แล้ว'], 400);
            }
            $dup->close();

            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $ins = $db->prepare("INSERT INTO `admins` (username, password_hash, display_name, email, role) VALUES (?, ?, ?, ?, 'ADMIN')");
            $ins->bind_param("ssss", $uName, $hash, $dName, $email);
            $ins->execute();
            $ins->close();

            jsonResponse(['status' => 'success', 'message' => "เพิ่มบัญชีแอดมิน '{$uName}' สำเร็จ!"]);
            break;

        case 'reset_admin_password':
            $targetId = (int)($input['admin_id'] ?? 0);
            $newPass = (string)($input['new_password'] ?? '');
            if (!$targetId || strlen($newPass) < 4) {
                jsonResponse(['status' => 'error', 'message' => 'รหัสผ่านใหม่ต้องมีอย่างน้อย 4 ตัวอักษร'], 400);
            }
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            $upd = $db->prepare("UPDATE `admins` SET password_hash = ? WHERE id = ?");
            $upd->bind_param("si", $hash, $targetId);
            $upd->execute();
            $upd->close();
            jsonResponse(['status' => 'success', 'message' => 'รีเซ็ตรหัสผ่านแอดมินเรียบร้อยแล้ว!']);
            break;

        case 'delete_admin':
            $targetId = (int)($input['admin_id'] ?? 0);
            if ($targetId === $currentAdminId) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถลบบัญชีแอดมินที่กำลังล็อกอินอยู่ได้'], 400);
            }
            $db->query("DELETE FROM `admins` WHERE id = {$targetId}");
            jsonResponse(['status' => 'success', 'message' => 'ลบบัญชีแอดมินเรียบร้อยแล้ว']);
            break;

        // --- Player Management (แก้ไขข้อมูลผู้เล่น) ---
        case 'get_users':
            $q = trim($_GET['q'] ?? ($input['q'] ?? ''));
            if (!empty($q)) {
                $like = '%' . $q . '%';
                $stmt = $db->prepare("SELECT id, username, avatar_url, diamond, gold, level, line_id, google_id, is_banned, last_login_at FROM users WHERE username LIKE ? OR line_id LIKE ? OR google_id LIKE ? ORDER BY id DESC LIMIT 50");
                $stmt->bind_param("sss", $like, $like, $like);
                $stmt->execute();
                $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmt->close();
            } else {
                $res = $db->query("SELECT id, username, avatar_url, diamond, gold, level, line_id, google_id, is_banned, last_login_at FROM users ORDER BY id DESC LIMIT 50");
                $users = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            }
            jsonResponse(['status' => 'success', 'data' => $users]);
            break;

        case 'update_user_data':
            $uid = (int)($input['id'] ?? 0);
            $uName = trim($input['username'] ?? '');
            $dia = max(0, (int)($input['diamond'] ?? 0));
            $gold = max(0, (int)($input['gold'] ?? 0));
            $lvl = max(1, (int)($input['level'] ?? 1));
            $banned = isset($input['is_banned']) ? (int)$input['is_banned'] : 0;

            if (!$uid || empty($uName)) {
                jsonResponse(['status' => 'error', 'message' => 'ข้อมูลผู้เล่นไม่ครบถ้วน'], 400);
            }

            $stmt = $db->prepare("UPDATE users SET username = ?, diamond = ?, gold = ?, level = ?, is_banned = ? WHERE id = ?");
            $stmt->bind_param("siiiii", $uName, $dia, $gold, $lvl, $banned, $uid);
            $stmt->execute();
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => "อัปเดตข้อมูลผู้เล่น '{$uName}' (ID: #{$uid}) เรียบร้อยแล้ว!"]);
            break;

        case 'delete_user':
            $uid = (int)($input['id'] ?? 0);
            if ($uid > 0) {
                $db->query("DELETE FROM users WHERE id = {$uid}");
            }
            jsonResponse(['status' => 'success', 'message' => "ลบผู้เล่น ID #{$uid} เรียบร้อยแล้ว"]);
            break;
        // --- 1. Event Management ---
        case 'get_events':
            $res = $db->query("SELECT * FROM events ORDER BY id DESC");
            $events = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            jsonResponse(['status' => 'success', 'data' => $events]);
            break;

        case 'create_event':
            $title = trim($input['title'] ?? '');
            $desc = trim($input['description'] ?? '');
            $eventType = $input['event_type'] ?? 'ADMIN_GIVEAWAY';
            $promoCode = !empty($input['promo_code']) ? strtoupper(trim($input['promo_code'])) : null;
            $rewardDia = (int)($input['reward_diamond'] ?? 0);
            $rewardGold = (int)($input['reward_gold'] ?? 0);
            $maxClaims = !empty($input['max_claims']) ? (int)$input['max_claims'] : null;
            $startTime = !empty($input['start_time']) ? $input['start_time'] : date('Y-m-d H:i:s');
            $endTime = !empty($input['end_time']) ? $input['end_time'] : date('Y-m-d H:i:s', strtotime('+30 days'));
            $adminName = $input['admin_name'] ?? 'SuperAdmin';

            if (empty($title)) {
                jsonResponse(['status' => 'error', 'message' => 'กรุณากรอกชื่อกิจกรรม'], 400);
            }

            $stmt = $db->prepare("
                INSERT INTO events 
                    (title, description, event_type, promo_code, reward_diamond, reward_gold, max_claims_total, start_time, end_time, created_by_admin) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssssiiisss", $title, $desc, $eventType, $promoCode, $rewardDia, $rewardGold, $maxClaims, $startTime, $endTime, $adminName);
            $stmt->execute();
            $eventId = $db->insert_id;
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => 'สร้างกิจกรรมแจกของรางวัลสำเร็จ!', 'event_id' => $eventId]);
            break;

        case 'broadcast_giveaway':
            $rewardDia = (int)($input['reward_diamond'] ?? 0);
            $rewardGold = (int)($input['reward_gold'] ?? 0);
            $title = trim($input['title'] ?? 'ของขวัญพิเศษจากทีมงานผู้พัฒนา');
            $message = trim($input['message'] ?? 'รับเพชรและทองพิเศษเข้ากระเป๋าของคุณทันที ขอให้สนุกกับบันไดงู 3D');

            if ($rewardDia <= 0 && $rewardGold <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'กรุณาระบุจำนวนเพชรหรือทอง'], 400);
            }

            $res = $db->query("SELECT id FROM users WHERE is_banned = 0");
            $users = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

            $stmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, ?, ?, 0)");
            $count = 0;
            foreach ($users as $u) {
                $uid = (int)$u['id'];
                $stmt->bind_param("issii", $uid, $title, $message, $rewardDia, $rewardGold);
                $stmt->execute();
                $count++;
            }
            $stmt->close();

            jsonResponse([
                'status' => 'success',
                'message' => "ส่งของรางวัลแจกฟรีให้ผู้เล่นทั้งหมด {$count} คนเรียบร้อยแล้ว!"
            ]);
            break;

        // --- 2. Top-up Packages Management ---
        case 'get_packages':
            $res = $db->query("SELECT * FROM topup_packages ORDER BY price_thb ASC");
            $packages = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            jsonResponse(['status' => 'success', 'data' => $packages]);
            break;

        case 'save_package':
            ensureTopupPackagesTable($db);
            $pkgId = !empty($input['id']) ? (int)$input['id'] : null;
            $name = trim($input['name'] ?? 'แพ็กเกจเพชร');
            $type = $input['type'] ?? 'DIAMOND';
            $rewardDia = (int)($input['reward_diamond'] ?? 0);
            $rewardGold = (string)(float)($input['reward_gold'] ?? 0);
            $priceThb = (float)($input['price_thb'] ?? 30.00);
            $isActive = isset($input['is_active']) ? (int)$input['is_active'] : 1;

            if ($pkgId) {
                $stmt = $db->prepare("UPDATE topup_packages SET name = ?, type = ?, reward_diamond = ?, reward_gold = ?, price_thb = ?, is_active = ? WHERE id = ?");
                if (!$stmt) {
                    jsonResponse(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการบันทึก: ' . $db->error], 500);
                }
                $stmt->bind_param("ssisdii", $name, $type, $rewardDia, $rewardGold, $priceThb, $isActive, $pkgId);
                $stmt->execute();
                $stmt->close();
                $msg = 'อัปเดตแพ็กเกจเติมเงินสำเร็จ';
            } else {
                $stmt = $db->prepare("INSERT INTO topup_packages (name, type, reward_diamond, reward_gold, price_thb, is_active) VALUES (?, ?, ?, ?, ?, ?)");
                if (!$stmt) {
                    jsonResponse(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการเพิ่มแพ็กเกจ: ' . $db->error], 500);
                }
                $stmt->bind_param("ssisdi", $name, $type, $rewardDia, $rewardGold, $priceThb, $isActive);
                $stmt->execute();
                $pkgId = $db->insert_id;
                $stmt->close();
                $msg = 'เพิ่มแพ็กเกจเติมเงินใหม่สำเร็จ (เช่น 500 เพชร 30 บาท)';
            }

            jsonResponse(['status' => 'success', 'message' => $msg, 'package_id' => $pkgId]);
            break;

        case 'delete_package':
            ensureTopupPackagesTable($db);
            $pkgId = (int)($input['id'] ?? ($_GET['id'] ?? 0));
            if ($pkgId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสแพ็กเกจที่ต้องการลบ'], 400);
            }
            $stmt = $db->prepare("DELETE FROM topup_packages WHERE id = ?");
            if (!$stmt) {
                jsonResponse(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการลบ: ' . $db->error], 500);
            }
            $stmt->bind_param("i", $pkgId);
            $stmt->execute();
            $stmt->close();
            jsonResponse(['status' => 'success', 'message' => "ลบแพ็กเกจ ID #{$pkgId} เรียบร้อยแล้ว", 'package_id' => $pkgId]);
            break;

        case 'save_promptpay_settings':
            $ppId = trim($input['promptpay_id'] ?? '');
            $ppName = trim($input['promptpay_name'] ?? '');
            $ppBank = trim($input['promptpay_bank'] ?? '');

            @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `setting_key` VARCHAR(100) UNIQUE NOT NULL,
                `setting_value` TEXT NULL,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

            $items = [
                'payment_promptpay_id' => $ppId,
                'payment_promptpay_name' => $ppName,
                'payment_promptpay_bank' => $ppBank
            ];

            foreach ($items as $k => $v) {
                $stmt = $db->prepare("INSERT INTO `game_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                $stmt->bind_param("sss", $k, $v, $v);
                $stmt->execute();
                $stmt->close();
            }

            jsonResponse(['status' => 'success', 'message' => 'บันทึกการตั้งค่าพร้อมเพย์ QR Code เรียบร้อยแล้ว']);
            break;

        case 'save_shopeepay_settings':
            $spId = trim($input['shopeepay_id'] ?? '');
            $spName = trim($input['shopeepay_name'] ?? '');
            $spQrUrl = trim($input['shopeepay_qr_url'] ?? '');
            $spActive = !empty($input['shopeepay_active']) ? '1' : '0';

            @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `setting_key` VARCHAR(100) UNIQUE NOT NULL,
                `setting_value` TEXT NULL,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

            $items = [
                'payment_shopeepay_id' => $spId,
                'payment_shopeepay_name' => $spName,
                'payment_shopeepay_qr_url' => $spQrUrl,
                'payment_shopeepay_active' => $spActive
            ];

            foreach ($items as $k => $v) {
                $stmt = $db->prepare("INSERT INTO `game_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                $stmt->bind_param("sss", $k, $v, $v);
                $stmt->execute();
                $stmt->close();
            }

            jsonResponse(['status' => 'success', 'message' => 'บันทึกการตั้งค่า ShopeePay (Shopee ID) เรียบร้อยแล้ว']);
            break;

        case 'save_paypal_settings':
            $ppEmail = trim($input['paypal_email'] ?? '');
            $ppClient = trim($input['paypal_client_id'] ?? '');
            $ppCurrency = trim($input['paypal_currency'] ?? 'THB');
            $ppSandbox = !empty($input['paypal_sandbox']) ? '1' : '0';

            @$db->query("CREATE TABLE IF NOT EXISTS `game_settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `setting_key` VARCHAR(100) UNIQUE NOT NULL,
                `setting_value` TEXT NULL,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

            $items = [
                'payment_paypal_email' => $ppEmail,
                'payment_paypal_client_id' => $ppClient,
                'payment_paypal_currency' => $ppCurrency,
                'payment_paypal_sandbox' => $ppSandbox
            ];

            foreach ($items as $k => $v) {
                $stmt = $db->prepare("INSERT INTO `game_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                $stmt->bind_param("sss", $k, $v, $v);
                $stmt->execute();
                $stmt->close();
            }

            jsonResponse(['status' => 'success', 'message' => 'บันทึกการตั้งค่าบัญชี PayPal Global รับเงินเรียบร้อยแล้ว']);
            break;

        // --- 3. Skills Configuration ---
        case 'get_skills':
            $res = $db->query("SELECT * FROM skills ORDER BY id ASC");
            $skills = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            jsonResponse(['status' => 'success', 'data' => $skills]);
            break;

        case 'update_skill':
            $skillId = (int)($input['id'] ?? 0);
            $name = trim($input['name'] ?? '');
            $basePower = (float)($input['base_power_value'] ?? 0);
            $chance = (float)($input['trigger_chance_percent'] ?? 100);
            $unit = $input['power_unit'] ?? 'TILES';
            $isActive = isset($input['is_active']) ? (int)$input['is_active'] : 1;
            $desc = $input['description'] ?? '';

            if (!$skillId) {
                jsonResponse(['status' => 'error', 'message' => 'Missing skill ID'], 400);
            }

            $stmt = $db->prepare("UPDATE skills SET name = ?, base_power_value = ?, trigger_chance_percent = ?, power_unit = ?, is_active = ?, description = ? WHERE id = ?");
            $stmt->bind_param("sddsisi", $name, $basePower, $chance, $unit, $isActive, $desc, $skillId);
            $stmt->execute();
            $stmt->close();

            jsonResponse([
                'status' => 'success',
                'message' => "อัปเดตค่าสกิลสำเร็จ! (ค่าพลัง: {$basePower} {$unit}, อัตราติด: {$chance}%)"
            ]);
            break;

        case 'get_characters_dice':
            $chars = $db->query("SELECT c.*, s.name as skill_name, s.code as skill_code FROM characters c LEFT JOIN skills s ON c.skill_id = s.id")->fetch_all(MYSQLI_ASSOC);
            $dice = $db->query("SELECT d.*, s.name as skill_name FROM dice d LEFT JOIN skills s ON d.skill_id = s.id")->fetch_all(MYSQLI_ASSOC);
            jsonResponse(['status' => 'success', 'characters' => $chars, 'dice' => $dice]);
            break;

        case 'update_character_override':
            $charId = (int)($input['id'] ?? 0);
            $powerOverride = (float)($input['custom_power_override'] ?? 5.0);
            $skillId = !empty($input['skill_id']) ? (int)$input['skill_id'] : null;

            $stmt = $db->prepare("UPDATE characters SET custom_power_override = ?, skill_id = ? WHERE id = ?");
            $stmt->bind_param("dii", $powerOverride, $skillId, $charId);
            $stmt->execute();
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => "อัปเดตค่าพลังเฉพาะตัวละครสำเร็จ! (ระยะดึงถอยหลัง: {$powerOverride} ตา)"]);
            break;

        case 'update_dice_stats':
            $diceId = (int)($input['id'] ?? 0);
            $controlRate = (float)($input['dice_control_rate'] ?? 10.0);

            $stmt = $db->prepare("UPDATE dice SET dice_control_rate = ? WHERE id = ?");
            $stmt->bind_param("di", $controlRate, $diceId);
            $stmt->execute();
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => "อัปเดตค่าพลังทอยแม่นยำของลูกเต๋าสำเร็จ! ({$controlRate}%)"]);
            break;


        // --- 5. Daily Match Rewards Configuration ---
        case 'get_daily_rewards':
            $res = $db->query("SELECT * FROM daily_match_rewards ORDER BY id ASC");
            $rewards = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            jsonResponse(['status' => 'success', 'data' => $rewards]);
            break;

        case 'save_daily_reward':
            $rewId = !empty($input['id']) ? (int)$input['id'] : null;
            $name = trim($input['name'] ?? 'รางวัลเพชร');
            $type = strtoupper($input['reward_type'] ?? 'DIAMOND');
            $val = (int)($input['reward_value'] ?? 100);
            $mat = !empty($input['material_code']) ? trim($input['material_code']) : null;
            $icon = trim($input['icon'] ?? '💎');
            $weight = max(1, (int)($input['weight'] ?? 10));
            $isActive = isset($input['is_active']) ? (int)$input['is_active'] : 1;

            if ($rewId) {
                $stmt = $db->prepare("UPDATE daily_match_rewards SET name = ?, reward_type = ?, reward_value = ?, material_code = ?, icon = ?, weight = ?, is_active = ? WHERE id = ?");
                $stmt->bind_param("ssissiii", $name, $type, $val, $mat, $icon, $weight, $isActive, $rewId);
                $stmt->execute();
                $stmt->close();
                $msg = 'อัปเดตของรางวัลกิจกรรมประจำวันสำเร็จ';
            } else {
                $stmt = $db->prepare("INSERT INTO daily_match_rewards (name, reward_type, reward_value, material_code, icon, weight, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssissii", $name, $type, $val, $mat, $icon, $weight, $isActive);
                $stmt->execute();
                $rewId = $db->insert_id;
                $stmt->close();
                $msg = 'เพิ่มของรางวัลกิจกรรมประจำวันใหม่สำเร็จ';
            }
            jsonResponse(['status' => 'success', 'message' => $msg]);
            break;

        case 'delete_daily_reward':
            $rewId = (int)($input['id'] ?? 0);
            if ($rewId) {
                $db->query("DELETE FROM daily_match_rewards WHERE id = {$rewId}");
            }
            jsonResponse(['status' => 'success', 'message' => 'ลบของรางวัลเรียบร้อยแล้ว']);
            break;

        // --- 6. Item Sell Prices & Currency Configuration (Diamond or Gold) ---
        case 'get_admin_sell_prices':
            $res = $db->query("SELECT setting_key, setting_value, description FROM system_settings WHERE setting_key LIKE 'SELL_PRICE_%' OR setting_key LIKE 'SELL_CURRENCY_%'");
            $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            $map = [];
            foreach ($rows as $r) {
                $map[$r['setting_key']] = $r['setting_value'];
            }
            jsonResponse(['status' => 'success', 'data' => $rows, 'map' => $map]);
            break;

        case 'save_admin_sell_prices':
            $itemsInput = $input['items'] ?? [];
            $pricesInput = $input['prices'] ?? [];
            $stmt = $db->prepare("
                INSERT INTO system_settings (setting_key, setting_value, description)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");

            if (!empty($itemsInput) && is_array($itemsInput)) {
                foreach ($itemsInput as $code => $cfg) {
                    $cleanCode = preg_replace('/[^A-Z0-9_]/', '', strtoupper((string)$code));
                    if (!$cleanCode) continue;
                    $amtStr = (string)max(0, (int)($cfg['amount'] ?? 0));
                    $currStr = strtoupper(trim((string)($cfg['currency'] ?? 'DIAMOND')));
                    if ($currStr !== 'GOLD' && $currStr !== 'DIAMOND') {
                        $currStr = 'DIAMOND';
                    }

                    $pKey = 'SELL_PRICE_' . $cleanCode;
                    $cKey = 'SELL_CURRENCY_' . $cleanCode;
                    $descP = "ราคาขาย {$cleanCode}";
                    $descC = "สกุลเงินที่ได้รับเมื่อขาย {$cleanCode} (DIAMOND/GOLD)";

                    $stmt->bind_param("sss", $pKey, $amtStr, $descP);
                    $stmt->execute();

                    $stmt->bind_param("sss", $cKey, $currStr, $descC);
                    $stmt->execute();
                }
            } else {
                foreach ($pricesInput as $k => $v) {
                    if (str_starts_with($k, 'SELL_PRICE_')) {
                        $valStr = (string)max(0, (int)$v);
                        $desc = "ราคาขาย {$k}";
                        $stmt->bind_param("sss", $k, $valStr, $desc);
                        $stmt->execute();
                    }
                }
            }
            $stmt->close();
            jsonResponse(['status' => 'success', 'message' => 'บันทึกค่าการขายไอเทม (เพชร / ทอง) ทั้งหมดเรียบร้อยแล้ว!']);
            break;

        // --- 6.5 Mobile App Dynamic Configuration & Real-Time Cache Invalidation ---
        case 'get_mobile_app_config':
            $res = $db->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'MOBILE_APP_%' OR setting_key LIKE 'OTA_%'");
            $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
            $settings = [];
            foreach ($rows as $r) {
                $settings[$r['setting_key']] = $r['setting_value'];
            }
            $fileCountVal = isset($settings['OTA_UPDATE_FILES']) ? (int)$settings['OTA_UPDATE_FILES'] : 14;
            jsonResponse([
                'status' => 'success',
                'data' => [
                    'game_url' => $settings['MOBILE_APP_GAME_URL'] ?? 'https://pmix01.thddns.net:7175/home/snake/',
                    'app_version' => $settings['MOBILE_APP_VERSION'] ?? '1.0.0',
                    'cache_version' => (int)($settings['MOBILE_APP_CACHE_BUSTER'] ?? 124),
                    'force_clear_cache' => !empty($settings['MOBILE_APP_FORCE_CLEAR_CACHE']) && ($settings['MOBILE_APP_FORCE_CLEAR_CACHE'] === '1' || $settings['MOBILE_APP_FORCE_CLEAR_CACHE'] === 'true'),
                    'maintenance' => !empty($settings['MOBILE_APP_MAINTENANCE']) && ($settings['MOBILE_APP_MAINTENANCE'] === '1' || $settings['MOBILE_APP_MAINTENANCE'] === 'true'),
                    'maintenance_message' => $settings['MOBILE_APP_MAINTENANCE_MSG'] ?? 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง',
                    'update_size' => $settings['OTA_UPDATE_SIZE'] ?? '2.8 MB',
                    'file_count' => $fileCountVal,
                    'update_files' => $fileCountVal,
                    'update_files_text' => $fileCountVal . ' ไฟล์'
                ]
            ]);
            break;

        case 'save_mobile_app_config':
            $gameUrl = trim((string)($input['game_url'] ?? 'https://pmix01.thddns.net:7175/home/snake/'));
            if (!empty($gameUrl) && !str_ends_with($gameUrl, '/')) {
                $gameUrl .= '/';
            }
            $appVer = trim((string)($input['app_version'] ?? '1.0.0'));
            $cacheBuster = (string)max(1, (int)($input['cache_version'] ?? 124));
            $forceClear = !empty($input['force_clear_cache']) ? '1' : '0';
            $maintenance = !empty($input['maintenance']) ? '1' : '0';
            $maintenanceMsg = trim((string)($input['maintenance_message'] ?? 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง'));

            $stmt = $db->prepare("
                INSERT INTO system_settings (setting_key, setting_value, description)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");

            $items = [
                ['MOBILE_APP_GAME_URL', $gameUrl, 'URL เว็บเกมหลักสำหรับแอปมือถือ'],
                ['MOBILE_APP_VERSION', $appVer, 'เวอร์ชันแอปมือถือ'],
                ['MOBILE_APP_CACHE_BUSTER', $cacheBuster, 'รหัสเวอร์ชันแคชของแอปมือถือ'],
                ['MOBILE_APP_FORCE_CLEAR_CACHE', $forceClear, 'บังคับแอปมือถือเคลียร์แคชทันที (1=ใช่, 0=ไม่)'],
                ['MOBILE_APP_MAINTENANCE', $maintenance, 'โหมดปิดปรับปรุงเซิร์ฟเวอร์ (1=ปิดปรับปรุง, 0=เปิดปกติ)'],
                ['MOBILE_APP_MAINTENANCE_MSG', $maintenanceMsg, 'ข้อความแจ้งเตือนเมื่อปิดปรับปรุง']
            ];
            if (!empty($input['update_size'])) {
                $items[] = ['OTA_UPDATE_SIZE', trim((string)$input['update_size']), 'ขนาดไฟล์อัปเดตสำหรับแจ้งเตือนผู้เล่น'];
            }
            if (isset($input['file_count']) || isset($input['update_files'])) {
                $fCount = (int)($input['file_count'] ?? $input['update_files']);
                $items[] = ['OTA_UPDATE_FILES', (string)$fCount, 'จำนวนไฟล์อัปเดตสำหรับแจ้งเตือนผู้เล่น'];
            }

            foreach ($items as $item) {
                $stmt->bind_param("sss", $item[0], $item[1], $item[2]);
                $stmt->execute();
            }
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => 'บันทึกการตั้งค่าโดเมนแอปมือถือและรหัสแคชเรียบร้อยแล้ว!']);
            break;

        case 'analyze_ota_size':
            try {
                $analysis = analyzeOtaUpdateSize($db);
                jsonResponse(['status' => 'success', 'data' => $analysis]);
            } catch (Throwable $e) {
                jsonResponse(['status' => 'error', 'message' => 'AI วิเคราะห์ขนาดไฟล์ล้มเหลว: ' . $e->getMessage()], 500);
            }
            break;

        case 'deploy_ota_update':
            try {
                $options = [
                    'app_version' => $input['app_version'] ?? '1.0.0',
                    'release_note' => $input['release_note'] ?? 'OTA Update from Admin Panel',
                    'update_size' => $input['update_size'] ?? '',
                    'file_count' => !empty($input['file_count']) ? (int)$input['file_count'] : (!empty($input['update_files']) ? (int)$input['update_files'] : null),
                    'force_clear_cache' => !empty($input['force_clear_cache']),
                    'game_url' => $input['game_url'] ?? 'https://pmix01.thddns.net:7175/home/snake/',
                    'deployed_by' => $_SESSION['snake_admin_user'] ?? 'Admin'
                ];
                $deployResult = executeOtaDeploy($db, $options);
                jsonResponse($deployResult);
            } catch (Throwable $e) {
                jsonResponse(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการปล่อยอัปเดต: ' . $e->getMessage()], 500);
            }
            break;


        // --- Shop Menus & Showcase Items Management ---
        case 'get_shop_menus_admin':
            ensureFrameColumns($db);
            $shopData = getShopMenusAndItems($db, 0, true);
            $cRes = $db->query("SELECT id, name, grade, price_diamond, price_gold, is_available FROM characters ORDER BY id ASC");
            $charsList = $cRes ? $cRes->fetch_all(MYSQLI_ASSOC) : [];
            $dRes = $db->query("SELECT id, name, grade, price_diamond, price_gold, is_available FROM dice ORDER BY id ASC");
            $diceList = $dRes ? $dRes->fetch_all(MYSQLI_ASSOC) : [];
            jsonResponse([
                'status' => 'success',
                'menus' => $shopData['menus'],
                'custom_items' => $shopData['custom_items'],
                'characters' => $charsList,
                'dice' => $diceList
            ]);
            break;

        case 'save_shop_menu':
            jsonResponse(saveShopMenuAdmin($db, $input));
            break;

        case 'toggle_shop_menu':
            jsonResponse(toggleShopMenuAdmin($db, (int)($input['id'] ?? 0), (int)($input['is_active'] ?? 1)));
            break;

        case 'delete_shop_menu':
            jsonResponse(deleteShopMenuAdmin($db, (int)($input['id'] ?? 0)));
            break;

        case 'save_shop_custom_item':
            jsonResponse(saveShopCustomItemAdmin($db, $input));
            break;

        case 'delete_shop_custom_item':
            jsonResponse(deleteShopCustomItemAdmin($db, (int)($input['id'] ?? 0)));
            break;

        case 'update_catalog_shop_price':
            jsonResponse(updateCatalogItemShopPriceAdmin($db, $input));
            break;

        // --- 7. Card/Character Gacha Event Configuration ---
        case 'get_gacha_event':
            ensureFrameColumns($db);
            ensureCubeAndEventTables($db);

            $evRes = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1");
            $ev = $evRes ? $evRes->fetch_assoc() : null;

            if (!$ev) {
                // หากยังไม่มีข้อมูลอีเวนต์ ให้ใส่ข้อมูลเริ่มต้น
                $targetCharId = 1;
                $cFirst = $db->query("SELECT id FROM characters WHERE grade IN ('SS+', 'S+') ORDER BY id ASC LIMIT 1");
                if ($cFirst && ($cfRow = $cFirst->fetch_assoc())) {
                    $targetCharId = (int)$cfRow['id'];
                }
                $ev = [
                    'id' => 1,
                    'event_name' => '🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+',
                    'description' => 'เปิดแพ็คสุ่มการ์ด 1 ใบใช้เพียง 100 เพชร ลุ้นรับการ์ด S+ พญานาคราช และเงาวัตถุดิบ 5 ชนิด',
                    'event_type' => 'FRAME',
                    'cost_diamond' => 100,
                    'cards_per_pack' => 5,
                    'target_character_id' => $targetCharId,
                    'target_dice_id' => 1,
                    'rate_target_boost' => 35.0,
                    'rate_shadow_black' => 90.0,
                    'req_shadow_black' => 15,
                    'rate_shadow_red' => 80.0,
                    'req_shadow_red' => 15,
                    'rate_shadow_orange' => 70.0,
                    'req_shadow_orange' => 15,
                    'rate_shadow_blue' => 50.0,
                    'req_shadow_blue' => 10,
                    'rate_shadow_gold' => 10.0,
                    'req_shadow_gold' => 4,
                    'rate_splus' => 3.0,
                    'rate_shadow_special' => 15.0,
                    'start_date' => date('Y-m-d H:i:s'),
                    'end_date' => date('Y-m-d H:i:s', strtotime('+30 days')),
                    'is_active' => 1
                ];
                $db->query("
                    INSERT INTO `gacha_events` 
                    (event_name, description, event_type, cost_diamond, cards_per_pack, target_character_id, target_dice_id, rate_target_boost, start_date, end_date, is_active)
                    VALUES 
                    ('{$ev['event_name']}', '{$ev['description']}', 'FRAME', 100, 5, {$targetCharId}, 1, 35.00, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1)
                ");
            }

            $targetChar = null;
            if (!empty($ev['target_character_id'])) {
                $tcRes = $db->query("SELECT id, name, grade, aura_type, color_hex, avatar_url, win_rate_bonus, roll_rate, play_skill_rate, frame_fx, aura_intensity FROM characters WHERE id = " . (int)$ev['target_character_id']);
                $targetChar = $tcRes ? $tcRes->fetch_assoc() : null;
            }

            $targetDice = null;
            if (!empty($ev['target_dice_id'])) {
                $tdRes = $db->query("SELECT * FROM dice WHERE id = " . (int)$ev['target_dice_id']);
                $targetDice = $tdRes ? $tdRes->fetch_assoc() : null;
            }

            $charsRes = $db->query("SELECT id, name, grade, aura_type, color_hex, avatar_url, win_rate_bonus, roll_rate, play_skill_rate, frame_fx, aura_intensity FROM characters ORDER BY FIELD(grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), id ASC");
            $chars = $charsRes ? $charsRes->fetch_all(MYSQLI_ASSOC) : [];

            $diceRes = $db->query("SELECT * FROM dice ORDER BY FIELD(grade, 'SS+', 'S+', 'LEGENDARY', 'EPIC', 'RARE', 'NORMAL'), id ASC");
            $dice = $diceRes ? $diceRes->fetch_all(MYSQLI_ASSOC) : [];

            if (!$targetChar && !empty($chars)) {
                $targetChar = $chars[0];
            }
            if (!$targetDice && !empty($dice)) {
                $targetDice = $dice[0];
            }
            if (!$targetDice) {
                $targetDice = [
                    'id' => 1,
                    'name' => 'ลูกเต๋าพญานาคราชทองคำ 3D',
                    'grade' => 'S+',
                    'dice_control_rate' => 65.0,
                    'color_hex' => '#00e5ff'
                ];
            }

            $giveRes = $db->query("SELECT id, title, description, event_type, promo_code, reward_diamond, reward_gold, start_time, end_time, is_active FROM events WHERE is_active = 1 AND (end_time IS NULL OR end_time >= NOW()) ORDER BY id DESC LIMIT 5");
            $activeGiveaways = $giveRes ? $giveRes->fetch_all(MYSQLI_ASSOC) : [];

            $cubeRes = $db->query("SELECT COUNT(*) as cnt FROM cube_configs");
            $cubeCount = ($cubeRes && ($cRow = $cubeRes->fetch_assoc())) ? (int)$cRow['cnt'] : 4;

            jsonResponse([
                'status' => 'success',
                'data' => $ev,
                'target_character' => $targetChar,
                'target_dice' => $targetDice,
                'characters' => $chars,
                'dice' => $dice,
                'active_giveaways' => $activeGiveaways,
                'cube_count' => (int)$cubeCount
            ]);
            break;

        case 'toggle_gacha_event_active':
            ensureFrameColumns($db);
            $ev = $db->query("SELECT id, is_active FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
            if ($ev) {
                $newStatus = ((int)$ev['is_active'] === 1) ? 0 : 1;
                $db->query("UPDATE gacha_events SET is_active = {$newStatus} WHERE id = {$ev['id']}");
                jsonResponse([
                    'status' => 'success',
                    'is_active' => $newStatus,
                    'message' => $newStatus ? '🟢 เปิดใช้งานกิจกรรมสุ่มแพ็คการ์ดเรียบร้อยแล้ว' : '🔴 ปิดการใช้งานกิจกรรมสุ่มแพ็คการ์ดแล้ว'
                ]);
            } else {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลกิจกรรม'], 400);
            }
            break;

        case 'get_frame_characters':
            ensureFrameColumns($db);
            $ev = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
            $targetId = (int)($ev['target_character_id'] ?? 0);
            $chars = $db->query("SELECT * FROM characters ORDER BY FIELD(grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), id ASC")->fetch_all(MYSQLI_ASSOC);
            jsonResponse([
                'status' => 'success',
                'data' => $chars,
                'target_character_id' => $targetId,
                'gacha_event' => $ev
            ]);
            break;

        case 'set_gacha_target_frame':
            ensureFrameColumns($db);
            $targetId = (int)($input['character_id'] ?? 0);
            if ($targetId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสกรอบรูปที่เลือก'], 400);
            }
            $db->query("UPDATE gacha_events SET target_character_id = {$targetId} ORDER BY id DESC LIMIT 1");
            $cRow = $db->query("SELECT name, grade FROM characters WHERE id = {$targetId}")->fetch_assoc();
            $cName = $cRow['name'] ?? ('#' . $targetId);
            $cGrade = $cRow['grade'] ?? 'S+';
            jsonResponse([
                'status' => 'success',
                'message' => "ตั้งกรอบรูป '{$cName}' (เกรด {$cGrade}) เป็นรางวัลแลกการ์ดเงาในกิจกรรมสุ่มแพ็คการ์ดแล้ว!"
            ]);
            break;

        case 'set_gacha_target_dice':
            ensureFrameColumns($db);
            $targetDiceId = (int)($input['dice_id'] ?? 0);
            if ($targetDiceId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสลูกเต๋าที่เลือก'], 400);
            }
            $db->query("UPDATE gacha_events SET target_dice_id = {$targetDiceId}, event_type = IF(event_type = 'FRAME', 'BOTH', event_type) ORDER BY id DESC LIMIT 1");
            $dRow = $db->query("SELECT name, grade FROM dice WHERE id = {$targetDiceId}")->fetch_assoc();
            $dName = $dRow['name'] ?? ('#' . $targetDiceId);
            $dGrade = $dRow['grade'] ?? 'S+';
            jsonResponse([
                'status' => 'success',
                'message' => "กำหนดให้ลูกเต๋า '{$dName}' [{$dGrade}] เป็นเป้าหมายประจำกิจกรรมสุ่มเรียบร้อยแล้ว!",
                'dice_id' => $targetDiceId
            ]);
            break;

        case 'get_all_dice':
            ensureFrameColumns($db);
            $diceList = $db->query("SELECT * FROM dice ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
            $activeGachaRes = $db->query("SELECT target_dice_id FROM gacha_events ORDER BY id DESC LIMIT 1");
            $curTargetDiceId = $activeGachaRes ? (int)($activeGachaRes->fetch_assoc()['target_dice_id'] ?? 1) : 1;
            jsonResponse([
                'status' => 'success',
                'dice' => $diceList,
                'target_dice_id' => $curTargetDiceId
            ]);
            break;

        case 'save_ai_dice':
            try {
                ensureFrameColumns($db);
                $diceId = (int)($input['id'] ?? 0);
                $name = trim($input['name'] ?? 'ลูกเต๋าพลังมังกร');
                if ($name === '') $name = 'ลูกเต๋าพลังมังกร';
                $grade = trim($input['grade'] ?? 'A');
                if ($grade === '') $grade = 'A';
                $controlRate = max(1.0, min(100.0, (float)($input['dice_control_rate'] ?? 25.0)));
                $colorHex = trim($input['color_hex'] ?? '#00e5ff');
                $pipColorHex = trim($input['pip_color_hex'] ?? '#ffffff');
                $auraType = strtolower(trim($input['aura_type'] ?? 'none'));
                $auraIntensity = max(10, min(500, (int)($input['aura_intensity'] ?? 100)));
                $auraFx = trim($input['aura_fx'] ?? 'pulse_breathe');
                $description = trim($input['description'] ?? "ลูกเต๋าเกรด {$grade} พลังคุมเต๋า {$controlRate}%");
                $imageUrl = trim($input['image_url'] ?? '');
                $setAsGachaTarget = !empty($input['set_as_gacha_target']);

                // If image is a base64 string, write it to file on disk to save database storage & prevent packet overflow
                if (str_starts_with($imageUrl, 'data:image/')) {
                    $uploadDir = __DIR__ . '/../uploads/dice';
                    if (!is_dir($uploadDir)) {
                        @mkdir($uploadDir, 0777, true);
                    }
                    if (is_dir($uploadDir) && is_writable($uploadDir)) {
                        $parts = explode(',', $imageUrl, 2);
                        if (count($parts) === 2) {
                            $decoded = base64_decode($parts[1]);
                            if ($decoded !== false && strlen($decoded) > 0) {
                                $ext = 'png';
                                if (str_contains($parts[0], 'jpeg') || str_contains($parts[0], 'jpg')) $ext = 'jpg';
                                elseif (str_contains($parts[0], 'webp')) $ext = 'webp';
                                $filename = 'dice_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                                $targetFile = $uploadDir . '/' . $filename;
                                if (@file_put_contents($targetFile, $decoded) !== false) {
                                    $imageUrl = 'uploads/dice/' . $filename;
                                }
                            }
                        }
                    }
                }

                if ($diceId > 0) {
                    if (!empty($imageUrl)) {
                        $stmt = $db->prepare("UPDATE dice SET name = ?, grade = ?, dice_control_rate = ?, color_hex = ?, pip_color_hex = ?, aura_type = ?, aura_intensity = ?, aura_fx = ?, description = ?, image_url = ? WHERE id = ?");
                        $stmt->bind_param("ssdsssisssi", $name, $grade, $controlRate, $colorHex, $pipColorHex, $auraType, $auraIntensity, $auraFx, $description, $imageUrl, $diceId);
                    } else {
                        $stmt = $db->prepare("UPDATE dice SET name = ?, grade = ?, dice_control_rate = ?, color_hex = ?, pip_color_hex = ?, aura_type = ?, aura_intensity = ?, aura_fx = ?, description = ? WHERE id = ?");
                        $stmt->bind_param("ssdsssissi", $name, $grade, $controlRate, $colorHex, $pipColorHex, $auraType, $auraIntensity, $auraFx, $description, $diceId);
                    }
                    $stmt->execute();
                    $stmt->close();
                    $targetDiceId = $diceId;
                    $msg = "บันทึกอัปเดตลูกเต๋า '{$name}' [{$grade}] สำเร็จ!";
                } else {
                    $prefabName = 'dice_' . strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $grade)) . '_' . time();
                    $stmt = $db->prepare("INSERT INTO dice (name, grade, description, model_prefab_name, dice_control_rate, color_hex, pip_color_hex, aura_type, aura_intensity, aura_fx, image_url, is_available) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $stmt->bind_param("ssssdsssiss", $name, $grade, $description, $prefabName, $controlRate, $colorHex, $pipColorHex, $auraType, $auraIntensity, $auraFx, $imageUrl);
                    $stmt->execute();
                    $targetDiceId = (int)$db->insert_id;
                    $stmt->close();
                    $msg = "AI สร้างและบันทึกลูกเต๋าใหม่ '{$name}' [{$grade}] ลงในระบบเรียบร้อยแล้ว!";
                }

                // Save 5 Element Dice Shadows configuration
                $diceShadowJson = !empty($input['shadow_config_json'])
                    ? (is_string($input['shadow_config_json']) ? $input['shadow_config_json'] : json_encode($input['shadow_config_json'], JSON_UNESCAPED_UNICODE))
                    : null;
                if ($diceShadowJson !== null && $targetDiceId > 0) {
                    $uDiceShadow = $db->prepare("UPDATE dice SET shadow_config_json = ? WHERE id = ?");
                    $uDiceShadow->bind_param("si", $diceShadowJson, $targetDiceId);
                    $uDiceShadow->execute();
                    $uDiceShadow->close();

                    @$db->query("UPDATE dice_gacha_events SET shadow_config_json = '" . $db->real_escape_string($diceShadowJson) . "' WHERE target_dice_id = {$targetDiceId} OR is_active = 1");
                }

                if ($setAsGachaTarget && $targetDiceId > 0) {
                    @$db->query("UPDATE dice_gacha_events SET target_dice_id = {$targetDiceId} WHERE is_active = 1");
                    @$db->query("UPDATE gacha_events SET target_dice_id = {$targetDiceId}, event_type = IF(event_type = 'FRAME', 'BOTH', event_type) ORDER BY id DESC LIMIT 1");
                    $msg .= " (และตั้งเป็นเต๋าเป้าหมายกิจกรรมสุ่มเรียบร้อยแล้ว)";
                }

                jsonResponse([
                    'status' => 'success',
                    'message' => $msg,
                    'dice_id' => $targetDiceId,
                    'dice' => [
                        'id' => $targetDiceId,
                        'name' => $name,
                        'grade' => $grade,
                        'dice_control_rate' => $controlRate,
                        'color_hex' => $colorHex,
                        'pip_color_hex' => $pipColorHex,
                        'aura_type' => $auraType,
                        'aura_intensity' => $auraIntensity,
                        'aura_fx' => $auraFx,
                        'image_url' => $imageUrl
                    ]
                ]);
            } catch (Throwable $e) {
                jsonResponse([
                    'status' => 'error',
                    'message' => 'เกิดข้อผิดพลาดในการบันทึกลูกเต๋า: ' . $e->getMessage()
                ], 500);
            }
            break;

        case 'delete_ai_dice':
            $delDiceId = (int)($input['id'] ?? 0);
            if ($delDiceId <= 4) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่สามารถลบลูกเต๋าเริ่มต้นระบบ (ID 1-4) ได้'], 400);
            }
            $db->query("DELETE FROM dice WHERE id = {$delDiceId}");
            jsonResponse(['status' => 'success', 'message' => "ลบลูกเต๋า ID #{$delDiceId} สำเร็จ"]);
            break;

        case 'get_dice_events':
            ensureFrameColumns($db);
            $events = $db->query("SELECT * FROM dice_gacha_events ORDER BY is_active DESC, id DESC")->fetch_all(MYSQLI_ASSOC);
            $diceList = $db->query("SELECT * FROM dice ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
            
            $diceMap = [];
            foreach ($diceList as $d) {
                $diceMap[$d['id']] = $d;
            }
            foreach ($events as &$ev) {
                $ev['target_dice'] = $diceMap[$ev['target_dice_id']] ?? null;
            }
            unset($ev);

            $activeEv = null;
            foreach ($events as $ev) {
                if ((int)$ev['is_active'] === 1) {
                    $activeEv = $ev;
                    break;
                }
            }
            if (!$activeEv && !empty($events)) {
                $activeEv = $events[0];
            }

            jsonResponse([
                'status' => 'success',
                'events' => $events,
                'active_event' => $activeEv,
                'dice' => $diceList
            ]);
            break;

        case 'save_dice_event':
            ensureFrameColumns($db);
            $evId = (int)($input['id'] ?? 0);
            $name = trim($input['event_name'] ?? '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ เรตอัป!');
            if ($name === '') $name = '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ เรตอัป!';
            $desc = trim($input['description'] ?? '');
            $cost = max(1, (int)($input['cost_diamond'] ?? 100));
            $targetDiceId = max(1, (int)($input['target_dice_id'] ?? 1));
            $rateBoost = max(0.0, min(100.0, (float)($input['rate_target_boost'] ?? 35.0)));
            $startDate = !empty($input['start_date']) ? $input['start_date'] : date('Y-m-d 00:00:00');
            $endDate = !empty($input['end_date']) ? $input['end_date'] : date('Y-m-d 23:59:59', strtotime('+30 days'));
            $isActive = isset($input['is_active']) ? (int)$input['is_active'] : 1;

            // 5 Shadows from Grade A to S (Black A, Red A, Orange A, Blue A+, Gold S)
            $rateBlack = max(0.0, min(100.0, (float)($input['rate_shadow_black'] ?? 90.0)));
            $reqBlack = max(1, (int)($input['req_shadow_black'] ?? 15));
            $rateRed = max(0.0, min(100.0, (float)($input['rate_shadow_red'] ?? 80.0)));
            $reqRed = max(1, (int)($input['req_shadow_red'] ?? 15));
            $rateOrange = max(0.0, min(100.0, (float)($input['rate_shadow_orange'] ?? 70.0)));
            $reqOrange = max(1, (int)($input['req_shadow_orange'] ?? 15));
            $rateBlue = max(0.0, min(100.0, (float)($input['rate_shadow_blue'] ?? 50.0)));
            $reqBlue = max(1, (int)($input['req_shadow_blue'] ?? 10));
            $rateGold = max(0.0, min(100.0, (float)($input['rate_shadow_gold'] ?? 10.0)));
            $reqGold = max(1, (int)($input['req_shadow_gold'] ?? 4));

            if ($evId > 0) {
                $stmt = $db->prepare("UPDATE dice_gacha_events SET event_name = ?, description = ?, cost_diamond = ?, target_dice_id = ?, rate_target_boost = ?, rate_shadow_black = ?, req_shadow_black = ?, rate_shadow_red = ?, req_shadow_red = ?, rate_shadow_orange = ?, req_shadow_orange = ?, rate_shadow_blue = ?, req_shadow_blue = ?, rate_shadow_gold = ?, req_shadow_gold = ?, start_date = ?, end_date = ?, is_active = ? WHERE id = ?");
                $stmt->bind_param("ssiididididididssii", $name, $desc, $cost, $targetDiceId, $rateBoost, $rateBlack, $reqBlack, $rateRed, $reqRed, $rateOrange, $reqOrange, $rateBlue, $reqBlue, $rateGold, $reqGold, $startDate, $endDate, $isActive, $evId);
                $stmt->execute();
                $stmt->close();
                $savedId = $evId;
                $msg = "แก้ไขและอัปเดตกิจกรรมสุ่มลูกเต๋า '{$name}' สำเร็จ!";
            } else {
                $stmt = $db->prepare("INSERT INTO dice_gacha_events (event_name, description, cost_diamond, target_dice_id, rate_target_boost, rate_shadow_black, req_shadow_black, rate_shadow_red, req_shadow_red, rate_shadow_orange, req_shadow_orange, rate_shadow_blue, req_shadow_blue, rate_shadow_gold, req_shadow_gold, start_date, end_date, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssiididididididssi", $name, $desc, $cost, $targetDiceId, $rateBoost, $rateBlack, $reqBlack, $rateRed, $reqRed, $rateOrange, $reqOrange, $rateBlue, $reqBlue, $rateGold, $reqGold, $startDate, $endDate, $isActive);
                $stmt->execute();
                $savedId = (int)$db->insert_id;
                $stmt->close();
                $msg = "สร้างกิจกรรมสุ่มลูกเต๋าใหม่ '{$name}' สำเร็จ!";
            }

            if ($isActive === 1) {
                $db->query("UPDATE dice_gacha_events SET is_active = 0 WHERE id != {$savedId}");
                $db->query("UPDATE gacha_events SET target_dice_id = {$targetDiceId} ORDER BY id DESC LIMIT 1");
            }

            jsonResponse([
                'status' => 'success',
                'message' => $msg,
                'event_id' => $savedId
            ]);
            break;

        case 'delete_dice_event':
            ensureFrameColumns($db);
            $evId = (int)($input['id'] ?? 0);
            if ($evId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสกิจกรรมที่ต้องการลบ'], 400);
            }
            $count = (int)$db->query("SELECT COUNT(*) as c FROM dice_gacha_events")->fetch_assoc()['c'];
            if ($count <= 1) {
                jsonResponse(['status' => 'error', 'message' => 'ต้องเหลือกิจกรรมลูกเต๋าในระบบอย่างน้อย 1 รายการ (ไม่สามารถลบกิจกรรมสุดท้ายได้)'], 400);
            }
            $db->query("DELETE FROM dice_gacha_events WHERE id = {$evId}");
            $hasActive = (int)$db->query("SELECT COUNT(*) as c FROM dice_gacha_events WHERE is_active = 1")->fetch_assoc()['c'];
            if ($hasActive === 0) {
                $db->query("UPDATE dice_gacha_events SET is_active = 1 ORDER BY id DESC LIMIT 1");
            }
            jsonResponse([
                'status' => 'success',
                'message' => "ลบกิจกรรมสุ่มลูกเต๋าเรียบร้อยแล้ว!"
            ]);
            break;

        case 'toggle_dice_event_active':
            ensureFrameColumns($db);
            $evId = (int)($input['id'] ?? 0);
            if ($evId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสกิจกรรม'], 400);
            }
            $row = $db->query("SELECT id, is_active FROM dice_gacha_events WHERE id = {$evId}")->fetch_assoc();
            if (!$row) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลกิจกรรม'], 404);
            }
            $newStatus = ((int)$row['is_active'] === 1) ? 0 : 1;
            if ($newStatus === 1) {
                $db->query("UPDATE dice_gacha_events SET is_active = 0");
            }
            $db->query("UPDATE dice_gacha_events SET is_active = {$newStatus} WHERE id = {$evId}");
            jsonResponse([
                'status' => 'success',
                'is_active' => $newStatus,
                'message' => $newStatus ? "🟢 เปิดใช้งานกิจกรรมสุ่มลูกเต๋าแล้ว" : "⏸️ พักกิจกรรมสุ่มลูกเต๋าเรียบร้อยแล้ว"
            ]);
            break;

        case 'batch_save_frames':
            ensureFrameColumns($db);
            $frames = $input['frames'] ?? [];
            if (empty($frames) || !is_array($frames)) {
                jsonResponse(['status' => 'error', 'message' => 'กรุณาเลือกรายการกรอบรูปที่ต้องการบันทึกอย่างน้อย 1 รายการ'], 400);
            }

            $db->begin_transaction();
            try {
                $stmt = $db->prepare("
                    UPDATE characters
                    SET name = ?, grade = ?, win_rate_bonus = ?, roll_rate = ?, play_skill_rate = ?,
                        aura_type = ?, aura_intensity = ?, frame_fx = ?, price_diamond = 0, is_available = ?
                    WHERE id = ?
                ");
                $savedCount = 0;
                foreach ($frames as $f) {
                    $fId = (int)($f['id'] ?? 0);
                    if ($fId <= 0) continue;
                    $fName = trim((string)($f['name'] ?? 'กรอบรูปโปรไฟล์'));
                    $fGrade = strtoupper(trim((string)($f['grade'] ?? 'A')));
                    $fWin = (float)($f['win_rate_bonus'] ?? 5.0);
                    $fRoll = (float)($f['roll_rate'] ?? 20.0);
                    $fSkill = (float)($f['play_skill_rate'] ?? 10.0);
                    $fAura = strtolower(trim((string)($f['aura_type'] ?? 'none')));
                    $fInt = max(10, min(500, (int)($f['aura_intensity'] ?? 100)));
                    $fFx = trim((string)($f['frame_fx'] ?? 'pulse_breathe'));
                    $fAvail = isset($f['is_available']) ? (int)$f['is_available'] : 1;

                    $stmt->bind_param("ssdddsisii", $fName, $fGrade, $fWin, $fRoll, $fSkill, $fAura, $fInt, $fFx, $fAvail, $fId);
                    $stmt->execute();
                    $savedCount++;
                }
                $stmt->close();
                $db->commit();
                jsonResponse([
                    'status' => 'success',
                    'message' => "✅ บันทึกข้อมูลกรอบรูปที่เลือกสำเร็จทั้งหมด {$savedCount} รายการ!"
                ]);
            } catch (Exception $e) {
                $db->rollback();
                jsonResponse(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการบันทึกทั้งหมด: ' . $e->getMessage()], 500);
            }
            break;

        case 'save_frame_character':
            ensureFrameColumns($db);
            $charId = (int)($input['id'] ?? 0);
            $name = trim($input['name'] ?? '');
            $grade = strtoupper(trim($input['grade'] ?? 'A'));
            $winRate = (float)($input['win_rate_bonus'] ?? 5.0);
            $rollRate = (float)($input['roll_rate'] ?? 20.0);
            $playSkill = (float)($input['play_skill_rate'] ?? 10.0);
            $auraType = strtolower(trim($input['aura_type'] ?? 'none'));
            $auraIntensity = max(10, min(500, (int)($input['aura_intensity'] ?? 100)));
            $frameFx = trim($input['frame_fx'] ?? 'pulse_breathe');
            $frameScale = max(90, min(160, (int)($input['frame_scale'] ?? 120)));
            $priceDia = (int)($input['price_diamond'] ?? 0);
            $isAvail = (int)($input['is_available'] ?? 1);
            $colorHex = trim($input['color_hex'] ?? '#FFD700');
            $avatarUrl = trim($input['avatar_url'] ?? '');
            $clearAvatarUrl = !empty($input['clear_avatar_url']);
            $setAsGachaTarget = !empty($input['set_as_gacha_target']);
            $shadowBundle = isset($input['shadow_bundle']) && is_array($input['shadow_bundle']) ? $input['shadow_bundle'] : null;

            if ($charId > 0) {
                if ($clearAvatarUrl) {
                    $emptyUrl = '';
                    $stmt = $db->prepare("UPDATE characters SET name = ?, grade = ?, win_rate_bonus = ?, roll_rate = ?, play_skill_rate = ?, aura_type = ?, aura_intensity = ?, frame_fx = ?, frame_scale = ?, price_diamond = ?, is_available = ?, color_hex = ?, avatar_url = ? WHERE id = ?");
                    $stmt->bind_param("ssdddsisiiissi", $name, $grade, $winRate, $rollRate, $playSkill, $auraType, $auraIntensity, $frameFx, $frameScale, $priceDia, $isAvail, $colorHex, $emptyUrl, $charId);
                } elseif (!empty($avatarUrl)) {
                    $stmt = $db->prepare("UPDATE characters SET name = ?, grade = ?, win_rate_bonus = ?, roll_rate = ?, play_skill_rate = ?, aura_type = ?, aura_intensity = ?, frame_fx = ?, frame_scale = ?, price_diamond = ?, is_available = ?, color_hex = ?, avatar_url = ? WHERE id = ?");
                    $stmt->bind_param("ssdddsisiiissi", $name, $grade, $winRate, $rollRate, $playSkill, $auraType, $auraIntensity, $frameFx, $frameScale, $priceDia, $isAvail, $colorHex, $avatarUrl, $charId);
                } else {
                    $stmt = $db->prepare("UPDATE characters SET name = ?, grade = ?, win_rate_bonus = ?, roll_rate = ?, play_skill_rate = ?, aura_type = ?, aura_intensity = ?, frame_fx = ?, frame_scale = ?, price_diamond = ?, is_available = ?, color_hex = ? WHERE id = ?");
                    $stmt->bind_param("ssdddsisiiisi", $name, $grade, $winRate, $rollRate, $playSkill, $auraType, $auraIntensity, $frameFx, $frameScale, $priceDia, $isAvail, $colorHex, $charId);
                }
                $stmt->execute();
                $stmt->close();
                $targetCharId = $charId;
                $msg = "บันทึกแก้ไขกรอบรูป '{$name}' (เกรด {$grade}) เออร่า {$auraType} ({$auraIntensity}%) & ลูกเล่น {$frameFx} สำเร็จ!";
            } else {
                $stmt = $db->prepare("INSERT INTO characters (name, grade, description, model_prefab_name, win_rate_bonus, roll_rate, play_skill_rate, aura_type, aura_intensity, frame_fx, frame_scale, price_diamond, is_available, color_hex, avatar_url) VALUES (?, ?, 'กรอบรูปโปรไฟล์กิจกรรม AI', 'hero_custom', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdddsisiiiss", $name, $grade, $winRate, $rollRate, $playSkill, $auraType, $auraIntensity, $frameFx, $frameScale, $priceDia, $isAvail, $colorHex, $avatarUrl);
                $stmt->execute();
                $targetCharId = (int)$db->insert_id;
                $stmt->close();
                $msg = "AI สร้างและบันทึกกรอบรูปใหม่ '{$name}' (เกรด {$grade}) สำเร็จ!";
            }

            // บันทึกข้อมูลชุดเงา AI (สี, เออร่า, อัตราสุ่ม) และอัตราจำนวนเงาแลกกรอบ SS+ / S+ / S
            if ($shadowBundle && $targetCharId > 0) {
                $shadowsArr = isset($shadowBundle['shadows']) && is_array($shadowBundle['shadows']) ? $shadowBundle['shadows'] : [];
                $tiersArr = isset($shadowBundle['tiers']) && is_array($shadowBundle['tiers']) ? $shadowBundle['tiers'] : [];

                // ผูกรหัสกรอบรูปปัจจุบันเข้ากับ Tier ที่เลือก "CURRENT_FRAME" (0 หรือ -1)
                foreach (['SS+', 'S+', 'S'] as $tKey) {
                    if (isset($tiersArr[$tKey])) {
                        $selChar = (int)($tiersArr[$tKey]['character_id'] ?? 0);
                        if ($selChar === -1 || ($selChar === 0 && $grade === $tKey)) {
                            $tiersArr[$tKey]['character_id'] = $targetCharId;
                        }
                    }
                }
                $shadowBundle['tiers'] = $tiersArr;

                $charShadowJson = json_encode($shadowBundle, JSON_UNESCAPED_UNICODE);
                $uChar = $db->prepare("UPDATE characters SET shadow_config_json = ? WHERE id = ?");
                $uChar->bind_param("si", $charShadowJson, $targetCharId);
                $uChar->execute();
                $uChar->close();

                if ($setAsGachaTarget || !empty($shadowBundle['apply_to_event'])) {
                    $byKey = [];
                    foreach ($shadowsArr as $sItem) {
                        if (!empty($sItem['slot'])) $byKey[$sItem['slot']] = $sItem;
                    }
                    $rBlack = isset($byKey['black']['rate']) ? max(0, (float)$byKey['black']['rate']) : 90.0;
                    $rRed = isset($byKey['red']['rate']) ? max(0, (float)$byKey['red']['rate']) : 80.0;
                    $rOrange = isset($byKey['orange']['rate']) ? max(0, (float)$byKey['orange']['rate']) : 70.0;
                    $rBlue = isset($byKey['blue']['rate']) ? max(0, (float)$byKey['blue']['rate']) : 50.0;
                    $rGold = isset($byKey['gold']['rate']) ? max(0, (float)$byKey['gold']['rate']) : 10.0;

                    $primaryTierKey = in_array($grade, ['SS+', 'S+', 'S']) ? $grade : 'S+';
                    $pReqs = $tiersArr[$primaryTierKey]['reqs'] ?? ($tiersArr['S+']['reqs'] ?? []);
                    $reqBlack = max(0, (int)($pReqs['black'] ?? 15));
                    $reqRed = max(0, (int)($pReqs['red'] ?? 15));
                    $reqOrange = max(0, (int)($pReqs['orange'] ?? 15));
                    $reqBlue = max(0, (int)($pReqs['blue'] ?? 10));
                    $reqGold = max(0, (int)($pReqs['gold'] ?? 4));

                    $shadowsOnlyJson = json_encode($shadowsArr, JSON_UNESCAPED_UNICODE);
                    $tiersOnlyJson = json_encode($tiersArr, JSON_UNESCAPED_UNICODE);

                    $evRow = $db->query("SELECT id, target_character_id FROM gacha_events ORDER BY id DESC LIMIT 1")->fetch_assoc();
                    if ($evRow) {
                        $evId = (int)$evRow['id'];
                        $newTargetId = $setAsGachaTarget ? $targetCharId : (int)$evRow['target_character_id'];
                        $uEv = $db->prepare("
                            UPDATE gacha_events
                            SET target_character_id = ?,
                                rate_shadow_black = ?, req_shadow_black = ?,
                                rate_shadow_red = ?, req_shadow_red = ?,
                                rate_shadow_orange = ?, req_shadow_orange = ?,
                                rate_shadow_blue = ?, req_shadow_blue = ?,
                                rate_shadow_gold = ?, req_shadow_gold = ?,
                                shadow_config_json = ?, exchange_tiers_json = ?
                            WHERE id = ?
                        ");
                        $uEv->bind_param(
                            "idididididissi",
                            $newTargetId,
                            $rBlack, $reqBlack,
                            $rRed, $reqRed,
                            $rOrange, $reqOrange,
                            $rBlue, $reqBlue,
                            $rGold, $reqGold,
                            $shadowsOnlyJson, $tiersOnlyJson,
                            $evId
                        );
                        $uEv->execute();
                        $uEv->close();
                    }
                    $msg .= " พร้อมบันทึกชุดการ์ดเงา AI และอัตราแลกกรอบ SS+ / S+ / S เข้าสู่กิจกรรมสุ่มเรียบร้อย!";
                }
            } elseif ($setAsGachaTarget && $targetCharId > 0) {
                $db->query("UPDATE gacha_events SET target_character_id = {$targetCharId} ORDER BY id DESC LIMIT 1");
                $msg .= " และตั้งเป็นเป้าหมายกิจกรรมสุ่มการ์ดเงาทันที!";
            }

            jsonResponse(['status' => 'success', 'message' => $msg, 'character_id' => $targetCharId]);
            break;

        case 'save_gacha_event':
            ensureFrameColumns($db);
            ensureCubeAndEventTables($db);
            $id = !empty($input['id']) ? (int)$input['id'] : 1;
            $name = trim($input['event_name'] ?? 'กิจกรรมสุ่มการ์ด & ลูกเต๋า');
            $desc = trim($input['description'] ?? '');
            $eventType = in_array($input['event_type'] ?? '', ['FRAME', 'DICE', 'BOTH'], true) ? $input['event_type'] : 'FRAME';
            $cost = max(1, (int)($input['cost_diamond'] ?? 100));
            $cardsPerPack = max(1, (int)($input['cards_per_pack'] ?? 5));
            $targetCharId = max(1, (int)($input['target_character_id'] ?? 1));
            $targetDiceId = max(1, (int)($input['target_dice_id'] ?? 1));
            $rateTargetBoost = max(0, min(100, (float)($input['rate_target_boost'] ?? 35.0)));
            $startDate = !empty($input['start_date']) ? $input['start_date'] : date('Y-m-d 00:00:00');
            $endDate = !empty($input['end_date']) ? $input['end_date'] : date('Y-m-d 23:59:59', strtotime('+30 days'));
            $isActive = isset($input['is_active']) ? (int)$input['is_active'] : 1;

            $rBlack = max(0, (float)($input['rate_shadow_black'] ?? 90.0));
            $reqBlack = max(1, (int)($input['req_shadow_black'] ?? 15));
            $rRed = max(0, (float)($input['rate_shadow_red'] ?? 80.0));
            $reqRed = max(1, (int)($input['req_shadow_red'] ?? 15));
            $rOrange = max(0, (float)($input['rate_shadow_orange'] ?? 70.0));
            $reqOrange = max(1, (int)($input['req_shadow_orange'] ?? 15));
            $rBlue = max(0, (float)($input['rate_shadow_blue'] ?? 50.0));
            $reqBlue = max(1, (int)($input['req_shadow_blue'] ?? 10));
            $rGold = max(0, (float)($input['rate_shadow_gold'] ?? 10.0));
            $reqGold = max(1, (int)($input['req_shadow_gold'] ?? 4));

            $rSPlus = max(0, (float)($input['rate_splus'] ?? 3.0));
            $rSpecial = max(0, (float)($input['rate_shadow_special'] ?? 15.0));

            $stmt = $db->prepare("
                UPDATE gacha_events 
                SET event_name = ?, description = ?, event_type = ?, cost_diamond = ?, cards_per_pack = ?, 
                    target_character_id = ?, target_dice_id = ?, rate_target_boost = ?,
                    start_date = ?, end_date = ?, is_active = ?,
                    rate_shadow_black = ?, req_shadow_black = ?,
                    rate_shadow_red = ?, req_shadow_red = ?,
                    rate_shadow_orange = ?, req_shadow_orange = ?,
                    rate_shadow_blue = ?, req_shadow_blue = ?,
                    rate_shadow_gold = ?, req_shadow_gold = ?,
                    rate_splus = ?, rate_shadow_special = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sssiisidssiididididddddi", 
                $name, $desc, $eventType, $cost, $cardsPerPack, 
                $targetCharId, $targetDiceId, $rateTargetBoost,
                $startDate, $endDate, $isActive,
                $rBlack, $reqBlack,
                $rRed, $reqRed,
                $rOrange, $reqOrange,
                $rBlue, $reqBlue,
                $rGold, $reqGold,
                $rSPlus, $rSpecial,
                $id
            );
            $stmt->execute();
            $stmt->close();

            jsonResponse([
                'status' => 'success',
                'message' => "บันทึกการตั้งค่ากิจกรรมสุ่มสำเร็จ! (จัดแบบ: {$eventType}, เป้าหมายเต๋า ID {$targetDiceId}, กรอบรูป ID {$targetCharId}, เรตบูสต์ {$rateTargetBoost}%, ถึงวันที่ {$endDate})"
            ]);
            break;

        // --- 7.1 Magic Cube Management (ลูกบาศก์นำโชค) ---
        case 'get_cube_configs':
            ensureCubeAndEventTables($db);
            $configs = $db->query("SELECT * FROM cube_configs ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
            foreach ($configs as &$cfg) {
                $cfg['rewards'] = !empty($cfg['rewards_json']) ? json_decode($cfg['rewards_json'], true) : [];
            }
            $users = $db->query("SELECT id, username FROM users ORDER BY id ASC LIMIT 150")->fetch_all(MYSQLI_ASSOC);
            $chars = $db->query("SELECT id, name, grade FROM characters ORDER BY FIELD(grade, 'SS+', 'S+', 'S', 'A+', 'A', 'B'), id ASC")->fetch_all(MYSQLI_ASSOC);
            $dice = $db->query("SELECT id, name, grade FROM dice ORDER BY FIELD(grade, 'SS+', 'S+', 'LEGENDARY', 'EPIC', 'RARE', 'NORMAL'), id ASC")->fetch_all(MYSQLI_ASSOC);
            jsonResponse([
                'status' => 'success',
                'data' => $configs,
                'users' => $users,
                'characters' => $chars,
                'dice' => $dice
            ]);
            break;

        case 'save_cube_config':
            ensureCubeAndEventTables($db);
            $cubeType = trim($input['cube_type'] ?? '');
            $cubeName = trim($input['cube_name'] ?? '');
            $colorHex = trim($input['color_hex'] ?? '#00e5ff');
            $minHours = max(0.1, (float)($input['min_hours'] ?? 1));
            $maxHours = max($minHours, (float)($input['max_hours'] ?? 3));
            $dropRate = max(0, min(100, (float)($input['drop_rate_percent'] ?? 50)));
            $spinDia = max(0, (int)($input['spin_cost_diamond'] ?? 20));
            $spinGold = max(0, (int)($input['spin_cost_gold'] ?? 10000));
            $rewards = is_array($input['rewards'] ?? null) ? $input['rewards'] : [];
            $rewardsJson = json_encode($rewards, JSON_UNESCAPED_UNICODE);

            $stmt = $db->prepare("
                UPDATE cube_configs 
                SET cube_name = ?, color_hex = ?, min_hours = ?, max_hours = ?, drop_rate_percent = ?, spin_cost_diamond = ?, spin_cost_gold = ?, rewards_json = ?
                WHERE cube_type = ?
            ");
            $stmt->bind_param("ssdddiiss", $cubeName, $colorHex, $minHours, $maxHours, $dropRate, $spinDia, $spinGold, $rewardsJson, $cubeType);
            $stmt->execute();
            $stmt->close();

            jsonResponse(['status' => 'success', 'message' => "บันทึกการตั้งค่า '{$cubeName}' (ระยะเวลาสุ่ม {$minHours}-{$maxHours} ชม., รางวัล " . count($rewards) . " รายการ) เรียบร้อย!"]);
            break;

        case 'give_user_cube':
            ensureCubeAndEventTables($db);
            $targetUserId = (int)($input['user_id'] ?? 0);
            $cubeType = strtoupper(trim($input['cube_type'] ?? 'SILVER'));
            if ($targetUserId <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'กรุณาเลือกผู้เล่น'], 400);
            }
            $chk = $db->query("SELECT cube_name FROM cube_configs WHERE cube_type = '{$cubeType}' LIMIT 1")->fetch_assoc();
            if (!$chk) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบประเภทลูกบาศก์นี้'], 400);
            }
            $stmt = $db->prepare("INSERT INTO user_cubes (user_id, cube_type, status) VALUES (?, ?, 'IDLE')");
            $stmt->bind_param("is", $targetUserId, $cubeType);
            $stmt->execute();
            $stmt->close();

            // ส่งจดหมายแจ้งเตือน
            $cubeTitle = "🧊 คุณได้รับของขวัญ: {$chk['cube_name']}!";
            $cubeMsg = "ผู้ดูแลระบบได้มอบ {$chk['cube_name']} ให้คุณ 1 ชิ้น เข้าไปที่เมนู 'หมุนลูกบาศก์' เพื่อเริ่มหมุนลุ้นรับเพชรและทอง!";
            $m = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
            $m->bind_param("iss", $targetUserId, $cubeTitle, $cubeMsg);
            $m->execute();
            $m->close();

            jsonResponse(['status' => 'success', 'message' => "มอบ {$chk['cube_name']} ให้ผู้เล่น ID {$targetUserId} สำเร็จ!"]);
            break;
            break;

        case 'get_room_settings':
            $rooms = ensureAdminRoomSettingsTable($db);
            jsonResponse(['status' => 'success', 'rooms' => $rooms]);
            break;

        case 'save_room_settings':
            ensureAdminRoomSettingsTable($db);
            $roomsPayload = $input['rooms'] ?? [];
            if (!is_array($roomsPayload) || empty($roomsPayload)) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลตั้งค่าห้องแข่งขัน'], 400);
            }
            $stmt = $db->prepare("
                INSERT INTO `room_settings`
                    (room_tier, room_title, entry_fee_gold, start_match_gold, reward_diamond, reward_gold, tax_amount, tax_percent, city_base_cost, landmark_cost, toll_percent, buyout_percent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    room_title = VALUES(room_title),
                    entry_fee_gold = VALUES(entry_fee_gold),
                    start_match_gold = VALUES(start_match_gold),
                    reward_diamond = VALUES(reward_diamond),
                    reward_gold = VALUES(reward_gold),
                    tax_amount = VALUES(tax_amount),
                    tax_percent = VALUES(tax_percent),
                    city_base_cost = VALUES(city_base_cost),
                    landmark_cost = VALUES(landmark_cost),
                    toll_percent = VALUES(toll_percent),
                    buyout_percent = VALUES(buyout_percent)
            ");
            $savedCount = 0;
            foreach ($roomsPayload as $r) {
                $tier = strtoupper(trim((string)($r['room_tier'] ?? '')));
                if (!in_array($tier, ['2M', '5M', '10M', 'PRACTICE'], true)) continue;
                $title = trim((string)($r['room_title'] ?? "ห้อง {$tier}"));
                $entryFee = max(0, (int)($r['entry_fee_gold'] ?? 0));
                $startGold = max(10000, (int)($r['start_match_gold'] ?? 2000000));
                $rewDia = max(0, (int)($r['reward_diamond'] ?? 0));
                $rewGold = max(0, (int)($r['reward_gold'] ?? 0));
                $taxAmt = max(0, (int)($r['tax_amount'] ?? 50000));
                $taxPct = max(1, min(300, (int)($r['tax_percent'] ?? 20)));
                $cityCost = max(500, (int)($r['city_base_cost'] ?? 120000));
                $lmCost = max(1000, (int)($r['landmark_cost'] ?? 320000));
                $tollPct = max(10, min(500, (int)($r['toll_percent'] ?? 85)));
                $buyoutPct = max(100, min(500, (int)($r['buyout_percent'] ?? 160)));

                $stmt->bind_param(
                    "ssiiiiiiiiii",
                    $tier, $title, $entryFee, $startGold,
                    $rewDia, $rewGold, $taxAmt, $taxPct,
                    $cityCost, $lmCost, $tollPct, $buyoutPct
                );
                $stmt->execute();
                $savedCount++;
            }
            $stmt->close();

            jsonResponse([
                'status' => 'success',
                'message' => "บันทึกการตั้งค่าห้องแข่งขัน & เมือง/แลนด์มาร์ค ทั้ง {$savedCount} ห้องเรียบร้อยแล้ว!",
                'rooms' => ensureAdminRoomSettingsTable($db)
            ]);
            break;

        case 'upload_app_icon':
            $imgBinary = null;
            if (isset($_FILES['icon_file']) && $_FILES['icon_file']['error'] === UPLOAD_ERR_OK) {
                $tmpPath = $_FILES['icon_file']['tmp_name'];
                $imgBinary = @file_get_contents($tmpPath);
            } elseif (!empty($input['image_data'])) {
                $raw = (string)$input['image_data'];
                if (str_contains($raw, ';base64,')) {
                    $raw = substr($raw, strpos($raw, ';base64,') + 8);
                }
                $imgBinary = base64_decode($raw);
            }

            if (!$imgBinary || strlen($imgBinary) < 100) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบข้อมูลไฟล์รูปภาพ หรือขนาดไฟล์ไม่ถูกต้อง'], 400);
            }

            $finalPng = null;
            if (function_exists('imagecreatefromstring')) {
                $src = @imagecreatefromstring($imgBinary);
                if ($src !== false) {
                    $w = imagesx($src);
                    $h = imagesy($src);
                    $dst = imagecreatetruecolor(1024, 1024);
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                    $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
                    imagefilledrectangle($dst, 0, 0, 1024, 1024, $transparent);
                    imagecopyresampled($dst, $src, 0, 0, 0, 0, 1024, 1024, $w, $h);

                    ob_start();
                    imagepng($dst, null, 9);
                    $finalPng = ob_get_clean();
                    imagedestroy($src);
                    imagedestroy($dst);
                }
            }

            if (!$finalPng) {
                $finalPng = $imgBinary;
            }

            $root = dirname(__DIR__);
            $destinations = [
                $root . '/ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png',
                $root . '/assets/images/app_icon.png',
                $root . '/apple-touch-icon.png',
                $root . '/apple-touch-icon-precomposed.png',
                $root . '/favicon.png',
                $root . '/www/apple-touch-icon.png',
                $root . '/www/assets/images/app_icon.png',
                $root . '/ios/App/App/public/apple-touch-icon.png'
            ];

            $savedCount = 0;
            foreach ($destinations as $dstPath) {
                $dDir = dirname($dstPath);
                if (!is_dir($dDir)) {
                    @mkdir($dDir, 0755, true);
                }
                if (@file_put_contents($dstPath, $finalPng) !== false) {
                    $savedCount++;
                }
            }

            $tNow = time();
            jsonResponse([
                'status' => 'success',
                'message' => 'บันทึกไอคอนแอปใหม่ขนาด 1024x1024 เรียบร้อยแล้ว (อัปเดตลงระบบ iOS และ Web ทั้งหมด ' . $savedCount . ' ไฟล์)',
                'icon_url' => '../assets/images/app_icon.png?v=' . $tNow,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            break;

        // ============================================================
        // 🗺️ AI 3D BOARD STUDIO API ACTIONS
        // ============================================================
        case 'get_custom_boards':
            ensureCustomBoardsTable($db);
            $boards = getAllCustomBoards($db, false);
            jsonResponse([
                'status' => 'success',
                'boards' => $boards
            ]);
            break;

        case 'save_custom_board':
            ensureCustomBoardsTable($db);
            $id = (int)($input['id'] ?? 0);
            $boardName = trim((string)($input['board_name'] ?? 'กระดาน AI 3D ใหม่'));
            if ($boardName === '') $boardName = 'กระดาน AI 3D ใหม่';
            $boardCode = trim((string)($input['board_code'] ?? ''));
            if ($boardCode === '') {
                $boardCode = 'ai_board_' . time() . '_' . mt_rand(100, 999);
            }
            $description = trim((string)($input['description'] ?? ''));
            $shapeType = trim((string)($input['shape_type'] ?? 'rectangle'));
            if (!in_array($shapeType, ['rectangle', 'square', 'spiral', 'hexagon', 'diamond_ring'], true)) {
                $shapeType = 'rectangle';
            }
            $gridCols = max(4, min(20, (int)($input['grid_cols'] ?? 12)));
            $gridRows = max(4, min(20, (int)($input['grid_rows'] ?? 8)));
            $totalTiles = max(20, min(200, (int)($input['total_tiles'] ?? 100)));
            $tileSize = max(3.0, min(10.0, (float)($input['tile_size'] ?? 6.20)));
            $tileGap = max(0.05, min(2.0, (float)($input['tile_gap'] ?? 0.40)));
            $sourceImageUrl = (string)($input['source_image_url'] ?? '');
            $applyBoardTexture = !empty($input['apply_board_texture']) ? 1 : 0;

            $themeConfig = is_array($input['theme_config'] ?? null) ? $input['theme_config'] : [];
            $cities = is_array($input['cities'] ?? null) ? $input['cities'] : getDefaultAiCityNames($totalTiles, 'thai_famous');
            $specialTiles = is_array($input['special_tiles'] ?? null) ? $input['special_tiles'] : [];
            $effects = is_array($input['effects'] ?? null) ? $input['effects'] : [];
            $rollBtnConfig = is_array($input['roll_btn_config'] ?? null) ? $input['roll_btn_config'] : [];

            $themeJson = json_encode($themeConfig, JSON_UNESCAPED_UNICODE);
            $citiesJson = json_encode($cities, JSON_UNESCAPED_UNICODE);
            $specialJson = json_encode($specialTiles, JSON_UNESCAPED_UNICODE);
            $effectsJson = json_encode($effects, JSON_UNESCAPED_UNICODE);
            $rollBtnJson = json_encode($rollBtnConfig, JSON_UNESCAPED_UNICODE);

            $isActive = isset($input['is_active']) ? ((int)$input['is_active'] ? 1 : 0) : 1;
            $isDefault = !empty($input['is_default']) ? 1 : 0;

            if ($isDefault === 1) {
                $db->query("UPDATE `custom_boards` SET `is_default` = 0");
                $isActive = 1; // ถ้าตั้งเป็นกระดานหลัก ต้องเปิดใช้งานด้วยเสมอ
            }

            if ($id > 0) {
                $stmt = $db->prepare("
                    UPDATE `custom_boards`
                    SET `board_name` = ?, `description` = ?, `shape_type` = ?, `grid_cols` = ?, `grid_rows` = ?,
                        `total_tiles` = ?, `tile_size` = ?, `tile_gap` = ?, `source_image_url` = ?, `apply_board_texture` = ?,
                        `theme_config_json` = ?, `cities_json` = ?, `special_tiles_json` = ?, `effects_json` = ?, `roll_btn_config_json` = ?,
                        `is_active` = ?, `is_default` = ?
                    WHERE `id` = ?
                ");
                $stmt->bind_param(
                    "sssiiiddsisssssiii",
                    $boardName, $description, $shapeType, $gridCols, $gridRows,
                    $totalTiles, $tileSize, $tileGap, $sourceImageUrl, $applyBoardTexture,
                    $themeJson, $citiesJson, $specialJson, $effectsJson, $rollBtnJson,
                    $isActive, $isDefault, $id
                );
                $stmt->execute();
                $stmt->close();
                $savedId = $id;
            } else {
                $stmt = $db->prepare("
                    INSERT INTO `custom_boards`
                    (`board_code`, `board_name`, `description`, `shape_type`, `grid_cols`, `grid_rows`, `total_tiles`, `tile_size`, `tile_gap`, `source_image_url`, `apply_board_texture`, `theme_config_json`, `cities_json`, `special_tiles_json`, `effects_json`, `roll_btn_config_json`, `is_active`, `is_default`)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param(
                    "ssssiiiddsisssssii",
                    $boardCode, $boardName, $description, $shapeType, $gridCols, $gridRows,
                    $totalTiles, $tileSize, $tileGap, $sourceImageUrl, $applyBoardTexture,
                    $themeJson, $citiesJson, $specialJson, $effectsJson, $rollBtnJson,
                    $isActive, $isDefault
                );
                $stmt->execute();
                $savedId = (int)$stmt->insert_id;
                $stmt->close();
            }

            jsonResponse([
                'status' => 'success',
                'message' => "บันทึกกระดาน 3D '{$boardName}' เรียบร้อยแล้ว!" . ($isDefault ? " (ตั้งเป็นกระดานหลักพร้อมเล่นทันที)" : ""),
                'board_id' => $savedId,
                'boards' => getAllCustomBoards($db, false)
            ]);
            break;

        case 'toggle_custom_board':
            ensureCustomBoardsTable($db);
            $id = (int)($input['id'] ?? 0);
            $isActive = !empty($input['is_active']) ? 1 : 0;
            $makeDefault = !empty($input['is_default']) ? 1 : 0;
            if ($id <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสกระดาน'], 400);
            }
            if ($makeDefault === 1) {
                $db->query("UPDATE `custom_boards` SET `is_default` = 0");
                $stmt = $db->prepare("UPDATE `custom_boards` SET `is_active` = 1, `is_default` = 1 WHERE `id` = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();
                $msg = 'เปิดใช้งานและตั้งเป็นกระดานหลักพร้อมเล่นทันทีเรียบร้อย!';
            } else {
                if ($isActive === 0) {
                    $stmt = $db->prepare("UPDATE `custom_boards` SET `is_active` = 0, `is_default` = 0 WHERE `id` = ?");
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $stmt->close();
                    $msg = 'ยกเลิก/ปิดการแสดงผลกระดานนี้เรียบร้อยแล้ว';
                } else {
                    $stmt = $db->prepare("UPDATE `custom_boards` SET `is_active` = 1 WHERE `id` = ?");
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $stmt->close();
                    $msg = 'เปิดใช้งานกระดานนี้ให้ผู้เล่นเลือกเล่นได้ทันที!';
                }
            }
            jsonResponse([
                'status' => 'success',
                'message' => $msg,
                'boards' => getAllCustomBoards($db, false)
            ]);
            break;

        case 'cancel_all_default_boards':
            ensureCustomBoardsTable($db);
            $db->query("UPDATE `custom_boards` SET `is_default` = 0");
            jsonResponse([
                'status' => 'success',
                'message' => 'ยกเลิกการใช้กระดาน AI เป็นค่าเริ่มต้น (กลับไปใช้กระดานมาตรฐานของระบบ)',
                'boards' => getAllCustomBoards($db, false)
            ]);
            break;

        case 'delete_custom_board':
            ensureCustomBoardsTable($db);
            $id = (int)($input['id'] ?? 0);
            if ($id <= 0) {
                jsonResponse(['status' => 'error', 'message' => 'ไม่พบรหัสกระดาน'], 400);
            }
            $stmt = $db->prepare("DELETE FROM `custom_boards` WHERE `id` = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            jsonResponse([
                'status' => 'success',
                'message' => 'ลบกระดาน 3D ออกจากระบบเรียบร้อยแล้ว',
                'boards' => getAllCustomBoards($db, false)
            ]);
            break;

        case 'ai_generate_city_names':
            $totalTiles = max(20, min(200, (int)($input['total_tiles'] ?? 100)));
            $style = trim((string)($input['style'] ?? 'thai_famous'));
            $customPrefix = trim((string)($input['custom_prefix'] ?? ''));
            $shuffle = !empty($input['shuffle']);
            $cities = getDefaultAiCityNames($totalTiles, $style);
            if ($shuffle && count($cities) > 3) {
                $middle = [];
                for ($i = 2; $i < $totalTiles; $i++) {
                    if ($i === 10) continue; // keep jail slot name
                    $middle[] = $cities[$i];
                }
                shuffle($middle);
                $mIdx = 0;
                for ($i = 2; $i < $totalTiles; $i++) {
                    if ($i === 10) continue;
                    $cities[$i] = $middle[$mIdx++] ?? ("เมือง #" . $i);
                }
            }
            if ($customPrefix !== '') {
                for ($i = 2; $i < $totalTiles; $i++) {
                    if ($i === 10) continue;
                    $cities[$i] = $customPrefix . ' ' . $cities[$i];
                }
            }
            jsonResponse([
                'status' => 'success',
                'cities' => $cities,
                'message' => 'AI สร้างและจัดเรียงชื่อเมืองครบทั้ง ' . $totalTiles . ' ช่องเรียบร้อย!'
            ]);
            break;

        default:
            jsonResponse(['status' => 'error', 'message' => 'Invalid admin action'], 400);
    }
}

function ensureAdminRoomSettingsTable(mysqli $db): array {
    $db->query("
        CREATE TABLE IF NOT EXISTS `room_settings` (
            `room_tier` VARCHAR(16) NOT NULL PRIMARY KEY,
            `room_title` VARCHAR(80) NOT NULL,
            `entry_fee_gold` INT NOT NULL DEFAULT 2000 COMMENT 'ค่าผ่านทางเข้าห้อง (ทอง)',
            `start_match_gold` BIGINT NOT NULL DEFAULT 2000000 COMMENT 'เงินทองเริ่มต้นในกระดาน (Match Gold)',
            `reward_diamond` INT NOT NULL DEFAULT 200 COMMENT 'รางวัลเพชรเมื่อชนะ',
            `reward_gold` INT NOT NULL DEFAULT 100000 COMMENT 'รางวัลทองเข้ากระเป๋าหลักเมื่อชนะ',
            `tax_amount` BIGINT NOT NULL DEFAULT 50000 COMMENT 'ฐานภาษีขั้นต่ำช่อง TAX (เมื่อไม่มีเมือง)',
            `tax_percent` INT NOT NULL DEFAULT 20 COMMENT 'อัตราภาษีตามค่าก่อสร้างเมืองรวม (%)',
            `city_base_cost` BIGINT NOT NULL DEFAULT 120000 COMMENT 'ราคาสร้างเมืองเริ่มต้นต่อหลัง',
            `landmark_cost` BIGINT NOT NULL DEFAULT 320000 COMMENT 'ราคาอัปเกรดแลนด์มาร์ค',
            `toll_percent` INT NOT NULL DEFAULT 85 COMMENT 'อัตราค่าผ่านทาง (% ของมูลค่าเมือง)',
            `buyout_percent` INT NOT NULL DEFAULT 160 COMMENT 'อัตราซื้อต่อเมือง (% ของมูลค่าเมือง ยกเว้นแลนด์มาร์ค)',
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $colChk = $db->query("SHOW COLUMNS FROM `room_settings` LIKE 'tax_percent'");
    if ($colChk && $colChk->num_rows === 0) {
        $db->query("ALTER TABLE `room_settings` ADD COLUMN `tax_percent` INT NOT NULL DEFAULT 20 COMMENT 'อัตราภาษีตามค่าก่อสร้างเมืองรวม (%)' AFTER `tax_amount`");
    }

    $defaults = [
        '2M' => [
            'room_tier' => '2M', 'room_title' => 'ห้อง 2M (ยอดนิยม)',
            'entry_fee_gold' => 2000, 'start_match_gold' => 2000000,
            'reward_diamond' => 200, 'reward_gold' => 100000,
            'tax_amount' => 50000, 'tax_percent' => 20,
            'city_base_cost' => 120000, 'landmark_cost' => 320000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ],
        '5M' => [
            'room_tier' => '5M', 'room_title' => 'ห้อง 5M (ระดับเซียน)',
            'entry_fee_gold' => 5000, 'start_match_gold' => 5000000,
            'reward_diamond' => 500, 'reward_gold' => 300000,
            'tax_amount' => 120000, 'tax_percent' => 22,
            'city_base_cost' => 300000, 'landmark_cost' => 800000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ],
        '10M' => [
            'room_tier' => '10M', 'room_title' => 'ห้อง 10M (มหาเศรษฐี)',
            'entry_fee_gold' => 10000, 'start_match_gold' => 10000000,
            'reward_diamond' => 1200, 'reward_gold' => 800000,
            'tax_amount' => 250000, 'tax_percent' => 25,
            'city_base_cost' => 600000, 'landmark_cost' => 1600000,
            'toll_percent' => 90, 'buyout_percent' => 160
        ],
        'PRACTICE' => [
            'room_tier' => 'PRACTICE', 'room_title' => 'โหมดทดลองเล่น (ฝึกซ้อม)',
            'entry_fee_gold' => 0, 'start_match_gold' => 2000000,
            'reward_diamond' => 0, 'reward_gold' => 0,
            'tax_amount' => 50000, 'tax_percent' => 20,
            'city_base_cost' => 120000, 'landmark_cost' => 320000,
            'toll_percent' => 85, 'buyout_percent' => 160
        ]
    ];

    $res = $db->query("SELECT * FROM `room_settings`");
    $existing = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $t = strtoupper($row['room_tier']);
            $existing[$t] = [
                'room_tier' => $t,
                'room_title' => $row['room_title'],
                'entry_fee_gold' => (int)$row['entry_fee_gold'],
                'start_match_gold' => (int)$row['start_match_gold'],
                'reward_diamond' => (int)$row['reward_diamond'],
                'reward_gold' => (int)$row['reward_gold'],
                'tax_amount' => (int)$row['tax_amount'],
                'tax_percent' => isset($row['tax_percent']) ? (int)$row['tax_percent'] : 20,
                'city_base_cost' => (int)$row['city_base_cost'],
                'landmark_cost' => (int)$row['landmark_cost'],
                'toll_percent' => (int)$row['toll_percent'],
                'buyout_percent' => (int)$row['buyout_percent']
            ];
        }
    }

    foreach ($defaults as $tierKey => $d) {
        if (!isset($existing[$tierKey])) {
            $ins = $db->prepare("
                INSERT IGNORE INTO `room_settings`
                (room_tier, room_title, entry_fee_gold, start_match_gold, reward_diamond, reward_gold, tax_amount, tax_percent, city_base_cost, landmark_cost, toll_percent, buyout_percent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $ins->bind_param(
                "ssiiiiiiiiii",
                $d['room_tier'], $d['room_title'], $d['entry_fee_gold'], $d['start_match_gold'],
                $d['reward_diamond'], $d['reward_gold'], $d['tax_amount'], $d['tax_percent'],
                $d['city_base_cost'], $d['landmark_cost'], $d['toll_percent'], $d['buyout_percent']
            );
            $ins->execute();
            $ins->close();
            $existing[$tierKey] = $d;
        }
    }

    $ordered = [];
    foreach (['2M', '5M', '10M', 'PRACTICE'] as $k) {
        if (isset($existing[$k])) $ordered[$k] = $existing[$k];
    }
    return $ordered;
}

/**
 * Render Modern Responsive Admin Web Panel
 */
function renderAdminWebUi(mysqli $db): void {
    header('Content-Type: text/html; charset=utf-8');

    $currentAdminId = (int)($_SESSION['snake_admin_id'] ?? 1);
    $admStmt = $db->prepare("SELECT * FROM `admins` WHERE id = ? LIMIT 1");
    $admStmt->bind_param("i", $currentAdminId);
    $admStmt->execute();
    $currentAdmin = $admStmt->get_result()->fetch_assoc() ?: [
        'id' => $currentAdminId,
        'username' => $_SESSION['snake_admin_user'] ?? 'admin',
        'display_name' => $_SESSION['snake_admin_name'] ?? 'Super Admin',
        'email' => ''
    ];
    $admStmt->close();

    $adminsRes = $db->query("SELECT id, username, display_name, email, role, last_login_at, created_at FROM `admins` ORDER BY id ASC");
    $adminsList = $adminsRes ? $adminsRes->fetch_all(MYSQLI_ASSOC) : [];

    $usersRes = $db->query("SELECT id, username, avatar_url, diamond, gold, level, line_id, google_id, is_banned, last_login_at FROM users ORDER BY id DESC LIMIT 50");
    $usersList = $usersRes ? $usersRes->fetch_all(MYSQLI_ASSOC) : [];

    $events = $db->query("SELECT * FROM events ORDER BY id DESC LIMIT 10");
    $events = $events ? $events->fetch_all(MYSQLI_ASSOC) : [];

    $packages = $db->query("SELECT * FROM topup_packages ORDER BY price_thb ASC");
    $packages = $packages ? $packages->fetch_all(MYSQLI_ASSOC) : [];

    $promptPaySettings = [
        'id' => '',
        'name' => '',
        'bank' => ''
    ];
    $ppRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('payment_promptpay_id', 'payment_promptpay_name', 'payment_promptpay_bank')");
    if ($ppRes) {
        while ($row = $ppRes->fetch_assoc()) {
            if ($row['setting_key'] === 'payment_promptpay_id') $promptPaySettings['id'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_promptpay_name') $promptPaySettings['name'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_promptpay_bank') $promptPaySettings['bank'] = $row['setting_value'];
        }
    }

    $shopeePaySettings = [
        'id' => '',
        'name' => '',
        'qr_url' => '',
        'active' => '1'
    ];
    $spRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('payment_shopeepay_id', 'payment_shopeepay_name', 'payment_shopeepay_qr_url', 'payment_shopeepay_active')");
    if ($spRes) {
        while ($row = $spRes->fetch_assoc()) {
            if ($row['setting_key'] === 'payment_shopeepay_id') $shopeePaySettings['id'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_shopeepay_name') $shopeePaySettings['name'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_shopeepay_qr_url') $shopeePaySettings['qr_url'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_shopeepay_active') $shopeePaySettings['active'] = $row['setting_value'];
        }
    }

    $paypalSettings = [
        'email' => '',
        'client_id' => '',
        'currency' => 'THB',
        'sandbox' => '0'
    ];
    $paypalRes = @$db->query("SELECT setting_key, setting_value FROM `game_settings` WHERE setting_key IN ('payment_paypal_email', 'payment_paypal_client_id', 'payment_paypal_currency', 'payment_paypal_sandbox')");
    if ($paypalRes) {
        while ($row = $paypalRes->fetch_assoc()) {
            if ($row['setting_key'] === 'payment_paypal_email') $paypalSettings['email'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_paypal_client_id') $paypalSettings['client_id'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_paypal_currency') $paypalSettings['currency'] = $row['setting_value'];
            if ($row['setting_key'] === 'payment_paypal_sandbox') $paypalSettings['sandbox'] = $row['setting_value'];
        }
    }

    $skills = $db->query("SELECT * FROM skills ORDER BY id ASC");
    $skills = $skills ? $skills->fetch_all(MYSQLI_ASSOC) : [];

    $characters = $db->query("SELECT c.*, s.name as skill_name FROM characters c LEFT JOIN skills s ON c.skill_id = s.id");
    $characters = $characters ? $characters->fetch_all(MYSQLI_ASSOC) : [];

    $dice = $db->query("SELECT * FROM dice ORDER BY id ASC");
    $dice = $dice ? $dice->fetch_all(MYSQLI_ASSOC) : [];

    $activeGachaRes = $db->query("SELECT * FROM gacha_events ORDER BY id DESC LIMIT 1");
    $activeGacha = $activeGachaRes ? $activeGachaRes->fetch_assoc() : null;
    $activeGachaTargetDiceId = (int)($activeGacha['target_dice_id'] ?? 1);

    $uRes = $db->query("SELECT COUNT(*) as cnt FROM users");
    $userCount = $uRes ? (int)($uRes->fetch_assoc()['cnt'] ?? 0) : 0;

    // OTA Status & AI Delta Size Analysis for Mobile App Settings
    $initialOtaInfo = function_exists('getOtaStatusInfo') ? getOtaStatusInfo($db) : [];
    $initialUpdateSize = !empty($initialOtaInfo['update_size']) 
        ? $initialOtaInfo['update_size'] 
        : ($initialOtaInfo['ai_size_analysis']['update_size'] ?? '2.8 MB');
    $initialUpdateFiles = $initialOtaInfo['file_count'] ?? ($initialOtaInfo['ai_size_analysis']['files_count'] ?? 14);
    $initialUpdateFilesText = $initialUpdateFiles . ' ไฟล์';
    $initialAiSummary = $initialOtaInfo['ai_size_analysis']['analysis_summary'] ?? "AI คำนวณขนาดและจำนวนไฟล์อัปเดต: {$initialUpdateSize} ({$initialUpdateFilesText})";
    $initialPrevFormatted = $initialOtaInfo['ai_size_analysis']['previous_bundle_formatted'] ?? '-';
    $initialCurFormatted = $initialOtaInfo['ai_size_analysis']['current_bundle_formatted'] ?? '-';
    $initialDiffFormatted = $initialOtaInfo['ai_size_analysis']['diff_formatted'] ?? '';
    $initialAppVersion = $initialOtaInfo['app_version'] ?? '1.0.0';
    $initialCacheBuster = $initialOtaInfo['cache_buster'] ?? 126;
    $initialGameUrl = $initialOtaInfo['game_url'] ?? 'https://pmix01.thddns.net:7175/home/snake/';
    $initialForceClear = !empty($initialOtaInfo['force_clear_cache']);
    ?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ระบบจัดการหลังบ้าน Snake & Ladder 3D Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0f172a;
            --panel-bg: #1e293b;
            --panel-border: #334155;
            --primary: #06b6d4;
            --accent: #f59e0b;
            --success: #10b981;
            --danger: #ef4444;
            --text-light: #f8fafc;
            --text-muted: #94a3b8;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Kanit', sans-serif; }
        body { background: var(--bg-dark); color: var(--text-light); padding: 0; margin: 0; min-height: 100vh; overflow-x: hidden; }
        
        /* 📱 Modern Left Sidebar Layout */
        .admin-layout { display: flex; min-height: 100vh; background: var(--bg-dark); }
        .admin-sidebar {
            width: 285px;
            min-width: 285px;
            max-width: 285px;
            background: #080d1a;
            border-right: 1.5px solid rgba(56, 189, 248, 0.2);
            display: flex;
            flex-direction: column;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            box-shadow: 4px 0 25px rgba(0, 0, 0, 0.55);
            scrollbar-width: thin;
            scrollbar-color: #334155 #080d1a;
        }
        .admin-sidebar::-webkit-scrollbar { width: 5px; }
        .admin-sidebar::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }

        .sidebar-header {
            padding: 16px 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            gap: 12px;
            background: linear-gradient(180deg, rgba(30, 41, 59, 0.6) 0%, transparent 100%);
        }
        .sidebar-logo-icon {
            font-size: 28px;
            filter: drop-shadow(0 0 10px rgba(6, 182, 212, 0.65));
        }
        .sidebar-logo-text {
            font-size: 15px;
            font-weight: 800;
            color: #f8fafc;
            line-height: 1.2;
            letter-spacing: 0.3px;
        }
        .sidebar-logo-sub {
            font-size: 11px;
            color: var(--primary);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .sidebar-menu {
            flex: 1;
            padding: 12px 10px;
            display: flex;
            flex-direction: column;
            gap: 3px;
        }
        .sidebar-section-title {
            font-size: 10.5px;
            color: #64748b;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            padding: 10px 10px 4px 10px;
            margin-top: 6px;
        }
        .sidebar-section-title:first-child { margin-top: 0; }

        .sidebar-tab-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 9px 12px;
            border-radius: 10px;
            border: 1.5px solid transparent;
            background: transparent;
            color: #94a3b8;
            font-size: 13px;
            font-weight: 600;
            text-align: left;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            text-decoration: none;
            box-sizing: border-box;
        }
        .sidebar-tab-btn:hover {
            background: rgba(30, 41, 59, 0.85);
            color: #f8fafc;
            border-color: rgba(56, 189, 248, 0.3);
            transform: translateX(3px);
        }
        .sidebar-tab-btn.active {
            background: linear-gradient(135deg, rgba(6, 182, 212, 0.22) 0%, rgba(14, 165, 233, 0.12) 100%);
            color: #00e5ff;
            font-weight: 800;
            border-color: rgba(0, 229, 255, 0.5);
            box-shadow: 0 0 15px rgba(0, 229, 255, 0.18), inset 3px 0 0 #00e5ff;
        }
        .sidebar-tab-btn .btn-icon {
            font-size: 16px;
            min-width: 22px;
            text-align: center;
            display: inline-flex;
            justify-content: center;
            align-items: center;
        }
        .sidebar-tab-btn .btn-text {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .sidebar-tab-btn .btn-badge {
            font-size: 10px;
            font-weight: 800;
            padding: 2px 7px;
            border-radius: 10px;
            margin-left: auto;
        }

        .sidebar-footer {
            padding: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(15, 23, 42, 0.6);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .admin-main-wrapper {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background: var(--bg-dark);
        }
        .admin-main-wrapper .header {
            margin-bottom: 0;
            padding: 14px 24px;
            background: rgba(15, 23, 42, 0.88);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .admin-main-wrapper .header h1 { font-size: 20px; color: var(--primary); display: flex; align-items: center; gap: 10px; margin: 0; }
        .admin-content-area {
            flex: 1;
            padding: 24px;
            min-width: 0;
        }
        .stats-badge { background: #3b82f6; padding: 6px 14px; border-radius: 20px; font-size: 14px; font-weight: 600; }
        .tabs { display: none; }
        .tab-btn { display: none; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .grid-2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 24px; }
        .card { background: var(--panel-bg); border: 1px solid var(--panel-border); border-radius: 12px; padding: 20px; margin-bottom: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.2); }
        .card h2 { font-size: 18px; margin-bottom: 16px; color: var(--accent); border-bottom: 1px solid var(--panel-border); padding-bottom: 8px; }
        .form-group { margin-bottom: 14px; }
        label { display: block; font-size: 13px; color: var(--text-muted); margin-bottom: 6px; }
        input, select, textarea { width: 100%; background: #0b1120; border: 1px solid var(--panel-border); border-radius: 6px; padding: 10px; color: #fff; font-size: 14px; }
        input:focus, select:focus, textarea:focus { border-color: var(--primary); outline: none; }
        .btn { background: var(--primary); color: #000; border: none; padding: 10px 18px; border-radius: 6px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-accent { background: var(--accent); color: #000; }
        .btn-danger { background: var(--danger); color: #fff; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--panel-border); }
        th { background: #0f172a; color: var(--text-muted); }
        tr:hover { background: rgba(255,255,255,0.03); }
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; }
        .badge-gold { background: #d97706; color: #fff; }
        .badge-dia { background: #0284c7; color: #fff; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: var(--success); color: #fff; padding: 12px 20px; border-radius: 8px; display: none; z-index: 9999; }
        
        /* AI Frame Studio Live Aura & Special FX Animations */
        @keyframes auraPulseOrange {
            0%, 100% { box-shadow: 0 0 25px rgba(255,102,0,0.85), 0 0 55px rgba(255,51,0,0.65), inset 0 0 20px rgba(255,170,0,0.6); }
            50% { box-shadow: 0 0 48px rgba(255,136,0,1), 0 0 92px rgba(255,68,0,0.92), inset 0 0 36px rgba(255,200,0,0.85); }
        }
        @keyframes auraPulseGold {
            0%, 100% { box-shadow: 0 0 25px rgba(255,215,0,0.85), 0 0 55px rgba(245,158,11,0.65), inset 0 0 20px rgba(255,255,255,0.6); }
            50% { box-shadow: 0 0 48px rgba(255,215,0,1), 0 0 92px rgba(217,119,6,0.92), inset 0 0 36px rgba(255,255,255,0.9); }
        }
        @keyframes auraPulseYellow {
            0%, 100% { box-shadow: 0 0 20px rgba(250,204,21,0.75), 0 0 42px rgba(234,179,8,0.55); }
            50% { box-shadow: 0 0 38px rgba(250,204,21,1), 0 0 70px rgba(202,138,4,0.85); }
        }
        @keyframes auraPulseCyan {
            0%, 100% { box-shadow: 0 0 20px rgba(0,229,255,0.75), 0 0 42px rgba(2,132,199,0.55); }
            50% { box-shadow: 0 0 38px rgba(0,229,255,1), 0 0 70px rgba(2,132,199,0.85); }
        }
        @keyframes auraPulseCrimson {
            0%, 100% { box-shadow: 0 0 24px rgba(239,68,68,0.85), 0 0 52px rgba(185,28,28,0.65), inset 0 0 18px rgba(248,113,113,0.55); }
            50% { box-shadow: 0 0 46px rgba(255,40,80,1), 0 0 88px rgba(220,38,38,0.92), inset 0 0 34px rgba(252,165,165,0.85); }
        }
        @keyframes auraPulsePurple {
            0%, 100% { box-shadow: 0 0 24px rgba(168,85,247,0.85), 0 0 52px rgba(109,40,217,0.65), inset 0 0 18px rgba(216,180,254,0.55); }
            50% { box-shadow: 0 0 46px rgba(192,132,252,1), 0 0 88px rgba(126,34,206,0.92), inset 0 0 34px rgba(233,213,255,0.85); }
        }
        @keyframes auraPulseRainbow {
            0% { box-shadow: 0 0 30px #ff0055, 0 0 65px rgba(255,136,0,0.8); filter: hue-rotate(0deg); }
            50% { box-shadow: 0 0 42px #00e5ff, 0 0 82px rgba(168,85,247,0.9); filter: hue-rotate(180deg); }
            100% { box-shadow: 0 0 30px #ff0055, 0 0 65px rgba(255,136,0,0.8); filter: hue-rotate(360deg); }
        }
        @keyframes auraPulseWhite {
            0%, 100% { box-shadow: 0 0 15px rgba(255,255,255,0.65), 0 0 35px rgba(255,255,255,0.45); }
            50% { box-shadow: 0 0 32px rgba(255,255,255,0.95), 0 0 58px rgba(255,255,255,0.75); }
        }
        @keyframes aiFrameSpinSlow {
            from { transform: translate(-50%, -50%) rotate(0deg); }
            to { transform: translate(-50%, -50%) rotate(360deg); }
        }
        @keyframes aiFrameSpinReverse {
            from { transform: translate(-50%, -50%) rotate(360deg); }
            to { transform: translate(-50%, -50%) rotate(0deg); }
        }
        @keyframes aiFrameSpinPulse {
            0% { transform: translate(-50%, -50%) rotate(0deg) scale(0.98); filter: brightness(1); }
            50% { transform: translate(-50%, -50%) rotate(180deg) scale(1.04); filter: brightness(1.25); }
            100% { transform: translate(-50%, -50%) rotate(360deg) scale(0.98); filter: brightness(1); }
        }
        @keyframes aiFrameBreathe {
            0%, 100% { transform: translate(-50%, -50%) scale(0.98); filter: brightness(0.96); }
            50% { transform: translate(-50%, -50%) scale(1.04); filter: brightness(1.22); }
        }
        @keyframes aiFlameFlicker {
            0%, 100% { transform: translate(-50%, -50%) scale(1) rotate(-1.5deg); filter: brightness(1.05) contrast(1.05); }
            50% { transform: translate(-50%, -50%) scale(1.05) rotate(1.5deg); filter: brightness(1.3) contrast(1.12); }
        }
        .aura-anim-orange { animation: auraPulseOrange 2s infinite ease-in-out; }
        .aura-anim-gold { animation: auraPulseGold 2s infinite ease-in-out; }
        .aura-anim-yellow { animation: auraPulseYellow 2s infinite ease-in-out; }
        .aura-anim-cyan { animation: auraPulseCyan 2s infinite ease-in-out; }
        .aura-anim-crimson { animation: auraPulseCrimson 1.9s infinite ease-in-out; }
        .aura-anim-purple { animation: auraPulsePurple 2.1s infinite ease-in-out; }
        .aura-anim-rainbow { animation: auraPulseRainbow 3.2s infinite linear; }
        .aura-anim-white { animation: auraPulseWhite 2s infinite ease-in-out; }

        .fx-ring-spin_slow { animation: aiFrameSpinSlow 10s linear infinite; }
        .fx-ring-spin_pulse { animation: aiFrameSpinPulse 7s linear infinite; }
        .fx-ring-reverse_dual { animation: aiFrameSpinSlow 8s linear infinite; }
        .fx-ring-electric_orbit { animation: aiFrameBreathe 2.2s ease-in-out infinite; }
        .fx-ring-flame_halo { animation: aiFlameFlicker 1.4s ease-in-out infinite; }
        .fx-ring-pulse_breathe { animation: aiFrameBreathe 2.6s ease-in-out infinite; }
        .fx-ring-static { transform: translate(-50%, -50%); }

        .fx-deco-orbit {
            position: absolute; top: 50%; left: 50%;
            width: 118%; height: 118%; border-radius: 50%;
            transform: translate(-50%, -50%); pointer-events: none; z-index: 5;
        }
        .fx-deco-orbit.dual-ring {
            border: 2px dashed rgba(255,255,255,0.75);
            box-shadow: 0 0 12px currentColor;
            animation: aiFrameSpinReverse 5.5s linear infinite;
        }
        .fx-deco-orbit.spark-orbit {
            animation: aiFrameSpinSlow 3.2s linear infinite;
        }
        .fx-deco-orbit.spark-orbit::before,
        .fx-deco-orbit.spark-orbit::after {
            content: '✦';
            position: absolute; font-size: 16px; color: #fff;
            text-shadow: 0 0 10px #00e5ff, 0 0 18px #ffd700;
        }
        .fx-deco-orbit.spark-orbit::before { top: -6px; left: 50%; transform: translateX(-50%); }
        .fx-deco-orbit.spark-orbit::after { bottom: -6px; left: 50%; transform: translateX(-50%); }
        .fx-deco-orbit.flame-ring {
            width: 122%; height: 122%;
            background: conic-gradient(from 0deg, transparent 0%, rgba(255,102,0,0.55) 20%, transparent 40%, rgba(255,215,0,0.6) 65%, transparent 85%, rgba(255,51,0,0.55) 100%);
            -webkit-mask: radial-gradient(circle, transparent 61%, #000 66%, #000 72%, transparent 75%);
            mask: radial-gradient(circle, transparent 61%, #000 66%, #000 72%, transparent 75%);
            animation: aiFrameSpinSlow 4s linear infinite;
        }

        @keyframes livePulseDot {
            0%, 100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.75); }
            50% { transform: scale(1.2); opacity: 0.85; box-shadow: 0 0 0 7px rgba(16, 185, 129, 0); }
        }
        .live-pulse-dot {
            width: 10px;
            height: 10px;
            background: #10b981;
            border-radius: 50%;
            display: inline-block;
            animation: livePulseDot 1.4s infinite ease-in-out;
        }

        /* ============================================================ */
        /* 🎲 3D DICE & AURA SIMULATOR STYLES */
        /* ============================================================ */
        .dice-stage-box {
            position: relative;
            background: radial-gradient(circle at center, rgba(30, 41, 59, 0.75) 0%, rgba(15, 23, 42, 0.98) 75%);
            border: 2px solid rgba(168, 85, 247, 0.35);
            border-radius: 18px;
            padding: 24px;
            text-align: center;
            overflow: hidden;
            box-shadow: 0 10px 35px rgba(0,0,0,0.5), inset 0 0 25px rgba(168, 85, 247, 0.12);
        }

        .dice-scene {
            perspective: 900px;
            width: 200px;
            height: 200px;
            margin: 25px auto 35px auto;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .dice-pedestal-platform {
            position: absolute;
            bottom: -25px;
            width: 220px;
            height: 70px;
            background: radial-gradient(ellipse at center, var(--aura-glow-color, #00e5ff) 0%, rgba(168, 85, 247, 0.25) 45%, transparent 70%);
            border-radius: 50%;
            transform: rotateX(68deg);
            opacity: 0.85;
            pointer-events: none;
            transition: all 0.3s ease;
        }

        .dice-aura-glow-wrapper {
            position: absolute;
            width: 220px;
            height: 220px;
            display: flex;
            align-items: center;
            justify-content: center;
            pointer-events: none;
            z-index: 1;
            transition: transform 0.25s ease;
        }

        .dice-aura-glow-wrapper.is-rolling {
            animation: auraGlowRollPhysics 1.25s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }

        @keyframes auraGlowRollPhysics {
            0% { transform: translateY(0) scale(1); filter: brightness(1); }
            20% { transform: translateY(-48px) scale(1.55); filter: brightness(1.8); }
            55% { transform: translateY(-22px) scale(1.35); filter: brightness(1.4); }
            80% { transform: translateY(-6px) scale(1.15); filter: brightness(1.2); }
            100% { transform: translateY(0) scale(1); filter: brightness(1); }
        }

        .dice-aura-glow-backdrop {
            position: absolute;
            width: 210px;
            height: 210px;
            border-radius: 50%;
            pointer-events: none;
            z-index: 1;
            transition: all 0.25s ease;
            filter: blur(calc(22px * var(--aura-blur-scale, 1)));
            background: radial-gradient(circle, var(--aura-glow-color, rgba(0, 229, 255, 0.85)) 0%, rgba(255, 255, 255, 0.35) 25%, var(--aura-glow-color, rgba(0, 229, 255, 0.55)) 48%, transparent 72%);
            opacity: var(--aura-opacity, 0.85);
        }

        /* Attached 3D Aura that lives inside the cube and spins/tumbles with it in 3D */
        .dice-attached-aura-glow {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 175px;
            height: 175px;
            margin-top: -87.5px;
            margin-left: -87.5px;
            border-radius: 50%;
            background: radial-gradient(circle, var(--aura-glow-color, rgba(0, 229, 255, 0.85)) 0%, rgba(255,255,255,0.3) 30%, transparent 70%);
            filter: blur(calc(16px * var(--aura-blur-scale, 1)));
            opacity: calc(var(--aura-opacity, 0.85) * 0.95);
            pointer-events: none;
            transform: translateZ(0);
            z-index: 0;
            transition: opacity 0.3s ease;
        }

        /* Remove the circular ring element completely as requested */
        .dice-aura-outer-ring {
            display: none !important;
        }

        /* Dynamic Aura Particles scattering around rolling dice */
        .dice-particles-container {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            pointer-events: none;
            z-index: 10;
        }

        .dice-aura-particle {
            position: absolute;
            border-radius: 50%;
            pointer-events: none;
            opacity: 0;
            will-change: transform, opacity;
            animation: auraParticleScatter 1.1s cubic-bezier(0.12, 0.8, 0.35, 1) forwards;
        }

        @keyframes auraParticleScatter {
            0% {
                transform: translate3d(0, 0, 0) scale(1.1);
                opacity: 1;
                filter: brightness(2);
            }
            35% {
                opacity: 1;
                filter: brightness(2.5);
            }
            75% {
                opacity: 0.85;
            }
            100% {
                transform: translate3d(var(--tx), var(--ty), var(--tz)) scale(0.1);
                opacity: 0;
            }
        }

        .dice-cube-3d {
            width: 110px;
            height: 110px;
            position: relative;
            transform-style: preserve-3d;
            transform: rotateX(-22deg) rotateY(32deg) rotateZ(0deg);
            transition: transform 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 3;
            cursor: grab;
            user-select: none;
        }

        .dice-cube-3d:active {
            cursor: grabbing;
        }

        .dice-cube-3d.is-rolling {
            animation: diceRollPhysics 1.25s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }

        @keyframes diceRollPhysics {
            0% { transform: rotateX(0deg) rotateY(0deg) rotateZ(0deg) scale(0.9); }
            20% { transform: rotateX(360deg) rotateY(540deg) rotateZ(180deg) scale(1.18) translateY(-45px); }
            55% { transform: rotateX(720deg) rotateY(900deg) rotateZ(360deg) scale(1.12) translateY(-20px); }
            80% { transform: rotateX(1000deg) rotateY(1260deg) rotateZ(600deg) scale(1.04) translateY(-5px); }
            100% { transform: var(--roll-target-transform, rotateX(-22deg) rotateY(32deg)); }
        }

        .dice-face-3d {
            position: absolute;
            width: 110px;
            height: 110px;
            background-color: var(--dice-body-color, #1e1b4b);
            background-image: var(--dice-skin-image, none);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            border: 2.5px solid rgba(255, 255, 255, 0.45);
            border-radius: 20px;
            box-shadow: inset 0 0 18px rgba(0,0,0,0.5), inset 0 0 8px rgba(255,255,255,0.3), 0 0 22px var(--aura-glow-color, rgba(0,229,255,0.4));
            display: grid;
            padding: 12px;
            box-sizing: border-box;
            backface-visibility: visible;
            transition: background 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .dice-cube-3d.has-texture-skin .dice-face-3d {
            background-blend-mode: overlay;
            border-color: rgba(255, 255, 255, 0.7);
            box-shadow: inset 0 0 20px rgba(0,0,0,0.65), 0 0 25px var(--aura-glow-color, rgba(0,229,255,0.5));
        }

        /* 🎲 Crystal Glass & Acrylic Shader for 3D Cube (เหมือนรูป 2 เป๊ะๆ) */
        .dice-cube-3d.style-crystal .dice-face-3d {
            background: radial-gradient(circle at 35% 30%, rgba(255,255,255,0.45) 0%, var(--dice-body-color, #dc2626) 42%, rgba(20,0,5,0.9) 100%) !important;
            border: 2px solid rgba(255, 255, 255, 0.75) !important;
            border-radius: 22px !important;
            box-shadow: inset 2px 2px 7px rgba(255,255,255,0.92), 
                        inset -3px -3px 9px rgba(0,0,0,0.7), 
                        0 0 25px var(--aura-glow-color, rgba(239,68,68,0.55)) !important;
        }

        .dice-cube-3d.style-crystal .dice-pip-dot {
            background: var(--dice-pip-color, #ffffff) !important;
            border-radius: 50% !important;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.45), 0 0 6px rgba(255,255,255,0.9) !important;
        }

        .dice-cube-3d.style-crystal .dice-pip-face-1 {
            width: 26px !important;
            height: 26px !important;
            background: var(--dice-pip-color, #ffffff) !important;
            border-radius: 50% !important;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.45), 0 0 10px rgba(255,255,255,0.95) !important;
        }

        .dice-image-showcase {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: diceShowcaseFloat 3s ease-in-out infinite;
        }
        @keyframes diceShowcaseFloat {
            0%, 100% { transform: translateY(0px) scale(0.98); }
            50% { transform: translateY(-5px) scale(1.02); }
        }
        .dice-image-showcase.is-rolling img {
            animation: diceImageRollPhysics 1.25s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }
        @keyframes diceImageRollPhysics {
            0% { transform: scale(0.9) rotate(0deg); }
            25% { transform: scale(1.2) rotate(360deg) translateY(-40px); }
            60% { transform: scale(1.1) rotate(720deg) translateY(-15px); }
            85% { transform: scale(1.03) rotate(1080deg) translateY(-5px); }
            100% { transform: scale(1) rotate(1440deg); }
        }

        .ai-variation-card {
            background: rgba(30,41,59,0.7);
            border: 1.5px solid rgba(255,255,255,0.12);
            border-radius: 10px;
            padding: 8px 10px;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            flex-direction: column;
            gap: 5px;
            text-align: left;
        }
        .ai-variation-card:hover {
            transform: translateY(-3px) scale(1.02);
            border-color: #a855f7;
            box-shadow: 0 4px 16px rgba(168,85,247,0.3);
            background: rgba(30,41,59,0.95);
        }
        .ai-variation-card.active {
            border-color: #00e5ff;
            box-shadow: 0 0 18px rgba(0,229,255,0.45);
            background: rgba(2,132,199,0.2);
        }

        .dice-shadow-card-preview {
            background: rgba(15,23,42,0.92);
            border-radius: 12px;
            padding: 10px 4px;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
            min-width: 0;
            width: 100%;
            overflow: hidden;
            box-sizing: border-box;
            position: relative;
        }
        .dice-shadow-card-preview:hover {
            transform: translateY(-2px);
        }

        /* 🔮 Shadow Dice & Wave Effect (เงาลูกเต๋าจางๆ + คลื่นเงา) */
        .dice-shadow-icon-wrap {
            position: relative;
            width: 62px;
            height: 62px;
            margin: 4px auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .shadow-wave-aura {
            position: absolute;
            inset: 2px;
            border-radius: 50%;
            background: radial-gradient(circle, var(--sw-glow, rgba(56,189,248,0.5)) 0%, transparent 72%);
            animation: shadowAuraBreathe 2.4s ease-in-out infinite;
            pointer-events: none;
            z-index: 1;
        }

        .shadow-wave-ring {
            position: absolute;
            inset: 4px;
            border-radius: 50%;
            border: 1.5px solid var(--sw-color, #38bdf8);
            pointer-events: none;
            z-index: 2;
            animation: shadowWavePulse 2.4s cubic-bezier(0.1, 0.7, 0.3, 1) infinite;
        }

        .shadow-wave-ring.r1 { animation-delay: 0s; }
        .shadow-wave-ring.r2 { animation-delay: 0.8s; }
        .shadow-wave-ring.r3 { animation-delay: 1.6s; }

        @keyframes shadowWavePulse {
            0% {
                transform: scale(0.65);
                opacity: 0.85;
                border-color: var(--sw-color, #38bdf8);
                box-shadow: 0 0 8px var(--sw-glow, rgba(56,189,248,0.6));
            }
            45% {
                opacity: 0.55;
            }
            100% {
                transform: scale(1.6);
                opacity: 0;
                border-color: transparent;
                box-shadow: 0 0 16px transparent;
            }
        }

        @keyframes shadowAuraBreathe {
            0%, 100% {
                opacity: 0.35;
                transform: scale(0.85);
            }
            50% {
                opacity: 0.85;
                transform: scale(1.2);
            }
        }

        .phantom-dice-core {
            position: relative;
            z-index: 5;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: shadowDiceFloat 3s ease-in-out infinite;
            transition: all 0.3s ease;
        }

        @keyframes shadowDiceFloat {
            0%, 100% {
                transform: translateY(0px) scale(0.97);
            }
            50% {
                transform: translateY(-3px) scale(1.03);
            }
        }

        .phantom-shadow-dice-svg {
            transition: all 0.25s ease;
        }

        .dice-shadow-card-preview:hover .phantom-shadow-dice-svg {
            transform: scale(1.1) rotate(4deg);
            filter: drop-shadow(0 0 12px var(--sw-color)) !important;
        }

        .phantom-skin-image-box {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
            border: 1.5px solid var(--sw-color);
            box-shadow: 0 0 10px var(--sw-glow);
            background: rgba(0,0,0,0.5);
            opacity: 0.72;
            transition: all 0.2s ease;
        }

        .phantom-skin-image-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: brightness(0.85) contrast(1.1);
            opacity: 0.75;
        }

        .phantom-skin-image-box .skin-color-veil {
            position: absolute;
            inset: 0;
            background: var(--sw-glow);
            mix-blend-mode: screen;
            pointer-events: none;
        }

        /* 3D Face coordinates for 110px cube (half size = 55px) */
        .face-val-1 { transform: rotateY(0deg) translateZ(55px); grid-template: 1fr / 1fr; place-items: center; }
        .face-val-6 { transform: rotateX(180deg) translateZ(55px); grid-template: repeat(3, 1fr) / repeat(2, 1fr); place-items: center; }
        .face-val-2 { transform: rotateY(90deg) translateZ(55px); grid-template: repeat(2, 1fr) / repeat(2, 1fr); }
        .face-val-5 { transform: rotateY(-90deg) translateZ(55px); grid-template: repeat(3, 1fr) / repeat(3, 1fr); }
        .face-val-3 { transform: rotateX(90deg) translateZ(55px); grid-template: repeat(3, 1fr) / repeat(3, 1fr); }
        .face-val-4 { transform: rotateX(-90deg) translateZ(55px); grid-template: repeat(2, 1fr) / repeat(2, 1fr); }

        .dice-pip-dot {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: var(--dice-pip-color, #ffffff);
            box-shadow: 0 0 8px rgba(0,0,0,0.45), inset 0 1px 2px rgba(255,255,255,0.85);
            margin: auto;
            transition: background 0.3s ease;
        }

        .dice-pip-face-1 {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: var(--dice-pip-color, #ffffff);
            box-shadow: 0 0 10px rgba(0,0,0,0.45), inset 0 1px 2px rgba(255,255,255,0.85);
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .dice-pip-face-1.has-custom-img {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            border: 2px solid rgba(255,255,255,0.8);
            box-shadow: 0 0 14px var(--aura-glow-color, #00e5ff);
            overflow: hidden;
        }

        /* Specific Pip Dot Placements */
        .face-val-2 .dice-pip-dot:nth-child(1) { grid-area: 1 / 1; }
        .face-val-2 .dice-pip-dot:nth-child(2) { grid-area: 2 / 2; }

        .face-val-3 .dice-pip-dot:nth-child(1) { grid-area: 1 / 1; }
        .face-val-3 .dice-pip-dot:nth-child(2) { grid-area: 2 / 2; }
        .face-val-3 .dice-pip-dot:nth-child(3) { grid-area: 3 / 3; }

        .face-val-4 .dice-pip-dot:nth-child(1) { grid-area: 1 / 1; }
        .face-val-4 .dice-pip-dot:nth-child(2) { grid-area: 1 / 2; }
        .face-val-4 .dice-pip-dot:nth-child(3) { grid-area: 2 / 1; }
        .face-val-4 .dice-pip-dot:nth-child(4) { grid-area: 2 / 2; }

        .face-val-5 .dice-pip-dot:nth-child(1) { grid-area: 1 / 1; }
        .face-val-5 .dice-pip-dot:nth-child(2) { grid-area: 1 / 3; }
        .face-val-5 .dice-pip-dot:nth-child(3) { grid-area: 2 / 2; }
        .face-val-5 .dice-pip-dot:nth-child(4) { grid-area: 3 / 1; }
        .face-val-5 .dice-pip-dot:nth-child(5) { grid-area: 3 / 3; }

        .face-val-6 .dice-pip-dot:nth-child(1) { grid-area: 1 / 1; }
        .face-val-6 .dice-pip-dot:nth-child(2) { grid-area: 1 / 2; }
        .face-val-6 .dice-pip-dot:nth-child(3) { grid-area: 2 / 1; }
        .face-val-6 .dice-pip-dot:nth-child(4) { grid-area: 2 / 2; }
        .face-val-6 .dice-pip-dot:nth-child(5) { grid-area: 3 / 1; }
        .face-val-6 .dice-pip-dot:nth-child(6) { grid-area: 3 / 2; }

        /* Aura FX Animations */
        .dice-fx-pulse_breathe {
            animation: diceFxPulse 2s ease-in-out infinite;
        }
        @keyframes diceFxPulse {
            0%, 100% { transform: scale(1); opacity: var(--aura-opacity, 0.8); }
            50% { transform: scale(1.22); opacity: calc(var(--aura-opacity, 0.8) * 1.25); }
        }

        .dice-fx-rotate_spin {
            animation: diceFxSpin 5s linear infinite;
        }
        @keyframes diceFxSpin {
            0% { transform: rotate(0deg) scale(1); }
            50% { transform: rotate(180deg) scale(1.15); }
            100% { transform: rotate(360deg) scale(1); }
        }

        .dice-fx-dual_ring {
            animation: diceFxDualRing 4s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
        @keyframes diceFxDualRing {
            0% { transform: rotate(0deg) scale(1); }
            50% { transform: rotate(180deg) scale(1.25); }
            100% { transform: rotate(360deg) scale(1); }
        }

        .dice-fx-solar_flare {
            animation: diceFxSolar 1.8s ease-in-out infinite alternate;
        }
        @keyframes diceFxSolar {
            0% { transform: scale(0.95); filter: brightness(1) blur(calc(15px * var(--aura-blur-scale, 1))); }
            50% { transform: scale(1.35); filter: brightness(1.7) blur(calc(30px * var(--aura-blur-scale, 1))); }
            100% { transform: scale(1.15); filter: brightness(1.3) blur(calc(22px * var(--aura-blur-scale, 1))); }
        }

        .dice-fx-lightning_spark {
            animation: diceFxLightning 0.8s steps(2, start) infinite;
        }
        @keyframes diceFxLightning {
            0%, 100% { opacity: 0.6; filter: brightness(1); }
            25% { opacity: 1; filter: brightness(2.2); transform: scale(1.2); }
            50% { opacity: 0.4; }
            75% { opacity: 1; filter: brightness(2.5); transform: scale(1.25); }
        }

        .dice-fx-cosmic_hyper {
            animation: diceFxCosmic 3s linear infinite;
        }
        @keyframes diceFxCosmic {
            0% { transform: rotate(0deg) scale(1); filter: hue-rotate(0deg) brightness(1.1); }
            50% { transform: rotate(180deg) scale(1.3); filter: hue-rotate(180deg) brightness(1.5); }
            100% { transform: rotate(360deg) scale(1); filter: hue-rotate(360deg) brightness(1.1); }
        }

        /* Grade Badges */
        .grade-badge-pill {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 6px;
            font-weight: 800;
            font-size: 13px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.25);
        }
        .grade-pill-click {
            cursor: pointer;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 800;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            color: #cbd5e1;
            transition: all 0.2s;
        }
        .grade-pill-click:hover {
            transform: translateY(-2px);
            border-color: #00e5ff;
            color: #fff;
            box-shadow: 0 0 10px rgba(0,229,255,0.4);
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- 🧭 SLEEK LEFT SIDEBAR -->
        <aside class="admin-sidebar" id="admin-sidebar">
            <!-- Sidebar Header -->
            <div class="sidebar-header">
                <span class="sidebar-logo-icon">🎲</span>
                <div>
                    <div class="sidebar-logo-text">Snake & Ladder 3D</div>
                    <div class="sidebar-logo-sub">Admin Control Studio</div>
                </div>
            </div>

            <!-- Sidebar Navigation Menu -->
            <nav class="sidebar-menu">
                <div class="sidebar-section-title">📊 ภาพรวม & แดชบอร์ด</div>
                <a href="../admin_dashboard.php" class="sidebar-tab-btn" style="border-color: rgba(16,185,129,0.35); background: rgba(16,185,129,0.1); color: #34d399;">
                    <span class="btn-icon">🚀</span>
                    <span class="btn-text">แดชบอร์ดคำสั่งซื้อ & OTA</span>
                    <span class="btn-badge" style="background:#10b981; color:#000;">ใหม่</span>
                </a>
                <a href="../admin_dashboard.php#tab-icon" onclick="localStorage.setItem('admin_default_tab', 'tab-icon');" class="sidebar-tab-btn" style="border-color: rgba(0,229,255,0.35); background: rgba(0,229,255,0.1); color: #00e5ff;">
                    <span class="btn-icon">📱</span>
                    <span class="btn-text">จัดการไอคอนแอป iOS &amp; Web</span>
                    <span class="btn-badge" style="background:#00e5ff; color:#000;">1024px</span>
                </a>
                <button type="button" class="sidebar-tab-btn active" data-tab="events" onclick="switchTab('events')">
                    <span class="btn-icon">🎁</span>
                    <span class="btn-text">กิจกรรมแจกเพชร & ทอง</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="ranking_settings" onclick="switchTab('ranking_settings')">
                    <span class="btn-icon">🏆</span>
                    <span class="btn-text">จัดอันดับ & รีเซ็ตสัปดาห์</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="magic_cubes" onclick="switchTab('magic_cubes')">
                    <span class="btn-icon">🧊</span>
                    <span class="btn-text">หมุนลูกบาศก์ Magic Cube</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="broadcast" onclick="switchTab('broadcast')">
                    <span class="btn-icon">📢</span>
                    <span class="btn-text">ยิงของรางวัลทั้งเซิร์ฟ</span>
                </button>

                <div class="sidebar-section-title">🎨 AI & สตูดิโอ 3D</div>
                <button type="button" class="sidebar-tab-btn" id="btn-tab-board-studio" data-tab="board_studio" onclick="switchTab('board_studio')" style="border-color: rgba(16,185,129,0.5); background: rgba(16,185,129,0.12); color:#34d399;">
                    <span class="btn-icon">🗺️</span>
                    <span class="btn-text">AI สร้างกระดาน 3D & เมือง</span>
                    <span class="btn-badge" style="background:linear-gradient(135deg,#10b981,#06b6d4); color:#000;">AI 3D</span>
                </button>
                <button type="button" class="sidebar-tab-btn" id="btn-tab-dice-creator" data-tab="dice_creator" onclick="switchTab('dice_creator')" style="border-color: rgba(168,85,247,0.35); color:#d8b4fe;">
                    <span class="btn-icon">🎲</span>
                    <span class="btn-text">AI ลูกเต๋า 3D & ทอยจำลอง</span>
                    <span class="btn-badge" style="background:#a855f7; color:#fff;">3D</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="ai_creator" onclick="switchTab('ai_creator')" style="border-color: rgba(6,182,212,0.35); color:#67e8f9;">
                    <span class="btn-icon">🤖</span>
                    <span class="btn-text">AI สร้างกรอบรูปตัวละคร</span>
                    <span class="btn-badge" style="background:#06b6d4; color:#000;">AI</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="frames" onclick="switchTab('frames')">
                    <span class="btn-icon">👑</span>
                    <span class="btn-text">จัดการกรอบรูป & การ์ด 5 ใบ</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="thai_audio" onclick="switchTab('thai_audio')" style="border-color: rgba(236,72,153,0.35); color:#f472b6;">
                    <span class="btn-icon">🎵</span>
                    <span class="btn-text">ระบบเสียง & พากย์ไทย</span>
                    <span class="btn-badge" style="background:#ec4899; color:#fff;">ใหม่</span>
                </button>

                <div class="sidebar-section-title">💰 ระบบร้านค้า & ค่าพลัง</div>
                <button type="button" class="sidebar-tab-btn" data-tab="shop_menus" onclick="switchTab('shop_menus')" style="border-color: rgba(250,204,21,0.45); background: rgba(250,204,21,0.08); color: #fde047;">
                    <span class="btn-icon">🏪</span>
                    <span class="btn-text">จัดการเมนูร้านค้า & สินค้า</span>
                    <span class="btn-badge" style="background:linear-gradient(135deg,#facc15,#f59e0b); color:#000;">ใหม่</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="room_economy" onclick="switchTab('room_economy')">
                    <span class="btn-icon">🏙️</span>
                    <span class="btn-text">ห้องแข่ง & เมือง/แลนด์มาร์ค</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="sell_prices" onclick="switchTab('sell_prices')">
                    <span class="btn-icon">💰</span>
                    <span class="btn-text">ตั้งค่าการขายไอเทม</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="packages" onclick="switchTab('packages')">
                    <span class="btn-icon">💎</span>
                    <span class="btn-text">แพ็กเกจเติมเพชร/ทอง</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="skills" onclick="switchTab('skills')">
                    <span class="btn-icon">⚡</span>
                    <span class="btn-text">สกิลตัวละคร & ลูกเต๋า</span>
                </button>

                <div class="sidebar-section-title">⚙️ ระบบ & ผู้ใช้งาน</div>
                <button type="button" class="sidebar-tab-btn" data-tab="mobile_app" onclick="switchTab('mobile_app')">
                    <span class="btn-icon">📱</span>
                    <span class="btn-text">แอปมือถือ & แคชเซิร์ฟ</span>
                </button>
                <button type="button" class="sidebar-tab-btn" data-tab="users" onclick="switchTab('users')">
                    <span class="btn-icon">👥</span>
                    <span class="btn-text">จัดการข้อมูลผู้เล่น</span>
                </button>
                <button type="button" class="sidebar-tab-btn" id="btn-tab-admin-account" data-tab="admin_account" onclick="switchTab('admin_account')">
                    <span class="btn-icon">🔐</span>
                    <span class="btn-text">บัญชี Admin / รหัสผ่าน</span>
                </button>
            </nav>

            <!-- Sidebar Footer -->
            <div class="sidebar-footer">
                <div style="display:flex; align-items:center; gap:8px; min-width:0; flex:1;">
                    <img id="sidebar-admin-avatar" src="<?= htmlspecialchars($currentAdmin['avatar_url'] ?: '../avatars/avatar_01.png') ?>" style="width:32px; height:32px; border-radius:50%; object-fit:cover; border:1.5px solid var(--primary); background:#1e293b; flex-shrink:0;">
                    <div style="min-width:0; flex:1;">
                        <div style="font-size:12px; font-weight:700; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                            <?= htmlspecialchars($currentAdmin['display_name']) ?>
                        </div>
                        <div style="font-size:10px; color:#94a3b8;">
                            @<?= htmlspecialchars($currentAdmin['username']) ?>
                        </div>
                    </div>
                </div>
                <a href="admin_panel.php?action=logout" title="ออกจากระบบ" style="padding:6px 10px; background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.4); border-radius:8px; color:#ef4444; font-size:12px; text-decoration:none; font-weight:700;">
                    🚪
                </a>
            </div>
        </aside>

        <!-- 🖥️ MAIN WRAPPER (RIGHT SIDE) -->
        <div class="admin-main-wrapper">
            <header class="header">
                <h1>🎲 Snake & Ladder 3D - Admin Panel</h1>
                <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                    <span class="stats-badge">👥 ผู้เล่นทั้งหมด: <?= number_format((int)$userCount) ?> คน</span>
                    <button class="btn btn-accent" style="padding: 7px 14px; font-size: 13px;" onclick="switchTab('admin_account')">
                        🔐 แก้ไขข้อมูล / เปลี่ยนรหัสผ่าน
                    </button>
                    <a href="../index.html" class="btn" style="padding: 7px 14px; font-size: 13px; text-decoration: none; background: #334155; color: #fff;">
                        🎮 หน้าเกม
                    </a>
                    <a href="admin_panel.php?action=logout" class="btn btn-danger" style="padding: 7px 14px; font-size: 13px; text-decoration: none;">
                        🚪 ออกจากระบบ
                    </a>
                </div>
            </header>

            <main class="admin-content-area">

    
    <!-- TAB: FRAMES & GACHA EVENT MANAGEMENT -->
    <div id="tab-frames" class="tab-content">

        <!-- 🎯 ACTIVE EVENTS & LIVE CAMPAIGNS OVERVIEW -->
        <div class="card" id="card-active-events-overview" style="margin-bottom: 24px; background: linear-gradient(135deg, rgba(15,23,42,0.96) 0%, rgba(30,41,59,0.92) 100%); border: 2px solid #38bdf8; border-radius: 16px; box-shadow: 0 12px 35px rgba(0,0,0,0.6), 0 0 25px rgba(56,189,248,0.22); padding: 22px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid rgba(56,189,248,0.3); padding-bottom:14px; margin-bottom:18px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="font-size:32px; filter:drop-shadow(0 0 10px rgba(56,189,248,0.6));">🎯</span>
                    <div>
                        <h2 style="margin:0; border:none; padding:0; color:#38bdf8; font-size:20px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                            <span>กิจกรรมที่กำลังดำเนินการอยู่ในช่วงเวลานี้ (Active Events & Live Campaigns)</span>
                            <span id="badge-live-events-count" style="background:#10b981; color:#fff; font-size:12px; font-weight:800; padding:3px 12px; border-radius:20px; box-shadow:0 0 10px rgba(16,185,129,0.5);">กำลังเปิดกิจกรรม</span>
                        </h2>
                        <div style="font-size:12px; color:#94a3b8; margin-top:4px;">
                            สรุปภาพรวมกิจกรรมทั้งหมดที่เปิดให้ผู้เล่นร่วมสนุกในเซิร์ฟเวอร์แบบเรียลไทม์ พร้อมตัวนับเวลาถอยหลังและตั้งค่าด่วน
                        </div>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                    <button type="button" class="btn" style="padding:8px 14px; font-size:13px; background:rgba(56,189,248,0.15); border:1px solid #38bdf8; color:#38bdf8; font-weight:700;" onclick="loadAdminFrames()">
                        🔄 รีเฟรชสถานะสด
                    </button>
                    <button type="button" class="btn btn-accent" style="padding:8px 16px; font-size:13px; font-weight:700;" onclick="scrollToGachaSetupForm()">
                        ⚙️ ตั้งค่ากิจกรรมสุ่มการ์ด
                    </button>
                </div>
            </div>

            <!-- Dynamic Active Events Container (populated by renderActiveEventsOverview) -->
            <div id="active-events-overview-container">
                <div style="text-align:center; padding:24px; color:#94a3b8;">
                    ⏳ กำลังโหลดสรุปกิจกรรมที่กำลังดำเนินการอยู่ในช่วงเวลานี้...
                </div>
            </div>
        </div>

        <div class="card" style="margin-bottom: 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:14px;">
                <h2 style="margin:0; border:none; padding:0;">👑 จัดการกรอบรูปโปรไฟล์ & ปรับแต่งอัตราสถิติ (Win Rate / Roll / Skill)</h2>
                <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                    <label style="display:inline-flex; align-items:center; gap:8px; margin:0; background:rgba(6,182,212,0.12); border:1px solid var(--primary); padding:7px 14px; border-radius:8px; color:#fff; cursor:pointer; font-weight:600;">
                        <input type="checkbox" id="chk-toolbar-select-all" checked onchange="toggleSelectAllFrames(this.checked)" style="width:18px; height:18px; cursor:pointer;">
                        <span>เลือกทั้งหมด (<span id="selected-frames-count">0</span>)</span>
                    </label>
                    <button type="button" class="btn btn-accent btn-save-all-frames" style="padding:8px 16px; font-size:14px; font-weight:700;" onclick="saveSelectedFrames()">
                        💾 บันทึกทั้งหมด (ที่เลือก)
                    </button>
                    <button type="button" class="btn" style="padding:8px 14px; font-size:13px;" onclick="switchTab('ai_creator')">
                        🤖 ไปหน้า AI สร้างกรอบรูป
                    </button>
                </div>
            </div>
            <p style="color:var(--text-muted); font-size:13px; margin-bottom: 16px;">
                ตั้งค่ากรอบรูปโปรไฟล์ ปรับอัตราชนะ อัตราการทอยเต๋า อัตราการเล่นเก่ง และแสงเออร่าประจำแต่ละเกรด (กรอบรูปทั้งหมดรับได้จาก <strong>การเปิดแพ็คการ์ดสุ่ม 5 ใบ & สะสมการ์ดเงา 5 สีแลกรับ</strong> ไม่ขายตรงด้วยเพชร):
                <br>• <strong>เกรด A</strong>: ไม่มีแสงเออร่า
                • <strong>เกรด A+</strong>: แสงเออร่าสีขาวนิดๆ
                • <strong>เกรด S</strong>: แสงเออร่าสีฟ้านิดๆ
                • <strong>เกรด S+</strong>: แสงเออร่าสีเหลือง แบบเต็มๆ
                • <strong>เกรด SS+</strong>: แสงเออร่าสีทองแบบสง่าสวยๆ เด่นๆ หรือ <strong>สีส้มเพลิง</strong> (ปรับระดับแสงได้ 10% - 500%)
            </p>

            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="width:70px; text-align:center;">
                                <label style="display:inline-flex; align-items:center; gap:5px; margin:0; cursor:pointer; color:#38bdf8; font-size:12px;">
                                    <input type="checkbox" id="chk-select-all-frames" checked onchange="toggleSelectAllFrames(this.checked)" style="width:17px; height:17px; cursor:pointer;">
                                    <span>ทั้งหมด</span>
                                </label>
                            </th>
                            <th>พรีวิว & แสงเออร่า</th>
                            <th>ชื่อกรอบรูป</th>
                            <th>เกรด</th>
                            <th>🏆 อัตราชนะ (%)</th>
                            <th>🎲 อัตราทอย/คุมเต๋า (%)</th>
                            <th>⚡ อัตราเล่นเก่ง (ฝีมือ)</th>
                            <th>เออร่า</th>
                            <th>🔥 ระดับแสง (%)</th>
                            <th>✨ ลูกเล่น (FX)</th>
                            <th>วิธีได้รับ (กิจกรรมสุ่มการ์ด)</th>
                            <th>สถานะ</th>
                            <th style="white-space:nowrap; text-align:right;">
                                <div style="display:inline-flex; align-items:center; gap:8px; justify-content:flex-end;">
                                    <label style="display:inline-flex; align-items:center; gap:5px; margin:0; cursor:pointer; color:#38bdf8; font-size:12px; background:rgba(56,189,248,0.12); border:1px solid rgba(56,189,248,0.4); padding:4px 8px; border-radius:6px;">
                                        <input type="checkbox" id="chk-right-select-all-frames" checked onchange="toggleSelectAllFrames(this.checked)" style="width:16px; height:16px; cursor:pointer;">
                                        <span>เลือกทั้งหมด</span>
                                    </label>
                                    <button type="button" class="btn btn-accent btn-save-all-frames" style="padding:5px 12px; font-size:12px; font-weight:700;" onclick="saveSelectedFrames()">💾 บันทึกทั้งหมด</button>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody id="admin-frames-tbody">
                        <tr><td colspan="13" style="text-align:center; padding:20px;">กำลังโหลดข้อมูลกรอบรูป...</td></tr>
                    </tbody>
                </table>
            </div>
            <div style="display:flex; justify-content:flex-end; align-items:center; gap:10px; flex-wrap:wrap; margin-top:12px; padding-top:10px; border-top:1px dashed rgba(148,163,184,0.2);">
                <label style="display:inline-flex; align-items:center; gap:8px; margin:0; background:rgba(6,182,212,0.12); border:1px solid var(--primary); padding:7px 14px; border-radius:8px; color:#fff; cursor:pointer; font-weight:600; font-size:13px;">
                    <input type="checkbox" id="chk-bottom-select-all" checked onchange="toggleSelectAllFrames(this.checked)" style="width:17px; height:17px; cursor:pointer;">
                    <span>เลือกทั้งหมด (<span id="selected-frames-count-bottom">0</span> รายการ)</span>
                </label>
                <button type="button" class="btn btn-accent btn-save-all-frames" style="padding:8px 18px; font-size:14px; font-weight:700;" onclick="saveSelectedFrames()">
                    💾 บันทึกทั้งหมด (ที่เลือก)
                </button>
            </div>

            <!-- Add new frame form -->
            <div style="margin-top: 24px; padding-top: 18px; border-top: 1px solid var(--panel-border);">
                <h3 style="color:var(--primary); font-size:15px; margin-bottom:12px;">➕ เพิ่มกรอบรูปใหม่สำหรับกิจกรรมสุ่มแพ็คการ์ด (เช่น เกรด S+ หรือ SS+)</h3>
                <form id="createFrameForm" onsubmit="submitCreateFrame(event)" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:12px; align-items:end;">
                    <div>
                        <label>ชื่อกรอบรูป *</label>
                        <input type="text" id="new_frame_name" placeholder="เช่น พญานาคราช S+" required>
                    </div>
                    <div>
                        <label>เกรด *</label>
                        <select id="new_frame_grade" onchange="autoSelectAura(this.value)">
                            <option value="A">A (ไม่มีเออร่า)</option>
                            <option value="A+">A+ (สีขาวนิดๆ)</option>
                            <option value="S">S (สีฟ้านิดๆ)</option>
                            <option value="S+" selected>S+ (สีเหลืองเต็มๆ - รางวัลแลกเงา)</option>
                            <option value="SS+">SS+ (สีทองสง่างาม)</option>
                        </select>
                    </div>
                    <div>
                        <label>🏆 อัตราชนะ (%)</label>
                        <input type="number" id="new_frame_win" value="55" min="0" max="100" step="0.5">
                    </div>
                    <div>
                        <label>🎲 อัตราการทอย (%)</label>
                        <input type="number" id="new_frame_roll" value="65" min="0" max="100" step="0.5">
                    </div>
                    <div>
                        <label>⚡ อัตราเล่นเก่ง</label>
                        <input type="number" id="new_frame_skill" value="30" min="0" max="100" step="1">
                    </div>
                    <div>
                        <label>แสงเออร่า</label>
                        <select id="new_frame_aura">
                            <option value="none">none (ไม่มีเออร่า)</option>
                            <option value="white">white (สีขาวนิดๆ)</option>
                            <option value="cyan">cyan (สีฟ้านิดๆ)</option>
                            <option value="yellow" selected>yellow (สีเหลืองเต็มๆ)</option>
                            <option value="gold">gold (สีทองสง่างาม)</option>
                            <option value="orange">orange (สีส้มเพลิงร้อนแรง 🔥)</option>
                        </select>
                    </div>
                    <div>
                        <label>🔥 ระดับแสงเออร่า (10% - 500%)</label>
                        <input type="number" id="new_frame_intensity" value="100" min="10" max="500" step="5">
                    </div>
                    <div>
                        <label>รูปแบบรับไอเทม (ไม่ขายเพชรตรง)</label>
                        <select id="new_frame_set_target" style="border-color:#ffd700; color:#ffd700;">
                            <option value="1" selected>🌟 ตั้งเป็นเป้าหมายแลกการ์ดเงาทันที</option>
                            <option value="0">🎴 เก็บไว้จัดกิจกรรมสุ่มรอบถัดไป</option>
                        </select>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-accent" style="width:100%; padding:10px;">➕ สร้างกรอบกิจกรรมใหม่</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Frame Gacha Event Setup -->
        <div class="card">
            <h2>🎰 จัดกิจกรรมสุ่มแพ็คการ์ดกรอบรูป (Card Pack Gacha & Shadow Exchange Event)</h2>
            <p style="color:var(--text-muted); font-size:13px; margin-bottom: 16px;">
                ตั้งค่ากิจกรรมเปิดให้ผู้เล่นใช้เพชรเปิดแพ็คการ์ด 5 ใบ เพื่อสะสมการ์ดเงา 5 สีแลกรับกรอบรูปเป้าหมายระดับ S+:
            </p>
            <form id="frameGachaEventForm" onsubmit="submitSaveFrameGacha(event)">
                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>ชื่อกิจกรรมสุ่มกรอบรูป *</label>
                        <input type="text" id="ev_frame_name" value="🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+" required>
                    </div>
                    <div class="form-group">
                        <label>จำนวนเพชรที่ใช้เปิดแพ็ค (Diamond Cost เช่น 100 หรือ 200 เพชร) *</label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="number" id="ev_frame_cost" value="100" min="1" required style="flex:1;">
                            <button type="button" class="btn" style="padding:10px 14px; font-size:13px; white-space:nowrap;" onclick="document.getElementById('ev_frame_cost').value=100;">💎 100 เพชร</button>
                            <button type="button" class="btn btn-accent" style="padding:10px 14px; font-size:13px; white-space:nowrap;" onclick="document.getElementById('ev_frame_cost').value=200;">💎 200 เพชร</button>
                        </div>
                    </div>
                </div>

                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>จำนวนการ์ดที่สุ่มเปิดต่อ 1 แพ็ค (Cards Per Pack) *</label>
                        <input type="number" id="ev_cards_per_pack" value="5" min="1" max="20" required>
                    </div>
                    <div class="form-group">
                        <label>👑 กรอบรูปเป้าหมายที่ได้รับจากการสะสมแลก (Target Frame) *</label>
                        <select id="ev_target_char_id" style="border-color:#ffd700; color:#ffd700; font-weight:700;">
                            <option value="1">กำลังโหลดรายการกรอบรูป...</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>อัตราเพิ่มโอกาสได้รับเป้าหมายเรตอัป (Rate-Up Boost %)</label>
                    <div style="display:flex; gap:8px; align-items:center;">
                        <input type="number" id="ev_rate_target_boost" value="35.0" step="0.5" min="1" max="100" style="flex:1;">
                        <span style="font-size:12px; color:var(--text-muted);">เช่น +35% ให้เป้าหมายออกง่ายขึ้น</span>
                    </div>
                </div>

                <div class="form-group">
                    <label>คำอธิบายกิจกรรม / ไฮไลต์รางวัล</label>
                    <textarea id="ev_frame_desc" rows="2">เปิดแพ็คสุ่มการ์ด 1 แพ็ค ได้รับการ์ด 5 ใบ สะสมการ์ดเงาครบ 5 สี แลกรับกรอบรูปตัวละครระดับ S+ ไปสวมใส่และอัพเลเวล 1-30 ได้ทันที</textarea>
                </div>

                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>วันที่เริ่มต้นกิจกรรม</label>
                        <input type="datetime-local" id="ev_frame_start">
                    </div>
                    <div class="form-group">
                        <label>วันที่สิ้นสุดกิจกรรม</label>
                        <input type="datetime-local" id="ev_frame_end">
                    </div>
                </div>

                <h3 style="color:var(--accent); font-size:14px; margin: 16px 0 10px 0;">🎯 กำหนดอัตราการออก (%) และจำนวนใบที่ต้องใช้สะสมแลกของการ์ดเงาทั้ง 5 สี:</h3>
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); gap:12px; margin-bottom: 16px;">
                    <!-- 1. Black -->
                    <div style="background:rgba(100,116,139,0.12); border:1px solid #94a3b8; border-radius:8px; padding:10px;">
                        <label style="color:#cbd5e1; font-weight:700;">⬛ เงาสีดำ (เกรด A)</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#94a3b8;">% ออก:</span>
                                <input type="number" id="ev_rate_black" value="90.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#94a3b8;">ต้องใช้:</span>
                                <input type="number" id="ev_req_black" value="15" min="1" max="100">
                            </div>
                        </div>
                    </div>

                    <!-- 2. Red -->
                    <div style="background:rgba(239,68,68,0.12); border:1px solid #ef4444; border-radius:8px; padding:10px;">
                        <label style="color:#ef4444; font-weight:700;">🟥 เงาสีแดง (เกรด A)</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#fca5a5;">% ออก:</span>
                                <input type="number" id="ev_rate_red" value="80.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#fca5a5;">ต้องใช้:</span>
                                <input type="number" id="ev_req_red" value="15" min="1" max="100">
                            </div>
                        </div>
                    </div>

                    <!-- 3. Orange -->
                    <div style="background:rgba(255,136,0,0.12); border:1px solid #ff8800; border-radius:8px; padding:10px;">
                        <label style="color:#ff8800; font-weight:700;">🟧 เงาสีส้ม (เกรด A)</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#fdba74;">% ออก:</span>
                                <input type="number" id="ev_rate_orange" value="70.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#fdba74;">ต้องใช้:</span>
                                <input type="number" id="ev_req_orange" value="15" min="1" max="100">
                            </div>
                        </div>
                    </div>

                    <!-- 4. Blue -->
                    <div style="background:rgba(56,189,248,0.12); border:1px solid #38bdf8; border-radius:8px; padding:10px;">
                        <label style="color:#38bdf8; font-weight:700;">🟦 เงาสีฟ้า (เกรด A+)</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#bae6fd;">% ออก:</span>
                                <input type="number" id="ev_rate_blue" value="50.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#bae6fd;">ต้องใช้:</span>
                                <input type="number" id="ev_req_blue" value="10" min="1" max="100">
                            </div>
                        </div>
                    </div>

                    <!-- 5. Gold -->
                    <div style="background:rgba(255,215,0,0.12); border:1px solid #ffd700; border-radius:8px; padding:10px;">
                        <label style="color:#ffd700; font-weight:700;">🟨 เงาสีทอง (เกรด S)</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#fef08a;">% ออก:</span>
                                <input type="number" id="ev_rate_gold" value="10.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#fef08a;">ต้องใช้:</span>
                                <input type="number" id="ev_req_gold" value="4" min="1" max="100">
                            </div>
                        </div>
                    </div>

                    <!-- Jackpot S+ & Special -->
                    <div style="background:rgba(168,85,247,0.12); border:1px solid #a855f7; border-radius:8px; padding:10px;">
                        <label style="color:#a855f7; font-weight:700;">👑 แจ็คพอต & การ์ดพิเศษ</label>
                        <div style="display:flex; gap:6px; margin-top:4px;">
                            <div>
                                <span style="font-size:11px; color:#e9d5ff;">% แจ็คพอต S+:</span>
                                <input type="number" id="ev_rate_splus" value="3.0" step="0.1" min="0" max="100">
                            </div>
                            <div>
                                <span style="font-size:11px; color:#e9d5ff;">% การ์ดพิเศษ:</span>
                                <input type="number" id="ev_rate_special" value="15.0" step="0.1" min="0" max="100">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group" style="display:flex; align-items:center; gap:10px;">
                    <input type="checkbox" id="ev_frame_active" checked style="width:20px; height:20px;">
                    <label for="ev_frame_active" style="margin:0; font-size:14px; color:#fff; cursor:pointer;">เปิดใช้งานกิจกรรมสุ่มการ์ดแพ็คนี้ทันที (Active)</label>
                </div>

                <button type="submit" class="btn btn-accent" style="width:100%; padding:12px; font-size:15px;">💾 บันทึกและเปิดจัดกิจกรรมสุ่มแพ็คการ์ด 5 ใบ</button>
            </form>
        </div>
    </div>

    <!-- TAB: AI FRAME CREATOR & STUDIO -->

    <div id="tab-ai_creator" class="tab-content">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">🤖 ระบบ AI สร้าง & แก้ไขกรอบรูปวงแหวน + แสงเออร่า & ลูกเล่นพิเศษ (AI Frame Studio)</h2>
                    <p style="color:var(--text-muted); font-size:13px; margin-top:4px; margin-bottom:0;">
                        อัปโหลดรูปกรอบวงกลม ระบบ AI จะ <strong>ตัดพื้นหลังตารางหมากรุก/สีพื้น + เจาะรูโปร่งใสตรงกลางอัตโนมัติ</strong> เพื่อแสดงเฉพาะ <strong>ส่วนของกรอบวงแหวน</strong> รอบขอบโปรไฟล์ (ไม่บังรูปตรงกลาง) พร้อมปรับแต่งแสงเออร่าและลูกเล่นแอนิเมชันได้ทั้งสร้างใหม่และแก้ไขกรอบเดิม
                    </p>
                </div>
                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <select id="ai_edit_existing_select" onchange="loadFrameIntoAiStudio(this.value)" style="width:270px; border-color:#38bdf8; color:#38bdf8; font-weight:700;">
                        <option value="0">➕ โหมด: สร้างกรอบรูปใหม่ด้วย AI</option>
                    </select>
                    <button type="button" class="btn" style="padding:8px 12px; font-size:12px; background:#334155; color:#fff;" onclick="resetAiStudioToNew()">
                        🔄 ล้างค่า/สร้างใหม่
                    </button>
                </div>
            </div>

            <div class="grid-2" style="gap: 24px; align-items: start;">
                <!-- Left: Upload & AI Controls Form -->
                <div>
                    <!-- Drop Zone -->
                    <div id="ai_dropzone" onclick="document.getElementById('ai_image_input').click()" 
                        style="border: 2px dashed var(--primary); border-radius: 12px; padding: 22px 16px; text-align: center; background: rgba(6,182,212,0.05); cursor: pointer; transition: 0.2s; margin-bottom: 14px;">
                        <input type="file" id="ai_image_input" accept="image/*" style="display:none;" onchange="handleAiImageSelect(event)">
                        <div style="font-size: 34px; margin-bottom: 6px;">⭕</div>
                        <div style="font-size: 15px; font-weight: 700; color: var(--primary);">คลิกเพื่ออัปโหลดรูปกรอบวงแหวน (PNG / JPG / WEBP) หรือลากไฟล์มาวางที่นี่</div>
                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">AI จะสกัดเฉพาะเส้นกรอบวงกลม ตัดพื้นหลังตารางหมากรุก/สีขาว และเจาะรูตรงกลางให้อัตโนมัติ</div>
                    </div>

                    <!-- Smart Ring Cutout Controls -->
                    <div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 10px; padding: 12px 14px; margin-bottom: 14px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; flex-wrap:wrap; gap:6px;">
                            <span style="font-size:13px; font-weight:700; color:#38bdf8;">✂️ ตั้งค่าสกัดเฉพาะส่วนของกรอบวงแหวน (AI Ring Extractor)</span>
                            <div style="display:flex; align-items:center; gap:10px;">
                                <label style="display:inline-flex; align-items:center; gap:5px; margin:0; font-size:12px; color:#a7f3d0; cursor:pointer;">
                                    <input type="checkbox" id="ai_auto_remove_bg" checked onchange="reprocessCurrentAiRing()" style="width:15px; height:15px;">
                                    <span>ตัดพื้นหลังสีขาว/ตารางหมากรุก</span>
                                </label>
                                <button type="button" id="btn_clear_ai_ring" class="btn btn-danger" style="display:none; padding:3px 8px; font-size:11px;" onclick="clearAiRingImage()">🗑️ ลบรูปกรอบ</button>
                            </div>
                        </div>
                        <div class="grid-2" style="gap: 12px;">
                            <div>
                                <div style="display:flex; justify-content:space-between; font-size:11.5px; color:#cbd5e1; margin-bottom:3px;">
                                    <span>⭕ เจาะรูโปร่งใสตรงกลาง:</span>
                                    <strong id="ai_inner_cut_label" style="color:#38bdf8;">56%</strong>
                                </div>
                                <input type="range" id="ai_inner_cut" min="0" max="86" value="56" step="2" oninput="onAiRingParamChange()" style="width:100%; padding:0;">
                            </div>
                            <div>
                                <div style="display:flex; justify-content:space-between; font-size:11.5px; color:#cbd5e1; margin-bottom:3px;">
                                    <span>🧹 ความไวตัดพื้นหลัง:</span>
                                    <strong id="ai_bg_tol_label" style="color:#38bdf8;">45</strong>
                                </div>
                                <input type="range" id="ai_bg_tol" min="10" max="85" value="45" step="1" oninput="onAiRingParamChange()" style="width:100%; padding:0;">
                            </div>
                        </div>
                        <div style="margin-top:8px;">
                            <div style="display:flex; justify-content:space-between; font-size:11.5px; color:#cbd5e1; margin-bottom:3px;">
                                <span>🔍 ขนาดสวมกรอบรอบวงกลม (Scale):</span>
                                <strong id="ai_frame_scale_label" style="color:#ffd700;">122%</strong>
                            </div>
                            <input type="range" id="ai_frame_scale" min="95" max="150" value="122" step="1" oninput="updateAiPreview()" style="width:100%; padding:0;">
                        </div>
                    </div>

                    <!-- AI Status / Generated badge -->
                    <div id="ai_analysis_status" style="display:none; background: rgba(16,185,129,0.15); border: 1px solid var(--success); border-radius: 8px; padding: 10px 14px; margin-bottom: 14px; font-size: 13px; color: #a7f3d0;">
                        ✨ AI สกัดเส้นกรอบวงแหวนโปร่งใส + คำนวณแสงเออร่าและลูกเล่นให้อัตโนมัติแล้ว!
                    </div>

                    <form id="aiFrameForm" onsubmit="submitSaveAiFrame(event)">
                        <input type="hidden" id="ai_editing_char_id" value="0">
                        <div class="form-group">
                            <label>ชื่อกรอบรูป (AI แนะนำ / แก้ไขได้) *</label>
                            <div style="display:flex; gap:8px;">
                                <input type="text" id="ai_frame_name" placeholder="อัปโหลดรูปเพื่อให้ AI ตั้งชื่ออัตโนมัติ" required oninput="updateAiPreview()">
                                <button type="button" class="btn" style="white-space:nowrap; padding: 0 14px;" onclick="regenerateAiTitle()" title="สุ่มชื่อใหม่ตามเฉดสี">🎲 สุ่มชื่อ</button>
                            </div>
                        </div>

                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>เกรดของกรอบรูป *</label>
                                <select id="ai_frame_grade" onchange="updateAiPreview()">
                                    <option value="SS+" selected>SS+ (สูงสุด จักรพรรดิ)</option>
                                    <option value="S+">S+ (เทพเจ้า รางวัลสะสมการ์ดเงา)</option>
                                    <option value="S">S (ยอดฝีมือ)</option>
                                    <option value="A+">A+ (รุ่งอรุณ)</option>
                                    <option value="A">A (มาตรฐาน)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>แสงเออร่า (Aura Type) *</label>
                                <select id="ai_frame_aura" onchange="updateAiPreview()">
                                    <option value="orange" selected>orange (สีส้มเพลิงมหาเวทย์ 🔥)</option>
                                    <option value="gold">gold (สีทองสง่างาม 👑)</option>
                                    <option value="crimson">crimson (สีแดงเพลิงโลหิต 🩸)</option>
                                    <option value="purple">purple (สีม่วงดาราจักร 🔮)</option>
                                    <option value="rainbow">rainbow (สีรุ้งปริซึม 7 สี 🌈)</option>
                                    <option value="yellow">yellow (สีเหลืองสายฟ้า ⚡)</option>
                                    <option value="cyan">cyan (สีฟ้านีออนวารี 🌊)</option>
                                    <option value="white">white (สีขาวนีออนบริสุทธิ์ ✨)</option>
                                    <option value="none">none (ไม่มีเออร่า)</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>✨ ลูกเล่นแอนิเมชันกรอบ (Frame FX) *</label>
                                <select id="ai_frame_fx" onchange="updateAiPreview()" style="border-color:#c084fc; color:#f3e8ff; font-weight:600;">
                                    <option value="spin_pulse" selected>🌀 หมุนวงแหวน + พัลส์พลังงาน</option>
                                    <option value="spin_slow">🔄 หมุนวงแหวน 360° ต่อเนื่อง</option>
                                    <option value="reverse_dual">💫 วงแหวนพลังงานคู่หมุนสวนทาง</option>
                                    <option value="electric_orbit">⚡ ประกายดาวสายฟ้าวิ่งรอบกรอบ</option>
                                    <option value="flame_halo">🔥 เปลวเพลิงออร่าลุกโชนรอบกรอบ</option>
                                    <option value="pulse_breathe">✨ เรืองแสงหายใจเข้า-ออก นุ่มนวล</option>
                                    <option value="static">🛡️ กรอบนิ่งคมชัด (ไม่หมุน)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:6px;">
                                    <label style="margin:0;">🔥 ความเข้มแสงเออร่า (10% - 500%):</label>
                                    <div style="display:inline-flex; align-items:center; gap:5px;">
                                        <input type="number" id="ai_frame_intensity_num" min="10" max="500" step="5" value="100"
                                            oninput="updateAiIntensity(this.value)"
                                            style="width:74px; padding:4px 8px; text-align:right; font-weight:700; color:var(--accent); border-color:rgba(245,158,11,0.45);">
                                        <span id="ai_intensity_label" style="font-weight:700; color:var(--accent); min-width:44px; text-align:right;">100%</span>
                                    </div>
                                </div>
                                <input type="range" id="ai_frame_intensity" min="10" max="500" value="100" step="5" oninput="updateAiIntensity(this.value)" style="width:100%; margin-top:4px;">
                            </div>
                        </div>

                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>🏆 อัตราชนะ (%)</label>
                                <input type="number" id="ai_frame_win" value="85" step="0.5" min="0" max="100" oninput="updateAiPreview()">
                            </div>
                            <div class="form-group">
                                <label>🎲 อัตราทอยเต๋า/คุมเต๋า (%)</label>
                                <input type="number" id="ai_frame_roll" value="90" step="0.5" min="0" max="100" oninput="updateAiPreview()">
                            </div>
                        </div>

                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>⚡ อัตราเล่นเก่ง (Skill)</label>
                                <input type="number" id="ai_frame_skill" value="45" min="0" max="100" oninput="updateAiPreview()">
                            </div>
                            <div class="form-group">
                                <label>🎨 สีขอบวงในเสริม (Hex)</label>
                                <input type="color" id="ai_frame_color" value="#f59e0b" style="height:42px; padding:2px;" onchange="updateAiPreview()">
                            </div>
                        </div>

                        <div class="form-group" style="background:rgba(255,215,0,0.08); border:1px solid rgba(255,215,0,0.3); border-radius:8px; padding:12px; margin-top:6px;">
                            <label style="display:flex; align-items:center; gap:10px; margin:0; cursor:pointer; color:#ffd700; font-weight:700;">
                                <input type="checkbox" id="ai_set_as_gacha_target" checked style="width:20px; height:20px;">
                                <span>🌟 ตั้งเป็นกรอบรูปเป้าหมายของกิจกรรมสุ่มการ์ดเงาทันที</span>
                            </label>
                            <p style="font-size:12px; color:var(--text-muted); margin:4px 0 0 30px;">
                                เมื่อผู้เล่นสะสมการ์ดเงาครบ 5 สี (ดำ, แดง, ส้ม, ฟ้า, ทอง) จะแลกรับกรอบรูปนี้ได้ทันที 1 ใบ
                            </p>
                        </div>

                        <button type="submit" id="btn-save-ai-frame" class="btn btn-accent" style="width:100%; padding:14px; font-size:16px; margin-top:14px; font-weight:700;">
                            💾 บันทึกเป็นกรอบรูปกิจกรรมใหม่ลงฐานข้อมูล
                        </button>
                    </form>
                </div>

                <!-- Right: Live 3D Circular Ring Frame & Aura Preview -->
                <div style="background: radial-gradient(circle at 50% 42%, #131c31 0%, #070a12 75%); border: 1.5px solid var(--panel-border); border-radius: 16px; padding: 24px; text-align: center; box-shadow: inset 0 0 35px rgba(0,0,0,0.85);">
                    <h3 style="color:var(--text-muted); font-size:14px; margin-bottom:12px;">✨ ตัวอย่างส่วนของกรอบวงแหวน & แสงเออร่า (LIVE FRAME RING PREVIEW)</h3>

                    <!-- Toggle Center Mode & Upload Admin Avatar -->
                    <div style="display:flex; justify-content:center; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:10px;">
                        <div style="display:inline-flex; gap:4px; background:rgba(15,23,42,0.9); padding:4px; border-radius:10px; border:1px solid rgba(255,255,255,0.1);">
                            <button type="button" id="btn_prev_mode_avatar" class="btn" style="padding:6px 14px; font-size:12px; background:var(--primary); color:#000; font-weight:700;" onclick="setAiPreviewCenterMode('sample_avatar')">
                                👤 จำลองสวมรูปโปรไฟล์แอดมิน
                            </button>
                            <button type="button" id="btn_prev_mode_ring" class="btn" style="padding:6px 14px; font-size:12px; background:transparent; color:#cbd5e1;" onclick="setAiPreviewCenterMode('ring_only')">
                                ⭕ แสดงเฉพาะส่วนของกรอบ
                            </button>
                        </div>
                        <label for="admin_avatar_quick_uploader" class="btn btn-accent" style="padding:6px 14px; font-size:12px; cursor:pointer; display:inline-flex; align-items:center; gap:6px; margin:0; font-weight:700; box-shadow:0 0 12px rgba(245,158,11,0.35);">
                            📸 อัปโหลดรูปแอดมินทดสอบ
                        </label>
                        <input type="file" id="admin_avatar_quick_uploader" accept="image/*" style="display:none;" onchange="handleAdminAvatarUpload(event)">
                    </div>
                    <div style="font-size:11.5px; color:#94a3b8; margin-bottom:14px;">
                        💡 คลิกปุ่ม <strong style="color:#fbbf24;">"📸 อัปโหลดรูปแอดมินทดสอบ"</strong> หรือคลิกตรงกลางวงกลมเพื่ออัปรูปตัวเองมาทดสอบสวมกรอบได้ทันที
                    </div>
                    
                    <div style="display: flex; justify-content: center; align-items: center; min-height: 250px; margin-bottom: 16px; position: relative;">
                        <div id="ai_preview_stage" style="position:relative; width:176px; height:176px; display:flex; align-items:center; justify-content:center;">
                            <!-- Layer 1: Outer Aura Glow Ring -->
                            <div id="ai_preview_aura_container" style="position:absolute; width:152px; height:152px; border-radius:50%; transition: all 0.3s; z-index:1;"></div>

                            <!-- Layer 2: Center Hollow / Sample Avatar (Admin's Avatar!) -->
                            <div id="ai_preview_avatar" onclick="document.getElementById('admin_avatar_quick_uploader').click()" title="คลิกเพื่ออัปโหลดรูปตัวเองมาทดสอบสวมกรอบ" style="width:136px; height:136px; border-radius:50%; background-image:url('<?= htmlspecialchars($currentAdmin['avatar_url'] ?: '../avatars/avatar_01.png') ?>'); background-size:cover; background-position:center; border: 2.5px solid #f59e0b; display:flex; flex-direction:column; align-items:center; justify-content:center; overflow:hidden; z-index:2; position:relative; box-shadow: inset 0 0 18px rgba(0,0,0,0.85); cursor:pointer;">
                                <span id="ai_preview_center_hint" style="display:none; font-size:11px; color:rgba(148,163,184,0.65); font-weight:600; letter-spacing:0.5px;">ช่องว่างรูปโปรไฟล์</span>
                            </div>

                            <!-- Layer 3: Special FX Decoration Layer (Sparks / Dual Ring / Flame) -->
                            <div id="ai_preview_fx_deco" class="fx-deco-orbit" style="display:none;"></div>

                            <!-- Layer 4: Extracted Transparent Ring Frame Overlay (Around Perimeter!) -->
                            <img id="ai_preview_ring_overlay" src="" alt="AI Ring Frame" class="fx-ring-spin_pulse"
                                style="display:none; position:absolute; top:50%; left:50%; width:166px; height:166px; object-fit:contain; pointer-events:none; z-index:4; filter: drop-shadow(0 0 8px rgba(255,255,255,0.35));">

                            <!-- Layer 5: Grade Badge -->
                            <div id="ai_preview_grade_badge" style="position:absolute; bottom:8px; right:8px; background:linear-gradient(135deg,#ffd700,#f59e0b); color:#000; font-size:12px; font-weight:800; padding:2px 9px; border-radius:12px; z-index:6; border:1.5px solid #fff; box-shadow:0 2px 8px rgba(0,0,0,0.65);">
                                SS+
                            </div>
                        </div>
                    </div>

                    <div id="ai_stage_shadow_banner" style="display:none; margin-bottom:10px;">
                        <span style="display:inline-flex; align-items:center; gap:8px; background:rgba(168,85,247,0.18); border:1px solid #a855f7; color:#f3e8ff; padding:5px 12px; border-radius:999px; font-size:12px; font-weight:700;">
                            <span id="ai_stage_shadow_banner_text">🌑 กำลังแสดงตัวอย่างเงา</span>
                            <button type="button" onclick="exitShadowStageInspect()" style="background:#a855f7; color:#fff; border:none; border-radius:999px; padding:2px 10px; font-size:11px; font-weight:700; cursor:pointer;">🔙 กลับดูกรอบหลัก</button>
                        </span>
                    </div>

                    <h4 id="ai_preview_display_name" style="font-size:18px; color:#ffd700; margin-bottom:4px; font-weight:700;">กรอบรูปเทพมังกรเพลิงมหาเวทย์</h4>
                    <div id="ai_preview_aura_desc" style="font-size:12px; color:#38bdf8; margin-bottom:4px;">แสงเออร่า: ส้มเพลิงมหาเวทย์ 🔥 (ระดับแสง 100%)</div>
                    <div id="ai_preview_fx_desc" style="font-size:12px; color:#c084fc; margin-bottom:14px; font-weight:600;">✨ ลูกเล่น: หมุนวงแหวน + พัลส์พลังงาน</div>

                    <div style="display:flex; justify-content:center; gap:8px; font-size:12px; margin-bottom:14px; flex-wrap:wrap;">
                        <span style="background:rgba(255,255,255,0.06); padding:4px 10px; border-radius:6px; border:1px solid rgba(255,255,255,0.1);">🏆 อัตราชนะ <strong id="ai_prev_win" style="color:#ffd700;">85%</strong></span>
                        <span style="background:rgba(255,255,255,0.06); padding:4px 10px; border-radius:6px; border:1px solid rgba(255,255,255,0.1);">🎲 ทอยเต๋า <strong id="ai_prev_roll" style="color:#38bdf8;">90%</strong></span>
                        <span style="background:rgba(255,255,255,0.06); padding:4px 10px; border-radius:6px; border:1px solid rgba(255,255,255,0.1);">⚡ ฝีมือ <strong id="ai_prev_skill" style="color:#a855f7;">45</strong></span>
                    </div>

                    <!-- Mini Gallery of AI-Synthesized Shadow Rings matching the uploaded frame -->
                    <div style="margin-top:14px; padding-top:14px; border-top:1px solid rgba(255,255,255,0.1); text-align:left;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; flex-wrap:wrap; gap:6px;">
                            <span style="font-size:12px; font-weight:700; color:#f8fafc;">🌑 ตัวอย่างชุดเงาที่ AI สร้างจากรูปกรอบนี้ (คลิกเพื่อดูวงใหญ่):</span>
                            <button type="button" class="btn" style="padding:3px 9px; font-size:11px; background:rgba(56,189,248,0.15); color:#38bdf8; border:1px solid rgba(56,189,248,0.4);" onclick="autoAnalyzeShadowsFromRing()">🪄 วิเคราะห์เงาใหม่</button>
                        </div>
                        <div id="ai_shadow_mini_gallery" style="display:grid; grid-template-columns:repeat(5, 1fr); gap:8px;"></div>
                    </div>

                    <p style="font-size:12px; color:var(--text-muted); line-height: 1.5; margin:12px 0 0 0;">
                        💡 <strong>แสดงเฉพาะส่วนของกรอบรอบนอก:</strong> ตรงกลางจะถูกเจาะโปร่งใสเพื่อให้รูปอวตารของผู้เล่นแสดงอยู่ด้านใน โดยตัวกรอบ แสงเออร่า และชุดเงาทั้ง 5 จะถอดลวดลายจากกรอบต้นฉบับอัตโนมัติ
                    </p>
                </div>
            </div>

            <!-- FULL-WIDTH AI SHADOW BUILDER & MULTI-GRADE EXCHANGE STUDIO -->
            <div style="margin-top: 22px; border-top: 1.5px solid var(--panel-border); padding-top: 20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                    <div>
                        <h3 style="color:#ffd700; font-size:17px; margin:0; display:flex; align-items:center; gap:8px;">
                            <span>🌑</span> ระบบ AI วิเคราะห์สร้างการ์ดเงาประจำกรอบรูป & ตั้งค่าแลกกรอบ SS+ / S+ / S
                        </h3>
                        <p style="color:var(--text-muted); font-size:12px; margin-top:4px;">
                            ระบบ AI ถอดโครงสร้างลวดลายและขอบแสงจากรูปกรอบที่อัปโหลด มาสร้างเป็น <strong>เงาวงแหวนสวยๆ ทั้ง 5 ระดับ (เช่น เงา A, A+, S)</strong> พร้อมให้ปรับแต่ง <strong>สีเงา, แสงเออร่า, % อัตราการสุ่มออก</strong> และกำหนด <strong>จำนวนเงาที่ใช้แลกกรอบ SS+ / S+ / S</strong> ได้ครบในหน้าเดียว
                        </p>
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <button type="button" class="btn" style="background:linear-gradient(135deg,#0284c7,#6366f1); color:#fff; font-size:13px; padding:9px 14px; font-weight:700;" onclick="autoAnalyzeShadowsFromRing()">
                            🪄 ให้ AI วิเคราะห์ทำเงาสวยๆ จากรูปอัปโหลด
                        </button>
                        <button type="button" class="btn" style="background:#334155; color:#cbd5e1; font-size:12px; padding:9px 12px;" onclick="resetAiShadowStudioDefaults()">
                            🔄 รีเซ็ตค่าเริ่มต้นเงา
                        </button>
                    </div>
                </div>

                <!-- 5 Configurable AI Shadow Cards -->
                <div id="ai_shadow_cards_editor" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(225px, 1fr)); gap:12px; margin-bottom:20px;"></div>

                <!-- Multi-Grade Frame Exchange Configuration: SS+, S+, S -->
                <div style="background:rgba(15,23,42,0.72); border:1.5px solid rgba(255,215,0,0.28); border-radius:14px; padding:16px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                        <div>
                            <h4 style="color:#38bdf8; font-size:15px; margin:0;">🎯 กำหนดอัตราจำนวนเงาที่ใช้สะสมเพื่อแลก กรอบ SS+ / กรอบ S+ / กรอบ S</h4>
                            <p style="font-size:12px; color:var(--text-muted); margin-top:2px;">
                                กำหนดว่าผู้เล่นต้องสะสมเงาแต่ละสีกี่อัน เพื่อนำไปแลกรับกรอบระดับ <strong>SS+</strong>, <strong>S+</strong> หรือ <strong>S</strong> (เลือกกรอบเป้าหมายของแต่ละเกรดได้อิสระ)
                            </p>
                        </div>
                        <label style="display:inline-flex; align-items:center; gap:8px; margin:0; background:rgba(16,185,129,0.12); border:1px solid rgba(16,185,129,0.4); padding:6px 12px; border-radius:8px; color:#34d399; font-size:12px; font-weight:700; cursor:pointer;">
                            <input type="checkbox" id="ai_sync_shadow_to_event" checked style="width:17px; height:17px;">
                            <span>⚡ นำชุดเงาและอัตราแลกนี้ไปใช้ในกิจกรรมสุ่มแพ็คการ์ดทันที</span>
                        </label>
                    </div>

                    <div id="ai_exchange_tiers_editor" style="display:flex; flex-direction:column; gap:10px;"></div>

                    <div style="margin-top:16px; display:flex; justify-content:flex-end;">
                        <button type="button" class="btn btn-accent" style="padding:12px 24px; font-size:15px; font-weight:700;" onclick="document.getElementById('btn-save-ai-frame').click()">
                            💾 บันทึกกรอบรูป + ชุดเงา AI & อัตราแลกกรอบ SS+ / S+ / S ทั้งหมด
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- TAB: AI DICE CREATOR & 3D ROLL SIMULATOR -->
    <!-- ============================================================ -->
    <div id="tab-dice_creator" class="tab-content">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:14px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">🎲 ระบบ AI สร้าง & ปรับแต่งลูกเต๋า 3D + แสงเออร่าทะลุขีดจำกัด (AI Dice Studio)</h2>
                    <p style="color:var(--text-muted); font-size:13px; margin-top:4px; margin-bottom:0;">
                        สร้างลูกเต๋าใหม่จากรูปภาพด้วย AI, ปรับสีเต๋า & สีจุดแต้มอิสระ, เร่งแสงเออร่าได้ถึง <strong>500%</strong> พร้อมลูกเล่นแสง FX, ตั้งเกรดได้ตั้งแต่ <strong>A ถึง SS+</strong> หรือพิมพ์เกรดเอง เช่น <strong>Z+, ZZ+</strong> และทดสอบทอยลูกเต๋า 3D จำลองผลลัพธ์แบบเรียลไทม์
                    </p>
                </div>
                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <select id="ai_dice_existing_select" onchange="loadDiceIntoStudio(this.value)" style="width:280px; border-color:#a855f7; color:#c084fc; font-weight:700;">
                        <option value="0">➕ โหมด: สร้างลูกเต๋าใหม่ด้วย AI</option>
                    </select>
                    <button type="button" class="btn" style="padding:8px 14px; font-size:12px; background:#334155; color:#fff;" onclick="resetAiDiceStudio()">
                        🔄 ล้างค่า/สร้างใหม่
                    </button>
                </div>
            </div>

            <div class="grid-2" style="gap: 24px; align-items: start;">
                <!-- LEFT COLUMN: AI Upload & Dice Settings -->
                <div>
                    <!-- Drop Zone for Dice Skin/Image -->
                    <div id="ai_dice_dropzone" onclick="document.getElementById('ai_dice_image_input').click()" 
                        style="border: 2px dashed #a855f7; border-radius: 12px; padding: 20px 16px; text-align: center; background: rgba(168,85,247,0.06); cursor: pointer; transition: 0.2s; margin-bottom: 14px;">
                        <input type="file" id="ai_dice_image_input" accept="image/*" style="display:none;" onchange="handleAiDiceImageSelect(event)">
                        <div style="font-size: 34px; margin-bottom: 6px;">🎲</div>
                        <div style="font-size: 15px; font-weight: 700; color: #c084fc;">คลิกเพื่ออัปโหลดรูปลูกเต๋า / เท็กซ์เจอร์ หรือลากไฟล์มาวางที่นี่</div>
                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">AI จะวิเคราะห์โทนสีตัวเต๋า, คำนวณสีจุดแต้มตัดสายตา, แนะนำเกรด (เช่น Z+, ZZ+) และแสงเออร่าที่เข้ากันให้อัตโนมัติ</div>
                    </div>

                    <!-- AI Analysis Box (shows detected colors & recommendation) -->
                    <div id="ai_dice_analysis_badge" style="display:none; background:rgba(15,23,42,0.8); border:1px solid rgba(168,85,247,0.35); border-radius:10px; padding:10px 14px; margin-bottom:12px; font-size:12px; color:#cbd5e1;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                            <span style="font-weight:700; color:#38bdf8;">🧠 ผลวิเคราะห์ AI จากรูปภาพ:</span>
                            <span id="ai_analysis_theme_tag" style="background:rgba(168,85,247,0.25); color:#c084fc; padding:2px 8px; border-radius:4px; font-weight:700;">Theme</span>
                        </div>
                        <div style="display:flex; gap:16px; align-items:center; flex-wrap:wrap;">
                            <div>สีตัวเต๋า: <span id="ai_detected_body_swatch" style="display:inline-block; width:14px; height:14px; border-radius:3px; vertical-align:middle; border:1px solid #fff;"></span> <code id="ai_detected_body_hex">#000</code></div>
                            <div>สีจุดแต้ม: <span id="ai_detected_pip_swatch" style="display:inline-block; width:14px; height:14px; border-radius:3px; vertical-align:middle; border:1px solid #fff;"></span> <code id="ai_detected_pip_hex">#fff</code></div>
                            <div>แสงเออร่าที่แนะนำ: <strong id="ai_recommended_aura_name" style="color:#ffd700;">Gold</strong></div>
                        </div>
                    </div>

                    <!-- Toggle Apply Skin Texture Wrap -->
                    <div style="display:flex; align-items:center; justify-content:space-between; background:rgba(168,85,247,0.12); border:1px solid rgba(168,85,247,0.3); border-radius:10px; padding:8px 12px; margin-bottom:12px;">
                        <label style="margin:0; font-size:12.5px; font-weight:700; color:#c084fc; cursor:pointer; display:flex; align-items:center; gap:8px;" for="ai_dice_apply_skin_texture">
                            <span>🎨 สวมภาพภายนอกเป็นสกินลูกเต๋า 3D (Apply Texture Skin)</span>
                        </label>
                        <input type="checkbox" id="ai_dice_apply_skin_texture" checked onchange="updateAiDice3DPreview()" style="transform:scale(1.2); cursor:pointer;">
                    </div>

                    <!-- AI Style Variations Section with Rebuild Button -->
                    <div id="ai_variations_section" style="background:rgba(15,23,42,0.85); border:1.5px solid #a855f7; border-radius:12px; padding:12px; margin-bottom:14px; box-shadow:0 0 15px rgba(168,85,247,0.15);">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; flex-wrap:wrap; gap:8px;">
                            <span style="font-size:12.5px; font-weight:800; color:#c084fc;">
                                🎨 สไตล์ที่ AI ออกแบบ (คลิกเพื่อเลือกดู &amp; ลองทอย):
                            </span>
                            <button type="button" class="btn" style="padding:4px 10px; font-size:11.5px; background:linear-gradient(135deg, #a855f7, #ec4899); color:#fff; font-weight:800; border-radius:8px; box-shadow:0 0 10px rgba(168,85,247,0.4);" onclick="rebuildAiDiceVariations()">
                                🔄 Rebuild สุ่มใหม่
                            </button>
                        </div>
                        <div id="ai_variations_grid" style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;">
                            <!-- Injected dynamically by JS -->
                        </div>
                    </div>

                    <form id="aiDiceForm" onsubmit="saveAiDiceToDatabase(event)">
                        <input type="hidden" id="ai_dice_id" value="0">
                        <input type="hidden" id="ai_dice_image_url" value="">

                        <!-- Row 1: Name and Random Generator -->
                        <div class="form-group" style="margin-bottom:12px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                <label style="margin:0; font-weight:700;">ชื่อลูกเต๋า (Dice Name)</label>
                                <button type="button" class="btn" style="padding:2px 8px; font-size:11px; background:#3b82f6;" onclick="generateRandomDiceName()">
                                    ✨ สุ่มชื่อ AI
                                </button>
                            </div>
                            <input type="text" id="ai_dice_name" value="ลูกเต๋ามังกรดาราจักร ZZ+" required oninput="updateAiDice3DPreview()" style="font-weight:700; color:#fff; font-size:15px;">
                        </div>

                        <!-- Row 2: Grade (Text input + Datalist + Clickable Pills) -->
                        <div class="form-group" style="margin-bottom:14px;">
                            <label style="font-weight:700; display:flex; justify-content:space-between; align-items:center;">
                                <span>ระดับเกรดลูกเต๋า (Dice Grade)</span>
                                <span style="font-size:11px; color:#38bdf8; font-weight:normal;">* พิมพ์เกรดที่ต้องการได้อย่างอิสระ เช่น Z+, ZZ+</span>
                            </label>
                            <input type="text" id="ai_dice_grade" list="dice_grade_datalist" value="SS+" required oninput="updateAiDice3DPreview()" style="font-weight:800; font-size:15px; color:#ffd700; text-transform:uppercase;">
                            <datalist id="dice_grade_datalist">
                                <option value="A">
                                <option value="A+">
                                <option value="S">
                                <option value="S+">
                                <option value="SS+">
                                <option value="SSS+">
                                <option value="Z+">
                                <option value="ZZ+">
                                <option value="ZZZ+">
                                <option value="GOD">
                                <option value="MYTHIC">
                            </datalist>
                            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:6px;">
                                <span style="font-size:11px; color:var(--text-muted); align-self:center;">เลือกเกรดด่วน:</span>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('A')">A</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('A+')">A+</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('S')">S</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('S+')">S+</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('SS+')" style="color:#ffd700; border-color:#ffd700;">SS+</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('Z+')" style="color:#f43f5e; border-color:#f43f5e; background:rgba(244,63,94,0.15);">Z+</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('ZZ+')" style="color:#a855f7; border-color:#a855f7; background:rgba(168,85,247,0.2);">ZZ+</button>
                                <button type="button" class="grade-pill-click" onclick="setDiceGradeQuick('SSS+')" style="color:#00e5ff; border-color:#00e5ff; background:rgba(0,229,255,0.15);">SSS+</button>
                            </div>
                        </div>

                        <!-- Row 3: Dice Control Rate -->
                        <div class="form-group" style="margin-bottom:14px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                <label style="margin:0; font-weight:700;">🎯 อัตราควบคุมลูกเต๋า / ทอยแม่นยำ (%)</label>
                                <span id="lbl_dice_ctrl_val" style="color:#00e5ff; font-weight:800; font-size:14px;">85.00%</span>
                            </div>
                            <div style="display:flex; gap:10px; align-items:center;">
                                <input type="range" id="ai_dice_control_rate_range" min="1" max="100" step="0.5" value="85" oninput="syncDiceCtrlSlider(this.value)" style="flex:1;">
                                <input type="number" id="ai_dice_control_rate" min="1" max="100" step="0.5" value="85.00" oninput="syncDiceCtrlNum(this.value)" style="width:85px; text-align:center; font-weight:700;">
                            </div>
                        </div>

                        <!-- Row 4: Colors (Dice Body & Pips) -->
                        <div style="background:rgba(15,23,42,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:12px; margin-bottom:14px;">
                            <label style="font-weight:700; margin-bottom:8px; display:block; color:#cbd5e1;">🎨 ปรับสีตัวเต๋า & สีจุดแต้ม (Dice & Pip Colors)</label>
                            <div class="grid-2" style="gap:12px; margin-bottom:8px;">
                                <div>
                                    <div style="font-size:12px; color:var(--text-muted); margin-bottom:3px;">สีตัวลูกเต๋า (Face Color)</div>
                                    <div style="display:flex; gap:6px; align-items:center;">
                                        <input type="color" id="ai_dice_color_picker" value="#1e1b4b" onchange="syncDiceBodyColor(this.value)" style="width:38px; height:36px; padding:1px; border:none; border-radius:6px; cursor:pointer;">
                                        <input type="text" id="ai_dice_color" value="#1e1b4b" oninput="syncDiceBodyColorHex(this.value)" style="font-family:monospace; font-weight:700;">
                                    </div>
                                </div>
                                <div>
                                    <div style="font-size:12px; color:var(--text-muted); margin-bottom:3px;">สีจุดแต้ม / ตัวเลข (Pip Color)</div>
                                    <div style="display:flex; gap:6px; align-items:center;">
                                        <input type="color" id="ai_dice_pip_color_picker" value="#00e5ff" onchange="syncDicePipColor(this.value)" style="width:38px; height:36px; padding:1px; border:none; border-radius:6px; cursor:pointer;">
                                        <input type="text" id="ai_dice_pip_color" value="#00e5ff" oninput="syncDicePipColorHex(this.value)" style="font-family:monospace; font-weight:700;">
                                    </div>
                                </div>
                            </div>
                            <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                                <span style="font-size:11px; color:var(--text-muted);">พรีเซ็ตสี:</span>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#1e1b4b; color:#00e5ff; border:1px solid #00e5ff;" onclick="applyDiceColorPreset('#1e1b4b', '#00e5ff', 'cyan')">ไซยานคอสมิค</button>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#451a03; color:#ffd700; border:1px solid #ffd700;" onclick="applyDiceColorPreset('#451a03', '#ffd700', 'gold')">สุริยมังกรทอง</button>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#581c87; color:#f43f5e; border:1px solid #f43f5e;" onclick="applyDiceColorPreset('#3b0764', '#f43f5e', 'purple')">ดาราจักรเนบิวลา</button>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#450a0a; color:#f97316; border:1px solid #f97316;" onclick="applyDiceColorPreset('#450a0a', '#f97316', 'orange')">เพลิงนรกานต์</button>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#022c22; color:#34d399; border:1px solid #34d399;" onclick="applyDiceColorPreset('#022c22', '#34d399', 'emerald')">มรกตราชันย์</button>
                                <button type="button" class="btn" style="padding:2px 7px; font-size:10px; background:#000000; color:#ffffff; border:1px solid #ffffff;" onclick="applyDiceColorPreset('#0f172a', '#ffffff', 'white')">ออบซิเดียนขาว</button>
                            </div>
                        </div>

                        <!-- Row 5: Aura System (Type, Intensity 10-500%, FX) -->
                        <div style="background:rgba(15,23,42,0.6); border:1px solid rgba(168,85,247,0.3); border-radius:10px; padding:12px; margin-bottom:14px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                <label style="margin:0; font-weight:700; color:#c084fc;">✨ แสงเออร่าลูกเต๋า & ลูกเล่นพิเศษ (Aura & FX)</label>
                                <span id="lbl_dice_aura_power_tag" style="background:rgba(168,85,247,0.25); color:#c084fc; font-weight:800; font-size:11px; padding:2px 8px; border-radius:4px;">100% (ปกติ)</span>
                            </div>

                            <div class="grid-2" style="gap:12px; margin-bottom:10px;">
                                <div>
                                    <div style="font-size:12px; color:var(--text-muted); margin-bottom:3px;">โทนแสงเออร่า (Aura Type)</div>
                                    <select id="ai_dice_aura" onchange="updateAiDice3DPreview()">
                                        <option value="none">ไม่มีแสงเออร่า (none)</option>
                                        <option value="cyan" selected>ฟ้าไอซ์ไซยาน (cyan)</option>
                                        <option value="gold">ทองสง่างามจักรพรรดิ (gold)</option>
                                        <option value="purple">ม่วงดาราจักรเนบิวลา (purple)</option>
                                        <option value="orange">ส้มเพลิงสุริยัน (orange)</option>
                                        <option value="crimson">แดงเพลิงมังกร (crimson)</option>
                                        <option value="yellow">เหลืองอัสนีบาต (yellow)</option>
                                        <option value="white">ขาวประกายเพชร (white)</option>
                                        <option value="emerald">เขียวมรกตเทพ (emerald)</option>
                                        <option value="pink">ชมพูนีออนไซเบอร์ (pink)</option>
                                        <option value="rainbow">รุ้ง 7 สีศักดิ์สิทธิ์ (rainbow)</option>
                                    </select>
                                </div>
                                <div>
                                    <div style="font-size:12px; color:var(--text-muted); margin-bottom:3px;">ลูกเล่นแอนิเมชันแสง (Aura FX)</div>
                                    <select id="ai_dice_fx" onchange="updateAiDice3DPreview()">
                                        <option value="pulse_breathe" selected>พัลส์แสงนุ่มนวล (Pulse Breathe)</option>
                                        <option value="rotate_spin">หมุนวนรอบทิศทาง (Orbit Spin)</option>
                                        <option value="dual_ring">วงแหวนคู่ 3D ซ้อนมิติ (Dual Rings)</option>
                                        <option value="solar_flare">ประกายเปลวสุริยะ (Solar Flare)</option>
                                        <option value="lightning_spark">สายฟ้าแลบกระพริบ (Lightning Spark)</option>
                                        <option value="cosmic_hyper">ไฮเปอร์ไดรฟ์จักรวาล (Cosmic Hyper)</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Slider 10% - 500% -->
                            <div>
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                    <span style="font-size:12px; color:#cbd5e1; font-weight:700;">⚡ ระดับความเข้มแสงเออร่า (Aura Intensity 10% - 500%):</span>
                                    <span id="lbl_dice_intensity_val" style="color:#ffd700; font-weight:800; font-size:13px;">100%</span>
                                </div>
                                <div style="display:flex; gap:10px; align-items:center;">
                                    <input type="range" id="ai_dice_intensity_range" min="10" max="500" step="5" value="100" oninput="syncDiceIntensitySlider(this.value)" style="flex:1;">
                                    <input type="number" id="ai_dice_intensity" min="10" max="500" step="5" value="100" oninput="syncDiceIntensityNum(this.value)" style="width:75px; text-align:center; font-weight:700;">
                                </div>
                                <div style="display:flex; justify-content:space-between; font-size:10.5px; color:var(--text-muted); margin-top:2px;">
                                    <span>10% (เบาบาง)</span>
                                    <span>100% (มาตรฐาน)</span>
                                    <span>250% (ทรงพลัง)</span>
                                    <span style="color:#ef4444; font-weight:700;">500% (MAX OVERLOAD)</span>
                                </div>
                            </div>
                        </div>

                        <!-- Row 6: Event Target Checkbox -->
                        <div style="background:rgba(2,132,199,0.1); border:1px solid rgba(2,132,199,0.3); border-radius:10px; padding:12px; margin-bottom:16px;">
                            <label style="display:flex; align-items:center; gap:8px; margin:0; cursor:pointer;">
                                <input type="checkbox" id="ai_dice_set_as_gacha_target" checked style="width:18px; height:18px;">
                                <span style="font-size:13px; font-weight:700; color:#38bdf8;">🎯 กำหนดให้เป็นลูกเต๋าเป้าหมายประจำกิจกรรมสุ่ม (Gacha Event Target) ทันทีหลังบันทึก</span>
                            </label>
                        </div>

                        <!-- Action Buttons -->
                        <div style="display:flex; gap:10px; flex-wrap:wrap;">
                            <button type="submit" class="btn btn-accent" style="flex:1; padding:12px 18px; font-size:14px; font-weight:800; background:linear-gradient(135deg, #7c3aed, #a855f7);">
                                💾 บันทึกลูกเต๋า (Save Dice)
                            </button>
                            <button type="button" class="btn" style="padding:12px 16px; font-size:13px; font-weight:700; background:#0284c7; color:#fff;" onclick="setDiceAsGachaTargetFromStudio()">
                                🎯 ตั้งเป็นเต๋ากิจกรรม
                            </button>
                            <button type="button" class="btn" style="padding:12px 14px; font-size:13px; background:#334155; color:#fff;" onclick="resetAiDiceStudio()">
                                🔄 รีเซ็ต
                            </button>
                        </div>
                    </form>
                </div>

                <!-- RIGHT COLUMN: 3D Interactive Stage & Roll Simulator -->
                <div>
                    <div class="dice-stage-box">
                        <!-- Top Stage Header -->
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                            <span id="stage_dice_grade_badge" class="grade-badge-pill" style="background:linear-gradient(135deg, #ffd700, #f59e0b); color:#000;">SS+</span>
                            <h3 id="stage_dice_title" style="margin:0; font-size:16px; font-weight:800; color:#fff; text-shadow:0 0 10px rgba(0,229,255,0.5);">ลูกเต๋ามังกรดาราจักร ZZ+</h3>
                            <span id="stage_dice_rate_badge" style="background:rgba(0,229,255,0.15); border:1px solid #00e5ff; color:#00e5ff; font-size:12px; font-weight:800; padding:3px 8px; border-radius:4px;">คุมเต๋า 85%</span>
                        </div>

                        <!-- 🎲 View Mode Switcher: 3D Crystal Cube vs Original Dice Showcase -->
                        <div id="dice_view_mode_selector" style="display:flex; justify-content:center; gap:8px; margin-bottom:10px;">
                            <button type="button" id="btnMode3DCube" class="btn" onclick="setDiceViewMode('cube')" 
                                style="padding:5px 14px; font-size:12px; font-weight:800; background:linear-gradient(135deg, #0284c7, #00e5ff); color:#000; border-radius:8px; border:none; box-shadow:0 0 12px rgba(0,229,255,0.4); cursor:pointer;">
                                🎲 ลูกเต๋า 3D สี่เหลี่ยมคริสตัล (Real 3D Cube)
                            </button>
                            <button type="button" id="btnModeShowcaseImg" class="btn" onclick="setDiceViewMode('showcase')" 
                                style="display:none; padding:5px 14px; font-size:12px; font-weight:800; background:#1e293b; color:#cbd5e1; border-radius:8px; border:1px solid rgba(255,255,255,0.18); cursor:pointer;">
                                🖼️ แสดงรูปทรงเต๋าต้นฉบับ 3 มิติ (เหมือนรูป 2)
                            </button>
                        </div>

                        <!-- 3D Scene Viewport -->
                        <div class="dice-scene" id="diceSceneContainer">
                            <!-- Pedestal Platform -->
                            <div class="dice-pedestal-platform" id="dicePedestal"></div>

                            <!-- Aura Glow backdrop wrapper (Outer circle removed as requested) -->
                            <div class="dice-aura-glow-wrapper" id="diceAuraGlowWrapper">
                                <div class="dice-aura-glow-backdrop dice-fx-pulse_breathe" id="diceAuraGlow"></div>
                            </div>
                            <!-- Particles container for scattering aura during roll -->
                            <div class="dice-particles-container" id="diceParticlesContainer"></div>

                            <!-- 🖼️ Original Dice Image Showcase (Uncut 3D Dice Showcase with Aura) -->
                            <div class="dice-image-showcase" id="diceImageShowcase" onclick="rollDiceSimulator(0)" style="display:none; position:relative; z-index:10; cursor:pointer;">
                                <img id="diceShowcaseImg" src="" alt="3D Dice" style="max-width:145px; max-height:145px; object-fit:contain; filter:drop-shadow(0 0 20px var(--aura-glow-color, #00e5ff)); transition:all 0.3s ease;">
                            </div>

                            <!-- 3D CSS Cube -->
                            <div class="dice-cube-3d style-crystal" id="diceCube3D" onclick="rollDiceSimulator(0)">
                                <!-- Core aura attached directly to cube center to roll and tumble with it in 3D -->
                                <div class="dice-attached-aura-glow" id="diceAttachedAura"></div>

                                <!-- Face 1 -->
                                <div class="dice-face-3d face-val-1">
                                    <div class="dice-pip-face-1" id="diceEmblemFace1"></div>
                                </div>
                                <!-- Face 6 -->
                                <div class="dice-face-3d face-val-6">
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                </div>
                                <!-- Face 2 -->
                                <div class="dice-face-3d face-val-2">
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                </div>
                                <!-- Face 5 -->
                                <div class="dice-face-3d face-val-5">
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                </div>
                                <!-- Face 3 -->
                                <div class="dice-face-3d face-val-3">
                                    <div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div>
                                </div>
                                <!-- Face 4 -->
                                <div class="dice-face-3d face-val-4">
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                    <div class="dice-pip-dot"></div><div class="dice-pip-dot"></div>
                                </div>
                            </div>
                        </div>

                        <!-- 3D View Angle Controller Sliders -->
                        <div style="background:rgba(15,23,42,0.65); border:1px solid rgba(255,255,255,0.08); border-radius:8px; padding:8px 12px; margin-bottom:16px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; font-size:11px; color:#cbd5e1; margin-bottom:4px;">
                                <span>🔄 หมุนมุมมองลูกเต๋า 3D (3D Orbit View):</span>
                                <button type="button" class="btn" style="padding:1px 6px; font-size:10px; background:#334155;" onclick="resetDice3DView()">มุมมองมาตรฐาน</button>
                            </div>
                            <div class="grid-2" style="gap:8px;">
                                <div style="display:flex; align-items:center; gap:6px; font-size:10.5px; color:var(--text-muted);">
                                    <span>แกน X:</span>
                                    <input type="range" id="view_rot_x" min="-90" max="90" value="-22" oninput="adjustDiceView()" style="flex:1;">
                                </div>
                                <div style="display:flex; align-items:center; gap:6px; font-size:10.5px; color:var(--text-muted);">
                                    <span>แกน Y:</span>
                                    <input type="range" id="view_rot_y" min="-180" max="180" value="32" oninput="adjustDiceView()" style="flex:1;">
                                </div>
                            </div>
                        </div>

                        <!-- 🔮 5 Dice Shadows Preview & Interactive Editor -->
                        <div id="dice_shadows_preview_section" style="background:rgba(15,23,42,0.85); border:1.5px solid #38bdf8; border-radius:12px; padding:12px; margin-bottom:16px; text-align:left; box-shadow:0 0 16px rgba(56,189,248,0.15);">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:6px;">
                                <span style="font-size:12.5px; font-weight:800; color:#38bdf8; display:flex; align-items:center; gap:6px;">
                                    <span>🔮 ตัวอย่างการ์ดเงา 5 ธาตุสำหรับแลกลูกเต๋านี้ (5 Dice Shadows):</span>
                                </span>
                                <span style="font-size:11px; color:#a7f3d0;">✨ คลิกที่การ์ดเพื่อแก้ไขสี/แสงเออร่า/ขนาด</span>
                            </div>

                            <!-- 5 Cards Grid Matching Image 3 -->
                            <div id="dice_shadows_cards_grid" style="display:grid; grid-template-columns:repeat(5, minmax(0, 1fr)); gap:6px; width:100%; box-sizing:border-box;">
                                <!-- Injected dynamically by JS -->
                            </div>

                            <!-- 🛠️ Interactive Shadow & Aura Editor for Selected Slot -->
                            <div id="dice_shadow_editor_panel" style="margin-top:12px; background:rgba(30,41,59,0.75); border:1px solid rgba(56,189,248,0.4); border-radius:10px; padding:12px;">
                                <!-- Rendered dynamically by renderDiceShadowEditorPanel() -->
                            </div>
                        </div>

                        <!-- 🎲 ROLL SIMULATOR CONTROLS -->
                        <div style="background:linear-gradient(135deg, rgba(30,41,59,0.95), rgba(15,23,42,0.95)); border:2px solid #00e5ff; border-radius:12px; padding:14px; box-shadow:0 0 20px rgba(0,229,255,0.25);">
                            <div style="font-size:13px; font-weight:800; color:#38bdf8; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
                                <span>🎲 เครื่องจำลองการทอยลูกเต๋า 3D (Roll Simulator)</span>
                                <span style="font-size:11px; color:#a7f3d0;">● พร้อมระบบฟิสิกส์หมุน 3 มิติ</span>
                            </div>

                            <!-- Roll Button -->
                            <button type="button" id="btnRollSimulator" class="btn" onclick="rollDiceSimulator(0)" 
                                style="width:100%; padding:14px 20px; font-size:16px; font-weight:900; background:linear-gradient(135deg, #0284c7, #00e5ff); color:#000; border:none; border-radius:10px; cursor:pointer; box-shadow:0 4px 18px rgba(0,229,255,0.45); transition:all 0.2s; letter-spacing:0.5px; text-transform:uppercase;">
                                ⚡ กดทดสอบทอยลูกเต๋า (Roll Dice Simulator)
                            </button>

                            <!-- Forced Face Buttons for testing landing on each number -->
                            <div style="display:flex; gap:6px; justify-content:center; align-items:center; margin-top:10px; flex-wrap:wrap;">
                                <span style="font-size:11px; color:#cbd5e1;">ทดสอบออกแต้ม:</span>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#334155; color:#fff;" onclick="rollDiceSimulator(0)">🎲 สุ่ม</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(1)">แต้ม 1</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(2)">แต้ม 2</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(3)">แต้ม 3</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(4)">แต้ม 4</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(5)">แต้ม 5</button>
                                <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#1e293b; color:#ffd700;" onclick="rollDiceSimulator(6)">แต้ม 6</button>
                            </div>

                            <!-- Roll Outcome Banner -->
                            <div id="roll_simulation_result_box" style="margin-top:12px; background:rgba(15,23,42,0.9); border:1px solid rgba(0,229,255,0.4); border-radius:10px; padding:10px 14px; text-align:left; display:none;">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                    <div style="font-size:18px; font-weight:900; color:#ffd700;" id="res_roll_score_text">🎲 ได้แต้ม 6</div>
                                    <div id="res_roll_ctrl_badge" style="background:rgba(16,185,129,0.25); border:1px solid #10b981; color:#34d399; font-size:11.5px; font-weight:800; padding:2px 8px; border-radius:4px;">🎯 คุมเต๋าติดสำเร็จ (Triggered!)</div>
                                </div>
                                <div style="font-size:12px; color:#cbd5e1; line-height:1.6;" id="res_roll_detail_text">
                                    การคำนวณ: สุ่มได้ 45.2% &le; อัตราคุมเต๋า 85.00% &rarr; ควบคุมแต้มเป้าหมายแม่นยำ 100%
                                </div>
                            </div>
                        </div>

                        <!-- Quick Existing Dice Cards Gallery -->
                        <div style="margin-top:18px; text-align:left;">
                            <div style="font-size:12px; font-weight:700; color:#38bdf8; margin-bottom:8px;">
                                📋 ลูกเต๋าที่มีในระบบปัจจุบัน (คลิกเพื่อโหลดมาแก้ไขใน Studio):
                            </div>
                            <div id="ai_dice_gallery_list" style="display:flex; gap:8px; overflow-x:auto; padding-bottom:8px;">
                                <!-- Rendered dynamically by JS -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================ -->
        <!-- CARD: DICE GACHA EVENT CAMPAIGN SETUP (จัดกิจกรรมสุ่มลูกเต๋า 3D แยกเฉพาะ) -->
        <!-- ============================================================ -->
        <div class="card" style="margin-top:20px; border:2px solid #a855f7; box-shadow:0 0 25px rgba(168,85,247,0.15);">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:14px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0; color:#c084fc;">🎯 จัดกิจกรรมสุ่มลูกเต๋า 3D & เรตอัป (Dice Gacha & Campaign Events)</h2>
                    <p style="color:var(--text-muted); font-size:13px; margin-top:4px; margin-bottom:0;">
                        กำหนดกิจกรรมสุ่มลูกเต๋าแยกเฉพาะหน้าลูกเต๋า: เลือกลูกเต๋าเป้าหมาย, กำหนดราคาเพชร, เพิ่มโอกาสเรตอัป %, แก้ไข และลบกิจกรรมได้อย่างอิสระ ไม่ต้องรวมกับกิจกรรมกรอบรูป
                    </p>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <button type="button" class="btn" style="padding:8px 14px; font-size:12px; background:linear-gradient(135deg, #7c3aed, #a855f7); color:#fff; font-weight:800;" onclick="resetDiceEventForm()">
                        ✨ สร้างกิจกรรมสุ่มลูกเต๋าใหม่
                    </button>
                    <button type="button" class="btn" style="padding:8px 12px; font-size:12px; background:#0284c7; color:#fff;" onclick="loadDiceEventsAdmin()">
                        🔄 รีเฟรชรายการ
                    </button>
                </div>
            </div>

            <!-- Active Dice Event Highlight Card -->
            <div id="active_dice_event_overview_card" style="background:radial-gradient(ellipse at center, rgba(30,41,59,0.95), rgba(15,23,42,0.98)); border:2px solid #38bdf8; border-radius:14px; padding:18px; margin-bottom:20px; box-shadow:0 0 20px rgba(56,189,248,0.2);">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span id="active_dice_ev_status_badge" style="background:rgba(16,185,129,0.2); border:1.5px solid #10b981; color:#34d399; font-weight:800; padding:4px 12px; border-radius:20px; font-size:12px;">
                            🟢 กำลังจัดกิจกรรม (LIVE NOW)
                        </span>
                        <h3 id="active_dice_ev_name" style="margin:0; font-size:17px; font-weight:800; color:#fff;">-</h3>
                    </div>
                    <div style="display:flex; gap:8px; align-items:center;">
                        <button type="button" id="btn_toggle_active_dice_ev" class="btn btn-danger" style="padding:6px 12px; font-size:12px;" onclick="toggleActiveDiceEventFromOverview()">
                            ⏸️ พัก/ปิดกิจกรรมนี้
                        </button>
                        <button type="button" class="btn" style="padding:6px 12px; font-size:12px; background:#0284c7; color:#fff;" onclick="editCurrentActiveDiceEvent()">
                            ✏️ แก้ไขกิจกรรมนี้
                        </button>
                    </div>
                </div>

                <div class="grid-2" style="gap:16px; align-items:center;">
                    <!-- Target Dice Highlight Preview -->
                    <div style="display:flex; align-items:center; gap:16px; background:rgba(15,23,42,0.7); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:12px;">
                        <div id="active_dice_ev_swatch" style="width:52px; height:52px; border-radius:12px; background:#1e1b4b; border:2.5px solid #00e5ff; box-shadow:0 0 18px #00e5ff; display:flex; align-items:center; justify-content:center; color:#00e5ff; font-size:22px; font-weight:900;">
                            🎲
                        </div>
                        <div>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <span id="active_dice_ev_grade" style="background:#ffd700; color:#000; font-weight:900; font-size:11px; padding:2px 6px; border-radius:4px;">SS+</span>
                                <strong id="active_dice_ev_target_name" style="font-size:15px; color:#fff;">ลูกเต๋าเป้าหมาย</strong>
                            </div>
                            <div style="font-size:12px; color:#38bdf8; margin-top:4px;">
                                ค่าพลังคุมเต๋า: <span id="active_dice_ev_ctrl">85%</span> &bull; แสงเออร่า: <span id="active_dice_ev_aura">cyan (100%)</span>
                            </div>
                        </div>
                    </div>

                    <!-- Event Parameters Snapshot -->
                    <div style="font-size:12.5px; color:#cbd5e1; line-height:1.8;">
                        <div>💎 <strong>ราคาเปิดสุ่ม:</strong> <span id="active_dice_ev_cost" style="color:#00e5ff; font-weight:800;">100 เพชร</span> / ครั้ง</div>
                        <div>⚡ <strong>อัตราเพิ่มโอกาสเรตอัป:</strong> <span id="active_dice_ev_boost" style="color:#ffd700; font-weight:800;">+35.00%</span> (ออกง่ายขึ้น)</div>
                        <div>📅 <strong>ระยะเวลากิจกรรม:</strong> <span id="active_dice_ev_period" style="color:#94a3b8;">-</span></div>
                    </div>
                </div>

                <!-- 5 Shadow Cards Exchange Preview (A ถึง S) -->
                <div style="margin-top:14px; border-top:1px dashed rgba(255,255,255,0.12); padding-top:12px;">
                    <div style="font-size:12px; font-weight:700; color:#38bdf8; margin-bottom:8px; display:flex; align-items:center; gap:6px;">
                        <span>🔮 การ์ดเงา A ถึง S (5 เงา) ที่ต้องสะสมเพื่อแลกลูกเต๋า:</span>
                        <span style="font-size:11px; background:rgba(0,229,255,0.15); color:#00e5ff; padding:1px 6px; border-radius:3px;">สะสมครบแลกได้ทันที</span>
                    </div>
                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr)); gap:8px;">
                        <div style="background:rgba(100,116,139,0.2); border:1px solid #94a3b8; border-radius:8px; padding:8px; text-align:center;">
                            <div style="font-size:11px; color:#cbd5e1; font-weight:700;">⬛ เงาดำ (A)</div>
                            <div style="font-size:14px; font-weight:900; color:#ffd700; margin:2px 0;"><span id="active_dice_req_black">15</span> ใบ</div>
                            <div style="font-size:10px; color:#94a3b8;">ออก: <span id="active_dice_rate_black">90%</span></div>
                        </div>
                        <div style="background:rgba(239,68,68,0.2); border:1px solid #ef4444; border-radius:8px; padding:8px; text-align:center;">
                            <div style="font-size:11px; color:#fca5a5; font-weight:700;">🟥 เงาแดง (A)</div>
                            <div style="font-size:14px; font-weight:900; color:#ffd700; margin:2px 0;"><span id="active_dice_req_red">15</span> ใบ</div>
                            <div style="font-size:10px; color:#fca5a5;">ออก: <span id="active_dice_rate_red">80%</span></div>
                        </div>
                        <div style="background:rgba(255,136,0,0.2); border:1px solid #ff8800; border-radius:8px; padding:8px; text-align:center;">
                            <div style="font-size:11px; color:#fdba74; font-weight:700;">🟧 เงาส้ม (A)</div>
                            <div style="font-size:14px; font-weight:900; color:#ffd700; margin:2px 0;"><span id="active_dice_req_orange">15</span> ใบ</div>
                            <div style="font-size:10px; color:#fdba74;">ออก: <span id="active_dice_rate_orange">70%</span></div>
                        </div>
                        <div style="background:rgba(56,189,248,0.2); border:1px solid #38bdf8; border-radius:8px; padding:8px; text-align:center;">
                            <div style="font-size:11px; color:#38bdf8; font-weight:700;">🟦 เงาฟ้า (A+)</div>
                            <div style="font-size:14px; font-weight:900; color:#ffd700; margin:2px 0;"><span id="active_dice_req_blue">10</span> ใบ</div>
                            <div style="font-size:10px; color:#38bdf8;">ออก: <span id="active_dice_rate_blue">50%</span></div>
                        </div>
                        <div style="background:rgba(255,215,0,0.2); border:1px solid #ffd700; border-radius:8px; padding:8px; text-align:center;">
                            <div style="font-size:11px; color:#ffd700; font-weight:700;">🟨 เงาทอง (S)</div>
                            <div style="font-size:14px; font-weight:900; color:#ffd700; margin:2px 0;"><span id="active_dice_req_gold">4</span> ใบ</div>
                            <div style="font-size:10px; color:#ffd700;">ออก: <span id="active_dice_rate_gold">10%</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form: ตั้งค่า / แก้ไข กิจกรรมสุ่มลูกเต๋า -->
            <form id="diceEventCampaignForm" onsubmit="submitSaveDiceEvent(event)" style="background:rgba(15,23,42,0.6); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:18px; margin-bottom:20px;">
                <input type="hidden" id="dice_ev_id" value="0">
                
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:10px;">
                    <h3 id="dice_ev_form_title" style="margin:0; font-size:15px; color:#ffd700;">📝 ฟอร์มสร้าง / แก้ไขกิจกรรมสุ่มลูกเต๋า</h3>
                    <span id="dice_ev_form_mode_badge" style="font-size:11.5px; background:rgba(168,85,247,0.2); color:#c084fc; padding:2px 8px; border-radius:4px; font-weight:700;">โหมด: สร้างใหม่</span>
                </div>

                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>ชื่อกิจกรรมสุ่มลูกเต๋า *</label>
                        <input type="text" id="dice_ev_name" value="🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป" required>
                    </div>
                    <div class="form-group">
                        <label>จำนวนเพชรที่ใช้สุ่มต่อ 1 ครั้ง (Diamond Cost) *</label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="number" id="dice_ev_cost_diamond" value="100" min="1" required style="flex:1;">
                            <button type="button" class="btn" style="padding:10px 12px; font-size:12px; white-space:nowrap;" onclick="document.getElementById('dice_ev_cost_diamond').value=50;">💎 50</button>
                            <button type="button" class="btn btn-accent" style="padding:10px 12px; font-size:12px; white-space:nowrap;" onclick="document.getElementById('dice_ev_cost_diamond').value=100;">💎 100</button>
                            <button type="button" class="btn" style="padding:10px 12px; font-size:12px; white-space:nowrap; background:#0284c7; color:#fff;" onclick="document.getElementById('dice_ev_cost_diamond').value=200;">💎 200</button>
                        </div>
                    </div>
                </div>

                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>🎯 เลือกลูกเต๋าที่จะใช้จัดกิจกรรม (Target Dice เรตอัป) *</label>
                        <select id="dice_ev_target_dice_id" onchange="previewSelectedEventDice(this.value)" style="border-color:#00e5ff; color:#00e5ff; font-weight:700;">
                            <option value="1">กำลังโหลดรายการลูกเต๋า...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>อัตราเพิ่มโอกาสได้รับลูกเต๋าเป้าหมายเรตอัป (Rate-Up Boost %)</label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="number" id="dice_ev_rate_target_boost" value="35.0" step="0.5" min="1" max="100" style="flex:1;">
                            <span style="font-size:12px; color:var(--text-muted);">เช่น +35% ให้เต๋าเป้าหมายออกง่ายขึ้น</span>
                        </div>
                    </div>
                </div>

                <!-- 5 Shadow Cards Settings (A ถึง S จำนวน 5 เงา เพื่อไปสุ่มและสะสมแลกลูกเต๋า) -->
                <div style="margin: 16px 0 18px 0; background:rgba(0,0,0,0.25); border:1.5px solid rgba(56,189,248,0.3); border-radius:10px; padding:14px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:6px;">
                        <h4 style="margin:0; font-size:13.5px; color:#38bdf8; font-weight:800;">🔮 กำหนดเงา A ถึง S (5 เงา) อัตราออก (%) และจำนวนที่ต้องสะสมเพื่อแลกลูกเต๋า:</h4>
                        <span style="font-size:11px; color:#cbd5e1;">ผู้เล่นสามารถสุ่มรับเงาเหล่านี้เพื่อนำไปแลกลูกเต๋าใน Shop</span>
                    </div>

                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(185px, 1fr)); gap:12px;">
                        <!-- 1. Black A -->
                        <div style="background:rgba(100,116,139,0.15); border:1.5px solid #94a3b8; border-radius:10px; padding:10px;">
                            <label style="color:#cbd5e1; font-weight:800; font-size:12px;">⬛ เงาสีดำ (เกรด A)</label>
                            <div style="display:flex; gap:6px; margin-top:6px;">
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#94a3b8;">% ออก:</span>
                                    <input type="number" id="dice_ev_rate_black" value="90.0" step="0.1" min="0" max="100" style="padding:6px; font-size:12px;">
                                </div>
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#94a3b8;">ต้องสะสม:</span>
                                    <input type="number" id="dice_ev_req_black" value="15" min="1" max="100" style="padding:6px; font-size:12px; color:#ffd700; font-weight:800;">
                                </div>
                            </div>
                        </div>

                        <!-- 2. Red A -->
                        <div style="background:rgba(239,68,68,0.15); border:1.5px solid #ef4444; border-radius:10px; padding:10px;">
                            <label style="color:#ef4444; font-weight:800; font-size:12px;">🟥 เงาสีแดง (เกรด A)</label>
                            <div style="display:flex; gap:6px; margin-top:6px;">
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fca5a5;">% ออก:</span>
                                    <input type="number" id="dice_ev_rate_red" value="80.0" step="0.1" min="0" max="100" style="padding:6px; font-size:12px;">
                                </div>
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fca5a5;">ต้องสะสม:</span>
                                    <input type="number" id="dice_ev_req_red" value="15" min="1" max="100" style="padding:6px; font-size:12px; color:#ffd700; font-weight:800;">
                                </div>
                            </div>
                        </div>

                        <!-- 3. Orange A -->
                        <div style="background:rgba(255,136,0,0.15); border:1.5px solid #ff8800; border-radius:10px; padding:10px;">
                            <label style="color:#ff8800; font-weight:800; font-size:12px;">🟧 เงาสีส้ม (เกรด A)</label>
                            <div style="display:flex; gap:6px; margin-top:6px;">
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fdba74;">% ออก:</span>
                                    <input type="number" id="dice_ev_rate_orange" value="70.0" step="0.1" min="0" max="100" style="padding:6px; font-size:12px;">
                                </div>
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fdba74;">ต้องสะสม:</span>
                                    <input type="number" id="dice_ev_req_orange" value="15" min="1" max="100" style="padding:6px; font-size:12px; color:#ffd700; font-weight:800;">
                                </div>
                            </div>
                        </div>

                        <!-- 4. Blue A+ -->
                        <div style="background:rgba(56,189,248,0.15); border:1.5px solid #38bdf8; border-radius:10px; padding:10px;">
                            <label style="color:#38bdf8; font-weight:800; font-size:12px;">🟦 เงาสีฟ้า (เกรด A+)</label>
                            <div style="display:flex; gap:6px; margin-top:6px;">
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#bae6fd;">% ออก:</span>
                                    <input type="number" id="dice_ev_rate_blue" value="50.0" step="0.1" min="0" max="100" style="padding:6px; font-size:12px;">
                                </div>
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#bae6fd;">ต้องสะสม:</span>
                                    <input type="number" id="dice_ev_req_blue" value="10" min="1" max="100" style="padding:6px; font-size:12px; color:#ffd700; font-weight:800;">
                                </div>
                            </div>
                        </div>

                        <!-- 5. Gold S -->
                        <div style="background:rgba(255,215,0,0.15); border:1.5px solid #ffd700; border-radius:10px; padding:10px;">
                            <label style="color:#ffd700; font-weight:800; font-size:12px;">🟨 เงาสีทอง (เกรด S)</label>
                            <div style="display:flex; gap:6px; margin-top:6px;">
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fef08a;">% ออก:</span>
                                    <input type="number" id="dice_ev_rate_gold" value="10.0" step="0.1" min="0" max="100" style="padding:6px; font-size:12px;">
                                </div>
                                <div style="flex:1;">
                                    <span style="font-size:11px; color:#fef08a;">ต้องสะสม:</span>
                                    <input type="number" id="dice_ev_req_gold" value="4" min="1" max="100" style="padding:6px; font-size:12px; color:#ffd700; font-weight:800;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid-2" style="gap: 16px;">
                    <div class="form-group">
                        <label>วันที่เริ่มต้นกิจกรรม</label>
                        <input type="datetime-local" id="dice_ev_start_date">
                    </div>
                    <div class="form-group">
                        <label>วันที่สิ้นสุดกิจกรรม</label>
                        <input type="datetime-local" id="dice_ev_end_date">
                    </div>
                </div>

                <div class="form-group">
                    <label>คำอธิบายกิจกรรม / รางวัลไฮไลต์</label>
                    <textarea id="dice_ev_description" rows="2">เปิดสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับลูกเต๋าเป้าหมายเรตอัป พร้อมเอฟเฟกต์แสงเออร่าและพลังการคุมเต๋าขั้นสูงสุด</textarea>
                </div>

                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; flex-wrap:wrap; gap:10px;">
                    <label style="display:flex; align-items:center; gap:8px; margin:0; cursor:pointer;">
                        <input type="checkbox" id="dice_ev_is_active" checked style="width:18px; height:18px;">
                        <span style="font-size:13px; font-weight:700; color:#34d399;">🟢 เปิดใช้งานกิจกรรมสุ่มลูกเต๋านี้ทันที (Active)</span>
                    </label>

                    <div style="display:flex; gap:10px;">
                        <button type="button" class="btn" style="padding:10px 16px; font-size:13px; background:#334155; color:#fff;" onclick="resetDiceEventForm()">
                            🔄 ล้างฟอร์ม
                        </button>
                        <button type="button" id="btn_delete_dice_ev" class="btn btn-danger" style="display:none; padding:10px 16px; font-size:13px;" onclick="deleteDiceEventFromForm()">
                            🗑️ ลบกิจกรรมนี้
                        </button>
                        <button type="submit" class="btn btn-accent" style="padding:10px 24px; font-size:14px; font-weight:800; background:linear-gradient(135deg, #0284c7, #00e5ff); color:#000;">
                            💾 บันทึกกิจกรรมลูกเต๋า
                        </button>
                    </div>
                </div>
            </form>

            <!-- Table: ประวัติและรายการกิจกรรมสุ่มลูกเต๋าทั้งหมด -->
            <div style="margin-top:10px;">
                <h3 style="margin:0 0 10px 0; font-size:15px; color:#cbd5e1;">📋 รายการกิจกรรมสุ่มลูกเต๋าทั้งหมด (คลิกเพื่อแก้ไข หรือลบกิจกรรม)</h3>
                <table style="width:100%;">
                    <thead>
                        <tr>
                            <th>รหัส</th>
                            <th>ชื่อกิจกรรม</th>
                            <th>ลูกเต๋าเป้าหมายเรตอัป</th>
                            <th>ราคาเพชร</th>
                            <th>เงาที่ต้องสะสม (A ถึง S)</th>
                            <th>โบนัสเรตอัป</th>
                            <th>ระยะเวลา</th>
                            <th>สถานะ</th>
                            <th>การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="dice_events_table_body">
                        <!-- Loaded dynamically via JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB: SELL PRICES & CURRENCY CONFIGURATION (กำหนดค่าการขายเป็นเพชร หรือ ทอง) -->
    <div id="tab-sell_prices" class="tab-content">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:14px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">💰 กำหนดค่าการขายไอเทมผู้เล่น (เลือกให้ขายได้เป็น 💎 เพชร หรือ 🪙 ทอง)</h2>
                    <p style="color:var(--text-muted); font-size:13px; margin-top:4px;">
                        ตั้งค่าราคาขายและสกุลเงินที่ผู้เล่นจะได้รับเมื่อกดขาย กรอบรูปโปรไฟล์, ลูกเต๋า 3D และการ์ดเงาวัตถุดิบในหน้าคลังไอเทม (Inventory)
                    </p>
                </div>
                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <label style="display:inline-flex; align-items:center; gap:7px; margin:0; background:rgba(6,182,212,0.12); border:1px solid var(--primary); padding:7px 12px; border-radius:8px; color:#fff; cursor:pointer; font-weight:600; font-size:13px;">
                        <input type="checkbox" id="chk-select-all-sell" checked onchange="toggleSelectAllSellItems(this.checked)" style="width:17px; height:17px; cursor:pointer;">
                        <span>เลือกทั้งหมด</span>
                    </label>
                    <button type="button" class="btn" style="padding:8px 12px; font-size:12px; background:#0284c7; color:#fff;" onclick="setSelectedSellCurrency('DIAMOND')">
                        💎 ตั้งที่เลือกเป็นเพชร
                    </button>
                    <button type="button" class="btn" style="padding:8px 12px; font-size:12px; background:#d97706; color:#fff;" onclick="setSelectedSellCurrency('GOLD')">
                        🪙 ตั้งที่เลือกเป็นทอง
                    </button>
                    <button type="button" class="btn btn-accent" style="padding:8px 18px; font-size:14px; font-weight:700;" onclick="saveSellPrices()">
                        💾 บันทึกทั้งหมด
                    </button>
                </div>
            </div>

            <form id="sellPricesForm" onsubmit="saveSellPrices(event)">
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(340px, 1fr)); gap:18px; margin-bottom:20px;">
                    <!-- 1. Character Frames -->
                    <div style="background:rgba(15,23,42,0.7); border:1px solid var(--panel-border); border-radius:12px; padding:16px;">
                        <h3 style="color:#ffd700; font-size:15px; margin-bottom:12px;">👑 1. ราคาขายกรอบรูปโปรไฟล์ตัวละคร</h3>
                        <div id="sell-group-chars"></div>
                    </div>

                    <!-- 2. 3D Dice -->
                    <div style="background:rgba(15,23,42,0.7); border:1px solid var(--panel-border); border-radius:12px; padding:16px;">
                        <h3 style="color:#38bdf8; font-size:15px; margin-bottom:12px;">🎲 2. ราคาขายลูกเต๋า 3D</h3>
                        <div id="sell-group-dice"></div>
                    </div>

                    <!-- 3. Shadow Cards & Special Card -->
                    <div style="background:rgba(15,23,42,0.7); border:1px solid var(--panel-border); border-radius:12px; padding:16px;">
                        <h3 style="color:#c084fc; font-size:15px; margin-bottom:12px;">🃏 3. ราคาขายการ์ดเงา 5 สี & การ์ดพิเศษ (ต่อ 1 ใบ)</h3>
                        <div id="sell-group-materials"></div>
                    </div>
                </div>

                <button type="submit" class="btn btn-accent" style="width:100%; padding:14px; font-size:16px; font-weight:700;">
                    💾 บันทึกค่าการขายไอเทมทั้งหมด (มีผลในคลังผู้เล่นทันที)
                </button>
            </form>
        </div>
    </div>

    <!-- TAB 1: EVENTS -->
    <div id="tab-events" class="tab-content active">
        <div class="grid-2">
            <div class="card">
                <h2>สร้างกิจกรรมใหม่ (Event)</h2>
                <form id="createEventForm">
                    <div class="form-group">
                        <label>ชื่อกิจกรรม</label>
                        <input type="text" name="title" placeholder="เช่น ฉลองเปิดเซิร์ฟ แจกทองและเพชร" required>
                    </div>
                    <div class="form-group">
                        <label>คำอธิบายกิจกรรม</label>
                        <textarea name="description" rows="2" placeholder="รายละเอียดกิจกรรม..."></textarea>
                    </div>
                    <div class="grid-2" style="gap: 12px;">
                        <div class="form-group">
                            <label>แจกเพชร (Diamonds)</label>
                            <input type="number" name="reward_diamond" value="300" min="0">
                        </div>
                        <div class="form-group">
                            <label>แจกทอง (Gold)</label>
                            <input type="number" name="reward_gold" value="50000" min="0">
                        </div>
                    </div>
                    <div class="grid-2" style="gap: 12px;">
                        <div class="form-group">
                            <label>ประเภทกิจกรรม</label>
                            <select name="event_type">
                                <option value="ADMIN_GIVEAWAY">ADMIN_GIVEAWAY (กดรับฟรีทุกคน)</option>
                                <option value="PROMO_CODE">PROMO_CODE (ต้องกรอกโค้ด)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>โค้ดรับรางวัล (ถ้ามี)</label>
                            <input type="text" name="promo_code" placeholder="เช่น SNAKE3D2026">
                        </div>
                    </div>
                    <button type="button" class="btn" onclick="submitCreateEvent()">บันทึกและเปิดกิจกรรม</button>
                </form>
            </div>

            <div class="card">
                <h2>รายการกิจกรรมล่าสุด</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ชื่อกิจกรรม</th>
                            <th>ของรางวัล</th>
                            <th>โค้ด</th>
                            <th>สถานะ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($events as $ev): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($ev['title']) ?></strong></td>
                            <td>
                                <span class="badge badge-dia">💎 <?= number_format((int)$ev['reward_diamond']) ?></span>
                                <span class="badge badge-gold">🪙 <?= number_format((int)$ev['reward_gold']) ?></span>
                            </td>
                            <td><?= $ev['promo_code'] ? '<code>'.htmlspecialchars($ev['promo_code']).'</code>' : '-' ?></td>
                            <td><?= $ev['is_active'] ? '<span style="color:var(--success)">เปิดใช้งาน</span>' : 'ปิด' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB: SHOP MENUS & SHOWCASE BUILDER -->
    <div id="tab-shop_menus" class="tab-content">
        <div class="card" style="margin-bottom:20px; background:linear-gradient(135deg, rgba(30,58,138,0.45), rgba(15,23,42,0.9)); border:1px solid rgba(96,165,250,0.4);">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <div>
                    <h2 style="margin:0; color:#fde047; font-size:20px;">🏪 จัดการเมนูร้านค้า & การ์ดโชว์เคส (Video-Style Shop Builder)</h2>
                    <p style="margin:4px 0 0 0; color:#cbd5e1; font-size:13px;">เพิ่ม/แก้ไขหมวดหมู่เมนูฝั่งซ้ายของหน้าร้านค้า (เพชร • ทอง • การ์ดกรอบ • ลูกเต๋า • PICK UP • เมนูโปรโมชั่นใหม่) พร้อมสร้างการ์ดสินค้าแนวตั้งและปรับราคาขายตรงได้ทันที</p>
                </div>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <button type="button" class="btn" onclick="window.loadAdminShopMenusTab()" style="background:rgba(56,189,248,0.2); color:#38bdf8; border:1px solid rgba(56,189,248,0.45);">🔄 รีเฟรชข้อมูล</button>
                    <a href="../index.html" target="_blank" class="btn btn-accent" style="text-decoration:none;">🎮 เปิดหน้าร้านค้าในเกม</a>
                </div>
            </div>
        </div>

        <!-- Section 1: Left Sidebar Menus Builder + Live Preview -->
        <div class="grid-2" style="margin-bottom:22px; align-items:start;">
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <h2 id="smenu_form_title" style="margin:0; color:#38bdf8;">➕ เพิ่มเมนูร้านค้าใหม่ (แถบเมนูฝั่งซ้าย)</h2>
                    <button type="button" class="btn" style="padding:5px 10px; font-size:12px;" onclick="window.resetShopMenuForm()">ล้างฟอร์ม</button>
                </div>
                <form id="shopMenuForm" onsubmit="window.submitSaveShopMenuAdmin(event)">
                    <input type="hidden" id="smenu_id" value="0">
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>ชื่อเมนูร้านค้า (แสดงบนปุ่มฝั่งซ้าย)</label>
                            <input type="text" id="smenu_title" placeholder="เช่น ร้านค้า VIP / โปรโมชั่นวันหยุด" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสอ้างอิงเมนู (Slug ภาษาอังกฤษ - เว้นว่างให้สร้างอัตโนมัติได้)</label>
                            <input type="text" id="smenu_slug" placeholder="เช่น vip_special">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>ไอคอนเมนู (Emoji)</label>
                            <input type="text" id="smenu_icon" value="🏪" placeholder="🏪 / 💎 / 🪙 / 👑 / 🎲">
                        </div>
                        <div class="form-group">
                            <label>รูปแบบการแสดงผลของเมนู (Menu Type)</label>
                            <select id="smenu_type">
                                <option value="CUSTOM">✨ เมนูโปรโมชั่นกำหนดเอง (แสดงการ์ดสินค้าที่สร้างด้านล่าง)</option>
                                <option value="FEATURED">🔥 ร้านค้าแนะนำ (รวมแพ็กเกจสุดฮิต + 1+1)</option>
                                <option value="DIAMOND">💎 ร้านค้าเพชร (เชื่อมต่อแพ็กเกจเติมเพชร & ดูโฆษณาเพชรฟรี)</option>
                                <option value="GOLD">🪙 ร้านค้าทอง (แลกเพชรเป็นทอง & แพ็กเกจทอง)</option>
                                <option value="FRAME">👑 การ์ดกรอบตัวละคร (ดึงกรอบทั้งหมดมาแสดงเป็นการ์ดสูง)</option>
                                <option value="DICE">🎲 ลูกเต๋า 3D (ดึงลูกเต๋าทั้งหมดมาแสดงเป็นการ์ดสูง)</option>
                                <option value="PICKUP_FRAME">🌟 PICK UP การ์ดกรอบ (แบนเนอร์สุ่มกรอบ SS+)</option>
                                <option value="PICKUP_DICE">⚡ PICK UP ลูกเต๋า (แบนเนอร์สุ่มลูกเต๋า 3D)</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>แท็บย่อยด้านบน (คั่นด้วยเครื่องหมายจุลภาค , เช่น โปรโมชั่นจำกัด, แพ็กเกจรายวัน)</label>
                        <input type="text" id="smenu_subtabs" value="โปรโมชั่นจำกัด, แพ็กเกจสุดคุ้ม" placeholder="แท็บย่อย 1, แท็บย่อย 2">
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>ป้ายกำกับมุมปุ่ม (Badge เช่น HOT / NEW / 1+1 หรือเว้นว่าง)</label>
                            <input type="text" id="smenu_badge" value="NEW" placeholder="HOT / NEW / SALE">
                        </div>
                        <div class="grid-2" style="gap:10px;">
                            <div class="form-group">
                                <label>ลำดับการเรียง (น้อยขึ้นก่อน)</label>
                                <input type="number" id="smenu_sort" value="80">
                            </div>
                            <div class="form-group">
                                <label>สถานะการแสดงผล</label>
                                <select id="smenu_active">
                                    <option value="1">✅ เปิดแสดงในร้านค้า</option>
                                    <option value="0">🚫 ซ่อนชั่วคราว</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-accent" style="width:100%; font-weight:800; padding:11px;">💾 บันทึกเมนูร้านค้า</button>
                </form>

                <!-- Live Sidebar Preview matching Video -->
                <div style="margin-top:18px; padding:14px; border-radius:14px; background:linear-gradient(180deg, #1d4ed8 0%, #1e3a8a 100%); border:2px solid #60a5fa; box-shadow:inset 0 2px 12px rgba(0,0,0,0.35);">
                    <div style="font-size:12px; font-weight:800; color:#bfdbfe; margin-bottom:8px;">👁️ ตัวอย่างแถบเมนูร้านค้าฝั่งซ้าย (ตามแบบคลิป):</div>
                    <div id="adm_shop_sidebar_preview" style="max-width:260px;"></div>
                </div>
            </div>

            <div class="card">
                <h2 style="margin-top:0; color:#fde047;">📋 รายการเมนูร้านค้าทั้งหมดในระบบ</h2>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>เมนูร้านค้า</th>
                                <th>ประเภท</th>
                                <th>แท็บย่อยด้านบน</th>
                                <th>ป้าย</th>
                                <th>ลำดับ</th>
                                <th>สถานะ</th>
                                <th>จัดการ</th>
                            </tr>
                        </thead>
                        <tbody id="adm_shop_menus_tbody">
                            <tr><td colspan="7" style="text-align:center; color:#94a3b8;">กำลังโหลดเมนูร้านค้า...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Section 2: Custom Tall Showcase Cards Manager -->
        <div class="grid-2" style="margin-bottom:22px; align-items:start;">
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <h2 id="sitem_form_title" style="margin:0; color:#f472b6;">➕ เพิ่มการ์ดสินค้าใหม่เข้าเมนูร้านค้า</h2>
                    <button type="button" class="btn" style="padding:5px 10px; font-size:12px;" onclick="window.resetShopCustomItemForm()">ล้างฟอร์ม</button>
                </div>
                <form id="shopCustomItemForm" onsubmit="window.submitSaveShopCustomItemAdmin(event)">
                    <input type="hidden" id="sitem_id" value="0">
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>เลือกเมนูร้านค้าที่จะนำไปวางแสดง</label>
                            <select id="sitem_menu_slug"></select>
                        </div>
                        <div class="form-group">
                            <label>ชื่อแท็บย่อย (เว้นว่าง = แสดงทุกแท็บย่อยในเมนูนั้น)</label>
                            <input type="text" id="sitem_subtab" placeholder="เช่น โปรโมชั่นจำกัด">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>ชื่อการ์ดสินค้า / แพ็กเกจ</label>
                            <input type="text" id="sitem_title" placeholder="เช่น กล่องสุ่มมหาเศรษฐี 1+1" required>
                        </div>
                        <div class="form-group">
                            <label>คำอธิบายสั้นใต้ชื่อการ์ด</label>
                            <input type="text" id="sitem_subtitle" placeholder="เช่น รับเพชร + ทอง + การ์ดกรอบทันที">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>โทนสีการ์ดแนวตั้ง (เหมือนในคลิป)</label>
                            <select id="sitem_theme">
                                <option value="pink">🌸 ชมพู (Pink Showcase)</option>
                                <option value="purple">🔮 ม่วง (Purple Showcase)</option>
                                <option value="blue">💎 ฟ้าคราม (Royal Blue Showcase)</option>
                                <option value="gold">👑 ทองอร่าม (Gold VIP Showcase)</option>
                                <option value="green">🍀 เขียวมรกต (Emerald Showcase)</option>
                                <option value="crimson">🔥 แดงเพลิง (Crimson Showcase)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>ป้ายมุมการ์ด (เช่น 1+1 / HOT / VIP / SALE)</label>
                            <input type="text" id="sitem_badge" value="1+1" placeholder="1+1 / HOT / LIMITED">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>💎 เพชรที่ผู้เล่นจะได้รับ</label>
                            <input type="number" id="sitem_reward_dia" value="0" min="0">
                        </div>
                        <div class="form-group">
                            <label>🪙 ทองที่ผู้เล่นจะได้รับ</label>
                            <input type="number" id="sitem_reward_gold" value="1000000" min="0" step="1000">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>👑 แถมการ์ดกรอบตัวละครถาวร (ถ้ามี)</label>
                            <select id="sitem_ref_char_id"><option value="0">-- ไม่แถมการ์ดกรอบ --</option></select>
                        </div>
                        <div class="form-group">
                            <label>🎲 แถมลูกเต๋า 3D ถาวร (ถ้ามี)</label>
                            <select id="sitem_ref_dice_id"><option value="0">-- ไม่แถมลูกเต๋า --</option></select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>🖼️ รูปไอคอนสินค้า (URL หรืออัปโหลดไฟล์ PNG/JPG - เว้นว่างให้ระบบใช้ไอคอนอัตโนมัติได้)</label>
                        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                            <input type="text" id="sitem_image_url" placeholder="วาง URL รูปภาพ หรือเลือกไฟล์ด้านขวา..." style="flex:1; min-width:180px;">
                            <input type="file" accept="image/*" onchange="window.handleShopItemImageFile(event)" style="max-width:210px; font-size:12px;">
                            <img id="sitem_image_preview" src="" alt="preview" style="display:none; width:46px; height:46px; object-fit:contain; border-radius:8px; border:1px solid rgba(255,255,255,0.25); background:rgba(0,0,0,0.4);">
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>สกุลเงินที่ใช้ซื้อ</label>
                            <select id="sitem_currency">
                                <option value="DIAMOND">💎 ซื้อด้วยเพชร (Diamond)</option>
                                <option value="GOLD">🪙 ซื้อด้วยทอง (Gold)</option>
                                <option value="THB">฿ เงินบาท (เชื่อมระบบชำระเงิน PromptPay/TrueMoney/ShopeePay)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>ราคาขาย</label>
                            <input type="number" step="0.01" id="sitem_price" value="199" min="0" required>
                        </div>
                    </div>
                    <div class="grid-2" style="gap:12px;">
                        <div class="form-group">
                            <label>จำกัดจำนวนซื้อต่อคน (0 = ไม่จำกัด)</label>
                            <input type="number" id="sitem_limit" value="3" min="0">
                        </div>
                        <div class="grid-2" style="gap:10px;">
                            <div class="form-group">
                                <label>ลำดับการ์ด</label>
                                <input type="number" id="sitem_sort" value="10">
                            </div>
                            <div class="form-group">
                                <label>สถานะ</label>
                                <select id="sitem_active">
                                    <option value="1">✅ เปิดขาย</option>
                                    <option value="0">🚫 ซ่อน</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-accent" style="width:100%; font-weight:800; padding:11px; background:linear-gradient(135deg,#ec4899,#8b5cf6); color:#fff;">💾 บันทึกการ์ดสินค้าเข้าร้านค้า</button>
                </form>
            </div>

            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                    <h2 style="margin:0; color:#f472b6;">🛍️ รายการการ์ดสินค้าในเมนูร้านค้า</h2>
                    <select id="adm_sitem_filter_menu" onchange="window.filterAdminShopItems(this.value)" style="max-width:230px; padding:6px 10px;"></select>
                </div>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ชื่อการ์ดสินค้า</th>
                                <th>เมนู / แท็บย่อย</th>
                                <th>ของรางวัลที่ได้รับ</th>
                                <th>ราคา</th>
                                <th>จำกัดซื้อ</th>
                                <th>สถานะ</th>
                                <th>จัดการ</th>
                            </tr>
                        </thead>
                        <tbody id="adm_shop_items_tbody">
                            <tr><td colspan="7" style="text-align:center; color:#94a3b8;">กำลังโหลดรายการสินค้า...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Section 3: Quick Price Editor for Built-in Frame Cards & 3D Dice -->
        <div class="grid-2" style="align-items:start;">
            <div class="card">
                <h2 style="margin-top:0; color:#fde047;">👑 ตั้งราคาขายตรง: หมวดการ์ดกรอบตัวละคร</h2>
                <p style="font-size:12px; color:#94a3b8; margin-top:-6px;">ปรับราคาเพชร / ราคาทอง และการเปิดแสดงในเมนู <strong>การ์ดกรอบ</strong> ของหน้าร้านค้า</p>
                <div style="overflow-x:auto; max-height:420px; overflow-y:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>การ์ดกรอบ</th>
                                <th>💎 ราคาเพชร</th>
                                <th>🪙 ราคาทอง</th>
                                <th>สถานะในร้าน</th>
                                <th>บันทึก</th>
                            </tr>
                        </thead>
                        <tbody id="adm_quick_char_prices_tbody"></tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <h2 style="margin-top:0; color:#38bdf8;">🎲 ตั้งราคาขายตรง: หมวดลูกเต๋า 3D</h2>
                <p style="font-size:12px; color:#94a3b8; margin-top:-6px;">ปรับราคาเพชร / ราคาทอง และการเปิดแสดงในเมนู <strong>ลูกเต๋า</strong> ของหน้าร้านค้า</p>
                <div style="overflow-x:auto; max-height:420px; overflow-y:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ลูกเต๋า 3D</th>
                                <th>💎 ราคาเพชร</th>
                                <th>🪙 ราคาทอง</th>
                                <th>สถานะในร้าน</th>
                                <th>บันทึก</th>
                            </tr>
                        </thead>
                        <tbody id="adm_quick_dice_prices_tbody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 2: PACKAGES -->
    <div id="tab-packages" class="tab-content">
        <div class="grid-2">
            <div class="card">
                <h2 id="pkg-form-title">สร้าง/แก้ไขแพ็กเกจเติมเงิน (เช่น 500 เพชร 30 บาท)</h2>
                <form id="pkgForm">
                    <input type="hidden" name="id" id="pkg_id" value="">
                    <div class="form-group">
                        <label>ชื่อแพ็กเกจ</label>
                        <input type="text" name="name" id="pkg_name" value="แพ็กเกจเพชรเริ่มต้น (500 เพชร)" required>
                    </div>
                    <div class="grid-2" style="gap: 12px;">
                        <div class="form-group">
                            <label>ประเภท</label>
                            <select name="type" id="pkg_type">
                                <option value="DIAMOND">DIAMOND (เพชร)</option>
                                <option value="GOLD">GOLD (ทอง)</option>
                                <option value="COMBO">COMBO (เพชร + ทอง)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>ราคา (บาท)</label>
                            <input type="number" step="0.5" name="price_thb" id="pkg_price_thb" value="30.00" required>
                        </div>
                    </div>
                    <div class="grid-2" style="gap: 12px;">
                        <div class="form-group">
                            <label>จำนวนเพชร</label>
                            <input type="number" name="reward_diamond" id="pkg_reward_diamond" value="500">
                        </div>
                        <div class="form-group">
                            <label>จำนวนทอง</label>
                            <input type="number" name="reward_gold" id="pkg_reward_gold" value="0">
                        </div>
                    </div>
                    <div class="form-group" style="margin-bottom: 14px;">
                        <label>สถานะการแสดงในร้านค้า</label>
                        <select name="is_active" id="pkg_is_active">
                            <option value="1">✅ แสดงในร้านค้า (เปิดขาย)</option>
                            <option value="0">❌ ซ่อน (ปิดการขายชั่วคราว)</option>
                        </select>
                    </div>
                    <div style="display:flex; gap:10px; align-items:center;">
                        <button type="button" class="btn btn-accent" id="btn-save-pkg" onclick="submitSavePackage()">
                            ➕ เพิ่มแพ็กเกจในร้านค้า
                        </button>
                        <button type="button" class="btn" id="btn-cancel-pkg" onclick="resetPackageForm()" style="display:none; background:#334155; color:#fff;">
                            ❌ ยกเลิกการแก้ไข
                        </button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>แพ็กเกจเติมเงินในเกมปัจจุบัน</h2>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ชื่อแพ็กเกจ</th>
                                <th>เพชร / ทอง</th>
                                <th>ราคา</th>
                                <th>สถานะ</th>
                                <th style="text-align:center; min-width:140px;">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($packages)): ?>
                            <tr>
                                <td colspan="5" style="text-align:center; padding:20px; color:#94a3b8;">ยังไม่มีแพ็กเกจในร้านค้า</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($packages as $pkg): ?>
                            <tr id="pkg-row-<?= (int)$pkg['id'] ?>">
                                <td><strong style="color:#00e5ff;"><?= htmlspecialchars($pkg['name']) ?></strong></td>
                                <td>
                                    <?php if (!empty($pkg['reward_diamond'])): ?><span class="badge badge-dia">💎 <?= number_format((int)$pkg['reward_diamond']) ?></span><?php endif; ?>
                                    <?php if (!empty($pkg['reward_gold'])): ?><span class="badge badge-gold">🪙 <?= number_format((float)$pkg['reward_gold']) ?></span><?php endif; ?>
                                </td>
                                <td><strong><?= number_format((float)$pkg['price_thb'], 2) ?> บาท</strong></td>
                                <td><?= !empty($pkg['is_active']) ? '<span style="color:#10b981;">✅ แสดงในร้าน</span>' : '<span style="color:#ef4444;">❌ ซ่อน</span>' ?></td>
                                <td style="text-align:center;">
                                    <div style="display:inline-flex; gap:6px;">
                                        <button type="button" class="btn btn-sm" onclick='editPackage(<?= json_encode($pkg, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>)' style="background:rgba(0,229,255,0.15); border:1px solid #00e5ff; color:#00e5ff; padding:4px 10px; border-radius:6px; font-size:12px; cursor:pointer;">
                                            ✏️ แก้ไข
                                        </button>
                                        <button type="button" class="btn btn-sm" onclick="deletePackage(<?= (int)$pkg['id'] ?>, '<?= htmlspecialchars(addslashes($pkg['name'])) ?>')" style="background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#f87171; padding:4px 10px; border-radius:6px; font-size:12px; cursor:pointer;">
                                            🗑️ ลบ
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- 📱 ตั้งค่าระบบชำระเงินผ่านพร้อมเพย์ (PromptPay QR Code Settings) -->
        <div class="card" style="margin-top:16px; border:1.5px solid #00e5ff; background:radial-gradient(circle at 10% 20%, rgba(15,23,42,0.95) 0%, rgba(3,7,18,0.98) 100%);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid rgba(0,229,255,0.3); padding-bottom:8px; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:22px;">📱</span>
                    <div>
                        <h3 style="margin:0; font-size:15px; color:#00e5ff;">ตั้งค่ารับชำระเงินผ่าน PromptPay QR Code</h3>
                        <div style="font-size:11px; color:#94a3b8;">กรอกเบอร์โทรหรือเลขบัตรประชาชนสำหรับสร้าง QR Code รับเงินอัตโนมัติ</div>
                    </div>
                </div>
                <button type="button" class="btn btn-accent" onclick="savePromptPaySettingsFromAdmin()" style="padding:6px 16px; font-size:12px;">💾 บันทึกพร้อมเพย์</button>
            </div>

            <div class="grid-3" style="gap:12px; align-items:start;">
                <div class="form-group">
                    <label style="color:#ffd700;">เบอร์พร้อมเพย์ หรือ เลขบัตรประชาชน</label>
                    <input type="text" id="admin_promptpay_id" value="<?= htmlspecialchars($promptPaySettings['id']) ?>" placeholder="เช่น 0812345678 หรือ 1100200300400" oninput="updateAdminPromptPayPreview()">
                    <small style="color:#94a3b8; font-size:10px;">เบอร์มือถือ 10 หลัก หรือ เลขประจำตัวประชาชน 13 หลัก</small>
                </div>
                <div class="form-group">
                    <label style="color:#ffd700;">ชื่อบัญชีผู้รับเงิน</label>
                    <input type="text" id="admin_promptpay_name" value="<?= htmlspecialchars($promptPaySettings['name']) ?>" placeholder="เช่น นายสมชาย ใจดี" oninput="updateAdminPromptPayPreview()">
                </div>
                <div class="form-group">
                    <label style="color:#ffd700;">ธนาคาร</label>
                    <input type="text" id="admin_promptpay_bank" value="<?= htmlspecialchars($promptPaySettings['bank']) ?>" placeholder="เช่น กสิกรไทย, ไทยพาณิชย์, พร้อมเพย์กลาง">
                </div>
            </div>

            <!-- Live EMVCo PromptPay QR Code Preview -->
            <div style="margin-top:12px; background:rgba(15,23,42,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:12px; display:flex; align-items:center; gap:16px;">
                <div id="admin_promptpay_qr_img" style="width:90px; height:90px; background:#fff; border-radius:8px; padding:4px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                    <img id="admin_promptpay_qr_tag" src="" alt="PromptPay QR" style="width:100%; height:100%; object-fit:contain; display:none;">
                    <span id="admin_promptpay_qr_placeholder" style="font-size:10px; color:#333; text-align:center;">ตัวอย่าง QR</span>
                </div>
                <div>
                    <div style="font-size:13px; font-weight:800; color:#fff;" id="admin_promptpay_preview_name">ชื่อบัญชี: <?= htmlspecialchars($promptPaySettings['name'] ?: '-') ?></div>
                    <div style="font-size:12px; color:#38bdf8;" id="admin_promptpay_preview_id">หมายเลข: <?= htmlspecialchars($promptPaySettings['id'] ?: '-') ?></div>
                    <div style="font-size:11px; color:#10b981; margin-top:2px;">● ระบบสร้าง QR Code มาตรฐาน EMVCo พร้อมใช้งานในแอปเกมทันที</div>
                </div>
            </div>
        </div>

        <!-- 🛍️ ตั้งค่าระบบรับชำระเงินผ่าน ShopeePay (Shopee ID Settings) -->
        <div class="card" style="margin-top:16px; border:1.5px solid #ee4d2d; background:radial-gradient(circle at 10% 20%, rgba(32,14,12,0.96) 0%, rgba(15,5,5,0.98) 100%); box-shadow:0 6px 20px rgba(238,77,45,0.15);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid rgba(238,77,45,0.35); padding-bottom:8px; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:24px;">🛍️</span>
                    <div>
                        <h3 style="margin:0; font-size:15px; color:#ee4d2d;">ตั้งค่ารับชำระเงินผ่าน ShopeePay (Shopee ID Settings)</h3>
                        <div style="font-size:11px; color:#94a3b8;">กรอก Shopee ID / ShopeePay Merchant ID เพื่อรับเงินจากผู้เล่นเข้า ShopeePay โดยตรง</div>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <label style="display:flex; align-items:center; gap:6px; font-size:12px; color:#fff; cursor:pointer; margin:0;">
                        <input type="checkbox" id="admin_shopeepay_active" <?= (!empty($shopeePaySettings['active']) && $shopeePaySettings['active'] === '1') ? 'checked' : '' ?> style="width:16px; height:16px; accent-color:#ee4d2d;">
                        <span>เปิดใช้งาน ShopeePay</span>
                    </label>
                    <button type="button" class="btn" onclick="saveShopeePaySettingsFromAdmin()" style="background:linear-gradient(135deg, #ee4d2d, #ff7337); color:#fff; font-weight:800; padding:6px 16px; font-size:12px; border:none; border-radius:6px; cursor:pointer; box-shadow:0 2px 10px rgba(238,77,45,0.4);">💾 บันทึก ShopeePay</button>
                </div>
            </div>

            <div class="grid-3" style="gap:12px; align-items:start;">
                <div class="form-group">
                    <label style="color:#ff7337;">Shopee ID / บัญชี ShopeePay ผู้รับเงิน</label>
                    <input type="text" id="admin_shopeepay_id" value="<?= htmlspecialchars($shopeePaySettings['id']) ?>" placeholder="เช่น 0891234567 หรือ SHOPEE_MERCHANT_01" oninput="updateAdminShopeePayPreview()">
                    <small style="color:#94a3b8; font-size:10px;">เบอร์โทร ShopeePay, Shopee Username หรือ Merchant ID</small>
                </div>
                <div class="form-group">
                    <label style="color:#ff7337;">ชื่อร้านค้า / ชื่อบัญชี Shopee</label>
                    <input type="text" id="admin_shopeepay_name" value="<?= htmlspecialchars($shopeePaySettings['name']) ?>" placeholder="เช่น Snake & Ladder 3D Official" oninput="updateAdminShopeePayPreview()">
                    <small style="color:#94a3b8; font-size:10px;">ชื่อที่จะแสดงในหน้าต่างสแกนจ่ายเงินของเกม</small>
                </div>
                <div class="form-group">
                    <label style="color:#ff7337;">ลิงก์รูป QR Code รับเงิน Shopee (ถ้ามี)</label>
                    <input type="text" id="admin_shopeepay_qr_url" value="<?= htmlspecialchars($shopeePaySettings['qr_url']) ?>" placeholder="https://... หรือ assets/img/shopee_qr.png" oninput="updateAdminShopeePayPreview()">
                    <small style="color:#94a3b8; font-size:10px;">ใส่ URL รูป QR ของ Shopee หรือเว้นว่างเพื่อให้ระบบสร้าง QR อัตโนมัติ</small>
                </div>
            </div>

            <!-- Live ShopeePay Preview -->
            <div style="margin-top:12px; background:rgba(30,12,10,0.65); border:1px solid rgba(238,77,45,0.3); border-radius:10px; padding:12px; display:flex; align-items:center; gap:16px;">
                <div id="admin_shopeepay_qr_box" style="width:90px; height:90px; background:#fff; border-radius:8px; padding:4px; display:flex; align-items:center; justify-content:center; flex-shrink:0; border:2px solid #ee4d2d;">
                    <img id="admin_shopeepay_qr_tag" src="" alt="ShopeePay QR" style="width:100%; height:100%; object-fit:contain; display:none;">
                    <span id="admin_shopeepay_qr_placeholder" style="font-size:10px; color:#ee4d2d; text-align:center; font-weight:800;">ShopeePay<br>QR</span>
                </div>
                <div>
                    <div style="font-size:13px; font-weight:800; color:#fff;" id="admin_shopeepay_preview_name">ชื่อบัญชี: <?= htmlspecialchars($shopeePaySettings['name'] ?: '-') ?></div>
                    <div style="font-size:12px; color:#ff7337;" id="admin_shopeepay_preview_id">Shopee ID: <?= htmlspecialchars($shopeePaySettings['id'] ?: '-') ?></div>
                    <div style="font-size:11px; color:#10b981; margin-top:2px;">● รองรับการเปิดแอป Shopee / ShopeePay และสแกน QR Code พร้อมตรวจสอบยอดเงินอัตโนมัติ</div>
                </div>
            </div>
        </div>

        <!-- 🌐 ตั้งค่าระบบรับชำระเงินผ่าน PayPal Global -->
        <div class="card" style="margin-top:16px; border:1.5px solid #0284c7; background:radial-gradient(circle at 10% 20%, rgba(15,23,42,0.95) 0%, rgba(3,7,18,0.98) 100%);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid rgba(2,132,199,0.3); padding-bottom:8px; flex-wrap:wrap; gap:8px;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:22px;">🌐</span>
                    <div>
                        <h3 style="margin:0; font-size:15px; color:#38bdf8;">ตั้งค่ารับชำระเงินผ่าน PayPal Global (เงินเข้ากระเป๋า PayPal โดยตรง)</h3>
                        <div style="font-size:11px; color:#94a3b8;">เงินจะเข้าบัญชี PayPal Business ของคุณโดยตรง และสามารถถอนเข้าบัญชีธนาคารไทยได้ตลอดเวลา</div>
                    </div>
                </div>
                <button type="button" class="btn" onclick="savePayPalSettingsFromAdmin()" style="background:linear-gradient(135deg, #0284c7, #00e5ff); color:#000; font-weight:800; padding:6px 16px; font-size:12px; border:none; border-radius:6px; cursor:pointer;">💾 บันทึก PayPal</button>
            </div>

            <div style="background:rgba(2,132,199,0.1); border:1px solid rgba(56,189,248,0.25); border-radius:8px; padding:10px 14px; margin-bottom:12px; font-size:12px; color:#cbd5e1; line-height:1.6;">
                💡 <strong>คำแนะนำ:</strong> ใส่ <strong>PayPal Business Email</strong> ที่คุณใช้รับเงิน หากต้องการเปิดระบบตัดเงินอัตโนมัติ ให้สร้างและใส่ <strong>PayPal Client ID</strong> จากเว็บ developer.paypal.com
            </div>

            <div class="grid-2" style="gap:12px; align-items:start;">
                <div class="form-group">
                    <label style="color:#ffd700;">📧 PayPal Business Email (อีเมลสำหรับรับเงิน)</label>
                    <input type="email" id="admin_paypal_email" value="<?= htmlspecialchars($paypalSettings['email']) ?>" placeholder="เช่น your-business@example.com">
                    <small style="color:#94a3b8; font-size:10px;">อีเมลที่ผู้เล่นจะชำระเงินเข้ากระเป๋า PayPal นี้โดยตรง</small>
                </div>
                <div class="form-group">
                    <label style="color:#ffd700;">🔑 PayPal Client ID (REST API Key - ออปชันเสริม)</label>
                    <input type="text" id="admin_paypal_client_id" value="<?= htmlspecialchars($paypalSettings['client_id']) ?>" placeholder="เช่น AXYZ123... (สร้างฟรีที่ developer.paypal.com)">
                    <small style="color:#94a3b8; font-size:10px;">สำหรับเชื่อมต่อปุ่มชำระเงิน PayPal Smart Buttons</small>
                </div>
            </div>

            <div class="grid-2" style="gap:12px; align-items:center; margin-top:10px;">
                <div class="form-group">
                    <label style="color:#ffd700;">💱 สกุลเงินในบิลชำระเงิน (Currency)</label>
                    <select id="admin_paypal_currency" style="width:100%; padding:8px 10px; background:#0f172a; border:1px solid #334155; border-radius:6px; color:#fff;">
                        <option value="THB" <?= ($paypalSettings['currency'] === 'THB') ? 'selected' : '' ?>>THB — เงินบาทไทย (฿)</option>
                        <option value="USD" <?= ($paypalSettings['currency'] === 'USD') ? 'selected' : '' ?>>USD — United States Dollar ($)</option>
                    </select>
                </div>
                <div class="form-group" style="padding-top:16px;">
                    <label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer; color:#cbd5e1; font-size:12px;">
                        <input type="checkbox" id="admin_paypal_sandbox" <?= ($paypalSettings['sandbox'] === '1') ? 'checked' : '' ?> style="width:16px; height:16px;">
                        <span>เปิดโหมดทดสอบ Sandbox (สำหรับทดสอบระบบ ไม่คิดเงินจริง)</span>
                    </label>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 3: SKILLS -->
    <div id="tab-skills" class="tab-content">
        <div class="card">
            <h2>กำหนดค่าสกิลระบบกลาง (ทอยแม่นยำ / ดึงถอยหลัง 5 หรือ 8 ตา)</h2>
            <table>
                <thead>
                    <tr>
                        <th>รหัสสกิล</th>
                        <th>ชื่อสกิล</th>
                        <th>ประเภท</th>
                        <th>ค่าพลังที่กำหนด (Admin Value)</th>
                        <th>โอกาสติด (%)</th>
                        <th>การจัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($skills as $sk): ?>
                    <tr>
                        <td><code><?= htmlspecialchars($sk['code']) ?></code></td>
                        <td><?= htmlspecialchars($sk['name']) ?></td>
                        <td><?= $sk['target_type'] ?></td>
                        <td>
                            <input type="number" id="sk_power_<?= $sk['id'] ?>" value="<?= $sk['base_power_value'] ?>" style="width: 100px; display: inline-block;">
                            <?= htmlspecialchars($sk['power_unit']) ?>
                        </td>
                        <td>
                            <input type="number" id="sk_chance_<?= $sk['id'] ?>" value="<?= $sk['trigger_chance_percent'] ?>" style="width: 80px; display: inline-block;"> %
                        </td>
                        <td>
                            <button class="btn" style="padding: 6px 12px; font-size: 13px;" onclick="saveSkill(<?= $sk['id'] ?>, '<?= htmlspecialchars($sk['name']) ?>', '<?= $sk['power_unit'] ?>')">💾 อัปเดต</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="grid-2">
            <div class="card">
                <h2>กำหนดค่าพลังตัวละคร 3D (ระยะดึงถอยหลัง)</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ตัวละคร</th>
                            <th>เกรด</th>
                            <th>สกิลหลัก</th>
                            <th>ระยะถอยหลัง (ตา)</th>
                            <th>บันทึก</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($characters as $c): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($c['name']) ?></strong></td>
                            <td><?= $c['grade'] ?></td>
                            <td><?= htmlspecialchars($c['skill_name'] ?? 'ไม่มี') ?></td>
                            <td>
                                <input type="number" id="char_power_<?= $c['id'] ?>" value="<?= $c['custom_power_override'] ?? 5 ?>" style="width: 80px;"> ช่อง
                            </td>
                            <td>
                                <button class="btn" style="padding: 4px 10px;" onclick="saveCharOverride(<?= $c['id'] ?>, <?= $c['skill_id'] ?? 2 ?>)">บันทึก</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; flex-wrap:wrap; gap:10px;">
                    <h2 style="margin:0;">🎲 กำหนดค่าพลังลูกเต๋า 3D & กิจกรรมสุ่มลูกเต๋าเรตอัป</h2>
                    <span style="font-size:12px; color:#38bdf8; background:rgba(56,189,248,0.12); padding:5px 12px; border-radius:6px; border:1px solid rgba(56,189,248,0.3);">
                        🎯 เต๋าเป้าหมายกิจกรรมปัจจุบัน: <strong id="lbl-active-event-dice" style="color:#00e5ff;"><?php
                            $curDiceName = "ลูกเต๋า ID #{$activeGachaTargetDiceId}";
                            foreach ($dice as $_dc) {
                                if ((int)$_dc['id'] === (int)$activeGachaTargetDiceId) {
                                    $curDiceName = $_dc['name'] . " [{$_dc['grade']}]";
                                    break;
                                }
                            }
                            echo htmlspecialchars($curDiceName);
                        ?></strong>
                    </span>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ลูกเต๋า</th>
                            <th>เกรด</th>
                            <th>ความแม่นยำ (%)</th>
                            <th>🎯 จัดกิจกรรมสุ่มเต๋า</th>
                            <th>บันทึกค่าพลัง</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dice as $d): 
                            $isTarget = ((int)$d['id'] === (int)$activeGachaTargetDiceId);
                            $bodyColor = $d['color_hex'] ?? '#1e1b4b';
                            $pipColor = $d['pip_color_hex'] ?? '#ffffff';
                        ?>
                        <tr id="dice-row-<?= $d['id'] ?>">
                            <td>
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <span style="display:inline-block; width:16px; height:16px; border-radius:4px; background:<?= htmlspecialchars($bodyColor) ?>; border:1.5px solid <?= htmlspecialchars($pipColor) ?>; box-shadow:0 0 6px <?= htmlspecialchars($bodyColor) ?>;" title="สีตัวเต๋า & สีจุดแต้ม"></span>
                                    <strong><?= htmlspecialchars($d['name']) ?></strong>
                                </div>
                            </td>
                            <td><span style="background:rgba(255,255,255,0.08); padding:2px 8px; border-radius:4px; font-weight:700; color:#ffd700;"><?= htmlspecialchars($d['grade']) ?></span></td>
                            <td>
                                <input type="number" id="dice_rate_<?= $d['id'] ?>" value="<?= $d['dice_control_rate'] ?>" style="width: 80px;"> %
                            </td>
                            <td>
                                <div id="target-dice-action-<?= $d['id'] ?>">
                                    <?php if ($isTarget): ?>
                                        <span style="background:rgba(16,185,129,0.2); border:1.5px solid #10b981; color:#34d399; font-weight:800; padding:4px 10px; border-radius:6px; font-size:12px; display:inline-flex; align-items:center; gap:5px; box-shadow:0 0 10px rgba(16,185,129,0.3);">
                                            🌟 กำลังเป็นเต๋าเป้าหมายกิจกรรม
                                        </span>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-accent" style="padding:4px 12px; font-size:12px; background:linear-gradient(135deg, #0284c7, #06b6d4);" onclick="setGachaTargetDice(<?= $d['id'] ?>, '<?= htmlspecialchars($d['name'], ENT_QUOTES) ?>')">
                                            🎯 ตั้งเป็นเต๋ากิจกรรม
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div style="display:flex; gap:6px;">
                                    <button type="button" class="btn" style="padding: 4px 8px;" onclick="saveDiceStats(<?= $d['id'] ?>)">บันทึก</button>
                                    <button type="button" class="btn" style="padding: 4px 8px; background:linear-gradient(135deg, #7c3aed, #a855f7); color:#fff;" onclick="switchTab('dice_creator'); loadDiceIntoStudio(<?= $d['id'] ?>);" title="เปิดแก้ไขใน 3D AI Studio">🎨 แต่ง 3D</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB 4: BROADCAST GIVEAWAY -->
    <div id="tab-broadcast" class="tab-content">
        <div class="card" style="max-width: 650px; margin: 0 auto;">
            <h2>ยิงแจกของรางวัลผู้เล่นทั้งเซิร์ฟเวอร์ (Broadcast Giveaway)</h2>
            <p style="color:var(--text-muted); margin-bottom: 16px;">ระบบจะส่งเพชรและทองเข้ากล่องจดหมาย (Mailbox) ของผู้เล่นทุกคนในฐานข้อมูลทันที</p>
            <form id="broadcastForm">
                <div class="form-group">
                    <label>หัวข้อจดหมาย</label>
                    <input type="text" name="title" value="ของขวัญพิเศษฉลองเทศกาลจากทีมงาน Snake 3D" required>
                </div>
                <div class="form-group">
                    <label>ข้อความถึงผู้เล่น</label>
                    <textarea name="message" rows="3" required>ทีมงานขอมอบเพชรและทองพิเศษให้ทุกท่าน ขอให้สนุกกับการทอยเต๋าและชิงชัยในบันไดงู 3D!</textarea>
                </div>
                <div class="grid-2" style="gap: 12px;">
                    <div class="form-group">
                        <label>จำนวนเพชรที่แจกทุกคน</label>
                        <input type="number" name="reward_diamond" value="500" min="0">
                    </div>
                    <div class="form-group">
                        <label>จำนวนทองที่แจกทุกคน</label>
                        <input type="number" name="reward_gold" value="100000" min="0">
                    </div>
                </div>
                <button type="button" class="btn btn-accent" style="width: 100%; padding: 14px; font-size: 16px;" onclick="submitBroadcast()">🚀 แจกให้ผู้เล่นทุกคนทันที</button>
            </form>
        </div>
    </div>

    <!-- TAB 5: PLAYER MANAGEMENT (จัดการและแก้ไขข้อมูลผู้เล่น) -->
    <div id="tab-users" class="tab-content">
        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
                <h2 style="margin: 0; border: none; padding: 0;">👥 จัดการและแก้ไขข้อมูลผู้เล่น (ชื่อ / เพชร / ทอง / เลเวล / แบน)</h2>
                <div style="display: flex; gap: 8px; width: 340px; max-width: 100%;">
                    <input type="text" id="search-user-input" placeholder="ค้นหาชื่อผู้เล่น หรือ LINE/Google ID..." onkeydown="if(event.key==='Enter') searchUsers()">
                    <button class="btn" onclick="searchUsers()">🔍 ค้นหา</button>
                </div>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อผู้เล่น (แก้ไขได้)</th>
                            <th>เพชร (💎)</th>
                            <th>ทอง (🪙)</th>
                            <th>เลเวล</th>
                            <th>สถานะบัญชี</th>
                            <th>บันทึก / จัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="users-table-tbody">
                        <?php foreach ($usersList as $u): ?>
                        <tr id="user-row-<?= (int)$u['id'] ?>">
                            <td><strong>#<?= (int)$u['id'] ?></strong></td>
                            <td>
                                <input type="text" id="u_name_<?= (int)$u['id'] ?>" value="<?= htmlspecialchars($u['username']) ?>" style="min-width: 150px;">
                            </td>
                            <td>
                                <input type="number" id="u_dia_<?= (int)$u['id'] ?>" value="<?= (int)$u['diamond'] ?>" style="width: 110px;">
                            </td>
                            <td>
                                <input type="number" id="u_gold_<?= (int)$u['id'] ?>" value="<?= (int)$u['gold'] ?>" style="width: 130px;">
                            </td>
                            <td>
                                <input type="number" id="u_lvl_<?= (int)$u['id'] ?>" value="<?= (int)$u['level'] ?>" style="width: 75px;" min="1">
                            </td>
                            <td>
                                <select id="u_ban_<?= (int)$u['id'] ?>" style="width: 115px;">
                                    <option value="0" <?= !$u['is_banned'] ? 'selected' : '' ?>>🟢 ปกติ</option>
                                    <option value="1" <?= $u['is_banned'] ? 'selected' : '' ?>>🔴 ระงับ (แบน)</option>
                                </select>
                            </td>
                            <td style="white-space: nowrap;">
                                <button class="btn" style="padding: 6px 12px; font-size: 13px;" onclick="saveUserRow(<?= (int)$u['id'] ?>)">💾 บันทึก</button>
                                <button class="btn btn-danger" style="padding: 6px 10px; font-size: 13px;" onclick="deleteUserRow(<?= (int)$u['id'] ?>, '<?= htmlspecialchars(addslashes($u['username'])) ?>')">🗑️</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB: THAI VOICE & SFX STUDIO (จัดการระบบเสียง & เสียงพากย์ภาษาไทย) -->
    <div id="tab-thai_audio" class="tab-content">
        <div class="card" style="border:1.5px solid #ec4899; background:radial-gradient(circle at 10% 20%, rgba(15,23,42,0.95) 0%, rgba(3,7,18,0.98) 100%);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; border-bottom:1px solid rgba(236,72,153,0.3); padding-bottom:12px; flex-wrap:wrap; gap:12px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <div style="font-size:32px; background:rgba(236,72,153,0.15); width:56px; height:56px; border-radius:14px; display:flex; align-items:center; justify-content:center; border:1px solid #ec4899; box-shadow:0 0 20px rgba(236,72,153,0.3);">🎵</div>
                    <div>
                        <h2 style="margin:0; font-size:18px; color:#f472b6;">สตูดิโอจัดการระบบเสียง & เสียงพากย์เด็กผู้หญิงภาษาไทย (Thai Voice & SFX Studio)</h2>
                        <div style="font-size:12px; color:#94a3b8; margin-top:3px;">
                            ตั้งค่าเสียงพากย์ไทย อัปโหลดไฟล์ MP3/WAV สำหรับแต่ละเหตุการณ์ในเกม ทดลองฟังเสียงสด และเพิ่มเหตุการณ์เสียงใหม่ได้ไม่จำกัด
                        </div>
                    </div>
                </div>
                <div style="display:flex; gap:10px; flex-wrap:wrap; position:relative; z-index:5;">
                    <button type="button" class="btn" onclick="window.openAddAudioEventModal()" style="background:linear-gradient(135deg, #ec4899, #d946ef); color:#fff; font-weight:800; padding:9px 18px; font-size:13px; border:none; border-radius:8px; cursor:pointer; box-shadow:0 0 15px rgba(236,72,153,0.4);">
                        ➕ เพิ่มเหตุการณ์เสียงใหม่
                    </button>
                    <button type="button" class="btn" onclick="window.saveAllAudioEventsAdmin()" style="background:linear-gradient(135deg, #10b981, #059669); color:#fff; font-weight:800; padding:9px 18px; font-size:13px; border:none; border-radius:8px; cursor:pointer;">
                        💾 บันทึกการตั้งค่าเสียง
                    </button>
                    <button type="button" class="btn" onclick="window.resetDefaultAudioEventsAdmin()" style="background:rgba(255,255,255,0.08); color:#cbd5e1; font-weight:700; padding:9px 14px; font-size:12px; border:1px solid rgba(255,255,255,0.18); border-radius:8px; cursor:pointer;" title="กู้คืนรายการเสียงพากย์และเอฟเฟกต์หลักทั้ง 6 รายการ">
                        🔄 คืนค่าเสียงเริ่มต้น
                    </button>
                </div>
            </div>

            <!-- Global Audio Info & Quick Controls -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:14px; margin-bottom:20px;">
                <div style="background:rgba(236,72,153,0.08); border:1px solid rgba(236,72,153,0.25); border-radius:10px; padding:12px 14px;">
                    <div style="font-size:11px; color:#f472b6; font-weight:700;">📂 ที่จัดเก็บไฟล์เสียงบนเซิร์ฟเวอร์:</div>
                    <div style="font-size:12px; color:#fff; font-weight:600; margin-top:4px;"><code>assets/audio/th/</code></div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:2px;">รองรับไฟล์ <strong>.mp3, .wav, .ogg, .m4a</strong></div>
                </div>
                <div style="background:rgba(2,132,199,0.08); border:1px solid rgba(56,189,248,0.25); border-radius:10px; padding:12px 14px;">
                    <div style="font-size:11px; color:#38bdf8; font-weight:700;">⚡ การประมวลผลเสียง (HTML5 Audio Pool):</div>
                    <div style="font-size:12px; color:#fff; font-weight:600; margin-top:4px;">Asynchronous + Preload ล่วงหน้า</div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:2px;">เล่นซ้อนกันได้ทันที ไม่มีสะดุดหรือดีเลย์</div>
                </div>
                <div style="background:rgba(16,185,129,0.08); border:1px solid rgba(16,185,129,0.25); border-radius:10px; padding:12px 14px;">
                    <div style="font-size:11px; color:#34d399; font-weight:700;">🎮 การเชื่อมโยงกับเกม 3D:</div>
                    <div style="font-size:12px; color:#fff; font-weight:600; margin-top:4px;">ผูกกับ Game Loop อัตโนมัติ</div>
                    <div style="font-size:11px; color:#94a3b8; margin-top:2px;">เริ่มเกม / ทอยเต๋า / เดินนับก้าว / เบิ้ล / ติดเกาะ</div>
                </div>
            </div>

            <!-- Audio Events Table -->
            <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse:collapse;" id="thai-audio-events-table">
                    <thead>
                        <tr style="background:rgba(15,23,42,0.9); border-bottom:1.5px solid rgba(236,72,153,0.4);">
                            <th style="padding:10px; text-align:left; font-size:12px; color:#f472b6;">เหตุการณ์ (Event Key)</th>
                            <th style="padding:10px; text-align:left; font-size:12px; color:#f472b6;">ชื่อเรียก & คำพูดพากย์ภาษาไทย</th>
                            <th style="padding:10px; text-align:left; font-size:12px; color:#f472b6;">ประเภท</th>
                            <th style="padding:10px; text-align:left; font-size:12px; color:#f472b6;">ไฟล์เสียงที่ผูกไว้</th>
                            <th style="padding:10px; text-align:center; font-size:12px; color:#f472b6;">ทดลองฟัง</th>
                            <th style="padding:10px; text-align:center; font-size:12px; color:#f472b6;">อัปโหลดไฟล์ใหม่</th>
                            <th style="padding:10px; text-align:center; font-size:12px; color:#f472b6;">สถานะเปิด/ปิด</th>
                            <th style="padding:10px; text-align:center; font-size:12px; color:#f472b6;">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="thai-audio-table-body">
                        <!-- Populated by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- TAB 6: ADMIN ACCOUNT & PASSWORD MANAGEMENT (แก้ไขข้อมูลแอดมิน & เปลี่ยนรหัสผ่าน) -->
    <div id="tab-admin_account" class="tab-content">
        <div class="grid-2">
            <!-- ฟอร์มแก้ไขข้อมูลส่วนตัวแอดมิน & เปลี่ยนรหัสผ่าน -->
            <div class="card">
                <h2>🔐 แก้ไขข้อมูลส่วนตัวแอดมิน & รูปโปรไฟล์</h2>
                <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px; background:rgba(15,23,42,0.65); padding:16px; border-radius:12px; border:1px solid rgba(255,255,255,0.1);">
                    <img id="adm_avatar_preview" src="<?= htmlspecialchars($currentAdmin['avatar_url'] ?: '../avatars/avatar_01.png') ?>" style="width:72px; height:72px; border-radius:50%; object-fit:cover; border:2.5px solid #f59e0b; box-shadow:0 0 15px rgba(245,158,11,0.35); background:#1e293b;">
                    <div>
                        <strong style="color:#f8fafc; font-size:15px; display:block; margin-bottom:4px;"><?= htmlspecialchars($currentAdmin['display_name']) ?></strong>
                        <div style="font-size:12px; color:#94a3b8; margin-bottom:10px;">รูปโปรไฟล์แอดมินที่ใช้แสดงในระบบและจำลองสวมกรอบรูป AI</div>
                        <label for="admin_avatar_uploader_tab" class="btn btn-accent" style="padding:6px 14px; font-size:12px; cursor:pointer; margin:0; display:inline-flex; align-items:center; gap:6px;">
                            📸 อัปโหลดเปลี่ยนรูปโปรไฟล์
                        </label>
                        <input type="file" id="admin_avatar_uploader_tab" accept="image/*" style="display:none;" onchange="handleAdminAvatarUpload(event)">
                    </div>
                </div>
                <form id="adminProfileForm" onsubmit="submitUpdateAdminAccount(event)">
                    <div class="form-group">
                        <label>ชื่อผู้ใช้สำหรับเข้าสู่ระบบ (Admin Username) *</label>
                        <input type="text" id="adm_username" value="<?= htmlspecialchars($currentAdmin['username']) ?>" required minlength="3">
                    </div>
                    <div class="form-group">
                        <label>ชื่อที่แสดงผล (Display Name) *</label>
                        <input type="text" id="adm_display_name" value="<?= htmlspecialchars($currentAdmin['display_name']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>อีเมลผู้ดูแลระบบ (Email)</label>
                        <input type="email" id="adm_email" value="<?= htmlspecialchars($currentAdmin['email'] ?? '') ?>" placeholder="admin@example.com">
                    </div>

                    <hr style="border: none; border-top: 1px solid var(--panel-border); margin: 18px 0;">

                    <div class="form-group">
                        <label style="color: var(--accent); font-weight: 600;">🔑 รหัสผ่านปัจจุบัน (ต้องกรอกเพื่อยืนยันการแก้ไข) *</label>
                        <input type="password" id="adm_current_password" placeholder="กรอกรหัสผ่านปัจจุบันของคุณ..." required>
                    </div>

                    <div class="grid-2" style="gap: 12px;">
                        <div class="form-group">
                            <label style="color: var(--primary);">✨ รหัสผ่านใหม่ (เว้นว่างได้หากไม่ต้องการเปลี่ยนพาส)</label>
                            <input type="password" id="adm_new_password" placeholder="รหัสผ่านใหม่อย่างน้อย 4 ตัวอักษร">
                        </div>
                        <div class="form-group">
                            <label style="color: var(--primary);">✨ ยืนยันรหัสผ่านใหม่</label>
                            <input type="password" id="adm_confirm_password" placeholder="กรอกรหัสผ่านใหม่อีกครั้ง">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-accent" style="width: 100%; padding: 12px; font-size: 15px;">
                        💾 บันทึกข้อมูลแอดมิน / เปลี่ยนรหัสผ่าน
                    </button>
                </form>
            </div>

            <!-- จัดการรายการบัญชีแอดมิน & เพิ่มแอดมินใหม่ -->
            <div>
                <div class="card">
                    <h2>➕ เพิ่มบัญชีผู้ดูแลระบบใหม่ (Create Admin)</h2>
                    <form id="createAdminForm" onsubmit="submitCreateAdmin(event)">
                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>Username *</label>
                                <input type="text" id="new_adm_user" placeholder="เช่น admin2" required minlength="3">
                            </div>
                            <div class="form-group">
                                <label>ชื่อแสดงผล *</label>
                                <input type="text" id="new_adm_name" placeholder="เช่น ทีมงานดูแลระบบ" required>
                            </div>
                        </div>
                        <div class="grid-2" style="gap: 12px;">
                            <div class="form-group">
                                <label>รหัสผ่าน (Password) *</label>
                                <input type="password" id="new_adm_pass" placeholder="อย่างน้อย 4 ตัวอักษร" required minlength="4">
                            </div>
                            <div class="form-group">
                                <label>อีเมล</label>
                                <input type="email" id="new_adm_email" placeholder="staff@snake3d.local">
                            </div>
                        </div>
                        <button type="submit" class="btn" style="width: 100%;">➕ สร้างบัญชีแอดมินเพิ่ม</button>
                    </form>
                </div>

                <div class="card">
                    <h2>🛡️ รายชื่อผู้ดูแลระบบทั้งหมด</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>ชื่อแสดงผล</th>
                                <th>เข้าสู่ระบบล่าสุด</th>
                                <th>จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($adminsList as $adm): ?>
                            <tr>
                                <td>#<?= (int)$adm['id'] ?></td>
                                <td><code><?= htmlspecialchars($adm['username']) ?></code></td>
                                <td><strong><?= htmlspecialchars($adm['display_name']) ?></strong></td>
                                <td><?= htmlspecialchars($adm['last_login_at'] ?? '-') ?></td>
                                <td>
                                    <button class="btn" style="padding: 4px 10px; font-size: 12px;" onclick="promptResetAdminPass(<?= (int)$adm['id'] ?>, '<?= htmlspecialchars(addslashes($adm['username'])) ?>')">🔑 ตั้งพาสใหม่</button>
                                    <?php if ((int)$adm['id'] !== (int)$currentAdmin['id']): ?>
                                    <button class="btn btn-danger" style="padding: 4px 10px; font-size: 12px;" onclick="deleteAdminAccount(<?= (int)$adm['id'] ?>, '<?= htmlspecialchars(addslashes($adm['username'])) ?>')">ลบ</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB: ROOM ECONOMY, ENTRY FEE, STARTING MATCH GOLD, CITIES & LANDMARKS -->
    <div id="tab-room_economy" class="tab-content">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">🏙️ ตั้งค่าห้องแข่งขัน ค่าผ่านทางเข้าเล่น ทองเริ่มต้นในกระดาน เมือง & แลนด์มาร์ค</h2>
                    <p style="font-size:13px; color:var(--text-muted); margin-top:6px;">
                        กำหนดค่าผ่านทางเข้าเล่นจากกระเป๋าหลัก (เช่น ห้อง 2M จ่ายค่าเข้า 2,000 ทอง) และทองเริ่มต้นในกระดาน (เช่น เริ่มต้น 2,000,000 ทอง) รวมถึงค่าภาษี ราคาสร้างเมือง 1–3 เมือง แลนด์มาร์ค ค่าผ่านทาง และอัตราซื้อต่อเมือง
                    </p>
                </div>
                <button class="btn btn-accent" style="padding:12px 22px; font-size:15px;" onclick="saveAllRoomEconomySettings()">
                    💾 บันทึกตั้งค่าห้องทั้งหมด
                </button>
            </div>

            <div style="background:rgba(6,182,212,0.08); border:1px solid rgba(6,182,212,0.35); border-radius:10px; padding:12px 16px; margin-bottom:18px; font-size:13px; line-height:1.65; color:#e2e8f0;">
                💡 <strong>กติกามหาเศรษฐีบนกระดาน 3D:</strong>
                ตกช่องจังหวัดว่างครั้งที่ 1 สร้างเมืองได้สูงสุด <strong>3 เมือง</strong> • ตกเมืองตัวเองครั้งที่ 2 อัปเกรดเป็น <strong>🏛️ แลนด์มาร์ค</strong> (ป้องกันการซื้อต่อ!) • ตกแลนด์มาร์คตัวเองสุ่มตัวคูณ <strong>X2 / X4 / X6 / X8</strong> •
                <span style="color:#fde047;">💸 <strong>ช่องภาษี (TAX):</strong> คิดตามจำนวนเมืองและมูลค่าก่อสร้างที่ครอบครองจริง (ยิ่งมีเมืองเยอะ ค่าก่อสร้างเยอะ ยิ่งจ่ายภาษีเยอะ! หากยังไม่มีเมืองจะเสียเฉพาะฐานภาษีขั้นต่ำ)</span> •
                หากทองในกระดานหมดจะ <strong>💥 ล้มละลาย</strong> ทันที และหากยังมีทองเหลือต้องไปตกที่ <strong>🏁 เส้นชัย (ช่อง 100)</strong> เพื่อคว้าชัยชนะ!
            </div>

            <div id="room_economy_cards_container" class="grid-2">
                <div style="color:var(--text-muted); padding:20px;">กำลังโหลดข้อมูลตั้งค่าห้องแข่งขัน...</div>
            </div>
        </div>
    </div>

    <!-- TAB: RANKING & WEEKLY WEDNESDAY RESET SETTINGS -->
    <div id="tab-ranking_settings" class="tab-content">
        <div class="card" style="margin-bottom: 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">🏆 ตั้งค่าระบบจัดอันดับประจำสัปดาห์ & กำหนดเวลารีเซ็ตวันพุธ 10:00 น.</h2>
                    <p style="font-size:13px; color:var(--text-muted); margin-top:6px; margin-bottom:0;">
                        ระบบจัดอันดับแข่งขันรอบละ 1 สัปดาห์ โดยอันดับจะรีเซ็ตอัตโนมัติทุกวันพุธ เวลา 10:00 น. กำหนดคะแนนจัดอันดับ (RP) และเงินทองที่ได้/เสีย เพื่อรักษาอันดับ
                    </p>
                </div>
                <div style="display:flex; gap:10px;">
                    <button class="btn btn-danger" onclick="manualResetSeasonAdmin()" style="padding:10px 18px;">🔄 สั่งรีเซ็ตอันดับทันที (Manual Reset)</button>
                    <button class="btn btn-accent" onclick="saveAdminRankingSettings()" style="padding:10px 22px;">💾 บันทึกการตั้งค่า</button>
                </div>
            </div>

            <!-- Season Cycle Info Box -->
            <div style="background:radial-gradient(circle at top, rgba(255,215,0,0.12), rgba(15,23,42,0.9)); border:1.5px solid rgba(255,215,0,0.4); border-radius:12px; padding:18px 20px; margin-bottom:20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                    <div>
                        <div style="font-size:12px; color:#ffd700; font-weight:800; text-transform:uppercase; letter-spacing:1px;">⏳ ฤดูกาลประจำสัปดาห์ปัจจุบัน</div>
                        <div style="font-size:24px; font-weight:900; color:#fff; margin:4px 0;" id="adm_season_title">Season #1</div>
                        <div style="font-size:13px; color:#94a3b8;" id="adm_season_cycle">รอบการแข่งขัน: ทุกวันพุธ 10:00 น. ถึง วันพุธถัดไป 10:00 น.</div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:12px; color:#38bdf8;">เวลารีเซ็ตครั้งถัดไป:</div>
                        <div style="font-size:18px; font-weight:800; color:#38bdf8;" id="adm_next_reset_text">-</div>
                        <div style="font-size:14px; font-weight:700; color:#ffd700; background:rgba(0,0,0,0.4); padding:4px 10px; border-radius:8px; display:inline-block; margin-top:4px;" id="adm_countdown_text">⏳ กำลังคำนวณ...</div>
                    </div>
                </div>
            </div>

            <!-- Settings Grid -->
            <div class="grid-2">
                <!-- Card 1: เดี่ยว 4 (4 Players) -->
                <div style="background:rgba(15,23,42,0.6); border:1px solid var(--panel-border); border-radius:12px; padding:16px;">
                    <h3 style="color:#38bdf8; font-size:15px; margin:0 0 12px 0;">🎮 โหมดเดี่ยว 4 (4 Players) - คะแนน & ทองที่ได้/เสีย</h3>
                    <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px;">กำหนดคะแนน RP และทองที่ได้รับหรือเสียในแต่ละอันดับ 1–4</p>
                    
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">
                        <div>
                            <label style="font-size:12px; color:#ffd700; font-weight:700;">🥇 อันดับ 1 (ชนะเลิศ) คะแนน RP:</label>
                            <input type="number" id="cfg_points_4p_rank1" value="35" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid #ffd700; border-radius:6px; color:#ffd700; font-weight:800;">
                        </div>
                        <div>
                            <label style="font-size:12px; color:#ffd700; font-weight:700;">🥇 ทองรางวัลอันดับ 1:</label>
                            <input type="number" id="cfg_gold_4p_rank1" value="150000" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid #ffd700; border-radius:6px; color:#ffd700; font-weight:800;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">
                        <div>
                            <label style="font-size:12px; color:#38bdf8; font-weight:700;">🥈 อันดับ 2 คะแนน RP:</label>
                            <input type="number" id="cfg_points_4p_rank2" value="10" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#38bdf8; font-weight:800;">
                        </div>
                        <div>
                            <label style="font-size:12px; color:#38bdf8; font-weight:700;">🥈 ทองอันดับ 2 (0 = คืนทุน):</label>
                            <input type="number" id="cfg_gold_4p_rank2" value="0" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#fff;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">
                        <div>
                            <label style="font-size:12px; color:#f472b6; font-weight:700;">🥉 อันดับ 3 คะแนน RP (ติดลบ):</label>
                            <input type="number" id="cfg_points_4p_rank3" value="-10" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#f472b6; font-weight:800;">
                        </div>
                        <div>
                            <label style="font-size:12px; color:#f472b6; font-weight:700;">🥉 ทองที่เสียอันดับ 3 (ติดลบ):</label>
                            <input type="number" id="cfg_gold_4p_rank3" value="-30000" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#f472b6;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <div>
                            <label style="font-size:12px; color:#f43f5e; font-weight:700;">4️⃣ อันดับ 4 (แพ้) คะแนน RP:</label>
                            <input type="number" id="cfg_points_4p_rank4" value="-25" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid #f43f5e; border-radius:6px; color:#f43f5e; font-weight:800;">
                        </div>
                        <div>
                            <label style="font-size:12px; color:#f43f5e; font-weight:700;">4️⃣ ทองที่เสียอันดับ 4 (ติดลบ):</label>
                            <input type="number" id="cfg_gold_4p_rank4" value="-50000" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid #f43f5e; border-radius:6px; color:#f43f5e; font-weight:800;">
                        </div>
                    </div>
                </div>

                <!-- Card 2: 1v1 และเกณฑ์การรักษาอันดับ -->
                <div style="background:rgba(15,23,42,0.6); border:1px solid var(--panel-border); border-radius:12px; padding:16px;">
                    <h3 style="color:#a855f7; font-size:15px; margin:0 0 12px 0;">⚔️ โหมดเดี่ยว 2 (1v1) & เกณฑ์รักษาอันดับสัปดาห์</h3>
                    
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px;">
                        <div>
                            <label style="font-size:12px; color:#10b981; font-weight:700;">🏆 ชนะเลิศ 1v1 คะแนน RP:</label>
                            <input type="number" id="cfg_points_1v1_win" value="25" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#10b981; font-weight:800;">
                        </div>
                        <div>
                            <label style="font-size:12px; color:#f43f5e; font-weight:700;">💥 พ่ายแพ้ 1v1 คะแนน RP (ติดลบ):</label>
                            <input type="number" id="cfg_points_1v1_loss" value="-20" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#f43f5e; font-weight:800;">
                        </div>
                    </div>

                    <div style="border-top:1px solid var(--panel-border); padding-top:14px; margin-top:14px;">
                        <h4 style="color:#ffd700; font-size:14px; margin:0 0 8px 0;">🛡️ เกณฑ์การรักษาอันดับ (Rank Maintenance Rule)</h4>
                        <p style="font-size:12px; color:var(--text-muted); margin-bottom:12px;">ผู้เล่นต้องลงแข่งขันอย่างน้อยตามจำนวนนี้ต่อสัปดาห์ เพื่อรักษาระดับ Tier และอันดับไว้</p>
                        
                        <div style="margin-bottom:10px;">
                            <label style="font-size:12px; color:#e2e8f0;">จำนวนแมตช์ขั้นต่ำต่อสัปดาห์เพื่อรักษาอันดับ:</label>
                            <input type="number" id="cfg_maintain_min_matches" value="5" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#fff;">
                        </div>

                        <div>
                            <label style="font-size:12px; color:#e2e8f0;">คะแนนฐานเริ่มต้นเมื่อรีเซ็ตสัปดาห์ (RP):</label>
                            <input type="number" id="cfg_maintain_min_points" value="1000" style="width:100%; padding:8px; background:rgba(0,0,0,0.5); border:1px solid var(--panel-border); border-radius:6px; color:#fff;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB: MAGIC CUBE & REWARD MANAGEMENT (LINE LET'S GET RICH STYLE) -->
    <div id="tab-magic_cubes" class="tab-content">
        <div class="card" style="margin-bottom: 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0;">🧊 จัดการกิจกรรมหมุนลูกบาศก์นำโชค & ของรางวัลในกล่อง (Magic Cube)</h2>
                    <p style="font-size:13px; color:var(--text-muted); margin-top:6px; margin-bottom:0;">
                        ผู้เล่นจะได้รับลูกบาศก์จากการเล่นชนะในห้องแข่งขัน (ชนะได้ทอง + เพชร + สุ่มดรอปลูกบาศก์เงิน / ทอง / เพชร / ในตำนาน) โดยระบบจะสุ่มระยะเวลาหมุน เช่น 2 ชม., 5 ชม., 9 ชม. ตามช่วงที่ Admin กำหนด และของรางวัลที่ได้รับขึ้นอยู่กับระยะเวลาหมุน
                    </p>
                </div>
                <button class="btn" onclick="loadMagicCubeConfigsAdmin()" style="padding:8px 16px;">🔄 รีเฟรชข้อมูล</button>
            </div>

            <!-- Quick Give Tool -->
            <div style="background:rgba(0,229,255,0.06); border:1px solid rgba(0,229,255,0.3); border-radius:10px; padding:14px; margin-bottom:20px;">
                <h3 style="color:#00e5ff; font-size:14px; margin:0 0 10px 0;">🎁 เครื่องมือ Admin: แจกลูกบาศก์ให้ผู้เล่นทันที (สำหรับทดสอบระบบ)</h3>
                <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:flex-end;">
                    <div style="flex:1; min-width:200px;">
                        <label style="font-size:12px; color:var(--text-muted);">เลือกผู้เล่น:</label>
                        <select id="admin_give_user_id" style="width:100%; padding:8px 10px; background:rgba(0,0,0,0.4); border:1px solid var(--panel-border); border-radius:6px; color:#fff;">
                            <option value="">กำลังโหลดผู้เล่น...</option>
                        </select>
                    </div>
                    <div style="flex:1; min-width:180px;">
                        <label style="font-size:12px; color:var(--text-muted);">ประเภทลูกบาศก์:</label>
                        <select id="admin_give_cube_type" style="width:100%; padding:8px 10px; background:rgba(0,0,0,0.4); border:1px solid var(--panel-border); border-radius:6px; color:#ffd700; font-weight:700;">
                            <option value="SILVER">🪙 ลูกบาศก์เงิน (1-3 ชม.)</option>
                            <option value="GOLD">👑 ลูกบาศก์ทอง (3-6 ชม.)</option>
                            <option value="DIAMOND">💎 ลูกบาศก์เพชร (6-9 ชม.)</option>
                            <option value="LEGENDARY">🌟 ลูกบาศก์ในตำนาน (9-14 ชม.)</option>
                        </select>
                    </div>
                    <button type="button" class="btn btn-accent" onclick="submitAdminGiveCube()" style="padding:9px 18px; font-weight:700;">
                        🚀 มอบลูกบาศก์เข้ากระเป๋าผู้เล่น
                    </button>
                </div>
            </div>

            <!-- 4 Cube Config Cards Grid -->
            <div id="magic_cube_cards_grid" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
                <div style="color:var(--text-muted); text-align:center; padding:30px; grid-column: 1 / -1;">กำลังโหลดการตั้งค่าลูกบาศก์...</div>
            </div>
        </div>
    </div>

    <!-- TAB: MOBILE APP DYNAMIC CONFIG & REAL-TIME CACHE BUSTER -->
    <div id="tab-mobile_app" class="tab-content">
        <div class="card" style="margin-bottom: 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--panel-border); padding-bottom:12px; margin-bottom:16px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0; color:#38bdf8;">📱 ตั้งค่าแอปมือถือ Android (Kotlin) & iOS (Swift) และระบบแคชแบบเรียลไทม์</h2>
                    <p style="font-size:13px; color:var(--text-muted); margin-top:6px; margin-bottom:0;">
                        กำหนด URL โดเมนของหน้าเว็บเกมหลัก และควบคุมการล้างแคชอัปเดตของตัวแอปพลิเคชันจากเซิร์ฟเวอร์แบบ Real-time โดยไม่ต้องอัปโหลดขึ้นสโตร์ใหม่
                    </p>
                </div>
                <div style="display:flex; gap:10px;">
                    <a href="../admin_dashboard.php" class="btn" style="background:#0284c7; color:#fff; text-decoration:none; padding:8px 16px; font-weight:700;">🚀 เปิดหน้า OTA Dashboard เต็มจอ</a>
                    <button class="btn" onclick="loadMobileAppConfigAdmin()" style="padding:8px 16px;">🔄 รีเฟรชข้อมูล</button>
                </div>
            </div>

            <!-- MEGA DEPLOY BUTTON BANNER -->
            <div style="background:linear-gradient(135deg, rgba(2, 132, 199, 0.2), rgba(16, 185, 129, 0.2)); border:2px solid #00e5ff; border-radius:14px; padding:20px 24px; margin-bottom:24px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:18px; box-shadow:0 0 25px rgba(0,229,255,0.2);">
                <div>
                    <h3 style="margin:0 0 6px 0; color:#00e5ff; font-size:18px; display:flex; align-items:center; gap:8px;">
                        <span>🚀</span> ระบบอัปเดตไฟล์เกมแบบเรียลไทม์ (Deploy Update to Mobile)
                    </h3>
                    <p style="margin:0; color:#cbd5e1; font-size:13px; max-width:650px;">
                        เมื่อแก้ไขโค้ด JS หรือ CSS ใน IDE เสร็จ ให้กดปุ่มนี้เพื่อสร้างรหัสเวอร์ชันใหม่ตาม Timestamp อัตโนมัติ บันทึกลงฐานข้อมูล และต่อท้าย ?v=timestamp ใน index.html ทันที บังคับให้แอปมือถือโหลดไฟล์ใหม่โดยไม่ต้องผ่าน Store
                    </p>
                </div>
                <button id="btn_admin_panel_deploy" class="btn" onclick="openOtaDeployModal()" style="background:linear-gradient(135deg, #0284c7 0%, #00e5ff 50%, #10b981 100%); color:#000; font-size:16px; font-weight:900; padding:15px 32px; border-radius:12px; border:none; cursor:pointer; box-shadow:0 6px 20px rgba(0,229,255,0.45); display:inline-flex; align-items:center; gap:10px;">
                    <span style="font-size:22px;">🚀</span>
                    <span>ปุ่มกดอัปเดตระบบเกมส์ (Deploy Update to Mobile)</span>
                </button>
            </div>

            <div class="grid-2" style="gap:20px;">
                <!-- Form Box -->
                <div style="background:rgba(15,23,42,0.65); border:1.5px solid rgba(56,189,248,0.3); border-radius:12px; padding:18px;">
                    <h3 style="color:#ffd700; font-size:15px; margin:0 0 14px 0;">⚙️ ข้อมูลการเชื่อมต่อ & แคชเซิร์ฟเวอร์</h3>

                    <div class="form-group" style="margin-bottom:14px;">
                        <label style="font-size:12px; font-weight:700; color:#38bdf8;">🌐 URL หน้าเว็บเกมหลัก (Web Game URL):</label>
                        <input type="url" id="mobile_game_url" value="https://pmix01.thddns.net:7175/home/snake/" placeholder="https://yourdomain.com/home/snake/" style="width:100%; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.15); border-radius:8px; color:#fff;" required>
                        <span style="font-size:11px; color:#94a3b8; display:block; margin-top:4px;">ตัวแอป Android และ iOS จะดึงหน้าเกมจาก URL นี้โดยอัตโนมัติเมื่อเปิดแอป</span>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
                        <div class="form-group" style="margin:0;">
                            <label style="font-size:11px; font-weight:700; color:#cbd5e1;">📦 เวอร์ชันแอป:</label>
                            <input type="text" id="mobile_app_version" value="<?= htmlspecialchars($initialAppVersion) ?>" style="width:100%; padding:9px 10px; font-size:13px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.15); border-radius:8px; color:#fff;">
                        </div>
                        <div class="form-group" style="margin:0;">
                            <label style="font-size:11px; font-weight:700; color:#cbd5e1;">🔄 รหัสแคช:</label>
                            <input type="number" id="mobile_cache_version" value="<?= (int)$initialCacheBuster ?>" min="1" style="width:100%; padding:9px 10px; font-size:13px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.15); border-radius:8px; color:#ffd700; font-weight:800;">
                        </div>
                        <div class="form-group" style="margin:0;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                                <label style="font-size:11px; font-weight:700; color:#38bdf8; margin:0;">💾 ขนาด & จำนวนไฟล์อัปเดต:</label>
                                <button type="button" class="btn" onclick="runAiAnalyzeUpdateSize()" title="ให้ AI วิเคราะห์ขนาดและจำนวนไฟล์อัปเดตทั้งหมด" style="background:linear-gradient(135deg, #8b5cf6, #ec4899); color:#fff; font-size:10px; font-weight:800; padding:2px 7px; border-radius:6px; border:none; cursor:pointer;">
                                    ✨ AI วิเคราะห์ขนาด
                                </button>
                            </div>
                            <div style="display:flex; gap:6px;">
                                <input type="text" id="mobile_update_size" value="<?= htmlspecialchars($initialUpdateSize) ?>" placeholder="เช่น 2.8 MB" title="ขนาดไฟล์อัปเดต (MB/KB)" style="flex:1; padding:9px 10px; font-size:13px; background:rgba(0,0,0,0.5); border:1px solid rgba(56,189,248,0.3); border-radius:8px; color:#38bdf8; font-weight:800;">
                                <input type="text" id="mobile_update_files" value="<?= htmlspecialchars($initialUpdateFilesText) ?>" placeholder="เช่น 14 ไฟล์" title="จำนวนไฟล์อัปเดต" style="width:90px; padding:9px 6px; font-size:12px; background:rgba(0,0,0,0.5); border:1px solid rgba(16,185,129,0.3); border-radius:8px; color:#10b981; font-weight:800; text-align:center;">
                            </div>
                            <div id="ai_size_analysis_badge" style="<?= !empty($initialAiSummary) ? 'display:block;' : 'display:none;' ?> margin-top:6px; font-size:11px; color:#a7f3d0; background:rgba(16,185,129,0.12); border:1px solid rgba(16,185,129,0.3); border-radius:6px; padding:6px 10px; line-height:1.4;">
                                <?php if (!empty($initialAiSummary)): ?>
                                    🤖 <strong><?= htmlspecialchars($initialAiSummary) ?></strong><br>
                                    <span style="color:#94a3b8; font-size:10.5px;">ขนาดรวมปัจจุบัน: <b style="color:#ffd700;"><?= htmlspecialchars($initialUpdateSize) ?></b> | จำนวน: <b style="color:#10b981;"><?= htmlspecialchars($initialUpdateFilesText) ?></b></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div style="background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.25); border-radius:8px; padding:10px 12px; margin-bottom:14px;">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0; font-size:13px; color:#fca5a5; font-weight:700;">
                            <input type="checkbox" id="mobile_force_clear_cache" style="width:18px; height:18px; cursor:pointer;">
                            <span>⚠️ บังคับให้แอปมือถือเคลียร์แคชทันทีในการเปิดแอปครั้งถัดไป</span>
                        </label>
                        <span style="font-size:11px; color:#cbd5e1; display:block; margin-top:4px; padding-left:26px;">
                            (หากเปิดไว้ ตัวแอป Android / iOS จะลบแคชเก่าและโหลดโค้ดเกมล่าสุดจากเซิร์ฟเวอร์ทันที)
                        </span>
                    </div>

                    <div style="background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.25); border-radius:8px; padding:10px 12px; margin-bottom:14px;">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0 0 6px 0; font-size:13px; color:#fde047; font-weight:700;">
                            <input type="checkbox" id="mobile_maintenance_mode" style="width:18px; height:18px; cursor:pointer;">
                            <span>🚧 โหมดปิดปรับปรุงเซิร์ฟเวอร์ชั่วคราว (Maintenance Mode)</span>
                        </label>
                        <input type="text" id="mobile_maintenance_msg" value="ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง" placeholder="ข้อความแจ้งเตือนผู้เล่น" style="width:100%; padding:8px 10px; font-size:12px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.15); border-radius:6px; color:#fff;">
                    </div>

                    <button class="btn btn-accent" onclick="saveMobileAppConfigAdmin()" style="width:100%; padding:12px; font-size:14px; font-weight:800; background:linear-gradient(135deg, #0284c7, #0369a1); border:none; border-radius:10px; box-shadow:0 4px 15px rgba(2,132,199,0.4);">
                        💾 บันทึกการตั้งค่าแอปมือถือ & อัปเดตรหัสแคช
                    </button>
                </div>

                <!-- Preview / API Endpoint Box -->
                <div style="background:rgba(15,23,42,0.65); border:1.5px solid rgba(255,255,255,0.1); border-radius:12px; padding:18px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <h3 style="color:#38bdf8; font-size:15px; margin:0 0 10px 0;">📡 Live JSON Endpoint (สำหรับแอป Android & iOS):</h3>
                        <p style="font-size:12px; color:#94a3b8; margin:0 0 10px 0;">
                            แอปมือถือทั้ง Kotlin และ Swift จะเรียกคำสั่งมาที่ Endpoint นี้ก่อนโหลดหน้าเกม เพื่อตรวจสอบ URL และตรวจเช็ครหัสแคช:
                        </p>
                        <div style="background:#000; border:1px solid rgba(0,229,255,0.3); border-radius:8px; padding:10px 14px; font-family:monospace; font-size:12px; color:#00e5ff; word-break:break-all; margin-bottom:12px;">
                            GET https://pmix01.thddns.net:7175/home/snake/api/app_config.php
                        </div>
                        <label style="font-size:12px; color:#cbd5e1; font-weight:700;">ตัวอย่างผลลัพธ์ JSON Real-time:</label>
                        <pre id="mobile_app_json_preview" style="background:#030712; border:1px solid rgba(255,255,255,0.08); border-radius:8px; padding:12px; font-size:12px; color:#10b981; overflow-x:auto; max-height:210px; font-family:monospace; margin-top:6px;">
กำลังโหลดผลลัพธ์จาก API...
                        </pre>
                    </div>

                    <div style="background:rgba(56,189,248,0.08); border:1px solid rgba(56,189,248,0.25); border-radius:8px; padding:10px 12px; font-size:12px; color:#38bdf8; margin-top:14px;">
                        💡 <strong>คำแนะนำ:</strong> เมื่อคุณต้องการอัปเดตไฟล์เกมบนเซิร์ฟเวอร์ ให้เพิ่มตัวเลข <strong>รหัสแคช (Cache Buster)</strong> ขึ้น 1 ค่า เช่น จาก 124 เป็น 125 เมื่อผู้เล่นเปิดแอป ตัวแอปจะล้างแคชเก่าทิ้งและดึงไฟล์ใหม่ทันที!
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- TAB: AI 3D BOARD STUDIO (สร้างกระดาน 3D ด้วย AI จากรูปภาพ + กำหนดทรงสี่เหลี่ยมผืนผ้า/หลายทรง + จัดการชื่อเมือง AI + การ์ดดวง + เอฟเฟกต์ + ตำแหน่งปุ่มทอย) -->
    <!-- ============================================================ -->
    <div id="tab-board_studio" class="tab-content">
        <div class="card" style="background:linear-gradient(135deg, rgba(6,78,59,0.35), rgba(15,23,42,0.95)); border:1.5px solid rgba(16,185,129,0.45); margin-bottom:18px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <div>
                    <h2 style="margin:0; border:none; padding:0; color:#34d399; font-size:20px;">🗺️ AI 3D Board Studio — สร้างกระดาน 3D ด้วย AI จากรูปภาพ & จัดการเมือง/ช่องพิเศษ/ปุ่มทอย</h2>
                    <p style="color:#cbd5e1; font-size:13px; margin:4px 0 0 0;">
                        อัปโหลดรูปภาพเพื่อให้ AI วิเคราะห์สีและสร้างกระดาน 3D อัตโนมัติ • เลือกรูปทรงกระดาน (<strong>สี่เหลี่ยมผืนผ้า</strong>, สี่เหลี่ยมจัตุรัส, ก้นหอย, หกเหลี่ยม, วงแหวนเพชร) • กำหนดขนาดและจำนวนช่อง • ให้ AI ตั้งชื่อเมืองและแก้ไขรายช่อง • กำหนดจำนวนและตำแหน่ง <strong>การ์ดดวง</strong> / ช่องพิเศษ • ตั้งค่าเอฟเฟกต์ 3D • กำหนดตำแหน่ง <strong>ปุ่มทอยลูกเต๋า</strong> • เปิดให้เล่นได้ทันทีหรือยกเลิกได้ตลอดเวลา
                    </p>
                </div>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <select id="abs_existing_select" onchange="window.loadBoardIntoStudio(this.value)" style="width:270px; border-color:#10b981; color:#34d399; font-weight:700;">
                        <option value="0">➕ โหมด: สร้างกระดาน 3D ใหม่ด้วย AI</option>
                    </select>
                    <button type="button" class="btn" style="background:#334155; color:#fff; padding:8px 14px; font-size:12px;" onclick="window.resetAiBoardStudio()">
                        🔄 เริ่มสร้างใหม่
                    </button>
                    <button type="button" class="btn btn-danger" style="padding:8px 14px; font-size:12px;" onclick="window.cancelAllDefaultAiBoards()">
                        ⏹️ ยกเลิกกระดานหลัก (กลับค่าเริ่มต้น)
                    </button>
                </div>
            </div>
        </div>

        <div class="grid-2" style="gap:20px; align-items:start;">
            <!-- LEFT COLUMN: AI Image Processor, Shape & Grid Size, Effects & Roll Button Position -->
            <div>
                <!-- 1. AI Image Upload & Theme Extraction -->
                <div class="card" style="margin-bottom:16px; border:1px solid rgba(56,189,248,0.35);">
                    <h3 style="margin-top:0; color:#38bdf8; font-size:15px;">📸 1. อัปโหลดรูปภาพต้นแบบเพื่อให้ AI ประมวลผลสร้างกระดาน 3D</h3>
                    <div id="abs_image_dropzone" onclick="document.getElementById('abs_image_input').click()"
                        style="border:2px dashed #38bdf8; border-radius:12px; padding:18px; text-align:center; background:rgba(56,189,248,0.06); cursor:pointer; transition:0.2s; margin-bottom:12px;">
                        <input type="file" id="abs_image_input" accept="image/*" style="display:none;" onchange="window.handleAiBoardImageUpload(event)">
                        <div id="abs_image_preview_wrap" style="display:none; margin-bottom:10px;">
                            <img id="abs_image_preview_el" src="" style="max-height:130px; max-width:100%; border-radius:8px; border:2px solid #38bdf8; object-fit:cover;">
                        </div>
                        <div style="font-size:30px; margin-bottom:4px;">🖼️🤖</div>
                        <div style="font-size:14px; font-weight:800; color:#38bdf8;">คลิกอัปโหลดรูปภาพ หรือลากไฟล์รูปมาวางที่นี่</div>
                        <div style="font-size:11.5px; color:#94a3b8; margin-top:4px;">AI จะดึงชุดสีหลัก (Palette), สีพื้นกระดาน, สีช่องคู่/คี่, แสงนีออน, เอฟเฟกต์ และตั้งชื่อเมืองตามโทนภาพให้อัตโนมัติ</div>
                    </div>

                    <!-- AI Analysis Result Badge -->
                    <div id="abs_ai_analysis_box" style="display:none; background:rgba(15,23,42,0.85); border:1px solid rgba(16,185,129,0.4); border-radius:10px; padding:10px 12px; margin-bottom:12px; font-size:12px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                            <span style="font-weight:800; color:#34d399;">🧠 ผลวิเคราะห์ภาพจาก AI สำเร็จ:</span>
                            <span id="abs_ai_detected_mood" style="background:rgba(16,185,129,0.2); color:#34d399; padding:2px 8px; border-radius:999px; font-weight:700;">Cyber Neon</span>
                        </div>
                        <div id="abs_ai_palette_swatches" style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;"></div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; background:rgba(15,23,42,0.6); padding:8px 12px; border-radius:8px; margin-bottom:10px;">
                        <label style="margin:0; display:flex; align-items:center; gap:8px; cursor:pointer; font-size:12.5px; color:#fde047; font-weight:700;">
                            <input type="checkbox" id="abs_apply_board_texture" checked onchange="window.updateAiBoardStudioPreview()" style="width:17px; height:17px;">
                            <span>🎨 ใช้รูปภาพที่อัปโหลดปูเป็นพื้นผิว (3D Texture Skin) บนฐานและช่องกระดาน</span>
                        </label>
                        <button type="button" class="btn" style="padding:4px 10px; font-size:11px; background:#a855f7; color:#fff;" onclick="window.aiRandomizeBoardThemeFromImage()">
                            ✨ ให้ AI สุ่มโทนสีใหม่จากภาพ
                        </button>
                    </div>

                    <!-- Color Pickers for Board Theme -->
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;">
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีบรรยากาศ/ฉากหลัง</label>
                            <input type="color" id="abs_col_bg" value="#060b16" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีช่องเลขคู่ (Even)</label>
                            <input type="color" id="abs_col_even" value="#0f203c" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีช่องเลขคี่ (Odd)</label>
                            <input type="color" id="abs_col_odd" value="#173058" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีขอบนีออน (Border)</label>
                            <input type="color" id="abs_col_border" value="#00e5ff" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีบันได 3D (Ladder)</label>
                            <input type="color" id="abs_col_ladder" value="#38bdf8" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#94a3b8;">สีพญางู 3D (Snake)</label>
                            <input type="color" id="abs_col_snake" value="#f43f5e" onchange="window.updateAiBoardStudioPreview()" style="width:100%; height:32px; padding:1px; border-radius:6px; cursor:pointer;">
                        </div>
                    </div>
                </div>

                <!-- 2. Board Shape, Dimensions & Tile Count -->
                <div class="card" style="margin-bottom:16px; border:1px solid rgba(250,204,21,0.35);">
                    <h3 style="margin-top:0; color:#fde047; font-size:15px;">📐 2. กำหนดรูปทรงกระดาน ขนาด (กว้าง x ยาว) และจำนวนช่อง</h3>
                    <input type="hidden" id="abs_board_id" value="0">
                    <input type="hidden" id="abs_board_code" value="">

                    <div class="grid-2" style="gap:10px; margin-bottom:10px;">
                        <div class="form-group" style="margin:0;">
                            <label>ชื่อกระดาน 3D *</label>
                            <input type="text" id="abs_board_name" value="🏙️ มหานครไซเบอร์สี่เหลี่ยมผืนผ้า (AI 3D)" oninput="window.updateAiBoardStudioPreview()" style="font-weight:700; color:#fff;">
                        </div>
                        <div class="form-group" style="margin:0;">
                            <label>รูปทรงกระดาน (Board Shape) *</label>
                            <select id="abs_shape_type" onchange="window.onAiBoardShapeChange(this.value)" style="border-color:#fde047; color:#fde047; font-weight:800;">
                                <option value="rectangle" selected>▭ สี่เหลี่ยมผืนผ้าแนวกว้าง (Rectangle Widescreen)</option>
                                <option value="square">🟩 สี่เหลี่ยมจัตุรัสมาตรฐาน (Classic Square)</option>
                                <option value="spiral">🌀 วงกลมก้นหอยกาแล็กซี (Spiral Galaxy)</option>
                                <option value="hexagon">⬡ หกเหลี่ยมรังผึ้ง (Hexagon Honeycomb)</option>
                                <option value="diamond_ring">❖ วงแหวนเพชร/สนามแข่งรอบนอก (Diamond Ring)</option>
                            </select>
                        </div>
                    </div>

                    <!-- Quick Dimension Presets -->
                    <div style="margin-bottom:10px;">
                        <span style="font-size:11.5px; color:#94a3b8; display:block; margin-bottom:5px;">⚡ พรีเซ็ตขนาดกระดานด่วน:</span>
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(16,185,129,0.2); color:#34d399; border:1px solid #10b981;" onclick="window.setAiBoardDimensions('rectangle', 12, 8, 96)">▭ ผืนผ้า 12x8 (96 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(16,185,129,0.2); color:#34d399; border:1px solid #10b981;" onclick="window.setAiBoardDimensions('rectangle', 14, 7, 98)">▭ ผืนผ้า 14x7 (98 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(16,185,129,0.2); color:#34d399; border:1px solid #10b981;" onclick="window.setAiBoardDimensions('rectangle', 15, 6, 90)">▭ ผืนผ้ายาว 15x6 (90 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(56,189,248,0.2); color:#38bdf8; border:1px solid #38bdf8;" onclick="window.setAiBoardDimensions('square', 10, 10, 100)">🟩 จัตุรัส 10x10 (100 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(56,189,248,0.2); color:#38bdf8; border:1px solid #38bdf8;" onclick="window.setAiBoardDimensions('square', 8, 8, 64)">🟩 จัตุรัสไว 8x8 (64 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(168,85,247,0.2); color:#c084fc; border:1px solid #a855f7;" onclick="window.setAiBoardDimensions('spiral', 10, 10, 100)">🌀 ก้นหอย (100 ช่อง)</button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:rgba(250,204,21,0.2); color:#fde047; border:1px solid #facc15;" onclick="window.setAiBoardDimensions('hexagon', 10, 10, 100)">⬡ หกเหลี่ยม (100 ช่อง)</button>
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:8px; margin-bottom:12px;">
                        <div>
                            <label style="font-size:11px; color:#cbd5e1;">แนวกว้าง (Cols)</label>
                            <input type="number" id="abs_grid_cols" value="12" min="4" max="20" onchange="window.onAiGridSizeInputsChange()" style="font-weight:800; color:#38bdf8;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#cbd5e1;">แนวลึก (Rows)</label>
                            <input type="number" id="abs_grid_rows" value="8" min="4" max="20" onchange="window.onAiGridSizeInputsChange()" style="font-weight:800; color:#38bdf8;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#fde047;">จำนวนช่องรวม</label>
                            <input type="number" id="abs_total_tiles" value="100" min="20" max="200" onchange="window.onAiTotalTilesChange()" style="font-weight:800; color:#fde047;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#cbd5e1;">ขนาดบล็อก 3D</label>
                            <input type="number" id="abs_tile_size" value="6.2" min="3.5" max="9.5" step="0.2" onchange="window.updateAiBoardStudioPreview()">
                        </div>
                    </div>

                    <!-- Hollow Center Area (ทำให้ตรงกลางว่าง / ไม่ว่าง & ปรับขนาดตรงกลางได้ สำหรับวางปุ่มทอย & ลูกเต๋า) -->
                    <div style="background:rgba(250,204,21,0.08); border:1.5px solid rgba(250,204,21,0.45); border-radius:10px; padding:12px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
                            <label style="margin:0; display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; color:#fde047; font-weight:800;">
                                <input type="checkbox" id="abs_hollow_center" onchange="window.onHollowCenterConfigChange()" style="width:18px; height:18px; cursor:pointer;">
                                <span>🕳️ ทำให้ตรงกลางกระดานว่าง (Hollow Center) เพื่อลากปุ่มทอย & ลูกเต๋ามาใส่</span>
                            </label>
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button type="button" class="btn" style="padding:4px 10px; font-size:11px; background:linear-gradient(135deg,#facc15,#eab308); color:#000; font-weight:900;" onclick="window.quickCenterArenaSetup()">
                                    🎯 เว้นว่างตรงกลาง + ดึงปุ่มทอย & ลูกเต๋ามาใส่ทันที
                                </button>
                                <button type="button" class="btn" style="padding:4px 10px; font-size:11px; background:#334155; color:#cbd5e1;" onclick="window.quickSolidBoardSetup()">
                                    🧱 เต็มกระดาน (ไม่ว่าง)
                                </button>
                            </div>
                        </div>

                        <div id="abs_hollow_controls_wrap" style="display:grid; grid-template-columns:repeat(2, 1fr); gap:10px;">
                            <div style="grid-column: 1 / -1; background:rgba(15,23,42,0.75); border:1px solid rgba(56,189,248,0.35); border-radius:8px; padding:8px 10px;">
                                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:6px;">
                                    <label style="font-size:12px; color:#38bdf8; font-weight:800; margin:0;">
                                        📍 เลือกแถวที่เริ่มว่าง (นับจากด้านหน้าสุด: แถว 1, แถว 2, แถว 3...)
                                    </label>
                                    <span id="abs_hollow_range_summary" style="font-size:11px; background:rgba(56,189,248,0.18); color:#7dd3fc; padding:2px 8px; border-radius:999px; font-weight:700;">
                                        ว่างตั้งแต่ แถวที่ 2 ถึง แถวที่ 7
                                    </span>
                                </div>
                                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                                    <select id="abs_hole_start_row" onchange="window.onHollowCenterConfigChange()" style="flex:1; min-width:190px; font-size:12px; padding:6px; font-weight:700; color:#fde047;">
                                        <option value="1">แถวที่ 1 (ว่างตั้งแต่แถวหน้าสุดเลย)</option>
                                        <option value="2" selected>แถวที่ 2 (มีแถวที่ 1 ด้านหน้า 1 แถว แล้วเริ่มว่างที่แถว 2)</option>
                                        <option value="3">แถวที่ 3 (มีแถวหน้า 2 แถว คือ แถว 1-2 แล้วเริ่มว่างที่แถว 3)</option>
                                        <option value="4">แถวที่ 4 (มีแถวหน้า 3 แถว คือ แถว 1-3 แล้วเริ่มว่างที่แถว 4)</option>
                                        <option value="5">แถวที่ 5 (เริ่มว่างตั้งแต่แถวที่ 5 เป็นต้นไป)</option>
                                        <option value="6">แถวที่ 6 (เริ่มว่างตั้งแต่แถวที่ 6 เป็นต้นไป)</option>
                                        <option value="0">กึ่งกลางกระดานอัตโนมัติ (Auto Center)</option>
                                    </select>
                                    <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#0284c7; color:#fff; font-weight:800;" onclick="window.setHollowStartRowQuick(1)">เริ่มแถว 1</button>
                                    <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#f59e0b; color:#000; font-weight:900;" onclick="window.setHollowStartRowQuick(2)">⭐ เริ่มแถว 2</button>
                                    <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#0284c7; color:#fff; font-weight:800;" onclick="window.setHollowStartRowQuick(3)">เริ่มแถว 3</button>
                                    <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#0284c7; color:#fff; font-weight:800;" onclick="window.setHollowStartRowQuick(4)">เริ่มแถว 4</button>
                                </div>
                            </div>
                            <div>
                                <label style="font-size:11.5px; color:#fde047; font-weight:700;">
                                    ↔️ ความกว้างพื้นที่ว่างตรงกลาง (<span id="abs_lbl_hole_cols">6</span> ช่อง)
                                </label>
                                <input type="range" id="abs_hole_cols" min="2" max="16" step="1" value="6" oninput="document.getElementById('abs_lbl_hole_cols').innerText=this.value; window.onHollowCenterConfigChange();">
                            </div>
                            <div>
                                <label style="font-size:11.5px; color:#fde047; font-weight:700;">
                                    ↕️ จำนวนแถวที่ว่าง / ความลึก (<span id="abs_lbl_hole_rows">6</span> แถว)
                                </label>
                                <input type="range" id="abs_hole_rows" min="1" max="14" step="1" value="6" oninput="document.getElementById('abs_lbl_hole_rows').innerText=this.value; window.onHollowCenterConfigChange();">
                            </div>
                            <div>
                                <label style="font-size:11px; color:#cbd5e1;">รูปแบบการเรียงช่องเมื่อตรงกลางว่าง</label>
                                <select id="abs_hollow_mode" onchange="window.onHollowCenterConfigChange()" style="font-size:12px; padding:6px;">
                                    <option value="grid_cutout" selected>🔲 เจาะช่องว่างตามแถวที่เลือก (เริ่มว่างตามแถวที่กำหนดเป๊ะ)</option>
                                    <option value="ring_loop">🔄 เดินวนรอบลานตรงกลาง (สไตล์เกมเศรษฐี วนรอบกรอบ)</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-size:11px; color:#cbd5e1;">รูปแบบพื้นลานตรงกลาง (Center Arena)</label>
                                <select id="abs_hollow_style" onchange="window.onHollowCenterConfigChange()" style="font-size:12px; padding:6px;">
                                    <option value="arena_tray" selected>🏟️ ลานทอยเต๋า 3D กรอบไฟนีออน (Dice Arena Tray)</option>
                                    <option value="open_hole">🌌 เจาะทะลุโปร่งโล่ง (True Hollow Cutout)</option>
                                    <option value="crystal_glass">💎 แท่นกระจกคริสตัลเรืองแสง (Crystal Glass Stage)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. Special Tiles Manager (Chance Cards, Tax, Gamble, Destroy, Jail, Ladders, Snakes) -->
                <div class="card" style="margin-bottom:16px; border:1px solid rgba(245,158,11,0.4);">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
                        <h3 style="margin:0; color:#fbbf24; font-size:15px;">🎁 3. กำหนดช่องการ์ดดวง (Chance) และช่องพิเศษบนกระดาน</h3>
                        <button type="button" class="btn" style="padding:5px 10px; font-size:11.5px; background:linear-gradient(135deg,#f59e0b,#d97706); color:#000; font-weight:800;" onclick="window.aiAutoDistributeSpecialTiles()">
                            🎲 ให้ AI กระจายตำแหน่งอัตโนมัติตามจำนวนที่ตั้ง
                        </button>
                    </div>

                    <div style="display:grid; grid-template-columns:130px 1fr; gap:8px; align-items:center; margin-bottom:8px;">
                        <div>
                            <label style="font-size:11.5px; color:#fbbf24; font-weight:700; margin:0;">🎁 จำนวนการ์ดดวง</label>
                            <input type="number" id="abs_chance_count" value="5" min="0" max="25" onchange="window.aiUpdateSpecialTileCount('chance', this.value)" style="padding:6px; font-weight:800; color:#fbbf24;">
                        </div>
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1; margin:0;">อยู่ช่องไหนบ้าง (คั่นด้วยลูกน้ำ , เช่น 8, 23, 45, 67, 85)</label>
                            <input type="text" id="abs_chance_tiles" value="8, 23, 45, 67, 85" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; color:#fde047; font-family:monospace;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:130px 1fr; gap:8px; align-items:center; margin-bottom:8px;">
                        <div>
                            <label style="font-size:11.5px; color:#f87171; font-weight:700; margin:0;">💸 จำนวนช่องภาษี</label>
                            <input type="number" id="abs_tax_count" value="3" min="0" max="15" onchange="window.aiUpdateSpecialTileCount('tax', this.value)" style="padding:6px; font-weight:800; color:#f87171;">
                        </div>
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1; margin:0;">ตำแหน่งช่องภาษี (Tax Tiles)</label>
                            <input type="text" id="abs_tax_tiles" value="18, 52, 82" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; color:#fca5a5; font-family:monospace;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:130px 1fr; gap:8px; align-items:center; margin-bottom:8px;">
                        <div>
                            <label style="font-size:11.5px; color:#c084fc; font-weight:700; margin:0;">🎰 ช่องเสี่ยงโชค</label>
                            <input type="number" id="abs_gamble_count" value="3" min="0" max="15" onchange="window.aiUpdateSpecialTileCount('gamble', this.value)" style="padding:6px; font-weight:800; color:#c084fc;">
                        </div>
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1; margin:0;">ตำแหน่งช่องเสี่ยงโชค (Lucky Gamble)</label>
                            <input type="text" id="abs_gamble_tiles" value="14, 62, 88" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; color:#e9d5ff; font-family:monospace;">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns:130px 1fr; gap:8px; align-items:center; margin-bottom:8px;">
                        <div>
                            <label style="font-size:11.5px; color:#fb7185; font-weight:700; margin:0;">💥 ช่องสกิลลบเมือง</label>
                            <input type="number" id="abs_destroy_count" value="3" min="0" max="15" onchange="window.aiUpdateSpecialTileCount('destroy', this.value)" style="padding:6px; font-weight:800; color:#fb7185;">
                        </div>
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1; margin:0;">ตำแหน่งช่องทำลายเมืองคู่แข่ง (Destroy)</label>
                            <input type="text" id="abs_destroy_tiles" value="28, 56, 91" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; color:#fecdd3; font-family:monospace;">
                        </div>
                    </div>

                    <div class="grid-2" style="gap:8px; margin-bottom:8px;">
                        <div>
                            <label style="font-size:11.5px; color:#94a3b8; font-weight:700; margin:0;">⛓️ ช่องคุก / เกาะร้าง (Jail Tile)</label>
                            <input type="number" id="abs_jail_tile" value="10" min="2" max="99" onchange="window.syncSpecialTilesFromInputs()" style="padding:6px; font-weight:800;">
                        </div>
                        <div style="display:flex; align-items:flex-end;">
                            <button type="button" class="btn" style="width:100%; padding:7px; font-size:11.5px; background:rgba(56,189,248,0.18); color:#38bdf8; border:1px solid #38bdf8;" onclick="window.aiRandomizeSnakesAndLaddersPairs()">
                                🪜🐍 สุ่มคู่บันได & งูใหม่ทั้งหมด
                            </button>
                        </div>
                    </div>

                    <div class="grid-2" style="gap:8px;">
                        <div>
                            <label style="font-size:11px; color:#38bdf8; margin:0;">🪜 คู่บันได (เริ่ม:ปลาย เช่น 4:16, 9:31)</label>
                            <input type="text" id="abs_ladders_text" value="4:16, 9:31, 21:42, 29:74, 40:59, 51:68, 63:81, 72:92" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; font-size:11.5px; font-family:monospace; color:#38bdf8;">
                        </div>
                        <div>
                            <label style="font-size:11px; color:#f43f5e; margin:0;">🐍 คู่งู (หัว:หาง เช่น 17:7, 49:30)</label>
                            <input type="text" id="abs_snakes_text" value="17:7, 49:30, 61:19, 65:58, 84:26, 93:73, 96:76, 99:79" oninput="window.syncSpecialTilesFromInputs()" style="padding:6px; font-size:11.5px; font-family:monospace; color:#f43f5e;">
                        </div>
                    </div>
                </div>

                <!-- 4. Effects & Roll Button Position Config -->
                <div class="card" style="border:1px solid rgba(168,85,247,0.4);">
                    <h3 style="margin-top:0; color:#c084fc; font-size:15px;">✨ 4. ตั้งค่าเอฟเฟกต์กระดาน 3D & ตำแหน่งปุ่มทอยลูกเต๋า</h3>

                    <div class="grid-2" style="gap:10px; margin-bottom:10px;">
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1;">เอฟเฟกต์ละอองพลังงาน (3D Particles)</label>
                            <select id="abs_fx_particle_type" onchange="window.updateAiBoardStudioPreview()">
                                <option value="cyber_sparks" selected>⚡ ประกายไฟไซเบอร์นีออน (Cyber Sparks)</option>
                                <option value="golden_dust">🌟 ละอองทองคำศักดิ์สิทธิ์ (Golden Dust)</option>
                                <option value="fire_embers">🔥 สะเก็ดเพลิงลาวา (Fire Embers)</option>
                                <option value="snow_crystal">❄️ เกล็ดหิมะคริสตัล (Snow Crystals)</option>
                                <option value="emerald_orbs">🟢 หิ่งห้อยมรกตเวทมนตร์ (Emerald Orbs)</option>
                                <option value="none">🚫 ปิดเอฟเฟกต์ละออง</option>
                            </select>
                        </div>
                        <div>
                            <label style="font-size:11.5px; color:#cbd5e1;">ความสว่างแสงไฟ 3D (<span id="abs_lbl_light">150%</span>)</label>
                            <input type="range" id="abs_fx_light_intensity" min="50" max="250" step="10" value="150" oninput="document.getElementById('abs_lbl_light').innerText=this.value+'%'; window.updateAiBoardStudioPreview();">
                        </div>
                    </div>

                    <div style="display:flex; gap:14px; flex-wrap:wrap; margin-bottom:14px; background:rgba(15,23,42,0.65); padding:8px 12px; border-radius:8px;">
                        <label style="margin:0; display:flex; align-items:center; gap:6px; font-size:12px; color:#34d399; cursor:pointer;">
                            <input type="checkbox" id="abs_fx_step_bounce" checked onchange="window.updateAiBoardStudioPreview()">
                            <span>ช่องเด้งนูนเมื่อเดินผ่าน (Step Bounce)</span>
                        </label>
                        <label style="margin:0; display:flex; align-items:center; gap:6px; font-size:12px; color:#38bdf8; cursor:pointer;">
                            <input type="checkbox" id="abs_fx_neon_glow" checked onchange="window.updateAiBoardStudioPreview()">
                            <span>เรืองแสงขอบนีออน (Neon Rim)</span>
                        </label>
                        <label style="margin:0; display:flex; align-items:center; gap:6px; font-size:12px; color:#fde047; cursor:pointer;">
                            <input type="checkbox" id="abs_fx_floating_gems" checked onchange="window.updateAiBoardStudioPreview()">
                            <span>คริสตัลลอยรอบกระดาน</span>
                        </label>
                    </div>

                    <!-- Roll Button & 3D Dice Position Settings -->
                    <div style="background:rgba(0,229,255,0.08); border:1.5px solid rgba(0,229,255,0.35); border-radius:10px; padding:12px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:8px;">
                            <span style="font-size:13px; font-weight:800; color:#00e5ff;">🎲 ตั้งค่าตำแหน่งปุ่มทอย & ย้ายลูกเต๋า 3D บนกระดาน (รองรับ iOS & Android):</span>
                            <div style="display:flex; gap:6px; align-items:center;">
                                <span id="abs_roll_pos_badge" style="font-size:11px; background:#00e5ff; color:#000; padding:2px 8px; border-radius:999px; font-weight:800;">ล่างกึ่งกลาง</span>
                                <span id="abs_dice3d_pos_badge" style="font-size:11px; background:#facc15; color:#000; padding:2px 8px; border-radius:999px; font-weight:800;">เต๋า: หน้ากระดาน</span>
                            </div>
                        </div>

                        <div class="grid-2" style="gap:10px; margin-bottom:8px;">
                            <div>
                                <label style="font-size:11.5px; color:#cbd5e1;">ตำแหน่งหลักของปุ่มทอยบนหน้าจอ</label>
                                <select id="abs_roll_preset" onchange="window.onRollPresetChange(this.value)" style="border-color:#00e5ff; color:#00e5ff; font-weight:700;">
                                    <option value="bottom_center" selected>⬇️ ล่างกึ่งกลางกระดาน (Bottom Center - มาตรฐาน)</option>
                                    <option value="bottom_right">↘️ มุมขวาล่าง (Bottom Right - ถนัดมือขวา)</option>
                                    <option value="bottom_left">↙️ มุมซ้ายล่าง (Bottom Left - ถนัดมือซ้าย)</option>
                                    <option value="center_board">🎯 กึ่งกลางกระดาน 3D (Center Board Overlay)</option>
                                    <option value="middle_right">➡️ ขอบขวากลางจอ (Right Side Dock)</option>
                                    <option value="middle_left">⬅️ ขอบซ้ายกลางจอ (Left Side Dock)</option>
                                    <option value="top_center">⬆️ ด้านบนกึ่งกลาง (Top Center)</option>
                                    <option value="custom_xy">🖐️ กำหนดพิกัด X / Y อิสระ (ลากวางบนจอตัวอย่างได้)</option>
                                </select>
                            </div>
                            <div>
                                <label style="font-size:11.5px; color:#fde047; font-weight:700;">🎲 ตำแหน่งลูกเต๋า 3D บนกระดาน (ลากย้ายบนจอได้)</label>
                                <select id="abs_dice3d_pos" onchange="window.onDice3dPosModeChange(this.value)" style="border-color:#facc15; color:#fde047; font-weight:700;">
                                    <option value="front_center" selected>⬇️ หน้ากระดานกึ่งกลาง (Front Center)</option>
                                    <option value="board_center">🎯 ตรงกลางกระดาน (ในช่องว่างตรงกลาง / Center Arena)</option>
                                    <option value="follow_button">🔗 เกาะติดกับปุ่มทอยอัตโนมัติ (Follow Roll Button)</option>
                                    <option value="front_right">↘️ มุมหน้าขวาของกระดาน</option>
                                    <option value="front_left">↙️ มุมหน้าซ้ายของกระดาน</option>
                                    <option value="custom_xz">🖐️ ลากวางลูกเต๋า 3D อิสระ (Custom X/Z บนกระดาน)</option>
                                </select>
                            </div>
                        </div>

                        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; margin-bottom:10px;">
                            <div>
                                <label style="font-size:11px; color:#94a3b8;">ปุ่มทอย แกน X (<span id="abs_lbl_roll_x">0</span>px)</label>
                                <input type="range" id="abs_roll_offset_x" min="-350" max="350" step="5" value="0" oninput="document.getElementById('abs_lbl_roll_x').innerText=this.value; window.updateAiBoardRollBtnPreview();">
                            </div>
                            <div>
                                <label style="font-size:11px; color:#94a3b8;">ปุ่มทอย แกน Y (<span id="abs_lbl_roll_y">0</span>px)</label>
                                <input type="range" id="abs_roll_offset_y" min="-350" max="350" step="5" value="0" oninput="document.getElementById('abs_lbl_roll_y').innerText=this.value; window.updateAiBoardRollBtnPreview();">
                            </div>
                            <div>
                                <label style="font-size:11px; color:#94a3b8;">ขนาดปุ่มทอย (<span id="abs_lbl_roll_scale">100</span>%)</label>
                                <input type="range" id="abs_roll_scale" min="70" max="150" step="5" value="100" oninput="document.getElementById('abs_lbl_roll_scale').innerText=this.value; window.updateAiBoardRollBtnPreview();">
                            </div>
                        </div>

                        <!-- 3D Dice Free Move & Scale Sliders -->
                        <div style="background:rgba(250,204,21,0.08); border:1px dashed rgba(250,204,21,0.45); border-radius:8px; padding:10px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:6px;">
                                <label style="margin:0; display:flex; align-items:center; gap:6px; font-size:12px; color:#fde047; font-weight:700; cursor:pointer;">
                                    <input type="checkbox" id="abs_sync_dice_with_btn" checked onchange="window.updateAiBoardRollBtnPreview()">
                                    <span>🔗 เมื่อลากปุ่มทอยบนจอ ให้ย้ายลูกเต๋า 3D ตามมาด้วยอัตโนมัติ</span>
                                </label>
                                <button type="button" class="btn" style="padding:3px 9px; font-size:11px; background:#facc15; color:#000; font-weight:800;" onclick="window.moveDiceAndBtnToCenterNow()">
                                    🎲 นำลูกเต๋า + ปุ่มทอย มาวางตรงกลางทันที
                                </button>
                            </div>
                            <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;">
                                <div>
                                    <label style="font-size:11px; color:#fde047;">ลูกเต๋า แกน X (<span id="abs_lbl_dice_x">0.0</span>)</label>
                                    <input type="range" id="abs_dice3d_x" min="-38" max="38" step="0.5" value="0" oninput="document.getElementById('abs_dice3d_pos').value='custom_xz'; document.getElementById('abs_lbl_dice_x').innerText=Number(this.value).toFixed(1); window.updateAiBoardStudioPreview();">
                                </div>
                                <div>
                                    <label style="font-size:11px; color:#fde047;">ลูกเต๋า แกน Z (<span id="abs_lbl_dice_z">26.0</span>)</label>
                                    <input type="range" id="abs_dice3d_z" min="-34" max="36" step="0.5" value="26" oninput="document.getElementById('abs_dice3d_pos').value='custom_xz'; document.getElementById('abs_lbl_dice_z').innerText=Number(this.value).toFixed(1); window.updateAiBoardStudioPreview();">
                                </div>
                                <div>
                                    <label style="font-size:11px; color:#fde047;">ขนาดลูกเต๋า 3D (<span id="abs_lbl_dice_scale">100</span>%)</label>
                                    <input type="range" id="abs_dice3d_scale" min="60" max="170" step="5" value="100" oninput="document.getElementById('abs_lbl_dice_scale').innerText=this.value; window.updateAiBoardStudioPreview();">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN: Interactive 3D Board Live Preview + AI City Name Manager + Action Buttons -->
            <div>
                <!-- Live 3D WebGL Preview + Draggable Roll Button & Draggable 3D Dice + Resizable Center Hole -->
                <div class="card" style="margin-bottom:16px; border:1.5px solid #10b981; padding:14px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
                        <div>
                            <h3 style="margin:0; color:#34d399; font-size:15px;">🌐 ตัวอย่างกระดาน 3D แบบเรียลไทม์ (ลากย้ายลูกเต๋า & ปุ่มทอย + ปรับขนาดตรงกลางได้)</h3>
                            <span style="font-size:11px; color:#94a3b8;">ใช้นิ้วแตะลาก (iOS/Android) หรือเมาส์ลาก <b>ปุ่มทอย</b>, <b>ลูกเต๋า 3D</b> และ <b>กรอบพื้นที่ว่างตรงกลาง</b> ได้โดยตรง</span>
                        </div>
                        <div style="display:flex; gap:5px; flex-wrap:wrap;">
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:linear-gradient(135deg,#facc15,#eab308); color:#000; font-weight:900;" onclick="window.quickCenterArenaSetup()">
                                🎯 เว้นว่างตรงกลาง + ใส่เต๋า&ปุ่มทอย
                            </button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#059669; color:#fff; font-weight:700;" onclick="window.toggleHollowCenterQuick()">
                                🕳️ สลับตรงกลาง: ว่าง/ไม่ว่าง
                            </button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#0284c7; color:#fff;" onclick="window.testRollOnStudio3DBoard()">
                                🎲 ทดสอบทอย
                            </button>
                            <button type="button" class="btn" style="padding:4px 9px; font-size:11px; background:#334155; color:#fff;" onclick="window.resetStudioCameraAngle()">
                                🎥 รีเซ็ตมุมกล้อง
                            </button>
                        </div>
                    </div>

                    <div id="abs_preview_viewport" style="position:relative; width:100%; height:390px; border-radius:12px; overflow:hidden; background:#050914; border:1.5px solid rgba(0,229,255,0.35); box-shadow:inset 0 0 30px rgba(0,0,0,0.8); touch-action:none;">
                        <canvas id="abs_three_canvas" style="width:100%; height:100%; display:block;"></canvas>

                        <!-- Top Info Overlay inside Preview -->
                        <div style="position:absolute; top:10px; left:10px; right:10px; display:flex; justify-content:space-between; pointer-events:none; font-size:11px; z-index:8;">
                            <span id="abs_preview_tag_shape" style="background:rgba(15,23,42,0.88); border:1px solid #00e5ff; color:#00e5ff; padding:3px 10px; border-radius:999px; font-weight:800;">
                                ▭ สี่เหลี่ยมผืนผ้า 12x8 (100 ช่อง)
                            </span>
                            <span id="abs_preview_tag_special" style="background:rgba(15,23,42,0.88); border:1px solid #fbbf24; color:#fbbf24; padding:3px 10px; border-radius:999px; font-weight:800;">
                                🎁 การ์ดดวง: 5 ช่อง
                            </span>
                        </div>

                        <!-- Interactive Resizable Hollow Center Zone Frame (แสดงเมื่อเปิดโหมดเว้นที่ว่างตรงกลาง) -->
                        <div id="abs_preview_center_zone_box"
                            style="display:none; position:absolute; top:50%; left:50%; width:220px; height:115px; transform:translate(-50%, -50%); border:2px dashed #facc15; border-radius:12px; background:rgba(250,204,21,0.06); box-shadow:0 0 20px rgba(250,204,21,0.22), inset 0 0 15px rgba(250,204,21,0.08); pointer-events:none; z-index:9;">
                            <div style="position:absolute; top:-20px; left:50%; transform:translateX(-50%); background:rgba(15,23,42,0.92); border:1px solid #facc15; color:#fde047; font-size:10px; font-weight:800; padding:1px 8px; border-radius:999px; white-space:nowrap;">
                                🕳️ พื้นที่ว่างตรงกลาง (<span id="abs_center_box_dim_lbl">6.0 × 3.5</span> ช่อง)
                            </div>
                            <!-- Corner Resize Handle (Mouse + Touch iOS/Android) -->
                            <div id="abs_center_zone_resize_handle" title="ลากเพื่อปรับขนาดความกว้าง × ความยาว ของพื้นที่ว่างตรงกลาง"
                                style="position:absolute; right:-10px; bottom:-10px; width:26px; height:26px; border-radius:8px; background:linear-gradient(135deg,#facc15,#eab308); color:#000; font-size:13px; font-weight:900; display:flex; align-items:center; justify-content:center; cursor:nwse-resize; pointer-events:auto; box-shadow:0 2px 10px rgba(0,0,0,0.6); user-select:none; touch-action:none;">
                                ↘️
                            </div>
                        </div>

                        <!-- Draggable 3D Dice Handle inside Preview (ลากย้ายลูกเต๋า 3D ได้อิสระทั้ง PC, iOS, Android) -->
                        <div id="abs_preview_dice3d_handle" title="ใช้นิ้วหรือเมาส์ลากเพื่อย้ายตำแหน่งลูกเต๋า 3D บนกระดาน"
                            style="position:absolute; bottom:58px; left:50%; transform:translate(-50%, -50%); background:rgba(15,23,42,0.92); border:2px solid #facc15; border-radius:999px; padding:4px 11px; display:flex; align-items:center; gap:6px; box-shadow:0 0 18px rgba(250,204,21,0.55); cursor:grab; user-select:none; touch-action:none; z-index:12;">
                            <span style="font-size:15px;">🎲🎲</span>
                            <span style="font-size:11px; font-weight:900; color:#fde047; white-space:nowrap;">ลูกเต๋า 3D (ลากย้ายได้)</span>
                        </div>

                        <!-- Simulated Interactive Dice Station / Roll Button inside Preview -->
                        <div id="abs_preview_dice_station" title="ลากเพื่อย้ายตำแหน่งปุ่มทอยลูกเต๋าบนกระดาน"
                            style="position:absolute; bottom:12px; left:50%; transform:translateX(-50%); background:rgba(15,23,42,0.94); border:1.5px solid #00e5ff; border-radius:12px; padding:6px 12px; display:flex; align-items:center; gap:8px; box-shadow:0 0 20px rgba(0,229,255,0.45); cursor:grab; user-select:none; touch-action:none; z-index:11;">
                            <div style="display:flex; gap:4px;">
                                <span id="abs_sim_d1" style="width:24px; height:24px; background:#fff; color:#000; border-radius:5px; display:inline-flex; align-items:center; justify-content:center; font-weight:900; font-size:14px;">⚅</span>
                                <span id="abs_sim_d2" style="width:24px; height:24px; background:#fff; color:#000; border-radius:5px; display:inline-flex; align-items:center; justify-content:center; font-weight:900; font-size:14px;">⚅</span>
                            </div>
                            <button type="button" onclick="window.testRollOnStudio3DBoard()" style="background:linear-gradient(135deg,#00e5ff,#0077ff); color:#000; font-weight:900; border:none; border-radius:8px; padding:5px 12px; font-size:12px; cursor:pointer; display:flex; align-items:center; gap:4px;">
                                <span>🎲</span> ทอย
                            </button>
                            <span style="font-size:10px; color:#94a3b8;">✥ ลากปุ่มทอย</span>
                        </div>
                    </div>
                </div>

                <!-- 5. AI City Names Generator & Tile-by-Tile Editor -->
                <div class="card" style="margin-bottom:16px; border:1px solid rgba(56,189,248,0.35);">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
                        <h3 style="margin:0; color:#38bdf8; font-size:15px;">🏙️ 5. จัดการชื่อเมืองทุกช่อง (ให้ AI ตั้งชื่อได้ & แก้ไขรายช่องได้)</h3>
                        <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                            <select id="abs_ai_city_style" style="padding:5px 8px; font-size:12px; width:auto;">
                                <option value="thai_famous">🇹🇭 จังหวัดและแลนด์มาร์คไทย</option>
                                <option value="world_metropolis">🌍 มหานครระดับโลก (World Cities)</option>
                                <option value="cyber_galaxy">🚀 นครไซเบอร์ & ดาราจักร (Sci-Fi)</option>
                                <option value="mythic_kingdom">🛕 อาณาจักรเทพนิยาย & หิมพานต์</option>
                            </select>
                            <input type="text" id="abs_ai_city_prefix" placeholder="คำนำหน้า (เช่น นคร...)" style="width:110px; padding:5px 8px; font-size:12px;">
                            <button type="button" class="btn" style="padding:6px 12px; font-size:12px; background:linear-gradient(135deg,#06b6d4,#3b82f6); color:#fff; font-weight:800;" onclick="window.aiGenerateBoardCityNames(false)">
                                🤖 ให้ AI ตั้งชื่อเมือง
                            </button>
                            <button type="button" class="btn" style="padding:6px 10px; font-size:12px; background:#a855f7; color:#fff;" onclick="window.aiGenerateBoardCityNames(true)">
                                🔀 AI สุ่มสลับชื่อ
                            </button>
                        </div>
                    </div>

                    <!-- Filter / Search Tile -->
                    <div style="display:flex; gap:8px; margin-bottom:8px;">
                        <input type="text" id="abs_city_search" placeholder="🔍 ค้นหาเลขช่อง หรือชื่อเมือง..." oninput="window.renderAiBoardCityEditorGrid()" style="flex:1; padding:6px 10px; font-size:12px;">
                        <select id="abs_city_filter_type" onchange="window.renderAiBoardCityEditorGrid()" style="width:170px; padding:6px 8px; font-size:12px;">
                            <option value="ALL">แสดงทุกช่อง</option>
                            <option value="CHANCE">🎁 เฉพาะช่องการ์ดดวง</option>
                            <option value="SPECIAL">⭐ ช่องพิเศษทั้งหมด</option>
                            <option value="NORMAL">🏙️ เฉพาะช่องเมืองปกติ</option>
                        </select>
                    </div>

                    <!-- Scrollable Grid of Tiles for Editing City Names & Clicking to Toggle Chance/Special -->
                    <div id="abs_city_editor_grid" style="max-height:230px; overflow-y:auto; display:grid; grid-template-columns:repeat(auto-fill, minmax(175px, 1fr)); gap:6px; padding:6px; background:rgba(3,7,18,0.65); border:1px solid rgba(255,255,255,0.08); border-radius:10px;">
                        <!-- Populated by JS -->
                    </div>
                </div>

                <!-- 6. Save, Activate Playable Immediately, or Cancel -->
                <div class="card" style="background:rgba(16,185,129,0.1); border:2px solid #10b981;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                        <label style="margin:0; display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13.5px; font-weight:800; color:#34d399;">
                            <input type="checkbox" id="abs_is_active" checked style="width:18px; height:18px;">
                            <span>🟢 เปิดใช้งานกระดานนี้ในระบบ (ให้ผู้เล่นเลือกเล่นได้)</span>
                        </label>
                        <label style="margin:0; display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13.5px; font-weight:800; color:#fde047;">
                            <input type="checkbox" id="abs_is_default" checked style="width:18px; height:18px;">
                            <span>⭐ ตั้งเป็นกระดานหลักพร้อมเล่นทันทีเมื่อเข้าเกม</span>
                        </label>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <button type="button" class="btn btn-accent" style="padding:12px; font-size:14px; font-weight:900; background:linear-gradient(135deg,#10b981,#059669); color:#fff; border:none;" onclick="window.saveAiCustomBoard(false)">
                            💾 บันทึกกระดาน 3D
                        </button>
                        <button type="button" class="btn" style="padding:12px; font-size:14px; font-weight:900; background:linear-gradient(135deg,#facc15,#f59e0b); color:#000; border:none;" onclick="window.saveAiCustomBoard(true)">
                            🚀 บันทึก & เปิดเล่นกระดานนี้ทันที!
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Saved Custom Boards List Table -->
        <div class="card" style="margin-top:20px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
                <h3 style="margin:0; color:#fde047; font-size:16px;">📋 รายการกระดาน 3D ที่สร้างไว้ทั้งหมด (สามารถกดใช้เล่นทันที หรือกดยกเลิกได้ตลอดเวลา)</h3>
                <button type="button" class="btn" style="padding:6px 12px; font-size:12px;" onclick="window.loadCustomBoardsListAdmin()">🔄 รีเฟรชรายการ</button>
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>รหัส</th>
                            <th>ชื่อกระดาน 3D</th>
                            <th>รูปทรง & ขนาด</th>
                            <th>การ์ดดวง & ช่องพิเศษ</th>
                            <th>ตำแหน่งปุ่มทอย</th>
                            <th>สถานะ</th>
                            <th>การจัดการ (เล่นทันที / ยกเลิก / แก้ไข)</th>
                        </tr>
                    </thead>
                    <tbody id="abs_boards_table_body">
                        <tr><td colspan="7" style="text-align:center; color:#94a3b8;">กำลังโหลดข้อมูลกระดาน 3D...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

            </main>
        </div>
    </div>

    <div id="toast" class="toast"></div>

    <script>
        // ============================================================
        // 🛡️ Resilient Admin Fetch Wrapper (Auto-Retry + XHR Fallback for QUIC/Port :7175)
        // ============================================================
        if (!window.__adminResilientFetchInstalled) {
            window.__adminResilientFetchInstalled = true;
            const _nativeFetch = window.fetch.bind(window);

            function _xhrFallback(url, options = {}) {
                return new Promise((resolve, reject) => {
                    try {
                        const xhr = new XMLHttpRequest();
                        const method = (options.method || 'GET').toUpperCase();
                        const sep = String(url).includes('?') ? '&' : '?';
                        xhr.open(method, String(url) + sep + '_xhr=' + Date.now(), true);
                        xhr.withCredentials = true;
                        if (options.headers && typeof options.headers === 'object') {
                            Object.keys(options.headers).forEach(k => {
                                xhr.setRequestHeader(k, options.headers[k]);
                            });
                        }
                        xhr.onload = () => {
                            const bodyText = xhr.responseText || '';
                            resolve({
                                ok: xhr.status >= 200 && xhr.status < 300,
                                status: xhr.status,
                                text: async () => bodyText,
                                json: async () => JSON.parse(bodyText)
                            });
                        };
                        xhr.onerror = () => reject(new Error('XHR network connection failed'));
                        xhr.ontimeout = () => reject(new Error('XHR request timed out'));
                        xhr.timeout = 45000;
                        xhr.send(options.body || null);
                    } catch (err) {
                        reject(err);
                    }
                });
            }

            window.fetch = async function(input, init) {
                try {
                    return await _nativeFetch(input, init);
                } catch (err) {
                    console.warn('[AdminFetch] Primary fetch failed, retrying via fallback:', err);
                    await new Promise(r => setTimeout(r, 200));
                    try {
                        const retryUrl = typeof input === 'string'
                            ? input + (input.includes('?') ? '&' : '?') + '_rt=' + Date.now()
                            : input;
                        return await _nativeFetch(retryUrl, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, init || {}));
                    } catch (err2) {
                        if (typeof input === 'string') {
                            return await _xhrFallback(input, init || {});
                        }
                        throw err2;
                    }
                }
            };
        }

        // ============================================================
        // 🔔 Global Toast, Popup & Core Admin Action Helpers
        // ============================================================
        function showToast(msg, type = 'auto') {
            let t = document.getElementById('toast');
            if (!t) {
                t = document.createElement('div');
                t.id = 'toast';
                t.className = 'toast';
                document.body.appendChild(t);
            }
            const text = String(msg ?? 'ดำเนินการสำเร็จ');
            t.innerText = text;
            const isErr = type === 'error' || text.startsWith('❌') || text.includes('ผิดพลาด');
            const isWarn = type === 'warning' || text.startsWith('⚠️');
            t.style.background = isErr ? '#ef4444' : (isWarn ? '#f59e0b' : 'var(--success, #10b981)');
            t.style.color = isWarn ? '#000' : '#fff';
            t.style.zIndex = '1000000';
            t.style.boxShadow = '0 10px 28px rgba(0,0,0,0.55)';
            t.style.display = 'block';
            if (window.__adminToastTimer) clearTimeout(window.__adminToastTimer);
            window.__adminToastTimer = setTimeout(() => {
                t.style.display = 'none';
            }, 3500);
        }
        window.showToast = showToast;

        function showAdminPopup(options = {}) {
            let modal = document.getElementById('modal-admin-alert-popup');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'modal-admin-alert-popup';
                modal.className = 'modal-overlay';
                modal.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(3,7,18,0.85); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px); z-index:999999; justify-content:center; align-items:center; padding:16px;';
                modal.innerHTML = `
                    <div class="modal-content glass-panel" style="width:min(90vw, 440px); background:radial-gradient(circle at 50% 0%, #172554 0%, #090d16 100%); border:1.5px solid rgba(0,229,255,0.4); border-radius:18px; padding:24px 20px; box-shadow:0 0 50px rgba(0,0,0,0.85), 0 0 25px rgba(0,229,255,0.25); text-align:center;">
                        <div id="admin-popup-icon" style="font-size:46px; line-height:1; margin-bottom:12px; filter:drop-shadow(0 0 15px rgba(0,229,255,0.5));">🔔</div>
                        <h3 id="admin-popup-title" style="font-size:18px; font-weight:800; color:#00e5ff; margin-bottom:8px; text-shadow:0 0 10px rgba(0,229,255,0.3);">แจ้งเตือน</h3>
                        <p id="admin-popup-message" style="font-size:13px; color:#cbd5e1; line-height:1.5; margin-bottom:20px; word-break:break-word; white-space:pre-line;">รายละเอียด</p>
                        <div id="admin-popup-actions" style="display:flex; justify-content:center; gap:10px;">
                            <button id="admin-popup-btn-confirm" type="button" class="btn" style="min-width:110px; padding:10px 20px; border-radius:10px; background:linear-gradient(135deg, #00e5ff, #0284c7); color:#000; font-weight:700; font-size:14px; border:none; cursor:pointer; box-shadow:0 0 15px rgba(0,229,255,0.4);">ตกลง</button>
                            <button id="admin-popup-btn-cancel" type="button" class="btn" style="display:none; min-width:90px; padding:10px 16px; border-radius:10px; background:rgba(255,255,255,0.1); color:#94a3b8; font-weight:600; font-size:13px; border:1px solid rgba(255,255,255,0.15); cursor:pointer;">ยกเลิก</button>
                        </div>
                    </div>`;
                document.body.appendChild(modal);
            }

            const type = options.type || 'info';
            const iconEl = modal.querySelector('#admin-popup-icon');
            const titleEl = modal.querySelector('#admin-popup-title');
            const msgEl = modal.querySelector('#admin-popup-message');
            const confirmBtn = modal.querySelector('#admin-popup-btn-confirm');
            const cancelBtn = modal.querySelector('#admin-popup-btn-cancel');

            let defaultIcon = '🔔';
            let titleColor = '#00e5ff';
            let btnBg = 'linear-gradient(135deg, #00e5ff, #0284c7)';
            let btnColor = '#000';

            if (type === 'success') {
                defaultIcon = '✅';
                titleColor = '#10b981';
                btnBg = 'linear-gradient(135deg, #10b981, #059669)';
                btnColor = '#fff';
            } else if (type === 'error') {
                defaultIcon = '❌';
                titleColor = '#ef4444';
                btnBg = 'linear-gradient(135deg, #ef4444, #dc2626)';
                btnColor = '#fff';
            } else if (type === 'warning') {
                defaultIcon = '⚠️';
                titleColor = '#f59e0b';
                btnBg = 'linear-gradient(135deg, #f59e0b, #d97706)';
                btnColor = '#000';
            }

            if (iconEl) iconEl.innerText = options.icon || defaultIcon;
            if (titleEl) {
                titleEl.innerText = options.title || (type === 'success' ? 'สำเร็จ!' : type === 'error' ? 'เกิดข้อผิดพลาด' : 'แจ้งเตือน');
                titleEl.style.color = titleColor;
            }
            if (msgEl) msgEl.innerText = options.message || '';

            if (confirmBtn) {
                confirmBtn.innerText = options.confirmText || 'ตกลง';
                confirmBtn.style.background = btnBg;
                confirmBtn.style.color = btnColor;
                confirmBtn.onclick = () => {
                    modal.style.display = 'none';
                    if (typeof options.onConfirm === 'function') options.onConfirm();
                };
            }

            if (cancelBtn) {
                if (options.showCancel) {
                    cancelBtn.style.display = 'inline-block';
                    cancelBtn.innerText = options.cancelText || 'ยกเลิก';
                    cancelBtn.onclick = () => {
                        modal.style.display = 'none';
                        if (typeof options.onCancel === 'function') options.onCancel();
                    };
                } else {
                    cancelBtn.style.display = 'none';
                }
            }

            modal.style.display = 'flex';
        }
        window.showAdminPopup = showAdminPopup;

        async function submitCreateEvent() {
            try {
                const form = document.getElementById('createEventForm');
                if (!form) return;
                const data = Object.fromEntries(new FormData(form));
                const res = await fetch('admin_panel.php?api=1&action=create_event', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const json = await res.json();
                showToast(json.message || 'บันทึกกิจกรรมสำเร็จ');
                if (json.status === 'success') setTimeout(() => location.reload(), 1200);
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }

        async function saveSkill(id, name, unit) {
            try {
                const power = document.getElementById('sk_power_' + id)?.value || 0;
                const chance = document.getElementById('sk_chance_' + id)?.value || 0;
                const res = await fetch('admin_panel.php?api=1&action=update_skill', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        name: name,
                        base_power_value: parseFloat(power),
                        trigger_chance_percent: parseFloat(chance),
                        power_unit: unit,
                        is_active: 1
                    })
                });
                const json = await res.json();
                showToast(json.message || 'บันทึกสกิลสำเร็จ');
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }

        async function saveCharOverride(id, skillId) {
            try {
                const power = document.getElementById('char_power_' + id)?.value ?? '';
                const res = await fetch('admin_panel.php?api=1&action=update_character_override', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        character_id: id,
                        skill_id: skillId,
                        override_power: power !== '' ? parseFloat(power) : null
                    })
                });
                const json = await res.json();
                showToast(json.message || 'บันทึกค่าพลังตัวละครสำเร็จ');
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }

        async function saveDiceStats(id) {
            try {
                const ctrl = document.getElementById('dice_ctrl_' + id)?.value || 0;
                const res = await fetch('admin_panel.php?api=1&action=update_dice_stats', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        dice_control_rate: parseFloat(ctrl)
                    })
                });
                const json = await res.json();
                showToast(json.message || 'บันทึกค่าลูกเต๋าสำเร็จ');
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }

                let adminRoomSettingsCache = {};
        let adminRankingCountdownInterval = null;
        async function loadAdminRankingSettings() {
            try {
                const res = await fetch('../api/leaderboard.php?type=ranking_config');
                const json = await res.json();
                if (json.status !== 'success') return;
                const cfg = json.ranking_config || {};
                const reset = json.weekly_reset_info || {};
                const titleEl = document.getElementById('adm_season_title');
                const cycleEl = document.getElementById('adm_season_cycle');
                const nextEl = document.getElementById('adm_next_reset_text');
                const countEl = document.getElementById('adm_countdown_text');
                if (titleEl) titleEl.innerText = 'Season #' + (reset.season_number || 1);
                if (cycleEl) cycleEl.innerText = reset.rule_description || 'แข่งจัดอันดับ 1 สัปดาห์ • รีเซ็ตทุกวันพุธ 10:00 น.';
                if (nextEl) nextEl.innerText = reset.next_reset_at || 'วันพุธ 10:00 น.';
                if (countEl) {
                    if (adminRankingCountdownInterval) clearInterval(adminRankingCountdownInterval);
                    let remSec = reset.seconds_remaining || 0;
                    const updateCd = () => {
                        const d = Math.floor(remSec / 86400);
                        const h = Math.floor((remSec % 86400) / 3600);
                        const m = Math.floor((remSec % 3600) / 60);
                        const s = remSec % 60;
                        countEl.innerText = `⏳ เหลือเวลาอีก ${d} วัน ${h} ชม. ${m} นาที ${s} วินาที`;
                        if (remSec > 0) remSec--;
                    };
                    updateCd();
                    adminRankingCountdownInterval = setInterval(updateCd, 1000);
                }
                const setVal = (id, val) => {
                    const el = document.getElementById(id);
                    if (el && val !== undefined && val !== null) el.value = val;
                };
                setVal('cfg_points_4p_rank1', cfg.points_4p_rank1 ?? 35);
                setVal('cfg_gold_4p_rank1', cfg.gold_4p_rank1 ?? 150000);
                setVal('cfg_points_4p_rank2', cfg.points_4p_rank2 ?? 10);
                setVal('cfg_gold_4p_rank2', cfg.gold_4p_rank2 ?? 0);
                setVal('cfg_points_4p_rank3', cfg.points_4p_rank3 ?? -10);
                setVal('cfg_gold_4p_rank3', cfg.gold_4p_rank3 ?? -30000);
                setVal('cfg_points_4p_rank4', cfg.points_4p_rank4 ?? -25);
                setVal('cfg_gold_4p_rank4', cfg.gold_4p_rank4 ?? -50000);
                setVal('cfg_points_1v1_win', cfg.points_1v1_win ?? 25);
                setVal('cfg_points_1v1_loss', cfg.points_1v1_loss ?? -20);
                setVal('cfg_maintain_min_matches', cfg.maintain_min_matches ?? 5);
                setVal('cfg_maintain_min_points', cfg.maintain_min_points ?? 1000);
            } catch (e) {
                console.warn('loadAdminRankingSettings error:', e);
            }
        }
        async function loadRoomEconomySettings() {
            const container = document.getElementById('room_economy_cards_container');
            if (!container) return;
            try {
                const res = await fetch('admin_panel.php?api=1&action=get_room_settings');
                const json = await res.json();
                if (json.status !== 'success' || !json.rooms) {
                    container.innerHTML = '<div style="color:#ef4444;">โหลดข้อมูลตั้งค่าห้องไม่สำเร็จ</div>';
                    return;
                }
                adminRoomSettingsCache = json.rooms;
                const order = ['2M', '5M', '10M', 'PRACTICE'];
                const badgeMap = {
                    '2M': { color: '#06b6d4', icon: '🥉', sub: 'ห้องมาตรฐาน (จ่ายค่าเข้าเบาๆ 2,000 ทอง • เริ่มต้นในเกม 2M)' },
                    '5M': { color: '#f59e0b', icon: '🥈', sub: 'ห้องระดับเซียน (เริ่มต้นในเกม 5M)' },
                    '10M': { color: '#ec4899', icon: '🥇', sub: 'ห้องมหาเศรษฐี (เริ่มต้นในเกม 10M)' },
                    'PRACTICE': { color: '#10b981', icon: '🎯', sub: 'โหมดทดลองเล่นหน้ากระดานหลัก (เล่นฟรี ไม่เสียค่าเข้า)' }
                };

                container.innerHTML = order.map(tier => {
                    const r = json.rooms[tier] || {};
                    const meta = badgeMap[tier] || { color: '#06b6d4', icon: '🎲', sub: '' };
                    const isPractice = tier === 'PRACTICE';
                    return `
                        <div style="background:#0b1120; border:1px solid ${meta.color}; border-radius:12px; padding:18px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid var(--panel-border); padding-bottom:10px;">
                                <div>
                                    <div style="font-size:17px; font-weight:700; color:${meta.color};">${meta.icon} รหัสห้อง: ${tier}</div>
                                    <div style="font-size:12px; color:var(--text-muted);">${meta.sub}</div>
                                </div>
                                <span class="badge" style="background:${meta.color}; color:#000;">${tier}</span>
                            </div>

                            <div class="form-group">
                                <label>ชื่อห้องที่แสดงในหน้า Lobby</label>
                                <input type="text" id="rm_title_${tier}" value="${(r.room_title || '').replace(/"/g, '&quot;')}">
                            </div>

                            <div class="grid-2" style="gap:12px; grid-template-columns: 1fr 1fr;">
                                <div class="form-group">
                                    <label style="color:#fbbf24; font-weight:600;">🎟️ ค่าผ่านทางเข้าเล่น (หักทองกระเป๋าหลัก)</label>
                                    <input type="number" id="rm_fee_${tier}" value="${r.entry_fee_gold ?? 0}" min="0" step="100" ${isPractice ? 'readonly style="opacity:0.65;"' : ''}>
                                </div>
                                <div class="form-group">
                                    <label style="color:#34d399; font-weight:600;">💰 เงินทองเริ่มต้นในกระดาน (Match Gold)</label>
                                    <input type="number" id="rm_start_gold_${tier}" value="${r.start_match_gold ?? 2000000}" min="100000" step="100000">
                                </div>
                            </div>

                            <div class="grid-2" style="gap:12px; grid-template-columns: 1fr 1fr;">
                                <div class="form-group">
                                    <label style="color:#00e5ff; font-weight:600;">💎 รางวัลเพชรเมื่อชนะ</label>
                                    <input type="number" id="rm_rew_dia_${tier}" value="${r.reward_diamond ?? 0}" min="0">
                                </div>
                                <div class="form-group">
                                    <label style="color:#ffd700; font-weight:600;">🪙 รางวัลทองเข้ากระเป๋าเมื่อชนะ</label>
                                    <input type="number" id="rm_rew_gold_${tier}" value="${r.reward_gold ?? 0}" min="0" step="1000">
                                </div>
                            </div>

                            <div class="grid-2" style="gap:12px; grid-template-columns: 1fr 1fr 1fr;">
                                <div class="form-group">
                                    <label>💸 ค่าภาษีช่อง TAX</label>
                                    <input type="number" id="rm_tax_${tier}" value="${r.tax_amount ?? 150000}" min="0" step="10000">
                                </div>
                                <div class="form-group">
                                    <label>🏠 ค่าสร้างเมืองเริ่มต้น/หลัง</label>
                                    <input type="number" id="rm_city_cost_${tier}" value="${r.city_base_cost ?? 120000}" min="10000" step="10000">
                                </div>
                                <div class="form-group">
                                    <label>🏛️ ค่าสร้างแลนด์มาร์ค</label>
                                    <input type="number" id="rm_landmark_cost_${tier}" value="${r.landmark_cost ?? 320000}" min="20000" step="20000">
                                </div>
                            </div>

                            <div class="grid-2" style="gap:12px; grid-template-columns: 1fr 1fr;">
                                <div class="form-group">
                                    <label>🚧 อัตราเก็บค่าผ่านทาง (% ของมูลค่าเมือง)</label>
                                    <input type="number" id="rm_toll_pct_${tier}" value="${r.toll_percent ?? 85}" min="10" max="500">
                                </div>
                                <div class="form-group">
                                    <label>💼 อัตราซื้อต่อเมือง (% ของมูลค่าเมือง • ยกเว้นแลนด์มาร์ค)</label>
                                    <input type="number" id="rm_buyout_pct_${tier}" value="${r.buyout_percent ?? 160}" min="100" max="500">
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            } catch (err) {
                container.innerHTML = '<div style="color:#ef4444;">เกิดข้อผิดพลาดในการโหลดตั้งค่าห้อง</div>';
            }
        }

        async function saveAllRoomEconomySettings() {
            try {
                const order = ['2M', '5M', '10M', 'PRACTICE'];
                const rooms = [];
                for (const tier of order) {
                    const titleEl = document.getElementById('rm_title_' + tier);
                    if (!titleEl) continue;
                    rooms.push({
                        room_tier: tier,
                        room_title: titleEl.value.trim(),
                        entry_fee_gold: parseInt(document.getElementById('rm_fee_' + tier)?.value || '0', 10),
                        start_match_gold: parseInt(document.getElementById('rm_start_gold_' + tier)?.value || '2000000', 10),
                        reward_diamond: parseInt(document.getElementById('rm_rew_dia_' + tier)?.value || '0', 10),
                        reward_gold: parseInt(document.getElementById('rm_rew_gold_' + tier)?.value || '0', 10),
                        tax_amount: parseInt(document.getElementById('rm_tax_' + tier)?.value || '150000', 10),
                        city_base_cost: parseInt(document.getElementById('rm_city_cost_' + tier)?.value || '120000', 10),
                        landmark_cost: parseInt(document.getElementById('rm_landmark_cost_' + tier)?.value || '320000', 10),
                        toll_percent: parseInt(document.getElementById('rm_toll_pct_' + tier)?.value || '85', 10),
                        buyout_percent: parseInt(document.getElementById('rm_buyout_pct_' + tier)?.value || '160', 10)
                    });
                }
                const res = await fetch('admin_panel.php?api=1&action=save_room_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ rooms })
                });
                const json = await res.json();
                showToast(json.message || 'บันทึกสำเร็จ!');
                if (json.status === 'success') {
                    loadRoomEconomySettings();
                }
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }
        async function manualResetSeasonAdmin() {
            if (!confirm('⚠️ ยืนยันการสั่งรีเซ็ตอันดับประจำสัปดาห์ทันทีหรือไม่?\n\nระบบจะเริ่มนับ Season ใหม่ และปรับคะแนนจัดอันดับของผู้เล่นเพื่อแข่งขันสัปดาห์ใหม่')) return;
            try {
                const res = await fetch('../api/leaderboard.php?action=manual_reset_season', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const json = await res.json();
                showToast('✅ ' + (json.message || 'รีเซ็ตอันดับสำเร็จ!'));
                if (typeof loadAdminRankingSettings === 'function') loadAdminRankingSettings();
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาด: ' + (e.message || ''), 'error');
            }
        }

        async function saveAdminRankingSettings() {
            const getVal = (id, fallback) => {
                const el = document.getElementById(id);
                return el ? el.value.trim() : fallback;
            };
            const payload = {
                points_4p_rank1: getVal('cfg_points_4p_rank1', '35'),
                gold_4p_rank1: getVal('cfg_gold_4p_rank1', '150000'),
                points_4p_rank2: getVal('cfg_points_4p_rank2', '10'),
                gold_4p_rank2: getVal('cfg_gold_4p_rank2', '0'),
                points_4p_rank3: getVal('cfg_points_4p_rank3', '-10'),
                gold_4p_rank3: getVal('cfg_gold_4p_rank3', '-30000'),
                points_4p_rank4: getVal('cfg_points_4p_rank4', '-25'),
                gold_4p_rank4: getVal('cfg_gold_4p_rank4', '-50000'),
                points_1v1_win: getVal('cfg_points_1v1_win', '25'),
                points_1v1_loss: getVal('cfg_points_1v1_loss', '-20'),
                maintain_min_matches: getVal('cfg_maintain_min_matches', '5'),
                maintain_min_points: getVal('cfg_maintain_min_points', '1000')
            };
            try {
                const res = await fetch('../api/leaderboard.php?action=save_ranking_config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                showToast('✅ ' + (json.message || 'บันทึกการตั้งค่าสำเร็จ!'));
                if (typeof loadAdminRankingSettings === 'function') loadAdminRankingSettings();
            } catch (e) {
                showToast('❌ เกิดข้อผิดพลาดในการบันทึก: ' + (e.message || ''), 'error');
            }
        }

        // Initialize active tab on load
        document.addEventListener('DOMContentLoaded', () => {
            let initialTab = 'events';
            try {
                const saved = localStorage.getItem('snake_admin_active_tab');
                if (saved && document.getElementById('tab-' + saved)) {
                    initialTab = saved;
                }
            } catch(e) {}
            switchTab(initialTab);
        });
        let currentAdminAvatarUrl = <?= json_encode($currentAdmin['avatar_url'] ?: '') ?>;
        if (!currentAdminAvatarUrl && typeof localStorage !== 'undefined') {
            currentAdminAvatarUrl = localStorage.getItem('snake_admin_avatar') || '../avatars/avatar_01.png';
        }

        async function handleAdminAvatarUpload(e) {
            const file = e.target.files && e.target.files[0];
            if (!file) return;

            if (!file.type.startsWith('image/')) {
                showAdminPopup({
                    type: 'warning',
                    title: 'รูปแบบไฟล์ไม่ถูกต้อง',
                    message: 'กรุณาเลือกไฟล์รูปภาพ (PNG, JPG, WEBP)'
                });
                return;
            }

            const reader = new FileReader();
            reader.onload = async function(evt) {
                const rawData = evt.target.result;
                const img = new Image();
                img.onload = async function() {
                    const maxDim = 320;
                    let w = img.width;
                    let h = img.height;
                    if (w > maxDim || h > maxDim) {
                        if (w > h) {
                            h = Math.round((h * maxDim) / w);
                            w = maxDim;
                        } else {
                            w = Math.round((w * maxDim) / h);
                            h = maxDim;
                        }
                    }
                    const canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, w, h);
                    const base64Data = canvas.toDataURL('image/png', 0.88);

                    currentAdminAvatarUrl = base64Data;
                    try {
                        localStorage.setItem('snake_admin_avatar', base64Data);
                    } catch(e) {}

                    // อัปเดตรูปแสดงผลทันที
                    const topBarImg = document.getElementById('top-bar-admin-avatar');
                    if (topBarImg) topBarImg.src = base64Data;
                    const profilePreview = document.getElementById('adm_avatar_preview');
                    if (profilePreview) profilePreview.src = base64Data;

                    // สลับไปที่โหมดสวมรูปแอดมินใน AI Frame Studio
                    if (typeof setAiPreviewCenterMode === 'function') {
                        setAiPreviewCenterMode('sample_avatar');
                    } else if (typeof updateAiPreview === 'function') {
                        updateAiPreview();
                    }

                    // ส่งไปบันทึกลงฐานข้อมูล
                    try {
                        const res = await fetch('admin_panel.php?api=1&action=update_admin_avatar', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ avatar_url: base64Data })
                        }).then(r => r.json());

                        if (res && res.status === 'success') {
                            showAdminPopup({
                                type: 'success',
                                icon: '📸✅',
                                title: 'อัปเดตรูปโปรไฟล์สำเร็จ!',
                                message: 'เปลี่ยนรูปโปรไฟล์แอดมินเรียบร้อยแล้ว'
                            });
                        }
                    } catch(err) {
                        console.error('update_admin_avatar error:', err);
                    }
                };
                img.src = rawData;
            };
            reader.readAsDataURL(file);
        }

        // --- Admin Account & User Management Scripts ---
        async function submitUpdateAdminAccount(e) {
            e.preventDefault();
            const submitBtn = document.querySelector('#adminProfileForm button[type="submit"]');
            const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';

            const payload = {
                username: document.getElementById('adm_username').value.trim(),
                display_name: document.getElementById('adm_display_name').value.trim(),
                email: document.getElementById('adm_email').value.trim(),
                current_password: document.getElementById('adm_current_password').value,
                new_password: document.getElementById('adm_new_password').value,
                confirm_password: document.getElementById('adm_confirm_password').value
            };

            if (payload.new_password && payload.new_password !== payload.confirm_password) {
                showAdminPopup({
                    type: 'warning',
                    icon: '⚠️',
                    title: 'รหัสผ่านไม่ตรงกัน',
                    message: 'รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน กรุณาตรวจสอบอีกครั้ง'
                });
                return;
            }

            try {
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '⏳ กำลังบันทึกข้อมูล...';
                }

                const res = await fetch('admin_panel.php?api=1&action=update_admin_account', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(r => r.json());

                if (res.status === 'success') {
                    document.getElementById('adm_current_password').value = '';
                    document.getElementById('adm_new_password').value = '';
                    document.getElementById('adm_confirm_password').value = '';
                    showAdminPopup({
                        type: 'success',
                        icon: '🔐✅',
                        title: 'บันทึกข้อมูลแอดมินสำเร็จ!',
                        message: res.message || 'บันทึกข้อมูลส่วนตัวและรหัสผ่านเรียบร้อยแล้ว',
                        confirmText: 'ตกลง (รีโหลดหน้า)',
                        onConfirm: () => location.reload()
                    });
                } else {
                    showAdminPopup({
                        type: 'error',
                        icon: '❌',
                        title: 'ไม่สามารถบันทึกข้อมูลได้',
                        message: res.message || 'รหัสผ่านปัจจุบันไม่ถูกต้อง หรือข้อมูลไม่สมบูรณ์'
                    });
                }
            } catch (err) {
                console.error('submitUpdateAdminAccount error:', err);
                showAdminPopup({
                    type: 'error',
                    title: 'เกิดข้อผิดพลาด',
                    message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์ กรุณาลองใหม่อีกครั้ง'
                });
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = origBtnHtml || '💾 บันทึกข้อมูลแอดมิน / เปลี่ยนรหัสผ่าน';
                }
            }
        }

        async function submitCreateAdmin(e) {
            e.preventDefault();
            const submitBtn = document.querySelector('#createAdminForm button[type="submit"]');
            const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';

            const payload = {
                username: document.getElementById('new_adm_user').value.trim(),
                display_name: document.getElementById('new_adm_name').value.trim(),
                password: document.getElementById('new_adm_pass').value,
                email: document.getElementById('new_adm_email').value.trim()
            };

            try {
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '⏳ กำลังสร้างบัญชี...';
                }

                const res = await fetch('admin_panel.php?api=1&action=create_admin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(r => r.json());

                if (res.status === 'success') {
                    showAdminPopup({
                        type: 'success',
                        icon: '👤✅',
                        title: 'สร้างบัญชีแอดมินสำเร็จ!',
                        message: res.message || 'สร้างบัญชีผู้ดูแลระบบใหม่เรียบร้อยแล้ว',
                        confirmText: 'ตกลง',
                        onConfirm: () => location.reload()
                    });
                } else {
                    showAdminPopup({
                        type: 'error',
                        title: 'ไม่สามารถสร้างบัญชีได้',
                        message: res.message || 'เกิดข้อผิดพลาดในการสร้างแอดมิน'
                    });
                }
            } catch (err) {
                console.error('submitCreateAdmin error:', err);
                showAdminPopup({
                    type: 'error',
                    title: 'เกิดข้อผิดพลาด',
                    message: 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์'
                });
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = origBtnHtml || '➕ สร้างบัญชีแอดมินเพิ่ม';
                }
            }
        }

        async function promptResetAdminPass(adminId, username) {
            const newPass = prompt(`กรอกรหัสผ่านใหม่สำหรับแอดมิน "${username}" (อย่างน้อย 4 ตัวอักษร):`);
            if (!newPass) return;
            if (newPass.length < 4) {
                showAdminPopup({
                    type: 'warning',
                    title: 'รหัสผ่านสั้นเกินไป',
                    message: 'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร'
                });
                return;
            }
            try {
                const res = await fetch('admin_panel.php?api=1&action=reset_admin_password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ admin_id: adminId, new_password: newPass })
                }).then(r => r.json());

                if (res.status === 'success') {
                    showAdminPopup({
                        type: 'success',
                        icon: '🔑✅',
                        title: 'รีเซ็ตรหัสผ่านสำเร็จ!',
                        message: res.message || `รีเซ็ตรหัสผ่านสำหรับ "${username}" เรียบร้อยแล้ว`
                    });
                } else {
                    showAdminPopup({
                        type: 'error',
                        title: 'รีเซ็ตไม่สำเร็จ',
                        message: res.message || 'เกิดข้อผิดพลาด'
                    });
                }
            } catch (e) {
                showAdminPopup({
                    type: 'error',
                    title: 'เกิดข้อผิดพลาด',
                    message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้'
                });
            }
        }

        function deleteAdminAccount(adminId, username) {
            showAdminPopup({
                type: 'warning',
                icon: '⚠️',
                title: 'ยืนยันการลบบัญชี',
                message: `คุณแน่ใจหรือไม่ว่าต้องการลบบัญชีแอดมิน "${username}" ?\nการกระทำนี้ไม่สามารถย้อนกลับได้`,
                showCancel: true,
                confirmText: 'ยืนยันลบ',
                cancelText: 'ยกเลิก',
                onConfirm: async () => {
                    try {
                        const res = await fetch('admin_panel.php?api=1&action=delete_admin', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ admin_id: adminId })
                        }).then(r => r.json());

                        if (res.status === 'success') {
                            showAdminPopup({
                                type: 'success',
                                icon: '🗑️✅',
                                title: 'ลบบัญชีสำเร็จ!',
                                message: res.message || 'ลบบัญชีผู้ดูแลระบบเรียบร้อยแล้ว',
                                confirmText: 'ตกลง',
                                onConfirm: () => location.reload()
                            });
                        } else {
                            showAdminPopup({
                                type: 'error',
                                title: 'ไม่สามารถลบได้',
                                message: res.message || 'เกิดข้อผิดพลาด'
                            });
                        }
                    } catch (e) {
                        showAdminPopup({
                            type: 'error',
                            title: 'เกิดข้อผิดพลาด',
                            message: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้'
                        });
                    }
                }
            });
        }

        // ============================================================
        // 💎 Topup Packages & 📱 PromptPay Settings
        // ============================================================
        function editPackage(pkg) {
            if (!pkg) return;
            const formTitle = document.getElementById('pkg-form-title');
            if (formTitle) formTitle.innerText = '✏️ แก้ไขแพ็กเกจ: ' + (pkg.name || '');
            
            const idEl = document.getElementById('pkg_id');
            if (idEl) idEl.value = pkg.id || '';

            const nameEl = document.getElementById('pkg_name');
            if (nameEl) nameEl.value = pkg.name || '';

            const typeEl = document.getElementById('pkg_type');
            if (typeEl) typeEl.value = pkg.type || 'DIAMOND';

            const priceEl = document.getElementById('pkg_price_thb');
            if (priceEl) priceEl.value = pkg.price_thb !== undefined ? pkg.price_thb : '30.00';

            const diaEl = document.getElementById('pkg_reward_diamond');
            if (diaEl) diaEl.value = pkg.reward_diamond !== undefined ? pkg.reward_diamond : 0;

            const goldEl = document.getElementById('pkg_reward_gold');
            if (goldEl) goldEl.value = pkg.reward_gold !== undefined ? pkg.reward_gold : 0;

            const activeEl = document.getElementById('pkg_is_active');
            if (activeEl) activeEl.value = (pkg.is_active !== undefined) ? pkg.is_active : 1;

            const btnSave = document.getElementById('btn-save-pkg');
            if (btnSave) btnSave.innerHTML = '💾 บันทึกการแก้ไขแพ็กเกจ';

            const btnCancel = document.getElementById('btn-cancel-pkg');
            if (btnCancel) btnCancel.style.display = 'inline-block';

            const form = document.getElementById('pkgForm');
            if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function resetPackageForm() {
            const formTitle = document.getElementById('pkg-form-title');
            if (formTitle) formTitle.innerText = 'สร้าง/แก้ไขแพ็กเกจเติมเงิน (เช่น 500 เพชร 30 บาท)';

            const idEl = document.getElementById('pkg_id');
            if (idEl) idEl.value = '';

            const nameEl = document.getElementById('pkg_name');
            if (nameEl) nameEl.value = 'แพ็กเกจเพชรเริ่มต้น (500 เพชร)';

            const typeEl = document.getElementById('pkg_type');
            if (typeEl) typeEl.value = 'DIAMOND';

            const priceEl = document.getElementById('pkg_price_thb');
            if (priceEl) priceEl.value = '30.00';

            const diaEl = document.getElementById('pkg_reward_diamond');
            if (diaEl) diaEl.value = '500';

            const goldEl = document.getElementById('pkg_reward_gold');
            if (goldEl) goldEl.value = '0';

            const activeEl = document.getElementById('pkg_is_active');
            if (activeEl) activeEl.value = '1';

            const btnSave = document.getElementById('btn-save-pkg');
            if (btnSave) btnSave.innerHTML = '➕ เพิ่มแพ็กเกจในร้านค้า';

            const btnCancel = document.getElementById('btn-cancel-pkg');
            if (btnCancel) btnCancel.style.display = 'none';
        }

        async function submitSavePackage() {
            const form = document.getElementById('pkgForm');
            if (!form) return;
            const formData = new FormData(form);
            const idVal = formData.get('id');
            const payload = {
                id: idVal ? parseInt(idVal) : null,
                name: formData.get('name'),
                type: formData.get('type') || 'DIAMOND',
                price_thb: parseFloat(formData.get('price_thb')) || 30.00,
                reward_diamond: parseInt(formData.get('reward_diamond')) || 0,
                reward_gold: parseFloat(formData.get('reward_gold')) || 0,
                is_active: parseInt(formData.get('is_active') || '1')
            };

            const btn = document.getElementById('btn-save-pkg');
            const origText = btn ? btn.innerHTML : '';
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '⏳ กำลังบันทึกข้อมูล...';
            }

            try {
                const response = await fetch('admin_panel.php?api=1&action=save_package', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const res = await response.json();

                if (res && res.status === 'success') {
                    showToast('✅ ' + res.message);
                    setTimeout(() => location.reload(), 600);
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res?.message || 'ไม่สามารถบันทึกได้'));
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = origText;
                    }
                }
            } catch(e) {
                console.error('submitSavePackage error:', e);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ' + (e.message || ''));
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origText;
                }
            }
        }

        async function deletePackage(pkgId, pkgName) {
            if (!confirm(`คุณแน่ใจหรือไม่ว่าต้องการลบแพ็กเกจ "${pkgName}" (ID: #${pkgId}) ออกจากร้านค้า?\nการกระทำนี้ไม่สามารถย้อนกลับได้`)) {
                return;
            }

            try {
                const response = await fetch('admin_panel.php?api=1&action=delete_package', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: pkgId })
                });
                const res = await response.json();

                if (res && res.status === 'success') {
                    showToast('🗑️ ' + res.message);
                    const row = document.getElementById(`pkg-row-${pkgId}`);
                    if (row) {
                        row.remove();
                    } else {
                        setTimeout(() => location.reload(), 600);
                    }
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res?.message || 'ไม่สามารถลบแพ็กเกจได้'));
                }
            } catch(e) {
                console.error('deletePackage error:', e);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์: ' + (e.message || ''));
            }
        }

        function generatePromptPayPayload(target, amount = null) {
            if (!target) return null;
            target = target.replace(/[^0-9]/g, '');
            let targetType = '01';
            let formattedTarget = target;

            if (target.length === 10 && target.startsWith('0')) {
                formattedTarget = '0066' + target.substring(1);
                targetType = '01';
            } else if (target.length === 13) {
                formattedTarget = target;
                targetType = '02';
            } else {
                return null;
            }

            const targetSubTag = `${targetType}${('0' + formattedTarget.length).slice(-2)}${formattedTarget}`;
            const aid = '0016A000000677010111';
            const tag29 = `${aid}${targetSubTag}`;
            const tag29Length = ('0' + tag29.length).slice(-2);

            let raw = `00020101021129${tag29Length}${tag29}5802TH5303764`;
            if (amount !== null && amount > 0) {
                const amtStr = Number(amount).toFixed(2);
                raw += `54${('0' + amtStr.length).slice(-2)}${amtStr}`;
            }
            raw += '6304';

            let crc = 0xFFFF;
            for (let i = 0; i < raw.length; i++) {
                crc ^= (raw.charCodeAt(i) << 8);
                for (let j = 0; j < 8; j++) {
                    if ((crc & 0x8000) !== 0) {
                        crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
                    } else {
                        crc = (crc << 1) & 0xFFFF;
                    }
                }
            }
            const crcHex = ('0000' + crc.toString(16).toUpperCase()).slice(-4);
            return raw + crcHex;
        }

        function updateAdminPromptPayPreview() {
            const idVal = document.getElementById('admin_promptpay_id')?.value.trim() || '';
            const nameVal = document.getElementById('admin_promptpay_name')?.value.trim() || '';
            
            const pName = document.getElementById('admin_promptpay_preview_name');
            const pId = document.getElementById('admin_promptpay_preview_id');
            const qrImg = document.getElementById('admin_promptpay_qr_tag');
            const qrHolder = document.getElementById('admin_promptpay_qr_placeholder');

            if (pName) pName.innerText = `ชื่อบัญชี: ${nameVal || '-'}`;
            if (pId) pId.innerText = `หมายเลข: ${idVal || '-'}`;

            const payload = generatePromptPayPayload(idVal);
            if (payload && qrImg && qrHolder) {
                qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(payload)}`;
                qrImg.style.display = 'block';
                qrHolder.style.display = 'none';
            } else if (qrImg && qrHolder) {
                qrImg.style.display = 'none';
                qrHolder.style.display = 'block';
            }
        }

        async function savePromptPaySettingsFromAdmin() {
            const idVal = document.getElementById('admin_promptpay_id')?.value.trim() || '';
            const nameVal = document.getElementById('admin_promptpay_name')?.value.trim() || '';
            const bankVal = document.getElementById('admin_promptpay_bank')?.value.trim() || '';

            try {
                const res = await fetch('admin_panel.php?api=1&action=save_promptpay_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        promptpay_id: idVal,
                        promptpay_name: nameVal,
                        promptpay_bank: bankVal
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    showToast('✅ ' + res.message);
                    updateAdminPromptPayPreview(); updateAdminShopeePayPreview();
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
                }
            } catch(err) {
                console.error('savePromptPaySettingsFromAdmin error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        function updateAdminShopeePayPreview() {
            const idVal = document.getElementById('admin_shopeepay_id')?.value.trim() || '';
            const nameVal = document.getElementById('admin_shopeepay_name')?.value.trim() || '';
            const qrUrlVal = document.getElementById('admin_shopeepay_qr_url')?.value.trim() || '';

            const pName = document.getElementById('admin_shopeepay_preview_name');
            const pId = document.getElementById('admin_shopeepay_preview_id');
            const qrImg = document.getElementById('admin_shopeepay_qr_tag');
            const qrHolder = document.getElementById('admin_shopeepay_qr_placeholder');

            if (pName) pName.innerText = `ชื่อบัญชี: ${nameVal || '-'}`;
            if (pId) pId.innerText = `Shopee ID: ${idVal || '-'}`;

            if (qrUrlVal && qrImg && qrHolder) {
                qrImg.src = qrUrlVal;
                qrImg.style.display = 'block';
                qrHolder.style.display = 'none';
            } else if (idVal && qrImg && qrHolder) {
                const qrData = `https://shopee.co.th/pay?merchant_id=${encodeURIComponent(idVal)}`;
                qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}`;
                qrImg.style.display = 'block';
                qrHolder.style.display = 'none';
            } else if (qrImg && qrHolder) {
                qrImg.style.display = 'none';
                qrHolder.style.display = 'block';
            }
        }

        async function saveShopeePaySettingsFromAdmin() {
            const idVal = document.getElementById('admin_shopeepay_id')?.value.trim() || '';
            const nameVal = document.getElementById('admin_shopeepay_name')?.value.trim() || '';
            const qrUrlVal = document.getElementById('admin_shopeepay_qr_url')?.value.trim() || '';
            const activeVal = document.getElementById('admin_shopeepay_active')?.checked ? 1 : 0;

            try {
                const res = await fetch('admin_panel.php?api=1&action=save_shopeepay_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        shopeepay_id: idVal,
                        shopeepay_name: nameVal,
                        shopeepay_qr_url: qrUrlVal,
                        shopeepay_active: activeVal
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    showToast('✅ ' + res.message);
                    updateAdminShopeePayPreview();
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
                }
            } catch(err) {
                console.error('saveShopeePaySettingsFromAdmin error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        async function savePayPalSettingsFromAdmin() {
            const email = document.getElementById('admin_paypal_email')?.value.trim() || '';
            const clientId = document.getElementById('admin_paypal_client_id')?.value.trim() || '';
            const currency = document.getElementById('admin_paypal_currency')?.value || 'THB';
            const sandbox = document.getElementById('admin_paypal_sandbox')?.checked ? 1 : 0;

            try {
                const res = await fetch('admin_panel.php?api=1&action=save_paypal_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        paypal_email: email,
                        paypal_client_id: clientId,
                        paypal_currency: currency,
                        paypal_sandbox: sandbox
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    showToast('✅ ' + res.message);
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
                }
            } catch(err) {
                console.error('savePayPalSettingsFromAdmin error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        async function searchUsers() {
            const q = document.getElementById('search-user-input').value.trim();
            const res = await fetch('admin_panel.php?api=1&action=get_users&q=' + encodeURIComponent(q)).then(r => r.json());
            const tbody = document.getElementById('users-table-tbody');
            if (!tbody || !res.data) return;

            if (res.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:18px;">ไม่พบข้อมูลผู้เล่นที่ค้นหา</td></tr>';
                return;
            }

            tbody.innerHTML = res.data.map(u => `
                <tr id="user-row-${u.id}">
                    <td><strong>#${u.id}</strong></td>
                    <td><input type="text" id="u_name_${u.id}" value="${(u.username || '').replace(/"/g, '&quot;')}" style="min-width: 150px;"></td>
                    <td><input type="number" id="u_dia_${u.id}" value="${u.diamond}" style="width: 110px;"></td>
                    <td><input type="number" id="u_gold_${u.id}" value="${u.gold}" style="width: 130px;"></td>
                    <td><input type="number" id="u_lvl_${u.id}" value="${u.level}" style="width: 75px;" min="1"></td>
                    <td>
                        <select id="u_ban_${u.id}" style="width: 115px;">
                            <option value="0" ${u.is_banned == 0 ? 'selected' : ''}>🟢 ปกติ</option>
                            <option value="1" ${u.is_banned == 1 ? 'selected' : ''}>🔴 ระงับ (แบน)</option>
                        </select>
                    </td>
                    <td style="white-space: nowrap;">
                        <button class="btn" style="padding: 6px 12px; font-size: 13px;" onclick="saveUserRow(${u.id})">💾 บันทึก</button>
                        <button class="btn btn-danger" style="padding: 6px 10px; font-size: 13px;" onclick="deleteUserRow(${u.id}, '${(u.username || '').replace(/'/g, "\\'")}')">🗑️</button>
                    </td>
                </tr>
            `).join('');
        }

        async function saveUserRow(userId) {
            const payload = {
                id: userId,
                username: document.getElementById('u_name_' + userId).value.trim(),
                diamond: parseInt(document.getElementById('u_dia_' + userId).value) || 0,
                gold: parseInt(document.getElementById('u_gold_' + userId).value) || 0,
                level: parseInt(document.getElementById('u_lvl_' + userId).value) || 1,
                is_banned: parseInt(document.getElementById('u_ban_' + userId).value) || 0
            };

            const res = await fetch('admin_panel.php?api=1&action=update_user_data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(r => r.json());

            if (res.status === 'success') {
                showToast(res.message);
            } else {
                alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
            }
        }

        async function deleteUserRow(userId, username) {
            if (!confirm(`ยืนยันการลบบัญชีผู้เล่น "${username}" (#${userId}) อย่างถาวร?`)) return;
            const res = await fetch('admin_panel.php?api=1&action=delete_user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: userId })
            }).then(r => r.json());

            if (res.status === 'success') {
                const row = document.getElementById('user-row-' + userId);
                if (row) row.remove();
                showToast(res.message);
            } else {
                alert(res.message || 'ไม่สามารถลบได้');
            }
        }

        // --- Daily Rewards & Sell Prices Scripts ---
        async function loadDailyRewards() {
            try {
                const res = await fetch('admin_panel.php?api=1&action=get_daily_rewards').then(r => r.json());
                const tbody = document.getElementById('daily-rewards-tbody');
                if (!tbody) return;
                if (!res.data || res.data.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:16px;">ยังไม่มีของรางวัลในระบบ</td></tr>';
                    return;
                }
                tbody.innerHTML = res.data.map(r => `
                    <tr>
                        <td style="font-size:22px;">${r.icon}</td>
                        <td style="font-weight:600; color:#fff;">${r.name}</td>
                        <td><span class="badge" style="background:#3b82f6;">${r.reward_type}</span></td>
                        <td style="color:#ffd700;">${r.reward_type === 'MATERIAL' ? (r.reward_value + ' ใบ (' + (r.material_code || '-') + ')') : (Number(r.reward_value).toLocaleString() + (r.reward_type === 'DIAMOND' ? ' เพชร' : ' ทอง'))}</td>
                        <td>${r.weight}</td>
                        <td>${r.is_active == 1 ? '<span style="color:#10b981; font-weight:700;">● ใช้งาน</span>' : '<span style="color:#ef4444;">○ ปิด</span>'}</td>
                        <td>
                            <button class="btn btn-secondary" style="padding:4px 8px; font-size:11px;" onclick="deleteDailyReward(${r.id})">ลบ</button>
                        </td>
                    </tr>
                `).join('');
            } catch(e) {
                console.error(e);
            }
        }

        const SELL_PRICE_ITEMS_SPEC = [
            // Frames
            { group: 'chars', code: 'CHAR_SSPLUS', label: '👑 กรอบรูป เกรด SS+', defaultAmt: 1000, defaultCurr: 'DIAMOND' },
            { group: 'chars', code: 'CHAR_SPLUS', label: '🌟 กรอบรูป เกรด S+', defaultAmt: 400, defaultCurr: 'DIAMOND' },
            { group: 'chars', code: 'CHAR_S', label: '❄️ กรอบรูป เกรด S', defaultAmt: 250, defaultCurr: 'DIAMOND' },
            { group: 'chars', code: 'CHAR_APLUS', label: '⚪ กรอบรูป เกรด A+', defaultAmt: 150, defaultCurr: 'DIAMOND' },
            { group: 'chars', code: 'CHAR_A', label: '🛡️ กรอบรูป เกรด A', defaultAmt: 100, defaultCurr: 'DIAMOND' },
            { group: 'chars', code: 'CHAR_B', label: '🔸 กรอบรูป เกรด B', defaultAmt: 40, defaultCurr: 'DIAMOND' },
            // Dice
            { group: 'dice', code: 'DICE_SSPLUS', label: '🔥 ลูกเต๋า 3D เกรด SS+', defaultAmt: 800, defaultCurr: 'DIAMOND' },
            { group: 'dice', code: 'DICE_SPLUS', label: '⚡ ลูกเต๋า 3D เกรด S+', defaultAmt: 600, defaultCurr: 'DIAMOND' },
            { group: 'dice', code: 'DICE_LEGENDARY', label: '👑 ลูกเต๋า LEGENDARY', defaultAmt: 500, defaultCurr: 'DIAMOND' },
            { group: 'dice', code: 'DICE_EPIC', label: '💎 ลูกเต๋า EPIC', defaultAmt: 200, defaultCurr: 'DIAMOND' },
            { group: 'dice', code: 'DICE_RARE', label: '🔹 ลูกเต๋า RARE', defaultAmt: 80, defaultCurr: 'DIAMOND' },
            { group: 'dice', code: 'DICE_NORMAL', label: '🎲 ลูกเต๋า NORMAL', defaultAmt: 30, defaultCurr: 'DIAMOND' },
            // Shadow & Special Cards
            { group: 'materials', code: 'SHADOW_BLACK_A', label: '⬛ การ์ดเงาสีดำ ระดับ A', defaultAmt: 20, defaultCurr: 'DIAMOND', fallbackKey: 'SELL_PRICE_SHADOW_A' },
            { group: 'materials', code: 'SHADOW_RED_A', label: '🟥 การ์ดเงาสีแดง ระดับ A', defaultAmt: 20, defaultCurr: 'DIAMOND', fallbackKey: 'SELL_PRICE_SHADOW_A' },
            { group: 'materials', code: 'SHADOW_ORANGE_A', label: '🟧 การ์ดเงาสีส้ม ระดับ A', defaultAmt: 20, defaultCurr: 'DIAMOND', fallbackKey: 'SELL_PRICE_SHADOW_A' },
            { group: 'materials', code: 'SHADOW_BLUE_APLUS', label: '🟦 การ์ดเงาสีฟ้า ระดับ A+', defaultAmt: 35, defaultCurr: 'DIAMOND', fallbackKey: 'SELL_PRICE_SHADOW_A' },
            { group: 'materials', code: 'SHADOW_GOLD_S', label: '🟨 การ์ดเงาสีทอง ระดับ S', defaultAmt: 50, defaultCurr: 'DIAMOND', fallbackKey: 'SELL_PRICE_SHADOW_APLUS' },
            { group: 'materials', code: 'SPECIAL_CARD', label: '✨ การ์ดพิเศษ (Special Card)', defaultAmt: 80, defaultCurr: 'DIAMOND' }
        ];

        function renderSellPriceGroups(map = {}) {
            const groups = { chars: [], dice: [], materials: [] };
            SELL_PRICE_ITEMS_SPEC.forEach(item => {
                const pKey = 'SELL_PRICE_' + item.code;
                const cKey = 'SELL_CURRENCY_' + item.code;
                const rawAmt = map[pKey] !== undefined ? map[pKey] : (item.fallbackKey && map[item.fallbackKey] !== undefined ? map[item.fallbackKey] : item.defaultAmt);
                const curr = String(map[cKey] || item.defaultCurr).toUpperCase() === 'GOLD' ? 'GOLD' : 'DIAMOND';

                groups[item.group].push(`
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.06);">
                        <label style="display:flex; align-items:center; gap:8px; margin:0; color:#f8fafc; font-size:13px; cursor:pointer; flex:1; min-width:130px;">
                            <input type="checkbox" class="chk-sell-item" value="${item.code}" checked style="width:16px; height:16px; cursor:pointer;">
                            <span>${item.label}</span>
                        </label>
                        <div style="display:flex; align-items:center; gap:6px;">
                            <input type="number" id="sell_amt_${item.code}" value="${parseInt(rawAmt) || 0}" min="0" step="1" style="width:95px; padding:7px 8px; text-align:right; font-weight:700;">
                            <select id="sell_curr_${item.code}" style="width:118px; padding:7px 6px; font-weight:700;">
                                <option value="DIAMOND" ${curr === 'DIAMOND' ? 'selected' : ''}>💎 เพชร</option>
                                <option value="GOLD" ${curr === 'GOLD' ? 'selected' : ''}>🪙 ทอง</option>
                            </select>
                        </div>
                    </div>
                `);
            });

            if (document.getElementById('sell-group-chars')) document.getElementById('sell-group-chars').innerHTML = groups.chars.join('');
            if (document.getElementById('sell-group-dice')) document.getElementById('sell-group-dice').innerHTML = groups.dice.join('');
            if (document.getElementById('sell-group-materials')) document.getElementById('sell-group-materials').innerHTML = groups.materials.join('');
        }

        function toggleSelectAllSellItems(checked) {
            document.querySelectorAll('.chk-sell-item').forEach(chk => { chk.checked = checked; });
        }

        function setSelectedSellCurrency(curr) {
            let count = 0;
            document.querySelectorAll('.chk-sell-item:checked').forEach(chk => {
                const sel = document.getElementById('sell_curr_' + chk.value);
                if (sel) {
                    sel.value = curr;
                    count++;
                }
            });
            if (count === 0) {
                alert('กรุณาติ๊กเลือกรายการที่ต้องการเปลี่ยนสกุลเงินอย่างน้อย 1 รายการ');
                return;
            }
            showToast(`ตั้งค่าสกุลเงินที่เลือก ${count} รายการเป็น ${curr === 'GOLD' ? '🪙 ทอง' : '💎 เพชร'} แล้ว (กดบันทึกเพื่อยืนยัน)`);
        }

        async function loadSellPrices() {
            try {
                const res = await fetch('admin_panel.php?api=1&action=get_admin_sell_prices').then(r => r.json());
                const map = (res && res.map) ? res.map : {};
                if (res && res.data && Array.isArray(res.data)) {
                    res.data.forEach(p => { map[p.setting_key] = p.setting_value; });
                }
                renderSellPriceGroups(map);
            } catch(e) {
                console.error(e);
                renderSellPriceGroups({});
            }
        }

        async function saveSellPrices(e) {
            if (e && e.preventDefault) e.preventDefault();
            const items = {};
            const selectedBoxes = Array.from(document.querySelectorAll('.chk-sell-item:checked'));
            const targetCodes = selectedBoxes.length > 0
                ? selectedBoxes.map(c => c.value)
                : SELL_PRICE_ITEMS_SPEC.map(i => i.code);

            targetCodes.forEach(code => {
                const amtEl = document.getElementById('sell_amt_' + code);
                const currEl = document.getElementById('sell_curr_' + code);
                if (amtEl && currEl) {
                    items[code] = {
                        amount: parseInt(amtEl.value) || 0,
                        currency: currEl.value || 'DIAMOND'
                    };
                }
            });

            const res = await fetch('admin_panel.php?api=1&action=save_admin_sell_prices', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ items })
            }).then(r => r.json());

            if (res.status === 'success') {
                showToast(res.message);
            } else {
                alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
            }
        }

        async function deleteDailyReward(id) {
            if (!confirm('ยืนยันลบของรางวัลนี้ออกจากกิจกรรมประจำวัน?')) return;
            await fetch('admin_panel.php?api=1&action=delete_daily_reward', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id })
            });
            loadDailyRewards();
            showToast('ลบรายการสำเร็จ');
        }

        function openAddRewardModal() {
            const name = prompt('กรอกชื่อของรางวัล (เช่น 200 เพชร, การ์ดเงาทอง A+):');
            if (!name) return;
            const type = prompt('ประเภทรางวัล (DIAMOND / GOLD / MATERIAL):', 'DIAMOND');
            if (!type) return;
            const val = prompt('จำนวนเพชร/ทอง หรือจำนวนใบ:', '200');
            if (!val) return;
            let mat = null;
            if (type.toUpperCase() === 'MATERIAL') {
                mat = prompt('รหัสการ์ดเงา (SHADOW_GOLD_APLUS / SHADOW_RED_A / SPECIAL_CARD):', 'SHADOW_GOLD_APLUS');
            }
            const icon = prompt('ไอคอน (เช่น 💎, 🪙, 🎴, ✨):', '💎') || '💎';

            fetch('admin_panel.php?api=1&action=save_daily_reward', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    name: name.trim(),
                    reward_type: type.trim().toUpperCase(),
                    reward_value: parseInt(val),
                    material_code: mat,
                    icon: icon.trim(),
                    weight: 15,
                    is_active: 1
                })
            }).then(() => {
                loadDailyRewards();
                showToast('เพิ่มของรางวัลใหม่สำเร็จ');
            });
        }


        // --- Gacha Event Admin Scripts ---
        async function loadGachaEventConfig() {
            try {
                const res = await fetch('admin_panel.php?api=1&action=get_gacha_event').then(r => r.json());
                if (res && res.data) {
                    const ev = res.data;
                    document.getElementById('gacha_event_id').value = ev.id || 1;
                    document.getElementById('gacha_event_name').value = ev.event_name || '';
                    document.getElementById('gacha_event_desc').value = ev.description || '';
                    document.getElementById('gacha_cost_diamond').value = ev.cost_diamond || 100;
                    document.getElementById('gacha_is_active').value = ev.is_active;

                    if (ev.start_date) {
                        document.getElementById('gacha_start_date').value = ev.start_date.replace(' ', 'T').substring(0, 16);
                    }
                    if (ev.end_date) {
                        document.getElementById('gacha_end_date').value = ev.end_date.replace(' ', 'T').substring(0, 16);
                    }

                    document.getElementById('rate_splus').value = parseFloat(ev.rate_splus) || 3.0;
                    document.getElementById('rate_shadow_gold').value = parseFloat(ev.rate_shadow_gold) || 12.0;
                    document.getElementById('rate_shadow_red').value = parseFloat(ev.rate_shadow_red) || 25.0;
                    document.getElementById('rate_shadow_blue').value = parseFloat(ev.rate_shadow_blue) || 25.0;
                    document.getElementById('rate_shadow_black').value = parseFloat(ev.rate_shadow_black) || 20.0;
                    document.getElementById('rate_shadow_special').value = parseFloat(ev.rate_shadow_special) || 15.0;

                    calcGachaTotalRate();
                }
            } catch(e) {
                console.error('Load gacha event error:', e);
            }
        }

        function calcGachaTotalRate() {
            const rSPlus = parseFloat(document.getElementById('rate_splus').value) || 0;
            const rGold = parseFloat(document.getElementById('rate_shadow_gold').value) || 0;
            const rRed = parseFloat(document.getElementById('rate_shadow_red').value) || 0;
            const rBlue = parseFloat(document.getElementById('rate_shadow_blue').value) || 0;
            const rBlack = parseFloat(document.getElementById('rate_shadow_black').value) || 0;
            const rSpecial = parseFloat(document.getElementById('rate_shadow_special').value) || 0;

            const sum = (rSPlus + rGold + rRed + rBlue + rBlack + rSpecial).toFixed(2);
            const disp = document.getElementById('gacha_total_rate_display');
            if (disp) {
                disp.innerText = sum + '%';
                if (Math.abs(sum - 100) < 0.05) {
                    disp.style.color = '#10b981';
                } else {
                    disp.style.color = '#f59e0b';
                }
            }
        }

        async function saveGachaEventConfig(e) {
            e.preventDefault();
            const payload = {
                id: document.getElementById('gacha_event_id').value,
                event_name: document.getElementById('gacha_event_name').value.trim(),
                description: document.getElementById('gacha_event_desc').value.trim(),
                cost_diamond: document.getElementById('gacha_cost_diamond').value,
                start_date: document.getElementById('gacha_start_date').value.replace('T', ' ') + ':00',
                end_date: document.getElementById('gacha_end_date').value.replace('T', ' ') + ':00',
                is_active: document.getElementById('gacha_is_active').value,
                rate_splus: document.getElementById('rate_splus').value,
                rate_shadow_gold: document.getElementById('rate_shadow_gold').value,
                rate_shadow_red: document.getElementById('rate_shadow_red').value,
                rate_shadow_blue: document.getElementById('rate_shadow_blue').value,
                rate_shadow_black: document.getElementById('rate_shadow_black').value,
                rate_shadow_special: document.getElementById('rate_shadow_special').value
            };

            const res = await fetch('admin_panel.php?api=1&action=save_gacha_event', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            }).then(r => r.json());

            if (res && res.status === 'success') {
                showToast(res.message);
            } else {
                alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
            }
        }

        async function submitBroadcast() {
            if (!confirm('ยืนยันส่งของรางวัลให้ผู้เล่นทุกคนในเซิร์ฟเวอร์?')) return;
            const form = document.getElementById('broadcastForm');
            const data = Object.fromEntries(new FormData(form));
            const res = await fetch('admin_panel.php?api=1&action=broadcast_giveaway', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const json = await res.json();
            showToast(json.message);
        }

        // ==========================================
        // 🧊 MAGIC CUBE ADMIN JAVASCRIPT
        // ==========================================
        let adminCubeConfigsCache = [];
        let adminUsersListCache = [];
        let adminCubeRewardsState = {};

        async function loadMagicCubeConfigsAdmin() {
            const container = document.getElementById('magic_cube_cards_grid');
            if (!container) return;
            container.innerHTML = '<div style="color:var(--text-muted); text-align:center; padding:30px; grid-column:1/-1;">กำลังโหลดข้อมูลลูกบาศก์...</div>';

            try {
                const res = await fetch('admin_panel.php?api=1&action=get_cube_configs').then(r => r.json());
                if (res && res.status === 'success' && res.data) {
                    adminCubeConfigsCache = res.data;
                    adminUsersListCache = res.users || [];

                    // Populate give user select
                    const uSel = document.getElementById('admin_give_user_id');
                    if (uSel) {
                        uSel.innerHTML = '<option value="">-- เลือกผู้เล่นที่จะมอบให้ --</option>' + 
                            adminUsersListCache.map(u => `<option value="${u.id}">[ID: ${u.id}] ${u.display_name || u.username} (@${u.username})</option>`).join('');
                    }

                    // Initialize rewards state
                    adminCubeConfigsCache.forEach(c => {
                        adminCubeRewardsState[c.cube_type] = Array.isArray(c.rewards) ? JSON.parse(JSON.stringify(c.rewards)) : [];
                    });

                    renderCubeConfigCards();
                } else {
                    container.innerHTML = `<div style="color:#ef4444; padding:20px; grid-column:1/-1;">โหลดไม่สำเร็จ: ${res.message || 'Error'}</div>`;
                }
            } catch(e) {
                console.error('loadMagicCubeConfigsAdmin error:', e);
                container.innerHTML = '<div style="color:#ef4444; padding:20px; grid-column:1/-1;">เกิดข้อผิดพลาดในการโหลดข้อมูลลูกบาศก์</div>';
            }
        }

        function renderCubeConfigCards() {
            const container = document.getElementById('magic_cube_cards_grid');
            if (!container) return;

            const gradeBadgeMap = {
                'SILVER': { icon: '🪙', label: 'SILVER', border: '#94a3b8', bg: 'rgba(148,163,184,0.1)' },
                'GOLD': { icon: '👑', label: 'GOLD', border: '#f59e0b', bg: 'rgba(245,158,11,0.1)' },
                'DIAMOND': { icon: '💎', label: 'DIAMOND', border: '#00e5ff', bg: 'rgba(0,229,255,0.1)' },
                'LEGENDARY': { icon: '🌟', label: 'LEGENDARY', border: '#a855f7', bg: 'rgba(168,85,247,0.12)' }
            };

            container.innerHTML = adminCubeConfigsCache.map(cube => {
                const badge = gradeBadgeMap[cube.cube_type] || { icon: '🧊', label: cube.cube_type, border: '#00e5ff', bg: 'rgba(0,229,255,0.1)' };
                const rewards = adminCubeRewardsState[cube.cube_type] || [];

                return `
                    <div class="card" style="border: 1.5px solid ${cube.color_hex || badge.border}; background: ${badge.bg}; display:flex; flex-direction:column; justify-content:space-between;">
                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:8px;">
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <span style="font-size:24px;">${badge.icon}</span>
                                    <h3 style="margin:0; font-size:16px; color:#fff;">${cube.cube_name}</h3>
                                </div>
                                <span style="font-size:11px; padding:3px 8px; border-radius:6px; font-weight:700; background:${cube.color_hex}; color:#000;">${badge.label}</span>
                            </div>

                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:10px;">
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px;">ชื่อลูกบาศก์:</label>
                                    <input type="text" id="cube_name_${cube.cube_type}" value="${cube.cube_name}" style="padding:6px 8px; font-size:12px;">
                                </div>
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px;">สีประจำลูกบาศก์ (Hex):</label>
                                    <div style="display:flex; gap:6px; align-items:center;">
                                        <input type="color" id="cube_color_${cube.cube_type}" value="${cube.color_hex}" style="width:36px; height:32px; padding:0; border:none; cursor:pointer;">
                                        <input type="text" value="${cube.color_hex}" style="flex:1; padding:6px 8px; font-size:12px;" oninput="document.getElementById('cube_color_${cube.cube_type}').value = this.value">
                                    </div>
                                </div>
                            </div>

                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:10px;">
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px;">เวลาหมุนต่ำสุด (ชม.):</label>
                                    <input type="number" id="cube_min_h_${cube.cube_type}" value="${cube.min_hours}" min="0.1" step="0.5" style="padding:6px 8px; font-size:12px;">
                                </div>
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px;">เวลาหมุนสูงสุด (ชม.):</label>
                                    <input type="number" id="cube_max_h_${cube.cube_type}" value="${cube.max_hours}" min="0.1" step="0.5" style="padding:6px 8px; font-size:12px;">
                                </div>
                            </div>

                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:10px; background:rgba(0,229,255,0.06); border:1px solid rgba(0,229,255,0.2); padding:10px; border-radius:8px;">
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px; color:#38bdf8;">💎 ค่าเพชรในการหมุน:</label>
                                    <input type="number" id="cube_cost_dia_${cube.cube_type}" value="${cube.spin_cost_diamond || 20}" min="0" style="padding:6px 8px; font-size:12px;">
                                </div>
                                <div class="form-group" style="margin:0;">
                                    <label style="font-size:11px; color:#f59e0b;">🪙 ค่าทองในการหมุน:</label>
                                    <input type="number" id="cube_cost_gold_${cube.cube_type}" value="${cube.spin_cost_gold || 10000}" min="0" step="500" style="padding:6px 8px; font-size:12px;">
                                </div>
                            </div>

                            <div class="form-group" style="margin-bottom:12px;">
                                <label style="font-size:11px; color:#f59e0b;">🎲 โอกาสสุ่มดรอปเมื่อเล่นชนะ (%):</label>
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <input type="number" id="cube_drop_rate_${cube.cube_type}" value="${cube.drop_rate_percent}" min="0" max="100" step="0.5" style="padding:6px 8px; font-size:12px; flex:1;">
                                    <span style="font-size:12px; color:var(--text-muted);">% (ของผลการดรอป)</span>
                                </div>
                            </div>

                            <!-- Rewards List -->
                            <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:10px; margin-top:10px;">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                    <label style="font-size:12px; color:#ffd700; font-weight:700; margin:0;">🎁 รายการของรางวัลในกล่อง (${rewards.length} รายการ):</label>
                                    <button type="button" class="btn" style="padding:3px 8px; font-size:11px; background:#0284c7; color:#fff;" onclick="addRewardToCube('${cube.cube_type}')">➕ เพิ่มรางวัล</button>
                                </div>

                                <div id="rewards_list_${cube.cube_type}" style="display:flex; flex-direction:column; gap:6px; max-height:220px; overflow-y:auto; padding-right:4px;">
                                    ${rewards.map((rew, idx) => `
                                        <div style="display:flex; gap:6px; align-items:center; background:rgba(0,0,0,0.35); padding:6px 8px; border-radius:6px; font-size:11px;">
                                            <select style="width:78px; padding:3px; font-size:11px;" onchange="updateCubeRewardField('${cube.cube_type}', ${idx}, 'type', this.value)">
                                                <option value="GOLD" ${rew.type==='GOLD'?'selected':''}>🪙 ทอง</option>
                                                <option value="DIAMOND" ${rew.type==='DIAMOND'?'selected':''}>💎 เพชร</option>
                                                <option value="CUBE" ${rew.type==='CUBE'?'selected':''}>🧊 ลูกบาศก์</option>
                                            </select>
                                            <input type="number" value="${rew.amount || 0}" style="width:65px; padding:3px; font-size:11px;" placeholder="จำนวน" oninput="updateCubeRewardField('${cube.cube_type}', ${idx}, 'amount', parseInt(this.value)||0)">
                                            <input type="text" value="${rew.label || ''}" style="flex:1; padding:3px; font-size:11px;" placeholder="ชื่อแสดง" oninput="updateCubeRewardField('${cube.cube_type}', ${idx}, 'label', this.value)">
                                            <input type="number" value="${rew.weight || 10}" title="ค่าน้ำหนักโอกาสออก (Weight)" style="width:42px; padding:3px; font-size:11px;" placeholder="W" oninput="updateCubeRewardField('${cube.cube_type}', ${idx}, 'weight', parseFloat(this.value)||1)">
                                            <button type="button" onclick="removeRewardFromCube('${cube.cube_type}', ${idx})" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:13px;" title="ลบ">✕</button>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>

                        <div style="margin-top:14px; border-top:1px solid rgba(255,255,255,0.08); padding-top:12px;">
                            <button type="button" class="btn btn-accent" style="width:100%; padding:9px; font-weight:700; font-size:13px;" onclick="saveSingleCubeConfig('${cube.cube_type}')">
                                💾 บันทึกการตั้งค่า ${cube.cube_name}
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function updateCubeRewardField(cubeType, idx, field, val) {
            if (!adminCubeRewardsState[cubeType] || !adminCubeRewardsState[cubeType][idx]) return;
            adminCubeRewardsState[cubeType][idx][field] = val;
            if (field === 'amount' || field === 'type') {
                const rew = adminCubeRewardsState[cubeType][idx];
                if (rew.type === 'GOLD') rew.label = `🪙 ${(rew.amount || 0).toLocaleString()} ทอง`;
                else if (rew.type === 'DIAMOND') rew.label = `💎 ${(rew.amount || 0).toLocaleString()} เพชร`;
                else if (rew.type === 'CUBE') rew.label = `🧊 ลูกบาศก์นำโชค`;
            }
        }

        function addRewardToCube(cubeType) {
            if (!adminCubeRewardsState[cubeType]) adminCubeRewardsState[cubeType] = [];
            adminCubeRewardsState[cubeType].push({
                type: 'DIAMOND',
                amount: 100,
                label: '💎 100 เพชร',
                weight: 20
            });
            renderCubeConfigCards();
        }

        function removeRewardFromCube(cubeType, idx) {
            if (!adminCubeRewardsState[cubeType]) return;
            adminCubeRewardsState[cubeType].splice(idx, 1);
            renderCubeConfigCards();
        }

        async function saveSingleCubeConfig(cubeType) {
            const nameEl = document.getElementById(`cube_name_${cubeType}`);
            const colorEl = document.getElementById(`cube_color_${cubeType}`);
            const minHEl = document.getElementById(`cube_min_h_${cubeType}`);
            const maxHEl = document.getElementById(`cube_max_h_${cubeType}`);
            const dropEl = document.getElementById(`cube_drop_rate_${cubeType}`);
            const costDiaEl = document.getElementById(`cube_cost_dia_${cubeType}`);
            const costGoldEl = document.getElementById(`cube_cost_gold_${cubeType}`);

            const payload = {
                cube_type: cubeType,
                cube_name: nameEl ? nameEl.value.trim() : cubeType,
                color_hex: colorEl ? colorEl.value : '#00e5ff',
                min_hours: minHEl ? parseFloat(minHEl.value) : 1,
                max_hours: maxHEl ? parseFloat(maxHEl.value) : 3,
                drop_rate_percent: dropEl ? parseFloat(dropEl.value) : 50,
                spin_cost_diamond: costDiaEl ? parseInt(costDiaEl.value, 10) : 20,
                spin_cost_gold: costGoldEl ? parseInt(costGoldEl.value, 10) : 10000,
                rewards: adminCubeRewardsState[cubeType] || []
            };

            const res = await fetch('admin_panel.php?api=1&action=save_cube_config', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            }).then(r => r.json());

            if (res && res.status === 'success') {
                showToast(res.message);
                loadMagicCubeConfigsAdmin();
            } else {
                alert('เกิดข้อผิดพลาด: ' + (res.message || 'บันทึกไม่สำเร็จ'));
            }
        }

        async function submitAdminGiveCube() {
            const uId = document.getElementById('admin_give_user_id')?.value;
            const cType = document.getElementById('admin_give_cube_type')?.value;
            if (!uId) {
                alert('กรุณาเลือกผู้เล่นที่ต้องการมอบลูกบาศก์ให้');
                return;
            }

            const res = await fetch('admin_panel.php?api=1&action=give_user_cube', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ user_id: parseInt(uId), cube_type: cType })
            }).then(r => r.json());

            if (res && res.status === 'success') {
                showToast(res.message);
            } else {
                alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถมอบลูกบาศก์ได้'));
            }
        }

        
let adminFramesCache = [];

function renderAuraPreview(auraType, grade, intensity = 100) {
    const scale = Math.max(0.1, Math.min(5.0, (intensity || 100) / 100));
    const overBoost = scale > 1 ? ` brightness(${(1 + (scale - 1) * 0.22).toFixed(2)}) saturate(${(1 + (scale - 1) * 0.25).toFixed(2)})` : '';
    let base = 'width:48px; height:48px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; background:#090d16; transition:all 0.25s; position:relative;';
    
    if (auraType === 'orange') {
        const b1 = Math.round(22 * scale), b2 = Math.round(48 * scale), b3 = Math.round(80 * scale), b4 = Math.round(120 * scale), inset = Math.round(16 * Math.min(scale, 2.2)), filter = Math.round(14 * scale);
        return base + `border: 3px solid #ff5500; box-shadow: 0 0 ${b1}px #ff5500, 0 0 ${b2}px rgba(255,85,0,0.98), 0 0 ${b3}px rgba(255,140,0,0.85), 0 0 ${b4}px rgba(255,50,0,0.55), inset 0 0 ${inset}px #ff7700; filter: drop-shadow(0 0 ${filter}px #ff5500)${overBoost};`;
    } else if (auraType === 'crimson') {
        const b1 = Math.round(20 * scale), b2 = Math.round(44 * scale), b3 = Math.round(74 * scale), inset = Math.round(14 * Math.min(scale, 2.2)), filter = Math.round(12 * scale);
        return base + `border: 3px solid #ef4444; box-shadow: 0 0 ${b1}px #ef4444, 0 0 ${b2}px rgba(239,68,68,0.95), 0 0 ${b3}px rgba(185,28,28,0.75), inset 0 0 ${inset}px #f87171; filter: drop-shadow(0 0 ${filter}px #ef4444)${overBoost};`;
    } else if (auraType === 'purple') {
        const b1 = Math.round(20 * scale), b2 = Math.round(44 * scale), b3 = Math.round(74 * scale), inset = Math.round(14 * Math.min(scale, 2.2)), filter = Math.round(12 * scale);
        return base + `border: 3px solid #a855f7; box-shadow: 0 0 ${b1}px #a855f7, 0 0 ${b2}px rgba(168,85,247,0.95), 0 0 ${b3}px rgba(126,34,206,0.75), inset 0 0 ${inset}px #c084fc; filter: drop-shadow(0 0 ${filter}px #a855f7)${overBoost};`;
    } else if (auraType === 'rainbow') {
        const b1 = Math.round(22 * scale), b2 = Math.round(50 * scale), filter = Math.round(12 * scale);
        return base + `border: 3px solid #38bdf8; box-shadow: 0 0 ${b1}px #ff007f, 0 0 ${b2}px #00e5ff, inset 0 0 12px #ffd700; filter: drop-shadow(0 0 ${filter}px #00e5ff)${overBoost};`;
    } else if (auraType === 'gold' || grade === 'SS+') {
        const b1 = Math.round(22 * scale), b2 = Math.round(48 * scale), b3 = Math.round(80 * scale), b4 = Math.round(120 * scale), inset = Math.round(16 * Math.min(scale, 2.2)), filter = Math.round(14 * scale);
        return base + `border: 3px solid #ffd700; box-shadow: 0 0 ${b1}px #ffd700, 0 0 ${b2}px rgba(255,215,0,0.98), 0 0 ${b3}px rgba(255,193,7,0.85), 0 0 ${b4}px rgba(255,160,0,0.55), inset 0 0 ${inset}px #ffd700; filter: drop-shadow(0 0 ${filter}px #ffd700)${overBoost};`;
    } else if (auraType === 'yellow' || grade === 'S+') {
        const b1 = Math.round(18 * scale), b2 = Math.round(40 * scale), b3 = Math.round(68 * scale), inset = Math.round(14 * Math.min(scale, 2.2)), filter = Math.round(11 * scale);
        return base + `border: 3px solid #facc15; box-shadow: 0 0 ${b1}px #facc15, 0 0 ${b2}px rgba(250,204,21,0.95), 0 0 ${b3}px rgba(245,158,11,0.75), inset 0 0 ${inset}px #facc15; filter: drop-shadow(0 0 ${filter}px #facc15)${overBoost};`;
    } else if (auraType === 'cyan' || grade === 'S') {
        const b1 = Math.round(15 * scale), b2 = Math.round(34 * scale), b3 = Math.round(55 * scale), inset = Math.round(12 * Math.min(scale, 2.2)), filter = Math.round(10 * scale);
        return base + `border: 2.5px solid #00e5ff; box-shadow: 0 0 ${b1}px #00e5ff, 0 0 ${b2}px rgba(0, 229, 255, 0.9), 0 0 ${b3}px rgba(0, 150, 255, 0.65), inset 0 0 ${inset}px #00e5ff; filter: drop-shadow(0 0 ${filter}px #00e5ff)${overBoost};`;
    } else if (auraType === 'white' || grade === 'A+') {
        const b1 = Math.round(12 * scale), b2 = Math.round(26 * scale), inset = Math.round(10 * Math.min(scale, 2.2)), filter = Math.round(8 * scale);
        return base + `border: 2.5px solid #fff; box-shadow: 0 0 ${b1}px #fff, 0 0 ${b2}px rgba(255, 255, 255, 0.85), inset 0 0 ${inset}px #fff; filter: drop-shadow(0 0 ${filter}px #ffffff)${overBoost};`;
    }
    return base + 'border: 1.5px solid #64748b;';
}

function updateRowPreview(id) {
    const auraType = document.getElementById('frm_aura_' + id)?.value || 'none';
    const grade = document.getElementById('frm_grade_' + id)?.value || 'A';
    const intensity = parseInt(document.getElementById('frm_intensity_' + id)?.value) || 100;
    const fx = document.getElementById('frm_fx_' + id)?.value || 'pulse_breathe';
    const box = document.getElementById('preview_box_' + id);
    if (box) {
        box.style.cssText = renderAuraPreview(auraType, grade, intensity);
        const ringImg = box.querySelector('.row-ring-overlay');
        if (ringImg) {
            ringImg.className = 'row-ring-overlay fx-ring-' + fx;
        }
    }
}

async function loadAdminFrames() {
    try {
        const res = await fetch('admin_panel.php?api=1&action=get_frame_characters').then(r => r.json());
        const tbody = document.getElementById('admin-frames-tbody');
        const activeTargetId = res && res.target_character_id ? parseInt(res.target_character_id) : 0;

        if (tbody && res && res.status === 'success' && res.data) {
            adminFramesCache = res.data;
            if (res.gacha_event) {
                window.adminGachaEventCache = res.gacha_event;
            }
            populateAiStudioEditSelect(res.data);
            if (typeof renderAiExchangeTiersEditor === 'function') {
                renderAiExchangeTiersEditor();
            }

            tbody.innerHTML = res.data.map(f => {
                const intensityVal = f.aura_intensity !== undefined ? parseInt(f.aura_intensity) : 100;
                const fxVal = f.frame_fx || 'pulse_breathe';
                const scaleVal = parseInt(f.frame_scale) || 120;
                const ringPx = Math.round(48 * (scaleVal / 100));
                const isTarget = (parseInt(f.id) === activeTargetId);

                return `
                    <tr>
                        <td style="text-align:center;">
                            <input type="checkbox" class="chk-frame-row" id="chk_frame_left_${f.id}" value="${f.id}" checked onchange="syncFrameRowCheckbox(${f.id}, this.checked)" style="width:18px; height:18px; cursor:pointer;">
                        </td>
                        <td>
                            <div id="preview_box_${f.id}" style="${renderAuraPreview(f.aura_type, f.grade, intensityVal)}">
                                ${f.avatar_url
                                    ? `<img src="${f.avatar_url}" class="row-ring-overlay fx-ring-${fxVal}" style="position:absolute; top:50%; left:50%; width:${ringPx}px; height:${ringPx}px; object-fit:contain; pointer-events:none; z-index:3;">`
                                    : '<span style="font-size:18px; opacity:0.65;">⭕</span>'}
                            </div>
                        </td>
                        <td>
                            <input type="text" id="frm_name_${f.id}" value="${(f.name || '').replace(/"/g, '&quot;')}" style="width:145px;">
                        </td>
                        <td>
                            <select id="frm_grade_${f.id}" style="width:76px;" onchange="autoUpdateRowAura(${f.id}, this.value)">
                                <option value="A" ${f.grade==='A'?'selected':''}>A</option>
                                <option value="A+" ${f.grade==='A+'?'selected':''}>A+</option>
                                <option value="S" ${f.grade==='S'?'selected':''}>S</option>
                                <option value="S+" ${f.grade==='S+'?'selected':''}>S+</option>
                                <option value="SS+" ${f.grade==='SS+'?'selected':''}>SS+</option>
                            </select>
                        </td>
                        <td>
                            <input type="number" id="frm_win_${f.id}" value="${f.win_rate_bonus || 5}" style="width:70px;" step="0.5" min="0" max="100"> %
                        </td>
                        <td>
                            <input type="number" id="frm_roll_${f.id}" value="${f.roll_rate || 20}" style="width:70px;" step="0.5" min="0" max="100"> %
                        </td>
                        <td>
                            <input type="number" id="frm_skill_${f.id}" value="${f.play_skill_rate || 10}" style="width:65px;" min="0" max="100">
                        </td>
                        <td>
                            <select id="frm_aura_${f.id}" style="width:115px;" onchange="updateRowPreview(${f.id})">
                                <option value="none" ${f.aura_type==='none'?'selected':''}>ไม่มีเออร่า</option>
                                <option value="white" ${f.aura_type==='white'?'selected':''}>ขาวนิดๆ</option>
                                <option value="cyan" ${f.aura_type==='cyan'?'selected':''}>ฟ้านิดๆ</option>
                                <option value="yellow" ${f.aura_type==='yellow'?'selected':''}>เหลืองเต็มๆ</option>
                                <option value="gold" ${f.aura_type==='gold'?'selected':''}>ทองสง่างาม</option>
                                <option value="orange" ${f.aura_type==='orange'?'selected':''}>ส้มเพลิง 🔥</option>
                                <option value="crimson" ${f.aura_type==='crimson'?'selected':''}>แดงเพลิง 🩸</option>
                                <option value="purple" ${f.aura_type==='purple'?'selected':''}>ม่วงดาราจักร 🔮</option>
                                <option value="rainbow" ${f.aura_type==='rainbow'?'selected':''}>รุ้งปริซึม 🌈</option>
                            </select>
                        </td>
                        <td>
                            <input type="number" id="frm_intensity_${f.id}" value="${intensityVal}" style="width:72px;" min="10" max="500" step="5" oninput="updateRowPreview(${f.id})"> %
                        </td>
                        <td>
                            <select id="frm_fx_${f.id}" style="width:130px;" onchange="updateRowPreview(${f.id})">
                                <option value="pulse_breathe" ${fxVal==='pulse_breathe'?'selected':''}>✨ พัลส์แสงนุ่มนวล</option>
                                <option value="spin_pulse" ${fxVal==='spin_pulse'?'selected':''}>🌀 หมุน+พัลส์</option>
                                <option value="spin_slow" ${fxVal==='spin_slow'?'selected':''}>🔄 หมุน 360°</option>
                                <option value="reverse_dual" ${fxVal==='reverse_dual'?'selected':''}>💫 วงแหวนคู่สวนทาง</option>
                                <option value="electric_orbit" ${fxVal==='electric_orbit'?'selected':''}>⚡ ดาวสายฟ้าวิ่ง</option>
                                <option value="flame_halo" ${fxVal==='flame_halo'?'selected':''}>🔥 เปลวเพลิงออร่า</option>
                                <option value="static" ${fxVal==='static'?'selected':''}>🛡️ กรอบนิ่ง</option>
                            </select>
                        </td>
                        <td style="white-space:nowrap;">
                            ${isTarget ? `
                                <span class="badge badge-gold" style="display:inline-block; padding:5px 10px;">🌟 เป้าหมายแลกการ์ดเงา</span>
                            ` : `
                                <div style="display:flex; flex-direction:column; gap:4px; align-items:flex-start;">
                                    <span style="font-size:11px; color:#38bdf8;">🎴 สุ่มแพ็ค 5 ใบ / แลกเงา</span>
                                    <button type="button" class="btn" style="padding:3px 8px; font-size:11px; background:#334155; color:#ffd700; border:1px solid #f59e0b;" onclick="setGachaTargetFrame(${f.id})">🎯 ตั้งเป็นเป้าหมายสุ่ม</button>
                                </div>
                            `}
                        </td>
                        <td>
                            <select id="frm_avail_${f.id}" style="width:74px;">
                                <option value="1" ${f.is_available==1?'selected':''}>เปิด</option>
                                <option value="0" ${f.is_available==0?'selected':''}>ปิด</option>
                            </select>
                        </td>
                        <td style="white-space:nowrap; text-align:right;">
                            <div style="display:inline-flex; align-items:center; gap:6px; justify-content:flex-end;">
                                <input type="checkbox" class="chk-frame-row-right" data-frame-id="${f.id}" checked onchange="syncFrameRowCheckbox(${f.id}, this.checked)" title="เลือกเพื่อบันทึกพร้อมกัน" style="width:17px; height:17px; cursor:pointer;">
                                <button type="button" class="btn" style="padding:5px 8px; font-size:11px; background:#7e22ce; color:#fff;" onclick="openFrameInAiStudio(${f.id})" title="แก้ไขรูปกรอบ แสงเออร่า และลูกเล่นใน AI Studio">🎨 แต่งกรอบ</button>
                                <button class="btn btn-accent" style="padding:5px 10px; font-size:12px;" onclick="saveFrameRow(${f.id})">💾 บันทึก</button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
            updateSelectedFramesCount();
        }

        // Also fetch and load Gacha Event Data
        try {
            const evRes = await fetch('admin_panel.php?api=1&action=get_gacha_event').then(r => r.json()).catch(() => null);
            if (evRes && evRes.data) {
                const ev = evRes.data;
                if (document.getElementById('ev_frame_name')) document.getElementById('ev_frame_name').value = ev.event_name || '🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+';
                if (document.getElementById('ev_frame_desc')) document.getElementById('ev_frame_desc').value = ev.description || '';
                if (document.getElementById('ev_frame_cost')) document.getElementById('ev_frame_cost').value = ev.cost_diamond || 100;
                if (document.getElementById('ev_cards_per_pack')) document.getElementById('ev_cards_per_pack').value = ev.cards_per_pack || 5;

                if (ev.start_date && document.getElementById('ev_frame_start')) {
                    document.getElementById('ev_frame_start').value = ev.start_date.replace(' ', 'T').substring(0, 16);
                }
                if (ev.end_date && document.getElementById('ev_frame_end')) {
                    document.getElementById('ev_frame_end').value = ev.end_date.replace(' ', 'T').substring(0, 16);
                }

                // Populate target frame dropdown
                const targetSelect = document.getElementById('ev_target_char_id');
                if (targetSelect && evRes.characters) {
                    targetSelect.innerHTML = evRes.characters.map(c => 
                        `<option value="${c.id}" ${c.id == ev.target_character_id ? 'selected' : ''}>[เกรด ${c.grade}] ${c.name} (เออร่า: ${c.aura_type})</option>`
                    ).join('');
                }

                // Populate event type & target dice dropdown
                if (document.getElementById('ev_event_type')) document.getElementById('ev_event_type').value = ev.event_type || 'FRAME';
                if (document.getElementById('ev_rate_target_boost')) document.getElementById('ev_rate_target_boost').value = parseFloat(ev.rate_target_boost) || 35.0;

                const diceSelect = document.getElementById('ev_target_dice_id');
                if (diceSelect && evRes.dice) {
                    diceSelect.innerHTML = evRes.dice.map(d => 
                        `<option value="${d.id}" ${d.id == (ev.target_dice_id || 1) ? 'selected' : ''}>[${d.grade}] ${d.name}</option>`
                    ).join('');
                }

                // Rates and requirements
                if (document.getElementById('ev_rate_black')) document.getElementById('ev_rate_black').value = parseFloat(ev.rate_shadow_black) || 90.0;
                if (document.getElementById('ev_req_black')) document.getElementById('ev_req_black').value = parseInt(ev.req_shadow_black) || 15;

                if (document.getElementById('ev_rate_red')) document.getElementById('ev_rate_red').value = parseFloat(ev.rate_shadow_red) || 80.0;
                if (document.getElementById('ev_req_red')) document.getElementById('ev_req_red').value = parseInt(ev.req_shadow_red) || 15;

                if (document.getElementById('ev_rate_orange')) document.getElementById('ev_rate_orange').value = parseFloat(ev.rate_shadow_orange) || 70.0;
                if (document.getElementById('ev_req_orange')) document.getElementById('ev_req_orange').value = parseInt(ev.req_shadow_orange) || 15;

                if (document.getElementById('ev_rate_blue')) document.getElementById('ev_rate_blue').value = parseFloat(ev.rate_shadow_blue) || 50.0;
                if (document.getElementById('ev_req_blue')) document.getElementById('ev_req_blue').value = parseInt(ev.req_shadow_blue) || 10;

                if (document.getElementById('ev_rate_gold')) document.getElementById('ev_rate_gold').value = parseFloat(ev.rate_shadow_gold) || 10.0;
                if (document.getElementById('ev_req_gold')) document.getElementById('ev_req_gold').value = parseInt(ev.req_shadow_gold) || 4;

                if (document.getElementById('ev_rate_splus')) document.getElementById('ev_rate_splus').value = parseFloat(ev.rate_splus) || 3.0;
                if (document.getElementById('ev_rate_special')) document.getElementById('ev_rate_special').value = parseFloat(ev.rate_shadow_special) || 15.0;

                if (document.getElementById('ev_frame_active')) document.getElementById('ev_frame_active').checked = Boolean(Number(ev.is_active));
            }
            renderActiveEventsOverview(evRes);
        } catch(err) {
            console.error('get_gacha_event error:', err);
            renderActiveEventsOverview(null);
        }
    } catch(e) { console.error('loadAdminFrames error:', e); }
}

// ==========================================
// 🎯 ACTIVE EVENTS & LIVE CAMPAIGNS DASHBOARD
// ==========================================
let gachaLiveCountdownInterval = null;

function scrollToGachaSetupForm() {
    const el = document.getElementById('frameGachaEventForm');
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.style.transition = 'box-shadow 0.4s ease, border-color 0.4s ease';
        el.style.boxShadow = '0 0 35px rgba(245, 158, 11, 0.85)';
        el.style.borderColor = '#f59e0b';
        setTimeout(() => {
            el.style.boxShadow = '';
            el.style.borderColor = '';
        }, 2200);
    }
}

async function toggleGachaEventActiveState() {
    try {
        const res = await fetch('admin_panel.php?api=1&action=toggle_gacha_event_active', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'}
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(res.message || 'อัปเดตสถานะกิจกรรมสำเร็จ');
            await loadAdminFrames();
        } else {
            alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถสลับสถานะได้'));
        }
    } catch(e) {
        console.error('toggleGachaEventActiveState error:', e);
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อ');
    }
}

function renderActiveEventsOverview(evRes) {
    const container = document.getElementById('active-events-overview-container');
    if (!container) return;

    try {
        let ev = evRes?.data;
        if (!ev) {
            ev = {
                event_name: '🎰 เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+',
                description: 'เปิดแพ็คสุ่มการ์ด 1 ใบใช้เพียง 100 เพชร ลุ้นรับการ์ด S+ พญานาคราช และเงาวัตถุดิบ 5 ชนิด',
                event_type: 'FRAME',
                cost_diamond: 100,
                cards_per_pack: 5,
                target_character_id: 1,
                target_dice_id: 1,
                rate_target_boost: 35.0,
                is_active: 1,
                start_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
                end_date: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            };
        }

        const isActive = Boolean(Number(ev.is_active));
        let targetChar = evRes?.target_character || (evRes?.characters ? evRes.characters.find(c => parseInt(c.id) === parseInt(ev.target_character_id)) : null);
        if (!targetChar && typeof adminFramesCache !== 'undefined' && Array.isArray(adminFramesCache) && adminFramesCache.length > 0) {
            targetChar = adminFramesCache[0];
        }
        if (!targetChar) {
            targetChar = {
                name: 'พญานาคราช 3D',
                grade: 'S+',
                aura_type: 'gold',
                aura_intensity: 100,
                frame_fx: 'pulse_breathe',
                win_rate_bonus: 55,
                roll_rate: 65,
                play_skill_rate: 30
            };
        }

        let targetDice = evRes?.target_dice || (evRes?.dice ? evRes.dice.find(d => parseInt(d.id) === parseInt(ev.target_dice_id || 1)) : null);
        if (!targetDice && evRes?.dice && evRes.dice.length > 0) {
            targetDice = evRes.dice[0];
        }
        if (!targetDice) {
            targetDice = {
                id: 1,
                name: 'ลูกเต๋าพญานาคราชทองคำ 3D',
                grade: 'S+',
                dice_control_rate: 65,
                color_hex: '#00e5ff'
            };
        }

        const giveaways = evRes?.active_giveaways || [];
        const cubeCount = evRes?.cube_count || 4;

        // Check date validity
        const now = new Date();
        const startDate = ev.start_date ? new Date(String(ev.start_date).replace(' ', 'T')) : null;
        const endDate = ev.end_date ? new Date(String(ev.end_date).replace(' ', 'T')) : null;
        const isStarted = !startDate || (now >= startDate);
        const isExpired = endDate && (now > endDate);
        const isRunning = isActive && isStarted && !isExpired;

        // Count total live activities
        let liveCount = 0;
        if (isRunning) liveCount++;
        if (giveaways.length > 0) liveCount += giveaways.length;
        liveCount += 2; // Magic cube + Season ranking

        const countBadge = document.getElementById('badge-live-events-count');
        if (countBadge) {
            countBadge.innerText = isRunning ? `🟢 กำลังเปิด ${liveCount} กิจกรรม` : `⚠️ กำลังเปิด ${liveCount} กิจกรรม (สุ่มการ์ดถูกพัก)`;
            countBadge.style.background = isRunning ? '#10b981' : '#f59e0b';
        }

    // Target Character Preview HTML
    let charPreviewHtml = '';
    if (targetChar) {
        const intensity = parseInt(targetChar.aura_intensity) || 100;
        const fx = targetChar.frame_fx || 'pulse_breathe';
        const ringStyle = (typeof renderAuraPreview === 'function')
            ? renderAuraPreview(targetChar.aura_type, targetChar.grade, intensity)
            : 'width:56px; height:56px; border-radius:50%; border:3px solid #ffd700; box-shadow:0 0 20px #ffd700;';

        charPreviewHtml = `
            <div style="background: rgba(15,23,42,0.85); border: 1.5px solid #ffd700; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 14px; box-shadow: 0 4px 18px rgba(255,215,0,0.18);">
                <div style="${ringStyle} width:54px; height:54px; flex-shrink:0;">
                    ${targetChar.avatar_url ? `<img src="${targetChar.avatar_url}" class="fx-ring-${fx}" style="position:absolute; top:50%; left:50%; width:64px; height:64px; object-fit:contain; pointer-events:none; z-index:3;">` : '<span style="font-size:22px;">👑</span>'}
                </div>
                <div style="flex:1; min-width:0;">
                    <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                        <span style="background:linear-gradient(135deg, #ffd700, #f59e0b); color:#000; font-size:10px; font-weight:800; padding:2px 8px; border-radius:6px;">เกรด ${targetChar.grade || 'S+'}</span>
                        <strong style="color:#ffd700; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${targetChar.name || 'พญานาคราช 3D'}</strong>
                    </div>
                    <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                        เออร่า: <span style="color:#fde047; font-weight:700;">${targetChar.aura_type || 'gold'} (${intensity}%)</span>
                    </div>
                    <div style="display:flex; gap:6px; flex-wrap:wrap; font-size:10px; margin-top:4px;">
                        <span style="background:rgba(52,211,153,0.15); border:1px solid rgba(52,211,153,0.3); color:#34d399; padding:1px 6px; border-radius:4px;">🏆 ชนะ: +${targetChar.win_rate_bonus || 55}%</span>
                        <span style="background:rgba(56,189,248,0.15); border:1px solid rgba(56,189,248,0.3); color:#38bdf8; padding:1px 6px; border-radius:4px;">🎲 ทอย: +${targetChar.roll_rate || 65}%</span>
                        <span style="background:rgba(244,114,182,0.15); border:1px solid rgba(244,114,182,0.3); color:#f472b6; padding:1px 6px; border-radius:4px;">⚡ ฝีมือ: +${targetChar.play_skill_rate || 30}</span>
                    </div>
                </div>
            </div>
        `;
    }

    // Target Dice Preview HTML (แสดงกล่องกิจกรรมลูกเต๋าเป้าหมายเสมอ)
    let dicePreviewHtml = '';
    if (targetDice) {
        dicePreviewHtml = `
            <div style="background: rgba(15,23,42,0.85); border: 1.5px solid #00e5ff; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 14px; box-shadow: 0 4px 18px rgba(0,229,255,0.22); position:relative;">
                <div style="width:54px; height:54px; border-radius:12px; background:linear-gradient(135deg, rgba(0,229,255,0.18), rgba(2,132,199,0.25)); border:1.5px solid #00e5ff; display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 0 16px rgba(0,229,255,0.4);">
                    ${targetDice.image_url ? `<img src="${targetDice.image_url}" style="width:42px; height:42px; object-fit:contain;">` : '<span style="font-size:28px; filter: drop-shadow(0 0 8px #00e5ff);">🎲</span>'}
                </div>
                <div style="flex:1; min-width:0;">
                    <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                        <span style="background:linear-gradient(135deg, #00e5ff, #0284c7); color:#000; font-size:10px; font-weight:800; padding:2px 8px; border-radius:6px;">เกรด ${targetDice.grade || 'S+'}</span>
                        <strong style="color:#00e5ff; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${targetDice.name}</strong>
                    </div>
                    <div style="font-size:11px; color:#cbd5e1; margin-top:3px;">
                        คุมเต๋า/ทอยแม่นยำ: <span style="color:#38bdf8; font-weight:700;">+${targetDice.dice_control_rate || 65}%</span>
                    </div>
                    <div style="display:flex; gap:6px; flex-wrap:wrap; font-size:10px; margin-top:4px; align-items:center;">
                        <span style="background:rgba(245,158,11,0.2); border:1px solid #f59e0b; color:#fbbf24; font-weight:700; padding:1px 8px; border-radius:4px;">🔥 เรตอัปเป้าหมาย +${ev.rate_target_boost || 35}%</span>
                        <button type="button" class="btn" style="padding:2px 8px; font-size:10px; background:rgba(0,229,255,0.15); border:1px solid #00e5ff; color:#00e5ff; font-weight:700; cursor:pointer;" onclick="switchTab('character_stats')">🎯 เปลี่ยนเต๋า</button>
                    </div>
                </div>
            </div>
        `;
    }

    // Giveaways items HTML
    let giveawaysListHtml = '';
    if (giveaways.length > 0) {
        giveawaysListHtml = giveaways.map(g => `
            <div style="background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:8px 10px; margin-bottom:6px;">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:6px;">
                    <strong style="color:#f8fafc; font-size:12px;">${g.title}</strong>
                    ${g.promo_code ? `<span style="background:#f59e0b; color:#000; font-weight:800; font-size:10px; padding:2px 6px; border-radius:4px;">โค้ด: ${g.promo_code}</span>` : '<span style="background:#10b981; color:#fff; font-size:10px; padding:2px 6px; border-radius:4px;">แจกทุกคน</span>'}
                </div>
                <div style="font-size:11px; color:#94a3b8; margin-top:2px; display:flex; gap:8px;">
                    ${g.reward_diamond > 0 ? `<span style="color:#38bdf8;">💎 +${Number(g.reward_diamond).toLocaleString()} เพชร</span>` : ''}
                    ${g.reward_gold > 0 ? `<span style="color:#ffd700;">🪙 +${Number(g.reward_gold).toLocaleString()} ทอง</span>` : ''}
                </div>
            </div>
        `).join('');
    } else {
        giveawaysListHtml = '<div style="color:#64748b; font-size:11px; padding:10px; text-align:center;">ยังไม่มีกิจกรรมแจกโค้ดที่เปิดอยู่</div>';
    }

    container.innerHTML = `
        <!-- 1. PRIMARY HIGHLIGHT: CARD GACHA & SHADOW EXCHANGE EVENT -->
        <div style="background: linear-gradient(135deg, rgba(30,58,138,0.28) 0%, rgba(15,23,42,0.88) 100%); border: 1.5px solid ${isRunning ? '#38bdf8' : '#64748b'}; border-radius: 14px; padding: 18px 20px; margin-bottom: 20px; box-shadow: ${isRunning ? '0 8px 30px rgba(56,189,248,0.18)' : 'none'};">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px; margin-bottom:12px;">
                <div style="flex:1; min-width:280px;">
                    <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:6px;">
                        ${isRunning
                            ? `<span style="background:rgba(16,185,129,0.22); border:1.5px solid #10b981; color:#34d399; font-size:12px; font-weight:800; padding:4px 12px; border-radius:20px; display:inline-flex; align-items:center; gap:6px;"><span class="live-pulse-dot"></span> 🟢 กำลังดำเนินการ (LIVE NOW)</span>`
                            : `<span style="background:rgba(239,68,68,0.2); border:1.5px solid #ef4444; color:#f87171; font-size:12px; font-weight:800; padding:4px 12px; border-radius:20px;">🔴 ปิดใช้งานอยู่ (PAUSED)</span>`
                        }
                        <span style="font-size:12px; color:#38bdf8; font-weight:700;">🎰 กิจกรรมสุ่มแพ็คการ์ด 5 ใบ & แลกการ์ดเงา</span>
                    </div>
                    <h3 style="margin:0 0 6px 0; color:#f8fafc; font-size:19px; font-weight:800; letter-spacing:0.3px;">
                        ${ev.event_name || 'เทศกาลสุ่มการ์ดแพ็ค 5 ใบ ลุ้นรับการ์ดเงาแลกกรอบรูป S+'}
                    </h3>
                    <p style="margin:0; font-size:13px; color:#94a3b8; line-height:1.5;">
                        ${ev.description || 'เปิดแพ็คสุ่มการ์ด 1 ใบใช้เพียง 100 เพชร ลุ้นรับการ์ด S+ พญานาคราช และเงาวัตถุดิบ 5 ชนิด'}
                    </p>
                </div>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <button type="button" class="btn ${isActive ? 'btn-danger' : 'btn-accent'}" style="padding:8px 16px; font-size:13px; font-weight:700;" onclick="toggleGachaEventActiveState()">
                        ${isActive ? '⏸️ พัก/ปิดกิจกรรมนี้' : '▶️ เปิดใช้งานกิจกรรมนี้'}
                    </button>
                    <button type="button" class="btn" style="padding:8px 14px; font-size:13px; background:#334155; color:#fff;" onclick="scrollToGachaSetupForm()">
                        ⚙️ แก้ไขกิจกรรมนี้
                    </button>
                </div>
            </div>

            <!-- Time range & Countdown Ticker -->
            <div style="background:rgba(15,23,42,0.75); border:1px solid rgba(56,189,248,0.3); border-radius:10px; padding:10px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#cbd5e1;">
                    <span>📅</span>
                    <span>ระยะเวลากิจกรรม: <strong style="color:#fff;">${ev.start_date || '01 พ.ย. 2026 00:00'}</strong> ถึง <strong style="color:#fff;">${ev.end_date || '30 พ.ย. 2026 23:59'}</strong></span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="font-size:12px; color:#fbbf24; font-weight:700;">⏳ เวลาที่เหลือ:</span>
                    <span id="gacha-live-countdown" style="font-family:monospace; font-size:15px; font-weight:800; color:#00e5ff; background:rgba(0,229,255,0.12); padding:4px 10px; border-radius:6px; border:1px solid rgba(0,229,255,0.4);">
                        กำลังคำนวณ...
                    </span>
                </div>
            </div>

            <!-- Highlight Targets Box -->
            <div style="font-size:13px; font-weight:800; color:#f59e0b; margin-bottom:8px; display:flex; align-items:center; gap:6px;">
                <span>✨</span> ไอเทมเป้าหมายประจำกิจกรรม (Event Highlights):
            </div>
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:12px;">
                ${charPreviewHtml}
                ${dicePreviewHtml}
                <div style="background: rgba(15,23,42,0.85); border: 1.5px solid rgba(148,163,184,0.3); border-radius: 12px; padding: 12px 14px; display:flex; flex-direction:column; justify-content:center;">
                    <div style="font-size:11px; color:#94a3b8; margin-bottom:4px;">💎 ค่าเปิดสุ่มและอัตราการ์ด:</div>
                    <div style="font-size:14px; font-weight:800; color:#38bdf8; margin-bottom:6px;">
                        💎 ${ev.cost_diamond || 100} เพชร / 1 แพ็ค (${ev.cards_per_pack || 5} ใบ)
                    </div>
                    <div style="font-size:11px; color:#cbd5e1; display:flex; gap:6px; flex-wrap:wrap;">
                        <span title="เงาทมิฬ" style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">⬛ ${ev.req_shadow_black || 25} ใบ</span>
                        <span title="เงาเพลิง" style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">🟥 ${ev.req_shadow_red || 25} ใบ</span>
                        <span title="เงาส้ม" style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">🟧 ${ev.req_shadow_orange || 20} ใบ</span>
                        <span title="เงาฟ้า" style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">🟦 ${ev.req_shadow_blue || 15} ใบ</span>
                        <span title="เงาทอง" style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">🟨 ${ev.req_shadow_gold || 8} ใบ</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. CONCURRENT SERVER ACTIVITIES (3 COLUMNS) -->
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:14px;">
            <!-- Giveaway & Promo Codes -->
            <div style="background: rgba(15,23,42,0.65); border: 1.5px solid rgba(245,158,11,0.3); border-radius: 12px; padding: 14px 16px; display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                        <strong style="color:#fbbf24; font-size:14px; display:flex; align-items:center; gap:6px;">
                            <span>🎁</span> กิจกรรมแจกเพชร & ทอง
                        </strong>
                        <span style="background:rgba(16,185,129,0.2); color:#34d399; font-size:11px; font-weight:700; padding:2px 8px; border-radius:12px;">🟢 เปิดแจกอยู่</span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-bottom:10px;">
                        กิจกรรมแจกของรางวัลฟรี และโค้ดโปรโมชั่นที่เปิดให้กดรับ:
                    </div>
                    ${giveawaysListHtml}
                </div>
                <button type="button" class="btn" style="width:100%; margin-top:10px; padding:7px; font-size:12px; background:rgba(245,158,11,0.15); border:1px solid #f59e0b; color:#fbbf24; font-weight:700;" onclick="switchTab('events')">
                    👉 ไปจัดการกิจกรรมแจก (แท็บ 1)
                </button>
            </div>

            <!-- Magic Cube System -->
            <div style="background: rgba(15,23,42,0.65); border: 1.5px solid rgba(56,189,248,0.3); border-radius: 12px; padding: 14px 16px; display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                        <strong style="color:#38bdf8; font-size:14px; display:flex; align-items:center; gap:6px;">
                            <span>🧊</span> ตู้หมุนลูกบาศก์นำโชค (Magic Cube)
                        </strong>
                        <span style="background:rgba(16,185,129,0.2); color:#34d399; font-size:11px; font-weight:700; padding:2px 8px; border-radius:12px;">🟢 รองรับ 4 ช่อง</span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-bottom:8px;">
                        ลูกบาศก์ 4 ระดับ พร้อมหมุนรับเพชรและทองสูงสุด 250,000:
                    </div>
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:6px; font-size:11px;">
                        <div style="background:rgba(255,255,255,0.04); padding:6px 8px; border-radius:6px; border-left:2px solid #cbd5e1;">
                            <span style="color:#cbd5e1; font-weight:700;">ลูกบาศก์เงิน</span>
                            <div style="color:#94a3b8; font-size:10px;">⏱️ 1-3 ชม.</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.04); padding:6px 8px; border-radius:6px; border-left:2px solid #f59e0b;">
                            <span style="color:#f59e0b; font-weight:700;">ลูกบาศก์ทอง</span>
                            <div style="color:#94a3b8; font-size:10px;">⏱️ 3-6 ชม.</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.04); padding:6px 8px; border-radius:6px; border-left:2px solid #00e5ff;">
                            <span style="color:#00e5ff; font-weight:700;">ลูกบาศก์เพชร</span>
                            <div style="color:#94a3b8; font-size:10px;">⏱️ 6-9 ชม.</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.04); padding:6px 8px; border-radius:6px; border-left:2px solid #c084fc;">
                            <span style="color:#c084fc; font-weight:700;">ลูกบาศก์ตำนาน</span>
                            <div style="color:#94a3b8; font-size:10px;">⏱️ 9-12 ชม.</div>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn" style="width:100%; margin-top:10px; padding:7px; font-size:12px; background:rgba(56,189,248,0.15); border:1px solid #38bdf8; color:#38bdf8; font-weight:700;" onclick="switchTab('magic_cubes')">
                    👉 ไปจัดการลูกบาศก์ Magic Cube (แท็บ 5)
                </button>
            </div>

            <!-- Season Ranking Weekly Reset -->
            <div style="background: rgba(15,23,42,0.65); border: 1.5px solid rgba(250,204,21,0.3); border-radius: 12px; padding: 14px 16px; display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                        <strong style="color:#ffd700; font-size:14px; display:flex; align-items:center; gap:6px;">
                            <span>🏆</span> ลีกจัดอันดับ (Ranking Season 1)
                        </strong>
                        <span style="background:rgba(16,185,129,0.2); color:#34d399; font-size:11px; font-weight:700; padding:2px 8px; border-radius:12px;">🟢 แข่งขันอยู่</span>
                    </div>
                    <div style="font-size:11px; color:#94a3b8; margin-bottom:8px;">
                        ระบบการแข่งขันไต่อันดับกระดาน 3D ประจำฤดูกาล:
                    </div>
                    <div style="background:rgba(255,255,255,0.04); padding:8px 10px; border-radius:8px; font-size:11px; color:#cbd5e1; margin-bottom:6px;">
                        <div>⚡ <strong>รอบรีเซ็ตแต้ม:</strong> ทุกวันพุธ เวลา 10:00 น.</div>
                        <div style="margin-top:3px; color:#94a3b8;">🎁 แจกรางวัลอัตโนมัติเข้าตู้จดหมายผู้เล่นอันดับ 1 - 100</div>
                    </div>
                    <div style="font-size:11px; color:#34d399; display:flex; align-items:center; gap:4px;">
                        <span>🛡️</span> จัดอันดับตามสินทรัพย์และคะแนนสะสมแบบเรียลไทม์
                    </div>
                </div>
                <button type="button" class="btn" style="width:100%; margin-top:10px; padding:7px; font-size:12px; background:rgba(250,204,21,0.15); border:1px solid #ffd700; color:#ffd700; font-weight:700;" onclick="switchTab('ranking_settings')">
                    👉 ไปจัดการจัดอันดับ & รีเซ็ต (แท็บ 3)
                </button>
            </div>
        </div>
    `;

    // Start Live Countdown Interval
    if (gachaLiveCountdownInterval) clearInterval(gachaLiveCountdownInterval);
    const updateCountdown = () => {
        const cdEl = document.getElementById('gacha-live-countdown');
        if (!cdEl) return;
        if (!endDate) {
            cdEl.innerText = 'ไม่จำกัดเวลา (ถาวร)';
            return;
        }
        const diff = endDate.getTime() - Date.now();
        if (diff <= 0) {
            cdEl.innerText = 'สิ้นสุดระยะเวลากิจกรรมแล้ว';
            cdEl.style.color = '#ef4444';
        } else {
            const d = Math.floor(diff / (1000 * 60 * 60 * 24));
            const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const s = Math.floor((diff % (1000 * 60)) / 1000);
            const pad = (n) => String(n).padStart(2, '0');
            cdEl.innerText = `${d} วัน ${pad(h)}:${pad(m)}:${pad(s)} ชม.`;
            cdEl.style.color = '#00e5ff';
        }
    };
    updateCountdown();
    gachaLiveCountdownInterval = setInterval(updateCountdown, 1000);
    } catch(err) {
        console.error('renderActiveEventsOverview error:', err);
    }
}

function autoUpdateRowAura(id, grade) {
    const sel = document.getElementById('frm_aura_' + id);
    if (!sel) return;
    if (grade === 'SS+') sel.value = 'gold';
    else if (grade === 'S+') sel.value = 'yellow';
    else if (grade === 'S') sel.value = 'cyan';
    else if (grade === 'A+') sel.value = 'white';
    else sel.value = 'none';
    updateRowPreview(id);
}

function autoSelectAura(grade) {
    const sel = document.getElementById('new_frame_aura');
    if (!sel) return;
    if (grade === 'SS+') sel.value = 'gold';
    else if (grade === 'S+') sel.value = 'yellow';
    else if (grade === 'S') sel.value = 'cyan';
    else if (grade === 'A+') sel.value = 'white';
    else sel.value = 'none';
}

function syncFrameRowCheckbox(id, checked) {
    const leftChk = document.getElementById('chk_frame_left_' + id);
    if (leftChk) leftChk.checked = checked;
    document.querySelectorAll(`.chk-frame-row-right[data-frame-id="${id}"]`).forEach(chk => {
        chk.checked = checked;
    });
    updateSelectedFramesCount();
}

function toggleSelectAllFrames(checked) {
    document.querySelectorAll('.chk-frame-row, .chk-frame-row-right').forEach(chk => { chk.checked = checked; });
    ['chk-select-all-frames', 'chk-right-select-all-frames', 'chk-toolbar-select-all', 'chk-bottom-select-all'].forEach(elId => {
        const el = document.getElementById(elId);
        if (el) el.checked = checked;
    });
    updateSelectedFramesCount();
}

function updateSelectedFramesCount() {
    const all = document.querySelectorAll('.chk-frame-row');
    const checked = document.querySelectorAll('.chk-frame-row:checked');
    const cntEl = document.getElementById('selected-frames-count');
    if (cntEl) cntEl.innerText = checked.length;
    const cntBottomEl = document.getElementById('selected-frames-count-bottom');
    if (cntBottomEl) cntBottomEl.innerText = checked.length;
    const allChecked = all.length > 0 && checked.length === all.length;
    ['chk-select-all-frames', 'chk-right-select-all-frames', 'chk-toolbar-select-all', 'chk-bottom-select-all'].forEach(elId => {
        const el = document.getElementById(elId);
        if (el) el.checked = allChecked;
    });
}

function collectFrameRowPayload(id) {
    return {
        id: parseInt(id),
        name: document.getElementById('frm_name_' + id)?.value || '',
        grade: document.getElementById('frm_grade_' + id)?.value || 'A',
        win_rate_bonus: parseFloat(document.getElementById('frm_win_' + id)?.value) || 0,
        roll_rate: parseFloat(document.getElementById('frm_roll_' + id)?.value) || 0,
        play_skill_rate: parseFloat(document.getElementById('frm_skill_' + id)?.value) || 0,
        aura_type: document.getElementById('frm_aura_' + id)?.value || 'none',
        aura_intensity: parseInt(document.getElementById('frm_intensity_' + id)?.value) || 100,
        frame_fx: document.getElementById('frm_fx_' + id)?.value || 'pulse_breathe',
        price_diamond: 0,
        is_available: parseInt(document.getElementById('frm_avail_' + id)?.value ?? '1')
    };
}

async function saveSelectedFrames() {
    const checked = Array.from(document.querySelectorAll('.chk-frame-row:checked'));
    if (checked.length === 0) {
        alert('กรุณาติ๊กเลือกรายการกรอบรูปที่ต้องการบันทึก หรือกด "เลือกทั้งหมด" ก่อน');
        return;
    }

    const saveBtns = Array.from(document.querySelectorAll('.btn-save-all-frames'));
    const origTexts = saveBtns.map(b => b.innerHTML);
    saveBtns.forEach(b => { b.disabled = true; b.innerHTML = '⏳ กำลังบันทึก...'; });

    try {
        const frames = checked.map(chk => collectFrameRowPayload(chk.value));
        const res = await fetch('admin_panel.php?api=1&action=batch_save_frames', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ frames })
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(res.message);
            await loadAdminFrames();
        } else {
            alert('เกิดข้อผิดพลาด: ' + (res.message || 'บันทึกทั้งหมดไม่สำเร็จ'));
        }
    } catch (err) {
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อ: ' + err.message);
    } finally {
        saveBtns.forEach((b, i) => { b.disabled = false; b.innerHTML = origTexts[i]; });
    }
}

async function setGachaTargetFrame(charId) {
    const res = await fetch('admin_panel.php?api=1&action=set_gacha_target_frame', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ character_id: charId })
    }).then(r => r.json());

    if (res && res.status === 'success') {
        showToast(res.message);
        loadAdminFrames();
    } else {
        alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถตั้งเป้าหมายได้'));
    }
}

async function setGachaTargetDice(diceId, diceName) {
    if (diceName && !confirm(`ยืนยันการตั้งลูกเต๋า '${diceName}' ให้เป็นเป้าหมายประจำกิจกรรมสุ่มลูกเต๋าใช่หรือไม่?`)) return;
    try {
        const res = await fetch('admin_panel.php?api=1&action=set_gacha_target_dice', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ dice_id: diceId })
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(res.message);
            // อัปเดตสถานะปุ่มในตารางลูกเต๋า
            document.querySelectorAll('[id^="target-dice-action-"]').forEach(el => {
                const id = el.id.replace('target-dice-action-', '');
                if (parseInt(id) === parseInt(diceId)) {
                    el.innerHTML = `<span style="background:rgba(16,185,129,0.2); border:1.5px solid #10b981; color:#34d399; font-weight:800; padding:4px 10px; border-radius:6px; font-size:12px; display:inline-flex; align-items:center; gap:5px; box-shadow:0 0 10px rgba(16,185,129,0.3);">🌟 กำลังเป็นเต๋าเป้าหมายกิจกรรม</span>`;
                } else {
                    el.innerHTML = `<button type="button" class="btn btn-accent" style="padding:4px 12px; font-size:12px; background:linear-gradient(135deg, #0284c7, #06b6d4);" onclick="setGachaTargetDice(${id}, '')">🎯 ตั้งเป็นเต๋ากิจกรรม</button>`;
                }
            });
            const lbl = document.getElementById('lbl-active-event-dice');
            if (lbl && diceName) lbl.innerText = diceName;
            // โหลดข้อมูลกิจกรรมใหม่เพื่ออัปเดตกล่องไฮไลต์ด้านบน
            await loadAdminFrames();
        } else {
            alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถตั้งเป้าหมายลูกเต๋าได้'));
        }
    } catch (err) {
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อ: ' + err.message);
    }
}

async function saveFrameRow(id) {
    const payload = collectFrameRowPayload(id);

    const res = await fetch('admin_panel.php?api=1&action=save_frame_character', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(r => r.json());

    if (res && res.status === 'success') {
        showToast(res.message);
        loadAdminFrames();
    } else {
        alert('เกิดข้อผิดพลาด: ' + (res.message || 'บันทึกไม่สำเร็จ'));
    }
}

async function submitCreateFrame(e) {
    e.preventDefault();
    const setTargetEl = document.getElementById('new_frame_set_target');
    const payload = {
        id: 0,
        name: document.getElementById('new_frame_name').value.trim(),
        grade: document.getElementById('new_frame_grade').value,
        win_rate_bonus: parseFloat(document.getElementById('new_frame_win').value) || 0,
        roll_rate: parseFloat(document.getElementById('new_frame_roll').value) || 0,
        play_skill_rate: parseFloat(document.getElementById('new_frame_skill').value) || 0,
        aura_type: document.getElementById('new_frame_aura').value,
        aura_intensity: parseInt(document.getElementById('new_frame_intensity').value) || 100,
        price_diamond: 0,
        is_available: 1,
        set_as_gacha_target: setTargetEl ? (setTargetEl.value === '1') : true
    };

    const res = await fetch('admin_panel.php?api=1&action=save_frame_character', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(r => r.json());

    if (res && res.status === 'success') {
        showToast(res.message);
        document.getElementById('new_frame_name').value = '';
        loadAdminFrames();
    } else {
        alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถสร้างได้'));
    }
}

async function submitSaveFrameGacha(e) {
    e.preventDefault();
    const payload = {
        event_name: document.getElementById('ev_frame_name').value,
        description: document.getElementById('ev_frame_desc').value,
        event_type: 'FRAME',
        cost_diamond: parseInt(document.getElementById('ev_frame_cost').value) || 100,
        cards_per_pack: parseInt(document.getElementById('ev_cards_per_pack').value) || 5,
        target_character_id: parseInt(document.getElementById('ev_target_char_id').value) || 1,
        target_dice_id: activeEventTargetDiceId || 1,
        rate_target_boost: parseFloat(document.getElementById('ev_rate_target_boost')?.value) || 35.0,
        start_date: document.getElementById('ev_frame_start').value || undefined,
        end_date: document.getElementById('ev_frame_end').value || undefined,
        rate_shadow_black: parseFloat(document.getElementById('ev_rate_black').value) || 90.0,
        req_shadow_black: parseInt(document.getElementById('ev_req_black').value) || 15,
        rate_shadow_red: parseFloat(document.getElementById('ev_rate_red').value) || 80.0,
        req_shadow_red: parseInt(document.getElementById('ev_req_red').value) || 15,
        rate_shadow_orange: parseFloat(document.getElementById('ev_rate_orange').value) || 70.0,
        req_shadow_orange: parseInt(document.getElementById('ev_req_orange').value) || 15,
        rate_shadow_blue: parseFloat(document.getElementById('ev_rate_blue').value) || 50.0,
        req_shadow_blue: parseInt(document.getElementById('ev_req_blue').value) || 10,
        rate_shadow_gold: parseFloat(document.getElementById('ev_rate_gold').value) || 10.0,
        req_shadow_gold: parseInt(document.getElementById('ev_req_gold').value) || 4,
        rate_splus: parseFloat(document.getElementById('ev_rate_splus').value) || 3.0,
        rate_shadow_special: parseFloat(document.getElementById('ev_rate_special').value) || 15.0,
        is_active: document.getElementById('ev_frame_active').checked ? 1 : 0
    };

    const res = await fetch('admin_panel.php?api=1&action=save_gacha_event', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(r => r.json());

    if (res && res.status === 'success') {
        showToast('บันทึกการตั้งค่ากิจกรรมสุ่มแพ็คการ์ด 5 ใบสำเร็จ!');
        await loadAdminFrames();
    } else {
        alert('เกิดข้อผิดพลาด: ' + (res.message || 'บันทึกไม่สำเร็จ'));
    }
}

// ==========================================
// 🤖 AI FRAME STUDIO & CREATOR JAVASCRIPT
// ==========================================
let currentAiSourceImageObj = null;
let currentAiUploadedImageData = '';
let currentAiClearAvatarFlag = false;
let currentAiColorTone = 'orange';
let currentAiCenterMode = 'sample_avatar'; // 'sample_avatar' (ใส่รูปแอดมินทดสอบเป็นค่าเริ่มต้น) | 'ring_only'

function populateAiStudioEditSelect(framesList) {
    const sel = document.getElementById('ai_edit_existing_select');
    if (!sel || !Array.isArray(framesList)) return;
    const curVal = sel.value || '0';
    sel.innerHTML = '<option value="0">➕ โหมด: สร้างกรอบรูปใหม่ด้วย AI</option>' +
        framesList.map(f => `<option value="${f.id}">✏️ แก้ไข: [${f.grade}] ${f.name}</option>`).join('');
    if ([...sel.options].some(o => o.value === String(curVal))) {
        sel.value = String(curVal);
    }
}

async function openFrameInAiStudio(charId) {
    switchTab('ai_creator');
    if (!adminFramesCache || adminFramesCache.length === 0) {
        await loadAdminFrames();
    }
    const sel = document.getElementById('ai_edit_existing_select');
    if (sel) sel.value = String(charId);
    loadFrameIntoAiStudio(charId);
}

function loadFrameIntoAiStudio(charId) {
    const id = parseInt(charId) || 0;
    document.getElementById('ai_editing_char_id').value = id;
    currentAiClearAvatarFlag = false;

    const btnSave = document.getElementById('btn-save-ai-frame');
    const clearBtn = document.getElementById('btn_clear_ai_ring');

    if (id <= 0) {
        resetAiStudioToNew();
        return;
    }

    const f = (adminFramesCache || []).find(item => parseInt(item.id) === id);
    if (!f) return;

    document.getElementById('ai_frame_name').value = f.name || '';
    document.getElementById('ai_frame_grade').value = f.grade || 'SS+';
    document.getElementById('ai_frame_aura').value = f.aura_type || 'gold';
    const intVal = f.aura_intensity !== undefined ? parseInt(f.aura_intensity) : 100;
    document.getElementById('ai_frame_intensity').value = intVal;
    if (document.getElementById('ai_frame_intensity_num')) document.getElementById('ai_frame_intensity_num').value = intVal;
    document.getElementById('ai_intensity_label').innerText = intVal + '%';
    document.getElementById('ai_frame_fx').value = f.frame_fx || 'spin_pulse';
    const scaleVal = parseInt(f.frame_scale) || 122;
    document.getElementById('ai_frame_scale').value = scaleVal;
    document.getElementById('ai_frame_scale_label').innerText = scaleVal + '%';

    document.getElementById('ai_frame_win').value = parseFloat(f.win_rate_bonus) || 55;
    document.getElementById('ai_frame_roll').value = parseFloat(f.roll_rate) || 65;
    document.getElementById('ai_frame_skill').value = parseFloat(f.play_skill_rate) || 30;
    if (f.color_hex && /^#[0-9a-fA-F]{6}$/.test(f.color_hex)) {
        document.getElementById('ai_frame_color').value = f.color_hex;
    }

    currentAiSourceImageObj = null;
    currentAiUploadedImageData = f.avatar_url || '';

    // If existing avatar_url was an old non-transparent JPEG, re-extract it cleanly into a transparent ring PNG!
    if (currentAiUploadedImageData && currentAiUploadedImageData.startsWith('data:image/jpeg')) {
        const tmpImg = new Image();
        tmpImg.onload = () => {
            currentAiSourceImageObj = tmpImg;
            reprocessCurrentAiRing();
        };
        tmpImg.src = currentAiUploadedImageData;
    }

    if (clearBtn) clearBtn.style.display = currentAiUploadedImageData ? 'inline-block' : 'none';
    if (btnSave) btnSave.innerText = `💾 บันทึกการแก้ไขกรอบรูป "${f.name}" (#${id})`;

    const statusBox = document.getElementById('ai_analysis_status');
    if (statusBox) {
        statusBox.style.display = 'block';
        statusBox.innerHTML = `✏️ กำลังแก้ไขกรอบรูป <strong>${f.name}</strong> — สามารถเปลี่ยนแสงเออร่า ลูกเล่นแอนิเมชัน ปรับแต่งชุดเงา AI หรืออัปโหลดรูปกรอบวงแหวนใหม่ได้ทันที`;
    }

    loadShadowConfigForFrame(f);
    updateAiPreview();
}

function resetAiStudioToNew() {
    document.getElementById('ai_editing_char_id').value = '0';
    const sel = document.getElementById('ai_edit_existing_select');
    if (sel) sel.value = '0';
    currentAiSourceImageObj = null;
    currentAiUploadedImageData = '';
    currentAiClearAvatarFlag = false;
    activeInspectedShadowSlot = null;
    document.getElementById('ai_frame_name').value = 'กรอบรูปเทพมังกรเพลิงมหาเวทย์ SS+';
    document.getElementById('ai_frame_grade').value = 'SS+';
    document.getElementById('ai_frame_aura').value = 'orange';
    document.getElementById('ai_frame_fx').value = 'spin_pulse';
    document.getElementById('ai_frame_intensity').value = 100;
    if (document.getElementById('ai_frame_intensity_num')) document.getElementById('ai_frame_intensity_num').value = 100;
    document.getElementById('ai_intensity_label').innerText = '100%';
    document.getElementById('ai_frame_scale').value = 122;
    document.getElementById('ai_frame_scale_label').innerText = '122%';
    document.getElementById('ai_inner_cut').value = 56;
    document.getElementById('ai_inner_cut_label').innerText = '56%';
    document.getElementById('ai_bg_tol').value = 45;
    document.getElementById('ai_bg_tol_label').innerText = '45';
    document.getElementById('ai_analysis_status').style.display = 'none';
    const clearBtn = document.getElementById('btn_clear_ai_ring');
    if (clearBtn) clearBtn.style.display = 'none';
    const btnSave = document.getElementById('btn-save-ai-frame');
    if (btnSave) btnSave.innerText = '💾 บันทึกเป็นกรอบรูปกิจกรรมใหม่ลงฐานข้อมูล';
    resetAiShadowStudioDefaults(false);
    updateAiPreview();
}

function clearAiRingImage() {
    currentAiSourceImageObj = null;
    currentAiUploadedImageData = '';
    currentAiClearAvatarFlag = true;
    const clearBtn = document.getElementById('btn_clear_ai_ring');
    if (clearBtn) clearBtn.style.display = 'none';
    const fileInput = document.getElementById('ai_image_input');
    if (fileInput) fileInput.value = '';
    updateAiPreview();
}

function setAiPreviewCenterMode(mode) {
    currentAiCenterMode = mode;
    const btnRing = document.getElementById('btn_prev_mode_ring');
    const btnAv = document.getElementById('btn_prev_mode_avatar');
    if (btnRing && btnAv) {
        if (mode === 'ring_only') {
            btnRing.style.background = 'var(--primary)';
            btnRing.style.color = '#000';
            btnRing.style.fontWeight = '700';
            btnAv.style.background = 'transparent';
            btnAv.style.color = '#cbd5e1';
            btnAv.style.fontWeight = '400';
        } else {
            btnAv.style.background = 'var(--primary)';
            btnAv.style.color = '#000';
            btnAv.style.fontWeight = '700';
            btnRing.style.background = 'transparent';
            btnRing.style.color = '#cbd5e1';
            btnRing.style.fontWeight = '400';
        }
    }
    updateAiPreview();
}

function handleAiImageSelect(e) {
    const file = e.target.files[0];
    if (file) processAiImage(file);
}

/**
 * สกัดเฉพาะเส้นกรอบวงแหวน (Hollow Ring Frame Extractor):
 * 1) ลบพื้นหลังตารางหมากรุก (Checkerboard) หรือพื้นสีขาว/เทาจากขอบนอกทั้ง 4 ด้าน และจากจุดศูนย์กลางด้วย Flood-Fill
 *    โดยคงสีขาวนีออนที่อยู่ด้านในตัวเส้นกรอบไว้ครบถ้วน
 * 2) ครอบตัดหาจุดกึ่งกลางของวงแหวนอัตโนมัติ (Auto-Center Bounding Box)
 * 3) เจาะรูวงกลมตรงกลาง (Inner Hole Cutout) + ตัดมุมนอกวงกลม ส่งออกเป็น PNG โปร่งใส 100%
 */
function extractHollowRingPng(img, opts = {}) {
    const removeBg = opts.removeBg !== false;
    const innerCutPct = opts.innerCutPct !== undefined ? Number(opts.innerCutPct) : 56;
    const bgTol = opts.bgTol !== undefined ? Number(opts.bgTol) : 45;

    const workSize = 320;
    const srcCanvas = document.createElement('canvas');
    const sCtx = srcCanvas.getContext('2d');
    let sw = img.width, sh = img.height;
    const maxSrc = 360;
    if (sw > sh && sw > maxSrc) { sh = Math.max(1, Math.round(sh * maxSrc / sw)); sw = maxSrc; }
    else if (sh >= sw && sh > maxSrc) { sw = Math.max(1, Math.round(sw * maxSrc / sh)); sh = maxSrc; }
    srcCanvas.width = sw;
    srcCanvas.height = sh;
    sCtx.clearRect(0, 0, sw, sh);
    sCtx.drawImage(img, 0, 0, sw, sh);

    const imgDataObj = sCtx.getImageData(0, 0, sw, sh);
    const data = imgDataObj.data;

    if (removeBg) {
        // Sample corner & center background palette (catches white/grey checkerboard or solid dark/light bg)
        const sampleCoords = [
            [0, 0], [sw - 1, 0], [0, sh - 1], [sw - 1, sh - 1],
            [Math.min(sw - 1, 8), Math.min(sh - 1, 8)],
            [Math.max(0, sw - 9), Math.min(sh - 1, 8)],
            [Math.floor(sw / 2), Math.floor(sh / 2)],
            [Math.floor(sw / 2) + Math.min(10, Math.floor(sw / 8)), Math.floor(sh / 2)]
        ];
        const bgPalette = [];
        sampleCoords.forEach(([sx, sy]) => {
            const idx = (sy * sw + sx) * 4;
            if (data[idx + 3] > 20) {
                bgPalette.push([data[idx], data[idx + 1], data[idx + 2]]);
            }
        });

        const isBgPixel = (pIdx) => {
            const a = data[pIdx + 3];
            if (a < 25) return true;
            const r = data[pIdx], g = data[pIdx + 1], b = data[pIdx + 2];
            const maxC = Math.max(r, g, b), minC = Math.min(r, g, b);
            const sat = maxC - minC;

            // Neutral white / light-grey checkerboard squares
            if (sat <= Math.min(34, bgTol * 0.65) && minC >= (245 - bgTol * 1.45)) {
                return true;
            }
            // Match sampled corner/center background colors
            for (let k = 0; k < bgPalette.length; k++) {
                const [br, bg, bb] = bgPalette[k];
                const bSat = Math.max(br, bg, bb) - Math.min(br, bg, bb);
                if (bSat < 32) {
                    const dist = Math.abs(r - br) + Math.abs(g - bg) + Math.abs(b - bb);
                    if (dist <= bgTol * 1.65 && sat <= Math.max(30, bgTol * 0.7)) {
                        return true;
                    }
                }
            }
            return false;
        };

        // Flood-fill from all 4 outer borders + small center seed patch
        const totalPx = sw * sh;
        const visited = new Uint8Array(totalPx);
        const queue = new Int32Array(totalPx);
        let qHead = 0, qTail = 0;

        const trySeed = (x, y) => {
            if (x < 0 || x >= sw || y < 0 || y >= sh) return;
            const pos = y * sw + x;
            if (visited[pos]) return;
            if (isBgPixel(pos * 4)) {
                visited[pos] = 1;
                queue[qTail++] = pos;
            }
        };

        for (let x = 0; x < sw; x++) { trySeed(x, 0); trySeed(x, sh - 1); }
        for (let y = 0; y < sh; y++) { trySeed(0, y); trySeed(sw - 1, y); }

        // Seed center hole so checkerboard inside the ring is also flood-filled cleanly!
        const cxSeed = Math.floor(sw / 2), cySeed = Math.floor(sh / 2);
        const seedRad = Math.max(3, Math.floor(Math.min(sw, sh) * 0.14));
        for (let dy = -seedRad; dy <= seedRad; dy += 2) {
            for (let dx = -seedRad; dx <= seedRad; dx += 2) {
                if (dx * dx + dy * dy <= seedRad * seedRad) {
                    trySeed(cxSeed + dx, cySeed + dy);
                }
            }
        }

        while (qHead < qTail) {
            const curr = queue[qHead++];
            data[curr * 4 + 3] = 0;
            const cx = curr % sw;
            const cy = (curr - cx) / sw;

            if (cx > 0) trySeed(cx - 1, cy);
            if (cx + 1 < sw) trySeed(cx + 1, cy);
            if (cy > 0) trySeed(cx, cy - 1);
            if (cy + 1 < sh) trySeed(cx, cy + 1);
        }

        // Soft anti-alias feather along transparent boundary
        const alphaCopy = new Uint8Array(totalPx);
        for (let p = 0; p < totalPx; p++) alphaCopy[p] = data[p * 4 + 3];
        for (let y = 1; y < sh - 1; y++) {
            for (let x = 1; x < sw - 1; x++) {
                const p = y * sw + x;
                if (alphaCopy[p] === 0) continue;
                let zeroNeighbors = 0;
                if (alphaCopy[p - 1] === 0) zeroNeighbors++;
                if (alphaCopy[p + 1] === 0) zeroNeighbors++;
                if (alphaCopy[p - sw] === 0) zeroNeighbors++;
                if (alphaCopy[p + sw] === 0) zeroNeighbors++;
                if (zeroNeighbors >= 2) {
                    data[p * 4 + 3] = Math.round(alphaCopy[p] * 0.65);
                }
            }
        }
        sCtx.putImageData(imgDataObj, 0, 0);
    }

    // Auto-detect bounding box of remaining ring pixels so ring is centered!
    let minX = sw, minY = sh, maxX = 0, maxY = 0, foundVisible = false;
    for (let y = 0; y < sh; y++) {
        for (let x = 0; x < sw; x++) {
            if (data[(y * sw + x) * 4 + 3] > 25) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                foundVisible = true;
            }
        }
    }
    if (!foundVisible) { minX = 0; minY = 0; maxX = sw - 1; maxY = sh - 1; }

    const cropW = Math.max(16, maxX - minX + 1);
    const cropH = Math.max(16, maxY - minY + 1);
    const cropSize = Math.max(cropW, cropH);
    const cropCx = (minX + maxX) / 2;
    const cropCy = (minY + maxY) / 2;

    const outCanvas = document.createElement('canvas');
    outCanvas.width = workSize;
    outCanvas.height = workSize;
    const oCtx = outCanvas.getContext('2d');
    const pad = 6;
    const drawSpan = workSize - pad * 2;
    const scaleFactor = drawSpan / cropSize;

    oCtx.clearRect(0, 0, workSize, workSize);
    oCtx.drawImage(
        srcCanvas,
        cropCx - cropSize / 2, cropCy - cropSize / 2, cropSize, cropSize,
        pad, pad, drawSpan, drawSpan
    );

    // Apply circular outer trim + inner hollow cutout mask
    const outImg = oCtx.getImageData(0, 0, workSize, workSize);
    const oData = outImg.data;
    const half = workSize / 2;
    const outerRadius = half - 2;
    const innerRadius = (innerCutPct / 100) * outerRadius;
    const feather = 4.0;

    // Also analyze dominant color hue of the ring pixels!
    const hueBuckets = new Array(36).fill(0);
    let ringPxCount = 0;

    for (let y = 0; y < workSize; y++) {
        for (let x = 0; x < workSize; x++) {
            const idx = (y * workSize + x) * 4;
            let a = oData[idx + 3];
            if (a === 0) continue;

            const dx = x - half + 0.5;
            const dy = y - half + 0.5;
            const rDist = Math.sqrt(dx * dx + dy * dy);

            if (rDist > outerRadius) {
                a = 0;
            } else if (rDist > outerRadius - feather) {
                a = Math.round(a * ((outerRadius - rDist) / feather));
            } else if (innerRadius > 0 && rDist < innerRadius) {
                if (rDist < innerRadius - feather) {
                    a = 0;
                } else {
                    a = Math.round(a * ((rDist - (innerRadius - feather)) / feather));
                }
            }
            oData[idx + 3] = a;

            if (a > 90) {
                const rr = oData[idx] / 255, gg = oData[idx + 1] / 255, bb = oData[idx + 2] / 255;
                const maxC = Math.max(rr, gg, bb), minC = Math.min(rr, gg, bb);
                if (maxC - minC > 0.14) {
                    const d = maxC - minC;
                    let hue = 0;
                    if (maxC === rr) hue = ((gg - bb) / d + (gg < bb ? 6 : 0)) * 60;
                    else if (maxC === gg) hue = ((bb - rr) / d + 2) * 60;
                    else hue = ((rr - gg) / d + 4) * 60;
                    hueBuckets[Math.floor(hue / 10) % 36]++;
                    ringPxCount++;
                }
            }
        }
    }
    oCtx.putImageData(outImg, 0, 0);

    let dominantBucket = 0, maxB = 0;
    for (let b = 0; b < 36; b++) {
        if (hueBuckets[b] > maxB) { maxB = hueBuckets[b]; dominantBucket = b; }
    }
    const dominantHue = dominantBucket * 10 + 5;

    return {
        pngDataUrl: outCanvas.toDataURL('image/png'),
        dominantHue,
        hasColoredRing: ringPxCount > 30
    };
}

function onAiRingParamChange() {
    const innerVal = document.getElementById('ai_inner_cut')?.value || 56;
    const tolVal = document.getElementById('ai_bg_tol')?.value || 45;
    if (document.getElementById('ai_inner_cut_label')) document.getElementById('ai_inner_cut_label').innerText = innerVal + '%';
    if (document.getElementById('ai_bg_tol_label')) document.getElementById('ai_bg_tol_label').innerText = tolVal;
    reprocessCurrentAiRing();
}

function reprocessCurrentAiRing() {
    if (!currentAiSourceImageObj) {
        updateAiPreview();
        return;
    }
    const removeBg = document.getElementById('ai_auto_remove_bg')?.checked !== false;
    const innerCutPct = parseInt(document.getElementById('ai_inner_cut')?.value ?? '56');
    const bgTol = parseInt(document.getElementById('ai_bg_tol')?.value ?? '45');

    const extracted = extractHollowRingPng(currentAiSourceImageObj, { removeBg, innerCutPct, bgTol });
    currentAiUploadedImageData = extracted.pngDataUrl;
    currentAiClearAvatarFlag = false;
    regenerateAllShadowPngsFromRing();
    updateAiPreview();
}

function processAiImage(file) {
    if (!file.type.startsWith('image/')) {
        alert('กรุณาเลือกไฟล์รูปภาพที่ถูกต้อง (PNG, JPG, WEBP)');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(evt) {
        const img = new Image();
        img.onload = function() {
            currentAiSourceImageObj = img;
            const removeBg = document.getElementById('ai_auto_remove_bg')?.checked !== false;
            const innerCutPct = parseInt(document.getElementById('ai_inner_cut')?.value ?? '56');
            const bgTol = parseInt(document.getElementById('ai_bg_tol')?.value ?? '45');

            const extracted = extractHollowRingPng(img, { removeBg, innerCutPct, bgTol });
            currentAiUploadedImageData = extracted.pngDataUrl;
            currentAiClearAvatarFlag = false;

            const clearBtn = document.getElementById('btn_clear_ai_ring');
            if (clearBtn) clearBtn.style.display = 'inline-block';

            const dominantHue = extracted.dominantHue;
            const editingId = parseInt(document.getElementById('ai_editing_char_id')?.value || '0');

            // Auto-recommend Aura, Color & FX based on ring color!
            let chosenAura = 'orange';
            let chosenHex = '#ff6600';
            let chosenFx = 'spin_pulse';

            if (dominantHue < 12 || dominantHue >= 340) {
                chosenAura = 'crimson';
                chosenHex = '#ef4444';
                chosenFx = 'spin_pulse';
                currentAiColorTone = 'crimson';
            } else if (dominantHue >= 12 && dominantHue <= 38) {
                chosenAura = 'orange';
                chosenHex = '#ff6600';
                chosenFx = 'flame_halo';
                currentAiColorTone = 'orange';
            } else if (dominantHue > 38 && dominantHue <= 65) {
                chosenAura = 'gold';
                chosenHex = '#ffd700';
                chosenFx = 'reverse_dual';
                currentAiColorTone = 'gold';
            } else if (dominantHue > 65 && dominantHue <= 95) {
                chosenAura = 'yellow';
                chosenHex = '#facc15';
                chosenFx = 'electric_orbit';
                currentAiColorTone = 'yellow';
            } else if (dominantHue >= 165 && dominantHue <= 250) {
                chosenAura = 'cyan';
                chosenHex = '#00e5ff';
                chosenFx = 'spin_pulse';
                currentAiColorTone = 'cyan';
            } else if (dominantHue > 250 && dominantHue < 340) {
                chosenAura = 'purple';
                chosenHex = '#a855f7';
                chosenFx = 'reverse_dual';
                currentAiColorTone = 'purple';
            }

            document.getElementById('ai_frame_aura').value = chosenAura;
            document.getElementById('ai_frame_fx').value = chosenFx;
            if (editingId <= 0) {
                document.getElementById('ai_frame_intensity').value = 100;
                if (document.getElementById('ai_frame_intensity_num')) document.getElementById('ai_frame_intensity_num').value = 100;
                document.getElementById('ai_intensity_label').innerText = '100%';
            }
            document.getElementById('ai_frame_color').value = chosenHex;

            if (editingId <= 0) {
                document.getElementById('ai_frame_grade').value = 'SS+';
                document.getElementById('ai_frame_win').value = 85.0;
                document.getElementById('ai_frame_roll').value = 90.0;
                document.getElementById('ai_frame_skill').value = 45;
                regenerateAiTitle();
            }

            const statusBox = document.getElementById('ai_analysis_status');
            if (statusBox) {
                statusBox.style.display = 'block';
                statusBox.innerHTML = '✨ AI สกัดเฉพาะ <strong>ส่วนของกรอบวงแหวนโปร่งใส</strong> + วิเคราะห์สร้าง <strong>ชุดเงาวงแหวนทั้ง 5 ระดับ</strong> จากรูปที่อัปโหลดให้อัตโนมัติแล้ว!';
            }

            regenerateAllShadowPngsFromRing();
            updateAiPreview();
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
}

function regenerateAiTitle() {
    const titlesByTone = {
        crimson: ['จักรพรรดิโลหิตอัคคีแดง', 'วงแหวนเพลิงชาดมหาเวทย์', 'ราชันย์เนตรเพลิงสุริยัน', 'พญามังกรแดงผ่าสวรรค์'],
        orange: ['พญาราชสีห์เพลิงสุริยัน', 'วิหคอัคนีเพลิงส้มมหาเวทย์', 'จักรพรรดิอัคคีเพลิงสุริยะ', 'พญานาคินทร์เพลิงผลาญ'],
        gold: ['เทพมังกรทองนาคราช', 'จักรพรรดิทองคำนิรันดร์', 'บารมีอนันตนาคราช', 'มหาเทพสุวรรณภูมิวิเศษ'],
        yellow: ['พญาหงส์เพลิงมหาเวทย์', 'เทพราชสีห์ทอประกายเรืองรอง', 'รัศมีมงคลจักรีมหาบารมี'],
        cyan: ['พยัคฆ์สายฟ้าวายุจักรพรรดิ', 'มังกรสมุทรครามมรกต', 'เทวะวารีพิโรธมหาอำนาจ'],
        purple: ['จอมเวทย์ดาราจักรเนบิวลา', 'จักรพรรดิเงาม่วงอนันตกาล', 'วงแหวนมิติรัตติกาลสวรรค์'],
        rainbow: ['มหาเทพปริซึมเจ็ดดารา', 'จักรพรรดิรุ้งสวรรค์นิรันดร์'],
        white: ['พญาหงส์ขาวนีออนบริสุทธิ์', 'มหาเทพแสงศักดิ์สิทธิ์สวรรค์']
    };

    const grade = document.getElementById('ai_frame_grade').value || 'SS+';
    const aura = document.getElementById('ai_frame_aura').value || 'orange';
    const list = titlesByTone[aura] || titlesByTone['orange'];
    const chosen = list[Math.floor(Math.random() * list.length)];
    document.getElementById('ai_frame_name').value = `${chosen} ${grade}`;
    updateAiPreview();
}

function updateAiIntensity(val) {
    const clamped = Math.max(10, Math.min(500, parseInt(val) || 100));
    const rangeEl = document.getElementById('ai_frame_intensity');
    const numEl = document.getElementById('ai_frame_intensity_num');
    const lblEl = document.getElementById('ai_intensity_label');
    if (rangeEl && parseInt(rangeEl.value) !== clamped) rangeEl.value = clamped;
    if (numEl && document.activeElement !== numEl) numEl.value = clamped;
    if (lblEl) lblEl.innerText = clamped + '%';
    updateAiPreview();
}

// =========================================================================
// 🌑 AI SHADOW RING SYNTHESIZER & MULTI-GRADE EXCHANGE (SS+ / S+ / S)
// =========================================================================
let activeInspectedShadowSlot = null;

function getDefaultAiShadowsState() {
    return [
        { slot: 'black',  code: 'SHADOW_BLACK_A',     name: 'เงาทมิฬ A',     grade: 'A',  color: '#64748b', aura: 'white',   intensity: 65,  rate: 90.0, image_url: '' },
        { slot: 'red',    code: 'SHADOW_RED_A',       name: 'เงาโลหิต A',     grade: 'A',  color: '#ef4444', aura: 'crimson', intensity: 90,  rate: 80.0, image_url: '' },
        { slot: 'orange', code: 'SHADOW_ORANGE_A',    name: 'เงาอัคคี A',     grade: 'A',  color: '#ff7b00', aura: 'orange',  intensity: 100, rate: 70.0, image_url: '' },
        { slot: 'blue',   code: 'SHADOW_BLUE_APLUS',  name: 'เงาวารีฟ้า A+',  grade: 'A+', color: '#38bdf8', aura: 'cyan',    intensity: 120, rate: 50.0, image_url: '' },
        { slot: 'gold',   code: 'SHADOW_GOLD_S',      name: 'เงาสุวรรณทอง S', grade: 'S',  color: '#ffd700', aura: 'gold',    intensity: 150, rate: 10.0, image_url: '' }
    ];
}

function getDefaultAiExchangeTiersState() {
    return {
        'SS+': { enabled: true, character_id: -1, reqs: { black: 25, red: 25, orange: 20, blue: 15, gold: 8 } },
        'S+':  { enabled: true, character_id: 0,  reqs: { black: 15, red: 15, orange: 15, blue: 10, gold: 4 } },
        'S':   { enabled: true, character_id: 0,  reqs: { black: 10, red: 10, orange: 8,  blue: 5,  gold: 2 } }
    };
}

let aiShadowsState = getDefaultAiShadowsState();
let aiExchangeTiersState = getDefaultAiExchangeTiersState();

function hexToRgbTuple(hex) {
    const clean = String(hex || '#38bdf8').replace('#', '').trim();
    const full = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean.padEnd(6, '0');
    const n = parseInt(full.substring(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function drawFallbackProceduralRing(ctx, size) {
    const cx = size / 2, cy = size / 2;
    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.translate(cx, cy);

    // Outer ornate ring
    const grad = ctx.createRadialGradient(0, 0, size * 0.30, 0, 0, size * 0.48);
    grad.addColorStop(0, 'rgba(30,41,59,0)');
    grad.addColorStop(0.18, 'rgba(255,255,255,0.95)');
    grad.addColorStop(0.55, 'rgba(148,163,184,0.75)');
    grad.addColorStop(0.88, 'rgba(255,255,255,0.98)');
    grad.addColorStop(1, 'rgba(15,23,42,0)');

    ctx.beginPath();
    ctx.arc(0, 0, size * 0.46, 0, Math.PI * 2);
    ctx.arc(0, 0, size * 0.32, 0, Math.PI * 2, true);
    ctx.fillStyle = grad;
    ctx.fill();

    // Ornamental crests around the ring
    for (let i = 0; i < 12; i++) {
        ctx.save();
        ctx.rotate((Math.PI * 2 * i) / 12);
        ctx.beginPath();
        ctx.moveTo(0, -size * 0.49);
        ctx.lineTo(size * 0.045, -size * 0.39);
        ctx.lineTo(0, -size * 0.34);
        ctx.lineTo(-size * 0.045, -size * 0.39);
        ctx.closePath();
        ctx.fillStyle = i % 3 === 0 ? '#ffffff' : 'rgba(203,213,225,0.85)';
        ctx.fill();
        ctx.restore();
    }
    ctx.restore();
}

/**
 * ถอดลวดลายและโครงสร้างขอบแสงจากรูปกรอบที่อัปโหลด แล้วสร้างเป็นรูปเงาวงแหวนสุดเท่ตามสีเงาที่กำหนด
 */
function synthesizeShadowRingDataUrl(sourceImgElement, shadowHex, grade = 'A') {
    const size = 112;
    const srcCanvas = document.createElement('canvas');
    srcCanvas.width = size;
    srcCanvas.height = size;
    const sCtx = srcCanvas.getContext('2d');

    if (sourceImgElement && sourceImgElement.complete && sourceImgElement.naturalWidth > 0) {
        sCtx.drawImage(sourceImgElement, 0, 0, size, size);
    } else {
        drawFallbackProceduralRing(sCtx, size);
    }

    const srcData = sCtx.getImageData(0, 0, size, size);
    const px = srcData.data;
    const outImg = sCtx.createImageData(size, size);
    const out = outImg.data;

    const [tr, tg, tb] = hexToRgbTuple(shadowHex);
    const gradeBoost = grade === 'SS+' ? 1.35 : (grade === 'S+' ? 1.25 : (grade === 'S' ? 1.18 : (grade === 'A+' ? 1.08 : 0.95)));

    // Precompute luminance & alpha for edge detection so every dragon scale / ornament glows in shadow style!
    const lumArr = new Float32Array(size * size);
    const alphaArr = new Uint8Array(size * size);
    for (let i = 0; i < size * size; i++) {
        const p = i * 4;
        alphaArr[i] = px[p + 3];
        lumArr[i] = (0.299 * px[p] + 0.587 * px[p + 1] + 0.114 * px[p + 2]) / 255;
    }

    for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
            const idx = y * size + x;
            const a = alphaArr[idx];
            if (a < 8) continue;

            const lum = lumArr[idx];
            // Detect silhouette contour + internal ornament edges
            let edgeStrength = 0;
            if (x > 0 && x < size - 1 && y > 0 && y < size - 1) {
                const aDiff = (
                    Math.abs(a - alphaArr[idx - 1]) +
                    Math.abs(a - alphaArr[idx + 1]) +
                    Math.abs(a - alphaArr[idx - size]) +
                    Math.abs(a - alphaArr[idx + size])
                ) / (255 * 2.2);
                const lDiff = (
                    Math.abs(lum - lumArr[idx - 1]) +
                    Math.abs(lum - lumArr[idx + 1]) +
                    Math.abs(lum - lumArr[idx - size]) +
                    Math.abs(lum - lumArr[idx + size])
                ) * 1.45;
                edgeStrength = Math.min(1.0, aDiff * 0.9 + lDiff);
            }

            // Deep dark shadow core + glowing colored rim & specular veins matching the uploaded frame!
            const shadowCore = 0.08 + Math.pow(lum, 1.65) * 0.28;
            const rimGlow = Math.min(1.35, (edgeStrength * 0.88 + Math.pow(lum, 2.4) * 0.62) * gradeBoost);

            const rOut = Math.min(255, Math.round(10 * (1 - shadowCore) + tr * (shadowCore * 0.55 + rimGlow * 0.95) + (rimGlow > 0.92 ? (rimGlow - 0.92) * 180 : 0)));
            const gOut = Math.min(255, Math.round(14 * (1 - shadowCore) + tg * (shadowCore * 0.55 + rimGlow * 0.95) + (rimGlow > 0.92 ? (rimGlow - 0.92) * 180 : 0)));
            const bOut = Math.min(255, Math.round(24 * (1 - shadowCore) + tb * (shadowCore * 0.55 + rimGlow * 0.95) + (rimGlow > 0.92 ? (rimGlow - 0.92) * 180 : 0)));

            const p = idx * 4;
            out[p] = rOut;
            out[p + 1] = gOut;
            out[p + 2] = bOut;
            out[p + 3] = Math.min(255, Math.round(a * 0.96));
        }
    }

    // Compose onto final canvas with soft outer mystical shadow aura
    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = size;
    finalCanvas.height = size;
    const fCtx = finalCanvas.getContext('2d');

    sCtx.putImageData(outImg, 0, 0);
    fCtx.save();
    fCtx.shadowColor = shadowHex;
    fCtx.shadowBlur = grade === 'S' || grade === 'S+' || grade === 'SS+' ? 10 : 6;
    fCtx.drawImage(srcCanvas, 0, 0);
    fCtx.restore();
    fCtx.drawImage(srcCanvas, 0, 0);

    return finalCanvas.toDataURL('image/png');
}

function regenerateAllShadowPngsFromRing(callback) {
    if (currentAiUploadedImageData) {
        const ringImg = new Image();
        ringImg.onload = function() {
            aiShadowsState.forEach(s => {
                s.image_url = synthesizeShadowRingDataUrl(ringImg, s.color, s.grade);
            });
            renderAiShadowMiniGallery();
            renderAiShadowCardsEditor();
            if (activeInspectedShadowSlot) updateAiPreview();
            if (typeof callback === 'function') callback();
        };
        ringImg.src = currentAiUploadedImageData;
    } else {
        aiShadowsState.forEach(s => {
            s.image_url = synthesizeShadowRingDataUrl(null, s.color, s.grade);
        });
        renderAiShadowMiniGallery();
        renderAiShadowCardsEditor();
        if (activeInspectedShadowSlot) updateAiPreview();
        if (typeof callback === 'function') callback();
    }
}

function regenerateSingleShadowPng(slotIndex) {
    const s = aiShadowsState[slotIndex];
    if (!s) return;
    if (currentAiUploadedImageData) {
        const ringImg = new Image();
        ringImg.onload = function() {
            s.image_url = synthesizeShadowRingDataUrl(ringImg, s.color, s.grade);
            renderAiShadowMiniGallery();
            updateShadowCardPreviewDom(slotIndex);
            if (activeInspectedShadowSlot === s.slot) updateAiPreview();
        };
        ringImg.src = currentAiUploadedImageData;
    } else {
        s.image_url = synthesizeShadowRingDataUrl(null, s.color, s.grade);
        renderAiShadowMiniGallery();
        updateShadowCardPreviewDom(slotIndex);
        if (activeInspectedShadowSlot === s.slot) updateAiPreview();
    }
}

function autoAnalyzeShadowsFromRing() {
    const baseName = (document.getElementById('ai_frame_name')?.value || 'กรอบเทพ').replace(/\s*(SS\+|S\+|S|A\+|A)$/i, '').trim();
    const shortTitle = baseName.length > 14 ? baseName.substring(0, 14) : baseName;
    const mainHex = document.getElementById('ai_frame_color')?.value || '#ff6600';

    const presets = [
        { color: '#64748b', aura: 'white',   grade: 'A',  intensity: 70,  rate: 90.0, suffix: 'เงาทมิฬ' },
        { color: '#ef4444', aura: 'crimson', grade: 'A',  intensity: 95,  rate: 80.0, suffix: 'เงาโลหิต' },
        { color: mainHex,   aura: 'orange',  grade: 'A',  intensity: 110, rate: 70.0, suffix: 'เงาอัคคี' },
        { color: '#38bdf8', aura: 'cyan',    grade: 'A+', intensity: 135, rate: 50.0, suffix: 'เงาวารีฟ้า' },
        { color: '#ffd700', aura: 'gold',    grade: 'S',  intensity: 175, rate: 10.0, suffix: 'เงาสุวรรณทอง' }
    ];

    aiShadowsState.forEach((s, idx) => {
        const p = presets[idx];
        s.name = `${p.suffix} (${shortTitle}) ${p.grade}`;
        s.grade = p.grade;
        s.color = p.color;
        s.aura = p.aura;
        s.intensity = p.intensity;
        s.rate = p.rate;
    });

    regenerateAllShadowPngsFromRing(() => {
        showToast('✨ AI วิเคราะห์ลวดลายกรอบและสร้างชุดเงาทั้ง 5 ระดับเรียบร้อยแล้ว!');
    });
}

function resetAiShadowStudioDefaults(showMsg = true) {
    aiShadowsState = getDefaultAiShadowsState();
    aiExchangeTiersState = getDefaultAiExchangeTiersState();
    activeInspectedShadowSlot = null;
    regenerateAllShadowPngsFromRing();
    renderAiExchangeTiersEditor();
    if (showMsg) showToast('🔄 รีเซ็ตชุดเงาและอัตราแลกกรอบเป็นค่าเริ่มต้นแล้ว');
}

function loadShadowConfigForFrame(frameObj) {
    activeInspectedShadowSlot = null;
    let loaded = false;
    if (frameObj && frameObj.shadow_config_json) {
        try {
            const parsed = JSON.parse(frameObj.shadow_config_json);
            if (parsed && Array.isArray(parsed.shadows) && parsed.shadows.length > 0) {
                const defaults = getDefaultAiShadowsState();
                aiShadowsState = defaults.map((def, idx) => ({
                    ...def,
                    ...(parsed.shadows[idx] || {})
                }));
                loaded = true;
            }
            if (parsed && parsed.tiers && typeof parsed.tiers === 'object') {
                const defTiers = getDefaultAiExchangeTiersState();
                ['SS+', 'S+', 'S'].forEach(k => {
                    if (parsed.tiers[k]) {
                        defTiers[k] = {
                            enabled: parsed.tiers[k].enabled !== false,
                            character_id: parseInt(parsed.tiers[k].character_id ?? 0),
                            reqs: { ...defTiers[k].reqs, ...(parsed.tiers[k].reqs || {}) }
                        };
                    }
                });
                aiExchangeTiersState = defTiers;
            }
        } catch (e) {
            console.warn('parse frame shadow_config_json warning:', e);
        }
    }

    if (!loaded && window.adminGachaEventCache) {
        try {
            const ev = window.adminGachaEventCache;
            if (ev.shadow_config_json) {
                const evShadows = JSON.parse(ev.shadow_config_json);
                if (Array.isArray(evShadows) && evShadows.length > 0) {
                    const defaults = getDefaultAiShadowsState();
                    aiShadowsState = defaults.map((def, idx) => ({ ...def, ...(evShadows[idx] || {}) }));
                    loaded = true;
                }
            }
            if (ev.exchange_tiers_json) {
                const evTiers = JSON.parse(ev.exchange_tiers_json);
                const defTiers = getDefaultAiExchangeTiersState();
                ['SS+', 'S+', 'S'].forEach(k => {
                    if (evTiers && evTiers[k]) {
                        defTiers[k] = {
                            enabled: evTiers[k].enabled !== false,
                            character_id: parseInt(evTiers[k].character_id ?? 0),
                            reqs: { ...defTiers[k].reqs, ...(evTiers[k].reqs || {}) }
                        };
                    }
                });
                aiExchangeTiersState = defTiers;
            }
        } catch (e) {}
    }

    regenerateAllShadowPngsFromRing();
    renderAiExchangeTiersEditor();
}

function getShadowAuraBoxStyle(aura, colorHex, intensity = 100, sizePx = 56) {
    const scale = Math.max(0.15, Math.min(5.0, (parseInt(intensity) || 100) / 100));
    const auraColors = {
        white: '#ffffff',
        cyan: '#00e5ff',
        orange: '#ff5500',
        crimson: '#ef4444',
        purple: '#a855f7',
        yellow: '#facc15',
        gold: '#ffd700',
        rainbow: '#38bdf8'
    };
    const glow = aura === 'none' ? 'transparent' : (auraColors[aura] || colorHex || '#38bdf8');
    const b1 = Math.round(10 * scale);
    const b2 = Math.round(22 * scale);
    const shadowCss = aura === 'none'
        ? 'box-shadow: inset 0 0 10px rgba(0,0,0,0.85);'
        : `box-shadow: 0 0 ${b1}px ${glow}, 0 0 ${b2}px ${glow}88, inset 0 0 10px rgba(0,0,0,0.85);`;
    return `width:${sizePx}px; height:${sizePx}px; border-radius:50%; background:radial-gradient(circle, rgba(15,23,42,0.5) 0%, #050811 80%); border:1.5px solid ${colorHex}88; display:flex; align-items:center; justify-content:center; position:relative; ${shadowCss}`;
}

function renderAiShadowMiniGallery() {
    const box = document.getElementById('ai_shadow_mini_gallery');
    if (!box) return;
    box.innerHTML = aiShadowsState.map((s, idx) => {
        const isInspected = activeInspectedShadowSlot === s.slot;
        return `
            <div onclick="inspectShadowOnMainStage('${s.slot}')" title="คลิกเพื่อดูตัวอย่างเงา ${s.name} บนแท่นใหญ่"
                style="cursor:pointer; background:${isInspected ? 'rgba(168,85,247,0.22)' : 'rgba(15,23,42,0.85)'}; border:1.5px solid ${isInspected ? '#c084fc' : s.color + '66'}; border-radius:10px; padding:8px 4px; text-align:center; transition:all 0.2s;">
                <div style="margin:0 auto 5px auto; ${getShadowAuraBoxStyle(s.aura, s.color, s.intensity, 46)}">
                    ${s.image_url ? `<img src="${s.image_url}" style="width:48px; height:48px; object-fit:contain; pointer-events:none;">` : ''}
                    <span style="position:absolute; bottom:-3px; right:-3px; background:${s.color}; color:#000; font-size:9px; font-weight:800; padding:0 4px; border-radius:6px;">${s.grade}</span>
                </div>
                <div style="font-size:10px; font-weight:700; color:#f8fafc; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${s.name}</div>
                <div style="font-size:10px; color:${s.color}; font-weight:700;">สุ่ม ${s.rate}%</div>
            </div>
        `;
    }).join('');
}

function updateShadowCardPreviewDom(idx) {
    const s = aiShadowsState[idx];
    if (!s) return;
    const wrap = document.getElementById(`ai_sh_prev_wrap_${idx}`);
    if (wrap) {
        wrap.setAttribute('style', getShadowAuraBoxStyle(s.aura, s.color, s.intensity, 64));
        const img = wrap.querySelector('img');
        if (img && s.image_url) img.src = s.image_url;
        const badge = wrap.querySelector('.sh-grade-pill');
        if (badge) {
            badge.style.background = s.color;
            badge.innerText = s.grade;
        }
    }
}

function onShadowFieldChange(idx, field, val) {
    const s = aiShadowsState[idx];
    if (!s) return;
    if (field === 'rate') {
        s.rate = Math.max(0, Math.min(100, parseFloat(val) || 0));
    } else if (field === 'intensity') {
        s.intensity = Math.max(10, Math.min(500, parseInt(val) || 100));
    } else {
        s[field] = val;
    }

    if (field === 'color' || field === 'grade') {
        regenerateSingleShadowPng(idx);
    } else {
        renderAiShadowMiniGallery();
        updateShadowCardPreviewDom(idx);
        if (activeInspectedShadowSlot === s.slot) updateAiPreview();
    }
    renderAiExchangeTiersEditor();
}

function renderAiShadowCardsEditor() {
    const container = document.getElementById('ai_shadow_cards_editor');
    if (!container) return;

    const auraOptions = [
        { v: 'none',    t: 'ไม่มีเออร่า' },
        { v: 'white',   t: 'ขาวบริสุทธิ์ ✨' },
        { v: 'cyan',    t: 'ฟ้านีออน 🌊' },
        { v: 'orange',  t: 'ส้มเพลิง 🔥' },
        { v: 'crimson', t: 'แดงโลหิต 🩸' },
        { v: 'purple',  t: 'ม่วงเงามืด 🔮' },
        { v: 'yellow',  t: 'เหลืองสายฟ้า ⚡' },
        { v: 'gold',    t: 'ทองสง่างาม 👑' },
        { v: 'rainbow', t: 'รุ้งปริซึม 🌈' }
    ];

    container.innerHTML = aiShadowsState.map((s, idx) => `
        <div style="background:rgba(15,23,42,0.82); border:1.5px solid ${s.color}66; border-radius:12px; padding:12px; display:flex; flex-direction:column; gap:8px;">
            <div style="display:flex; align-items:center; gap:10px;">
                <div id="ai_sh_prev_wrap_${idx}" onclick="inspectShadowOnMainStage('${s.slot}')" title="คลิกดูขยายบนแท่นพรีวิว"
                    style="cursor:pointer; flex-shrink:0; ${getShadowAuraBoxStyle(s.aura, s.color, s.intensity, 64)}">
                    ${s.image_url ? `<img src="${s.image_url}" style="width:66px; height:66px; object-fit:contain; pointer-events:none;">` : ''}
                    <span class="sh-grade-pill" style="position:absolute; bottom:-2px; right:-2px; background:${s.color}; color:#000; font-size:10px; font-weight:800; padding:1px 6px; border-radius:8px; border:1px solid #fff;">${s.grade}</span>
                </div>
                <div style="flex:1; min-width:0;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:3px;">
                        <span style="font-size:11px; color:#94a3b8; font-weight:700;">เงาช่องที่ ${idx + 1}</span>
                        <button type="button" onclick="inspectShadowOnMainStage('${s.slot}')" style="background:rgba(168,85,247,0.2); border:1px solid #a855f7; color:#e9d5ff; border-radius:6px; padding:1px 7px; font-size:10px; cursor:pointer;">🔍 ดูวงใหญ่</button>
                    </div>
                    <input type="text" value="${String(s.name || '').replace(/"/g, '&quot;')}" oninput="onShadowFieldChange(${idx}, 'name', this.value)"
                        style="width:100%; padding:5px 8px; font-size:12px; font-weight:700;" placeholder="ชื่อการ์ดเงา">
                </div>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:6px;">
                <div>
                    <label style="font-size:11px; color:#94a3b8; margin-bottom:2px;">เกรดเงา</label>
                    <select onchange="onShadowFieldChange(${idx}, 'grade', this.value)" style="padding:5px 6px; font-size:12px;">
                        <option value="A" ${s.grade==='A'?'selected':''}>เกรด A</option>
                        <option value="A+" ${s.grade==='A+'?'selected':''}>เกรด A+</option>
                        <option value="S" ${s.grade==='S'?'selected':''}>เกรด S</option>
                        <option value="S+" ${s.grade==='S+'?'selected':''}>เกรด S+</option>
                    </select>
                </div>
                <div>
                    <label style="font-size:11px; color:#94a3b8; margin-bottom:2px;">🎨 สีเงา (Hex)</label>
                    <div style="display:flex; align-items:center; gap:4px;">
                        <input type="color" value="${s.color}" oninput="onShadowFieldChange(${idx}, 'color', this.value)" style="width:38px; height:31px; padding:1px; cursor:pointer;">
                        <input type="text" value="${s.color}" onchange="onShadowFieldChange(${idx}, 'color', this.value)" style="flex:1; padding:5px 6px; font-size:11px;">
                    </div>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: 1.25fr 0.75fr; gap:6px;">
                <div>
                    <label style="font-size:11px; color:#94a3b8; margin-bottom:2px;">✨ แสงเออร่าเงา</label>
                    <select onchange="onShadowFieldChange(${idx}, 'aura', this.value)" style="padding:5px 6px; font-size:12px;">
                        ${auraOptions.map(o => `<option value="${o.v}" ${s.aura===o.v?'selected':''}>${o.t}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label style="font-size:11px; color:#94a3b8; margin-bottom:2px;">🔥 แสง (%)</label>
                    <input type="number" min="10" max="500" step="5" value="${s.intensity}" oninput="onShadowFieldChange(${idx}, 'intensity', this.value)" style="padding:5px 6px; font-size:12px;">
                </div>
            </div>

            <div style="background:rgba(2,6,23,0.55); border:1px solid rgba(255,255,255,0.08); border-radius:8px; padding:6px 8px; display:flex; justify-content:space-between; align-items:center;">
                <span style="font-size:11px; color:#38bdf8; font-weight:700;">🎲 อัตราสุ่มออก (%):</span>
                <div style="display:flex; align-items:center; gap:4px;">
                    <input type="number" min="0" max="100" step="0.5" value="${s.rate}" oninput="onShadowFieldChange(${idx}, 'rate', this.value)" style="width:68px; padding:4px 6px; font-size:12px; font-weight:700; text-align:right; color:#ffd700;">
                    <span style="font-size:12px; font-weight:700; color:#ffd700;">%</span>
                </div>
            </div>
        </div>
    `).join('');
}

function onExchangeTierChange(tierGrade, field, val, slotKey = '') {
    const t = aiExchangeTiersState[tierGrade];
    if (!t) return;
    if (field === 'enabled') {
        t.enabled = Boolean(val);
    } else if (field === 'character_id') {
        t.character_id = parseInt(val);
    } else if (field === 'req' && slotKey) {
        t.reqs[slotKey] = Math.max(0, parseInt(val) || 0);
    }
}

function renderAiExchangeTiersEditor() {
    const box = document.getElementById('ai_exchange_tiers_editor');
    if (!box) return;

    const tierMeta = [
        { key: 'SS+', badge: '👑 กรอบระดับ SS+', border: '#ffd700', bg: 'rgba(255,215,0,0.07)' },
        { key: 'S+',  badge: '🌟 กรอบระดับ S+',  border: '#f59e0b', bg: 'rgba(245,158,11,0.07)' },
        { key: 'S',   badge: '💎 กรอบระดับ S',   border: '#38bdf8', bg: 'rgba(56,189,248,0.07)' }
    ];

    const frames = Array.isArray(adminFramesCache) ? adminFramesCache : [];

    box.innerHTML = tierMeta.map(tm => {
        const st = aiExchangeTiersState[tm.key] || { enabled: true, character_id: 0, reqs: { black: 15, red: 15, orange: 15, blue: 10, gold: 4 } };
        const matchingFrames = frames.filter(f => String(f.grade).toUpperCase() === tm.key);
        const otherFrames = frames.filter(f => String(f.grade).toUpperCase() !== tm.key);

        let optionsHtml = `<option value="-1" ${st.character_id === -1 ? 'selected' : ''}>✨ ใช้กรอบที่กำลังสร้าง/แก้ไขในหน้านี้ทันที</option>`;
        optionsHtml += `<option value="0" ${st.character_id === 0 ? 'selected' : ''}>🎯 เลือกกรอบระดับ ${tm.key} อัตโนมัติ</option>`;
        if (matchingFrames.length > 0) {
            optionsHtml += matchingFrames.map(f => `<option value="${f.id}" ${parseInt(f.id) === st.character_id ? 'selected' : ''}>[${f.grade}] ${f.name}</option>`).join('');
        }
        if (otherFrames.length > 0) {
            optionsHtml += otherFrames.map(f => `<option value="${f.id}" ${parseInt(f.id) === st.character_id ? 'selected' : ''}>[${f.grade}] ${f.name}</option>`).join('');
        }

        const reqInputsHtml = aiShadowsState.map(s => {
            const countVal = st.reqs && st.reqs[s.slot] !== undefined ? st.reqs[s.slot] : 10;
            return `
                <div style="background:rgba(2,6,23,0.65); border:1px solid ${s.color}55; border-radius:8px; padding:6px 8px; min-width:110px; flex:1;">
                    <div style="font-size:11px; color:${s.color}; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${s.name}</div>
                    <div style="display:flex; align-items:center; gap:4px; margin-top:4px;">
                        <span style="font-size:11px; color:#94a3b8;">ใช้:</span>
                        <input type="number" min="0" max="999" value="${countVal}"
                            oninput="onExchangeTierChange('${tm.key}', 'req', this.value, '${s.slot}')"
                            style="width:100%; padding:4px 6px; font-size:12px; font-weight:700; text-align:center; color:#fff;">
                        <span style="font-size:11px; color:#94a3b8;">อัน</span>
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div style="background:${tm.bg}; border:1px solid ${tm.border}66; border-radius:12px; padding:12px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px;">
                    <label style="display:inline-flex; align-items:center; gap:8px; margin:0; cursor:pointer; font-weight:700; col
or:#fff;">
                        <input type="checkbox" ${st.enabled ? 'checked' : ''} onchange="onExchangeTierChange('${tm.key}', 'enabled', this.checked)">
                        <span>${tm.badge}</span>
                    </label>
                    <div style="display:flex; align-items:center; gap:8px; flex:1; max-width:340px;">
                        <span style="font-size:11px; color:#94a3b8; white-space:nowrap;">กรอบเป้าหมาย:</span>
                        <select onchange="onExchangeTierChange('${tm.key}', 'character_id', this.value)" style="width:100%; font-size:11px; padding:3px 6px;">
                            ${optionsHtml}
                        </select>
                    </div>
                </div>
                <div style="font-size:11px; color:#94a3b8; margin-bottom:6px;">วัตถุดิบเงาที่ใช้แลกกรอบนี้ (ครบ 5 ธาตุ):</div>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    ${reqInputsHtml}
                </div>
            </div>
        `;
    }).join('');
}

function inspectShadowOnMainStage(slotKey) {
    activeInspectedShadowSlot = slotKey;
    updateAiPreview();
}

function exitShadowStageInspect() {
    activeInspectedShadowSlot = null;
    updateAiPreview();
}

function collectAiShadowBundle() {
    return {
        shadows: aiShadowsState,
        tiers: aiExchangeTiersState
    };
}

function updateAiPreview() {
    const inspectedShadow = (typeof activeInspectedShadowSlot !== 'undefined' && activeInspectedShadowSlot)
        ? aiShadowsState.find(s => s.slot === activeInspectedShadowSlot)
        : null;

    const bannerEl = document.getElementById('ai_stage_shadow_banner');
    const bannerTxt = document.getElementById('ai_stage_shadow_banner_text');
    if (bannerEl) {
        if (inspectedShadow) {
            bannerEl.style.display = 'block';
            if (bannerTxt) bannerTxt.innerText = `🌑 กำลังจำลองเงา: ${inspectedShadow.name} (สุ่มออก ${inspectedShadow.rate}%)`;
        } else {
            bannerEl.style.display = 'none';
        }
    }

    const name = inspectedShadow ? inspectedShadow.name : (document.getElementById('ai_frame_name')?.value || 'กรอบรูปตัวละคร');
    const grade = inspectedShadow ? inspectedShadow.grade : (document.getElementById('ai_frame_grade')?.value || 'SS+');
    const aura = inspectedShadow ? inspectedShadow.aura : (document.getElementById('ai_frame_aura')?.value || 'orange');
    const fx = inspectedShadow ? 'pulse_breathe' : (document.getElementById('ai_frame_fx')?.value || 'spin_pulse');
    const intensity = inspectedShadow ? (parseInt(inspectedShadow.intensity) || 100) : (parseInt(document.getElementById('ai_frame_intensity')?.value) || 100);
    const frameScale = parseInt(document.getElementById('ai_frame_scale')?.value) || 122;
    const colorHex = inspectedShadow ? inspectedShadow.color : (document.getElementById('ai_frame_color')?.value || '#f59e0b');
    const win = document.getElementById('ai_frame_win')?.value || 85;
    const roll = document.getElementById('ai_frame_roll')?.value || 90;
    const skill = document.getElementById('ai_frame_skill')?.value || 45;

    const scaleLbl = document.getElementById('ai_frame_scale_label');
    if (scaleLbl) scaleLbl.innerText = frameScale + '%';

    const dispNameEl = document.getElementById('ai_preview_display_name');
    if (dispNameEl) dispNameEl.innerText = name;
    const prevWinEl = document.getElementById('ai_prev_win');
    if (prevWinEl) prevWinEl.innerText = win + '%';
    const prevRollEl = document.getElementById('ai_prev_roll');
    if (prevRollEl) prevRollEl.innerText = roll + '%';
    const prevSkillEl = document.getElementById('ai_prev_skill');
    if (prevSkillEl) prevSkillEl.innerText = skill;
    const gradeBadgeEl = document.getElementById('ai_preview_grade_badge');
    if (gradeBadgeEl) gradeBadgeEl.innerText = grade;

    const auraNames = {
        orange: 'ส้มเพลิงมหาเวทย์ 🔥',
        gold: 'ทองสง่างาม 👑',
        crimson: 'แดงเพลิงโลหิต 🩸',
        purple: 'ม่วงดาราจักร 🔮',
        rainbow: 'รุ้งปริซึม 7 สี 🌈',
        yellow: 'เหลืองสายฟ้า ⚡',
        cyan: 'ฟ้านีออนวารี 🌊',
        white: 'ขาวบริสุทธิ์ ✨',
        none: 'ไม่มีแสงเออร่า'
    };
    const auraHexMap = {
        orange: '#f97316',
        gold: '#ffd700',
        crimson: '#ef4444',
        purple: '#a855f7',
        rainbow: '#ec4899',
        yellow: '#facc15',
        cyan: '#00e5ff',
        white: '#ffffff',
        none: 'transparent'
    };
    const fxNames = {
        spin_pulse: '🌀 หมุนวงแหวน + พัลส์พลังงาน',
        spin_slow: '🔄 หมุนวงแหวน 360° ต่อเนื่อง',
        reverse_dual: '💫 วงแหวนพลังงานคู่หมุนสวนทาง',
        electric_orbit: '⚡ ประกายดาวสายฟ้าวิ่งรอบกรอบ',
        flame_halo: '🔥 เปลวเพลิงออร่าลุกโชนรอบกรอบ',
        pulse_breathe: '✨ เรืองแสงหายใจเข้า-ออก นุ่มนวล',
        static: '🛡️ กรอบนิ่งคมชัด (ไม่หมุน)'
    };

    const auraDescEl = document.getElementById('ai_preview_aura_desc');
    if (auraDescEl) auraDescEl.innerText = `แสงเออร่า: ${auraNames[aura] || aura} (ระดับแสง ${intensity}%)`;
    const fxDescEl = document.getElementById('ai_preview_fx_desc');
    if (fxDescEl) {
        fxDescEl.innerText = inspectedShadow
            ? `🌑 โหมดแสดงตัวอย่างเงาวัตถุดิบ (อัตราสุ่มออก ${inspectedShadow.rate}%)`
            : `✨ ลูกเล่น: ${fxNames[fx] || fx}`;
    }

    const avEl = document.getElementById('ai_preview_avatar');
    const hintEl = document.getElementById('ai_preview_center_hint');
    const activeRingDataUrl = inspectedShadow ? (inspectedShadow.image_url || '') : (typeof currentAiUploadedImageData !== 'undefined' ? currentAiUploadedImageData : '');
    if (avEl) {
        if (typeof currentAiCenterMode !== 'undefined' && currentAiCenterMode === 'sample_avatar') {
            const sampleAv = currentAdminAvatarUrl || '../avatars/avatar_01.png';
            avEl.style.backgroundImage = `url("${sampleAv}")`;
            avEl.style.backgroundSize = 'cover';
            avEl.style.backgroundPosition = 'center';
            if (hintEl) hintEl.style.display = 'none';
        } else {
            avEl.style.backgroundImage = 'radial-gradient(circle, rgba(15,23,42,0.25) 0%, rgba(2,6,23,0.92) 100%)';
            if (hintEl) {
                hintEl.style.display = 'block';
                hintEl.innerText = inspectedShadow ? 'เงาวงแหวนโปร่งใส' : (activeRingDataUrl ? 'โปร่งใส (ช่องรูปโปรไฟล์)' : 'ช่องว่างรูปโปรไฟล์');
            }
        }
        avEl.style.borderColor = activeRingDataUrl ? 'rgba(255,255,255,0.18)' : colorHex;
        avEl.style.borderWidth = activeRingDataUrl ? '1.5px' : '3.5px';
    }

    const glowHex = auraHexMap[aura] || colorHex || '#f59e0b';
    const auraCont = document.getElementById('ai_preview_aura_container');
    if (auraCont) {
        if (aura === 'none') {
            auraCont.style.boxShadow = 'none';
            auraCont.style.background = 'transparent';
        } else {
            const spread = Math.max(8, Math.round(22 * (intensity / 100)));
            auraCont.style.boxShadow = `0 0 ${spread}px ${glowHex}, inset 0 0 ${Math.round(spread * 0.6)}px ${glowHex}`;
            auraCont.style.background = 'transparent';
        }
    }

    const fxDeco = document.getElementById('ai_preview_fx_deco');
    if (fxDeco) {
        fxDeco.style.display = (aura !== 'none' && fx !== 'static') ? 'block' : 'none';
    }

    const ringOverlay = document.getElementById('ai_preview_ring_overlay');
    if (ringOverlay) {
        if (activeRingDataUrl) {
            const pxSize = Math.round(136 * (frameScale / 100));
            ringOverlay.src = activeRingDataUrl;
            ringOverlay.style.width = pxSize + 'px';
            ringOverlay.style.height = pxSize + 'px';
            ringOverlay.style.display = 'block';
            ringOverlay.className = 'fx-ring-' + fx;
            if (aura !== 'none' && intensity > 100) {
                const overRatio = (intensity - 100) / 100;
                const ringDrop = Math.round(10 + overRatio * 18);
                ringOverlay.style.filter = `brightness(${(1 + overRatio * 0.2).toFixed(2)}) drop-shadow(0 0 ${ringDrop}px ${glowHex})`;
            } else {
                ringOverlay.style.filter = '';
            }
        } else {
            ringOverlay.style.display = 'none';
        }
    }
}

async function submitSaveAiFrame(e) {
    e.preventDefault();
    const btn = document.getElementById('btn-save-ai-frame');
    const origLabel = btn.innerText;
    btn.disabled = true;
    btn.innerText = '⏳ กำลังบันทึกลงฐานข้อมูล...';

    const editingId = parseInt(document.getElementById('ai_editing_char_id')?.value || '0');

    try {
        const payload = {
            id: editingId,
            name: document.getElementById('ai_frame_name').value.trim(),
            grade: document.getElementById('ai_frame_grade').value,
            win_rate_bonus: parseFloat(document.getElementById('ai_frame_win').value) || 0,
            roll_rate: parseFloat(document.getElementById('ai_frame_roll').value) || 0,
            play_skill_rate: parseFloat(document.getElementById('ai_frame_skill').value) || 0,
            aura_type: document.getElementById('ai_frame_aura').value,
            aura_intensity: parseInt(document.getElementById('ai_frame_intensity').value) || 100,
            frame_fx: document.getElementById('ai_frame_fx').value || 'spin_pulse',
            frame_scale: parseInt(document.getElementById('ai_frame_scale').value) || 122,
            price_diamond: 0,
            is_available: 1,
            color_hex: document.getElementById('ai_frame_color').value,
            avatar_url: currentAiUploadedImageData || '',
            clear_avatar_url: currentAiClearAvatarFlag ? 1 : 0,
            set_as_gacha_target: document.getElementById('ai_set_as_gacha_target').checked,
            shadow_bundle: collectAiShadowBundle()
        };

        const res = await fetch('admin_panel.php?api=1&action=save_frame_character', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(res.message);
            await loadAdminFrames();
            if (res.character_id) {
                const sel = document.getElementById('ai_edit_existing_select');
                if (sel) sel.value = String(res.character_id);
                loadFrameIntoAiStudio(res.character_id);
            }
        } else {
            alert('เกิดข้อผิดพลาด: ' + (res.message || 'บันทึกไม่สำเร็จ'));
        }
    } catch(err) {
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
    } finally {
        btn.disabled = false;
        if (parseInt(document.getElementById('ai_editing_char_id')?.value || '0') <= 0) {
            btn.innerText = '💾 บันทึกเป็นกรอบรูปกิจกรรมใหม่ลงฐานข้อมูล';
        } else {
            btn.innerText = origLabel;
        }
    }
}

// ============================================================
// 🎲 AI DICE STUDIO & 3D INTERACTIVE ROLL SIMULATOR ENGINE
// ============================================================
// 🎲 AI DICE STUDIO & 3D INTERACTIVE ROLL SIMULATOR ENGINE
// ============================================================

let adminDiceListCache = <?= json_encode($dice, JSON_UNESCAPED_UNICODE) ?> || [];
let activeEventTargetDiceId = <?= (int)$activeGachaTargetDiceId ?>;
let currentAiDiceImageBase64 = '';
let isDiceRolling = false;
let diceOrbitRotX = -22;
let diceOrbitRotY = 32;

// Maps Aura type to glow hex/rgba
const DICE_AURA_COLORS = {
    none: 'transparent',
    cyan: '#00e5ff',
    gold: '#ffd700',
    purple: '#c084fc',
    orange: '#f97316',
    crimson: '#ef4444',
    yellow: '#facc15',
    white: '#ffffff',
    emerald: '#10b981',
    pink: '#f43f5e',
    rainbow: '#00e5ff'
};

// Target rotations for each face 1 to 6 to face directly forward
const DICE_FACE_ROTATIONS = {
    1: { x: 0, y: 0, z: 0 },
    2: { x: 0, y: -90, z: 0 },
    3: { x: -90, y: 0, z: 0 },
    4: { x: 90, y: 0, z: 0 },
    5: { x: 0, y: 90, z: 0 },
    6: { x: 180, y: 0, z: 0 }
};

let currentDiceViewMode = 'cube';
let currentAiVariations = [];
let activeAiVariationIndex = 0;

function setDiceViewMode(mode) {
    currentDiceViewMode = mode;
    const cubeEl = document.getElementById('diceCube3D');
    const showcaseEl = document.getElementById('diceImageShowcase');
    const btnCube = document.getElementById('btnMode3DCube');
    const btnShowcase = document.getElementById('btnModeShowcaseImg');

    if (mode === 'showcase' && typeof currentAiDiceImageBase64 !== 'undefined' && currentAiDiceImageBase64) {
        if (cubeEl) cubeEl.style.display = 'none';
        if (showcaseEl) showcaseEl.style.display = 'flex';
        if (btnCube) {
            btnCube.style.background = '#1e293b';
            btnCube.style.color = '#94a3b8';
            btnCube.style.boxShadow = 'none';
        }
        if (btnShowcase) {
            btnShowcase.style.background = 'linear-gradient(135deg, #0284c7, #00e5ff)';
            btnShowcase.style.color = '#000';
            btnShowcase.style.boxShadow = '0 0 12px rgba(0,229,255,0.4)';
        }
    } else {
        if (cubeEl) cubeEl.style.display = 'block';
        if (showcaseEl) showcaseEl.style.display = 'none';
        if (btnCube) {
            btnCube.style.background = 'linear-gradient(135deg, #0284c7, #00e5ff)';
            btnCube.style.color = '#000';
            btnCube.style.boxShadow = '0 0 12px rgba(0,229,255,0.4)';
        }
        if (btnShowcase) {
            btnShowcase.style.background = '#1e293b';
            btnShowcase.style.color = '#cbd5e1';
            btnShowcase.style.boxShadow = 'none';
        }
    }
}

function renderAiVariationsGrid() {
    const grid = document.getElementById('ai_variations_grid');
    if (!grid || !Array.isArray(currentAiVariations)) return;
    grid.innerHTML = currentAiVariations.map((v, idx) => {
        const isSel = idx === activeAiVariationIndex;
        return `
            <div onclick="selectAiVariation(${idx}, true)" style="cursor:pointer; padding:8px; border-radius:9px; background:${isSel ? 'rgba(168,85,247,0.22)' : 'rgba(15,23,42,0.8)'}; border:1.5px solid ${isSel ? '#c084fc' : 'rgba(255,255,255,0.1)'}; text-align:center; transition:all 0.15s;">
                <div style="width:26px; height:26px; margin:0 auto 5px auto; border-radius:6px; background:${v.bodyColor}; border:2px solid ${v.pipColor}; box-shadow:0 0 10px ${v.badgeColor};"></div>
                <div style="font-size:11px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${v.title}</div>
                <div style="font-size:10px; color:${v.badgeColor}; font-weight:700;">[${v.grade}] ${v.ctrlRate}%</div>
            </div>
        `;
    }).join('');
}

function selectAiVariation(idx, notify = true) {
    const v = currentAiVariations[idx];
    if (!v) return;
    activeAiVariationIndex = idx;
    const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    setVal('ai_dice_name', v.name);
    setVal('ai_dice_grade', v.grade);
    setVal('ai_dice_color', v.bodyColor);
    setVal('ai_dice_color_hex', v.bodyColor);
    setVal('ai_dice_pip_color', v.pipColor);
    setVal('ai_dice_pip_color_hex', v.pipColor);
    setVal('ai_dice_aura', v.aura);
    setVal('ai_dice_fx', v.fx);
    setVal('ai_dice_intensity', v.intensity);
    setVal('ai_dice_intensity_num', v.intensity);
    setVal('ai_dice_control_rate', v.ctrlRate);
    setVal('ai_dice_control_slider', v.ctrlRate);
    const skinChk = document.getElementById('ai_dice_apply_skin_texture');
    if (skinChk) skinChk.checked = Boolean(v.useSkinTexture);
    renderAiVariationsGrid();
    if (typeof updateAiDice3DPreview === 'function') updateAiDice3DPreview();
    if (notify) showToast(`🎨 เลือกสไตล์ "${v.title}" [${v.grade}] เรียบร้อยแล้ว`);
}

function rebuildAiDiceVariations() {
    const rawName = document.getElementById('ai_dice_name')?.value || 'ลูกเต๋า';
    const cleanName = rawName.replace(/^ลูกเต๋า/, '').replace(/[A-Z\+\s]+$/, '').trim() || 'มังกรดาราจักร';
    const currentBaseColor = document.getElementById('ai_dice_color')?.value || '#1e1b4b';
    const currentPipColor = document.getElementById('ai_dice_pip_color')?.value || '#00e5ff';
    const hasImage = typeof currentAiDiceImageBase64 !== 'undefined' && Boolean(currentAiDiceImageBase64);

    currentAiVariations = [
        { title: '📸 สกินภาพจริงดั้งเดิม', subtitle: 'Real Texture Skin', name: `ลูกเต๋า${cleanName} ภาพจริง Z+`, grade: 'Z+', bodyColor: currentBaseColor, pipColor: currentPipColor, aura: 'cyan', fx: 'pulse_breathe', intensity: 150, ctrlRate: 85.0, useSkinTexture: hasImage, badgeColor: '#00e5ff' },
        { title: '⚡ ไซเบอร์นีออนเรืองแสง', subtitle: 'Cyber Glow Neon', name: `ลูกเต๋า${cleanName} นีออน SS+`, grade: 'SS+', bodyColor: '#0b0f19', pipColor: '#00f0ff', aura: 'cyan', fx: 'solar_flare', intensity: 220, ctrlRate: 87.5, useSkinTexture: hasImage, badgeColor: '#38bdf8' },
        { title: '👑 จักรพรรดิทองคำพรีเมียม', subtitle: 'Royal Gold Emperor', name: `ลูกเต๋า${cleanName} สุริยะทองคำ ZZ+`, grade: 'ZZ+', bodyColor: '#3b2308', pipColor: '#ffd700', aura: 'gold', fx: 'dual_ring', intensity: 250, ctrlRate: 90.0, useSkinTexture: false, badgeColor: '#ffd700' },
        { title: '🔮 คริสตัลมณีเวทมนตร์', subtitle: 'Mystic Crystal Gem', name: `ลูกเต๋า${cleanName} มณีมนตรา ZZZ+`, grade: 'ZZZ+', bodyColor: '#2e1065', pipColor: '#f43f5e', aura: 'purple', fx: 'cosmic_hyper', intensity: 240, ctrlRate: 88.0, useSkinTexture: false, badgeColor: '#c084fc' },
        { title: '🔥 เพลิงสุริยันระเบิดพลัง', subtitle: 'Blazing Solar Flame', name: `ลูกเต๋า${cleanName} เพลิงสุริยัน SSS+`, grade: 'SSS+', bodyColor: '#450a0a', pipColor: '#f97316', aura: 'crimson', fx: 'solar_flare', intensity: 300, ctrlRate: 92.0, useSkinTexture: false, badgeColor: '#ef4444' },
        { title: '🌌 ดาราจักรเนบิวลานิรันดร์', subtitle: 'Infinite Cosmic Nebula', name: `ลูกเต๋า${cleanName} ดาราจักร GOD`, grade: 'GOD', bodyColor: '#032030', pipColor: '#34d399', aura: 'emerald', fx: 'rotate_spin', intensity: 280, ctrlRate: 95.0, useSkinTexture: hasImage, badgeColor: '#10b981' }
    ];

    renderAiVariationsGrid();
    selectAiVariation(0, false);
}

function initAiDiceStudio() {
    populateDiceDropdown();
    renderAiDiceGallery();
    rebuildAiDiceVariations();
    updateAiDice3DPreview();
}

function populateDiceDropdown() {
    const sel = document.getElementById('ai_dice_existing_select');
    if (!sel) return;
    const curVal = sel.value;
    let html = '<option value="0">➕ โหมด: สร้างลูกเต๋าใหม่ด้วย AI</option>';
    adminDiceListCache.forEach(d => {
        const isTarget = (parseInt(d.id) === parseInt(activeEventTargetDiceId));
        const targetBadge = isTarget ? ' [🎯 เต๋ากิจกรรม]' : '';
        html += `<option value="${d.id}">✏️ [${d.grade}] ${d.name}${targetBadge}</option>`;
    });
    sel.innerHTML = html;
    if (curVal && sel.querySelector(`option[value="${curVal}"]`)) {
        sel.value = curVal;
    }
}

function renderAiDiceGallery() {
    const c = document.getElementById('ai_dice_gallery_list');
    if (!c) return;
    if (!adminDiceListCache || adminDiceListCache.length === 0) {
        c.innerHTML = '<span style="font-size:12px; color:var(--text-muted);">ไม่มีรายการลูกเต๋าในฐานข้อมูล</span>';
        return;
    }
    let html = '';
    adminDiceListCache.forEach(d => {
        const isTarget = (parseInt(d.id) === parseInt(activeEventTargetDiceId));
        const bodyColor = d.color_hex || '#1e1b4b';
        const pipColor = d.pip_color_hex || '#ffffff';
        const auraColor = DICE_AURA_COLORS[d.aura_type || 'cyan'] || '#00e5ff';
        html += `
            <div onclick="loadDiceIntoStudio(${d.id})" style="flex:0 0 140px; background:rgba(15,23,42,0.85); border:1.5px solid ${isTarget ? '#10b981' : 'rgba(255,255,255,0.12)'}; border-radius:10px; padding:10px 8px; cursor:pointer; text-align:center; transition:all 0.2s; box-shadow:0 3px 10px rgba(0,0,0,0.3);" onmouseover="this.style.borderColor='#a855f7'; this.style.transform='translateY(-3px)'" onmouseout="this.style.borderColor='${isTarget ? '#10b981' : 'rgba(255,255,255,0.12)'}'; this.style.transform='none'">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <span style="font-size:10px; font-weight:800; background:rgba(255,255,255,0.1); padding:1px 5px; border-radius:3px; color:#ffd700;">${d.grade}</span>
                    ${isTarget ? '<span style="font-size:9px; background:#10b981; color:#000; font-weight:900; padding:1px 4px; border-radius:3px;">TARGET</span>' : ''}
                </div>
                <div style="width:36px; height:36px; margin:0 auto 6px auto; background:${bodyColor}; border-radius:8px; border:2px solid ${pipColor}; box-shadow:0 0 12px ${auraColor}; display:flex; align-items:center; justify-content:center; color:${pipColor}; font-weight:900; font-size:14px;">
                    ★
                </div>
                <div style="font-size:11.5px; font-weight:700; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${d.name}">${d.name}</div>
                <div style="font-size:10.5px; color:#38bdf8; margin-top:2px;">คุมเต๋า ${parseFloat(d.dice_control_rate || 10).toFixed(0)}%</div>
            </div>
        `;
    });
    c.innerHTML = html;
}

function loadDiceIntoStudio(diceId) {
    diceId = parseInt(diceId);
    const sel = document.getElementById('ai_dice_existing_select');
    if (sel && sel.value != diceId) sel.value = diceId;

    if (diceId <= 0) {
        resetAiDiceStudio();
        return;
    }

    const d = adminDiceListCache.find(x => parseInt(x.id) === diceId);
    if (!d) return;

    document.getElementById('ai_dice_id').value = d.id;
    document.getElementById('ai_dice_name').value = d.name || 'ลูกเต๋า';
    document.getElementById('ai_dice_grade').value = d.grade || 'A';
    
    const ctrlRate = parseFloat(d.dice_control_rate || 20.0);
    document.getElementById('ai_dice_control_rate').value = ctrlRate.toFixed(2);
    document.getElementById('ai_dice_control_rate_range').value = ctrlRate;
    document.getElementById('lbl_dice_ctrl_val').innerText = ctrlRate.toFixed(2) + '%';

    const bodyColor = d.color_hex || '#1e1b4b';
    const pipColor = d.pip_color_hex || '#ffffff';
    document.getElementById('ai_dice_color').value = bodyColor;
    document.getElementById('ai_dice_color_picker').value = bodyColor;
    document.getElementById('ai_dice_pip_color').value = pipColor;
    document.getElementById('ai_dice_pip_color_picker').value = pipColor;

    const aura = d.aura_type || 'cyan';
    document.getElementById('ai_dice_aura').value = aura;

    const intensity = parseInt(d.aura_intensity || 100);
    document.getElementById('ai_dice_intensity').value = intensity;
    document.getElementById('ai_dice_intensity_range').value = intensity;
    syncDiceIntensityNum(intensity);

    const fx = d.aura_fx || 'pulse_breathe';
    document.getElementById('ai_dice_fx').value = fx;

    document.getElementById('ai_dice_image_url').value = d.image_url || '';
    currentAiDiceImageBase64 = d.image_url || '';

    const isTarget = (parseInt(d.id) === parseInt(activeEventTargetDiceId));
    document.getElementById('ai_dice_set_as_gacha_target').checked = isTarget;

    updateAiDice3DPreview();
    showToast(`📖 โหลดข้อมูลลูกเต๋า '${d.name}' [${d.grade}] เรียบร้อย`);
}

function resetAiDiceStudio() {
    document.getElementById('ai_dice_id').value = 0;
    const sel = document.getElementById('ai_dice_existing_select');
    if (sel) sel.value = 0;

    document.getElementById('ai_dice_name').value = 'ลูกเต๋ามังกรดาราจักร ZZ+';
    document.getElementById('ai_dice_grade').value = 'SS+';

    document.getElementById('ai_dice_control_rate').value = '85.00';
    document.getElementById('ai_dice_control_rate_range').value = 85;
    document.getElementById('lbl_dice_ctrl_val').innerText = '85.00%';

    document.getElementById('ai_dice_color').value = '#1e1b4b';
    document.getElementById('ai_dice_color_picker').value = '#1e1b4b';
    document.getElementById('ai_dice_pip_color').value = '#00e5ff';
    document.getElementById('ai_dice_pip_color_picker').value = '#00e5ff';

    document.getElementById('ai_dice_aura').value = 'cyan';
    document.getElementById('ai_dice_intensity').value = 100;
    document.getElementById('ai_dice_intensity_range').value = 100;
    syncDiceIntensityNum(100);

    document.getElementById('ai_dice_fx').value = 'pulse_breathe';
    document.getElementById('ai_dice_image_url').value = '';
    currentAiDiceImageBase64 = '';

    const analysisBox = document.getElementById('ai_dice_analysis_badge');
    if (analysisBox) analysisBox.style.display = 'none';

    updateAiDice3DPreview();
}

function setDiceGradeQuick(grade) {
    const input = document.getElementById('ai_dice_grade');
    if (input) {
        input.value = grade;
        updateAiDice3DPreview();
    }
}

function syncDiceCtrlSlider(v) {
    const num = parseFloat(v) || 10;
    document.getElementById('ai_dice_control_rate').value = num.toFixed(2);
    document.getElementById('lbl_dice_ctrl_val').innerText = num.toFixed(2) + '%';
    const badge = document.getElementById('stage_dice_rate_badge');
    if (badge) badge.innerText = `คุมเต๋า ${num.toFixed(0)}%`;
}

function syncDiceCtrlNum(v) {
    const num = Math.max(1, Math.min(100, parseFloat(v) || 10));
    document.getElementById('ai_dice_control_rate_range').value = num;
    document.getElementById('lbl_dice_ctrl_val').innerText = num.toFixed(2) + '%';
    const badge = document.getElementById('stage_dice_rate_badge');
    if (badge) badge.innerText = `คุมเต๋า ${num.toFixed(0)}%`;
}

function syncDiceBodyColor(hex) {
    document.getElementById('ai_dice_color').value = hex;
    updateAiDice3DPreview();
}
function syncDiceBodyColorHex(hex) {
    if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
        document.getElementById('ai_dice_color_picker').value = hex;
    }
    updateAiDice3DPreview();
}

function syncDicePipColor(hex) {
    document.getElementById('ai_dice_pip_color').value = hex;
    updateAiDice3DPreview();
}
function syncDicePipColorHex(hex) {
    if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
        document.getElementById('ai_dice_pip_color_picker').value = hex;
    }
    updateAiDice3DPreview();
}

function applyDiceColorPreset(bodyHex, pipHex, aura) {
    document.getElementById('ai_dice_color').value = bodyHex;
    document.getElementById('ai_dice_color_picker').value = bodyHex;
    document.getElementById('ai_dice_pip_color').value = pipHex;
    document.getElementById('ai_dice_pip_color_picker').value = pipHex;
    document.getElementById('ai_dice_aura').value = aura;
    updateAiDice3DPreview();
}

function syncDiceIntensitySlider(v) {
    const val = parseInt(v) || 100;
    document.getElementById('ai_dice_intensity').value = val;
    syncDiceIntensityNum(val);
}

function syncDiceIntensityNum(v) {
    const val = Math.max(10, Math.min(500, parseInt(v) || 100));
    document.getElementById('ai_dice_intensity_range').value = val;
    document.getElementById('lbl_dice_intensity_val').innerText = val + '%';
    
    const tag = document.getElementById('lbl_dice_aura_power_tag');
    if (tag) {
        if (val < 100) {
            tag.innerText = `${val}% (เบาบาง)`;
            tag.style.color = '#94a3b8';
            tag.style.background = 'rgba(148,163,184,0.15)';
        } else if (val <= 150) {
            tag.innerText = `${val}% (ปกติ)`;
            tag.style.color = '#38bdf8';
            tag.style.background = 'rgba(56,189,248,0.15)';
        } else if (val <= 300) {
            tag.innerText = `${val}% (ทรงพลัง ⚡)`;
            tag.style.color = '#ffd700';
            tag.style.background = 'rgba(255,215,0,0.2)';
        } else {
            tag.innerText = `${val}% (MAX OVERLOAD ⚡⚡⚡)`;
            tag.style.color = '#ef4444';
            tag.style.background = 'rgba(239,68,68,0.25)';
        }
    }
    updateAiDice3DPreview();
}

function adjustDiceView() {
    diceOrbitRotX = parseInt(document.getElementById('view_rot_x').value) || -22;
    diceOrbitRotY = parseInt(document.getElementById('view_rot_y').value) || 32;
    const cube = document.getElementById('diceCube3D');
    if (cube && !isDiceRolling) {
        cube.style.transform = `rotateX(${diceOrbitRotX}deg) rotateY(${diceOrbitRotY}deg) rotateZ(0deg)`;
    }
}

function resetDice3DView() {
    diceOrbitRotX = -22;
    diceOrbitRotY = 32;
    document.getElementById('view_rot_x').value = -22;
    document.getElementById('view_rot_y').value = 32;
    const cube = document.getElementById('diceCube3D');
    if (cube && !isDiceRolling) {
        cube.style.transform = `rotateX(-22deg) rotateY(32deg) rotateZ(0deg)`;
    }
}

function updateAiDice3DPreview() {
    const name = document.getElementById('ai_dice_name')?.value || 'ลูกเต๋า 3D';
    const grade = (document.getElementById('ai_dice_grade')?.value || 'A').toUpperCase();
    const ctrlRate = parseFloat(document.getElementById('ai_dice_control_rate')?.value || 85.0);
    const bodyColor = document.getElementById('ai_dice_color')?.value || '#1e1b4b';
    const pipColor = document.getElementById('ai_dice_pip_color')?.value || '#00e5ff';
    const auraType = document.getElementById('ai_dice_aura')?.value || 'cyan';
    const auraIntensity = parseInt(document.getElementById('ai_dice_intensity')?.value || 100);
    const auraFx = document.getElementById('ai_dice_fx')?.value || 'pulse_breathe';

    // Update Header Text & Badge
    const titleEl = document.getElementById('stage_dice_title');
    if (titleEl) titleEl.innerText = name;
    
    const rateEl = document.getElementById('stage_dice_rate_badge');
    if (rateEl) rateEl.innerText = `คุมเต๋า ${ctrlRate.toFixed(0)}%`;

    const gradeBadge = document.getElementById('stage_dice_grade_badge');
    if (gradeBadge) {
        gradeBadge.innerText = grade;
        if (grade.includes('Z')) {
            gradeBadge.style.background = 'linear-gradient(135deg, #f43f5e, #a855f7)';
            gradeBadge.style.color = '#fff';
            gradeBadge.style.boxShadow = '0 0 15px rgba(244,63,94,0.6)';
        } else if (grade.includes('SS') || grade.includes('GOD')) {
            gradeBadge.style.background = 'linear-gradient(135deg, #ffd700, #f59e0b)';
            gradeBadge.style.color = '#000';
            gradeBadge.style.boxShadow = '0 0 15px rgba(255,215,0,0.6)';
        } else if (grade.includes('S')) {
            gradeBadge.style.background = 'linear-gradient(135deg, #0284c7, #00e5ff)';
            gradeBadge.style.color = '#000';
            gradeBadge.style.boxShadow = '0 0 12px rgba(0,229,255,0.5)';
        } else {
            gradeBadge.style.background = 'rgba(255,255,255,0.15)';
            gradeBadge.style.color = '#fff';
            gradeBadge.style.boxShadow = 'none';
        }
    }

    // Set Scene CSS Variables
    const scene = document.getElementById('diceSceneContainer');
    if (!scene) return;

    scene.style.setProperty('--dice-body-color', bodyColor);
    scene.style.setProperty('--dice-pip-color', pipColor);

    const glowColor = DICE_AURA_COLORS[auraType] || '#00e5ff';
    scene.style.setProperty('--aura-glow-color', glowColor);

    // Multiplier for >100% aura!
    const blurScale = Math.max(0.2, (auraIntensity / 100));
    const opacityScale = Math.min(1.0, 0.35 + (auraIntensity / 500) * 0.65);
    scene.style.setProperty('--aura-blur-scale', blurScale.toFixed(2));
    scene.style.setProperty('--aura-opacity', opacityScale.toFixed(2));

    const glowEl = document.getElementById('diceAuraGlow');
    const ringEl = document.getElementById('diceAuraRing');
    const pedestalEl = document.getElementById('dicePedestal');

    if (auraType === 'none') {
        if (glowEl) glowEl.style.display = 'none';
        if (ringEl) ringEl.style.display = 'none';
        if (pedestalEl) pedestalEl.style.opacity = '0.2';
    } else {
        if (glowEl) {
            glowEl.style.display = 'block';
            glowEl.className = `dice-aura-glow-backdrop dice-fx-${auraFx}`;
            
            // Ultra-powerful bloom when intensity > 100%
            if (auraIntensity > 100) {
                const spread1 = Math.round(15 * (auraIntensity / 100));
                const spread2 = Math.round(35 * (auraIntensity / 100));
                const spread3 = Math.round(65 * (auraIntensity / 100));
                glowEl.style.boxShadow = `0 0 ${spread1}px ${glowColor}, 0 0 ${spread2}px ${glowColor}, 0 0 ${spread3}px rgba(255,255,255,0.5)`;
            } else {
                glowEl.style.boxShadow = `0 0 25px ${glowColor}`;
            }
        }
        if (ringEl) {
            ringEl.style.display = 'block';
            ringEl.style.borderColor = glowColor;
            ringEl.style.boxShadow = `0 0 ${Math.round(15 * blurScale)}px ${glowColor}`;
        }
        if (pedestalEl) {
            pedestalEl.style.opacity = '0.9';
            pedestalEl.style.boxShadow = `0 0 ${Math.round(30 * blurScale)}px ${glowColor}`;
        }
    }
}

// AI Image Analyzer for Dice Skin
function handleAiDiceImageSelect(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
        alert('กรุณาเลือกไฟล์รูปภาพที่ถูกต้อง (PNG, JPG, WEBP)');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(evt) {
        const base64 = evt.target.result;
        currentAiDiceImageBase64 = base64;
        document.getElementById('ai_dice_image_url').value = base64;

        const img = new Image();
        img.onload = function() {
            analyzeDiceImage(img);
        };
        img.src = base64;
    };
    reader.readAsDataURL(file);
}

function analyzeDiceImage(img) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const w = 64, h = 64;
    canvas.width = w; canvas.height = h;
    ctx.drawImage(img, 0, 0, w, h);

    const imgData = ctx.getImageData(0, 0, w, h).data;
    let rSum = 0, gSum = 0, bSum = 0, validCount = 0;
    const colorCounts = {};

    for (let i = 0; i < imgData.length; i += 4) {
        const a = imgData[i + 3];
        if (a < 50) continue;
        const r = imgData[i];
        const g = imgData[i + 1];
        const b = imgData[i + 2];
        rSum += r; gSum += g; bSum += b;
        validCount++;

        // Quantize
        const qr = Math.round(r / 32) * 32;
        const qg = Math.round(g / 32) * 32;
        const qb = Math.round(b / 32) * 32;
        const key = `${qr},${qg},${qb}`;
        colorCounts[key] = (colorCounts[key] || 0) + 1;
    }

    if (validCount === 0) return;

    // Dominant body color
    let maxK = '', maxC = 0;
    for (const k in colorCounts) {
        if (colorCounts[k] > maxC) {
            maxC = colorCounts[k];
            maxK = k;
        }
    }
    const [dr, dg, db] = maxK.split(',').map(Number);
    const toHex = (n) => n.toString(16).padStart(2, '0');
    const bodyHex = `#${toHex(dr)}${toHex(dg)}${toHex(db)}`;

    // High-contrast Pip color calculation using YIQ luminance
    const yiq = ((dr * 299) + (dg * 587) + (db * 114)) / 1000;
    let pipHex = '#ffffff';
    let suggestedAura = 'cyan';
    let suggestedFx = 'pulse_breathe';
    let themeName = 'คอสมิค';
    let suggestedGrade = 'SS+';

    // Determine Hue
    const rNorm = dr / 255, gNorm = dg / 255, bNorm = db / 255;
    const maxV = Math.max(rNorm, gNorm, bNorm), minV = Math.min(rNorm, gNorm, bNorm);
    const dVal = maxV - minV;
    let hue = 0;
    if (dVal > 0) {
        if (maxV === rNorm) hue = ((gNorm - bNorm) / dVal) % 6;
        else if (maxV === gNorm) hue = (bNorm - rNorm) / dVal + 2;
        else hue = (rNorm - gNorm) / dVal + 4;
        hue = Math.round(hue * 60);
        if (hue < 0) hue += 360;
    }

    if (hue >= 340 || hue < 20) {
        suggestedAura = 'crimson';
        suggestedFx = 'solar_flare';
        pipHex = '#ffd700';
        themeName = 'เพลิงสุริยันมังกรแดง';
        suggestedGrade = 'Z+';
    } else if (hue >= 20 && hue < 50) {
        suggestedAura = 'orange';
        suggestedFx = 'solar_flare';
        pipHex = '#ffffff';
        themeName = 'เพลิงอัคนีสุริยะ';
        suggestedGrade = 'S+';
    } else if (hue >= 50 && hue < 80) {
        suggestedAura = 'gold';
        suggestedFx = 'dual_ring';
        pipHex = '#1e1b4b';
        themeName = 'จักรพรรดิทองคำบริสุทธิ์';
        suggestedGrade = 'ZZ+';
    } else if (hue >= 80 && hue < 165) {
        suggestedAura = 'emerald';
        suggestedFx = 'rotate_spin';
        pipHex = '#ffffff';
        themeName = 'มรกตเทพมังกรหยก';
        suggestedGrade = 'SS+';
    } else if (hue >= 165 && hue < 250) {
        suggestedAura = 'cyan';
        suggestedFx = 'pulse_breathe';
        pipHex = '#ffffff';
        themeName = 'ไอซ์คริสตัลดาราจักร';
        suggestedGrade = 'ZZ+';
    } else if (hue >= 250 && hue < 340) {
        suggestedAura = 'purple';
        suggestedFx = 'cosmic_hyper';
        pipHex = '#00f0ff';
        themeName = 'เนบิวลาดาราจักรนิรันดร์';
        suggestedGrade = 'ZZ+';
    }

    // Set form values
    document.getElementById('ai_dice_color').value = bodyHex;
    document.getElementById('ai_dice_color_picker').value = bodyHex;
    document.getElementById('ai_dice_pip_color').value = pipHex;
    document.getElementById('ai_dice_pip_color_picker').value = pipHex;
    document.getElementById('ai_dice_aura').value = suggestedAura;
    document.getElementById('ai_dice_fx').value = suggestedFx;
    document.getElementById('ai_dice_grade').value = suggestedGrade;
    document.getElementById('ai_dice_name').value = `ลูกเต๋า${themeName} ${suggestedGrade}`;

    // Show analysis box
    const box = document.getElementById('ai_dice_analysis_badge');
    if (box) {
        box.style.display = 'block';
        document.getElementById('ai_analysis_theme_tag').innerText = themeName;
        document.getElementById('ai_detected_body_swatch').style.background = bodyHex;
        document.getElementById('ai_detected_body_hex').innerText = bodyHex;
        document.getElementById('ai_detected_pip_swatch').style.background = pipHex;
        document.getElementById('ai_detected_pip_hex').innerText = pipHex;
        document.getElementById('ai_recommended_aura_name').innerText = `${suggestedAura.toUpperCase()} (${suggestedFx})`;
    }

    updateAiDice3DPreview();
    showToast(`🤖 AI วิเคราะห์เสร็จสิ้น: ธีม ${themeName} [${suggestedGrade}] แสงเออร่า ${suggestedAura}`);
}

function generateRandomDiceName() {
    const prefixes = ['ลูกเต๋าเทพ', 'ลูกเต๋ามังกร', 'ลูกเต๋าจักรพรรดิ', 'ลูกเต๋าดาราจักร', 'ลูกเต๋าอัสนีบาต', 'ลูกเต๋าสุริยัน', 'ลูกเต๋าเนบิวลา', 'ลูกเต๋าเทวะ', 'ลูกเต๋าสวรรค์', 'ลูกเต๋าพญานาคราช', 'ลูกเต๋าพยัคฆ์ทมิฬ'];
    const suffixes = ['พันล้าน', 'ไร้พ่าย', 'ทรงฤทธิ์', 'นิรันดร์', 'เก้าตะวัน', 'บรรพกาล', 'อมตะ', 'อเวจี', 'จ้าวเวหา', 'สะท้านภพ', 'มหาเวทย์'];
    const p = prefixes[Math.floor(Math.random() * prefixes.length)];
    const s = suffixes[Math.floor(Math.random() * suffixes.length)];
    const grade = (document.getElementById('ai_dice_grade')?.value || 'SS+').trim();
    const newName = `${p}${s} ${grade}`;
    document.getElementById('ai_dice_name').value = newName;
    updateAiDice3DPreview();
}

// 🎲 3D ROLL SIMULATOR ENGINE
function rollDiceSimulator(forcedFace = 0) {
    if (isDiceRolling) return;
    isDiceRolling = true;

    const btn = document.getElementById('btnRollSimulator');
    if (btn) {
        btn.innerText = '🌀 กำลังหมุนทอยลูกเต๋า 3 มิติ...';
        btn.style.opacity = '0.75';
    }

    const cube = document.getElementById('diceCube3D');
    const resultBox = document.getElementById('roll_simulation_result_box');
    if (resultBox) resultBox.style.display = 'none';

    // Choose target face
    let targetFace = parseInt(forcedFace);
    if (targetFace < 1 || targetFace > 6) {
        targetFace = Math.floor(Math.random() * 6) + 1;
    }

    // Check Dice Control
    const ctrlRate = parseFloat(document.getElementById('ai_dice_control_rate')?.value || 85.0);
    const rollAccuracyCheck = (Math.random() * 100);
    const isControlTriggered = (rollAccuracyCheck <= ctrlRate);

    // Target face rotation + random multiple full spins (720-1440 deg)
    const baseRot = DICE_FACE_ROTATIONS[targetFace] || { x: 0, y: 0, z: 0 };
    const spins = 1080;
    const finalRotX = baseRot.x + spins;
    const finalRotY = baseRot.y + (spins * 1.5);
    const finalRotZ = baseRot.z;

    const targetTransform = `rotateX(${finalRotX}deg) rotateY(${finalRotY}deg) rotateZ(${finalRotZ}deg)`;
    cube.style.setProperty('--roll-target-transform', targetTransform);

    // Trigger roll animation
    cube.classList.remove('is-rolling');
    void cube.offsetWidth; // reflow
    cube.classList.add('is-rolling');

    setTimeout(() => {
        cube.classList.remove('is-rolling');
        // Set resting rotation showing the target face with slight isometric angle
        cube.style.transform = `rotateX(${baseRot.x - 12}deg) rotateY(${baseRot.y + 18}deg) rotateZ(${baseRot.z}deg)`;
        isDiceRolling = false;

        if (btn) {
            btn.innerText = '⚡ กดทดสอบทอยลูกเต๋า (Roll Dice Simulator)';
            btn.style.opacity = '1';
        }

        // Show Result Banner
        if (resultBox) {
            resultBox.style.display = 'block';
            const scoreEl = document.getElementById('res_roll_score_text');
            const badgeEl = document.getElementById('res_roll_ctrl_badge');
            const detailEl = document.getElementById('res_roll_detail_text');

            if (scoreEl) scoreEl.innerText = `🎲 ได้แต้ม: ${targetFace} ${targetFace === 6 ? '★ (แต้มสูงสุด!)' : ''}`;
            
            if (badgeEl) {
                if (isControlTriggered) {
                    badgeEl.innerText = `🎯 คุมเต๋าสำเร็จ! (${ctrlRate.toFixed(0)}%)`;
                    badgeEl.style.borderColor = '#10b981';
                    badgeEl.style.color = '#34d399';
                    badgeEl.style.background = 'rgba(16,185,129,0.25)';
                } else {
                    badgeEl.innerText = `💨 หลุดคุมเต๋า (สุ่มอิสระ)`;
                    badgeEl.style.borderColor = '#f59e0b';
                    badgeEl.style.color = '#fbbf24';
                    badgeEl.style.background = 'rgba(245,158,11,0.2)';
                }
            }

            if (detailEl) {
                detailEl.innerHTML = `
                    <span>การคำนวณ: ค่าสุ่ม ${rollAccuracyCheck.toFixed(1)}% ${isControlTriggered ? '&le;' : '>'} อัตราคุมเต๋า ${ctrlRate.toFixed(2)}% &bull; หน้าเต๋าที่หงาย: <strong>Face #${targetFace}</strong></span>
                    ${targetFace % 2 === 0 ? '<br><span style="color:#38bdf8;">✨ เอฟเฟกต์พิเศษ: ทอยได้เลขคู่! ได้รับโบนัสทอง +15%</span>' : ''}
                `;
            }
        }
    }, 1250);
}

// Save Dice to Database via API
async function saveAiDiceToDatabase(e) {
    if (e && e.preventDefault) e.preventDefault();

    const diceId = parseInt(document.getElementById('ai_dice_id')?.value || 0);
    const name = (document.getElementById('ai_dice_name')?.value || '').trim();
    const grade = (document.getElementById('ai_dice_grade')?.value || 'A').trim().toUpperCase();
    const controlRate = parseFloat(document.getElementById('ai_dice_control_rate')?.value || 25.0);
    const bodyColor = document.getElementById('ai_dice_color')?.value || '#00e5ff';
    const pipColor = document.getElementById('ai_dice_pip_color')?.value || '#ffffff';
    const auraType = document.getElementById('ai_dice_aura')?.value || 'none';
    const auraIntensity = parseInt(document.getElementById('ai_dice_intensity')?.value || 100);
    const auraFx = document.getElementById('ai_dice_fx')?.value || 'pulse_breathe';
    const setAsTarget = document.getElementById('ai_dice_set_as_gacha_target')?.checked ? 1 : 0;
    const imageUrl = currentAiDiceImageBase64 || document.getElementById('ai_dice_image_url')?.value || '';

    if (!name) {
        alert('กรุณากรอกชื่อลูกเต๋า');
        return;
    }

    try {
        const payload = {
            id: diceId,
            name: name,
            grade: grade,
            dice_control_rate: controlRate,
            color_hex: bodyColor,
            pip_color_hex: pipColor,
            aura_type: auraType,
            aura_intensity: auraIntensity,
            aura_fx: auraFx,
            image_url: imageUrl,
            set_as_gacha_target: setAsTarget
        };

        const res = await fetch('admin_panel.php?api=1&action=save_ai_dice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const json = await res.json();

        if (json.status === 'success') {
            showToast(`✅ ${json.message}`);
            if (json.dice_id) {
                document.getElementById('ai_dice_id').value = json.dice_id;
                if (setAsTarget) {
                    activeEventTargetDiceId = json.dice_id;
                    const lblTarget = document.getElementById('lbl-active-event-dice');
                    if (lblTarget) lblTarget.innerText = `${name} [${grade}]`;
                }
            }
            // Refresh dice cache from server
            await reloadAllDiceListFromServer();
        } else {
            alert('เกิดข้อผิดพลาด: ' + (json.message || 'ไม่สามารถบันทึกได้'));
        }
    } catch (err) {
        console.error('saveAiDiceToDatabase error:', err);
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
    }
}

async function setDiceAsGachaTargetFromStudio() {
    const diceId = parseInt(document.getElementById('ai_dice_id')?.value || 0);
    const diceName = document.getElementById('ai_dice_name')?.value || 'ลูกเต๋า';
    if (diceId <= 0) {
        alert('กรุณากดบันทึกลูกเต๋าก่อนเพื่อรับรหัสลูกเต๋าในฐานข้อมูล');
        return;
    }
    await setGachaTargetDice(diceId, diceName);
    activeEventTargetDiceId = diceId;
    document.getElementById('ai_dice_set_as_gacha_target').checked = true;
    renderAiDiceGallery();
    populateDiceDropdown();
}

async function reloadAllDiceListFromServer() {
    try {
        const res = await fetch('admin_panel.php?api=1&action=get_all_dice');
        const json = await res.json();
        if (json.status === 'success' && Array.isArray(json.dice)) {
            adminDiceListCache = json.dice;
            if (json.target_dice_id) activeEventTargetDiceId = json.target_dice_id;
            populateDiceDropdown();
            renderAiDiceGallery();
        }
    } catch (e) {
        console.warn('reloadAllDiceListFromServer error:', e);
    }
}

// ============================================================
// 🎯 DICE GACHA EVENT CAMPAIGN MANAGEMENT (จัดกิจกรรมสุ่มลูกเต๋า 3D แยกเฉพาะ)
// ============================================================
let adminDiceEventsCache = [];
let currentActiveDiceEventObj = null;

async function loadDiceEventsAdmin() {
    try {
        const res = await fetch('admin_panel.php?api=1&action=get_dice_events').then(r => r.json());
        if (res && res.status === 'success') {
            adminDiceEventsCache = res.events || [];
            currentActiveDiceEventObj = res.active_event || null;
            if (res.dice) {
                adminDiceListCache = res.dice;
                populateDiceEventTargetDropdown(res.dice);
            }
            renderActiveDiceEventOverview(currentActiveDiceEventObj);
            renderDiceEventsTable(adminDiceEventsCache);
        }
    } catch (e) {
        console.error('loadDiceEventsAdmin error:', e);
    }
}

function populateDiceEventTargetDropdown(diceList) {
    const sel = document.getElementById('dice_ev_target_dice_id');
    if (!sel || !Array.isArray(diceList)) return;
    const curVal = sel.value;
    sel.innerHTML = diceList.map(d => {
        const ctrl = parseFloat(d.dice_control_rate || 10).toFixed(0);
        return `<option value="${d.id}">[${d.grade}] ${d.name} (คุมเต๋า ${ctrl}%)</option>`;
    }).join('');
    if (curVal && sel.querySelector(`option[value="${curVal}"]`)) {
        sel.value = curVal;
    }
}

function renderActiveDiceEventOverview(ev) {
    const card = document.getElementById('active_dice_event_overview_card');
    if (!card) return;
    if (!ev) {
        card.style.display = 'none';
        return;
    }
    card.style.display = 'block';

    const isActive = (parseInt(ev.is_active) === 1);
    const badge = document.getElementById('active_dice_ev_status_badge');
    const toggleBtn = document.getElementById('btn_toggle_active_dice_ev');
    if (badge) {
        if (isActive) {
            badge.innerText = '🟢 กำลังจัดกิจกรรม (LIVE NOW)';
            badge.style.borderColor = '#10b981';
            badge.style.color = '#34d399';
            badge.style.background = 'rgba(16,185,129,0.2)';
        } else {
            badge.innerText = '⏸️ พักกิจกรรมชั่วคราว (PAUSED)';
            badge.style.borderColor = '#f59e0b';
            badge.style.color = '#fbbf24';
            badge.style.background = 'rgba(245,158,11,0.2)';
        }
    }
    if (toggleBtn) {
        toggleBtn.innerText = isActive ? '⏸️ พัก/ปิดกิจกรรมนี้' : '▶️ เปิดใช้งานกิจกรรมนี้';
        toggleBtn.className = isActive ? 'btn btn-danger' : 'btn btn-accent';
    }

    const titleEl = document.getElementById('active_dice_ev_name');
    if (titleEl) titleEl.innerText = ev.event_name || 'กิจกรรมสุ่มลูกเต๋า 3D';

    const td = ev.target_dice || adminDiceListCache.find(x => parseInt(x.id) === parseInt(ev.target_dice_id)) || null;
    const swatch = document.getElementById('active_dice_ev_swatch');
    const gradeEl = document.getElementById('active_dice_ev_grade');
    const nameEl = document.getElementById('active_dice_ev_target_name');
    const ctrlEl = document.getElementById('active_dice_ev_ctrl');
    const auraEl = document.getElementById('active_dice_ev_aura');

    if (td) {
        const bodyColor = td.color_hex || '#1e1b4b';
        const pipColor = td.pip_color_hex || '#00e5ff';
        const auraColor = DICE_AURA_COLORS[td.aura_type || 'cyan'] || '#00e5ff';

        if (swatch) {
            swatch.style.background = bodyColor;
            swatch.style.borderColor = pipColor;
            swatch.style.color = pipColor;
            swatch.style.boxShadow = `0 0 16px ${auraColor}`;
        }
        if (gradeEl) {
            gradeEl.innerText = td.grade || 'A';
            if (String(td.grade).includes('Z')) gradeEl.style.background = '#f43f5e';
            else if (String(td.grade).includes('SS')) gradeEl.style.background = '#ffd700';
            else gradeEl.style.background = '#00e5ff';
        }
        if (nameEl) nameEl.innerText = td.name || `ลูกเต๋า #${td.id}`;
        if (ctrlEl) ctrlEl.innerText = `${parseFloat(td.dice_control_rate || 10).toFixed(0)}%`;
        if (auraEl) auraEl.innerText = `${td.aura_type || 'none'} (${td.aura_intensity || 100}%)`;
    }

    const costEl = document.getElementById('active_dice_ev_cost');
    if (costEl) costEl.innerText = `${ev.cost_diamond || 100} เพชร`;

    const boostEl = document.getElementById('active_dice_ev_boost');
    if (boostEl) boostEl.innerText = `+${parseFloat(ev.rate_target_boost || 35).toFixed(2)}%`;

    const periodEl = document.getElementById('active_dice_ev_period');
    if (periodEl) {
        const s = (ev.start_date || '').substring(0, 16);
        const e = (ev.end_date || '').substring(0, 16);
        periodEl.innerText = `${s} ถึง ${e}`;
    }
}

function renderDiceEventsTable(events) {
    const tbody = document.getElementById('dice_events_table_body');
    if (!tbody) return;
    if (!Array.isArray(events) || events.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:16px;">ยังไม่มีกิจกรรมสุ่มลูกเต๋าในระบบ</td></tr>';
        return;
    }

    let html = '';
    events.forEach(ev => {
        const isActive = (parseInt(ev.is_active) === 1);
        const td = ev.target_dice || adminDiceListCache.find(x => parseInt(x.id) === parseInt(ev.target_dice_id));
        const tdName = td ? `[${td.grade}] ${td.name}` : `ลูกเต๋า #${ev.target_dice_id}`;
        const tdColor = td?.color_hex || '#00e5ff';
        const tdPip = td?.pip_color_hex || '#fff';

        html += `
            <tr style="${isActive ? 'background:rgba(16,185,129,0.06);' : ''}">
                <td><strong>#${ev.id}</strong></td>
                <td>
                    <div style="font-weight:700; color:#fff;">${ev.event_name}</div>
                    <div style="font-size:11px; color:var(--text-muted);">${(ev.description || '').substring(0, 45)}...</div>
                </td>
                <td>
                    <div style="display:inline-flex; align-items:center; gap:6px;">
                        <span style="width:14px; height:14px; border-radius:3px; background:${tdColor}; border:1px solid ${tdPip};"></span>
                        <strong style="color:#00e5ff;">${tdName}</strong>
                    </div>
                </td>
                <td><strong style="color:#38bdf8;">💎 ${ev.cost_diamond}</strong></td>
                <td><span style="color:#ffd700; font-weight:800;">+${parseFloat(ev.rate_target_boost).toFixed(0)}%</span></td>
                <td style="font-size:11px; color:#cbd5e1;">${(ev.start_date || '').substring(0, 10)} &rarr; ${(ev.end_date || '').substring(0, 10)}</td>
                <td>
                    ${isActive ? 
                        '<span style="background:rgba(16,185,129,0.2); border:1px solid #10b981; color:#34d399; font-size:11px; font-weight:800; padding:2px 8px; border-radius:4px;">🟢 เปิดใช้งาน</span>' : 
                        '<span style="background:rgba(148,163,184,0.15); border:1px solid #64748b; color:#94a3b8; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px;">⏸️ พัก</span>'
                    }
                </td>
                <td>
                    <div style="display:flex; gap:6px; flex-wrap:wrap;">
                        <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:#0284c7; color:#fff;" onclick="editDiceEvent(${ev.id})">
                            ✏️ แก้ไข
                        </button>
                        <button type="button" class="btn" style="padding:4px 8px; font-size:11px; background:${isActive ? '#eab308' : '#10b981'}; color:#000; font-weight:700;" onclick="toggleDiceEventActive(${ev.id})">
                            ${isActive ? '⏸️ พัก' : '▶️ เปิด'}
                        </button>
                        <button type="button" class="btn btn-danger" style="padding:4px 8px; font-size:11px;" onclick="deleteDiceEvent(${ev.id})">
                            🗑️ ลบ
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = html;
}

function resetDiceEventForm() {
    document.getElementById('dice_ev_id').value = 0;
    document.getElementById('dice_ev_name').value = '🎲 เทศกาลสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับเต๋าแรร์เรตอัป';
    document.getElementById('dice_ev_cost_diamond').value = 100;
    document.getElementById('dice_ev_rate_target_boost').value = 35.0;
    document.getElementById('dice_ev_description').value = 'เปิดสุ่มลูกเต๋า 3D สุดพิเศษ ลุ้นรับลูกเต๋าเป้าหมายเรตอัป พร้อมเอฟเฟกต์แสงเออร่าและพลังการคุมเต๋าขั้นสูงสุด';
    document.getElementById('dice_ev_is_active').checked = true;

    const now = new Date();
    const future = new Date(now.getTime() + (30 * 24 * 60 * 60 * 1000));
    const pad = n => String(n).padStart(2, '0');
    const toDt = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    
    document.getElementById('dice_ev_start_date').value = toDt(now);
    document.getElementById('dice_ev_end_date').value = toDt(future);

    const delBtn = document.getElementById('btn_delete_dice_ev');
    if (delBtn) delBtn.style.display = 'none';

    const modeBadge = document.getElementById('dice_ev_form_mode_badge');
    if (modeBadge) {
        modeBadge.innerText = 'โหมด: สร้างใหม่';
        modeBadge.style.color = '#c084fc';
        modeBadge.style.background = 'rgba(168,85,247,0.2)';
    }

    const titleEl = document.getElementById('dice_ev_form_title');
    if (titleEl) titleEl.innerText = '📝 ฟอร์มสร้างกิจกรรมสุ่มลูกเต๋าใหม่';
}

function editDiceEvent(evId) {
    const ev = adminDiceEventsCache.find(x => parseInt(x.id) === parseInt(evId));
    if (!ev) return;

    document.getElementById('dice_ev_id').value = ev.id;
    document.getElementById('dice_ev_name').value = ev.event_name || '';
    document.getElementById('dice_ev_cost_diamond').value = ev.cost_diamond || 100;
    document.getElementById('dice_ev_target_dice_id').value = ev.target_dice_id || 1;
    document.getElementById('dice_ev_rate_target_boost').value = parseFloat(ev.rate_target_boost || 35.0);
    document.getElementById('dice_ev_description').value = ev.description || '';
    document.getElementById('dice_ev_is_active').checked = (parseInt(ev.is_active) === 1);

    if (ev.start_date) {
        document.getElementById('dice_ev_start_date').value = ev.start_date.substring(0, 16).replace(' ', 'T');
    }
    if (ev.end_date) {
        document.getElementById('dice_ev_end_date').value = ev.end_date.substring(0, 16).replace(' ', 'T');
    }

    const delBtn = document.getElementById('btn_delete_dice_ev');
    if (delBtn) delBtn.style.display = 'inline-block';

    const modeBadge = document.getElementById('dice_ev_form_mode_badge');
    if (modeBadge) {
        modeBadge.innerText = `โหมด: แก้ไขกิจกรรม ID #${ev.id}`;
        modeBadge.style.color = '#ffd700';
        modeBadge.style.background = 'rgba(255,215,0,0.2)';
    }

    const titleEl = document.getElementById('dice_ev_form_title');
    if (titleEl) titleEl.innerText = `✏️ แก้ไขกิจกรรมสุ่มลูกเต๋า #${ev.id}`;

    const form = document.getElementById('diceEventCampaignForm');
    if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });

    showToast(`📝 โหลดข้อมูลกิจกรรม '#${ev.id}' ขึ้นมาแก้ไขแล้ว`);
}

function editCurrentActiveDiceEvent() {
    if (currentActiveDiceEventObj) {
        editDiceEvent(currentActiveDiceEventObj.id);
    }
}

async function submitSaveDiceEvent(e) {
    if (e && e.preventDefault) e.preventDefault();

    const evId = parseInt(document.getElementById('dice_ev_id')?.value || 0);
    const name = (document.getElementById('dice_ev_name')?.value || '').trim();
    const cost = parseInt(document.getElementById('dice_ev_cost_diamond')?.value || 100);
    const targetDiceId = parseInt(document.getElementById('dice_ev_target_dice_id')?.value || 1);
    const rateBoost = parseFloat(document.getElementById('dice_ev_rate_target_boost')?.value || 35.0);
    const desc = document.getElementById('dice_ev_description')?.value || '';
    const sDate = document.getElementById('dice_ev_start_date')?.value || '';
    const eDate = document.getElementById('dice_ev_end_date')?.value || '';
    const isActive = document.getElementById('dice_ev_is_active')?.checked ? 1 : 0;

    if (!name) {
        alert('กรุณากรอกชื่อกิจกรรม');
        return;
    }

    try {
        const payload = {
            id: evId,
            event_name: name,
            cost_diamond: cost,
            target_dice_id: targetDiceId,
            rate_target_boost: rateBoost,
            description: desc,
            start_date: sDate ? sDate.replace('T', ' ') + ':00' : undefined,
            end_date: eDate ? eDate.replace('T', ' ') + ':00' : undefined,
            is_active: isActive
        };

        const res = await fetch('admin_panel.php?api=1&action=save_dice_event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(`✅ ${res.message}`);
            await loadDiceEventsAdmin();
            resetDiceEventForm();
        } else {
            alert('เกิดข้อผิดพลาด: ' + (res?.message || 'ไม่สามารถบันทึกได้'));
        }
    } catch (err) {
        console.error('submitSaveDiceEvent error:', err);
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
    }
}

async function deleteDiceEvent(evId) {
    if (!confirm(`คุณแน่ใจหรือไม่ว่าต้องการลบกิจกรรมสุ่มลูกเต๋า #${evId}? การกระทำนี้ไม่สามารถเรียกคืนได้`)) {
        return;
    }

    try {
        const res = await fetch('admin_panel.php?api=1&action=delete_dice_event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: evId })
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(`🗑️ ${res.message}`);
            await loadDiceEventsAdmin();
            resetDiceEventForm();
        } else {
            alert('ไม่สามารถลบกิจกรรมได้: ' + (res?.message || 'เกิดข้อผิดพลาด'));
        }
    } catch (err) {
        console.error('deleteDiceEvent error:', err);
        alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
    }
}

function deleteDiceEventFromForm() {
    const evId = parseInt(document.getElementById('dice_ev_id')?.value || 0);
    if (evId > 0) {
        deleteDiceEvent(evId);
    }
}

async function toggleDiceEventActive(evId) {
    try {
        const res = await fetch('admin_panel.php?api=1&action=toggle_dice_event_active', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: evId })
        }).then(r => r.json());

        if (res && res.status === 'success') {
            showToast(`⚡ ${res.message}`);
            await loadDiceEventsAdmin();
        } else {
            alert('ไม่สามารถเปลี่ยนสถานะได้: ' + (res?.message || 'เกิดข้อผิดพลาด'));
        }
    } catch (err) {
        console.error('toggleDiceEventActive error:', err);
    }
}

function toggleActiveDiceEventFromOverview() {
    if (currentActiveDiceEventObj) {
        toggleDiceEventActive(currentActiveDiceEventObj.id);
    }
}

function previewSelectedEventDice(diceId) {
    const d = adminDiceListCache.find(x => parseInt(x.id) === parseInt(diceId));
    if (d) {
        showToast(`🎲 เลือกลูกเต๋าเป้าหมาย: [${d.grade}] ${d.name}`);
    }
}

function switchTab(tabId) {
    if (!tabId) return;
    document.querySelectorAll('.sidebar-tab-btn, .tab-btn').forEach(btn => {
        btn.classList.remove('active');
        const dataTab = btn.getAttribute('data-tab') || '';
        const onclickAttr = btn.getAttribute('onclick') || '';
        if (dataTab === tabId || onclickAttr.includes(`'${tabId}'`)) {
            btn.classList.add('active');
        }
    });
    document.querySelectorAll('.tab-content').forEach(c => {
        c.classList.remove('active');
        c.style.display = 'none';
    });
    const target = document.getElementById('tab-' + tabId);
    if (target) {
        target.classList.add('active');
        target.style.display = 'block';
    }
    try {
        localStorage.setItem('snake_admin_active_tab', tabId);
    } catch (e) {}

    if (tabId === 'daily_rewards' && typeof loadDailyRewards === 'function') loadDailyRewards();
    if (tabId === 'sell_prices' && typeof loadSellPrices === 'function') loadSellPrices();
    if (tabId === 'gacha_event' && typeof loadGachaEventConfig === 'function') loadGachaEventConfig();
    if (tabId === 'frames' && typeof loadAdminFrames === 'function') loadAdminFrames();
    if (tabId === 'magic_cubes' && typeof loadMagicCubeConfigsAdmin === 'function') loadMagicCubeConfigsAdmin();
    if (tabId === 'room_economy' && typeof loadRoomEconomySettings === 'function') loadRoomEconomySettings();
    if (tabId === 'ranking_settings' && typeof loadAdminRankingSettings === 'function') loadAdminRankingSettings();
    if (tabId === 'mobile_app' && typeof loadMobileAppConfigAdmin === 'function') loadMobileAppConfigAdmin();
        if (tabId === 'thai_audio' && typeof window.loadThaiAudioEventsAdmin === 'function') window.loadThaiAudioEventsAdmin();
    if (tabId === 'shop_menus' && typeof window.loadAdminShopMenusTab === 'function') window.loadAdminShopMenusTab();
    if (tabId === 'board_studio' && typeof window.initAiBoardStudioTab === 'function') window.initAiBoardStudioTab();
    if (tabId === 'dice_creator') {
        if (typeof initAiDiceStudio === 'function') initAiDiceStudio();
        if (typeof loadDiceEventsAdmin === 'function') loadDiceEventsAdmin();
    }
    if (tabId === 'ai_creator') {
        if ((!adminFramesCache || adminFramesCache.length === 0) && typeof loadAdminFrames === 'function') {
            loadAdminFrames();
        }
        if (!aiShadowsState[0]?.image_url && typeof regenerateAllShadowPngsFromRing === 'function') {
            regenerateAllShadowPngsFromRing();
        }
        if (typeof renderAiExchangeTiersEditor === 'function') renderAiExchangeTiersEditor();
        if (typeof updateAiPreview === 'function') updateAiPreview();
    }
}

// Enable Drag & Drop on AI Frame Studio Dropzone
document.addEventListener('DOMContentLoaded', () => {
    const dz = document.getElementById('ai_dropzone');
    if (dz) {
        dz.addEventListener('dragover', (e) => {
            e.preventDefault();
            dz.style.borderColor = '#ffd700';
            dz.style.background = 'rgba(255,215,0,0.12)';
        });
        dz.addEventListener('dragleave', () => {
            dz.style.borderColor = 'var(--primary)';
            dz.style.background = 'rgba(6,182,212,0.05)';
        });
        dz.addEventListener('drop', (e) => {
            e.preventDefault();
            dz.style.borderColor = 'var(--primary)';
            dz.style.background = 'rgba(6,182,212,0.05)';
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
                processAiImage(e.dataTransfer.files[0]);
            }
        });
    }

    // Enable Drag & Drop on AI Dice Studio Dropzone
    const diceDz = document.getElementById('ai_dice_dropzone');
    if (diceDz) {
        diceDz.addEventListener('dragover', (e) => {
            e.preventDefault();
            diceDz.style.borderColor = '#00e5ff';
            diceDz.style.background = 'rgba(0,229,255,0.15)';
        });
        diceDz.addEventListener('dragleave', () => {
            diceDz.style.borderColor = '#a855f7';
            diceDz.style.background = 'rgba(168,85,247,0.06)';
        });
        diceDz.addEventListener('drop', (e) => {
            e.preventDefault();
            diceDz.style.borderColor = '#a855f7';
            diceDz.style.background = 'rgba(168,85,247,0.06)';
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleAiDiceImageSelect({ target: { files: [e.dataTransfer.files[0]] } });
            }
        });
    }

    if (typeof initAiDiceStudio === 'function') {
        initAiDiceStudio();
    }
    if (typeof renderAiExchangeTiersEditor === 'function') {
        renderAiExchangeTiersEditor();
    }
    if (typeof updateAiPreview === 'function') {
        updateAiPreview();
    }
    const topBarImg = document.getElementById('top-bar-admin-avatar');
    if (topBarImg && currentAdminAvatarUrl) {
        topBarImg.src = currentAdminAvatarUrl;
    }
});

        // --- Mobile App Configuration & Remote Cache Buster Scripts ---
        async function runAiAnalyzeUpdateSize(isFromModal = false) {
            try {
                const res = await fetch('admin_panel.php?api=1&action=analyze_ota_size').then(r => r.json());
                if (res && res.status === 'success' && res.data) {
                    const d = res.data;
                    const sizeVal = d.update_size || d.recommended_size || '2.8 MB';
                    const filesCount = d.files_count || d.file_count || 14;
                    const filesVal = (d.update_files_text || (filesCount + ' ไฟล์'));

                    const sizeEl = document.getElementById('mobile_update_size');
                    const filesEl = document.getElementById('mobile_update_files');
                    const modalSizeEl = document.getElementById('modal_ota_update_size');
                    const modalFilesEl = document.getElementById('modal_ota_update_files');

                    if (sizeEl) sizeEl.value = sizeVal;
                    if (filesEl) filesEl.value = filesVal;
                    if (modalSizeEl) modalSizeEl.value = sizeVal;
                    if (modalFilesEl) modalFilesEl.value = filesVal;

                    const summary = d.analysis_summary || `AI คำนวณขนาดและจำนวนไฟล์อัปเดต: ${sizeVal} (${filesVal})`;
                    const badge = document.getElementById('ai_size_analysis_badge');
                    if (badge) {
                        badge.style.display = 'block';
                        badge.innerHTML = `🤖 <strong>${summary}</strong><br><span style="color:#94a3b8; font-size:10.5px;">ขนาดรวมปัจจุบัน: <b style="color:#ffd700;">${sizeVal}</b> | จำนวน: <b style="color:#10b981;">${filesVal}</b></span>`;
                    }
                    const modalBadge = document.getElementById('modal_ai_size_badge');
                    if (modalBadge) {
                        modalBadge.style.display = 'block';
                        modalBadge.innerHTML = `🤖 ${summary}`;
                    }
                    showToast(`✨ AI วิเคราะห์ขนาดและจำนวนไฟล์สำเร็จ: ${sizeVal} (${filesVal})`);
                    return d;
                } else {
                    showToast('❌ ไม่สามารถวิเคราะห์ขนาดไฟล์ได้: ' + (res?.message || 'Unknown error'), 'error');
                }
            } catch (e) {
                console.error('runAiAnalyzeUpdateSize error:', e);
                showToast('❌ เกิดข้อผิดพลาดในการวิเคราะห์ขนาดไฟล์: ' + (e.message || ''), 'error');
            }
            return null;
        }

        async function loadMobileAppConfigAdmin() {
            try {
                const res = await fetch('admin_panel.php?api=1&action=get_mobile_app_config').then(r => r.json());
                if (res && res.status === 'success' && res.data) {
                    const d = res.data;
                    const urlEl = document.getElementById('mobile_game_url');
                    const verEl = document.getElementById('mobile_app_version');
                    const cacheEl = document.getElementById('mobile_cache_version');
                    const forceEl = document.getElementById('mobile_force_clear_cache');
                    const maintEl = document.getElementById('mobile_maintenance_mode');
                    const maintMsgEl = document.getElementById('mobile_maintenance_msg');
                    const sizeEl = document.getElementById('mobile_update_size');
                    const filesEl = document.getElementById('mobile_update_files');

                    if (urlEl) urlEl.value = d.game_url || 'https://pmix01.thddns.net:7175/home/snake/';
                    if (verEl) verEl.value = d.app_version || '1.0.0';
                    if (cacheEl) cacheEl.value = d.cache_version || 124;
                    if (forceEl) forceEl.checked = Boolean(d.force_clear_cache);
                    if (maintEl) maintEl.checked = Boolean(d.maintenance);
                    if (maintMsgEl) maintMsgEl.value = d.maintenance_message || 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง';
                    if (sizeEl) sizeEl.value = d.update_size || '2.8 MB';
                    if (filesEl) filesEl.value = d.update_files_text || ((d.file_count || 14) + ' ไฟล์');
                }

                // ดึงผลลัพธ์จาก api/app_config.php สดมาแสดงในช่อง Preview
                const apiRes = await fetch('../api/app_config.php?t=' + Date.now()).then(r => r.json()).catch(() => null);
                const pre = document.getElementById('mobile_app_json_preview');
                if (pre && apiRes) {
                    pre.innerText = JSON.stringify(apiRes, null, 2);
                }
            } catch (e) {
                console.error('loadMobileAppConfigAdmin error:', e);
            }
        }

        async function saveMobileAppConfigAdmin() {
            const urlEl = document.getElementById('mobile_game_url');
            const verEl = document.getElementById('mobile_app_version');
            const cacheEl = document.getElementById('mobile_cache_version');
            const forceEl = document.getElementById('mobile_force_clear_cache');
            const maintEl = document.getElementById('mobile_maintenance_mode');
            const maintMsgEl = document.getElementById('mobile_maintenance_msg');
            const sizeEl = document.getElementById('mobile_update_size');
            const filesEl = document.getElementById('mobile_update_files');

            const fileCountVal = filesEl ? parseInt(filesEl.value.replace(/[^0-9]/g, ''), 10) || 14 : 14;

            const payload = {
                game_url: urlEl ? urlEl.value.trim() : 'https://pmix01.thddns.net:7175/home/snake/',
                app_version: verEl ? verEl.value.trim() : '1.0.0',
                cache_version: cacheEl ? parseInt(cacheEl.value, 10) : 124,
                force_clear_cache: forceEl ? forceEl.checked : false,
                maintenance: maintEl ? maintEl.checked : false,
                maintenance_message: maintMsgEl ? maintMsgEl.value.trim() : 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง',
                update_size: sizeEl ? sizeEl.value.trim() : '2.8 MB',
                file_count: fileCountVal,
                update_files: fileCountVal
            };

            try {
                const res = await fetch('admin_panel.php?api=1&action=save_mobile_app_config', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    showToast(res.message);
                    await loadMobileAppConfigAdmin();
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res.message || 'ไม่สามารถบันทึกได้'));
                }
            } catch (e) {
                console.error('saveMobileAppConfigAdmin error:', e);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        // --- OTA Deploy Modal & Realtime Status Popup ---
        function openOtaDeployModal() {
            const modal = document.getElementById('modal-admin-ota-deploy');
            if (!modal) return;

            // ตั้งค่าเริ่มต้นจากฟอร์มหลัก
            const appVer = document.getElementById('mobile_app_version')?.value || '1.0.0';
            const sizeVal = document.getElementById('mobile_update_size')?.value || '2.8 MB';
            const filesVal = document.getElementById('mobile_update_files')?.value || '14 ไฟล์';
            const forceClear = document.getElementById('mobile_force_clear_cache')?.checked ?? true;

            const modalVer = document.getElementById('modal_ota_app_version');
            const modalSize = document.getElementById('modal_ota_update_size');
            const modalFiles = document.getElementById('modal_ota_update_files');
            const modalForce = document.getElementById('modal_ota_force_clear');
            const modalNote = document.getElementById('modal_ota_release_note');

            if (modalVer) modalVer.value = appVer;
            if (modalSize) modalSize.value = sizeVal;
            if (modalFiles) modalFiles.value = filesVal;
            if (modalForce) modalForce.checked = forceClear;
            if (modalNote) modalNote.value = 'อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล';

            // แสดงหน้า Form ซ่อนหน้า Loading และ Success
            const sForm = document.getElementById('ota_modal_step_form');
            const sLoad = document.getElementById('ota_modal_step_loading');
            const sSucc = document.getElementById('ota_modal_step_success');
            if (sForm) sForm.style.display = 'block';
            if (sLoad) sLoad.style.display = 'none';
            if (sSucc) sSucc.style.display = 'none';

            modal.style.display = 'flex';
        }

        function closeOtaDeployModal() {
            const modal = document.getElementById('modal-admin-ota-deploy');
            if (modal) modal.style.display = 'none';
        }

        async function submitOtaDeployFromModal() {
            const sForm = document.getElementById('ota_modal_step_form');
            const sLoad = document.getElementById('ota_modal_step_loading');
            const sSucc = document.getElementById('ota_modal_step_success');

            const appVer = document.getElementById('modal_ota_app_version')?.value || '1.0.0';
            const updateSize = document.getElementById('modal_ota_update_size')?.value || '2.8 MB';
            const updateFiles = document.getElementById('modal_ota_update_files')?.value || '14 ไฟล์';
            const filesCountNum = parseInt(updateFiles.replace(/[^0-9]/g, ''), 10) || 14;
            const releaseNote = document.getElementById('modal_ota_release_note')?.value || 'OTA Deploy Update';
            const forceClear = document.getElementById('modal_ota_force_clear')?.checked ?? true;
            const gameUrl = document.getElementById('mobile_game_url')?.value || 'https://pmix01.thddns.net:7175/home/snake/';

            // สลับไปหน้า Loading
            if (sForm) sForm.style.display = 'none';
            if (sLoad) sLoad.style.display = 'block';
            if (sSucc) sSucc.style.display = 'none';

            try {
                const rawResp = await fetch('admin_panel.php?api=1&action=deploy_ota_update', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                    body: JSON.stringify({
                        app_version: appVer,
                        update_size: updateSize,
                        file_count: filesCountNum,
                        update_files: filesCountNum,
                        force_clear_cache: forceClear,
                        game_url: gameUrl,
                        release_note: releaseNote
                    })
                });
                const rawText = await rawResp.text();
                let res = null;
                try {
                    res = JSON.parse(rawText);
                } catch (jsonErr) {
                    const idx = rawText.indexOf('{"status"');
                    if (idx >= 0) {
                        res = JSON.parse(rawText.slice(idx));
                    } else {
                        throw new Error('เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ (HTTP ' + rawResp.status + ')');
                    }
                }

                if (res && res.status === 'success') {
                    const elBuster = document.getElementById('res_cache_buster');
                    const elVer = document.getElementById('res_version_code');
                    const elSize = document.getElementById('res_update_size');
                    const elCount = document.getElementById('res_affected_count');
                    const elTime = document.getElementById('res_deployed_time');

                    if (elBuster) elBuster.innerText = res.cache_buster || '-';
                    if (elVer) elVer.innerText = res.version_code || appVer;
                    if (elSize) elSize.innerText = res.update_size || updateSize;
                    if (elCount) elCount.innerText = res.file_count || res.affected_files_count || filesCountNum;
                    if (elTime) elTime.innerText = res.last_deployed_at || new Date().toLocaleString();

                    if (sLoad) sLoad.style.display = 'none';
                    if (sSucc) sSucc.style.display = 'block';

                    if (typeof showToast === 'function') {
                        showToast(`🚀 ${res.message}`);
                    }
                    loadMobileAppConfigAdmin().catch(() => {});
                } else {
                    if (sLoad) sLoad.style.display = 'none';
                    if (sForm) sForm.style.display = 'block';
                    alert('เกิดข้อผิดพลาด: ' + (res?.message || 'ไม่สามารถปล่อยอัปเดตได้'));
                }
            } catch (e) {
                console.error('submitOtaDeployFromModal error:', e);
                if (sLoad) sLoad.style.display = 'none';
                if (sForm) sForm.style.display = 'block';
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์ (' + (e && e.message ? e.message : 'กรุณารีเฟรชหน้า Admin 1 ครั้งแล้วลองใหม่') + ')');
            }
        }

        // =========================================================================
        // 🎵 THAI VOICE & SFX STUDIO ADMIN CONTROLLER (สตูดิโอจัดการเสียงพากย์ไทย & SFX)
        // =========================================================================
        window.adminAudioEventsMap = {};
        window.adminAudioUpdatedAt = Date.now();
        window.adminPreviewAudioObj = null;
        window.adminPreviewPlayingKey = '';
        window.adminEditingFilesTemp = [];

        const ADMIN_AUDIO_PRESETS = {
            'malei': { name: 'เสียงพากย์เริ่มเกม ("มาเลยๆ")', desc: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "มาเลยๆ" เมื่อเริ่มการแข่งขัน', type: 'voice', defaultFile: 'malei.mp3' },
            'yeay': { name: 'เสียงได้เริ่มคนแรก ("เย้! ได้ทอยเป็นคนแรก")', desc: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "เย้! ได้ทอยเป็นคนแรก"', type: 'voice', defaultFile: 'yeay.mp3' },
            'dice_roll': { name: 'เสียงทอยลูกเต๋า (Dice Roll)', desc: 'เอฟเฟกต์ลูกเต๋าหมุนกระทบพื้นกระดาน (Dice Roll SFX)', type: 'sfx', defaultFile: 'dice.mp3' },
            'step': { name: 'เสียงเดินนับช่อง (Step SFX)', desc: 'เสียงก้าวเดินสั้นๆ ตามจำนวนแต้มลูกเต๋าในแต่ละช่อง', type: 'sfx', defaultFile: 'walk.mp3' },
            'double': { name: 'เสียงทอยได้แต้มดับเบิล ("ดับเบิล!")', desc: 'เด็กผู้หญิงพูดภาษาไทยชัดเจนว่า "ดับเบิล!"', type: 'voice', defaultFile: 'double.mp3' },
            'island_trap': { name: 'เสียงตกเกาะ / ติดคุก ("หือๆๆ ติดเกาะซะแล้ว")', desc: 'เด็กผู้หญิงร้องไห้/บ่นภาษาไทยว่า "หือๆๆ ติดเกาะซะแล้ว"', type: 'voice', defaultFile: 'tok-koh.mp3' },
            'ladder_climb': { name: 'เสียงไต่บันไดขึ้น ("เย้! ขึ้นบันไดลัด!")', desc: 'เล่นเมื่อตัวละครตกช่องบันไดและไต่ขึ้นด้านบน', type: 'voice', defaultFile: '' },
            'snake_bite': { name: 'เสียงตกช่องงู ("ว้าย! โดนงูกัดไหลลงเลย")', desc: 'เล่นเมื่อตัวละครตกช่องหัวงูและสไลด์ลง', type: 'voice', defaultFile: '' },
            'build_landmark': { name: 'เสียงสร้างแลนด์มาร์คสำเร็จ ("แลนด์มาร์คของฉัน!")', desc: 'เล่นเมื่อผู้เล่นอัปเกรดเป็นแลนด์มาร์คสำเร็จ', type: 'voice', defaultFile: '' },
            'victory': { name: 'เสียงชนะการแข่งขัน ("เย้! ชนะที่หนึ่งแล้ว!")', desc: 'เล่นเมื่อจบเกมและคว้าชัยชนะ', type: 'voice', defaultFile: '' },
            'bankrupt': { name: 'เสียงล้มละลาย ("แงๆ หมดตัวเลย")', desc: 'เล่นเมื่อผู้เล่นล้มละลายในกระดาน', type: 'voice', defaultFile: '' },
            'step_1': { name: 'เสียงนับก้าวเดินที่ 1 ("หนึ่ง")', desc: 'เสียงพากย์นับก้าวที่ 1 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_2': { name: 'เสียงนับก้าวเดินที่ 2 ("สอง")', desc: 'เสียงพากย์นับก้าวที่ 2 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_3': { name: 'เสียงนับก้าวเดินที่ 3 ("สาม")', desc: 'เสียงพากย์นับก้าวที่ 3 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_4': { name: 'เสียงนับก้าวเดินที่ 4 ("สี่")', desc: 'เสียงพากย์นับก้าวที่ 4 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_5': { name: 'เสียงนับก้าวเดินที่ 5 ("ห้า")', desc: 'เสียงพากย์นับก้าวที่ 5 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_6': { name: 'เสียงนับก้าวเดินที่ 6 ("หก")', desc: 'เสียงพากย์นับก้าวที่ 6 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_7': { name: 'เสียงนับก้าวเดินที่ 7 ("เจ็ด")', desc: 'เสียงพากย์นับก้าวที่ 7 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_8': { name: 'เสียงนับก้าวเดินที่ 8 ("แปด")', desc: 'เสียงพากย์นับก้าวที่ 8 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_9': { name: 'เสียงนับก้าวเดินที่ 9 ("เก้า")', desc: 'เสียงพากย์นับก้าวที่ 9 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_10': { name: 'เสียงนับก้าวเดินที่ 10 ("สิบ")', desc: 'เสียงพากย์นับก้าวที่ 10 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_11': { name: 'เสียงนับก้าวเดินที่ 11 ("สิบเอ็ด")', desc: 'เสียงพากย์นับก้าวที่ 11 ขณะเดินหมาก', type: 'voice', defaultFile: '' },
            'step_12': { name: 'เสียงนับก้าวเดินที่ 12 ("สิบสอง")', desc: 'เสียงพากย์นับก้าวที่ 12 ขณะเดินหมาก', type: 'voice', defaultFile: '' }
        };

        const BUILTIN_AUDIO_KEYS = ['malei', 'yeay', 'dice_roll', 'step', 'double', 'island_trap'];

        function escAudioHtml(str) {
            return String(str == null ? '' : str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        window.loadThaiAudioEventsAdmin = async function() {
            const tbody = document.getElementById('thai-audio-table-body');
            if (!tbody) return;

            if (Object.keys(window.adminAudioEventsMap).length === 0) {
                tbody.innerHTML = `<tr><td colspan="8" style="padding:28px; text-align:center; color:#94a3b8; font-size:13px;">⏳ กำลังโหลดรายการเสียงพากย์ไทยและเอฟเฟกต์...</td></tr>`;
            }

            try {
                const res = await fetch('../api/audio_settings.php?action=get_config&t=' + Date.now()).then(r => r.json());
                if (res && res.status === 'success' && res.events) {
                    window.adminAudioEventsMap = res.events;
                    window.adminAudioUpdatedAt = res.updatedAt || Math.floor(Date.now() / 1000);
                    window.renderThaiAudioTable();
                    return;
                }
            } catch (err) {
                console.error('loadThaiAudioEventsAdmin error:', err);
            }

            // Fallback if API unreachable
            if (Object.keys(window.adminAudioEventsMap).length === 0) {
                BUILTIN_AUDIO_KEYS.forEach(k => {
                    const p = ADMIN_AUDIO_PRESETS[k];
                    window.adminAudioEventsMap[k] = {
                        name: p.name,
                        description: p.desc,
                        type: p.type,
                        files: p.defaultFile ? [p.defaultFile] : [],
                        volume: k === 'dice_roll' ? 0.9 : (k === 'step' ? 0.85 : 1.0),
                        enabled: true
                    };
                });
            }
            window.renderThaiAudioTable();
        };

        window.renderThaiAudioTable = function() {
            const tbody = document.getElementById('thai-audio-table-body');
            if (!tbody) return;

            const keys = Object.keys(window.adminAudioEventsMap || {});
            if (keys.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" style="padding:32px; text-align:center; color:#94a3b8;">
                            ยังไม่มีรายการเหตุการณ์เสียง กดปุ่ม <strong style="color:#f472b6;">➕ เพิ่มเหตุการณ์เสียงใหม่</strong> หรือ <strong style="color:#38bdf8;">🔄 คืนค่าเสียงเริ่มต้น</strong> ด้านบน
                        </td>
                    </tr>`;
                return;
            }

            tbody.innerHTML = keys.map(rawKey => {
                const key = String(rawKey).replace(/[^a-zA-Z0-9_\-]/g, '_');
                const ev = window.adminAudioEventsMap[rawKey] || {};
                const isVoice = ev.type !== 'sfx';
                const isEnabled = ev.enabled !== false;
                const isBuiltin = BUILTIN_AUDIO_KEYS.includes(key);
                const files = Array.isArray(ev.files) ? ev.files : [];
                const volPct = Math.round(((ev.volume !== undefined ? Number(ev.volume) : 1.0) || 0) * 100);
                const isPlayingThis = (window.adminPreviewPlayingKey === key);

                const filesBadgesHtml = files.length > 0
                    ? files.map((f, fIdx) => `
                        <span style="display:inline-flex; align-items:center; gap:5px; background:rgba(15,23,42,0.9); border:1px solid rgba(236,72,153,0.35); border-radius:6px; padding:3px 8px; margin:2px; font-size:11px; color:#f8fafc;">
                            <span style="cursor:pointer;" onclick="window.previewAdminAudioFile('${escAudioHtml(f)}', '${key}')" title="คลิกเพื่อฟังไฟล์นี้">🎵 ${escAudioHtml(f)}</span>
                            ${files.length > 1 ? `<button type="button" onclick="window.removeSingleAudioFileAdmin('${key}', ${fIdx})" style="background:none; border:none; color:#f87171; cursor:pointer; font-size:13px; line-height:1; padding:0 2px;" title="เอาไฟล์นี้ออก">&times;</button>` : ''}
                        </span>
                    `).join('')
                    : `<span style="font-size:11px; color:#f87171; font-style:italic;">⚠️ ยังไม่ได้อัปโหลดไฟล์ (.mp3 / .wav)</span>`;

                return `
                    <tr style="border-bottom:1px solid rgba(255,255,255,0.07); opacity:${isEnabled ? '1' : '0.58'}; transition:opacity 0.2s;">
                        <td style="padding:12px 10px; vertical-align:middle;">
                            <code style="background:rgba(236,72,153,0.14); color:#f472b6; padding:4px 8px; border-radius:6px; font-size:12px; font-weight:700; border:1px solid rgba(236,72,153,0.3);">${escAudioHtml(key)}</code>
                            <div style="margin-top:4px; font-size:10px; color:${isBuiltin ? '#34d399' : '#38bdf8'};">
                                ${isBuiltin ? '⭐ เหตุการณ์หลักของเกม' : '✨ เหตุการณ์เสริม'}
                            </div>
                        </td>
                        <td style="padding:12px 10px; vertical-align:middle;">
                            <div style="font-size:13px; font-weight:700; color:#f8fafc;">${escAudioHtml(ev.name || key)}</div>
                            <div style="font-size:11px; color:#94a3b8; margin-top:2px;">${escAudioHtml(ev.description || '-')}</div>
                            <div style="font-size:10px; color:#fbbf24; margin-top:3px;">🔉 ความดัง: ${volPct}%</div>
                        </td>
                        <td style="padding:12px 10px; vertical-align:middle;">
                            ${isVoice
                                ? `<span style="display:inline-block; background:rgba(236,72,153,0.18); color:#f472b6; border:1px solid rgba(236,72,153,0.4); padding:4px 9px; border-radius:999px; font-size:11px; font-weight:700;">🎤 พากย์ไทย</span>`
                                : `<span style="display:inline-block; background:rgba(56,189,248,0.18); color:#38bdf8; border:1px solid rgba(56,189,248,0.4); padding:4px 9px; border-radius:999px; font-size:11px; font-weight:700;">🔊 เอฟเฟกต์ SFX</span>`
                            }
                        </td>
                        <td style="padding:12px 10px; vertical-align:middle; max-width:240px;">
                            ${filesBadgesHtml}
                        </td>
                        <td style="padding:12px 10px; text-align:center; vertical-align:middle;">
                            <button type="button" onclick="window.previewAdminAudioEvent('${key}')" ${files.length === 0 ? 'disabled' : ''} style="background:${isPlayingThis ? 'linear-gradient(135deg,#ef4444,#dc2626)' : 'linear-gradient(135deg,#0284c7,#0ea5e9)'}; color:#fff; border:none; border-radius:8px; padding:6px 12px; font-size:12px; font-weight:700; cursor:${files.length === 0 ? 'not-allowed' : 'pointer'}; opacity:${files.length === 0 ? '0.4' : '1'}; white-space:nowrap;">
                                ${isPlayingThis ? '⏹️ หยุดฟัง' : '▶️ ฟังเสียง'}
                            </button>
                        </td>
                        <td style="padding:12px 10px; text-align:center; vertical-align:middle;">
                            <div style="display:flex; flex-direction:column; gap:5px; align-items:center;">
                                <label style="background:linear-gradient(135deg,#ec4899,#a855f7); color:#fff; padding:6px 11px; border-radius:8px; font-size:11px; font-weight:700; cursor:pointer; display:inline-flex; align-items:center; gap:5px; white-space:nowrap; margin:0; box-shadow:0 2px 10px rgba(236,72,153,0.25);">
                                    📤 อัปโหลด MP3/WAV
                                    <input type="file" accept=".mp3,.wav,.ogg,.m4a,audio/*" style="display:none;" onchange="window.handleRowAudioUpload('${key}', this, 'replace')">
                                </label>
                                <label style="background:rgba(255,255,255,0.07); color:#cbd5e1; border:1px dashed rgba(255,255,255,0.25); padding:3px 9px; border-radius:6px; font-size:10px; cursor:pointer; display:inline-flex; align-items:center; gap:4px; white-space:nowrap; margin:0;" title="เพิ่มไฟล์เสียงสุ่มเล่นร่วมกับไฟล์เดิม">
                                    ➕ เพิ่มไฟล์สุ่ม
                                    <input type="file" accept=".mp3,.wav,.ogg,.m4a,audio/*" style="display:none;" onchange="window.handleRowAudioUpload('${key}', this, 'append')">
                                </label>
                            </div>
                        </td>
                        <td style="padding:12px 10px; text-align:center; vertical-align:middle;">
                            <button type="button" onclick="window.toggleAdminAudioEnabled('${key}', ${isEnabled ? 'false' : 'true'})" style="background:${isEnabled ? 'rgba(16,185,129,0.18)' : 'rgba(100,116,139,0.22)'}; color:${isEnabled ? '#34d399' : '#94a3b8'}; border:1px solid ${isEnabled ? '#10b981' : 'rgba(148,163,184,0.35)'}; border-radius:999px; padding:5px 12px; font-size:11px; font-weight:800; cursor:pointer; white-space:nowrap;">
                                ${isEnabled ? '🟢 เปิดใช้งาน' : '⚪ ปิดเสียง'}
                            </button>
                        </td>
                        <td style="padding:12px 10px; text-align:center; vertical-align:middle;">
                            <div style="display:inline-flex; gap:6px; align-items:center;">
                                <button type="button" onclick="window.openEditAudioEventModal('${key}')" style="background:rgba(245,158,11,0.18); color:#fbbf24; border:1px solid rgba(245,158,11,0.45); border-radius:7px; padding:5px 10px; font-size:11px; font-weight:700; cursor:pointer; white-space:nowrap;">
                                    ✏️ แก้ไข
                                </button>
                                <button type="button" onclick="window.deleteAdminAudioEvent('${key}')" style="background:rgba(239,68,68,0.16); color:#f87171; border:1px solid rgba(239,68,68,0.4); border-radius:7px; padding:5px 10px; font-size:11px; font-weight:700; cursor:pointer; white-space:nowrap;">
                                    🗑️ ลบ
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
        };

        window.stopAdminAudioPreview = function() {
            if (window.adminPreviewAudioObj) {
                try {
                    window.adminPreviewAudioObj.pause();
                    window.adminPreviewAudioObj.currentTime = 0;
                } catch (e) {}
                window.adminPreviewAudioObj = null;
            }
            window.adminPreviewPlayingKey = '';
        };

        window.previewAdminAudioFile = function(filename, key) {
            if (!filename) return;
            if (window.adminPreviewPlayingKey === key && window.adminPreviewAudioObj) {
                window.stopAdminAudioPreview();
                window.renderThaiAudioTable();
                return;
            }
            window.stopAdminAudioPreview();

            const ev = window.adminAudioEventsMap[key] || {};
            const url = (filename.startsWith('http') || filename.startsWith('/'))
                ? filename
                : '../assets/audio/th/' + filename + '?t=' + Date.now();

            const audio = new Audio(url);
            audio.volume = Math.max(0.05, Math.min(1, ev.volume !== undefined ? Number(ev.volume) : 1.0));
            window.adminPreviewAudioObj = audio;
            window.adminPreviewPlayingKey = key || filename;
            window.renderThaiAudioTable();

            audio.onended = () => {
                window.stopAdminAudioPreview();
                window.renderThaiAudioTable();
            };
            audio.onerror = () => {
                window.stopAdminAudioPreview();
                window.renderThaiAudioTable();
                if (typeof showToast === 'function') {
                    showToast('❌ ไม่พบไฟล์เสียง ' + filename + ' บนเซิร์ฟเวอร์ กรุณาอัปโหลดไฟล์ใหม่');
                }
            };
            audio.play().catch(err => {
                window.stopAdminAudioPreview();
                window.renderThaiAudioTable();
                alert('ไม่สามารถเล่นเสียงได้: ' + err.message);
            });
        };

        window.previewAdminAudioEvent = function(key) {
            const ev = window.adminAudioEventsMap[key];
            if (!ev || !Array.isArray(ev.files) || ev.files.length === 0) {
                alert('ยังไม่มีไฟล์เสียงผูกกับเหตุการณ์นี้ กรุณากดอัปโหลดไฟล์ MP3 หรือ WAV ก่อนครับ');
                return;
            }
            if (window.adminPreviewPlayingKey === key && window.adminPreviewAudioObj) {
                window.stopAdminAudioPreview();
                window.renderThaiAudioTable();
                return;
            }
            const pick = ev.files[Math.floor(Math.random() * ev.files.length)];
            window.previewAdminAudioFile(pick, key);
        };

        window.handleRowAudioUpload = async function(eventKey, inputEl, mode) {
            if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
            const file = inputEl.files[0];
            const formData = new FormData();
            formData.append('action', 'upload_audio');
            formData.append('event_key', eventKey);
            formData.append('mode', mode || 'replace');
            formData.append('audio_file', file);

            if (typeof showToast === 'function') {
                showToast(`⏳ กำลังอัปโหลดไฟล์เสียง ${file.name}...`);
            }

            try {
                const res = await fetch('../api/audio_settings.php?action=upload_audio', {
                    method: 'POST',
                    body: formData
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    if (res.events) {
                        window.adminAudioEventsMap = res.events;
                    }
                    window.adminAudioUpdatedAt = res.updatedAt || Math.floor(Date.now() / 1000);
                    window.renderThaiAudioTable();
                    if (typeof showToast === 'function') {
                        showToast(`✅ ${res.message}`);
                    }
                } else {
                    alert('อัปโหลดไม่สำเร็จ: ' + (res?.message || 'เกิดข้อผิดพลาด'));
                }
            } catch (err) {
                console.error('handleRowAudioUpload error:', err);
                alert('เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยังเซิร์ฟเวอร์');
            } finally {
                inputEl.value = '';
            }
        };

        window.removeSingleAudioFileAdmin = async function(eventKey, fileIdx) {
            const ev = window.adminAudioEventsMap[eventKey];
            if (!ev || !Array.isArray(ev.files)) return;
            const removed = ev.files[fileIdx];
            if (!confirm(`ต้องการเอาไฟล์เสียง "${removed}" ออกจากเหตุการณ์ "${ev.name}" หรือไม่?`)) return;

            ev.files.splice(fileIdx, 1);
            await window.saveAllAudioEventsAdmin(true);
        };

        window.toggleAdminAudioEnabled = async function(eventKey, nextEnabled) {
            try {
                const res = await fetch('../api/audio_settings.php?action=toggle_item', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ event_key: eventKey, enabled: Boolean(nextEnabled) })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    window.adminAudioEventsMap = res.events || window.adminAudioEventsMap;
                    window.renderThaiAudioTable();
                    if (typeof showToast === 'function') showToast(`🎵 ${res.message}`);
                } else {
                    alert('ไม่สามารถเปลี่ยนสถานะเสียงได้: ' + (res?.message || ''));
                }
            } catch (err) {
                console.error('toggleAdminAudioEnabled error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        };

        window.deleteAdminAudioEvent = async function(eventKey) {
            const ev = window.adminAudioEventsMap[eventKey];
            const label = ev ? ev.name : eventKey;
            if (!confirm(`ยืนยันการลบรายการเสียง "${label}" (${eventKey}) ออกจากระบบหรือไม่?\n(คุณสามารถกดปุ่ม "🔄 คืนค่าเสียงเริ่มต้น" เพื่อกู้คืนเสียงหลักได้ตลอดเวลา)`)) {
                return;
            }
            window.stopAdminAudioPreview();
            try {
                const res = await fetch('../api/audio_settings.php?action=delete_item', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ event_key: eventKey })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    window.adminAudioEventsMap = res.events || {};
                    window.renderThaiAudioTable();
                    if (typeof showToast === 'function') showToast(`🗑️ ${res.message}`);
                } else {
                    alert('ลบไม่สำเร็จ: ' + (res?.message || ''));
                }
            } catch (err) {
                console.error('deleteAdminAudioEvent error:', err);
                alert('เกิดข้อผิดพลาดในการลบรายการเสียง');
            }
        };

        window.resetDefaultAudioEventsAdmin = async function() {
            if (!confirm('ต้องการคืนค่ารายการเสียงพากย์และเอฟเฟกต์เริ่มต้นทั้ง 6 รายการ (มาเลยๆ, เย้!, ทอยเต๋า, เดินนับช่อง, ดับเบิล!, ติดเกาะ) หรือไม่?\n(รายการเสียงเสริมที่คุณสร้างเพิ่มไว้จะยังคงอยู่ครบ)')) {
                return;
            }
            try {
                const res = await fetch('../api/audio_settings.php?action=reset_defaults', {
                    method: 'POST'
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    window.adminAudioEventsMap = res.events || {};
                    window.renderThaiAudioTable();
                    if (typeof showToast === 'function') showToast(`🔄 ${res.message}`);
                } else {
                    alert('คืนค่าไม่สำเร็จ: ' + (res?.message || ''));
                }
            } catch (err) {
                console.error('resetDefaultAudioEventsAdmin error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        };

        window.saveAllAudioEventsAdmin = async function(silentToast) {
            try {
                const res = await fetch('../api/audio_settings.php?action=save_events', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ events: window.adminAudioEventsMap })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    window.adminAudioEventsMap = res.events || window.adminAudioEventsMap;
                    window.renderThaiAudioTable();
                    if (typeof showToast === 'function') {
                        showToast(silentToast ? '✅ อัปเดตรายการไฟล์เสียงเรียบร้อยแล้ว' : `💾 ${res.message}`);
                    }
                } else {
                    alert('บันทึกไม่สำเร็จ: ' + (res?.message || ''));
                }
            } catch (err) {
                console.error('saveAllAudioEventsAdmin error:', err);
                alert('เกิดข้อผิดพลาดในการบันทึกการตั้งค่าเสียง');
            }
        };

        window.applyAdminAudioPreset = function(presetKey) {
            if (!presetKey || !ADMIN_AUDIO_PRESETS[presetKey]) return;
            const p = ADMIN_AUDIO_PRESETS[presetKey];
            const keyEl = document.getElementById('adm_audio_event_key');
            const nameEl = document.getElementById('adm_audio_name');
            const descEl = document.getElementById('adm_audio_desc');
            const typeEl = document.getElementById('adm_audio_type');
            if (keyEl && !keyEl.readOnly) keyEl.value = presetKey;
            if (nameEl) nameEl.value = p.name;
            if (descEl) descEl.value = p.desc;
            if (typeEl) typeEl.value = p.type;
            if (p.defaultFile && window.adminEditingFilesTemp.length === 0) {
                window.adminEditingFilesTemp = [p.defaultFile];
                window.renderModalEditingAudioFiles();
            }
        };

        window.renderModalEditingAudioFiles = function() {
            const wrap = document.getElementById('adm_audio_files_list');
            if (!wrap) return;
            if (!window.adminEditingFilesTemp || window.adminEditingFilesTemp.length === 0) {
                wrap.innerHTML = `<span style="font-size:12px; color:#94a3b8;">ยังไม่มีไฟล์เสียงเดิม (สามารถเลือกไฟล์ .mp3 หรือ .wav ด้านล่างเพื่ออัปโหลดได้ทันที)</span>`;
                return;
            }
            wrap.innerHTML = window.adminEditingFilesTemp.map((f, idx) => `
                <span style="display:inline-flex; align-items:center; gap:6px; background:rgba(236,72,153,0.15); border:1px solid rgba(236,72,153,0.4); color:#fff; padding:4px 10px; border-radius:8px; font-size:12px;">
                    🎵 ${escAudioHtml(f)}
                    <button type="button" onclick="window.removeTempModalAudioFile(${idx})" style="background:none; border:none; color:#fca5a5; cursor:pointer; font-size:14px; line-height:1; padding:0;">&times;</button>
                </span>
            `).join('');
        };

        window.removeTempModalAudioFile = function(idx) {
            window.adminEditingFilesTemp.splice(idx, 1);
            window.renderModalEditingAudioFiles();
        };

        window.openAddAudioEventModal = function() {
            const modal = document.getElementById('modal-admin-audio-event');
            if (!modal) return;

            document.getElementById('adm_audio_modal_title').innerText = '➕ เพิ่มเหตุการณ์เสียงพากย์ไทย / เอฟเฟกต์ใหม่';
            document.getElementById('adm_audio_orig_key').value = '';
            document.getElementById('adm_audio_preset_wrap').style.display = 'block';
            document.getElementById('adm_audio_preset').value = '';

            const keyEl = document.getElementById('adm_audio_event_key');
            keyEl.value = '';
            keyEl.readOnly = false;
            keyEl.style.opacity = '1';

            document.getElementById('adm_audio_name').value = '';
            document.getElementById('adm_audio_desc').value = '';
            document.getElementById('adm_audio_type').value = 'voice';
            document.getElementById('adm_audio_volume').value = '100';
            document.getElementById('adm_audio_vol_label').innerText = '100%';
            document.getElementById('adm_audio_enabled').checked = true;
            document.getElementById('adm_audio_upload_mode').value = 'replace';
            const fileInput = document.getElementById('adm_audio_file_input');
            if (fileInput) fileInput.value = '';

            window.adminEditingFilesTemp = [];
            window.renderModalEditingAudioFiles();

            modal.style.display = 'flex';
        };

        window.openEditAudioEventModal = function(eventKey) {
            const modal = document.getElementById('modal-admin-audio-event');
            const ev = window.adminAudioEventsMap[eventKey];
            if (!modal || !ev) return;

            document.getElementById('adm_audio_modal_title').innerText = `✏️ แก้ไขเหตุการณ์เสียง: ${eventKey}`;
            document.getElementById('adm_audio_orig_key').value = eventKey;
            document.getElementById('adm_audio_preset_wrap').style.display = 'none';

            const keyEl = document.getElementById('adm_audio_event_key');
            keyEl.value = eventKey;
            keyEl.readOnly = BUILTIN_AUDIO_KEYS.includes(eventKey);
            keyEl.style.opacity = keyEl.readOnly ? '0.7' : '1';

            document.getElementById('adm_audio_name').value = ev.name || '';
            document.getElementById('adm_audio_desc').value = ev.description || '';
            document.getElementById('adm_audio_type').value = ev.type === 'sfx' ? 'sfx' : 'voice';

            const volPct = Math.round(((ev.volume !== undefined ? Number(ev.volume) : 1.0) || 0) * 100);
            document.getElementById('adm_audio_volume').value = String(volPct);
            document.getElementById('adm_audio_vol_label').innerText = volPct + '%';
            document.getElementById('adm_audio_enabled').checked = ev.enabled !== false;
            document.getElementById('adm_audio_upload_mode').value = 'replace';
            const fileInput = document.getElementById('adm_audio_file_input');
            if (fileInput) fileInput.value = '';

            window.adminEditingFilesTemp = Array.isArray(ev.files) ? [...ev.files] : [];
            window.renderModalEditingAudioFiles();

            modal.style.display = 'flex';
        };

        window.closeAdminAudioModal = function() {
            const modal = document.getElementById('modal-admin-audio-event');
            if (modal) modal.style.display = 'none';
        };

        window.submitAdminAudioEventForm = async function(e) {
            if (e && e.preventDefault) e.preventDefault();

            const origKey = document.getElementById('adm_audio_orig_key').value.trim();
            const rawKey = document.getElementById('adm_audio_event_key').value.trim();
            const eventKey = rawKey.replace(/[^a-zA-Z0-9_\-]/g, '_');
            const name = document.getElementById('adm_audio_name').value.trim();
            const description = document.getElementById('adm_audio_desc').value.trim();
            const type = document.getElementById('adm_audio_type').value === 'sfx' ? 'sfx' : 'voice';
            const volume = Math.max(0, Math.min(1, (parseInt(document.getElementById('adm_audio_volume').value, 10) || 100) / 100));
            const enabled = document.getElementById('adm_audio_enabled').checked;
            const uploadMode = document.getElementById('adm_audio_upload_mode').value || 'replace';
            const fileInput = document.getElementById('adm_audio_file_input');
            const chosenFile = (fileInput && fileInput.files && fileInput.files[0]) ? fileInput.files[0] : null;

            if (!eventKey) {
                alert('กรุณากรอกรหัสเหตุการณ์ (Event Key) เช่น malei, victory, step_1');
                return;
            }
            if (!name) {
                alert('กรุณากรอกชื่อเรียกเหตุการณ์เสียง');
                return;
            }

            const submitBtn = document.getElementById('btn_adm_audio_submit');
            if (submitBtn) submitBtn.disabled = true;

            try {
                // 1. Save metadata & edited file list first
                const saveRes = await fetch('../api/audio_settings.php?action=save_item', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        orig_key: origKey,
                        event_key: eventKey,
                        name: name,
                        description: description,
                        type: type,
                        volume: volume,
                        enabled: enabled,
                        files: window.adminEditingFilesTemp
                    })
                }).then(r => r.json());

                if (!saveRes || saveRes.status !== 'success') {
                    alert('บันทึกข้อมูลไม่สำเร็จ: ' + (saveRes?.message || ''));
                    return;
                }

                window.adminAudioEventsMap = saveRes.events || window.adminAudioEventsMap;

                // 2. If user also selected a new MP3/WAV file inside the modal, upload it right away
                if (chosenFile) {
                    const formData = new FormData();
                    formData.append('action', 'upload_audio');
                    formData.append('event_key', eventKey);
                    formData.append('mode', uploadMode);
                    formData.append('event_name', name);
                    formData.append('event_desc', description);
                    formData.append('event_type', type);
                    formData.append('event_volume', String(volume));
                    formData.append('event_enabled', enabled ? '1' : '0');
                    formData.append('audio_file', chosenFile);

                    const upRes = await fetch('../api/audio_settings.php?action=upload_audio', {
                        method: 'POST',
                        body: formData
                    }).then(r => r.json());

                    if (!upRes || upRes.status !== 'success') {
                        alert('บันทึกหัวข้อสำเร็จ แต่ไฟล์เสียงอัปโหลดไม่ผ่าน: ' + (upRes?.message || ''));
                        window.renderThaiAudioTable();
                        return;
                    }
                    window.adminAudioEventsMap = upRes.events || window.adminAudioEventsMap;
                }

                window.renderThaiAudioTable();
                window.closeAdminAudioModal();
                if (typeof showToast === 'function') {
                    showToast(`✅ บันทึกเหตุการณ์เสียง "${name}" เรียบร้อยแล้ว!`);
                }
            } catch (err) {
                console.error('submitAdminAudioEventForm error:', err);
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            } finally {
                if (submitBtn) submitBtn.disabled = false;
            }
        };

        document.addEventListener('DOMContentLoaded', () => {
            if (document.getElementById('thai-audio-table-body')) {
                window.loadThaiAudioEventsAdmin();
            }
        });
    </script>

    <!-- ============================================== -->
    <!-- MODAL: OTA DEPLOY CONFIRMATION & REALTIME STATUS -->
    <!-- ============================================== -->
    <div id="modal-admin-ota-deploy" class="modal-overlay" style="display:none; position:fixed; inset:0; background:rgba(3,7,18,0.85); backdrop-filter:blur(10px); z-index:99999; justify-content:center; align-items:center; padding:16px;">
        <div class="glass-panel" style="width:100%; max-width:540px; background:linear-gradient(145deg, rgba(15,23,42,0.98), rgba(10,15,30,0.98)); border:2px solid #00e5ff; border-radius:18px; box-shadow:0 0 45px rgba(0,229,255,0.35); padding:24px; position:relative; animation:modalPopIn 0.25s ease-out;">
            <button onclick="closeOtaDeployModal()" style="position:absolute; top:16px; right:16px; background:none; border:none; color:#94a3b8; font-size:24px; cursor:pointer; line-height:1; transition:color 0.2s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
            
            <!-- Step 1: Form ยืนยันการปล่อยอัปเดต -->
            <div id="ota_modal_step_form">
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:12px;">
                    <div style="font-size:28px; background:rgba(0,229,255,0.15); width:50px; height:50px; border-radius:12px; display:flex; align-items:center; justify-content:center; border:1px solid #00e5ff; box-shadow:0 0 15px rgba(0,229,255,0.3);">🚀</div>
                    <div>
                        <h3 style="margin:0; font-size:18px; color:#00e5ff; font-weight:800; text-shadow:0 0 10px rgba(0,229,255,0.4);">สั่งปล่อยอัปเดตระบบเกมส์ (OTA Deploy)</h3>
                        <p style="margin:2px 0 0 0; font-size:12px; color:#94a3b8;">ส่งสัญญาณอัปเดตไปยังมือถือและผู้เล่นที่กำลังเล่นอยู่แบบ Real-time</p>
                    </div>
                </div>

                <div style="background:rgba(2,132,199,0.1); border:1px solid rgba(0,229,255,0.25); border-radius:10px; padding:12px; margin-bottom:16px;">
                    <div style="font-size:12px; color:#cbd5e1; line-height:1.5;">
                        ⚡ เมื่อกดปล่อยอัปเดต ระบบจะสร้างรหัส <strong>Timestamp ใหม่</strong> ต่อท้ายไฟล์สคริปต์ และส่งแจ้งเตือน <strong>Popup</strong> ขึ้นบนหน้าจอมือถือคนเล่นทันที พร้อมแสดงขนาดไฟล์และแถบ % ความคืบหน้า
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="font-size:11px; font-weight:700; color:#38bdf8; display:block; margin-bottom:5px;">📦 เวอร์ชันแอป (App Version):</label>
                        <input type="text" id="modal_ota_app_version" value="1.0.0" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.2); border-radius:8px; color:#fff;">
                    </div>
                    <div>
                        <label style="font-size:11px; font-weight:700; color:#38bdf8; display:block; margin-bottom:5px;">💾 ขนาดไฟล์อัปเดต:</label>
                        <input type="text" id="modal_ota_update_size" value="2.8 MB" placeholder="เช่น 2.8 MB" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.2); border-radius:8px; color:#ffd700; font-weight:700;">
                    </div>
                    <div>
                        <label style="font-size:11px; font-weight:700; color:#10b981; display:block; margin-bottom:5px;">📁 จำนวนไฟล์อัปเดต:</label>
                        <input type="text" id="modal_ota_update_files" value="14 ไฟล์" placeholder="เช่น 14 ไฟล์" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(16,185,129,0.3); border-radius:8px; color:#10b981; font-weight:700; text-align:center;">
                    </div>
                </div>

                <div style="margin-bottom:14px;">
                    <label style="font-size:11px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:5px;">📝 รายละเอียดการอัปเดต (Release Notes แสดงให้ผู้เล่นเห็น):</label>
                    <input type="text" id="modal_ota_release_note" value="อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล" placeholder="เช่น อัปเดตแผนที่ใหม่และแก้บั๊ก" style="width:100%; box-sizing:border-box; padding:10px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.2); border-radius:8px; color:#fff;">
                </div>

                <div style="background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.25); border-radius:8px; padding:10px 12px; margin-bottom:18px;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; margin:0; font-size:12px; color:#fca5a5; font-weight:700;">
                        <input type="checkbox" id="modal_ota_force_clear" checked style="width:16px; height:16px; cursor:pointer;">
                        <span>⚠️ บังคับให้ผู้เล่นและแอปเคลียร์แคชทันที (Force Clear Cache)</span>
                    </label>
                </div>

                <div style="display:flex; gap:10px; justify-content:flex-end;">
                    <button class="btn" onclick="closeOtaDeployModal()" style="background:rgba(255,255,255,0.1); color:#cbd5e1; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:600;">
                        ยกเลิก
                    </button>
                    <button id="btn_modal_confirm_deploy" class="btn" onclick="submitOtaDeployFromModal()" style="background:linear-gradient(135deg, #0284c7, #00e5ff, #10b981); color:#000; font-weight:900; border:none; padding:10px 24px; border-radius:8px; cursor:pointer; box-shadow:0 4px 15px rgba(0,229,255,0.4); display:inline-flex; align-items:center; gap:8px;">
                        <span>🚀 ยืนยันปล่อยอัปเดตเดี๋ยวนี้</span>
                    </button>
                </div>
            </div>

            <!-- Step 2: สถานะกำลัง Deploy -->
            <div id="ota_modal_step_loading" style="display:none; text-align:center; padding:30px 10px;">
                <div style="font-size:48px; animation:spin 1.5s linear infinite; display:inline-block; margin-bottom:16px;">🔄</div>
                <h3 style="color:#00e5ff; font-size:18px; margin:0 0 8px 0; font-weight:800;">กำลังปล่อยอัปเดตระบบเกมส์...</h3>
                <p style="color:#94a3b8; font-size:13px; margin:0 0 18px 0;">กำลังบันทึกข้อมูลเวอร์ชันใหม่และต่อท้าย ?v=timestamp ในโค้ด</p>
                <div style="width:100%; height:6px; background:rgba(255,255,255,0.1); border-radius:3px; overflow:hidden;">
                    <div style="width:100%; height:100%; background:linear-gradient(90deg, #0284c7, #00e5ff, #10b981); animation:indeterminate 1.5s infinite linear;"></div>
                </div>
            </div>

            <!-- Step 3: แสดงผลลัพธ์สำเร็จ -->
            <div id="ota_modal_step_success" style="display:none; text-align:center; padding:10px 0;">
                <div style="font-size:52px; margin-bottom:10px;">✅</div>
                <h3 style="color:#10b981; font-size:20px; margin:0 0 8px 0; font-weight:800; text-shadow:0 0 15px rgba(16,185,129,0.5);">ปล่อยอัปเดตระบบสำเร็จเรียบร้อย!</h3>
                <p style="color:#cbd5e1; font-size:13px; margin:0 0 18px 0;">ระบบพร้อมส่งแจ้งเตือน Popup ไปยังหน้าจอมือถือและผู้เล่นแล้ว</p>
                
                <div style="background:rgba(15,23,42,0.8); border:1px solid rgba(16,185,129,0.3); border-radius:12px; padding:14px; text-align:left; font-size:12px; color:#cbd5e1; margin-bottom:20px; line-height:1.8;">
                    <div>📌 <strong>รหัสเวอร์ชันใหม่ (Build):</strong> <span id="res_cache_buster" style="color:#ffd700; font-weight:800;">-</span></div>
                    <div>📦 <strong>เวอร์ชันแอป:</strong> <span id="res_version_code" style="color:#fff;">-</span></div>
                    <div>💾 <strong>ขนาดไฟล์อัปเดต:</strong> <span id="res_update_size" style="color:#38bdf8; font-weight:800;">-</span></div>
                    <div>📁 <strong>จำนวนไฟล์ที่ต่อท้ายแคชใหม่:</strong> <span id="res_affected_count" style="color:#10b981; font-weight:800;">-</span> ไฟล์</div>
                    <div>⏰ <strong>เวลาที่ปล่อยอัปเดต:</strong> <span id="res_deployed_time" style="color:#94a3b8;">-</span></div>
                </div>

                <button class="btn" onclick="closeOtaDeployModal()" style="background:linear-gradient(135deg, #10b981, #059669); color:#fff; font-weight:800; font-size:14px; padding:11px 32px; border:none; border-radius:10px; cursor:pointer; box-shadow:0 4px 15px rgba(16,185,129,0.4);">
                    🎉 ตกลง / รับทราบ (กลับหน้าควบคุม)
                </button>
            </div>
        </div>
    </div>

    <!-- ========================================================================= -->
    <!-- MODAL: ADD / EDIT THAI VOICE & SFX EVENT (เพิ่ม / แก้ไขเหตุการณ์เสียงพากย์ไทย) -->
    <!-- ========================================================================= -->
    <div id="modal-admin-audio-event" class="modal-overlay" onclick="if(event.target === this) window.closeAdminAudioModal()" style="display:none; position:fixed; inset:0; background:rgba(3,7,18,0.88); backdrop-filter:blur(10px); z-index:99999; justify-content:center; align-items:center; padding:16px; overflow-y:auto;">
        <div class="glass-panel" style="width:100%; max-width:580px; max-height:92vh; overflow-y:auto; background:linear-gradient(145deg, rgba(15,23,42,0.98), rgba(10,15,30,0.99)); border:2px solid #ec4899; border-radius:18px; box-shadow:0 0 45px rgba(236,72,153,0.38); padding:24px; position:relative;">
            <button type="button" onclick="window.closeAdminAudioModal()" style="position:absolute; top:14px; right:16px; background:none; border:none; color:#94a3b8; font-size:26px; cursor:pointer; line-height:1;">&times;</button>

            <div style="display:flex; align-items:center; gap:12px; margin-bottom:16px; border-bottom:1px solid rgba(236,72,153,0.3); padding-bottom:12px;">
                <div style="font-size:28px; background:rgba(236,72,153,0.16); width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; border:1px solid #ec4899;">🎵</div>
                <div>
                    <h3 id="adm_audio_modal_title" style="margin:0; font-size:17px; color:#f472b6; font-weight:800;">➕ เพิ่มเหตุการณ์เสียงพากย์ไทย / เอฟเฟกต์ใหม่</h3>
                    <p style="margin:2px 0 0 0; font-size:12px; color:#94a3b8;">ตั้งค่าเสียงพากย์ภาษาไทย อัปโหลดไฟล์ MP3 หรือ WAV และเชื่อมต่อเหตุการณ์ในเกม</p>
                </div>
            </div>

            <form id="adminAudioEventForm" onsubmit="window.submitAdminAudioEventForm(event)">
                <input type="hidden" id="adm_audio_orig_key" value="">

                <div id="adm_audio_preset_wrap" style="margin-bottom:14px; background:rgba(236,72,153,0.08); border:1px solid rgba(236,72,153,0.25); border-radius:10px; padding:12px;">
                    <label style="font-size:12px; font-weight:700; color:#f472b6; display:block; margin-bottom:6px;">🎯 เลือกเหตุการณ์ในเกมสำเร็จรูป (หรือพิมพ์กำหนดเองด้านล่าง):</label>
                    <select id="adm_audio_preset" onchange="window.applyAdminAudioPreset(this.value)" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.65); border:1px solid rgba(255,255,255,0.22); border-radius:8px; color:#fff;">
                        <option value="">-- กำหนดรหัสเหตุการณ์เอง (Custom Event Key) --</option>
                        <optgroup label="⭐ เหตุการณ์หลักของเกมบันไดงู 3D">
                            <option value="malei">malei — เสียงพากย์เริ่มเกม ("มาเลยๆ")</option>
                            <option value="yeay">yeay — เสียงได้เริ่มคนแรก ("เย้! ได้ทอยเป็นคนแรก")</option>
                            <option value="dice_roll">dice_roll — เสียงทอยลูกเต๋า (Dice Roll SFX)</option>
                            <option value="step">step — เสียงเดินนับช่อง (Step SFX)</option>
                            <option value="double">double — เสียงทอยได้แต้มดับเบิล ("ดับเบิล!")</option>
                            <option value="island_trap">island_trap — เสียงตกเกาะ / ติดคุก ("หือๆๆ ติดเกาะซะแล้ว")</option>
                        </optgroup>
                        <optgroup label="🎮 เหตุการณ์พิเศษในกระดาน">
                            <option value="ladder_climb">ladder_climb — เสียงไต่บันไดขึ้น</option>
                            <option value="snake_bite">snake_bite — เสียงตกช่องงูสไลด์ลง</option>
                            <option value="build_landmark">build_landmark — เสียงสร้างแลนด์มาร์คสำเร็จ</option>
                            <option value="victory">victory — เสียงชนะการแข่งขัน</option>
                            <option value="bankrupt">bankrupt — เสียงล้มละลาย</option>
                        </optgroup>
                        <optgroup label="🔢 เสียงพากย์นับก้าวเดินภาษาไทย (1-12)">
                            <option value="step_1">step_1 — เสียงนับก้าวที่ 1 ("หนึ่ง")</option>
                            <option value="step_2">step_2 — เสียงนับก้าวที่ 2 ("สอง")</option>
                            <option value="step_3">step_3 — เสียงนับก้าวที่ 3 ("สาม")</option>
                            <option value="step_4">step_4 — เสียงนับก้าวที่ 4 ("สี่")</option>
                            <option value="step_5">step_5 — เสียงนับก้าวที่ 5 ("ห้า")</option>
                            <option value="step_6">step_6 — เสียงนับก้าวที่ 6 ("หก")</option>
                            <option value="step_7">step_7 — เสียงนับก้าวที่ 7 ("เจ็ด")</option>
                            <option value="step_8">step_8 — เสียงนับก้าวที่ 8 ("แปด")</option>
                            <option value="step_9">step_9 — เสียงนับก้าวที่ 9 ("เก้า")</option>
                            <option value="step_10">step_10 — เสียงนับก้าวที่ 10 ("สิบ")</option>
                            <option value="step_11">step_11 — เสียงนับก้าวที่ 11 ("สิบเอ็ด")</option>
                            <option value="step_12">step_12 — เสียงนับก้าวที่ 12 ("สิบสอง")</option>
                        </optgroup>
                    </select>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:5px;">🔑 รหัสเหตุการณ์ (Event Key) *</label>
                        <input type="text" id="adm_audio_event_key" placeholder="เช่น malei, victory, step_1" required style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.22); border-radius:8px; color:#f472b6; font-family:monospace; font-weight:700;">
                    </div>
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:5px;">🎙️ ประเภทเสียง *</label>
                        <select id="adm_audio_type" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.22); border-radius:8px; color:#fff;">
                            <option value="voice">🎤 เสียงพากย์ภาษาไทย (Voice)</option>
                            <option value="sfx">🔊 เสียงเอฟเฟกต์ประกอบ (SFX)</option>
                        </select>
                    </div>
                </div>

                <div style="margin-bottom:12px;">
                    <label style="font-size:12px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:5px;">🏷️ ชื่อเรียกเสียง / ประโยคพากย์ *</label>
                    <input type="text" id="adm_audio_name" placeholder='เช่น เสียงพากย์เริ่มเกม ("มาเลยๆ")' required style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.22); border-radius:8px; color:#fff;">
                </div>

                <div style="margin-bottom:12px;">
                    <label style="font-size:12px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:5px;">💬 คำอธิบาย / บทพูดภาษาไทย</label>
                    <input type="text" id="adm_audio_desc" placeholder="เช่น เด็กผู้หญิงพูดคำว่า มาเลยๆ ตอนเริ่มเกม" style="width:100%; box-sizing:border-box; padding:9px 12px; font-size:13px; background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.22); border-radius:8px; color:#cbd5e1;">
                </div>

                <div style="display:grid; grid-template-columns:1fr auto; gap:14px; align-items:center; margin-bottom:14px; background:rgba(15,23,42,0.75); border:1px solid rgba(255,255,255,0.12); border-radius:10px; padding:10px 14px;">
                    <div>
                        <label style="font-size:12px; font-weight:700; color:#fbbf24; display:flex; justify-content:space-between; margin-bottom:4px;">
                            <span>🔉 ระดับความดังเสียง (Volume):</span>
                            <strong id="adm_audio_vol_label">100%</strong>
                        </label>
                        <input type="range" id="adm_audio_volume" min="10" max="100" step="5" value="100" oninput="document.getElementById('adm_audio_vol_label').innerText = this.value + '%'" style="width:100%; cursor:pointer;">
                    </div>
                    <div style="padding-left:10px; border-left:1px solid rgba(255,255,255,0.12);">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:700; color:#34d399; margin:0; white-space:nowrap;">
                            <input type="checkbox" id="adm_audio_enabled" checked style="width:17px; height:17px; cursor:pointer;">
                            <span>เปิดใช้งานเสียงนี้</span>
                        </label>
                    </div>
                </div>

                <div style="margin-bottom:12px;">
                    <label style="font-size:12px; font-weight:700; color:#cbd5e1; display:block; margin-bottom:6px;">📂 ไฟล์เสียงที่ผูกอยู่ปัจจุบัน:</label>
                    <div id="adm_audio_files_list" style="display:flex; flex-wrap:wrap; gap:6px; min-height:32px; align-items:center; background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.12); border-radius:8px; padding:8px 10px;"></div>
                </div>

                <div style="margin-bottom:18px; background:rgba(2,132,199,0.1); border:1px dashed rgba(56,189,248,0.45); border-radius:10px; padding:12px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:8px;">
                        <label style="font-size:12px; font-weight:700; color:#38bdf8; margin:0;">📤 อัปโหลดไฟล์เสียง (.mp3 / .wav / .ogg / .m4a):</label>
                        <select id="adm_audio_upload_mode" style="padding:4px 8px; font-size:11px; background:rgba(0,0,0,0.65); color:#fff; border:1px solid rgba(255,255,255,0.2); border-radius:6px;">
                            <option value="replace">แทนที่ไฟล์เสียงเดิม</option>
                            <option value="append">เพิ่มต่อท้าย (สุ่มเล่นหลายเสียง)</option>
                        </select>
                    </div>
                    <input type="file" id="adm_audio_file_input" accept=".mp3,.wav,.ogg,.m4a,audio/*" style="width:100%; font-size:12px; color:#e2e8f0;">
                </div>

                <div style="display:flex; gap:10px; justify-content:flex-end;">
                    <button type="button" class="btn" onclick="window.closeAdminAudioModal()" style="background:rgba(255,255,255,0.1); color:#cbd5e1; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:600;">
                        ยกเลิก
                    </button>
                    <button type="submit" id="btn_adm_audio_submit" class="btn" style="background:linear-gradient(135deg, #ec4899, #d946ef); color:#fff; font-weight:800; border:none; padding:10px 24px; border-radius:8px; cursor:pointer; box-shadow:0 4px 15px rgba(236,72,153,0.4);">
                        💾 บันทึกเหตุการณ์เสียง
                    </button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <script src="js/admin_shop_menus.js?v=<?= time() ?>"></script>
    <script src="js/admin_board_studio.js?v=<?= time() ?>"></script>
</body>
</html>
<?php
}
