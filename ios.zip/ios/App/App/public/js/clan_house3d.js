/**
 * clan_house3d.js - Interactive 3D Clan House Interior (ห้องในบ้าน 3D)
 * Three.js WebGL Interior Scene with Furniture (Sofa, Coffee Table, TV, Carpet, Plant, Lamp)
 * Features:
 *  - Procedural 3D Modern Living Room
 *  - Player's active character placed inside the room
 *  - Other clan members chilling in the room with floating name badges
 *  - Click-to-Move with Raycaster on floor + walk animation & target ring
 *  - Animated Smart TV screen displaying Clan Tag & LIVE Game News
 *  - Quick position buttons (Sit on Sofa, Watch TV, Center Room)
 *  - Orbit Controls (Drag to rotate 360ยฐ, pinch/scroll to zoom)
 */

class ClanHouse3D {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) return;

        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.clock = new THREE.Clock();

        // Object references
        this.floorMesh = null;
        this.playerPawn = null;
        this.otherPawns = [];
        this.targetRing = null;
        this.tvScreenTexture = null;
        this.tvCanvas = null;
        this.tvCtx = null;

        // Click to move state & obstacle avoidance pathfinding
        this.isMoving = false;
        this.targetPos = new THREE.Vector3();
        this.moveSpeed = 8.5; // units per sec
        this.walkCycle = 0;
        this.waypointPath = [];

        // Living room furniture obstacle boxes (x/z bounds)
        this.obstacles = [
            // Sofa (including backrest, cushions & armrests)
            { id: 'sofa', minX: -4.8, maxX: 4.8, minZ: 2.7, maxZ: 6.3 },
            // Coffee table (including legs, top, decor bowl & dice)
            { id: 'table', minX: -2.6, maxX: 2.6, minZ: -0.7, maxZ: 1.4 },
            // TV console & base
            { id: 'tv', minX: -4.0, maxX: 4.0, minZ: -9.0, maxZ: -7.2 },
            // Floor Lamp
            { id: 'lamp', minX: -8.3, maxX: -6.7, minZ: -2.3, maxZ: -0.7 },
            // Plant
            { id: 'plant', minX: 5.0, maxX: 6.6, minZ: -7.8, maxZ: -6.2 }
        ];

        // Clan & user data
        this.clanData = null;
        this.currentUser = null;

        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.animFrameId = null;

        this.init();
    }

    init() {
        const width = this.container.clientWidth || 540;
        const height = this.container.clientHeight || 340;

        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0a0f1d);
        this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.012);

        // Camera
        this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 500);
        this.camera.position.set(0, 13, 20);
        this.camera.lookAt(0, 2.5, 0);

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
        this.renderer.setSize(width, height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.container.innerHTML = '';
        this.container.appendChild(this.renderer.domElement);

        // Controls
        if (window.THREE.OrbitControls) {
            this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
            this.controls.enableDamping = true;
            this.controls.dampingFactor = 0.06;
            this.controls.maxPolarAngle = Math.PI / 2.1;
            this.controls.minDistance = 8;
            this.controls.maxDistance = 35;
            this.controls.target.set(0, 2.5, 0);
        }

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x475569, 0.9);
        this.scene.add(ambientLight);

        // Warm ceiling chandelier/spot light
        const ceilingLight = new THREE.PointLight(0xfff1e6, 1.4, 40);
        ceilingLight.position.set(0, 10, 0);
        ceilingLight.castShadow = true;
        this.scene.add(ceilingLight);

        // Cyan accent light near TV / wall
        const tvGlow = new THREE.PointLight(0x00e5ff, 0.8, 25);
        tvGlow.position.set(0, 5, -8.5);
        this.scene.add(tvGlow);

        // Warm cozy lamp light
        const lampGlow = new THREE.PointLight(0xffb703, 0.7, 18);
        lampGlow.position.set(-8.5, 5.5, -4);
        this.scene.add(lampGlow);

        // Build room and furniture
        this.buildRoom();
        this.buildSofa();
        this.buildCoffeeTable();
        this.buildTVUnit();
        this.buildCarpet();
        this.buildFloorLamp();
        this.buildPlant();
        this.createTargetRing();

        // Interaction
        this.renderer.domElement.addEventListener('pointerdown', (e) => this.onPointerDown(e));
        window.addEventListener('resize', () => this.onResize());

        // Start render loop
        this.animate();
    }

    buildRoom() {
        // 1. Room Floor (26 x 22 units)
        const floorGeo = new THREE.PlaneGeometry(26, 22);
        const floorCanvas = document.createElement('canvas');
        floorCanvas.width = 512;
        floorCanvas.height = 512;
        const fctx = floorCanvas.getContext('2d');
        // Wooden tile pattern
        fctx.fillStyle = '#1e293b';
        fctx.fillRect(0, 0, 512, 512);
        fctx.strokeStyle = '#334155';
        fctx.lineWidth = 4;
        for (let x = 0; x < 512; x += 64) {
            fctx.beginPath();
            fctx.moveTo(x, 0);
            fctx.lineTo(x, 512);
            fctx.stroke();
        }
        for (let y = 0; y < 512; y += 64) {
            fctx.beginPath();
            fctx.moveTo(0, y);
            fctx.lineTo(512, y);
            fctx.stroke();
        }
        const floorTex = new THREE.CanvasTexture(floorCanvas);
        floorTex.wrapS = THREE.RepeatWrapping;
        floorTex.wrapT = THREE.RepeatWrapping;
        floorTex.repeat.set(4, 4);

        const floorMat = new THREE.MeshStandardMaterial({
            map: floorTex,
            roughness: 0.35,
            metalness: 0.15
        });
        this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
        this.floorMesh.rotation.x = -Math.PI / 2;
        this.floorMesh.receiveShadow = true;
        this.scene.add(this.floorMesh);

        // 2. Back Wall (z = -10.5)
        const backWallGeo = new THREE.PlaneGeometry(26, 12);
        const wallMat = new THREE.MeshStandardMaterial({
            color: 0x0f172a,
            roughness: 0.8,
            metalness: 0.1
        });
        const backWall = new THREE.Mesh(backWallGeo, wallMat);
        backWall.position.set(0, 6, -10.5);
        this.scene.add(backWall);

        // Modern Wood Slats Panel on Back Wall
        for (let x = -8; x <= 8; x += 0.8) {
            const slatGeo = new THREE.BoxGeometry(0.35, 11, 0.15);
            const slatMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.7 });
            const slat = new THREE.Mesh(slatGeo, slatMat);
            slat.position.set(x, 5.5, -10.4);
            this.scene.add(slat);
        }

        // Baseboard
        const baseboardGeo = new THREE.BoxGeometry(26, 0.4, 0.3);
        const baseboardMat = new THREE.MeshStandardMaterial({ color: 0x00e5ff, emissive: 0x00e5ff, emissiveIntensity: 0.25 });
        const baseboard = new THREE.Mesh(baseboardGeo, baseboardMat);
        baseboard.position.set(0, 0.2, -10.35);
        this.scene.add(baseboard);

        // Left Wall
        const leftWallGeo = new THREE.PlaneGeometry(22, 12);
        const leftWall = new THREE.Mesh(leftWallGeo, wallMat);
        leftWall.position.set(-13, 6, 0.5);
        leftWall.rotation.y = Math.PI / 2;
        this.scene.add(leftWall);

        // Right Wall with Window
        const rightWall = new THREE.Mesh(leftWallGeo, wallMat);
        rightWall.position.set(13, 6, 0.5);
        rightWall.rotation.y = -Math.PI / 2;
        this.scene.add(rightWall);

        // เธเธฃเธฐเธ”เธฒเธเธ—เธณเน€เธเธตเธขเธเธชเธกเธฒเธเธดเธเธเธฃเธญเธเธเธฃเธฑเธง 3D เธเธเธเธเธฑเธเธเธงเธฒ (เธฃเธนเธเนเธเธเธงเธเธเธฅเธก 5 เนเธ–เธงเน เธฅเธฐ 6 เธเธ = 30 เธเธ)
        this.buildMembersBoard();
    }

    /**
     * คำนวณความสูงฐานของตัวละคร (Base Y) ตามตำแหน่งในห้อง 3D
     * หากนั่งอยู่บนโซฟา (Sofa Cushion) จะยกความสูงขึ้นให้แผ่นวงกลมโปรไฟล์ลอยอยู่เหนือเบาะพอดี
     * เพื่อให้เห็นรูปโปรไฟล์และขอบเรืองแสงเต็มวงกลม 100% โดยไม่ถูกเบาะโซฟาบังหรือตัดขอบ
     */
    getRestingHeight(x, z) {
        // ขอบเขตตำแหน่งโซฟา (Sofa area: |x| <= 4.6 และ z อยู่ระหว่าง 2.8 ถึง 6.0)
        if (Math.abs(x) <= 4.6 && z >= 2.8 && z <= 6.0) {
            return 0.95; // ยกขึ้นเหนือเบาะโซฟา (1.4) ให้แผ่นวงกลมโปรไฟล์แสดงผลเต็มวงกลมสวยงาม
        }
        return 0.0; // ระดับพื้นห้องปกติ
    }

    buildSofa() {
        const sofaGroup = new THREE.Group();
        const leatherMat = new THREE.MeshStandardMaterial({
            color: 0x1e293b,
            metalness: 0.2,
            roughness: 0.4
        });
        const cushionMat = new THREE.MeshStandardMaterial({
            color: 0x334155,
            metalness: 0.1,
            roughness: 0.6
        });

        // Sofa Base
        const baseGeo = new THREE.BoxGeometry(9.0, 0.8, 3.2);
        const base = new THREE.Mesh(baseGeo, leatherMat);
        base.position.y = 0.5;
        sofaGroup.add(base);

        // Seating Cushions
        for (let i = 0; i < 3; i++) {
            const seatGeo = new THREE.BoxGeometry(2.8, 0.6, 2.7);
            const seat = new THREE.Mesh(seatGeo, cushionMat);
            seat.position.set(-2.8 + i * 2.8, 1.1, 0.1);
            sofaGroup.add(seat);
        }

        // Backrest
        const backGeo = new THREE.BoxGeometry(9.0, 2.2, 0.8);
        const back = new THREE.Mesh(backGeo, leatherMat);
        back.position.set(0, 2.1, 1.3);
        sofaGroup.add(back);

        // Left Armrest
        const armGeo = new THREE.BoxGeometry(0.8, 1.8, 3.2);
        const armL = new THREE.Mesh(armGeo, leatherMat);
        armL.position.set(-4.5, 1.6, 0.2);
        sofaGroup.add(armL);

        // Right Armrest
        const armR = new THREE.Mesh(armGeo, leatherMat);
        armR.position.set(4.5, 1.6, 0.2);
        sofaGroup.add(armR);

        // Pillows
        const pillowMat1 = new THREE.MeshStandardMaterial({ color: 0x00e5ff, roughness: 0.5 });
        const pillowMat2 = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });
        const pGeo = new THREE.BoxGeometry(1.2, 1.2, 0.4);

        const p1 = new THREE.Mesh(pGeo, pillowMat1);
        p1.position.set(-3.7, 1.7, 0.9);
        p1.rotation.y = 0.3;
        sofaGroup.add(p1);

        const p2 = new THREE.Mesh(pGeo, pillowMat2);
        p2.position.set(3.7, 1.7, 0.9);
        p2.rotation.y = -0.3;
        sofaGroup.add(p2);

        // Position Sofa facing TV
        sofaGroup.position.set(0, 0, 4.5);
        this.scene.add(sofaGroup);
        this.sofaPos = new THREE.Vector3(0, 0, 3.5);
    }

    buildCoffeeTable() {
        const tableGroup = new THREE.Group();

        // Sleek Modern Low-Profile Coffee Table: width 4.6, depth 1.8, height 0.75
        const topGeo = new THREE.BoxGeometry(4.6, 0.16, 1.8);
        const topMat = new THREE.MeshStandardMaterial({
            color: 0x0f172a,
            metalness: 0.85,
            roughness: 0.25,
            transparent: true,
            opacity: 0.92
        });
        const top = new THREE.Mesh(topGeo, topMat);
        top.position.y = 0.75;
        tableGroup.add(top);

        // Legs (Metallic Gold)
        const legMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2 });
        const legPositions = [
            [-2.0, 0.375, -0.7], [2.0, 0.375, -0.7],
            [-2.0, 0.375, 0.7], [2.0, 0.375, 0.7]
        ];
        legPositions.forEach(pos => {
            const legGeo = new THREE.CylinderGeometry(0.05, 0.05, 0.75, 12);
            const leg = new THREE.Mesh(legGeo, legMat);
            leg.position.set(pos[0], pos[1], pos[2]);
            tableGroup.add(leg);
        });

        // 3D Glowing Dice placed safely on the FAR RIGHT of the Coffee Table (x = 1.7)
        // Leaving the center of the table completely clear so it never overlaps avatars
        const diceGeo = new THREE.BoxGeometry(0.36, 0.36, 0.36);
        const diceMat = new THREE.MeshStandardMaterial({
            color: 0x00e5ff,
            emissive: 0x00e5ff,
            emissiveIntensity: 0.6,
            metalness: 0.8,
            roughness: 0.2
        });
        const dice = new THREE.Mesh(diceGeo, diceMat);
        dice.position.set(1.7, 1.02, 0.1);
        dice.rotation.set(0.4, 0.6, 0.2);
        tableGroup.add(dice);

        // Decorative Bowl placed safely on the FAR LEFT of the Coffee Table (x = -1.7)
        const bowlGeo = new THREE.CylinderGeometry(0.38, 0.20, 0.18, 16);
        const bowlMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.1 });
        const bowl = new THREE.Mesh(bowlGeo, bowlMat);
        bowl.position.set(-1.7, 0.92, -0.1);
        tableGroup.add(bowl);

        // Position Coffee Table forward at z = 0.35 (leaving 1.6+ units of open corridor to sofa)
        tableGroup.position.set(0, 0, 0.35);
        this.scene.add(tableGroup);
    }

    buildCarpet() {
        const carpetGeo = new THREE.PlaneGeometry(10.5, 7.5);
        const carpetCanvas = document.createElement('canvas');
        carpetCanvas.width = 512;
        carpetCanvas.height = 384;
        const cctx = carpetCanvas.getContext('2d');
        cctx.fillStyle = '#0f172a';
        cctx.fillRect(0, 0, 512, 384);
        cctx.strokeStyle = '#6366f1';
        cctx.lineWidth = 8;
        cctx.strokeRect(16, 16, 480, 352);
        cctx.strokeStyle = 'rgba(0, 229, 255, 0.4)';
        cctx.lineWidth = 4;
        cctx.strokeRect(32, 32, 448, 320);

        const carpetTex = new THREE.CanvasTexture(carpetCanvas);
        const carpetMat = new THREE.MeshStandardMaterial({
            map: carpetTex,
            roughness: 0.8,
            metalness: 0.1
        });
        const carpet = new THREE.Mesh(carpetGeo, carpetMat);
        carpet.rotation.x = -Math.PI / 2;
        carpet.position.set(0, 0.02, 2.5);
        carpet.receiveShadow = true;
        this.scene.add(carpet);
    }

    buildTVUnit() {
        const tvGroup = new THREE.Group();

        // 1. Sleek Media Stand Console
        const standGeo = new THREE.BoxGeometry(9.0, 1.1, 1.8);
        const standMat = new THREE.MeshStandardMaterial({
            color: 0x18181b,
            metalness: 0.4,
            roughness: 0.3
        });
        const stand = new THREE.Mesh(standGeo, standMat);
        stand.position.set(0, 0.55, -9.0);
        tvGroup.add(stand);

        // LED Underglow
        const glowGeo = new THREE.BoxGeometry(8.6, 0.08, 1.6);
        const glowMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
        const glow = new THREE.Mesh(glowGeo, glowMat);
        glow.position.set(0, 0.04, -9.0);
        tvGroup.add(glow);

        // 2. Big Screen 75" TV Frame
        const frameGeo = new THREE.BoxGeometry(7.2, 4.2, 0.2);
        const frameMat = new THREE.MeshStandardMaterial({
            color: 0x09090b,
            metalness: 0.9,
            roughness: 0.1
        });
        const frame = new THREE.Mesh(frameGeo, frameMat);
        frame.position.set(0, 4.4, -9.8);
        tvGroup.add(frame);

        // 3. Dynamic TV Screen Display
        this.tvCanvas = document.createElement('canvas');
        this.tvCanvas.width = 1024;
        this.tvCanvas.height = 576;
        this.tvCtx = this.tvCanvas.getContext('2d');
        this.updateTVScreen();

        this.tvScreenTexture = new THREE.CanvasTexture(this.tvCanvas);
        const screenGeo = new THREE.PlaneGeometry(6.9, 3.9);
        const screenMat = new THREE.MeshBasicMaterial({
            map: this.tvScreenTexture
        });
        const screen = new THREE.Mesh(screenGeo, screenMat);
        screen.position.set(0, 4.4, -9.68);
        tvGroup.add(screen);

        this.scene.add(tvGroup);
        this.tvPos = new THREE.Vector3(0, 0, -6.5);
    }

    updateTVScreen() {
        if (!this.tvCtx) return;
        const ctx = this.tvCtx;
        const w = 1024;
        const h = 576;

        // Background
        const grad = ctx.createLinearGradient(0, 0, w, h);
        grad.addColorStop(0, '#020617');
        grad.addColorStop(1, '#0f172a');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Top bar
        ctx.fillStyle = 'rgba(0, 229, 255, 0.2)';
        ctx.fillRect(0, 0, w, 64);
        ctx.fillStyle = '#00e5ff';
        ctx.font = 'bold 28px Kanit, sans-serif';
        ctx.fillText('🔴 LIVE BROADCAST • ห้องนั่งเล่นบ้าน 3D', 36, 44);

        // Clan Branding / Public Lounge
        const isPublicLounge = !this.clanData || !this.clanData.has_clan;
        const clanName = isPublicLounge ? 'บ้านพักส่วนกลาง (Public Lounge)' : (this.clanData?.clan?.clan_name || 'บ้านพญานาคราช 3D');
        const tag = isPublicLounge ? '[PUBLIC] ' : (this.clanData?.clan?.tag ? `[${this.clanData.clan.tag}] ` : '[HOME] ');
        const memberCount = this.clanData?.members_count || 1;
        const onlineCount = this.clanData?.online_count || 1;

        ctx.fillStyle = '#ffffff';
        ctx.font = '900 48px Kanit, sans-serif';
        ctx.fillText(`🏠 ${tag}${clanName}`, 60, 180);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '24px Kanit, sans-serif';
        const subInfo = isPublicLounge
            ? 'บ้านพักสำหรับทุกคนร่วมเข้าได้ ไม่ใช่บ้านประจำ เป็นบ้านพักสำหรับทุกคนเข้ามาพูดคุยและเดินเล่นด้วยกัน'
            : `เลเวลบ้าน: Lv.${this.clanData?.clan?.clan_level || 1} | แต้มเกียรติยศ: ${(this.clanData?.clan?.total_score || 1000).toLocaleString()} คะแนน`;
        ctx.fillText(subInfo, 60, 235);

        // Online & Members Pill
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(80, 310, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#34d399';
        ctx.font = 'bold 34px Kanit, sans-serif';
        const onlineText = isPublicLounge
            ? `ออนไลน์ในเลานจ์: ${onlineCount} คน  (ผู้พักผ่อนทั้งหมด ${memberCount} คน)`
            : `ออนไลน์ขณะนี้: ${onlineCount} คน  (สมาชิกทั้งหมด ${memberCount} / 30 คน)`;
        ctx.fillText(onlineText, 110, 322);

        // Bottom Ticker Banner
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(40, 400, 944, 110);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.strokeRect(40, 400, 944, 110);

        if (isPublicLounge) {
            ctx.fillStyle = '#38bdf8';
            ctx.font = 'bold 28px Kanit, sans-serif';
            ctx.fillText('💬 ยินดีต้อนรับทุกคน! ร่วมพูดคุย ส่งอิโมจิ และเดินเล่นพักผ่อนในเลานจ์ได้อิสระ', 70, 465);
        } else {
            ctx.fillStyle = '#f59e0b';
            ctx.font = 'bold 30px Kanit, sans-serif';
            ctx.fillText('⚡ กิจกรรมบ้าน: รวมพลังไต่อันดับบันไดงู 3D รับโบนัสเพชร & ทอง!', 70, 465);
        }
        if (this.tvScreenTexture) {
            this.tvScreenTexture.needsUpdate = true;
        }
    }

    buildFloorLamp() {
        const lampGroup = new THREE.Group();

        // Heavy Base
        const baseGeo = new THREE.CylinderGeometry(0.7, 0.7, 0.15, 24);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.9, roughness: 0.2 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        base.position.y = 0.08;
        lampGroup.add(base);

        // Curved / Tall Stand
        const poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 7.5, 16);
        const poleMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.95, roughness: 0.1 });
        const pole = new THREE.Mesh(poleGeo, poleMat);
        pole.position.set(0, 3.8, 0);
        lampGroup.add(pole);

        // Lampshade
        const shadeGeo = new THREE.ConeGeometry(1.0, 1.2, 24, 1, true);
        const shadeMat = new THREE.MeshStandardMaterial({
            color: 0xffeedd,
            emissive: 0xffb703,
            emissiveIntensity: 0.6,
            side: THREE.DoubleSide
        });
        const shade = new THREE.Mesh(shadeGeo, shadeMat);
        shade.position.set(0, 7.2, 0);
        shade.rotation.x = Math.PI;
        lampGroup.add(shade);

        lampGroup.position.set(-9.5, 0, -4.5);
        this.scene.add(lampGroup);
    }

    buildPlant() {
        const plantGroup = new THREE.Group();

        // Modern White Pot
        const potGeo = new THREE.CylinderGeometry(0.8, 0.6, 1.8, 16);
        const potMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
        const pot = new THREE.Mesh(potGeo, potMat);
        pot.position.y = 0.9;
        plantGroup.add(pot);

        // Leaves
        const leafMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.5 });
        for (let i = 0; i < 7; i++) {
            const leafGeo = new THREE.ConeGeometry(0.35, 2.2, 8);
            const leaf = new THREE.Mesh(leafGeo, leafMat);
            const angle = (i / 7) * Math.PI * 2;
            leaf.position.set(Math.cos(angle) * 0.35, 2.2, Math.sin(angle) * 0.35);
            leaf.rotation.x = Math.sin(angle) * 0.45;
            leaf.rotation.z = -Math.cos(angle) * 0.45;
            plantGroup.add(leaf);
        }

        plantGroup.position.set(9.8, 0, -4.5);
        this.scene.add(plantGroup);
    }

    createTargetRing() {
        const ringGeo = new THREE.RingGeometry(0.5, 0.7, 32);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0x00e5ff,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0
        });
        this.targetRing = new THREE.Mesh(ringGeo, ringMat);
        this.targetRing.rotation.x = -Math.PI / 2;
        this.targetRing.position.y = 0.04;
        this.scene.add(this.targetRing);
    }

    /**
     * เธ”เธถเธเธเนเธญเธกเธนเธฅเนเธฅเธฐ URL เธฃเธนเธเนเธเธฃเนเธเธฅเนเธเธญเธเธเธนเนเนเธเนเธเธฒเธเธชเธ–เธฒเธเธฐเธเธฒเธฃเน€เธเนเธฒเธชเธนเนเธฃเธฐเธเธ (Google/LINE)
     */
    resolveProfileAvatar(userData = {}) {
        const u = userData || {};
        const provider = u.auth_provider || u.provider || (u.pictureUrl ? 'line' : (u.picture ? 'google' : 'guest'));
        let avatarUrl = '';

        if (provider === 'line' || u.pictureUrl) {
            avatarUrl = u.pictureUrl || u.picture || u.avatar_url || '';
        } else if (provider === 'google' || u.picture) {
            avatarUrl = u.picture || u.avatar_url || '';
        } else {
            avatarUrl = u.avatar_url || u.picture || u.pictureUrl || '';
        }

        // If empty, fallback to DEFAULT_USER
        if (!avatarUrl && typeof DEFAULT_USER !== 'undefined') {
            avatarUrl = DEFAULT_USER.avatar_url || DEFAULT_USER.picture || DEFAULT_USER.pictureUrl || '';
        }
        if (!avatarUrl || avatarUrl === 'avatars/google_avatar.png') {
            avatarUrl = 'avatars/avatar_01.svg';
        }

        // Always proxy external HTTP/HTTPS images to eliminate CORS errors in WebGL Canvas
        if (avatarUrl && (avatarUrl.startsWith('http://') || avatarUrl.startsWith('https://')) && !avatarUrl.startsWith(window.location.origin) && !avatarUrl.startsWith('http://localhost')) {
            avatarUrl = 'api/proxy_avatar.php?url=' + encodeURIComponent(avatarUrl);
        }

        return { provider, avatarUrl };
    }

    /**
     * เธชเธฃเนเธฒเธ Canvas Texture เธเธงเธฒเธกเธฅเธฐเน€เธญเธตเธขเธ”เธชเธนเธ (512x512) เธ•เธฑเธ”เธเธญเธเน€เธเนเธเธฃเธนเธเธงเธเธเธฅเธกเธชเธกเธเธนเธฃเธ“เน
     */
    createCircularAvatarCanvasTexture(imageElement = null, rimColorHex = 0x00e5ff, displayName = 'ผู้เล่น', grade = 'A') {
        const canvas = document.createElement('canvas');
        canvas.width = 1024;
        canvas.height = 1024;
        const ctx = canvas.getContext('2d');

        ctx.clearRect(0, 0, 1024, 1024);

        // วาดภาพโปรไฟล์ตัดเป็นวงกลมสมบูรณ์
        ctx.save();
        ctx.beginPath();
        ctx.arc(512, 512, 490, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();

        if (imageElement && imageElement.complete && imageElement.naturalWidth > 0) {
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.drawImage(imageElement, 22, 22, 980, 980);
        } else {
            const grad = ctx.createLinearGradient(0, 0, 1024, 1024);
            grad.addColorStop(0, '#0284c7');
            grad.addColorStop(0.5, '#0f172a');
            grad.addColorStop(1, '#0284c7');
            ctx.fillStyle = grad;
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 260px "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const cleanName = (displayName || 'P').replace(/^([\[^\]]*\]|\([^)]*\))\s*/, '').trim();
            const initial = (cleanName || 'P').charAt(0).toUpperCase();
            ctx.fillText(initial, 512, 512);
        }
        ctx.restore();

        // วาดป้ายเกรด A, A+, S, S+, SS+ ที่มุมขวาล่าง
        const displayGrade = (grade || 'A').toUpperCase();
        ctx.save();
        const badgeW = displayGrade.length > 2 ? 240 : (displayGrade.length > 1 ? 200 : 170);
        const badgeH = 100;
        const bx = 1024 - badgeW - 35;
        const by = 1024 - badgeH - 45;
        const radius = 30;

        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 24;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 8;

        const bgrad = ctx.createLinearGradient(bx, by, bx + badgeW, by + badgeH);
        let textColor = '#ffffff';
        let borderColor = '#ffffff';
        if (displayGrade === 'SS+') {
            bgrad.addColorStop(0, '#ffd700');
            bgrad.addColorStop(1, '#b45309');
            textColor = '#000000';
            borderColor = '#ffffff';
        } else if (displayGrade === 'S+') {
            bgrad.addColorStop(0, '#facc15');
            bgrad.addColorStop(1, '#ca8a04');
            textColor = '#000000';
            borderColor = '#fef08a';
        } else if (displayGrade === 'S') {
            bgrad.addColorStop(0, '#00e5ff');
            bgrad.addColorStop(1, '#0284c7');
            textColor = '#020617';
            borderColor = '#7dd3fc';
        } else if (displayGrade === 'A+') {
            bgrad.addColorStop(0, '#ffffff');
            bgrad.addColorStop(1, '#cbd5e1');
            textColor = '#0f172a';
            borderColor = '#ffffff';
        } else {
            bgrad.addColorStop(0, '#64748b');
            bgrad.addColorStop(1, '#475569');
            textColor = '#ffffff';
            borderColor = '#94a3b8';
        }

        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') {
            ctx.roundRect(bx, by, badgeW, badgeH, radius);
        } else {
            ctx.rect(bx, by, badgeW, badgeH);
        }
        ctx.fillStyle = bgrad;
        ctx.fill();

        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.strokeStyle = borderColor;
        ctx.lineWidth = 8;
        ctx.stroke();

        ctx.font = '900 62px "Kanit", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = textColor;
        ctx.fillText(displayGrade, bx + badgeW / 2, by + badgeH / 2 + 2);
        ctx.restore();

        const tex = new THREE.CanvasTexture(canvas);
        tex.anisotropy = 16;
        tex.generateMipmaps = true;
        tex.minFilter = THREE.LinearMipmapLinearFilter;
        tex.magFilter = THREE.LinearFilter;
        return tex;
    }

    /**
     * เธชเธฃเนเธฒเธเนเธกเน€เธ”เธฅเธ•เธฑเธงเธฅเธฐเธเธฃ 3D เนเธเธซเนเธญเธเธเนเธฒเธ: เนเธชเธ”เธเน€เธเธเธฒเธฐเนเธเนเธเธงเธเธเธฅเธกเนเธเธงเธ•เธฑเนเธ (Circular Mesh)
     * เธ•เธฑเธ”เธเธญเธเน€เธเนเธเธฃเธนเธเธงเธเธเธฅเธกเธชเธกเธเธนเธฃเธ“เน เธซเธฑเธเธซเธเนเธฒเน€เธเนเธฒเธซเธฒเธเธฅเนเธญเธ (Look at Camera) เนเธ”เธขเนเธกเนเธกเธตเธเธฒเธเธซเธฃเธทเธญเธเธฃเธงเธขเธ”เนเธฒเธเธฅเนเธฒเธ
     */
    createCharacterPawn(name, colorHex = 0x00e5ff, isAwakened = true, roleBadge = '👑 หัวหน้าบ้าน', userData = {}, isSelf = false) {
        const pawnGroup = new THREE.Group();

        // เนเธเนเธเธงเธเธเธฅเธกเนเธเธงเธ•เธฑเนเธ (Circular Mesh) เนเธชเธ”เธเธฃเธนเธเนเธเธฃเนเธเธฅเน
        const headBadgeGroup = new THREE.Group();
        headBadgeGroup.position.set(0, 2.1, 0);

        const userGrade = userData.character_grade || userData.grade || (isSelf ? (window.equippedFrameGrade || localStorage.getItem('snake_equipped_frame_grade') || 'A') : 'A');
        let rimColor = isAwakened ? 0x00e5ff : colorHex;
        if (userGrade === 'SS+') rimColor = 0xffd700;
        else if (userGrade === 'S+') rimColor = 0xfacc15;
        else if (userGrade === 'S') rimColor = 0x00e5ff;
        else if (userGrade === 'A+') rimColor = 0xffffff;
        else if (userGrade === 'A') rimColor = 0x64748b;
        const initialTex = this.createCircularAvatarCanvasTexture(null, rimColor, name, userGrade);
        const discGeo = new THREE.CircleGeometry(1.45, 64);
        const discMat = new THREE.MeshBasicMaterial({
            map: initialTex,
            side: THREE.DoubleSide,
            transparent: true
        });
        const headDiscMesh = new THREE.Mesh(discGeo, discMat);
        headBadgeGroup.add(headDiscMesh);

        // เธเธญเธเธงเธเนเธซเธงเธเน€เธฃเธทเธญเธเนเธชเธเธฃเธญเธเนเธเนเธเธฃเธนเธเนเธเธฃเนเธเธฅเนเธงเธเธเธฅเธก
        const rimGeo = new THREE.TorusGeometry(1.44, 0.075, 16, 64);
        const rimMat = new THREE.MeshBasicMaterial({ color: rimColor });
        const rimMesh = new THREE.Mesh(rimGeo, rimMat);
        headBadgeGroup.add(rimMesh);

        pawnGroup.add(headBadgeGroup);

        // เธเนเธฒเธขเธเธทเนเธญเธฅเธญเธขเน€เธซเธเธทเธญเนเธเนเธเธงเธเธเธฅเธกเธเธญเธ”เธต
        const nameCanvas = document.createElement('canvas');
        nameCanvas.width = 380;
        nameCanvas.height = 100;
        const nctx = nameCanvas.getContext('2d');
        nctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        nctx.roundRect(10, 10, 360, 80, 16);
        nctx.fill();
        nctx.strokeStyle = '#00e5ff';
        nctx.lineWidth = 3;
        nctx.stroke();

        nctx.fillStyle = '#ffffff';
        nctx.font = 'bold 28px Kanit, sans-serif';
        nctx.textAlign = 'center';
        nctx.fillText(name, 190, 48);

        nctx.fillStyle = '#38bdf8';
        nctx.font = '20px Kanit, sans-serif';
        nctx.fillText(roleBadge, 190, 76);

        const nameTex = new THREE.CanvasTexture(nameCanvas);
        const nameMat = new THREE.SpriteMaterial({ map: nameTex, transparent: true });
        const nameSprite = new THREE.Sprite(nameMat);
        nameSprite.position.set(0, 3.8, 0);
        nameSprite.scale.set(3.2, 0.9, 1);
        pawnGroup.add(nameSprite);

        pawnGroup.userData = {
            headBadgeGroup,
            headDiscMesh,
            rimMesh,
            nameCanvas,
            nameTex,
            nameSprite,
            colorHex: isAwakened ? 0x00e5ff : colorHex,
            displayName: name,
            isSelf
        };

        // เนเธซเธฅเธ”เธฃเธนเธเนเธเธฃเนเธเธฅเน Google / LINE
        const { avatarUrl } = this.resolveProfileAvatar(userData);
        if (avatarUrl) {
            this.loadAndApplyProfileTexture(pawnGroup, avatarUrl, name, rimColor, userGrade);
        }

        return pawnGroup;
    }

    updatePlayerPawnName(newName) {
        if (!this.playerPawn || !this.playerPawn.userData || !this.playerPawn.userData.nameCanvas) return;
        const canvas = this.playerPawn.userData.nameCanvas;
        const nctx = canvas.getContext('2d');
        nctx.clearRect(0, 0, canvas.width, canvas.height);
        nctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        if (typeof nctx.roundRect === 'function') {
            nctx.roundRect(10, 10, 360, 80, 16);
        } else {
            nctx.rect(10, 10, 360, 80);
        }
        nctx.fill();
        nctx.strokeStyle = '#00e5ff';
        nctx.lineWidth = 3;
        nctx.stroke();

        nctx.fillStyle = '#ffffff';
        nctx.font = 'bold 28px Kanit, sans-serif';
        nctx.textAlign = 'center';
        nctx.fillText(`(คุณ) ${newName}`, 190, 48);

        nctx.fillStyle = '#38bdf8';
        nctx.font = '20px Kanit, sans-serif';
        const roleLabel = (this.clanData?.my_role === 'leader' || this.clanData?.is_leader) ? '👑 หัวหน้าบ้าน' : '👤 สมาชิก';
        nctx.fillText(roleLabel, 190, 76);

        if (this.playerPawn.userData.nameTex) {
            this.playerPawn.userData.nameTex.needsUpdate = true;
        }
        this.playerPawn.userData.displayName = newName;
    }

    loadAndApplyProfileTexture(pawnGroup, resolvedUrl, displayName, rimColorHex, grade = 'A') {
        if (!pawnGroup || !pawnGroup.userData || !resolvedUrl) return;
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            if (pawnGroup && pawnGroup.userData && pawnGroup.userData.headDiscMesh) {
                const updatedTex = this.createCircularAvatarCanvasTexture(img, rimColorHex, displayName, grade);
                pawnGroup.userData.headDiscMesh.material.map = updatedTex;
                pawnGroup.userData.headDiscMesh.material.needsUpdate = true;
            }
        };
        img.onerror = () => {
            // Fallback gracefully to default avatar image
            const fbImg = new Image();
            fbImg.crossOrigin = 'anonymous';
            fbImg.onload = () => {
                if (pawnGroup && pawnGroup.userData && pawnGroup.userData.headDiscMesh) {
                    const updatedTex = this.createCircularAvatarCanvasTexture(fbImg, rimColorHex, displayName, grade);
                    pawnGroup.userData.headDiscMesh.material.map = updatedTex;
                    pawnGroup.userData.headDiscMesh.material.needsUpdate = true;
                }
            };
            fbImg.src = 'avatars/google_avatar.png';
        };
        img.src = resolvedUrl;
    }

    /**
     * เธซเธกเธธเธเนเธเนเธเธฃเธนเธเนเธเธฃเนเธเธฅเนเธงเธเธเธฅเธกเนเธซเนเธซเธฑเธเธซเธเนเธฒเน€เธเนเธฒเธซเธฒเธเธฅเนเธญเธ (Look at Camera) เธ•เธฅเธญเธ”เน€เธงเธฅเธฒ
     */
    orientPawnHeadToCamera(pawn) {
        if (!pawn || !pawn.userData || !pawn.userData.headBadgeGroup || !this.camera) return;
        pawn.userData.headBadgeGroup.lookAt(this.camera.position);
    }

    /**
     * เธเธฑเธ”เธงเธฒเธเธ•เธฑเธงเธฅเธฐเธเธฃเธเธญเธเธเธนเนเน€เธฅเนเธเนเธฅเธฐเธฅเธนเธเธเนเธฒเธเนเธเธซเนเธญเธ 3D
     */
    getRandomWalkableSpot() {
        for (let tries = 0; tries < 25; tries++) {
            const rx = (Math.random() - 0.5) * 13.0; // -6.5 to 6.5
            const rz = -6.5 + Math.random() * 8.5;  // -6.5 to 2.0
            let hit = false;
            for (const obs of this.obstacles) {
                if (rx >= obs.minX - 0.6 && rx <= obs.maxX + 0.6 &&
                    rz >= obs.minZ - 0.6 && rz <= obs.maxZ + 0.6) {
                    hit = true;
                    break;
                }
            }
            if (!hit) {
                return { x: rx, z: rz };
            }
        }
        return { x: 0, z: -2.5 };
    }

    startPawnWalk(pawn, tx, tz) {
        if (!pawn || !pawn.userData) return;
        pawn.userData.targetPos.set(tx, this.getRestingHeight(tx, tz), tz);
        pawn.userData.isWalking = true;
    }

    updateWalkers(delta) {
        if (!this.otherPawns || this.otherPawns.length === 0) return;
        this.otherPawns.forEach(pawn => {
            if (!pawn.userData || !pawn.userData.isWalker || !pawn.userData.isWalking) return;
            const current = pawn.position;
            const target = pawn.userData.targetPos;
            const dirX = target.x - current.x;
            const dirZ = target.z - current.z;
            const dist = Math.hypot(dirX, dirZ);

            if (dist > 0.15) {
                // Face moving direction
                const targetAngle = Math.atan2(dirX, dirZ);
                let angleDiff = targetAngle - pawn.rotation.y;
                while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
                while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
                pawn.rotation.y += angleDiff * Math.min(delta * 8, 1);

                // Move forward
                const speed = pawn.userData.walkSpeed || 3.8;
                const moveDist = speed * delta;
                const ratio = Math.min(moveDist / dist, 1);
                current.x += dirX * ratio;
                current.z += dirZ * ratio;

                // Bobbing step
                pawn.userData.walkCycle += delta * 12;
                const restingY = this.getRestingHeight(current.x, current.z);
                current.y = restingY + Math.abs(Math.sin(pawn.userData.walkCycle)) * 0.28;
            } else {
                current.x = target.x;
                current.z = target.z;
                current.y = this.getRestingHeight(target.x, target.z);
                pawn.userData.baseY = current.y;
                pawn.userData.isWalking = false;
            }
        });
    }

    showSpeechBubbleOnPawn(pawn, message = '', durationMs = 3800) {
        const text = String(message || '').trim();
        if (!text || !pawn) return;

        // ตรวจสอบว่าถ้าสมาชิกคนอื่นพูดแล้ว @ หาผู้เล่น ให้แจ้งเตือน "ชื่อ..พูดถึงคุณ"
        if (pawn !== this.playerPawn && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
            const speakerName = pawn.userData?.displayName || 'สมาชิกในบ้าน';
            const speakerAvatar = pawn.userData?.avatarUrl || 'avatars/google_avatar.png';
            if (typeof window.notifyUserMentioned === 'function') {
                window.notifyUserMentioned(speakerName, text, speakerAvatar);
            }
        }

        if (pawn.userData.activeBubbleSprite) {
            pawn.remove(pawn.userData.activeBubbleSprite);
            pawn.userData.activeBubbleSprite = null;
        }

        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 260;
        const ctx = canvas.getContext('2d');

        const stripped = text.replace(/\s+/g, '');
        const hasLetterOrDigit = /[A-Za-z0-9\u0E00-\u0E7F@]/.test(stripped);
        const isEmojiOnly = !hasLetterOrDigit && stripped.length > 0 && Array.from(stripped).length <= 4;

        if (isEmojiOnly) {
            // กรอบวงรีสีขาวขอบเข้มพร้อมหางชี้ สำหรับอิโมจิ (Oval Emoji Speech Bubble)
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#1e293b';
            ctx.lineWidth = 6;

            // ตัวฟองสบู่รูปวงรีแนวนอน (Horizontal Oval)
            ctx.beginPath();
            ctx.ellipse(256, 105, 125, 78, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // ติ่งหางชี้ลงกลางหัวตัวละคร (Pointer tail)
            ctx.beginPath();
            ctx.moveTo(242, 178);
            ctx.lineTo(256, 230);
            ctx.lineTo(270, 178);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // ลบเส้นขอบรอยต่อด้านในหาง
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.ellipse(256, 105, 121, 74, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(244, 174);
            ctx.lineTo(256, 226);
            ctx.lineTo(268, 174);
            ctx.closePath();
            ctx.fill();

            // วาดตัวอิโมจิอย่างคมชัดตรงกลางฟองวงรี
            ctx.font = '82px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, 256, 105);
        } else {
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#1e293b';
            ctx.lineWidth = 7;

            ctx.beginPath();
            ctx.ellipse(256, 105, 218, 76, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            ctx.beginPath();
            ctx.moveTo(236, 165);
            ctx.lineTo(256, 218);
            ctx.lineTo(276, 165);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.ellipse(256, 105, 214, 72, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(237, 160);
            ctx.lineTo(256, 214);
            ctx.lineTo(275, 160);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#0f172a';
            ctx.font = 'bold 34px "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const displayStr = text.length > 22 ? text.substring(0, 22) + '…' : text;
            ctx.fillText(displayStr, 256, 106);
        }

        const tex = new THREE.CanvasTexture(canvas);
        const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 1 });
        const sprite = new THREE.Sprite(mat);

        if (isEmojiOnly) {
            sprite.position.set(0, 4.5, 0);
            sprite.scale.set(3.0, 1.52, 1);
        } else {
            sprite.position.set(0, 4.75, 0);
            sprite.scale.set(4.0, 2.03, 1);
        }

        pawn.add(sprite);
        pawn.userData.activeBubbleSprite = sprite;

        setTimeout(() => {
            let fadeInterval = setInterval(() => {
                if (!pawn.userData.activeBubbleSprite) {
                    clearInterval(fadeInterval);
                    return;
                }
                pawn.userData.activeBubbleSprite.material.opacity -= 0.08;
                if (pawn.userData.activeBubbleSprite.material.opacity <= 0) {
                    clearInterval(fadeInterval);
                    pawn.remove(pawn.userData.activeBubbleSprite);
                    pawn.userData.activeBubbleSprite = null;
                }
            }, 35);
        }, durationMs - 450);
    }

    updateRoomMembers(clanData, currentUser) {
        this.clanData = clanData;
        this.currentUser = currentUser;

        // 1. Remove old pawns
        if (this.playerPawn) {
            this.scene.remove(this.playerPawn);
            this.playerPawn = null;
        }
        this.otherPawns.forEach(p => this.scene.remove(p));
        this.otherPawns = [];

        // บ้านพักส่วนกลาง (Public Lounge) สำหรับทุกคนร่วมเข้าได้
        const isPublicLounge = !clanData || !clanData.has_clan;

        // 2. Spawn current user's active character at center/front
        const activeUser = currentUser || (typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER : {});
        const myName = activeUser?.displayName || activeUser?.name || activeUser?.username || 'ผู้เล่น';
        const myRole = isPublicLounge ? 'guest' : (clanData?.my_role || 'member');
        const roleLabels = {
            'leader': '👑 หัวหน้าบ้าน',
            'co_leader': '🥈 รองหัวหน้า',
            'elder': '🥉 สมาชิกอาวุโส',
            'member': '👤 สมาชิก',
            'guest': '🏠 ผู้พักผ่อน'
        };
        const myRoleLabel = roleLabels[myRole] || '👤 สมาชิก';

        this.playerPawn = this.createCharacterPawn(`(คุณ) ${myName}`, 0x00e5ff, true, myRoleLabel, activeUser, true);
        this.playerPawn.position.set(0, 0, -2.8);
        this.scene.add(this.playerPawn);
        this.orientPawnHeadToCamera(this.playerPawn);

        // 3. แสดงสมาชิกคนอื่นในห้อง 3D ตามจำนวนคนที่ออนไลน์จริงเท่านั้น
        // ไม่ดึงบอทคนแปลกหน้าจากครอบครัวอื่นมาสุ่มใส่ห้องเด็ดขาด!
        const realMembers = Array.isArray(clanData?.members) ? clanData.members : [];
        const isAiFamily = Boolean(clanData?.is_ai_family || clanData?.isAiFamily);

        let onlineOthers = [];
        if (!isAiFamily && realMembers.length > 0) {
            // ครอบครัวจริงของผู้เล่นจากฐานข้อมูล (เช่น @PIMMY สมาชิก 3 คน ออนไลน์ 1 คน):
            // ดึงเฉพาะสมาชิกคนอื่นที่เป็นสมาชิกในบ้านนี้จริง และสถานะออนไลน์จริงเท่านั้น
            onlineOthers = realMembers.filter(m => {
                const isMe = (m.id === activeUser?.id || m.username === activeUser?.username || m.username === myName);
                return !isMe && Boolean(m.is_online);
            });
        } else if (isAiFamily && realMembers.length > 0) {
            // กรณีเปิดตรวจดูห้อง 3D ของครอบครัว AI:
            // ดึงเฉพาะสมาชิกของครอบครัวนั้นที่ออนไลน์อยู่ในบ้าน (0-15 คน)
            onlineOthers = realMembers.filter(m => {
                const isMe = (m.id === activeUser?.id || m.username === activeUser?.username);
                return !isMe && Boolean(m.is_online) && (m.status?.type === 'house' || m.status?.type === 'lobby' || !m.status);
            }).slice(0, 8);
        }

        // จุดยืนและจุดนั่งในห้องนั่งเล่น 3D
        const roomSpots = [
            { x: -3.0, z: 4.6, rot: 0, isWalker: false },     // sofa left (sitting)
            { x: 3.0, z: 4.6, rot: 0, isWalker: false },      // sofa right (sitting)
            { x: 0.0, z: 4.6, rot: 0, isWalker: false },      // sofa center (sitting)
            { x: -5.8, z: -1.0, rot: 1.1, isWalker: false },  // chilling near floor lamp
            { x: 5.2, z: 0.5, rot: -1.2, isWalker: true },    // Walker 1 (near table)
            { x: -4.2, z: -5.8, rot: 0.3, isWalker: true },   // Walker 2 (near TV left)
            { x: 4.2, z: -5.8, rot: -0.3, isWalker: true },   // Walker 3 (near TV right)
            { x: -2.8, z: -2.0, rot: 0.8, isWalker: true },   // Walker 4 (open carpet)
            { x: 2.8, z: -2.0, rot: -0.8, isWalker: true }    // Walker 5 (open carpet right)
        ];

        // สร้างตัวละครเฉพาะตามจำนวนสมาชิกคนอื่นที่ออนไลน์จริง (ถ้าออนไลน์แค่เราคนเดียว จะมีแค่เราในห้อง)
        onlineOthers.slice(0, roomSpots.length).forEach((spotMember, idx) => {
            const spot = roomSpots[idx];
            const m = spotMember;
            if (!m) return;
            const roleLabel = roleLabels[m.clan_role || m.role] || '👤 สมาชิก';
            const colorHex = spot.isWalker ? 0x00e5ff : 0xec4899;
            const pawn = this.createCharacterPawn(m.username, colorHex, false, roleLabel, m, false);
            const baseY = this.getRestingHeight(spot.x, spot.z);
            pawn.position.set(spot.x, baseY, spot.z);
            pawn.userData.baseY = baseY;
            pawn.userData.avatarUrl = m.avatar_url || m.picture || 'avatars/google_avatar.png';
            pawn.userData.displayName = m.username;
            pawn.userData.isWalker = Boolean(spot.isWalker);
            pawn.userData.isWalking = false;
            pawn.userData.walkCycle = Math.random() * 10;
            pawn.userData.walkSpeed = 3.5 + Math.random() * 1.5;
            pawn.userData.targetPos = new THREE.Vector3(spot.x, baseY, spot.z);
            pawn.rotation.y = spot.rot;
            this.scene.add(pawn);
            this.orientPawnHeadToCamera(pawn);
            this.otherPawns.push(pawn);
        });

        // 4. เริ่มระบบการเดินและการคุย เฉพาะเมื่อมีสมาชิกคนอื่นอยู่ในห้องจริงเท่านั้น
        if (this.otherPawns.length > 0 && typeof window.startLivelyRoomAutomation === 'function') {
            window.startLivelyRoomAutomation(this);
        }

        // 5. Refresh TV Screen text & Members Wall Board
        this.updateTVScreen();
        this.updateMembersBoard();
    }
    /**
     * เนเธชเธ”เธเธเธฅเนเธญเธเธเนเธญเธเธงเธฒเธก (Speech Bubble) เธชเนเธ•เธฅเนเธเธฒเธฃเนเธ•เธนเธเนเธเนเธเธกเธเธฅเธญเธขเน€เธซเธเธทเธญเธซเธฑเธงเธ•เธฑเธงเธฅเธฐเธเธฃเนเธเธซเนเธญเธเธเนเธฒเธ 3D
     * เนเธฅเธฐเธเนเธญเธขเน เธเธฒเธเธซเธฒเธขเนเธเธญเธฑเธ•เนเธเธกเธฑเธ•เธด (Fade Out) เนเธ 4 เธงเธดเธเธฒเธ—เธต
     */
    showPawnSpeechBubble(message = '', durationMs = 4000) {
        const text = String(message || '').trim();
        if (!text || !this.playerPawn) return;

        // เธฅเนเธฒเธเธเธฅเนเธญเธเธเนเธญเธเธงเธฒเธกเน€เธเนเธฒเธ–เนเธฒเธกเธตเธญเธขเธนเน
        if (this.activeBubbleSprite) {
            this.playerPawn.remove(this.activeBubbleSprite);
            this.activeBubbleSprite = null;
        }
        if (this.bubbleFadeInterval) {
            clearInterval(this.bubbleFadeInterval);
            this.bubbleFadeInterval = null;
        }
        if (this.bubbleTimeout) {
            clearTimeout(this.bubbleTimeout);
            this.bubbleTimeout = null;
        }

        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 260;
        const ctx = canvas.getContext('2d');

        const stripped = text.replace(/\s+/g, '');
        const hasLetterOrDigit = /[A-Za-z0-9\u0E00-\u0E7F@]/.test(stripped);
        const isEmojiOnly = !hasLetterOrDigit && stripped.length > 0 && Array.from(stripped).length <= 4;

        if (isEmojiOnly) {
            // กรอบวงรีสีขาวขอบเข้มพร้อมหางชี้ สำหรับอิโมจิ (Oval Emoji Speech Bubble)
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#1e293b';
            ctx.lineWidth = 6;

            // ตัวฟองสบู่รูปวงรีแนวนอน (Horizontal Oval)
            ctx.beginPath();
            ctx.ellipse(256, 105, 125, 78, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // ติ่งหางชี้ลงกลางหัวตัวละคร (Pointer tail)
            ctx.beginPath();
            ctx.moveTo(242, 178);
            ctx.lineTo(256, 230);
            ctx.lineTo(270, 178);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // ลบเส้นขอบรอยต่อด้านในหาง
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.ellipse(256, 105, 121, 74, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(244, 174);
            ctx.lineTo(256, 226);
            ctx.lineTo(268, 174);
            ctx.closePath();
            ctx.fill();

            // วาดตัวอิโมจิอย่างคมชัดตรงกลางฟองวงรี
            ctx.font = '82px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, 256, 105);
        } else {
            // หากเป็นข้อความ ให้แสดงกล่องข้อความวงรีสีขาวขอบดำ มีหางชี้ตรงกลางหัวตัวละคร
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#1e293b';
            ctx.lineWidth = 7;

            ctx.beginPath();
            ctx.ellipse(256, 105, 218, 76, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // ติ่งหางชี้ลงตรงกลางหัวตัวละครพอดี (Center Tail)
            ctx.beginPath();
            ctx.moveTo(236, 165);
            ctx.lineTo(256, 218);
            ctx.lineTo(276, 165);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // ลบเส้นรอยต่อด้านในหาง
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.ellipse(256, 105, 214, 72, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(237, 160);
            ctx.lineTo(256, 214);
            ctx.lineTo(275, 160);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#0f172a';
            ctx.font = 'bold 34px "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const displayStr = text.length > 22 ? text.substring(0, 22) + '…' : text;
            ctx.fillText(displayStr, 256, 106);
        }

        const tex = new THREE.CanvasTexture(canvas);
        const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 1 });
        const sprite = new THREE.Sprite(mat);
        if (isEmojiOnly) {
            sprite.position.set(0, 4.5, 0);
            sprite.scale.set(3.0, 1.52, 1);
        } else {
            sprite.position.set(0, 4.75, 0);
            sprite.scale.set(4.0, 2.03, 1);
        }
        this.playerPawn.add(sprite);
        this.activeBubbleSprite = sprite;

        const clamped = Math.min(Math.max(Number(durationMs) || 4000, 3000), 5000);
        this.bubbleTimeout = setTimeout(() => {
            this.bubbleFadeInterval = setInterval(() => {
                if (!this.activeBubbleSprite) {
                    clearInterval(this.bubbleFadeInterval);
                    return;
                }
                this.activeBubbleSprite.material.opacity -= 0.08;
                if (this.activeBubbleSprite.material.opacity <= 0) {
                    clearInterval(this.bubbleFadeInterval);
                    if (this.playerPawn && this.activeBubbleSprite) {
                        this.playerPawn.remove(this.activeBubbleSprite);
                    }
                    this.activeBubbleSprite = null;
                }
            }, 35);
        }, clamped - 450);
    }

    /**
     * Line-segment vs AABB obstacle intersection check (Liang-Barsky slab algorithm)
     */
    lineIntersectsObstacle(x1, z1, x2, z2, obs, margin = 0.35) {
        const minX = obs.minX - margin;
        const maxX = obs.maxX + margin;
        const minZ = obs.minZ - margin;
        const maxZ = obs.maxZ + margin;

        // Check endpoints
        if ((x1 >= minX && x1 <= maxX && z1 >= minZ && z1 <= maxZ) ||
            (x2 >= minX && x2 <= maxX && z2 >= minZ && z2 <= maxZ)) {
            return true;
        }

        const dx = x2 - x1;
        const dz = z2 - z1;
        let tmin = 0;
        let tmax = 1;

        if (Math.abs(dx) < 1e-7) {
            if (x1 < minX || x1 > maxX) return false;
        } else {
            const tx1 = (minX - x1) / dx;
            const tx2 = (maxX - x1) / dx;
            tmin = Math.max(tmin, Math.min(tx1, tx2));
            tmax = Math.min(tmax, Math.max(tx1, tx2));
            if (tmin > tmax) return false;
        }

        if (Math.abs(dz) < 1e-7) {
            if (z1 < minZ || z1 > maxZ) return false;
        } else {
            const tz1 = (minZ - z1) / dz;
            const tz2 = (maxZ - z1) / dz;
            tmin = Math.max(tmin, Math.min(tz1, tz2));
            tmax = Math.min(tmax, Math.max(tz1, tz2));
            if (tmin > tmax) return false;
        }

        return tmin <= tmax && tmax >= 0 && tmin <= 1;
    }

    /**
     * Check if path between two points is blocked by any furniture
     */
    isPathBlocked(x1, z1, x2, z2, ignoreObstacleId = null) {
        for (const obs of this.obstacles) {
            if (ignoreObstacleId && obs.id === ignoreObstacleId) continue;
            if (this.lineIntersectsObstacle(x1, z1, x2, z2, obs)) {
                return obs;
            }
        }
        return null;
    }

    /**
     * Intelligent pathfinding avoiding sofa, coffee table and TV unit
     * Generates waypoints navigating smoothly around furniture corridors
     */
    findNavPath(startX, startZ, destX, destZ) {
        // 1. Clamp inside room
        let targetX = Math.max(-11.2, Math.min(11.2, destX));
        let targetZ = Math.max(-8.5, Math.min(8.5, destZ));

        // 2. If target clicks directly inside table, project outside
        for (const obs of this.obstacles) {
            if (obs.id === 'table' && targetX >= obs.minX && targetX <= obs.maxX && targetZ >= obs.minZ && targetZ <= obs.maxZ) {
                targetZ = (targetZ < 0.35) ? -1.1 : 2.0;
            }
            if (obs.id === 'sofa' && targetX >= obs.minX && targetX <= obs.maxX && targetZ >= obs.minZ && targetZ <= obs.maxZ) {
                // If clicked cushion, allow sitting at z = 4.2
                if (targetZ <= 4.6 && Math.abs(targetX) <= 3.8) {
                    targetZ = 4.2;
                } else {
                    targetZ = (targetZ > 5.0) ? 6.8 : 2.0;
                }
            }
        }

        // 3. Direct line of sight test
        if (!this.isPathBlocked(startX, startZ, targetX, targetZ)) {
            return [new THREE.Vector3(targetX, 0, targetZ)];
        }

        // 4. Blocked! Route around sofa / table through side aisles (x = -5.8 or x = +5.8)
        const distViaLeft = Math.abs(startX - (-5.8)) + Math.abs(targetX - (-5.8));
        const distViaRight = Math.abs(startX - 5.8) + Math.abs(targetX - 5.8);
        const sideX = (distViaLeft <= distViaRight) ? -5.8 : 5.8;

        const waypoints = [];

        // If start is in the interior central zone (|x| < 4.8), first step out to the aisle along current corridor
        if (Math.abs(startX) < 4.8) {
            waypoints.push(new THREE.Vector3(sideX, 0, startZ));
        }

        // Walk along the side aisle to the target's Z corridor
        waypoints.push(new THREE.Vector3(sideX, 0, targetZ));

        // Finally walk in from the side aisle to the target destination
        waypoints.push(new THREE.Vector3(targetX, 0, targetZ));

        // 5. String-pulling simplification (skip redundant waypoints if direct line is clear)
        const simplified = [];
        let curr = new THREE.Vector3(startX, 0, startZ);

        for (let i = 0; i < waypoints.length; i++) {
            const wp = waypoints[i];
            const nextWp = (i + 1 < waypoints.length) ? waypoints[i + 1] : null;

            if (nextWp && !this.isPathBlocked(curr.x, curr.z, nextWp.x, nextWp.z)) {
                // Can see next waypoint directly, skip current
                continue;
            }
            simplified.push(wp);
            curr = wp;
        }

        return simplified.length > 0 ? simplified : [new THREE.Vector3(targetX, 0, targetZ)];
    }

    /**
     * Navigate player character along smart obstacle-avoiding waypoints
     */
    navigateTo(destX, destZ) {
        if (!this.playerPawn) return;
        const current = this.playerPawn.position;
        const path = this.findNavPath(current.x, current.z, destX, destZ);
        if (!path || path.length === 0) return;

        this.waypointPath = path;
        const finalDest = path[path.length - 1];
        this.targetPos.copy(finalDest);
        this.isMoving = true;

        if (this.targetRing) {
            this.targetRing.position.set(finalDest.x, 0.04, finalDest.z);
            this.targetRing.material.opacity = 0.85;
            this.targetRing.scale.set(1, 1, 1);
        }
    }

    /**
     * Click on Floor -> Move Character smoothly avoiding obstacles
     */
    onPointerDown(event) {
        if (!this.floorMesh || !this.playerPawn) return;

        const rect = this.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObject(this.floorMesh);

        if (intersects.length > 0) {
            const hitPoint = intersects[0].point;
            this.navigateTo(hitPoint.x, hitPoint.z);
        }
    }

    moveToPosition(x, z) {
        this.navigateTo(x, z);
    }

    onResize() {
        if (!this.container || !this.renderer || !this.camera) return;
        const width = this.container.clientWidth;
        const height = this.container.clientHeight;
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
    }

    animate() {
        this.animFrameId = requestAnimationFrame(() => this.animate());

        const delta = Math.min(this.clock.getDelta(), 0.1);

        if (this.controls) this.controls.update();

        // 0. Update other walking clan members
        this.updateWalkers(delta);

        // 1. Character Movement Logic with Waypoint Obstacle Avoidance
        if (this.isMoving && this.playerPawn && this.waypointPath && this.waypointPath.length > 0) {
            const current = this.playerPawn.position;
            const currentWP = this.waypointPath[0];
            const dirX = currentWP.x - current.x;
            const dirZ = currentWP.z - current.z;
            const dist = Math.hypot(dirX, dirZ);

            if (dist > 0.18) {
                // Face moving direction smoothly
                const targetAngle = Math.atan2(dirX, dirZ);
                let angleDiff = targetAngle - this.playerPawn.rotation.y;
                while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
                while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
                this.playerPawn.rotation.y += angleDiff * Math.min(delta * 12, 1);

                // Move forward towards current waypoint
                const moveDist = this.moveSpeed * delta;
                const ratio = Math.min(moveDist / dist, 1);
                current.x += dirX * ratio;
                current.z += dirZ * ratio;

                // Walking bobbing step
                this.walkCycle += delta * 14;
                const restingY = this.getRestingHeight(current.x, current.z);
                current.y = restingY + Math.abs(Math.sin(this.walkCycle)) * 0.35;

                // Pulse target ring at final destination
                if (this.targetRing) {
                    const s = 1.0 + Math.sin(this.walkCycle * 2) * 0.15;
                    this.targetRing.scale.set(s, s, s);
                }
            } else {
                // Reached current waypoint
                this.waypointPath.shift();
                if (this.waypointPath.length === 0) {
                    // Arrived at final destination
                    current.x = currentWP.x;
                    current.z = currentWP.z;
                    current.y = this.getRestingHeight(currentWP.x, currentWP.z);
                    this.isMoving = false;

                    // Fade target ring
                    if (this.targetRing) {
                        this.targetRing.material.opacity = 0;
                    }
                }
            }
                } else if (this.playerPawn) {
            // Idle gentle breathing bob with sitting/resting height
            const t = performance.now() * 0.002;
            const baseY = this.getRestingHeight(this.playerPawn.position.x, this.playerPawn.position.z);
            this.playerPawn.position.y = baseY + Math.sin(t) * 0.04;
        }

        // อัปเดต Idle bobbing สำหรับสมาชิกคนอื่นๆ ในห้อง พร้อมรักษาระดับความสูงบนโซฟา
        if (this.otherPawns && this.otherPawns.length > 0) {
            const t = performance.now() * 0.002;
            this.otherPawns.forEach((p, idx) => {
                const bY = p.userData.baseY !== undefined ? p.userData.baseY : this.getRestingHeight(p.position.x, p.position.z);
                p.position.y = bY + Math.sin(t + idx * 1.5) * 0.03;
            });
        }

        // หันหน้าแผ่นรูปโปรไฟล์วงกลมเข้าหากล้อง (Look at Camera) ตลอดเวลา
        if (this.playerPawn) this.orientPawnHeadToCamera(this.playerPawn);
        if (this.otherPawns) this.otherPawns.forEach(p => this.orientPawnHeadToCamera(p));

        // Render scene
        if (this.renderer && this.scene && this.camera) {
            this.renderer.render(this.scene, this.camera);
        }
    }

    destroy() {
        if (typeof window.stopLivelyRoomAutomation === 'function') {
            window.stopLivelyRoomAutomation();
        }
        if (this.animFrameId) {
            cancelAnimationFrame(this.animFrameId);
        }
        if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentNode) {
            this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
        }
    }

    /**
     * เธชเธฃเนเธฒเธเธเธฃเธฐเธ”เธฒเธเธ—เธณเน€เธเธตเธขเธเธชเธกเธฒเธเธดเธเธเธฃเธญเธเธเธฃเธฑเธง 3D เธเธเธเธเธฑเธเธเธงเธฒ (Members Roster Wall Board)
     * เนเธชเธ”เธเธฃเธนเธเนเธเธเธงเธเธเธฅเธก 5 เนเธ–เธงเน เธฅเธฐ 6 เธเธ (เธเธฃเธ 30 เธเนเธญเธ เน€เธฃเธตเธขเธเธ•เธฒเธกเธฅเธณเธ”เธฑเธเธเธฒเธฃเน€เธเนเธฒเธฃเนเธงเธก)
     */
    buildMembersBoard() {
        const boardGroup = new THREE.Group();

        // เธเธฃเธญเธเธเธญเธเธเธฃเธฐเธ”เธฒเธเธ•เธดเธ”เธเธเธฑเธเธเธงเธฒ (เธซเธฑเธเธซเธเนเธฒเน€เธเนเธฒเธซเนเธญเธ)
        const frameGeo = new THREE.BoxGeometry(0.22, 7.6, 11.2);
        const frameMat = new THREE.MeshStandardMaterial({
            color: 0x0b132b,
            metalness: 0.85,
            roughness: 0.2,
            emissive: 0x00e5ff,
            emissiveIntensity: 0.25
        });
        const frame = new THREE.Mesh(frameGeo, frameMat);
        frame.position.set(12.85, 6.0, 0);
        boardGroup.add(frame);

        // เน€เธชเนเธเธเธญเธเธเธตเธญเธญเธเน€เธฃเธทเธญเธเนเธชเธ
        const edgeGeo = new THREE.BoxGeometry(0.24, 7.45, 11.05);
        const edgeMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, wireframe: true });
        const edgeBox = new THREE.Mesh(edgeGeo, edgeMat);
        edgeBox.position.set(12.84, 6.0, 0);
        boardGroup.add(edgeBox);

        // เธเธญเนเธเธเธงเธฒเธชเนเธชเธ”เธเธเธฅเธ—เธณเน€เธเธตเธขเธเธชเธกเธฒเธเธดเธ (1500 x 1020)
        this.membersCanvas = document.createElement('canvas');
        this.membersCanvas.width = 1500;
        this.membersCanvas.height = 1020;
        this.membersBoardTexture = new THREE.CanvasTexture(this.membersCanvas);
        this.membersBoardTexture.anisotropy = 8;

        const screenGeo = new THREE.PlaneGeometry(10.8, 7.2);
        const screenMat = new THREE.MeshBasicMaterial({
            map: this.membersBoardTexture,
            side: THREE.DoubleSide
        });
        const screen = new THREE.Mesh(screenGeo, screenMat);
        screen.position.set(12.72, 6.0, 0);
        screen.rotation.y = -Math.PI / 2;
        boardGroup.add(screen);

        this.scene.add(boardGroup);
        this.membersBoardGroup = boardGroup;

        this.memberAvatarImageCache = new Map();
        this.updateMembersBoard();
    }

    /**
     * เธงเธฒเธ”เธ—เธณเน€เธเธตเธขเธเธชเธกเธฒเธเธดเธเธเธฃเธญเธเธเธฃเธฑเธง 3D เธฅเธเนเธ Canvas Texture
     * เน€เธฃเธตเธขเธเธ•เธฒเธกเธเธฒเธฃเน€เธเนเธฒเธฃเนเธงเธก เนเธชเธ”เธเนเธเธฃเธนเธเนเธเธเธงเธเธเธฅเธก 5 เนเธ–เธงเน เธฅเธฐ 6 เธเธ (เธฃเธงเธก 30 เธเธ)
     */
    updateMembersBoard() {
        if (!this.membersCanvas || !this.membersBoardTexture) return;
        const ctx = this.membersCanvas.getContext('2d');
        const W = this.membersCanvas.width;
        const H = this.membersCanvas.height;

        let members = (this.clanData?.members || []).slice();
        if (members.length === 0) {
            const u = this.currentUser || (typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER : null);
            if (u) {
                members = [{
                    user_id: u.id || 1,
                    username: u.username || u.name || 'หัวหน้าบ้าน',
                    role: this.clanData?.my_role || 'leader',
                    picture: u.picture || u.pictureUrl || u.avatar_url || '',
                    joined_at: new Date().toISOString()
                }];
            }
        }

        // เน€เธฃเธตเธขเธเธฅเธณเธ”เธฑเธเธชเธกเธฒเธเธดเธเธ•เธฒเธกเน€เธงเธฅเธฒเธเธฒเธฃเน€เธเนเธฒเธฃเนเธงเธก (joined_at)
        members.sort((a, b) => {
            if (a.role === 'leader') return -1;
            if (b.role === 'leader') return 1;
            const tA = a.joined_at ? new Date(a.joined_at).getTime() : 0;
            const tB = b.joined_at ? new Date(b.joined_at).getTime() : 0;
            return tA - tB;
        });

        // 1. เธเธทเนเธเธซเธฅเธฑเธเธเธฃเธฐเธ”เธฒเธ
        ctx.fillStyle = '#070d19';
        ctx.fillRect(0, 0, W, H);

        const bgGrad = ctx.createLinearGradient(0, 0, W, H);
        bgGrad.addColorStop(0, 'rgba(14, 165, 233, 0.12)');
        bgGrad.addColorStop(0.5, 'rgba(15, 23, 42, 0.85)');
        bgGrad.addColorStop(1, 'rgba(217, 119, 6, 0.08)');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, W, H);

        ctx.strokeStyle = 'rgba(0, 229, 255, 0.08)';
        ctx.lineWidth = 1;
        for (let x = 0; x < W; x += 40) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
        }
        for (let y = 0; y < H; y += 40) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
        }

        // 2. เธชเนเธงเธเธซเธฑเธงเธเธฃเธฐเธ”เธฒเธ (Header)
        const clanName = this.clanData?.clan?.clan_name || 'บ้านพญานาคราช 3D';
        const clanTag = this.clanData?.clan?.tag || 'HOME';

        ctx.fillStyle = '#0f172a';
        ctx.fillRect(30, 25, W - 60, 95);
        ctx.strokeStyle = 'rgba(0, 229, 255, 0.6)';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(30, 25, W - 60, 95);

        ctx.font = 'bold 36px "Kanit", sans-serif';
        ctx.fillStyle = '#00e5ff';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(`👑 ทำเนียบสมาชิกครอบครัว [${clanTag}] ${clanName}`, 55, 62);

        ctx.font = '500 20px "Kanit", sans-serif';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('เรียงตามลำดับการเข้าร่วม • รูปแบบวงกลม 5 แถวๆ ละ 6 คน (สูงสุด 30 คน)', 55, 96);

        // Pill เธเธณเธเธงเธเธชเธกเธฒเธเธดเธ
        ctx.save();
        ctx.fillStyle = '#0369a1';
        ctx.beginPath();
        ctx.roundRect(W - 320, 45, 270, 52, 26);
        ctx.fill();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.font = 'bold 22px "Kanit", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(`👥 สมาชิก: ${members.length} / 30 คน`, W - 185, 71);
        ctx.restore();

        // 3. เธงเธฒเธ”เธ•เธฒเธฃเธฒเธเธงเธเธเธฅเธก 5 เนเธ–เธงเน เธฅเธฐ 6 เธเธ = 30 เธเนเธญเธ
        const cols = 6;
        const rows = 5;
        const startX = 60;
        const startY = 145;
        const cellW = (W - startX * 2) / cols;
        const cellH = (H - startY - 30) / rows;
        const avatarRadius = 42;

        for (let slot = 0; slot < 30; slot++) {
            const r = Math.floor(slot / cols);
            const c = slot % cols;
            const cx = startX + c * cellW + cellW / 2;
            const cy = startY + r * cellH + 54;
            const member = members[slot];

            if (member) {
                const isLeader = member.role === 'leader' || slot === 0;
                const memberName = member.display_name || member.name || member.username || `ลูกบ้าน #${slot + 1}`;
                const rawPic = member.picture || member.pictureUrl || member.avatar_url || '';

                // เธเธฃเธญเธเธงเธเธเธฅเธกเน€เธฃเธทเธญเธเนเธชเธ
                ctx.save();
                ctx.beginPath();
                ctx.arc(cx, cy, avatarRadius + 4, 0, Math.PI * 2);
                ctx.fillStyle = isLeader ? 'rgba(255, 215, 0, 0.25)' : 'rgba(0, 229, 255, 0.2)';
                ctx.fill();
                ctx.strokeStyle = isLeader ? '#ffd700' : '#00e5ff';
                ctx.lineWidth = isLeader ? 4 : 3;
                ctx.stroke();
                ctx.restore();

                let imgDrawn = false;
                if (rawPic) {
                    const cached = this.memberAvatarImageCache.get(rawPic);
                    if (cached && cached.complete && cached.naturalWidth > 0) {
                        ctx.save();
                        ctx.beginPath();
                        ctx.arc(cx, cy, avatarRadius, 0, Math.PI * 2);
                        ctx.clip();
                        ctx.drawImage(cached, cx - avatarRadius, cy - avatarRadius, avatarRadius * 2, avatarRadius * 2);
                        ctx.restore();
                        imgDrawn = true;
                    } else if (!this.memberAvatarImageCache.has(rawPic)) {
                        const img = new Image();
                        img.crossOrigin = 'anonymous';
                        img.onload = () => {
                            this.memberAvatarImageCache.set(rawPic, img);
                            this.updateMembersBoard();
                        };
                        img.onerror = () => {
                            this.memberAvatarImageCache.set(rawPic, false);
                        };
                        const proxyUrl = (rawPic.startsWith('http://') || rawPic.startsWith('https://')) && !rawPic.startsWith(window.location.origin) ? 'api/proxy_avatar.php?url=' + encodeURIComponent(rawPic) : rawPic;
                        img.src = proxyUrl;
                        this.memberAvatarImageCache.set(rawPic, img);
                    }
                }

                if (!imgDrawn) {
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(cx, cy, avatarRadius, 0, Math.PI * 2);
                    const grad = ctx.createLinearGradient(cx - avatarRadius, cy - avatarRadius, cx + avatarRadius, cy + avatarRadius);
                    if (isLeader) {
                        grad.addColorStop(0, '#f59e0b');
                        grad.addColorStop(1, '#b45309');
                    } else {
                        grad.addColorStop(0, '#0284c7');
                        grad.addColorStop(1, '#0f172a');
                    }
                    ctx.fillStyle = grad;
                    ctx.fill();

                    ctx.font = 'bold 30px "Kanit", sans-serif';
                    ctx.fillStyle = '#ffffff';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    const initial = (memberName || 'P').trim().charAt(0).toUpperCase();
                    ctx.fillText(initial, cx, cy);
                    ctx.restore();
                }

                // เธเธทเนเธญเนเธฅเธฐเธฅเธณเธ”เธฑเธ
                ctx.save();
                ctx.font = 'bold 15px "Kanit", sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'top';

                const truncatedName = memberName.length > 9 ? memberName.substring(0, 9) + '…' : memberName;
                ctx.fillStyle = isLeader ? '#fef08a' : '#ffffff';
                ctx.fillText(truncatedName, cx, cy + avatarRadius + 8);

                ctx.font = '500 13px "Kanit", sans-serif';
                if (isLeader) {
                    ctx.fillStyle = '#ffd700';
                    ctx.fillText('👑 หัวหน้าบ้าน', cx, cy + avatarRadius + 29);
                } else {
                    ctx.fillStyle = '#38bdf8';
                    ctx.fillText(`ลำดับที่ #${slot + 1}`, cx, cy + avatarRadius + 29);
                }
                ctx.restore();

            } else {
                // เธเนเธญเธเธงเนเธฒเธเธชเธณเธซเธฃเธฑเธเธฅเธนเธเธเนเธฒเธ
                ctx.save();
                ctx.beginPath();
                ctx.arc(cx, cy, avatarRadius, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(15, 23, 42, 0.45)';
                ctx.fill();

                ctx.setLineDash([6, 6]);
                ctx.strokeStyle = 'rgba(71, 85, 105, 0.65)';
                ctx.lineWidth = 2;
                ctx.stroke();

                ctx.setLineDash([]);
                ctx.font = 'bold 24px "Kanit", sans-serif';
                ctx.fillStyle = '#475569';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(`+`, cx, cy - 6);

                ctx.font = 'bold 13px "Kanit", sans-serif';
                ctx.fillText(`#${slot + 1}`, cx, cy + 16);

                ctx.font = '13px "Kanit", sans-serif';
                ctx.fillStyle = '#64748b';
                ctx.textBaseline = 'top';
                    ctx.fillText('(ว่าง)', cx, cy + avatarRadius + 12);
                ctx.restore();
            }
        }

        this.membersBoardTexture.needsUpdate = true;
    }
}

window.ClanHouse3D = ClanHouse3D;
