/**
 * realistic_avatars.js - Thai & Asian Realistic Portraits Collection & Helper
 * คอลเลกชันรูปโปรไฟล์คนไทยและเอเชียแท้ (ชาย, หญิง, วัยรุ่น, สไตล์เน็ตไอดอล/ดารา)
 * โหลดเร็ว ปลอดภัยด้วย Local Assets ในระบบ ไม่พึ่งพา CDN ภายนอก
 */

(function() {
    'use strict';

    // คอลเลกชันภาพคนไทย เอเชีย คนบ้านๆ รูปต้นไม้ สัตว์เลี้ยง และธรรมชาติ (บันทึกในเครื่อง avatars/bots/)
    const REALISTIC_AVATARS = [
        // ==========================================
        // 1. ต้นไม้ & ธรรมชาติ & ดอกไม้ (Trees, Plants & Nature)
        // ==========================================
        { url: 'avatars/bots/tree_forest.jpg', type: 'nature', gender: 'nature', label: 'ต้นไม้ในป่าเขียว' },
        { url: 'avatars/bots/tree_oak.jpg', type: 'nature', gender: 'nature', label: 'ต้นโอ๊กใหญ่ร่มรื่น' },
        { url: 'avatars/bots/tree_woods.jpg', type: 'nature', gender: 'nature', label: 'ทิวต้นไม้ในสวน' },
        { url: 'avatars/bots/tree_green.jpg', type: 'nature', gender: 'nature', label: 'ต้นไม้ใบเขียวขจี' },
        { url: 'avatars/bots/tree_pine.jpg', type: 'nature', gender: 'nature', label: 'ต้นสนริมเขา' },
        { url: 'avatars/bots/tree_autumn.jpg', type: 'nature', gender: 'nature', label: 'ต้นไม้ผลัดใบ' },
        { url: 'avatars/bots/nature_sunlight.jpg', type: 'nature', gender: 'nature', label: 'แสงแดดยามเช้าในป่า' },
        { url: 'avatars/bots/plant_leaf.jpg', type: 'nature', gender: 'nature', label: 'ใบไม้หยาดน้ำค้าง' },
        { url: 'avatars/bots/nature_mountain.jpg', type: 'nature', gender: 'nature', label: 'วิวทิวเขาธรรมชาติ' },
        { url: 'avatars/bots/nature_sea.jpg', type: 'nature', gender: 'nature', label: 'ทะเลสีคราม' },
        { url: 'avatars/bots/flower_lotus.jpg', type: 'nature', gender: 'nature', label: 'ดอกบัวหลวงริมบึง' },
        { url: 'avatars/bots/flower_wild.jpg', type: 'nature', gender: 'nature', label: 'ดอกไม้ป่าสีสดใส' },
        { url: 'avatars/bots/landscape_lake.jpg', type: 'nature', gender: 'nature', label: 'ทะเลสาบเงียบสงบ' },
        { url: 'avatars/bots/tree_01.jpg', type: 'nature', gender: 'nature', label: 'ต้นไม้ธรรมชาติ' },

        // ==========================================
        // 2. คนบ้านๆ ทั่วไป ไม่เน้นสวยหล่อ (Everyday & Ordinary People)
        // ==========================================
        { url: 'avatars/bots/ordinary_man_uncle.jpg', type: 'man', gender: 'male', label: 'ลุงสมหมาย (คนบ้านๆ)' },
        { url: 'avatars/bots/ordinary_woman_aunt.jpg', type: 'woman', gender: 'female', label: 'ป้าเพ็ญศรี (ใจดี)' },
        { url: 'avatars/bots/ordinary_man_01.jpg', type: 'man', gender: 'male', label: 'น้าต้อย (ชาวบ้าน)' },
        { url: 'avatars/bots/ordinary_man_02.jpg', type: 'man', gender: 'male', label: 'ช่างชาญ (สายลุย)' },
        { url: 'avatars/bots/ordinary_man_03.jpg', type: 'man', gender: 'male', label: 'พี่เชิด (คนทำงาน)' },
        { url: 'avatars/bots/ordinary_man_04.jpg', type: 'man', gender: 'male', label: 'แบงค์ (หนุ่มบ้านๆ)' },
        { url: 'avatars/bots/ordinary_man_05.jpg', type: 'man', gender: 'male', label: 'พี่ยุทธ (คนสวน)' },
        { url: 'avatars/bots/ordinary_man_06.jpg', type: 'man', gender: 'male', label: 'จ่าต๋อย (มาดเข้ม)' },
        { url: 'avatars/bots/ordinary_man_smile.jpg', type: 'man', gender: 'male', label: 'โก้ (หนุ่มอารมณ์ดี)' },
        { url: 'avatars/bots/ordinary_woman_01.jpg', type: 'woman', gender: 'female', label: 'ป้าสมร (แม่บ้าน)' },
        { url: 'avatars/bots/ordinary_woman_02.jpg', type: 'woman', gender: 'female', label: 'น้องก้อย (สาวบ้านๆ)' },
        { url: 'avatars/bots/ordinary_woman_03.jpg', type: 'woman', gender: 'female', label: 'ครูน้อย (ยิ้มหวาน)' },
        { url: 'avatars/bots/ordinary_woman_04.jpg', type: 'woman', gender: 'female', label: 'ยุ้ย (สายชิล)' },
        { url: 'avatars/bots/ordinary_profile_01.jpg', type: 'man', gender: 'male', label: 'ต้อม (คนธรรมดา)' },
        { url: 'avatars/bots/ordinary_profile_02.jpg', type: 'man', gender: 'male', label: 'ป๊อกแป๊ก (เด็กแนว)' },

        // ==========================================
        // 3. สัตว์เลี้ยง & ชีวิตประจำวัน (Pets & Everyday Lifestyle)
        // ==========================================
        { url: 'avatars/bots/cat_orange.jpg', type: 'pet', gender: 'pet', label: 'เจ้าส้มจอมกวน' },
        { url: 'avatars/bots/cat_cute.jpg', type: 'pet', gender: 'pet', label: 'แมวน้อยน่ารัก' },
        { url: 'avatars/bots/dog_friendly.jpg', type: 'pet', gender: 'pet', label: 'ตูบซี้สี่ขา' },
        { url: 'avatars/bots/dog_funny.jpg', type: 'pet', gender: 'pet', label: 'หมาน้อยสายฮา' },
        { url: 'avatars/bots/dog_golden.jpg', type: 'pet', gender: 'pet', label: 'เจ้าตูบโกลเด้น' },
        { url: 'avatars/bots/coffee_cup.jpg', type: 'lifestyle', gender: 'item', label: 'ถ้วยกาแฟยามเช้า' },
        { url: 'avatars/bots/coffee_shop.jpg', type: 'lifestyle', gender: 'item', label: 'มุมร้านกาแฟ' },
        { url: 'avatars/bots/coffee_latte.jpg', type: 'lifestyle', gender: 'item', label: 'ลาเต้อาร์ต' },
        { url: 'avatars/bots/motorcycle.jpg', type: 'lifestyle', gender: 'item', label: 'มอเตอร์ไซค์คู่ใจ' },

        // ==========================================
        // 4. ผู้ชาย & ผู้หญิงไทย-เอเชีย (Thai & Asian Members)
        // ==========================================
        { url: 'avatars/bots/bot_m01.jpg', type: 'man', gender: 'male', label: 'หนุ่มมาดเข้ม' },
        { url: 'avatars/bots/bot_m02.jpg', type: 'man', gender: 'male', label: 'หนุ่มหน้าใส' },
        { url: 'avatars/bots/bot_m03.jpg', type: 'man', gender: 'male', label: 'หนุ่มมาดอบอุ่น' },
        { url: 'avatars/bots/bot_m04.jpg', type: 'man', gender: 'male', label: 'หนุ่มคิ้วเข้ม' },
        { url: 'avatars/bots/bot_m05.png', type: 'man', gender: 'male', label: 'หนุ่มตี๋' },
        { url: 'avatars/bots/bot_m06.png', type: 'man', gender: 'male', label: 'หนุ่มน่ารัก' },
        { url: 'avatars/bots/bot_m07.png', type: 'man', gender: 'male', label: 'หนุ่มยิ้มหวาน' },
        { url: 'avatars/bots/bot_m08.jpg', type: 'man', gender: 'male', label: 'หนุ่มสบายๆ' },
        { url: 'avatars/bots/bot_m09.png', type: 'man', gender: 'male', label: 'หนุ่มสตรีท' },
        { url: 'avatars/bots/bot_m10.jpg', type: 'man', gender: 'male', label: 'หนุ่มสปอร์ต' },
        { url: 'avatars/bots/bot_m11.jpg', type: 'man', gender: 'male', label: 'หนุ่มธรรมดา' },
        { url: 'avatars/bots/bot_m15.jpg', type: 'man', gender: 'male', label: 'หนุ่มทำงาน' },
        { url: 'avatars/bots/bot_m16.jpg', type: 'man', gender: 'male', label: 'หนุ่มมาดกวน' },
        { url: 'avatars/bots/bot_m17.jpg', type: 'man', gender: 'male', label: 'หนุ่มอารมณ์ดี' },
        { url: 'avatars/bots/bot_m18.jpg', type: 'man', gender: 'male', label: 'หนุ่มใจเย็น' },
        { url: 'avatars/bots/bot_m19.jpg', type: 'man', gender: 'male', label: 'หนุ่มยิ้มง่าย' },
        { url: 'avatars/bots/bot_f01.jpg', type: 'girl', gender: 'female', label: 'สาวสดใส' },
        { url: 'avatars/bots/bot_f02.jpg', type: 'woman', gender: 'female', label: 'สาวตาคม' },
        { url: 'avatars/bots/bot_f03.png', type: 'girl', gender: 'female', label: 'สาวน่ารัก' },
        { url: 'avatars/bots/bot_f04.png', type: 'woman', gender: 'female', label: 'สาวเรียบร้อย' },
        { url: 'avatars/bots/bot_f05.jpg', type: 'girl', gender: 'female', label: 'สาวหวาน' },
        { url: 'avatars/bots/bot_f06.jpg', type: 'girl', gender: 'female', label: 'สาวมาดมั่น' },
        { url: 'avatars/bots/bot_f07.jpg', type: 'girl', gender: 'female', label: 'สาวตาโต' },
        { url: 'avatars/bots/bot_f08.jpg', type: 'woman', gender: 'female', label: 'สาวรอยยิ้มหวาน' },
        { url: 'avatars/bots/bot_f09.jpg', type: 'woman', gender: 'female', label: 'สาวเก่ง' },
        { url: 'avatars/bots/bot_f10.jpg', type: 'woman', gender: 'female', label: 'สาวอารมณ์ดี' },
        { url: 'avatars/bots/bot_f12.jpg', type: 'girl', gender: 'female', label: 'สาวชาวบ้าน' },
        { url: 'avatars/bots/bot_f13.jpg', type: 'woman', gender: 'female', label: 'สาวเรียบง่าย' },
        { url: 'avatars/bots/bot_f14.jpg', type: 'girl', gender: 'female', label: 'สาวขี้เล่น' },
        { url: 'avatars/bots/bot_f20.jpg', type: 'girl', gender: 'female', label: 'สาวเสียงใส' }
    ];

    window.REALISTIC_AVATARS = REALISTIC_AVATARS;

    /**
     * ดึงภาพคนไทย/เอเชียจริงตาม Seed ข้อความ (เช่นชื่อผู้เล่น) ให้ได้ภาพไม่ซ้ำกัน
     */
    window.getDeterministicRealisticAvatar = function(seedKey = '', slotIndex = 0) {
        if (!REALISTIC_AVATARS || REALISTIC_AVATARS.length === 0) {
            return 'avatars/bots/bot_f01.jpg';
        }

        const str = String(seedKey || '').trim();
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = (hash << 5) - hash + str.charCodeAt(i);
            hash |= 0;
        }

        const idx = Math.abs(hash + Number(slotIndex || 0)) % REALISTIC_AVATARS.length;
        return REALISTIC_AVATARS[idx].url;
    };

    /**
     * ดึงภาพแบบสุ่มไม่ซ้ำตามจำนวนที่ต้องการ (พร้อมเลือกหมวดหมู่ ชาย/หญิง ได้)
     */
    window.pickRandomRealisticAvatars = function(count = 1, filterType = null, usedUrls = []) {
        const pool = filterType 
            ? REALISTIC_AVATARS.filter(a => a.type === filterType || a.gender === filterType)
            : REALISTIC_AVATARS;

        const used = new Set(usedUrls || []);
        const available = pool.filter(a => !used.has(a.url));
        const listToShuffle = available.length >= count ? available : pool;

        const shuffled = [...listToShuffle].sort(() => Math.random() - 0.5);
        return shuffled.slice(0, count).map(a => a.url);
    };

    // เชื่อมเข้ากับระบบ getOpponentAvatarByName ให้คืนภาพคนไทย/เอเชียจริงเสมอ
    const originalGetAvatar = window.getOpponentAvatarByName;
    window.getOpponentAvatarByName = function(name = '', index = 0) {
        try {
            return window.getDeterministicRealisticAvatar(name, index);
        } catch (e) {
            if (typeof originalGetAvatar === 'function') {
                return originalGetAvatar(name, index);
            }
            return 'avatars/bots/bot_f01.jpg';
        }
    };

})();
