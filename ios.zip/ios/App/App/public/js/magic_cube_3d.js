/**
 * =========================================================================
 * 🧊 Magic Cube 3D Engine (Three.js WebGL True 3D Rubik Speedcube)
 * Based on Tycoon 3D (เกมเศรษฐี) & GAN 3x3 Speedcube Reference
 * =========================================================================
 */
(function() {
    'use strict';

    const cubeInstances = new Map();
    let textureCache = new Map();

    // -------------------------------------------------------------
    // 1. Generate High-Res 3x3 Rubik Face Canvas Texture (512x512)
    // -------------------------------------------------------------
    function createFaceCanvas(faceType, cubeType, isCenterEmblem = false) {
        const cacheKey = `${cubeType}_${faceType}_${isCenterEmblem}`;
        if (textureCache.has(cacheKey)) {
            return textureCache.get(cacheKey);
        }

        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');

        const rawType = String(cubeType || 'SILVER').toUpperCase();

        // Color definitions
        let palette = {};
        let emblem = { type: 'text', text: '👑', bg: '#fffbeb', border: '#f59e0b', color: '#b45309' };
        let seamColor = '#111827';

        if (rawType.includes('GOLD') || rawType === 'GOLD') {
            seamColor = '#1f1304';
            emblem = { type: 'crown', text: '👑', bg: '#fffbeb', border: '#f59e0b', color: '#b45309' };
            palette = {
                top:    ['#fffbeb', '#fef08a', '#eab308'],
                front:  ['#fef08a', '#f59e0b', '#b45309'],
                left:   ['#fde047', '#d97706', '#92400e'],
                right:  ['#fef9c3', '#eab308', '#78350f'],
                back:   ['#fef08a', '#ca8a04', '#713f12'],
                bottom: ['#78350f', '#451a03', '#1c0a00']
            };
        } else if (rawType.includes('DIAMOND') || rawType === 'DIAMOND') {
            seamColor = '#031726';
            emblem = { type: 'diamond', text: '💎', bg: '#ecfeff', border: '#38bdf8', color: '#0284c7' };
            palette = {
                top:    ['#f0fdfa', '#67e8f9', '#06b6d4'],
                front:  ['#a5f3fc', '#0284c7', '#0c4a6e'],
                left:   ['#bae6fd', '#0369a1', '#075985'],
                right:  ['#cffafe', '#0891b2', '#155e75'],
                back:   ['#7dd3fc', '#0284c7', '#082f49'],
                bottom: ['#082f49', '#021e33', '#010f1a']
            };
        } else if (rawType.includes('LEGEND') || rawType === 'LEGENDARY') {
            seamColor = '#20052e';
            emblem = { type: 'star', text: '🌌', bg: '#fdf4ff', border: '#d946ef', color: '#701a75' };
            palette = {
                top:    ['#fdf4ff', '#f472b6', '#d946ef'],
                front:  ['#f5d0fe', '#c026d3', '#701a75'],
                left:   ['#e879f9', '#9333ea', '#581c87'],
                right:  ['#fae8ff', '#a855f7', '#4a044e'],
                back:   ['#d8b4fe', '#7e22ce', '#3b0764'],
                bottom: ['#3b0764', '#1e0533', '#120220']
            };
        } else if (rawType.includes('ANCIENT')) {
            seamColor = '#011c15';
            emblem = { type: 'orb', text: '🔮', bg: '#ecfdf5', border: '#10b981', color: '#065f46' };
            palette = {
                top:    ['#ecfdf5', '#34d399', '#059669'],
                front:  ['#6ee7b7', '#059669', '#064e3b'],
                left:   ['#a7f3d0', '#047857', '#022c22'],
                right:  ['#6ee7b7', '#10b981', '#047857'],
                back:   ['#34d399', '#065f46', '#064e3b'],
                bottom: ['#064e3b', '#022c22', '#011712']
            };
        } else {
            // Classic GAN 3x3 Rubik Speedcube
            seamColor = '#0a0a0a';
            emblem = { type: 'gan', text: 'GAN', bg: '#ffffff', border: '#cbd5e1', color: '#0284c7' };
            palette = {
                top:    ['#93c5fd', '#2563eb', '#1d4ed8'], // Blue top
                front:  ['#ffffff', '#f8fafc', '#e2e8f0'], // White front (with GAN logo)
                left:   ['#fdba74', '#f97316', '#c2410c'], // Orange left
                right:  ['#86efac', '#16a34a', '#14532d'], // Green right
                back:   ['#fef08a', '#eab308', '#a16207'], // Yellow back
                bottom: ['#fca5a5', '#dc2626', '#991b1b']  // Red bottom
            };
        }

        const faceColors = palette[faceType] || palette.front;

        // Fill background with seam grooves
        ctx.fillStyle = seamColor;
        ctx.fillRect(0, 0, 512, 512);

        // 3x3 Tile Grid
        const pad = 18;
        const gap = 16;
        const tileSize = (512 - (pad * 2) - (gap * 2)) / 3;
        const cornerR = 24;

        for (let row = 0; row < 3; row++) {
            for (let col = 0; col < 3; col++) {
                const x = pad + col * (tileSize + gap);
                const y = pad + row * (tileSize + gap);

                // Draw rounded tile
                drawRoundedRect(ctx, x, y, tileSize, tileSize, cornerR);

                // Main gradient fill
                const grad = ctx.createLinearGradient(x, y, x + tileSize, y + tileSize);
                grad.addColorStop(0, faceColors[0]);
                grad.addColorStop(0.5, faceColors[1]);
                grad.addColorStop(1, faceColors[2]);
                ctx.fillStyle = grad;
                ctx.fill();

                // Inner specular highlight bevel (top-left)
                ctx.save();
                ctx.clip();
                const bevelGrad = ctx.createLinearGradient(x, y, x + tileSize, y + tileSize);
                bevelGrad.addColorStop(0, 'rgba(255, 255, 255, 0.65)');
                bevelGrad.addColorStop(0.25, 'rgba(255, 255, 255, 0.15)');
                bevelGrad.addColorStop(0.7, 'rgba(0, 0, 0, 0)');
                bevelGrad.addColorStop(1, 'rgba(0, 0, 0, 0.45)');
                ctx.fillStyle = bevelGrad;
                ctx.fillRect(x, y, tileSize, tileSize);
                ctx.restore();

                // Tile border
                ctx.lineWidth = 3;
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
                ctx.stroke();

                // Center emblem on front face (col === 1 && row === 1)
                if (isCenterEmblem && col === 1 && row === 1) {
                    const cx = x + tileSize / 2;
                    const cy = y + tileSize / 2;
                    const r = tileSize * 0.36;

                    // Badge circle background
                    ctx.save();
                    ctx.beginPath();
                    ctx.arc(cx, cy, r, 0, Math.PI * 2);
                    ctx.fillStyle = emblem.bg;
                    ctx.fill();
                    ctx.lineWidth = 4;
                    ctx.strokeStyle = emblem.border;
                    ctx.stroke();

                    // Subtle shadow under badge
                    ctx.shadowColor = 'rgba(0,0,0,0.5)';
                    ctx.shadowBlur = 8;

                    if (emblem.type === 'gan') {
                        // Official GAN Speedcube Logo
                        ctx.fillStyle = emblem.color;
                        ctx.font = '900 36px "Segoe UI", sans-serif';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText('GAN', cx, cy - 2);

                        ctx.font = '800 13px "Segoe UI", sans-serif';
                        ctx.fillText('CUBE', cx, cy + 24);
                    } else {
                        // Crown, Diamond, or Star Emoji / Icon
                        ctx.font = '54px "Apple Color Emoji", "Segoe UI Emoji", sans-serif';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText(emblem.text, cx, cy + 2);
                    }
                    ctx.restore();
                }
            }
        }

        const texture = new THREE.CanvasTexture(canvas);
        texture.anisotropy = 4;
        textureCache.set(cacheKey, texture);
        return texture;
    }

    function drawRoundedRect(ctx, x, y, width, height, radius) {
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    }

    // -------------------------------------------------------------
    // 2. Generate Sunburst Aura Flare Plane Texture (512x512)
    // Supports Aura Types: neon_pulse, flame, cosmic, shockwave, golden_ring
    // -------------------------------------------------------------
    function createAuraFlareTexture(auraColor = '#ffd700', auraType = 'neon_pulse') {
        const cacheKey = `aura_${auraColor}_${auraType}`;
        if (textureCache.has(cacheKey)) return textureCache.get(cacheKey);

        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');
        const cx = 256;
        const cy = 256;

        if (auraType === 'flame') {
            // Flame Aura: Rising fiery tongue bursts with warm layers
            const radGrad = ctx.createRadialGradient(cx, cy, 30, cx, cy, 240);
            radGrad.addColorStop(0, '#fffbeb');
            radGrad.addColorStop(0.25, '#f59e0b');
            radGrad.addColorStop(0.6, '#ef444499');
            radGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = radGrad;
            ctx.fillRect(0, 0, 512, 512);

            ctx.save();
            ctx.translate(cx, cy);
            for (let i = 0; i < 20; i++) {
                ctx.rotate((Math.PI * 2) / 20);
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.quadraticCurveTo(-14, 140, 0, 245);
                ctx.quadraticCurveTo(14, 140, 0, 0);
                const fGrad = ctx.createLinearGradient(0, 0, 0, 245);
                fGrad.addColorStop(0, '#fef08a');
                fGrad.addColorStop(0.5, '#f97316cc');
                fGrad.addColorStop(1, 'transparent');
                ctx.fillStyle = fGrad;
                ctx.fill();
            }
            ctx.restore();
        } else if (auraType === 'cosmic') {
            // Cosmic Radiance: Deep space spiral nebula with runic stars
            const radGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, 250);
            radGrad.addColorStop(0, '#fdf4ff');
            radGrad.addColorStop(0.3, '#d946efaa');
            radGrad.addColorStop(0.65, '#3b82f644');
            radGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = radGrad;
            ctx.fillRect(0, 0, 512, 512);

            ctx.save();
            ctx.translate(cx, cy);
            for (let r = 60; r <= 220; r += 40) {
                ctx.lineWidth = 2.5;
                ctx.strokeStyle = '#c084fc88';
                ctx.setLineDash([12, 8, 4, 8]);
                ctx.beginPath();
                ctx.arc(0, 0, r, 0, Math.PI * 2);
                ctx.stroke();
            }
            ctx.restore();
        } else if (auraType === 'shockwave') {
            // Shockwave: High contrast ripple rings
            const radGrad = ctx.createRadialGradient(cx, cy, 10, cx, cy, 240);
            radGrad.addColorStop(0, auraColor);
            radGrad.addColorStop(0.2, auraColor + 'bb');
            radGrad.addColorStop(0.5, auraColor + '44');
            radGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = radGrad;
            ctx.fillRect(0, 0, 512, 512);

            ctx.save();
            ctx.translate(cx, cy);
            [80, 130, 180, 230].forEach((r, idx) => {
                ctx.lineWidth = 4 - idx * 0.6;
                ctx.strokeStyle = auraColor + 'cc';
                ctx.beginPath();
                ctx.arc(0, 0, r, 0, Math.PI * 2);
                ctx.stroke();
            });
            ctx.restore();
        } else if (auraType === 'golden_ring') {
            // Golden Ring: Sacred halo with solar sunburst teeth
            const radGrad = ctx.createRadialGradient(cx, cy, 30, cx, cy, 250);
            radGrad.addColorStop(0, '#fef9c3');
            radGrad.addColorStop(0.3, '#facc15aa');
            radGrad.addColorStop(0.7, '#ca8a0433');
            radGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = radGrad;
            ctx.fillRect(0, 0, 512, 512);

            ctx.save();
            ctx.translate(cx, cy);
            ctx.lineWidth = 5;
            ctx.strokeStyle = '#ffd700ee';
            ctx.beginPath();
            ctx.arc(0, 0, 180, 0, Math.PI * 2);
            ctx.stroke();

            for (let i = 0; i < 24; i++) {
                ctx.rotate((Math.PI * 2) / 24);
                ctx.beginPath();
                ctx.moveTo(0, 180);
                ctx.lineTo(-6, 235);
                ctx.lineTo(6, 235);
                ctx.closePath();
                ctx.fillStyle = '#ffd700cc';
                ctx.fill();
            }
            ctx.restore();
        } else {
            // Default: Neon Pulse (เหมือนรูปที่ 1: วงแหวนเทค & รัศมีแสง 8 ทิศ + จุดประกาย)
            const radGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, 250);
            radGrad.addColorStop(0, auraColor);
            radGrad.addColorStop(0.35, auraColor + '99');
            radGrad.addColorStop(0.7, auraColor + '22');
            radGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = radGrad;
            ctx.fillRect(0, 0, 512, 512);

            ctx.save();
            ctx.translate(cx, cy);

            // 8 Radiant Crosshair / Diagonal Rays
            ctx.strokeStyle = auraColor + 'dd';
            ctx.lineWidth = 5;
            ctx.lineCap = 'round';
            for (let i = 0; i < 4; i++) {
                ctx.beginPath();
                ctx.moveTo(-235, 0);
                ctx.lineTo(235, 0);
                ctx.stroke();
                ctx.rotate(Math.PI / 4);
            }

            // Inner dashed ring (r=160)
            ctx.lineWidth = 4;
            ctx.strokeStyle = auraColor + 'ee';
            ctx.setLineDash([20, 14]);
            ctx.beginPath();
            ctx.arc(0, 0, 160, 0, Math.PI * 2);
            ctx.stroke();

            // Outer dashed ring (r=210)
            ctx.lineWidth = 2.8;
            ctx.strokeStyle = auraColor + 'aa';
            ctx.setLineDash([8, 12]);
            ctx.beginPath();
            ctx.arc(0, 0, 210, 0, Math.PI * 2);
            ctx.stroke();

            ctx.restore();
        }

        const texture = new THREE.CanvasTexture(canvas);
        textureCache.set(cacheKey, texture);
        return texture;
    }

    function cleanupDetachedOrHiddenCubes() {
        for (const [canvas, inst] of cubeInstances.entries()) {
            if (!document.body.contains(canvas) || canvas.offsetParent === null) {
                inst.destroy();
            }
        }
    }

    // -------------------------------------------------------------
    // 3. Mount / Update True 3D Magic Cube in Canvas
    // -------------------------------------------------------------
    window.mountMagicCube3D = function(canvasEl, options = {}) {
        if (!canvasEl || !window.THREE) return null;

        cleanupDetachedOrHiddenCubes();

        // ห้ามสร้าง WebGLRenderer เด็ดขาดหาก Modal ลูกบาศก์ซ่อนอยู่ (ป้องกันแย่ง WebGL Context จนกระดานหลักจอดำ)
        if (!document.body.contains(canvasEl) || canvasEl.offsetParent === null) {
            return null;
        }

        const cubeType = String(options.cubeType || 'SILVER').toUpperCase();
        const isSpinning = Boolean(options.isSpinning);
        const hasAura = Boolean(options.hasAura);
        const auraType = String(options.auraType || 'neon_pulse');
        const particleFx = String(options.particleFx || 'flare_burst');
        const intensity = String(options.intensity || '2x');
        const width = options.width || canvasEl.clientWidth || 100;
        const height = options.height || canvasEl.clientHeight || 100;

        // Existing instance reuse
        if (cubeInstances.has(canvasEl)) {
            const inst = cubeInstances.get(canvasEl);
            inst.update(options);
            return inst;
        }

        // จำกัดจำนวน WebGLRenderer ของลูกบาศก์ไม่ให้เกิน 5 ช่อง (4 ช่องหลัก + 1 preview canvas)
        if (cubeInstances.size >= 6) {
            return null;
        }

        // Set up Scene, Camera, Renderer
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 100);
        camera.position.set(0, 0, 4.6);

        let renderer;
        try {
            renderer = new THREE.WebGLRenderer({
                canvas: canvasEl,
                alpha: true,
                antialias: false,
                powerPreference: 'default'
            });
            renderer.setSize(width, height, false);
            renderer.setPixelRatio(1);
        } catch (e) {
            console.warn('WebGL not supported for Magic Cube 3D:', e);
            return null;
        }

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.95);
        scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 1.35);
        dirLight.position.set(2.5, 4.5, 3.5);
        scene.add(dirLight);

        let auraColorHex = '#ffd700';
        if (cubeType.includes('DIAMOND')) auraColorHex = '#00e5ff';
        else if (cubeType.includes('LEGEND')) auraColorHex = '#ec4899';
        else if (cubeType.includes('ANCIENT')) auraColorHex = '#10b981';

        const intScale = intensity === '3x' ? 1.6 : (intensity === '1x' ? 0.75 : 1.15);
        const pointLight = new THREE.PointLight(new THREE.Color(auraColorHex), (hasAura ? 2.5 : 1.2) * intScale, 8);
        pointLight.position.set(0, 0, 2.2);
        scene.add(pointLight);

        // Root Pivot Group
        const rootGroup = new THREE.Group();
        scene.add(rootGroup);

        // Aura Plane (Behind Cube)
        const auraGeo = new THREE.PlaneGeometry(3.6 * intScale, 3.6 * intScale);
        const auraMat = new THREE.MeshBasicMaterial({
            map: createAuraFlareTexture(auraColorHex, auraType),
            transparent: true,
            opacity: hasAura ? (0.95 * Math.min(1.2, intScale)) : (isSpinning ? 0.65 : 0),
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });
        const auraMesh = new THREE.Mesh(auraGeo, auraMat);
        auraMesh.position.set(0, 0, -0.6);
        rootGroup.add(auraMesh);

        // 3D Particles Group (Orbit rings, Sparkles, Shards, Energy Pillar)
        const particleGroup = new THREE.Group();
        rootGroup.add(particleGroup);

        function rebuildParticles(pFx, colHex) {
            while (particleGroup.children.length > 0) {
                const c = particleGroup.children[0];
                particleGroup.remove(c);
                if (c.geometry) c.geometry.dispose();
                if (c.material) c.material.dispose();
            }
            if (pFx === 'orbit_rings') {
                const ringGeo1 = new THREE.RingGeometry(1.5, 1.62, 32);
                const ringMat1 = new THREE.MeshBasicMaterial({ color: new THREE.Color(colHex), side: THREE.DoubleSide, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending });
                const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
                ring1.rotation.x = 1.1;
                particleGroup.add(ring1);

                const ringGeo2 = new THREE.RingGeometry(1.75, 1.84, 32);
                const ringMat2 = new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffffff'), side: THREE.DoubleSide, transparent: true, opacity: 0.65, blending: THREE.AdditiveBlending });
                const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
                ring2.rotation.y = 1.2;
                ring2.rotation.x = -0.6;
                particleGroup.add(ring2);
            } else if (pFx === 'sparkles') {
                const starCount = 36;
                const starGeo = new THREE.BufferGeometry();
                const pos = new Float32Array(starCount * 3);
                for (let i = 0; i < starCount; i++) {
                    const u = Math.random();
                    const v = Math.random();
                    const theta = u * 2.0 * Math.PI;
                    const phi = Math.acos(2.0 * v - 1.0);
                    const r = 1.35 + Math.random() * 0.9;
                    pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
                    pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
                    pos[i * 3 + 2] = r * Math.cos(phi);
                }
                starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
                const starMat = new THREE.PointsMaterial({ color: new THREE.Color(colHex), size: 0.14, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending });
                const pSystem = new THREE.Points(starGeo, starMat);
                particleGroup.add(pSystem);
            } else if (pFx === 'shards') {
                for (let i = 0; i < 10; i++) {
                    const sGeo = new THREE.OctahedronGeometry(0.12, 0);
                    const sMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(colHex), metalness: 0.8, roughness: 0.2, transparent: true, opacity: 0.85 });
                    const sMesh = new THREE.Mesh(sGeo, sMat);
                    const angle = (i / 10) * Math.PI * 2;
                    sMesh.position.set(Math.cos(angle) * 1.55, (Math.random() - 0.5) * 1.2, Math.sin(angle) * 1.55);
                    particleGroup.add(sMesh);
                }
            } else if (pFx === 'energy_pillar') {
                const cylGeo = new THREE.CylinderGeometry(0.65, 0.65, 3.8, 16, 1, true);
                const cylMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(colHex), transparent: true, opacity: 0.35, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
                const cyl = new THREE.Mesh(cylGeo, cylMat);
                particleGroup.add(cyl);
            } else if (pFx === 'flare_burst') {
                const fGeo = new THREE.PlaneGeometry(3.0, 3.0);
                const fMat = new THREE.MeshBasicMaterial({ map: createAuraFlareTexture('#ffffff', 'neon_pulse'), transparent: true, opacity: 0.65, blending: THREE.AdditiveBlending });
                const fMesh = new THREE.Mesh(fGeo, fMat);
                fMesh.position.z = -0.4;
                particleGroup.add(fMesh);
            }
        }
        rebuildParticles(particleFx, auraColorHex);

        // 3D Shadow Ellipse on Floor
        const shadowCanvas = document.createElement('canvas');
        shadowCanvas.width = 128; shadowCanvas.height = 128;
        const sCtx = shadowCanvas.getContext('2d');
        const sGrad = sCtx.createRadialGradient(64, 64, 0, 64, 64, 60);
        sGrad.addColorStop(0, hasAura ? auraColorHex + '99' : 'rgba(0,0,0,0.65)');
        sGrad.addColorStop(0.5, hasAura ? auraColorHex + '33' : 'rgba(0,0,0,0.25)');
        sGrad.addColorStop(1, 'transparent');
        sCtx.fillStyle = sGrad;
        sCtx.fillRect(0, 0, 128, 128);
        const shadowTex = new THREE.CanvasTexture(shadowCanvas);
        const shadowMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(2.1, 0.7),
            new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, opacity: 0.85, depthWrite: false })
        );
        shadowMesh.position.set(0, -1.2, 0);
        rootGroup.add(shadowMesh);

        // Rubik 3x3 Cube Mesh
        // Materials for [right, left, top, bottom, front, back]
        function buildMaterials(cType) {
            const metal = cType.includes('GOLD') ? 0.75 : (cType.includes('DIAMOND') ? 0.25 : 0.45);
            const rough = cType.includes('GOLD') ? 0.25 : (cType.includes('DIAMOND') ? 0.15 : 0.35);

            return [
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('right', cType, false), metalness: metal, roughness: rough }),
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('left', cType, false), metalness: metal, roughness: rough }),
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('top', cType, false), metalness: metal, roughness: rough }),
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('bottom', cType, false), metalness: metal, roughness: rough }),
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('front', cType, true), metalness: metal, roughness: rough }),
                new THREE.MeshStandardMaterial({ map: createFaceCanvas('back', cType, false), metalness: metal, roughness: rough })
            ];
        }

        const cubeSize = 1.62;
        const cubeGeo = new THREE.BoxGeometry(cubeSize, cubeSize, cubeSize);
        let cubeMaterials = buildMaterials(cubeType);
        const cubeMesh = new THREE.Mesh(cubeGeo, cubeMaterials);
        rootGroup.add(cubeMesh);

        // State & Controls
        let state = {
            cubeType,
            isSpinning,
            hasAura,
            auraType,
            particleFx,
            intensity,
            animTime: 0,
            active: true
        };

        // Animation Loop
        let animFrameId = null;
        function animate() {
            if (!state.active) return;
            animFrameId = requestAnimationFrame(animate);

            state.animTime += 0.016;
            const t = state.animTime;

            // Rotate particle group
            if (particleGroup && particleGroup.children.length > 0) {
                const pSpeedY = (state.isSpinning && state.hasAura) ? 0.048 : 0.024;
                const pSpeedX = (state.isSpinning && state.hasAura) ? 0.020 : 0.010;
                particleGroup.rotation.y += pSpeedY;
                particleGroup.rotation.x += pSpeedX;
            }

            if (state.isSpinning) {
                // 🌀 Continuous 360-degree spin around Y with isometric down-tilt (เหมือนคลิปเกมเศรษฐี 100%)
                // สำหรับรายการที่สุ่มจากเพชร หรือสุ่มได้เวลาเต็ม MAX (hasAura): หมุนลูกบาศก์และเอฟเฟกต์เร็วกว่าเดิม (~1.75x)
                const spinSpeed = state.hasAura ? 0.068 : 0.038;
                cubeMesh.rotation.y += spinSpeed;
                cubeMesh.rotation.x = -0.42; // ~24 deg down tilt
                cubeMesh.rotation.z = 0;
                cubeMesh.position.y = Math.sin(t * (state.hasAura ? 4.8 : 3.5)) * 0.08;

                // Aura rotation
                auraMesh.rotation.z += (state.hasAura ? 0.038 : 0.018);
                auraMesh.scale.setScalar(1.0 + Math.sin(t * (state.hasAura ? 5.2 : 4.0)) * 0.08);
            } else {
                // ✦ Idle Isometric View (Showing Top, Left, and Front faces like GAN photo)
                cubeMesh.rotation.x = -0.40;
                cubeMesh.rotation.y = 0.68 + Math.sin(t * 1.6) * 0.12; // Gentle breathing sway
                cubeMesh.rotation.z = 0;
                cubeMesh.position.y = Math.sin(t * 2.2) * 0.05;

                auraMesh.rotation.z += 0.006;
                auraMesh.scale.setScalar(0.95);
            }

            // Shadow pulsing
            const shadowScale = 1.0 - cubeMesh.position.y * 0.3;
            shadowMesh.scale.set(shadowScale, shadowScale, shadowScale);

            renderer.render(scene, camera);
        }

        animate();

        const instance = {
            update(newOpts) {
                let colorChanged = false;
                if (newOpts.cubeType && newOpts.cubeType !== state.cubeType) {
                    state.cubeType = newOpts.cubeType.toUpperCase();
                    cubeMesh.material = buildMaterials(state.cubeType);
                    colorChanged = true;
                }

                if (newOpts.auraType !== undefined && newOpts.auraType !== state.auraType) {
                    state.auraType = String(newOpts.auraType);
                    colorChanged = true;
                }

                if (newOpts.particleFx !== undefined && newOpts.particleFx !== state.particleFx) {
                    state.particleFx = String(newOpts.particleFx);
                    rebuildParticles(state.particleFx, auraColorHex);
                }

                if (newOpts.intensity !== undefined && newOpts.intensity !== state.intensity) {
                    state.intensity = String(newOpts.intensity);
                    const newScale = state.intensity === '3x' ? 1.6 : (state.intensity === '1x' ? 0.75 : 1.15);
                    auraMesh.scale.set(newScale, newScale, newScale);
                    pointLight.intensity = (state.hasAura ? 2.5 : 1.2) * newScale;
                }

                if (colorChanged) {
                    let newColor = '#ffd700';
                    if (state.cubeType.includes('DIAMOND')) newColor = '#00e5ff';
                    else if (state.cubeType.includes('LEGEND')) newColor = '#ec4899';
                    else if (state.cubeType.includes('ANCIENT')) newColor = '#10b981';

                    auraColorHex = newColor;
                    pointLight.color.set(newColor);
                    auraMat.map = createAuraFlareTexture(newColor, state.auraType);
                    auraMat.needsUpdate = true;
                    rebuildParticles(state.particleFx, newColor);
                }

                if (newOpts.isSpinning !== undefined) state.isSpinning = Boolean(newOpts.isSpinning);
                if (newOpts.hasAura !== undefined) {
                    state.hasAura = Boolean(newOpts.hasAura);
                    auraMat.opacity = state.hasAura ? 0.95 : (state.isSpinning ? 0.65 : 0);
                    pointLight.intensity = state.hasAura ? 2.5 : 1.2;
                }

                if (newOpts.width && newOpts.height) {
                    renderer.setSize(newOpts.width, newOpts.height, false);
                    camera.aspect = newOpts.width / newOpts.height;
                    camera.updateProjectionMatrix();
                }
            },
            destroy() {
                state.active = false;
                if (animFrameId) cancelAnimationFrame(animFrameId);
                cubeInstances.delete(canvasEl);
                try {
                    renderer.dispose();
                    cubeGeo.dispose();
                    auraGeo.dispose();
                } catch (e) {}
            }
        };

        cubeInstances.set(canvasEl, instance);
        return instance;
    };

    // -------------------------------------------------------------
    // 4. Batch Initialize / Update All 3D Magic Cube Canvases on Page
    // -------------------------------------------------------------
    window.initOrUpdateMagicCube3DCanvases = function() {
        if (!window.THREE) return;
        cleanupDetachedOrHiddenCubes();

        const modalEl = document.getElementById('modal-magic-cube');
        if (modalEl && (modalEl.style.display === 'none' || modalEl.offsetParent === null)) {
            return;
        }

        const canvases = document.querySelectorAll('.magic-cube-3d-canvas');
        canvases.forEach(canvas => {
            if (canvas.offsetParent === null) return;
            const cubeType = canvas.getAttribute('data-type') || 'SILVER';
            const isSpinning = canvas.getAttribute('data-spinning') === 'true';
            const hasAura = canvas.getAttribute('data-aura') === 'true';
            const auraType = canvas.getAttribute('data-aura-type') || 'neon_pulse';
            const particleFx = canvas.getAttribute('data-particle-fx') || 'flare_burst';
            const intensity = canvas.getAttribute('data-intensity') || '2x';
            const size = parseInt(canvas.getAttribute('data-size') || '92', 10);

            window.mountMagicCube3D(canvas, {
                cubeType,
                isSpinning,
                hasAura,
                auraType,
                particleFx,
                intensity,
                width: size,
                height: size
            });
        });
    };

    // -------------------------------------------------------------
    // 5. Clean up disconnected or hidden canvases
    // -------------------------------------------------------------
    setInterval(cleanupDetachedOrHiddenCubes, 2000);

})();

