/**
 * js/ota_client.js
 * Snake & Ladder 3D - Realtime OTA (Over-The-Air) Mobile & Web Update Client
 *
 * คุณสมบัติ:
 * 1. ตรวจจับเวอร์ชันใหม่จากเซิร์ฟเวอร์แบบ Real-time โดยซิงก์กับ index.php / URL ?v= อัตโนมัติ (ไม่รีเฟรชวนลูป)
 * 2. แสดง Popup แจ้งเตือนการอัปเดตบนหน้าจอมือถือ/เว็บ พร้อมแสดงขนาดไฟล์
 * 3. เมื่อกดอัปเดต แสดง Progress Bar และตัวเลข % ความคืบหน้า (0% - 100%)
 * 4. ดาวน์โหลดไฟล์ใหม่และล้างแคชเดิม จากนั้นรีโหลดเข้าเกมใหม่อัตโนมัติเพียงครั้งเดียว
 */

(function() {
    'use strict';

    // Global forward reference for instant reliable button binding
    window._otaStartUpdate = function() {
        if (typeof window.SnakeOTA?.startUpdateProcess === 'function') {
            window.SnakeOTA.startUpdateProcess();
        } else if (typeof startUpdateProcess === 'function') {
            startUpdateProcess();
        }
    };

    const OTA_CONFIG = {
        checkIntervalMs: 15000,
        apiEndpoint: 'api/app_config.php',
        storageKey: 'snake_client_cache_version',
        installedKey: 'snake_client_installed_version',
        sessionGuardKey: 'snake_ota_applied_ver'
    };

    let isUpdating = false;
    let updateModalVisible = false;
    let pendingUpdateData = null;
    let isUpdateTriggered = false;

    function getApiEndpoint() {
        try {
            if (typeof window !== 'undefined' && window.location) {
                const proto = window.location.protocol;
                const host = window.location.hostname;
                const port = window.location.port;
                if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
                    return 'https://pmix01.thddns.net:7175/home/snake/api/app_config.php';
                }
                const path = window.location.pathname;
                const dir = path.substring(0, path.lastIndexOf('/') + 1);
                return (window.location.origin || '') + dir + 'api/app_config.php';
            }
        } catch (e) {}
        return 'https://pmix01.thddns.net:7175/home/snake/api/app_config.php';
    }

    // อ่านเวอร์ชันสูงสุดจาก index.php / index.html หรือพารามิเตอร์ ?v= บน URL
    function getEmbeddedVersion() {
        let best = 0;
        if (typeof window.__GAME_OTA_VERSION__ !== 'undefined' && window.__GAME_OTA_VERSION__) {
            best = Math.max(best, Number(String(window.__GAME_OTA_VERSION__).trim()) || 0);
        }
        const meta = document.querySelector('meta[name="game-ota-version"]');
        if (meta && meta.content) {
            best = Math.max(best, Number(String(meta.content).trim()) || 0);
        }
        try {
            const urlVer = new URLSearchParams(window.location.search).get('v');
            if (urlVer) {
                best = Math.max(best, Number(String(urlVer).trim()) || 0);
            }
        } catch (e) {}
        return best > 0 ? String(best) : null;
    }

    // อ่านเวอร์ชันที่เครื่องผู้เล่นติดตั้ง/ยอมรับการอัปเดตแล้วจริง (ไม่เขียนทับอัตโนมัติก่อนกดอัปเดต)
    function getLocalVersion() {
        let stored = null;
        try {
            stored = localStorage.getItem(OTA_CONFIG.installedKey) || localStorage.getItem(OTA_CONFIG.storageKey);
        } catch (e) {}

        if (stored && Number(stored) > 0) {
            return String(stored).trim();
        }
        return '0';
    }

    function isAppliedInCurrentSession(serverVer) {
        try {
            const applied = sessionStorage.getItem(OTA_CONFIG.sessionGuardKey);
            return applied && String(applied).trim() === String(serverVer).trim();
        } catch (e) {
            return false;
        }
    }

    // บันทึกเวอร์ชันใหม่เมื่อกดและดาวน์โหลดอัปเดตสำเร็จ
    function setLocalVersion(ver) {
        const clean = String(ver).trim();
        try {
            localStorage.setItem(OTA_CONFIG.storageKey, clean);
            localStorage.setItem(OTA_CONFIG.installedKey, clean);
        } catch (e) {}
        try {
            sessionStorage.setItem(OTA_CONFIG.sessionGuardKey, clean);
        } catch (e) {}
        if (typeof window !== 'undefined') {
            window.__GAME_OTA_VERSION__ = clean;
        }
    }

    function injectOtaStyles() {
        if (document.getElementById('ota-custom-styles')) return;

        const css = `
            @keyframes otaRocketFloat {
                0%, 100% { transform: translateY(0) rotate(0deg); }
                50% { transform: translateY(-8px) rotate(-3deg); }
            }
            .ota-modal-overlay {
                position: fixed !important;
                inset: 0 !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                width: 100vw !important;
                width: 100dvw !important;
                height: 100vh !important;
                height: 100dvh !important;
                background: rgba(3, 7, 18, 0.92) !important;
                backdrop-filter: blur(14px) !important;
                -webkit-backdrop-filter: blur(14px) !important;
                z-index: 2147483647 !important;
                display: none !important;
                align-items: center;
                justify-content: center;
                padding: 10px 14px;
                box-sizing: border-box;
                font-family: 'Kanit', sans-serif;
                opacity: 0 !important;
                pointer-events: none !important;
                visibility: hidden !important;
                touch-action: auto !important;
                transition: opacity 0.25s ease;
            }
            .ota-modal-overlay.ota-visible {
                display: flex !important;
                opacity: 1 !important;
                pointer-events: auto !important;
                visibility: visible !important;
            }
            .ota-modal-card {
                width: 96%;
                max-width: 520px;
                background: radial-gradient(circle at top left, #0f172a 0%, #030712 100%);
                border: 1.5px solid #00e5ff;
                border-radius: 16px;
                padding: 14px 18px;
                text-align: left;
                color: #fff;
                box-shadow: 0 10px 40px rgba(0,0,0,0.85), 0 0 25px rgba(0,229,255,0.3);
                position: relative !important;
                transform: scale(0.95);
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
                box-sizing: border-box;
                max-height: 94vh;
                overflow-y: auto;
                pointer-events: auto !important;
                z-index: 2147483647 !important;
            }
            .ota-modal-overlay.ota-visible .ota-modal-card {
                transform: scale(1);
            }
            .ota-landscape-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 10px;
                margin-bottom: 10px;
                border-bottom: 1px solid rgba(255,255,255,0.08);
                padding-bottom: 8px;
            }
            .ota-dice-emblem-wrap {
                position: relative;
                width: 44px;
                height: 44px;
                perspective: 240px;
                -webkit-perspective: 240px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                animation: otaDiceWiggle 2.5s infinite ease-in-out;
                -webkit-animation: otaDiceWiggle 2.5s infinite ease-in-out;
            }
            .ota-dice-aura {
                position: absolute;
                width: 36px;
                height: 36px;
                border-radius: 50%;
                background: radial-gradient(circle, rgba(0, 229, 255, 0.5) 0%, rgba(234, 179, 8, 0.35) 55%, transparent 75%);
                filter: blur(6px);
                -webkit-filter: blur(6px);
                animation: otaAuraPulse 2.5s infinite ease-in-out;
                -webkit-animation: otaAuraPulse 2.5s infinite ease-in-out;
                pointer-events: none;
            }
            @keyframes otaAuraPulse {
                0%, 100% { transform: scale(0.88); opacity: 0.55; }
                50% { transform: scale(1.3); opacity: 0.95; }
            }
            @-webkit-keyframes otaAuraPulse {
                0%, 100% { -webkit-transform: scale(0.88); opacity: 0.55; }
                50% { -webkit-transform: scale(1.3); opacity: 0.95; }
            }
            .ota-dice-cube {
                width: 28px;
                height: 28px;
                position: relative;
                transform-style: preserve-3d;
                -webkit-transform-style: preserve-3d;
                animation: otaCubeSpin 3.8s infinite linear;
                -webkit-animation: otaCubeSpin 3.8s infinite linear;
            }
            @keyframes otaCubeSpin {
                0% { transform: rotateX(15deg) rotateY(0deg) rotateZ(10deg); }
                50% { transform: rotateX(195deg) rotateY(180deg) rotateZ(190deg); }
                100% { transform: rotateX(375deg) rotateY(360deg) rotateZ(370deg); }
            }
            @-webkit-keyframes otaCubeSpin {
                0% { -webkit-transform: rotateX(15deg) rotateY(0deg) rotateZ(10deg); }
                50% { -webkit-transform: rotateX(195deg) rotateY(180deg) rotateZ(190deg); }
                100% { -webkit-transform: rotateX(375deg) rotateY(360deg) rotateZ(370deg); }
            }
            @keyframes otaDiceWiggle {
                0%, 100% { transform: translateY(0) scale(1) rotate(0deg); }
                20% { transform: translateY(-6px) scale(1.1) rotate(-8deg); }
                40% { transform: translateY(-1px) scale(0.95) rotate(5deg); }
                60% { transform: translateY(-7px) scale(1.08) rotate(-4deg); }
                80% { transform: translateY(-2px) scale(0.97) rotate(3deg); }
            }
            @-webkit-keyframes otaDiceWiggle {
                0%, 100% { -webkit-transform: translateY(0) scale(1) rotate(0deg); }
                20% { -webkit-transform: translateY(-6px) scale(1.1) rotate(-8deg); }
                40% { -webkit-transform: translateY(-1px) scale(0.95) rotate(5deg); }
                60% { -webkit-transform: translateY(-7px) scale(1.08) rotate(-4deg); }
                80% { -webkit-transform: translateY(-2px) scale(0.97) rotate(3deg); }
            }
            .ota-dice-face {
                position: absolute;
                width: 28px;
                height: 28px;
                background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.98));
                border: 1.8px solid #00e5ff;
                border-radius: 7px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 14px;
                box-shadow: inset 0 0 7px rgba(0, 229, 255, 0.45), 0 0 12px rgba(0, 229, 255, 0.6);
                backface-visibility: visible;
                -webkit-backface-visibility: visible;
            }
            .ota-face-front  { transform: rotateY(0deg) translateZ(14px); -webkit-transform: rotateY(0deg) translateZ(14px); }
            .ota-face-back   { transform: rotateY(180deg) translateZ(14px); -webkit-transform: rotateY(180deg) translateZ(14px); border-color: #facc15; }
            .ota-face-right  { transform: rotateY(90deg) translateZ(14px); -webkit-transform: rotateY(90deg) translateZ(14px); border-color: #a855f7; }
            .ota-face-left   { transform: rotateY(-90deg) translateZ(14px); -webkit-transform: rotateY(-90deg) translateZ(14px); border-color: #38bdf8; }
            .ota-face-top    { transform: rotateX(90deg) translateZ(14px); -webkit-transform: rotateX(90deg) translateZ(14px); border-color: #facc15; }
            .ota-face-bottom { transform: rotateX(-90deg) translateZ(14px); -webkit-transform: rotateX(-90deg) translateZ(14px); border-color: #22c55e; }
            .ota-title {
                font-size: 16px;
                font-weight: 800;
                color: #00e5ff;
                margin: 0;
                text-shadow: 0 0 10px rgba(0,229,255,0.5);
                letter-spacing: 0.3px;
                line-height: 1.2;
            }
            .ota-subtitle {
                font-size: 11px;
                color: #94a3b8;
                margin: 2px 0 0 0;
                line-height: 1.3;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                max-width: 270px;
            }
            .ota-info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 6px 12px;
                background: rgba(15, 23, 42, 0.7);
                border: 1px solid rgba(56, 189, 248, 0.25);
                border-radius: 10px;
                padding: 8px 12px;
                margin-bottom: 10px;
                box-shadow: inset 0 2px 6px rgba(0,0,0,0.4);
            }
            .ota-info-row {
                display: flex;
                align-items: center;
                gap: 6px;
                font-size: 12px;
            }
            .ota-info-label {
                color: #94a3b8;
                font-weight: 500;
                flex-shrink: 0;
            }
            .ota-info-value {
                color: #fff;
                font-weight: 700;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .ota-badge-size {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                background: linear-gradient(135deg, rgba(2,132,199,0.25), rgba(16,185,129,0.25));
                border: 1px solid #10b981;
                color: #34d399;
                font-weight: 800;
                font-size: 12px;
                padding: 2px 8px;
                border-radius: 12px;
                text-shadow: 0 0 6px rgba(16,185,129,0.5);
                flex-shrink: 0;
            }
            .ota-btn-primary {
                width: 100%;
                background: linear-gradient(135deg, #0284c7 0%, #00e5ff 50%, #10b981 100%);
                color: #030712;
                border: none;
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 14px;
                font-weight: 900;
                cursor: pointer !important;
                box-shadow: 0 4px 15px rgba(0,229,255,0.45);
                transition: transform 0.15s ease, box-shadow 0.15s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                position: relative !important;
                z-index: 2147483647 !important;
                pointer-events: auto !important;
                touch-action: manipulation !important;
                -webkit-tap-highlight-color: rgba(0, 229, 255, 0.4);
                user-select: none;
                -webkit-user-select: none;
            }
            .ota-btn-primary * {
                pointer-events: none !important;
            }
            .ota-btn-primary:active {
                transform: scale(0.96) !important;
                filter: brightness(1.15) !important;
            }
            .ota-progress-track {
                width: 100%;
                height: 12px;
                background: rgba(15, 23, 42, 0.9);
                border: 1.5px solid rgba(0, 229, 255, 0.5);
                border-radius: 8px;
                overflow: hidden;
                position: relative;
                box-shadow: inset 0 2px 6px rgba(0,0,0,0.6);
                margin: 8px 0 6px 0;
            }
            .ota-progress-fill {
                height: 100%;
                width: 0%;
                background: linear-gradient(90deg, #0284c7, #00e5ff, #10b981);
                background-size: 30px 30px;
                border-radius: 6px;
                transition: width 0.18s ease-out;
                box-shadow: 0 0 10px rgba(0,229,255,0.8);
            }
            .ota-percent-number {
                font-size: 24px;
                font-weight: 900;
                color: #00e5ff;
                text-shadow: 0 0 12px rgba(0,229,255,0.7);
                letter-spacing: 0.5px;
                line-height: 1;
            }
            .ota-status-step {
                font-size: 12px;
                color: #38bdf8;
                font-weight: 600;
                min-height: 16px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .in-game-ota-alert-pill {
                position: fixed !important;
                top: 14px !important;
                left: 50% !important;
                transform: translateX(-50%) !important;
                z-index: 2147483640 !important;
                display: flex !important;
                align-items: center !important;
                gap: 12px !important;
                background: radial-gradient(circle at top left, #1e293b 0%, #090d16 100%) !important;
                border: 2px solid #f59e0b !important;
                border-radius: 36px !important;
                padding: 8px 18px !important;
                color: #fff !important;
                box-shadow: 0 10px 35px rgba(0,0,0,0.85), 0 0 25px rgba(245, 158, 11, 0.45) !important;
                backdrop-filter: blur(12px) !important;
                -webkit-backdrop-filter: blur(12px) !important;
                animation: otaAlertSlideDown 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
                cursor: pointer !important;
                max-width: min(92vw, 560px) !important;
                box-sizing: border-box !important;
                pointer-events: auto !important;
                transition: transform 0.2s ease, box-shadow 0.2s ease !important;
            }
            .in-game-ota-alert-pill:hover {
                transform: translateX(-50%) scale(1.02) !important;
                box-shadow: 0 12px 40px rgba(0,0,0,0.9), 0 0 30px rgba(245, 158, 11, 0.6) !important;
            }
            .in-game-ota-alert-icon {
                font-size: 26px !important;
                line-height: 1 !important;
                animation: otaWarningBounce 1s infinite alternate ease-in-out !important;
                filter: drop-shadow(0 0 8px #f59e0b) !important;
                flex-shrink: 0 !important;
            }
            .in-game-ota-alert-content {
                display: flex !important;
                flex-direction: column !important;
                text-align: left !important;
                line-height: 1.3 !important;
                min-width: 0 !important;
            }
            .in-game-ota-alert-header {
                display: flex !important;
                align-items: center !important;
                gap: 8px !important;
            }
            .in-game-ota-alert-title {
                font-size: 13px !important;
                font-weight: 800 !important;
                color: #fbbf24 !important;
                letter-spacing: 0.3px !important;
            }
            .in-game-ota-alert-tag {
                font-size: 9px !important;
                background: #f59e0b !important;
                color: #000 !important;
                font-weight: 900 !important;
                padding: 1px 7px !important;
                border-radius: 10px !important;
                letter-spacing: 0.2px !important;
            }
            .in-game-ota-alert-desc {
                font-size: 11px !important;
                color: #f1f5f9 !important;
                white-space: nowrap !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
            }
            @keyframes otaWarningBounce {
                0% { transform: translateY(0) scale(1); }
                100% { transform: translateY(-3px) scale(1.18); filter: drop-shadow(0 0 12px #fbbf24); }
            }
            @keyframes otaAlertSlideDown {
                0% { transform: translate(-50%, -35px); opacity: 0; }
                100% { transform: translate(-50%, 0); opacity: 1; }
            }
        `;

        const styleEl = document.createElement('style');
        styleEl.id = 'ota-custom-styles';
        styleEl.innerHTML = css;
        document.head.appendChild(styleEl);
    }

    // Top-level module-scoped triggerUpdate function
    function triggerUpdate(e) {
        if (e) {
            try { e.preventDefault(); } catch(err) {}
            try { e.stopPropagation(); } catch(err) {}
        }
        if (isUpdateTriggered) return;
        isUpdateTriggered = true;

        const updateBtn = document.getElementById('btn-ota-start-update');
        if (updateBtn) {
            updateBtn.disabled = true;
            updateBtn.style.opacity = '0.75';
            updateBtn.innerHTML = '<span>⚡</span><span>กำลังเริ่มอัปเดตระบบ...</span>';
        }

        if (typeof window.SnakeOTA?.startUpdateProcess === 'function') {
            window.SnakeOTA.startUpdateProcess();
        } else if (typeof window._otaStartUpdate === 'function') {
            window._otaStartUpdate();
        } else {
            startUpdateProcess();
        }
    }

    function bindUpdateBtn(el) {
        if (!el || el._otaBound) return;
        el._otaBound = true;
        el.onclick = triggerUpdate;
        el.addEventListener('click', triggerUpdate);
        el.addEventListener('touchend', triggerUpdate, { passive: true });
    }

    function ensureOtaModalElement() {
        injectOtaStyles();
        let overlay = document.getElementById('ota-update-popup-overlay');
        if (overlay) return overlay;

        overlay = document.createElement('div');
        overlay.id = 'ota-update-popup-overlay';
        overlay.className = 'ota-modal-overlay';
        overlay.style.display = 'none';

        overlay.innerHTML = `
            <div class="ota-modal-card" id="ota-modal-card-box">
                <div id="ota-view-notify">
                    <div class="ota-landscape-header">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <div class="ota-dice-emblem-wrap" title="Snake & Ladder 3D">
                                <div class="ota-dice-aura"></div>
                                <div class="ota-dice-cube">
                                    <div class="ota-dice-face ota-face-front">🎲</div>
                                    <div class="ota-dice-face ota-face-back">💎</div>
                                    <div class="ota-dice-face ota-face-right">💰</div>
                                    <div class="ota-dice-face ota-face-left">👑</div>
                                    <div class="ota-dice-face ota-face-top">⚡</div>
                                    <div class="ota-dice-face ota-face-bottom">🐍</div>
                                </div>
                            </div>
                            <div>
                                <div class="ota-title">พบการอัปเดตเวอร์ชันใหม่!</div>
                                <div class="ota-subtitle" id="ota-notify-subtitle">อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล</div>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
                            <div class="ota-badge-size" id="ota-info-size" title="ขนาดไฟล์อัปเดต">
                                <span>💾</span> <span id="ota-info-size-text">2.8 MB</span>
                            </div>
                            <div class="ota-badge-files" id="ota-info-files-badge" title="จำนวนไฟล์อัปเดต" style="display:inline-flex; align-items:center; gap:4px; background:linear-gradient(135deg, rgba(245,158,11,0.25), rgba(16,185,129,0.25)); border:1px solid #f59e0b; color:#fbbf24; font-weight:800; font-size:12px; padding:2px 8px; border-radius:12px; text-shadow:0 0 6px rgba(245,158,11,0.5); flex-shrink:0;">
                                <span>📁</span> <span id="ota-info-files-badge-text">14 ไฟล์</span>
                            </div>
                        </div>
                    </div>

                    <div class="ota-info-grid">
                        <div class="ota-info-row">
                            <span class="ota-info-label">📦 เวอร์ชัน:</span>
                            <span class="ota-info-value" id="ota-info-version">v1.0.0</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">🔢 รหัสซิงก์:</span>
                            <span class="ota-info-value" id="ota-info-cache" style="color:#ffd700;">#1794057000</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">💾 ขนาดไฟล์:</span>
                            <span class="ota-info-value" id="ota-info-size-detail" style="color:#38bdf8; font-weight:800;">2.8 MB</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">📁 จำนวนไฟล์:</span>
                            <span class="ota-info-value" id="ota-info-files-detail" style="color:#10b981; font-weight:800;">14 ไฟล์</span>
                        </div>
                        <div class="ota-info-row" style="grid-column: span 2; border-top: 1px dashed rgba(255,255,255,0.08); padding-top: 4px; margin-top: 2px;">
                            <span class="ota-info-label">📝 รายละเอียด:</span>
                            <span class="ota-info-value" id="ota-info-release" style="color:#cbd5e1; font-weight:500;">-</span>
                        </div>
                    </div>

                    <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:4px;">
                        <span style="font-size:10px; color:#94a3b8; display:flex; align-items:center; gap:4px; flex-shrink:0;">
                            <span>💡</span> แนะนำให้อัปเดตทันที
                        </span>
                        <button type="button" class="ota-btn-primary" id="btn-ota-start-update" onclick="window.SnakeOTA.startUpdateProcess()" style="flex:1; max-width:260px;">
                            <span>⚡</span>
                            <span>กดอัปเดตระบบเกมส์เดี๋ยวนี้</span>
                        </button>
                    </div>
                </div>

                <div id="ota-view-progress" style="display:none;">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:4px;">
                        <div style="display:flex; align-items:center; gap:6px;">
                            <div class="ota-dice-emblem-wrap" style="width:28px; height:28px; perspective:140px;">
                                <div class="ota-dice-cube" style="width:20px; height:20px;">
                                    <div class="ota-dice-face ota-face-front" style="width:20px; height:20px; font-size:10px; transform:rotateY(0deg) translateZ(10px);">🎲</div>
                                    <div class="ota-dice-face ota-face-back" style="width:20px; height:20px; font-size:10px; transform:rotateY(180deg) translateZ(10px); border-color:#facc15;">💎</div>
                                    <div class="ota-dice-face ota-face-right" style="width:20px; height:20px; font-size:10px; transform:rotateY(90deg) translateZ(10px); border-color:#a855f7;">💰</div>
                                    <div class="ota-dice-face ota-face-left" style="width:20px; height:20px; font-size:10px; transform:rotateY(-90deg) translateZ(10px); border-color:#38bdf8;">👑</div>
                                    <div class="ota-dice-face ota-face-top" style="width:20px; height:20px; font-size:10px; transform:rotateX(90deg) translateZ(10px); border-color:#facc15;">⚡</div>
                                    <div class="ota-dice-face ota-face-bottom" style="width:20px; height:20px; font-size:10px; transform:rotateX(-90deg) translateZ(10px); border-color:#22c55e;">🐍</div>
                                </div>
                            </div>
                            <div>
                                <div class="ota-title" style="font-size:15px;">กำลังอัปเดตระบบเกมส์...</div>
                                <div style="font-size:10px; color:#94a3b8;" id="ota-progress-sub-info">กรุณารอสักครู่ ห้ามปิดหน้าต่างเกม</div>
                            </div>
                        </div>
                        <div class="ota-percent-number" id="ota-progress-pct-text">0%</div>
                    </div>

                    <div class="ota-progress-track">
                        <div class="ota-progress-fill" id="ota-progress-bar-inner"></div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div class="ota-status-step" id="ota-progress-step-text">
                            กำลังเตรียมการดาวน์โหลดข้อมูล...
                        </div>
                        <div style="font-size:10px; color:#10b981; font-weight:700;" id="ota-progress-byte-info">
                            OTA Fast Download
                        </div>
                    </div>
                </div>
            </div>
        `;

        isUpdateTriggered = false;
        const updateBtn = overlay.querySelector('#btn-ota-start-update');
        bindUpdateBtn(updateBtn);

        document.body.appendChild(overlay);
        return overlay;
    }

    function showGameUpdatePopup(configData) {
        if (isUpdating || updateModalVisible) return;
        pendingUpdateData = configData;

        // 🚨 สำคัญที่สุด: ซ่อนและทำลาย Splash Screen ทิ้งทันที!
        try {
            if (typeof window.dismissSplashScreen === 'function') {
                window.dismissSplashScreen();
            }
            const splashEl = document.getElementById('game-splash-screen');
            if (splashEl) {
                splashEl.classList.add('fade-out', 'dismissed');
                splashEl.style.pointerEvents = 'none';
                splashEl.style.display = 'none';
                if (splashEl.parentNode) {
                    splashEl.parentNode.removeChild(splashEl);
                }
            }
        } catch (e) {}

        const overlay = ensureOtaModalElement();
        const vNotify = document.getElementById('ota-view-notify');
        const vProg = document.getElementById('ota-view-progress');

        // รีเซ็ตสถานะปุ่มและพร้อมรับการคลิกทันที
        isUpdateTriggered = false;
        const btn = document.getElementById('btn-ota-start-update');
        if (btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.innerHTML = `<span>⚡</span><span>กดอัปเดตระบบเกมส์เดี๋ยวนี้</span>`;
            btn.onclick = triggerUpdate;
            btn.addEventListener('click', triggerUpdate);
            btn.addEventListener('touchend', triggerUpdate, { passive: true });
        }

        if (vNotify) vNotify.style.display = 'block';
        if (vProg) vProg.style.display = 'none';

        const verEl = document.getElementById('ota-info-version');
        const cacheEl = document.getElementById('ota-info-cache');
        const sizeTextEl = document.getElementById('ota-info-size-text');
        const filesBadgeText = document.getElementById('ota-info-files-badge-text');
        const sizeDetailEl = document.getElementById('ota-info-size-detail');
        const filesDetailEl = document.getElementById('ota-info-files-detail');
        const releaseEl = document.getElementById('ota-info-release');
        const subTitleEl = document.getElementById('ota-notify-subtitle');

        const sizeStr = configData.update_size || '2.8 MB';
        const filesCount = configData.file_count || configData.update_files || configData.affected_files_count || 14;
        const filesStr = configData.update_files_text || (filesCount + ' ไฟล์');

        if (verEl) verEl.innerText = 'v' + (configData.app_version || '1.0.0');
        if (cacheEl) cacheEl.innerText = '#' + (configData.cache_version || Date.now());
        if (sizeTextEl) sizeTextEl.innerText = sizeStr;
        if (filesBadgeText) filesBadgeText.innerText = filesStr;
        if (sizeDetailEl) sizeDetailEl.innerText = sizeStr;
        if (filesDetailEl) filesDetailEl.innerText = filesStr;
        if (releaseEl) releaseEl.innerText = configData.release_note || 'อัปเดตความเสถียรระบบเกมส์';
        if (subTitleEl && configData.release_note) {
            subTitleEl.innerText = configData.release_note;
        }

        overlay.style.display = 'flex';
        requestAnimationFrame(() => {
            overlay.classList.add('ota-visible');
        });
        updateModalVisible = true;
    }

    async function startUpdateProcess() {
        if (isUpdating) return;
        isUpdating = true;

        ensureOtaModalElement();
        const vNotify = document.getElementById('ota-view-notify');
        const vProg = document.getElementById('ota-view-progress');
        const bar = document.getElementById('ota-progress-bar-inner');
        const pctText = document.getElementById('ota-progress-pct-text');
        const stepText = document.getElementById('ota-progress-step-text');
        const subInfo = document.getElementById('ota-progress-sub-info');
        const byteInfo = document.getElementById('ota-progress-byte-info');

        if (vNotify) vNotify.style.display = 'none';
        if (vProg) vProg.style.display = 'block';

        const targetCache = pendingUpdateData && pendingUpdateData.cache_version
            ? String(pendingUpdateData.cache_version)
            : String(Date.now());
        const targetSize = pendingUpdateData ? (pendingUpdateData.update_size || '2.8 MB') : '2.8 MB';
        const targetFilesCount = pendingUpdateData ? (pendingUpdateData.file_count || pendingUpdateData.update_files || pendingUpdateData.affected_files_count || 14) : 14;
        const targetFiles = pendingUpdateData ? (pendingUpdateData.update_files_text || (targetFilesCount + ' ไฟล์')) : (targetFilesCount + ' ไฟล์');

        if (byteInfo) {
            byteInfo.innerText = `${targetSize} • ${targetFiles}`;
        }

        // บันทึกเวอร์ชันใหม่ทันทีตั้งแต่เริ่มกด เพื่อไม่ให้รีเฟรชซ้ำเด็ดขาด
        setLocalVersion(targetCache);

        function updateProgress(pct, message, subMsg) {
            const clamped = Math.min(100, Math.max(0, Math.round(pct)));
            if (bar) bar.style.width = clamped + '%';
            if (pctText) pctText.innerText = clamped + '%';
            if (stepText && message) stepText.innerText = message;
            if (subInfo && subMsg) subInfo.innerText = subMsg;
        }

        const coreAssets = [
            `index.html?v=${targetCache}`,
            `css/style.css?v=${targetCache}`,
            `js/sound_engine.js?v=${targetCache}`,
            `js/thai_audio_manager.js?v=${targetCache}`,
            `js/realistic_avatars.js?v=${targetCache}`,
            `js/api_client.js?v=${targetCache}`,
            `js/game3d.js?v=${targetCache}`,
            `js/clan_house3d.js?v=${targetCache}`,
            `js/clan_directory.js?v=${targetCache}`,
            `js/ota_client.js?v=${targetCache}`,
            `js/ui.js?v=${targetCache}`,
            `js/ui_events.js?v=${targetCache}`,
            `js/shop_showcase.js?v=${targetCache}`
        ];

        try {
            updateProgress(8, '🔍 กำลังตรวจสอบความพร้อมของเซิร์ฟเวอร์...', `เตรียมดาวน์โหลด ${targetSize} (${targetFiles})`);
            await new Promise(r => setTimeout(r, 150));

            const stepIncrement = 62 / Math.max(1, coreAssets.length);
            let currentPct = 15;

            for (let i = 0; i < coreAssets.length; i++) {
                const assetUrl = coreAssets[i];
                const fileName = assetUrl.split('/').pop().split('?')[0];

                currentPct += stepIncrement;
                updateProgress(
                    currentPct,
                    `📥 กำลังดาวน์โหลด: ${fileName} (${Math.round(currentPct)}%)`,
                    `ความคืบหน้า ${i + 1}/${coreAssets.length} ไฟล์ (${targetSize} • ${targetFiles})`
                );

                try {
                    await fetch(`${assetUrl}&_t=${Date.now()}_${i}`, { cache: 'no-store' }).catch(() => null);
                } catch (e) {}

                await new Promise(r => setTimeout(r, 35));
            }

            updateProgress(85, '⚙️ กำลังล้างแคชเก่าและติดตั้งทรัพยากรใหม่...', 'กำลังบันทึกเวอร์ชันล่าสุด...');

            if ('caches' in window) {
                try {
                    const cacheKeys = await window.caches.keys();
                    for (const key of cacheKeys) {
                        await window.caches.delete(key);
                    }
                } catch (e) {}
            }

            setLocalVersion(targetCache);
            if (pendingUpdateData && pendingUpdateData.events_summary && pendingUpdateData.events_summary.signature) {
                try {
                    localStorage.setItem('snake_applied_event_sig', pendingUpdateData.events_summary.signature);
                } catch(e) {}
            }
            updateProgress(100, '✅ อัปเดตเสร็จสมบูรณ์ 100%!', 'กำลังเข้าสู่เกมใหม่...');
            if (bar) bar.style.boxShadow = '0 0 25px #10b981';
            if (pctText) {
                pctText.style.color = '#10b981';
                pctText.innerText = '100%';
            }

            await new Promise(r => setTimeout(r, 350));

            const cleanUrl = window.location.href.split('?')[0].split('#')[0];
            const nextUrl = `${cleanUrl}?v=${targetCache}&_hard=${Date.now()}`;
            try {
                window.location.replace(nextUrl);
            } catch(e) {
                window.location.href = nextUrl;
            }
            setTimeout(() => {
                try { window.location.reload(); } catch(e) {}
            }, 2500);
        } catch (err) {
            console.error('OTA Update Error:', err);
            setLocalVersion(targetCache);
            const cleanUrl = window.location.href.split('?')[0].split('#')[0];
            const nextUrl = `${cleanUrl}?v=${targetCache}&_hard=${Date.now()}`;
            try {
                window.location.replace(nextUrl);
            } catch(e) {
                window.location.href = nextUrl;
            }
            setTimeout(() => {
                try { window.location.reload(); } catch(e) {}
            }, 2500);
        }
    }

    let pendingInGameUpdate = null;
    let scheduledEventTimers = [];

    function scheduleUpcomingEventTimers(eventsSummary) {
        if (!eventsSummary || !Array.isArray(eventsSummary.upcoming_timestamps)) return;
        scheduledEventTimers.forEach(t => clearTimeout(t));
        scheduledEventTimers = [];

        const now = Date.now();
        eventsSummary.upcoming_timestamps.forEach(ts => {
            const targetMs = ts * 1000;
            const diff = targetMs - now;
            // ตั้งเวลาทริกเกอร์ระดับเสี้ยววินาทีเมื่อถึงเวลาเริ่มหรือหมดเวลากิจกรรม (ภายใน 24 ชม.)
            if (diff > 0 && diff < 86400000) {
                console.log(`[SnakeOTA] ⏰ Event timer scheduled in ${Math.round(diff/1000)}s (${new Date(targetMs).toLocaleTimeString()})`);
                const tid = setTimeout(() => {
                    console.log(`[SnakeOTA] ⏰ Exact-second event transition reached! Checking for event updates...`);
                    checkForUpdates(false);
                }, diff + 250);
                scheduledEventTimers.push(tid);
            }
        });
    }

    function showInGameEventAlert(updateData) {
        let alertBox = document.getElementById('in-game-ota-alert');
        if (!alertBox) {
            alertBox = document.createElement('div');
            alertBox.id = 'in-game-ota-alert';
            alertBox.className = 'in-game-ota-alert-pill';
            document.body.appendChild(alertBox);
        }

        const note = updateData.release_note || 'มีการอัปเดตกิจกรรมใหม่ในระบบ';
        alertBox.innerHTML = `
            <div class="in-game-ota-alert-icon">⚠️</div>
            <div class="in-game-ota-alert-content">
                <div class="in-game-ota-alert-header">
                    <span class="in-game-ota-alert-title">🚨 แจ้งเตือนอัปเดตกิจกรรม</span>
                    <span class="in-game-ota-alert-tag">รอเข้าเมื่อจบเกม</span>
                </div>
                <div class="in-game-ota-alert-desc" title="${note}">
                    ${note} • ระบบจะเข้าหน้าอัปเดตทันทีเมื่อจบการแข่งขัน
                </div>
            </div>
        `;
        alertBox.style.display = 'flex';

        try {
            if (window.soundEngine && typeof window.soundEngine.playTurnBell === 'function') {
                window.soundEngine.playTurnBell();
            }
        } catch(e) {}
    }

    function hideInGameEventAlert() {
        const alertBox = document.getElementById('in-game-ota-alert');
        if (alertBox) {
            alertBox.style.display = 'none';
        }
    }

    function triggerPendingInGameUpdate() {
        if (!pendingInGameUpdate) return;
        const updateData = pendingInGameUpdate;
        pendingInGameUpdate = null;
        hideInGameEventAlert();
        console.log('[SnakeOTA] 🏁 Match concluded! Triggering queued update popup immediately.');
        setTimeout(() => {
            showGameUpdatePopup(updateData);
        }, 600);
    }
    window.triggerPendingInGameUpdate = triggerPendingInGameUpdate;

    let pendingHomeDelayTimer = null;

    function isElVisible(id) {
        const el = document.getElementById(id);
        if (!el) return false;
        const st = window.getComputedStyle ? window.getComputedStyle(el) : el.style;
        return st.display !== 'none' && st.visibility !== 'hidden' && el.offsetParent !== null;
    }

    function isPlayerBusyInMatchOrReward() {
        return Boolean(
            (window.game && window.game.isMatchActive) ||
            document.body.classList.contains('in-match-fullscreen') ||
            document.body.classList.contains('in-matchmaking') ||
            isElVisible('matchmaking-waiting-overlay') ||
            isElVisible('turn-picker-overlay') ||
            isElVisible('modal-gameover') ||
            isElVisible('game-over-modal') ||
            isElVisible('winner-reward-modal')
        );
    }

    function schedulePendingUpdateAfterHomeDelay() {
        if (!pendingInGameUpdate || pendingHomeDelayTimer) return;
        pendingHomeDelayTimer = setTimeout(() => {
            pendingHomeDelayTimer = null;
            if (pendingInGameUpdate && !isPlayerBusyInMatchOrReward()) {
                triggerPendingInGameUpdate();
            }
        }, 3000);
    }

    async function checkForUpdates(silent = true) {
        if (isUpdating || updateModalVisible) {
            console.log('[SnakeOTA] ⏭ Skipped: isUpdating=' + isUpdating + ', updateModalVisible=' + updateModalVisible);
            return;
        }

        // ห้ามขัดจังหวะหรือรีโหลดหน้าเว็บในขณะที่กำลังกลับมาจากหน้า OAuth Login (Google / LINE) เด็ดขาด
        const rawSearch = (window.location && window.location.search) ? window.location.search : '';
        const rawHash = (window.location && window.location.hash) ? window.location.hash : '';
        const isOAuthReturn = rawSearch.includes('code=')
            || rawSearch.includes('token=')
            || rawSearch.includes('auth_token=')
            || rawHash.includes('id_token=')
            || rawHash.includes('access_token=')
            || Boolean(window._oauthRedirectInProgress);
        if (isOAuthReturn) {
            return;
        }

        try {
            const currentLocal = getLocalVersion();
            const endpoint = getApiEndpoint();
            const res = await fetch(`${endpoint}?t=${Date.now()}`, {
                cache: 'no-store'
            }).then(r => r.json());

            if (!res || res.status !== 'success') return;

            // ซิงก์ค่าโหมดเกมส์หลัก (เกมส์เศรษฐี / บันไดงู) และกระดานจาก Admin สำหรับ iOS, Android และ Web
            if (res.game_rules) {
                window.GAME_RULES = res.game_rules;
            }
            if (res.game_modes) {
                window.GAME_MODES_CONFIG = res.game_modes;
            }
            if (res.active_monopoly_board) {
                window.ACTIVE_MONOPOLY_BOARD = res.active_monopoly_board;
            }
            if (Array.isArray(res.monopoly_boards)) {
                window.MONOPOLY_BOARDS_LIST = res.monopoly_boards;
            }
            if (typeof window.syncHomeGameModeSwitcher === 'function') {
                window.syncHomeGameModeSwitcher(true);
            }

            // ตั้งเวลาทริกเกอร์ตรงเวลาเมื่อถึงเวลาเริ่ม/หมดกิจกรรม
            if (res.events_summary) {
                scheduleUpcomingEventTimers(res.events_summary);
                if (typeof window.syncSidebarEventsSummary === 'function') {
                    window.syncSidebarEventsSummary(res.events_summary);
                }
            }

            const isMatchActive = isPlayerBusyInMatchOrReward();

            // ซิงก์รายการกระดาน AI 3D ใน Modal (ไม่ฝืนทับกระดานมาตรฐานหน้าหลักของผู้เล่น เพื่อป้องกันจอดำ)
            if (typeof window.fetchAndApplyActiveAiBoards === 'function') {
                try {
                    window.fetchAndApplyActiveAiBoards(false);
                } catch (boardSyncErr) {
                    console.warn('[SnakeOTA] AI Board sync warning:', boardSyncErr);
                }
            }

            if (!res.cache_version) {
                console.log('[SnakeOTA] ⏭ No cache_version in response:', JSON.stringify(res).substring(0, 200));
                return;
            }

            const serverCache = String(res.cache_version).trim();
            const serverNum = Number(serverCache || 0);
            const localNum = Number(currentLocal || 0);

            // เช็คว่ามี event state signature เปลี่ยนแปลงหรือไม่
            const storedSig = localStorage.getItem('snake_applied_event_sig') || '';
            const currentSig = res.events_summary ? (res.events_summary.signature || '') : '';
            const isEventChanged = (Boolean(currentSig) && Boolean(storedSig) && currentSig !== storedSig);

            console.log(`[SnakeOTA] 📊 Compare: server=${serverNum}, local=${localNum}, sig=${currentSig}, storedSig=${storedSig}, isMatch=${isMatchActive}`);

            // หากรอบนี้เพิ่งอัปเดตไปหมาดๆ ไม่แสดงซ้ำ
            if (isAppliedInCurrentSession(serverCache) && !isEventChanged) {
                console.log('[SnakeOTA] ⏭ Already applied in this session');
                setLocalVersion(serverCache);
                return;
            }

            const isNewUpdate = (serverNum > 0 && (localNum === 0 || serverNum > localNum)) || isEventChanged;

            // แจ้งเตือนเมื่อเซิร์ฟเวอร์มีเวอร์ชันใหม่ หรือมีการเริ่ม/หมดเวลากิจกรรม
            if (isNewUpdate) {
                console.log(`[SnakeOTA] 🚀 New update/event detected! Server: ${serverCache}, Local: ${currentLocal}`);
                if (isMatchActive) {
                    // กำลังเล่นเกมหรือรับรางวัลอยู่: เก็บเข้าคิวเงียบๆ ไม่เด้ง popup รบกวน จนกว่าจะกลับหน้าแรกแล้ว 3 วินาที
                    console.log('[SnakeOTA] 🎮 In-game/reward detected! Queueing update popup silently until 3s after returning home.');
                    pendingInGameUpdate = res;
                } else {
                    // ไม่อยู่ในเกม: แสดงหน้าต่าง Popup อัปเดตทันที
                    hideInGameEventAlert();
                    showGameUpdatePopup(res);
                }
            } else if (serverNum > 0 && serverNum <= localNum) {
                console.log(`[SnakeOTA] ✅ Up to date (server ${serverNum} <= local ${localNum})`);
                setLocalVersion(String(localNum));
            }
        } catch (e) {
            console.warn('[SnakeOTA] Check error:', e);
        }
    }

    function initOtaSystem() {
        // ตรวจสอบทันทีที่เปิดแอป (300ms)
        setTimeout(() => {
            checkForUpdates(false);
        }, 2500);

        // ตรวจสอบซ้ำอีกครั้งที่ 1.5 วินาที
        setTimeout(() => {
            checkForUpdates(true);
        }, 12000);

        // ตรวจสอบทุก 15 วินาที เพื่อให้แสดงผลทันทีหลังกด Deploy หรือเริ่มกิจกรรม
        setInterval(() => {
            checkForUpdates(true);
        }, OTA_CONFIG.checkIntervalMs);

        // ตรวจสอบสถานะการกลับสู่หน้าแรกทุก 1 วินาที: เมื่อเล่นเสร็จและรับรางวัลออกสู่หน้าแรกแล้ว รอ 3 วินาทีจึงแสดง Popup อัปเดต
        setInterval(() => {
            if (pendingInGameUpdate) {
                if (!isPlayerBusyInMatchOrReward()) {
                    schedulePendingUpdateAfterHomeDelay();
                } else if (pendingHomeDelayTimer) {
                    clearTimeout(pendingHomeDelayTimer);
                    pendingHomeDelayTimer = null;
                }
            }
        }, 1000);

        // Hook exitToHomeScreen เพื่อเริ่มนับถอยหลัง 3 วินาทีหลังกลับถึงหน้าแรก
        const hookTimer = setInterval(() => {
            if (typeof window.exitToHomeScreen === 'function' && !window.exitToHomeScreen._otaHooked) {
                const prevExitToHome = window.exitToHomeScreen;
                window.exitToHomeScreen = function(...args) {
                    const ret = prevExitToHome.apply(this, args);
                    if (pendingInGameUpdate) {
                        schedulePendingUpdateAfterHomeDelay();
                    }
                    return ret;
                };
                window.exitToHomeScreen._otaHooked = true;
            }

            if (window.exitToHomeScreen?._otaHooked) {
                clearInterval(hookTimer);
            }
        }, 500);

        // เมื่อสลับกลับเข้ามาที่หน้าแอปเกมบนมือถือ
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                checkForUpdates(false);
            }
        });

        window.addEventListener('focus', () => {
            checkForUpdates(false);
        });

        window.addEventListener('pageshow', () => {
            checkForUpdates(false);
        });
    }

    window.SnakeOTA = {
        check: checkForUpdates,
        startUpdateProcess: startUpdateProcess,
        showPopup: showGameUpdatePopup,
        getLocalVersion: getLocalVersion
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initOtaSystem);
    } else {
        initOtaSystem();
    }
})();
