/**
 * js/ota_client.js
 * Real-time OTA Update Client (Web, Android WebView & iOS)
 * - ตรวจจับ cache_version จากปุ่ม "Deploy Update to Mobile" (api/app_config.php)
 * - อัปเดตเมื่อ cache_version บนเซิร์ฟเวอร์ใหม่กว่าเวอร์ชันปัจจุบันของหน้าเว็บเท่านั้น
 * - แยกการจัดการ Event (รูป 2): รีเฟรชสถานะอีเวนต์เฉพาะเมื่อถึงเวลาเริ่ม/จบอีเวนต์ ไม่รีโหลดเกมมั่ว
 */
(function () {
    'use strict';

    const STORAGE_KEY_VER = 'snake_ota_cache_version';
    const STORAGE_KEY_EVENT_SIG = 'snake_ota_event_signature';
    let isChecking = false;
    let isPromptOpen = false;
    let eventTransitionTimer = null;

    function getEndpoint(relPath) {
        if (typeof window.getSnakeApiEndpoint === 'function') {
            return window.getSnakeApiEndpoint(relPath);
        }
        try {
            const proto = window.location.protocol;
            const host = window.location.hostname;
            const port = window.location.port;
            if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
                return 'https://pmix01.thddns.net:7175/home/snake/' + String(relPath).replace(/^\/+/, '');
            }
        } catch (e) { }
        return relPath;
    }

    function getCurrentLocalVersion() {
        const htmlVer = Number(window.__GAME_OTA_VERSION__ || 0) || 0;
        let storedVer = 0;
        try {
            storedVer = Number(localStorage.getItem(STORAGE_KEY_VER) || 0) || 0;
        } catch (e) { }
        // หาก HTML ที่โหลดมาใหม่กว่าค่าที่เคยจำไว้ ให้ซิงก์ค่าปัจจุบันทันทีเพื่อกันรีเฟรชวนลูป
        if (htmlVer > storedVer) {
            try {
                localStorage.setItem(STORAGE_KEY_VER, String(htmlVer));
            } catch (e) { }
            return htmlVer;
        }
        return storedVer || htmlVer;
    }

    function saveLocalVersion(ver) {
        try {
            localStorage.setItem(STORAGE_KEY_VER, String(ver));
        } catch (e) { }
    }

    async function performHardReload(targetVer) {
        saveLocalVersion(targetVer);
        try {
            if ('caches' in window && typeof caches.keys === 'function') {
                const keys = await caches.keys();
                await Promise.all(keys.map(k => caches.delete(k)));
            }
        } catch (e) { }

        try {
            const url = new URL(window.location.href);
            url.searchParams.set('ota_v', String(targetVer));
            window.location.replace(url.toString());
        } catch (e) {
            window.location.reload();
        }
    }

    function showUpdatePopup(cfg) {
        if (isPromptOpen) return;
        const targetVer = Number(cfg.cache_version || 0);
        if (!targetVer) return;

        isPromptOpen = true;

        const existing = document.getElementById('snake-ota-update-modal');
        if (existing && existing.parentNode) {
            existing.parentNode.removeChild(existing);
        }

        const appVer = cfg.app_version || '1.0.0';
        const sizeText = cfg.update_size || '2.5 MB';
        const filesText = cfg.update_files_text || ((cfg.file_count || 14) + ' ไฟล์');
        const noteText = cfg.release_note || 'อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล';

        const overlay = document.createElement('div');
        overlay.id = 'snake-ota-update-modal';
        overlay.style.cssText = [
            'position:fixed', 'inset:0', 'z-index:2147483645',
            'display:flex', 'align-items:center', 'justify-content:center',
            'padding:14px', 'background-color:rgba(2,6,23,0.88)',
            'box-sizing:border-box'
        ].join(';');

        const card = document.createElement('div');
        card.style.cssText = [
            'width:min(92vw,360px)', 'background-color:#0f172a',
            'border:1.5px solid #00e5ff', 'border-radius:16px',
            'padding:18px 16px', 'color:#ffffff', 'text-align:center',
            'box-shadow:0 16px 40px rgba(0,0,0,0.85), 0 0 24px rgba(0,229,255,0.28)',
            'font-family:Kanit,Prompt,sans-serif', 'box-sizing:border-box'
        ].join(';');

        card.innerHTML = `
            <div style="font-size:34px;line-height:1;margin-bottom:8px;">🚀</div>
            <div style="font-size:17px;font-weight:800;color:#00e5ff;margin-bottom:4px;">พบอัปเดตระบบเกมส์ใหม่!</div>
            <div style="font-size:12px;color:#94a3b8;margin-bottom:10px;">เวอร์ชัน ${escapeHtml(appVer)} • ${escapeHtml(sizeText)} (${escapeHtml(filesText)})</div>
            <div style="background-color:#0b1120;border:1px solid rgba(56,189,248,0.25);border-radius:10px;padding:10px 12px;font-size:12.5px;color:#e2e8f0;margin-bottom:14px;line-height:1.45;text-align:left;">
                ${escapeHtml(noteText)}
            </div>
            <button type="button" id="snake-ota-btn-now" style="width:100%;height:40px;border:none;border-radius:10px;background-color:#00b4d8;background-image:linear-gradient(135deg,#00e5ff,#0077ff);color:#000000;font-size:14px;font-weight:800;cursor:pointer;touch-action:manipulation;">
                ⚡ อัปเดตและรีโหลดทันที
            </button>
        `;

        overlay.appendChild(card);
        (document.body || document.documentElement).appendChild(overlay);

        const btnNow = document.getElementById('snake-ota-btn-now');
        if (btnNow) {
            btnNow.addEventListener('click', function () {
                btnNow.disabled = true;
                btnNow.textContent = 'กำลังอัปเดตระบบ...';
                performHardReload(targetVer);
            });
        }
    }

    function escapeHtml(str) {
        return String(str || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function handleEventSummary(eventsSummary) {
        if (!eventsSummary || typeof eventsSummary !== 'object') return;
        const newSig = String(eventsSummary.signature || '');
        let prevSig = '';
        try {
            prevSig = localStorage.getItem(STORAGE_KEY_EVENT_SIG) || '';
        } catch (e) { }

        if (newSig && newSig !== prevSig) {
            try {
                localStorage.setItem(STORAGE_KEY_EVENT_SIG, newSig);
            } catch (e) { }

            // รีเฟรชเฉพาะ UI อีเวนต์เมื่อมีการเริ่มหรือจบอีเวนต์เท่านั้น (ไม่รีโหลดทั้งแอป)
            if (prevSig) {
                try {
                    if (typeof window.loadSeparatedEventGachas === 'function') {
                        window.loadSeparatedEventGachas();
                    }
                    if (typeof window.loadActiveEvents === 'function') {
                        window.loadActiveEvents();
                    }
                } catch (e) { }
            }
        }

        // ตั้งเวลารีเฟรชสถานะอีเวนต์อัตโนมัติเมื่อถึงเวลาเริ่ม/จบอีเวนต์ถัดไป
        if (eventTransitionTimer) {
            clearTimeout(eventTransitionTimer);
            eventTransitionTimer = null;
        }
        const upcoming = Array.isArray(eventsSummary.upcoming_timestamps) ? eventsSummary.upcoming_timestamps : [];
        if (upcoming.length > 0) {
            const nowSec = Math.floor(Date.now() / 1000);
            const future = upcoming.map(Number).filter(t => t > nowSec).sort((a, b) => a - b);
            if (future.length > 0) {
                const delayMs = (future[0] - nowSec + 2) * 1000;
                if (delayMs > 0 && delayMs <= 86400000) {
                    eventTransitionTimer = setTimeout(function () {
                        window.SnakeOTA.check(true);
                    }, delayMs);
                }
            }
        }
    }

    window.SnakeOTA = {
        check: async function (showModalIfNew) {
            if (isChecking) return;
            isChecking = true;
            try {
                const cfgUrl = getEndpoint('api/app_config.php') + '?t=' + Date.now();
                const res = await fetch(cfgUrl, { cache: 'no-store' }).then(r => r.json());
                if (!res || res.status !== 'success') return;

                handleEventSummary(res.events_summary);

                const serverVer = Number(res.cache_version || 0) || 0;
                const localVer = getCurrentLocalVersion();

                if (serverVer > 0 && localVer > 0 && serverVer > localVer) {
                    if (window.game && window.game.isMatchActive) return;
                    if (showModalIfNew === false) {
                        // กรณีเปิดแอปครั้งแรกแล้วพบเวอร์ชันใหม่: แสดง Popup ให้อัปเดตทันที
                        showUpdatePopup(res);
                    } else {
                        showUpdatePopup(res);
                    }
                } else if (serverVer > 0 && localVer === 0) {
                    saveLocalVersion(serverVer);
                }
            } catch (e) {
                // ignore network glitches
            } finally {
                isChecking = false;
            }
        },
        getLocalVersion: getCurrentLocalVersion
    };

    // ตรวจสอบอัปเดตอัตโนมัติหลังโหลดหน้าเว็บ 1.5 วินาที และเช็กซ้ำทุก 15 วินาที (เฉพาะเมื่อเปิดหน้าจออยู่)
    if (typeof window !== 'undefined') {
        setTimeout(function () {
            if (window.SnakeOTA && typeof window.SnakeOTA.check === 'function') {
                window.SnakeOTA.check(true);
            }
        }, 1500);

        setInterval(function () {
            if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
            if (window.game && window.game.isMatchActive) return;
            if (window.SnakeOTA && typeof window.SnakeOTA.check === 'function') {
                window.SnakeOTA.check(true);
            }
        }, 15000);
    }
})();

