/**
 * js/ota_client.js
 * Snake & Ladder 3D - Realtime OTA (Over-The-Air) Mobile & Web Update Client
 *
 * คุณสมบัติ:
 * 1. ตรวจจับเวอร์ชันใหม่จากเซิร์ฟเวอร์แบบ Real-time โดยซิงก์กับ index.php / URL ?v= อัตโนมัติ (ไม่รีเฟรชวนลูป)
 * 2. แสดง Popup แจ้งเตือนการอัปเดตบนหน้าจอมือถือ/เว็บ พร้อมแสดงขนาดไฟล์
 * 3. เมื่อกดอัปเดต แสดง Progress Bar และตัวเลข % ความคืบหน้า (0% - 100%)
 * 4. ดาวน์โหลดไฟล์ใหม่และล้างแคชเดิม จากนั้นรีโหลดเข้าเกมใหม่อัตโนมัติเพียงครั้งเดียว
 */

(function() {
    'use strict';

    const OTA_CONFIG = {
        checkIntervalMs: 10000,
        apiEndpoint: 'api/app_config.php',
        storageKey: 'snake_client_cache_version',
        installedKey: 'snake_client_installed_version',
        sessionGuardKey: 'snake_ota_applied_ver'
    };

    let isUpdating = false;
    let updateModalVisible = false;
    let pendingUpdateData = null;

    function getApiEndpoint() {
        try {
            if (typeof window !== 'undefined' && window.location) {
                const proto = window.location.protocol;
                const host = window.location.hostname;
                const port = window.location.port;
                if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
                    return 'https://pmix01.thddns.net:7175/home/snake/api/app_config.php';
                }
                const path = window.location.pathname;
                const dir = path.substring(0, path.lastIndexOf('/') + 1);
                return (window.location.origin || '') + dir + 'api/app_config.php';
            }
        } catch (e) {}
        return 'https://pmix01.thddns.net:7175/home/snake/api/app_config.php';
    }

    // อ่านเวอร์ชันสูงสุดจาก index.php / index.html หรือพารามิเตอร์ ?v= บน URL
    function getEmbeddedVersion() {
        let best = 0;
        if (typeof window.__GAME_OTA_VERSION__ !== 'undefined' && window.__GAME_OTA_VERSION__) {
            best = Math.max(best, Number(String(window.__GAME_OTA_VERSION__).trim()) || 0);
        }
        const meta = document.querySelector('meta[name="game-ota-version"]');
        if (meta && meta.content) {
            best = Math.max(best, Number(String(meta.content).trim()) || 0);
        }
        try {
            const urlVer = new URLSearchParams(window.location.search).get('v');
            if (urlVer) {
                best = Math.max(best, Number(String(urlVer).trim()) || 0);
            }
        } catch (e) {}
        return best > 0 ? String(best) : null;
    }

    // อ่านเวอร์ชันที่เครื่องผู้เล่นติดตั้ง/ยอมรับการอัปเดตแล้วจริง (ไม่เขียนทับอัตโนมัติก่อนกดอัปเดต)
    function getLocalVersion() {
        let stored = null;
        try {
            stored = localStorage.getItem(OTA_CONFIG.installedKey) || localStorage.getItem(OTA_CONFIG.storageKey);
        } catch (e) {}

        if (stored && Number(stored) > 0) {
            return String(stored).trim();
        }
        return '0';
    }

    function isAppliedInCurrentSession(serverVer) {
        try {
            const applied = sessionStorage.getItem(OTA_CONFIG.sessionGuardKey);
            return applied && String(applied).trim() === String(serverVer).trim();
        } catch (e) {
            return false;
        }
    }

    // บันทึกเวอร์ชันใหม่เมื่อกดและดาวน์โหลดอัปเดตสำเร็จ
    function setLocalVersion(ver) {
        const clean = String(ver).trim();
        try {
            localStorage.setItem(OTA_CONFIG.storageKey, clean);
            localStorage.setItem(OTA_CONFIG.installedKey, clean);
        } catch (e) {}
        try {
            sessionStorage.setItem(OTA_CONFIG.sessionGuardKey, clean);
        } catch (e) {}
        if (typeof window !== 'undefined') {
            window.__GAME_OTA_VERSION__ = clean;
        }
    }

    function injectOtaStyles() {
        if (document.getElementById('ota-custom-styles')) return;

        const css = `
            @keyframes otaRocketFloat {
                0%, 100% { transform: translateY(0) rotate(0deg); }
                50% { transform: translateY(-8px) rotate(-3deg); }
            }
            .ota-modal-overlay {
                position: fixed;
                inset: 0;
                background: rgba(3, 7, 18, 0.88);
                backdrop-filter: blur(14px);
                -webkit-backdrop-filter: blur(14px);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 10px 14px;
                box-sizing: border-box;
                font-family: 'Kanit', sans-serif;
                opacity: 0;
                transition: opacity 0.3s ease;
            }
            .ota-modal-overlay.ota-visible {
                opacity: 1;
            }
            .ota-modal-card {
                width: 96%;
                max-width: 520px;
                background: radial-gradient(circle at top left, #0f172a 0%, #030712 100%);
                border: 1.5px solid #00e5ff;
                border-radius: 16px;
                padding: 14px 18px;
                text-align: left;
                color: #fff;
                box-shadow: 0 10px 40px rgba(0,0,0,0.85), 0 0 25px rgba(0,229,255,0.3);
                position: relative;
                transform: scale(0.95);
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
                box-sizing: border-box;
                max-height: 94vh;
                overflow-y: auto;
            }
            .ota-modal-overlay.ota-visible .ota-modal-card {
                transform: scale(1);
            }
            .ota-landscape-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 10px;
                margin-bottom: 10px;
                border-bottom: 1px solid rgba(255,255,255,0.08);
                padding-bottom: 8px;
            }
            .ota-rocket-icon {
                font-size: 26px;
                display: inline-block;
                animation: otaRocketFloat 2.2s infinite ease-in-out;
                filter: drop-shadow(0 0 10px rgba(0,229,255,0.8));
                flex-shrink: 0;
            }
            .ota-title {
                font-size: 16px;
                font-weight: 800;
                color: #00e5ff;
                margin: 0;
                text-shadow: 0 0 10px rgba(0,229,255,0.5);
                letter-spacing: 0.3px;
                line-height: 1.2;
            }
            .ota-subtitle {
                font-size: 11px;
                color: #94a3b8;
                margin: 2px 0 0 0;
                line-height: 1.3;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                max-width: 270px;
            }
            .ota-info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 6px 12px;
                background: rgba(15, 23, 42, 0.7);
                border: 1px solid rgba(56, 189, 248, 0.25);
                border-radius: 10px;
                padding: 8px 12px;
                margin-bottom: 10px;
                box-shadow: inset 0 2px 6px rgba(0,0,0,0.4);
            }
            .ota-info-row {
                display: flex;
                align-items: center;
                gap: 6px;
                font-size: 12px;
            }
            .ota-info-label {
                color: #94a3b8;
                font-weight: 500;
                flex-shrink: 0;
            }
            .ota-info-value {
                color: #fff;
                font-weight: 700;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .ota-badge-size {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                background: linear-gradient(135deg, rgba(2,132,199,0.25), rgba(16,185,129,0.25));
                border: 1px solid #10b981;
                color: #34d399;
                font-weight: 800;
                font-size: 12px;
                padding: 2px 8px;
                border-radius: 12px;
                text-shadow: 0 0 6px rgba(16,185,129,0.5);
                flex-shrink: 0;
            }
            .ota-btn-primary {
                width: 100%;
                background: linear-gradient(135deg, #0284c7 0%, #00e5ff 50%, #10b981 100%);
                color: #030712;
                border: none;
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 14px;
                font-weight: 900;
                cursor: pointer;
                box-shadow: 0 4px 15px rgba(0,229,255,0.45);
                transition: transform 0.15s ease, box-shadow 0.15s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
            }
            .ota-btn-primary:active {
                transform: scale(0.98);
            }
            .ota-progress-track {
                width: 100%;
                height: 12px;
                background: rgba(15, 23, 42, 0.9);
                border: 1.5px solid rgba(0, 229, 255, 0.5);
                border-radius: 8px;
                overflow: hidden;
                position: relative;
                box-shadow: inset 0 2px 6px rgba(0,0,0,0.6);
                margin: 8px 0 6px 0;
            }
            .ota-progress-fill {
                height: 100%;
                width: 0%;
                background: linear-gradient(90deg, #0284c7, #00e5ff, #10b981);
                background-size: 30px 30px;
                border-radius: 6px;
                transition: width 0.18s ease-out;
                box-shadow: 0 0 10px rgba(0,229,255,0.8);
            }
            .ota-percent-number {
                font-size: 24px;
                font-weight: 900;
                color: #00e5ff;
                text-shadow: 0 0 12px rgba(0,229,255,0.7);
                letter-spacing: 0.5px;
                line-height: 1;
            }
            .ota-status-step {
                font-size: 12px;
                color: #38bdf8;
                font-weight: 600;
                min-height: 16px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        `;

        const styleEl = document.createElement('style');
        styleEl.id = 'ota-custom-styles';
        styleEl.innerHTML = css;
        document.head.appendChild(styleEl);
    }

    function ensureOtaModalElement() {
        injectOtaStyles();
        let overlay = document.getElementById('ota-update-popup-overlay');
        if (overlay) return overlay;

        overlay = document.createElement('div');
        overlay.id = 'ota-update-popup-overlay';
        overlay.className = 'ota-modal-overlay';
        overlay.style.display = 'none';

        overlay.innerHTML = `
            <div class="ota-modal-card" id="ota-modal-card-box">
                <div id="ota-view-notify">
                    <div class="ota-landscape-header">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <div class="ota-rocket-icon">🚀</div>
                            <div>
                                <div class="ota-title">พบการอัปเดตเวอร์ชันใหม่!</div>
                                <div class="ota-subtitle" id="ota-notify-subtitle">อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล</div>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
                            <div class="ota-badge-size" id="ota-info-size" title="ขนาดไฟล์อัปเดต">
                                <span>💾</span> <span id="ota-info-size-text">2.8 MB</span>
                            </div>
                            <div class="ota-badge-files" id="ota-info-files-badge" title="จำนวนไฟล์อัปเดต" style="display:inline-flex; align-items:center; gap:4px; background:linear-gradient(135deg, rgba(245,158,11,0.25), rgba(16,185,129,0.25)); border:1px solid #f59e0b; color:#fbbf24; font-weight:800; font-size:12px; padding:2px 8px; border-radius:12px; text-shadow:0 0 6px rgba(245,158,11,0.5); flex-shrink:0;">
                                <span>📁</span> <span id="ota-info-files-badge-text">14 ไฟล์</span>
                            </div>
                        </div>
                    </div>

                    <div class="ota-info-grid">
                        <div class="ota-info-row">
                            <span class="ota-info-label">📦 เวอร์ชัน:</span>
                            <span class="ota-info-value" id="ota-info-version">v1.0.0</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">🔢 รหัสซิงก์:</span>
                            <span class="ota-info-value" id="ota-info-cache" style="color:#ffd700;">#1794057000</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">💾 ขนาดไฟล์:</span>
                            <span class="ota-info-value" id="ota-info-size-detail" style="color:#38bdf8; font-weight:800;">2.8 MB</span>
                        </div>
                        <div class="ota-info-row">
                            <span class="ota-info-label">📁 จำนวนไฟล์:</span>
                            <span class="ota-info-value" id="ota-info-files-detail" style="color:#10b981; font-weight:800;">14 ไฟล์</span>
                        </div>
                        <div class="ota-info-row" style="grid-column: span 2; border-top: 1px dashed rgba(255,255,255,0.08); padding-top: 4px; margin-top: 2px;">
                            <span class="ota-info-label">📝 รายละเอียด:</span>
                            <span class="ota-info-value" id="ota-info-release" style="color:#cbd5e1; font-weight:500;">-</span>
                        </div>
                    </div>

                    <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:4px;">
                        <span style="font-size:10px; color:#94a3b8; display:flex; align-items:center; gap:4px; flex-shrink:0;">
                            <span>💡</span> แนะนำให้อัปเดตทันที
                        </span>
                        <button type="button" class="ota-btn-primary" id="btn-ota-start-update" onclick="window.SnakeOTA.startUpdateProcess()" style="flex:1; max-width:260px;">
                            <span>⚡</span>
                            <span>กดอัปเดตระบบเกมส์เดี๋ยวนี้</span>
                        </button>
                    </div>
                </div>

                <div id="ota-view-progress" style="display:none;">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:4px;">
                        <div style="display:flex; align-items:center; gap:6px;">
                            <span class="ota-rocket-icon" style="font-size:20px;">⚡</span>
                            <div>
                                <div class="ota-title" style="font-size:15px;">กำลังอัปเดตระบบเกมส์...</div>
                                <div style="font-size:10px; color:#94a3b8;" id="ota-progress-sub-info">กรุณารอสักครู่ ห้ามปิดหน้าต่างเกม</div>
                            </div>
                        </div>
                        <div class="ota-percent-number" id="ota-progress-pct-text">0%</div>
                    </div>

                    <div class="ota-progress-track">
                        <div class="ota-progress-fill" id="ota-progress-bar-inner"></div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div class="ota-status-step" id="ota-progress-step-text">
                            กำลังเตรียมการดาวน์โหลดข้อมูล...
                        </div>
                        <div style="font-size:10px; color:#10b981; font-weight:700;" id="ota-progress-byte-info">
                            OTA Fast Download
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);
        return overlay;
    }

    function showGameUpdatePopup(configData) {
        if (isUpdating || updateModalVisible) return;
        pendingUpdateData = configData;

        const overlay = ensureOtaModalElement();
        const vNotify = document.getElementById('ota-view-notify');
        const vProg = document.getElementById('ota-view-progress');

        if (vNotify) vNotify.style.display = 'block';
        if (vProg) vProg.style.display = 'none';

        const verEl = document.getElementById('ota-info-version');
        const cacheEl = document.getElementById('ota-info-cache');
        const sizeTextEl = document.getElementById('ota-info-size-text');
        const filesBadgeText = document.getElementById('ota-info-files-badge-text');
        const sizeDetailEl = document.getElementById('ota-info-size-detail');
        const filesDetailEl = document.getElementById('ota-info-files-detail');
        const releaseEl = document.getElementById('ota-info-release');
        const subTitleEl = document.getElementById('ota-notify-subtitle');

        const sizeStr = configData.update_size || '2.8 MB';
        const filesCount = configData.file_count || configData.update_files || configData.affected_files_count || 14;
        const filesStr = configData.update_files_text || (filesCount + ' ไฟล์');

        if (verEl) verEl.innerText = 'v' + (configData.app_version || '1.0.0');
        if (cacheEl) cacheEl.innerText = '#' + (configData.cache_version || Date.now());
        if (sizeTextEl) sizeTextEl.innerText = sizeStr;
        if (filesBadgeText) filesBadgeText.innerText = filesStr;
        if (sizeDetailEl) sizeDetailEl.innerText = sizeStr;
        if (filesDetailEl) filesDetailEl.innerText = filesStr;
        if (releaseEl) releaseEl.innerText = configData.release_note || 'อัปเดตความเสถียรระบบเกมส์';
        if (subTitleEl && configData.release_note) {
            subTitleEl.innerText = configData.release_note;
        }

        overlay.style.display = 'flex';
        requestAnimationFrame(() => {
            overlay.classList.add('ota-visible');
        });
        updateModalVisible = true;
    }

    async function startUpdateProcess() {
        if (isUpdating) return;
        isUpdating = true;

        ensureOtaModalElement();
        const vNotify = document.getElementById('ota-view-notify');
        const vProg = document.getElementById('ota-view-progress');
        const bar = document.getElementById('ota-progress-bar-inner');
        const pctText = document.getElementById('ota-progress-pct-text');
        const stepText = document.getElementById('ota-progress-step-text');
        const subInfo = document.getElementById('ota-progress-sub-info');
        const byteInfo = document.getElementById('ota-progress-byte-info');

        if (vNotify) vNotify.style.display = 'none';
        if (vProg) vProg.style.display = 'block';

        const targetCache = pendingUpdateData && pendingUpdateData.cache_version
            ? String(pendingUpdateData.cache_version)
            : String(Date.now());
        const targetSize = pendingUpdateData ? (pendingUpdateData.update_size || '2.8 MB') : '2.8 MB';
        const targetFilesCount = pendingUpdateData ? (pendingUpdateData.file_count || pendingUpdateData.update_files || pendingUpdateData.affected_files_count || 14) : 14;
        const targetFiles = pendingUpdateData ? (pendingUpdateData.update_files_text || (targetFilesCount + ' ไฟล์')) : (targetFilesCount + ' ไฟล์');

        if (byteInfo) {
            byteInfo.innerText = `${targetSize} • ${targetFiles}`;
        }

        // บันทึกเวอร์ชันใหม่ทันทีตั้งแต่เริ่มกด เพื่อไม่ให้รีเฟรชซ้ำเด็ดขาด
        setLocalVersion(targetCache);

        function updateProgress(pct, message, subMsg) {
            const clamped = Math.min(100, Math.max(0, Math.round(pct)));
            if (bar) bar.style.width = clamped + '%';
            if (pctText) pctText.innerText = clamped + '%';
            if (stepText && message) stepText.innerText = message;
            if (subInfo && subMsg) subInfo.innerText = subMsg;
        }

        const coreAssets = [
            `css/style.css?v=${targetCache}`,
            `js/sound_engine.js?v=${targetCache}`,
            `js/thai_audio_manager.js?v=${targetCache}`,
            `js/realistic_avatars.js?v=${targetCache}`,
            `js/api_client.js?v=${targetCache}`,
            `js/game3d.js?v=${targetCache}`,
            `js/clan_house3d.js?v=${targetCache}`,
            `js/clan_directory.js?v=${targetCache}`,
            `js/ota_client.js?v=${targetCache}`,
            `js/ui.js?v=${targetCache}`,
            `js/ui_events.js?v=${targetCache}`,
            `js/shop_showcase.js?v=${targetCache}`
        ];

        try {
            updateProgress(8, '🔍 กำลังตรวจสอบความพร้อมของเซิร์ฟเวอร์...', `เตรียมดาวน์โหลด ${targetSize} (${targetFiles})`);
            await new Promise(r => setTimeout(r, 150));

            const stepIncrement = 62 / Math.max(1, coreAssets.length);
            let currentPct = 15;

            for (let i = 0; i < coreAssets.length; i++) {
                const assetUrl = coreAssets[i];
                const fileName = assetUrl.split('/').pop().split('?')[0];

                currentPct += stepIncrement;
                updateProgress(
                    currentPct,
                    `📥 กำลังดาวน์โหลด: ${fileName} (${Math.round(currentPct)}%)`,
                    `ความคืบหน้า ${i + 1}/${coreAssets.length} ไฟล์ (${targetSize} • ${targetFiles})`
                );

                try {
                    await fetch(assetUrl, { cache: 'reload' }).catch(() => null);
                } catch (e) {}

                await new Promise(r => setTimeout(r, 35));
            }

            updateProgress(85, '⚙️ กำลังล้างแคชเก่าและติดตั้งทรัพยากรใหม่...', 'กำลังบันทึกเวอร์ชันล่าสุด...');

            if ('caches' in window) {
                try {
                    const cacheKeys = await window.caches.keys();
                    for (const key of cacheKeys) {
                        await window.caches.delete(key);
                    }
                } catch (e) {}
            }

            setLocalVersion(targetCache);
            updateProgress(100, '✅ อัปเดตเสร็จสมบูรณ์ 100%!', 'กำลังเข้าสู่เกมใหม่...');
            if (bar) bar.style.boxShadow = '0 0 25px #10b981';
            if (pctText) {
                pctText.style.color = '#10b981';
                pctText.innerText = '100%';
            }

            await new Promise(r => setTimeout(r, 350));

            const cleanUrl = window.location.href.split('?')[0].split('#')[0];
            window.location.replace(`${cleanUrl}?v=${targetCache}&t=${Date.now()}`);
        } catch (err) {
            console.error('OTA Update Error:', err);
            setLocalVersion(targetCache);
            const cleanUrl = window.location.href.split('?')[0].split('#')[0];
            window.location.replace(`${cleanUrl}?v=${targetCache}&t=${Date.now()}`);
        }
    }

    async function checkForUpdates(silent = true) {
        if (isUpdating || updateModalVisible) return;
        if (window.game && window.game.isMatchActive) return;

        // ห้ามขัดจังหวะหรือรีโหลดหน้าเว็บในขณะที่กำลังกลับมาจากหน้า OAuth Login (Google / LINE) เด็ดขาด
        const rawSearch = (window.location && window.location.search) ? window.location.search : '';
        const rawHash = (window.location && window.location.hash) ? window.location.hash : '';
        const isOAuthReturn = rawSearch.includes('code=')
            || rawSearch.includes('token=')
            || rawSearch.includes('auth_token=')
            || rawHash.includes('id_token=')
            || rawHash.includes('access_token=')
            || Boolean(window._oauthRedirectInProgress);
        if (isOAuthReturn) {
            return;
        }

        try {
            const currentLocal = getLocalVersion();
            const endpoint = getApiEndpoint();
            const res = await fetch(`${endpoint}?t=${Date.now()}`, {
                cache: 'no-store'
            }).then(r => r.json());

            if (!res || res.status !== 'success') return;

            // ซิงก์กระดาน AI 3D แบบ Real-time สำหรับ iOS / Android / Web เมื่อแอดมินเปิดใช้งานหรือยกเลิกกระดาน
            if (typeof res.default_ai_board !== 'undefined' && window.game && !window.game.isMatchActive) {
                try {
                    const srvBoard = res.default_ai_board;
                    const curBoard = window.game.activeCustomBoard;
                    if (srvBoard && srvBoard.id) {
                        const needApply = !curBoard ||
                            Number(curBoard.id) !== Number(srvBoard.id) ||
                            String(curBoard.updated_at || '') !== String(srvBoard.updated_at || '');
                        if (needApply && typeof window.game.applyCustomBoardConfig === 'function') {
                            window.game.applyCustomBoardConfig(srvBoard);
                            if (typeof window.fetchAndApplyActiveAiBoards === 'function') {
                                window.fetchAndApplyActiveAiBoards(false);
                            }
                        }
                    } else if (!srvBoard && curBoard && Number(curBoard.is_default) === 1) {
                        if (typeof window.game.cancelCustomBoardConfig === 'function') {
                            window.game.cancelCustomBoardConfig();
                            if (typeof window.fetchAndApplyActiveAiBoards === 'function') {
                                window.fetchAndApplyActiveAiBoards(false);
                            }
                        }
                    }
                } catch (boardSyncErr) {
                    console.warn('[SnakeOTA] AI Board sync warning:', boardSyncErr);
                }
            }

            if (!res.cache_version) return;

            const serverCache = String(res.cache_version).trim();
            const serverNum = Number(serverCache || 0);
            const localNum = Number(currentLocal || 0);

            // หากรอบนี้เพิ่งอัปเดตไปหมาดๆ ไม่แสดงซ้ำ
            if (isAppliedInCurrentSession(serverCache)) {
                setLocalVersion(serverCache);
                return;
            }

            // แจ้งเตือนเมื่อเซิร์ฟเวอร์มีเวอร์ชันใหม่กว่าที่เครื่องผู้เล่นติดตั้งไว้ (หรือยังไม่เคยติดตั้ง)
            if (serverNum > 0 && (localNum === 0 || serverNum > localNum)) {
                console.log(`[SnakeOTA] 🚀 New update detected! Server: ${serverCache}, Local: ${currentLocal}`);
                showGameUpdatePopup(res);
            } else if (serverNum > 0 && serverNum <= localNum) {
                setLocalVersion(String(localNum));
            }
        } catch (e) {
            if (!silent) console.warn('[SnakeOTA] Check error:', e);
        }
    }

    function initOtaSystem() {
        // ตรวจสอบทันทีที่เปิดแอป (300ms)
        setTimeout(() => {
            checkForUpdates(false);
        }, 300);

        // ตรวจสอบซ้ำอีกครั้งที่ 1.5 วินาที
        setTimeout(() => {
            checkForUpdates(true);
        }, 1500);

        // ตรวจสอบทุก 10 วินาที เพื่อให้แสดงผลทันทีหลังกด Deploy ใน Admin Panel
        setInterval(() => {
            checkForUpdates(true);
        }, OTA_CONFIG.checkIntervalMs);

        // เมื่อสลับกลับเข้ามาที่หน้าแอปเกมบนมือถือ
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                checkForUpdates(false);
            }
        });

        window.addEventListener('focus', () => {
            checkForUpdates(false);
        });

        window.addEventListener('pageshow', () => {
            checkForUpdates(false);
        });
    }

    window.SnakeOTA = {
        check: checkForUpdates,
        startUpdateProcess: startUpdateProcess,
        showPopup: showGameUpdatePopup,
        getLocalVersion: getLocalVersion
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initOtaSystem);
    } else {
        initOtaSystem();
    }
})();
