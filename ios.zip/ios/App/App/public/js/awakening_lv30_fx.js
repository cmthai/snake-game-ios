/**
 * Lv.29 -> Lv.30 MAX Awakening Confirmation & Cinematic Fusion Ceremony
 * Supports Card/Frame, 3D Dice, and Magic Gems
 */
(function (global) {
    'use strict';

    let styleInjected = false;
    function ensureStyles() {
        if (styleInjected || typeof document === 'undefined') return;
        styleInjected = true;
        const st = document.createElement('style');
        st.id = 'awakening-lv30-styles';
        st.textContent = `
            @keyframes awPulseRing {
                0%, 100% { transform: translate(-50%,-50%) scale(0.96) rotate(0deg); opacity: 0.78; }
                50% { transform: translate(-50%,-50%) scale(1.06) rotate(180deg); opacity: 1; }
            }
            @keyframes awReverseRing {
                0% { transform: translate(-50%,-50%) rotate(360deg); }
                100% { transform: translate(-50%,-50%) rotate(0deg); }
            }
            @keyframes awConicSpin {
                0% { transform: translate(-50%,-50%) rotate(0deg) scale(1); }
                50% { transform: translate(-50%,-50%) rotate(180deg) scale(1.08); }
                100% { transform: translate(-50%,-50%) rotate(360deg) scale(1); }
            }
            @keyframes awPrismAura {
                0% { filter: hue-rotate(0deg) brightness(1.05); }
                50% { filter: hue-rotate(180deg) brightness(1.25); }
                100% { filter: hue-rotate(360deg) brightness(1.05); }
            }
            @keyframes awCoreFloat {
                0%, 100% { transform: translateY(0px) scale(1); }
                50% { transform: translateY(-5px) scale(1.03); }
            }
            @keyframes awShimmerSweep {
                0% { transform: translateX(-140%) skewX(-22deg); }
                100% { transform: translateX(220%) skewX(-22deg); }
            }
            @keyframes awShockwave {
                0% { transform: translate(-50%,-50%) scale(0.3); opacity: 0.98; }
                100% { transform: translate(-50%,-50%) scale(2.45); opacity: 0; }
            }
            @keyframes awFloatSpark {
                0% { transform: translate(0, 0) scale(0.4); opacity: 0; }
                25% { opacity: 1; }
                100% { transform: translate(var(--sx, 0px), var(--sy, -95px)) scale(1.3); opacity: 0; }
            }
            @keyframes awRainbowText {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
            }
            @keyframes awConfettiFall {
                0% { transform: translateY(-20px) rotate(0deg) scale(1); opacity: 1; }
                100% { transform: translateY(340px) rotate(540deg) scale(0.75); opacity: 0; }
            }
            @keyframes awFlashBurst {
                0% { opacity: 0.9; transform: scale(0.6); }
                100% { opacity: 0; transform: scale(2.2); }
            }
            .aw-lv30-max-pill {
                background: linear-gradient(120deg, #fde047, #f97316, #ec4899, #a855f7, #38bdf8, #34d399, #fde047);
                background-size: 300% 300%;
                animation: awRainbowText 2s linear infinite;
                color: #020617;
                font-weight: 900;
                padding: 4px 16px;
                border-radius: 999px;
                border: 2px solid #fff;
                box-shadow: 0 0 24px rgba(253, 224, 71, 0.95), 0 0 38px rgba(236, 72, 153, 0.6);
                display: inline-block;
            }
            .aw-ceremony-card-box {
                position: relative;
                width: min(88vw, 340px);
                max-height: 86vh;
                overflow-y: auto;
                padding: 14px 16px;
                border-radius: 20px;
                border: 2px solid rgba(251, 191, 36, 0.72);
                background: radial-gradient(circle at 50% 42%, rgba(49, 46, 129, 0.78) 0%, rgba(15, 23, 42, 0.96) 58%, rgba(2, 6, 23, 0.98) 100%);
                box-shadow: 0 0 50px rgba(168, 85, 247, 0.42), 0 0 28px rgba(251, 191, 36, 0.35), 0 18px 45px rgba(0, 0, 0, 0.92);
                text-align: center;
                overflow-x: hidden;
            }
            .aw-fusion-stage {
                position: relative;
                width: 240px;
                height: 155px;
                margin: 2px auto;
            }
            .aw-aurora-disc {
                position: absolute;
                top: 50%;
                left: 50%;
                width: 150px;
                height: 150px;
                border-radius: 50%;
                background: conic-gradient(from 0deg, rgba(253,224,71,0.38), rgba(236,72,153,0.42), rgba(168,85,247,0.45), rgba(56,189,248,0.42), rgba(52,211,153,0.38), rgba(251,146,60,0.4), rgba(253,224,71,0.38));
                filter: blur(14px);
                animation: awConicSpin 6s linear infinite;
                pointer-events: none;
                z-index: 0;
                opacity: 0.78;
                transition: opacity 0.4s ease, transform 0.4s ease;
            }
            .aw-starburst-rays {
                position: absolute;
                top: 50%;
                left: 50%;
                width: 175px;
                height: 175px;
                border-radius: 50%;
                background: repeating-conic-gradient(from 0deg, rgba(255,255,255,0.18) 0deg 8deg, transparent 8deg 24deg);
                -webkit-mask-image: radial-gradient(circle, rgba(0,0,0,0.95) 18%, rgba(0,0,0,0.3) 55%, transparent 72%);
                mask-image: radial-gradient(circle, rgba(0,0,0,0.95) 18%, rgba(0,0,0,0.3) 55%, transparent 72%);
                animation: awConicSpin 10s linear infinite;
                pointer-events: none;
                z-index: 1;
                opacity: 0.35;
                transition: opacity 0.45s ease;
            }
            .aw-core-prism-frame {
                position: relative;
                width: 74px;
                height: 86px;
                border-radius: 15px;
                padding: 2.5px;
                background: linear-gradient(135deg, #fde047, #ec4899, #a855f7, #38bdf8, #34d399, #fde047);
                background-size: 300% 300%;
                animation: awRainbowText 2.4s linear infinite;
                box-shadow: 0 0 24px rgba(251, 191, 36, 0.7), 0 0 38px rgba(168, 85, 247, 0.45);
                transition: transform 0.35s cubic-bezier(0.22,1,0.36,1), box-shadow 0.35s ease;
            }
            .aw-core-inner {
                position: relative;
                width: 100%;
                height: 100%;
                border-radius: 15px;
                background: radial-gradient(circle at 50% 32%, rgba(99, 102, 241, 0.52) 0%, #090d16 82%);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                overflow: hidden;
            }
            .aw-core-shimmer {
                position: absolute;
                inset: 0;
                background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.45) 50%, transparent 100%);
                width: 55%;
                animation: awShimmerSweep 2.4s ease-in-out infinite;
                pointer-events: none;
            }
        `;
        document.head.appendChild(st);
    }

    const CARD_THEMES = {
        aurora_purple: { bg: 'linear-gradient(145deg,#3b0764,#1e1b4b,#020617)', border: '#c084fc', glow: 'rgba(192,132,252,0.75)', accent: '#e9d5ff' },
        solar_gold:    { bg: 'linear-gradient(145deg,#78350f,#451a03,#020617)', border: '#fbbf24', glow: 'rgba(251,191,36,0.8)',  accent: '#fde047' },
        crimson_flame: { bg: 'linear-gradient(145deg,#7f1d1d,#450a0a,#020617)', border: '#f43f5e', glow: 'rgba(244,63,94,0.8)',   accent: '#fda4af' },
        cyber_cyan:    { bg: 'linear-gradient(145deg,#0c4a6e,#082f49,#020617)', border: '#38bdf8', glow: 'rgba(56,189,248,0.8)',  accent: '#bae6fd' },
        emerald_jade:  { bg: 'linear-gradient(145deg,#064e3b,#022c22,#020617)', border: '#34d399', glow: 'rgba(52,211,153,0.75)', accent: '#a7f3d0' },
        cosmic_prism:  { bg: 'linear-gradient(145deg,#4c1d95,#831843,#0f172a)', border: '#f472b6', glow: 'rgba(244,114,182,0.8)', accent: '#fbcfe8' }
    };

    const ICON_MAP = {
        crown: '👑',
        star: '🌟',
        dragon: '🐉',
        crystal: '💎',
        phoenix: '🔥',
        lotus: '🪷',
        dice: '🎲'
    };

    function getAwakeningCardMeta(itemCat) {
        const cat = String(itemCat || 'card').toLowerCase();
        const cfgAll = (global.GAME_RULES && global.GAME_RULES.special_awakening_config) || {};
        const catCfg = cfgAll[cat] || {};
        const defaults = {
            dice: { code: 'SPECIAL_DICE_CARD', icon: '🎲', title: 'การ์ดเต๋าปลุกพลังพิเศษ S', color: '#38bdf8', theme: 'cyber_cyan', icon_style: 'dice' },
            gem:  { code: 'SPECIAL_GEM_CARD',  icon: '💎', title: 'การ์ดอัญมณีปลุกพลังพิเศษ S', color: '#fbbf24', theme: 'solar_gold', icon_style: 'crystal' },
            card: { code: 'SPECIAL_CARD',      icon: '👑', title: 'การ์ดกรอบปลุกพลังพิเศษ S', color: '#c084fc', theme: 'aurora_purple', icon_style: 'crown' }
        };
        const def = defaults[cat] || defaults.card;
        const themeObj = CARD_THEMES[catCfg.theme] || CARD_THEMES[def.theme] || CARD_THEMES.aurora_purple;
        const borderCol = catCfg.aura_color || themeObj.border || def.color;
        const iconChar = ICON_MAP[catCfg.icon_style] || def.icon;
        const endDate = catCfg.end_date || '';
        const startDate = catCfg.start_date || '';
        const isActive = catCfg.is_active === undefined ? true : Boolean(Number(catCfg.is_active));
        let isExpired = !isActive;
        if (!isExpired && endDate) {
            const parsed = Date.parse(String(endDate).replace(' ', 'T'));
            if (!isNaN(parsed) && Date.now() > parsed) isExpired = true;
        }
        return {
            cat,
            code: def.code,
            icon: iconChar,
            title: (catCfg.name && String(catCfg.name).trim()) ? String(catCfg.name).trim() : def.title,
            color: borderCol,
            themeObj,
            startDate,
            endDate,
            isActive,
            isExpired
        };
    }

    global.getSpecialAwakeningCardInfo = getAwakeningCardMeta;

    global.buildSpecialAwakeningCardHtml = function (itemCat, sizePx = 52) {
        const meta = getAwakeningCardMeta(itemCat);
        const w = Math.round(sizePx * 0.86);
        const h = Math.round(sizePx * 1.12);
        const iconSize = Math.max(18, Math.round(sizePx * 0.44));
        return `
            <div style="position:relative; width:${w}px; height:${h}px; border-radius:10px; border:1.8px solid ${meta.color}; background:${meta.themeObj.bg}; box-shadow:0 0 14px ${meta.color}99, inset 0 0 10px ${meta.color}44; display:flex; flex-direction:column; align-items:center; justify-content:center; flex-shrink:0; overflow:hidden;">
                <div style="position:absolute; inset:0; background:radial-gradient(circle at 50% 35%, ${meta.color}38, transparent 70%); pointer-events:none;"></div>
                <span style="position:relative; z-index:2; font-size:${iconSize}px; filter:drop-shadow(0 0 8px ${meta.color}); line-height:1;">${meta.icon}</span>
                <span style="position:absolute; top:2px; left:4px; z-index:3; font-size:${Math.max(8, Math.round(sizePx * 0.17))}px; font-weight:900; font-style:italic; color:#fde047; text-shadow:0 1px 2px #000, 0 0 6px ${meta.color};">S</span>
                <span style="position:relative; z-index:2; margin-top:2px; font-size:${Math.max(7, Math.round(sizePx * 0.14))}px; font-weight:900; color:${meta.themeObj.accent}; letter-spacing:0.3px;">MAX</span>
            </div>
        `;
    };

    function getOwnedAwakeningCount(code) {
        const mats = global.latestMaterialsMap || {};
        return Math.max(0, parseInt(mats[code], 10) || 0);
    }

    global.buildEventSpecialAwakeningBannerHtml = function (itemCat, ownedCountOverride = null) {
        const cat = String(itemCat || 'card').toLowerCase();
        const meta = getAwakeningCardMeta(cat);
        const cfgAll = (global.GAME_RULES && global.GAME_RULES.special_awakening_config) || {};
        const reqQty = Math.max(1, parseInt(cfgAll.req_qty, 10) || 5);
        const owned = (ownedCountOverride !== null && ownedCountOverride !== undefined)
            ? Math.max(0, parseInt(ownedCountOverride, 10) || 0)
            : getOwnedAwakeningCount(meta.code);
        const isReady = owned >= reqQty;
        const missing = Math.max(0, reqQty - owned);
        const inspectCat = cat === 'dice' ? 'DICE' : (cat === 'gem' ? 'GEM' : 'FRAME');
        const cardHtml = global.buildSpecialAwakeningCardHtml(cat, 40);

        return `
            <div onclick="if(typeof window.showShadowMaterialInspectModal==='function') window.showShadowMaterialInspectModal('${meta.code}', '${inspectCat}')"
                 title="คลิกดูรายละเอียด ${meta.title} (ใช้สำหรับปลุกพลัง Lv.29 ➜ Lv.30)"
                 style="margin-top:6px; padding:7px 10px; border-radius:11px; border:1px solid ${meta.isExpired ? 'rgba(239,68,68,0.45)' : meta.color + '88'}; background:linear-gradient(90deg, rgba(15,23,42,0.92), ${meta.color}18); display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; box-shadow:0 2px 10px rgba(0,0,0,0.35);">
                <div style="display:flex; align-items:center; gap:9px; min-width:0; flex:1;">
                    ${cardHtml}
                    <div style="min-width:0; flex:1;">
                        <div style="display:flex; align-items:center; gap:5px; flex-wrap:wrap;">
                            <span style="font-size:11.5px; font-weight:900; color:${meta.color}; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${meta.title}</span>
                            <span style="font-size:9px; font-weight:800; padding:1px 6px; border-radius:999px; background:${meta.isExpired ? 'rgba(239,68,68,0.25)' : 'rgba(251,191,36,0.18)'}; border:1px solid ${meta.isExpired ? 'rgba(239,68,68,0.55)' : 'rgba(251,191,36,0.5)'}; color:${meta.isExpired ? '#fca5a5' : '#fde047'};">
                                ${meta.isExpired ? '🛑 หมดเวลา' : '⚡ ปลุกพลัง Lv.30'}
                            </span>
                        </div>
                        <div style="font-size:10px; color:#cbd5e1; margin-top:2px;">
                            ใช้ปลุกพลัง Lv.29 ➜ Lv.30 MAX • ต้องการ <strong style="color:#fde047;">${reqQty} ใบ</strong>
                        </div>
                    </div>
                </div>
                <div style="text-align:right; flex-shrink:0;">
                    <div style="font-size:12px; font-weight:900; color:${isReady ? '#34d399' : '#f8fafc'}; padding:2px 8px; border-radius:8px; background:${isReady ? 'rgba(16,185,129,0.2)' : 'rgba(30,41,59,0.85)'}; border:1px solid ${isReady ? 'rgba(16,185,129,0.55)' : 'rgba(148,163,184,0.35)'};">
                        ${isReady ? '✓ ' : ''}${owned}/${reqQty} ใบ
                    </div>
                    <div style="font-size:9px; color:${isReady ? '#6ee7b7' : '#fbbf24'}; margin-top:2px; font-weight:700;">
                        ${isReady ? 'พร้อมปลุกพลัง!' : `ขาดอีก ${missing} ใบ`}
                    </div>
                </div>
            </div>
        `;
    };

    global.showAwakeningLv30ConfirmModal = async function (opts, onConfirm) {
        ensureStyles();
        const cat = opts?.itemCat || 'card';
        const meta = getAwakeningCardMeta(cat);
        const reqQty = Math.max(1, parseInt(opts?.reqQty, 10) || 5);
        const costDia = Math.max(0, parseInt(opts?.costDia, 10) || 500);
        const itemName = opts?.itemName || 'ไอเทม';
        const itemGrade = String(opts?.itemGrade || 'SS+').toUpperCase();

        // Refresh materials count if missing
        if (!global.latestMaterialsMap && global.apiClient) {
            try {
                const inv = await global.apiClient.getInventory();
                if (inv && inv.materials) global.latestMaterialsMap = inv.materials;
            } catch (e) {}
        }

        const ownedCards = getOwnedAwakeningCount(meta.code);
        const haveDia = Number((global.DEFAULT_USER && (global.DEFAULT_USER.diamond ?? global.DEFAULT_USER.diamonds)) || 0);
        const hasEnoughCards = ownedCards >= reqQty;
        const hasEnoughDia = haveDia >= costDia;
        const isCardValid = !meta.isExpired;
        const canProceed = hasEnoughCards && hasEnoughDia && isCardValid;
        const cardPreviewHtml = global.buildSpecialAwakeningCardHtml(cat, 50);

        let modal = document.getElementById('modal-awakening-lv30-confirm');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'modal-awakening-lv30-confirm';
            modal.className = 'modal-overlay';
            document.body.appendChild(modal);
        }
        modal.style.cssText = 'position:fixed; inset:0; z-index:100600; background:rgba(2,6,23,0.86); backdrop-filter:blur(7px); display:flex; align-items:center; justify-content:center; padding:14px;';
        modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };

        const remDia = Math.max(0, haveDia - costDia);
        modal.innerHTML = `
            <div onclick="event.stopPropagation()" style="width:min(94vw, 410px); background:linear-gradient(165deg,#1e1b4b 0%,#0f172a 55%,#020617 100%); border:2px solid #fbbf24; border-radius:20px; padding:18px; color:#fff; box-shadow:0 20px 55px rgba(0,0,0,0.9), 0 0 32px rgba(251,191,36,0.28); text-align:center;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <span style="font-size:14px; font-weight:900; color:#fde047;">⚡ พิธีปลุกพลังขั้นสูงสุด Lv.29 ➔ Lv.30</span>
                    <button type="button" onclick="document.getElementById('modal-awakening-lv30-confirm').style.display='none'" style="width:28px; height:28px; border-radius:50%; border:none; background:rgba(239,68,68,0.85); color:#fff; font-weight:900; cursor:pointer;">✕</button>
                </div>

                <div style="background:rgba(15,23,42,0.75); border:1px solid rgba(251,191,36,0.3); border-radius:14px; padding:12px; margin-bottom:12px;">
                    <div style="font-size:11px; color:#fbbf24; font-weight:800;">เป้าหมายปลุกพลัง MAX Lv.30</div>
                    <div style="font-size:16px; font-weight:900; color:#fff; margin-top:2px;">${itemName} <span style="color:#c084fc;">[${itemGrade}]</span></div>
                </div>

                <div style="font-size:12px; font-weight:800; color:#cbd5e1; text-align:left; margin-bottom:6px;">วัตถุดิบที่ใช้ในการปลุกพลัง:</div>

                <!-- Special Awakening Card S Requirement -->
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; background:rgba(30,41,59,0.75); border:1.5px solid ${(hasEnoughCards && isCardValid) ? '#10b981' : '#ef4444'}; border-radius:12px; padding:10px 12px; margin-bottom:8px;">
                    <div style="display:flex; align-items:center; gap:10px; text-align:left;">
                        ${cardPreviewHtml}
                        <div>
                            <div style="font-size:12.5px; font-weight:900; color:#fff;">${meta.title}</div>
                            <div style="font-size:11px; color:#94a3b8;">ต้องการ: <strong style="color:#fde047;">${reqQty} ใบ</strong></div>
                            ${meta.endDate ? `<div style="font-size:10px; color:${isCardValid ? '#7dd3fc' : '#f87171'};">📅 หมดเขต: ${meta.endDate.substring(0, 16)} ${isCardValid ? '' : '(หมดอายุแล้ว)'}</div>` : ''}
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:13px; font-weight:900; color:${hasEnoughCards ? '#34d399' : '#f87171'};">${ownedCards} / ${reqQty} ใบ</div>
                        <div style="font-size:10px; color:${(hasEnoughCards && isCardValid) ? '#6ee7b7' : '#fca5a5'};">${!isCardValid ? '⏰ กิจกรรมหมดเวลา' : (hasEnoughCards ? '✔ เพียงพอ' : '❌ การ์ดไม่พอ')}</div>
                    </div>
                </div>

                <!-- Diamond Requirement -->
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; background:rgba(30,41,59,0.75); border:1.5px solid ${hasEnoughDia ? '#38bdf8' : '#ef4444'}; border-radius:12px; padding:10px 12px; margin-bottom:12px;">
                    <div style="display:flex; align-items:center; gap:10px; text-align:left;">
                        <div style="width:44px; height:44px; border-radius:10px; border:1.5px solid #38bdf8; background:radial-gradient(circle, rgba(56,189,248,0.35) 0%, #050811 85%); display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">💎</div>
                        <div>
                            <div style="font-size:12.5px; font-weight:900; color:#fff;">เพชรปลุกพลัง</div>
                            <div style="font-size:11px; color:#94a3b8;">คงเหลือหลังอัป: <strong style="color:#7dd3fc;">${remDia.toLocaleString()} 💎</strong></div>
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:13px; font-weight:900; color:${hasEnoughDia ? '#38bdf8' : '#f87171'};">-${costDia.toLocaleString()} 💎</div>
                        <div style="font-size:10px; color:#94a3b8;">มีอยู่ ${haveDia.toLocaleString()} 💎</div>
                    </div>
                </div>

                ${!hasEnoughCards ? `
                    <button type="button" onclick="document.getElementById('modal-awakening-lv30-confirm').style.display='none'; if(typeof closeModal==='function') closeModal('modal-inventory'); if(typeof openModal==='function') openModal('modal-shop'); if(typeof window.selectShopMenu==='function') window.selectShopMenu('awakening_cards', 0);" style="width:100%; padding:9px; border-radius:10px; border:1px solid #fbbf24; background:rgba(245,158,11,0.22); color:#fde047; font-weight:900; font-size:12.5px; cursor:pointer; margin-bottom:8px;">
                        🛒 ไปซื้อการ์ดปลุกพลังพิเศษ S ที่ร้านค้า
                    </button>
                ` : ''}

                <div style="display:flex; gap:8px;">
                    <button type="button" onclick="document.getElementById('modal-awakening-lv30-confirm').style.display='none'" style="flex:1; padding:10px; border-radius:10px; border:1px solid rgba(148,163,184,0.4); background:rgba(15,23,42,0.8); color:#cbd5e1; font-weight:800; font-size:13px; cursor:pointer;">✕ ยกเลิก</button>
                    <button type="button" id="btn-aw-lv30-confirm" ${canProceed ? '' : 'disabled'} style="flex:1.6; padding:10px; border-radius:10px; border:none; background:${canProceed ? 'linear-gradient(135deg,#f59e0b,#eab308,#ec4899)' : '#334155'}; color:${canProceed ? '#000' : '#94a3b8'}; font-weight:900; font-size:13px; cursor:${canProceed ? 'pointer' : 'not-allowed'}; box-shadow:${canProceed ? '0 0 18px rgba(251,191,36,0.55)' : 'none'};">
                        ⚡ เริ่มปลุกพลัง Lv.30 MAX
                    </button>
                </div>
            </div>
        `;
        const confirmBtn = document.getElementById('btn-aw-lv30-confirm');
        if (confirmBtn && canProceed) {
            confirmBtn.onclick = () => {
                modal.style.display = 'none';
                if (typeof onConfirm === 'function') onConfirm();
            };
        }
        modal.style.display = 'flex';
    };

    global.playAwakeningLv30Ceremony = function (opts) {
        ensureStyles();
        const cat = opts?.itemCat || 'card';
        const meta = getAwakeningCardMeta(cat);
        const reqQty = Math.max(1, parseInt(opts?.reqQty, 10) || 5);
        const costDia = Math.max(0, parseInt(opts?.costDia, 10) || 500);
        const itemName = opts?.itemName || 'ไอเทม';
        const itemGrade = String(opts?.itemGrade || 'SS+').toUpperCase();

        let modal = document.getElementById('modal-awakening-lv30-ceremony');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'modal-awakening-lv30-ceremony';
            document.body.appendChild(modal);
        }
        if (Array.isArray(modal._awTimers)) {
            modal._awTimers.forEach(t => clearTimeout(t));
        }
        modal._awTimers = [];
        const schedule = (fn, ms) => {
            const id = setTimeout(fn, ms);
            modal._awTimers.push(id);
            return id;
        };

        modal.style.cssText = 'position:fixed; inset:0; z-index:999999; background:radial-gradient(circle at 50% 45%, rgba(30,27,75,0.96) 0%, rgba(2,6,23,0.98) 100%); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; padding:10px; overflow-y:auto;';

        const auraPalette = ['#fde047', '#ec4899', '#38bdf8', '#a855f7', '#34d399', '#fb923c'];
        const radiusX = 82;
        const radiusY = 56;

        const cardAngles = [];
        for (let i = 0; i < reqQty; i++) {
            const ang = (-Math.PI / 2) + (i * (2 * Math.PI / reqQty));
            cardAngles.push({
                x: Math.round(Math.cos(ang) * radiusX),
                y: Math.round(Math.sin(ang) * radiusY),
                rot: Math.round((ang * 180 / Math.PI) + 90),
                color: auraPalette[i % auraPalette.length]
            });
        }

        const cardsHtml = cardAngles.map((pos, idx) => `
            <div id="aw-fly-card-${idx}" style="position:absolute; top:50%; left:50%; width:36px; height:46px; margin-left:-18px; margin-top:-23px; transform:translate(${pos.x}px, ${pos.y}px) rotate(${pos.rot * 0.12}deg) scale(1); border-radius:8px; border:1.8px solid ${pos.color}; background:${meta.themeObj.bg}; box-shadow:0 0 14px ${pos.color}cc, inset 0 0 8px ${pos.color}55; display:flex; flex-direction:column; align-items:center; justify-content:center; transition:transform 0.58s cubic-bezier(0.22,1,0.36,1), opacity 0.45s ease; z-index:6; overflow:hidden;">
                <div style="position:absolute; inset:0; background:radial-gradient(circle at 50% 30%, ${pos.color}44, transparent 70%); pointer-events:none;"></div>
                <span style="position:relative; z-index:2; font-size:16px; filter:drop-shadow(0 0 6px ${pos.color});">${meta.icon}</span>
                <span style="position:relative; z-index:2; font-size:7.5px; font-weight:900; color:#fde047; text-shadow:0 1px 2px #000;">S</span>
            </div>
        `).join('');

        const diaPositions = [
            { x: -radiusX - 6, y: -34 }, { x: radiusX + 6, y: -34 }, { x: -radiusX, y: 40 }, { x: radiusX, y: 40 }
        ];
        const diaHtml = diaPositions.map((pos, idx) => `
            <div id="aw-fly-dia-${idx}" style="position:absolute; top:50%; left:50%; width:30px; height:30px; margin-left:-15px; margin-top:-15px; transform:translate(${pos.x}px, ${pos.y}px) scale(0.85); opacity:0; border-radius:50%; border:1.8px solid #38bdf8; background:radial-gradient(circle, rgba(56,189,248,0.55), #020617); box-shadow:0 0 16px #38bdf8, 0 0 26px #a855f7; display:flex; align-items:center; justify-content:center; font-size:15px; transition:transform 0.58s cubic-bezier(0.22,1,0.36,1), opacity 0.35s ease; z-index:7;">💎</div>
        `).join('');

        modal.innerHTML = `
            <div class="aw-ceremony-card-box" onclick="event.stopPropagation()">
                <div id="aw-confetti-box" style="position:absolute; inset:0; pointer-events:none; overflow:hidden; z-index:20;"></div>
                <div id="aw-flash-overlay" style="position:absolute; inset:0; background:radial-gradient(circle, rgba(255,255,255,0.9), rgba(253,224,71,0.45), transparent 70%); opacity:0; pointer-events:none; z-index:19;"></div>

                <div id="aw-phase-title" style="font-size:13.5px; font-weight:900; color:#fde047; letter-spacing:0.3px; margin-bottom:2px; text-shadow:0 0 12px rgba(251,191,36,0.85);">
                    ⚡ กำลังเริ่มพิธีปลุกพลัง Lv.30 MAX...
                </div>
                <div id="aw-phase-sub" style="font-size:11px; color:#7dd3fc; font-weight:700; min-height:15px; margin-bottom:2px;">
                    หลอมรวม ${meta.title} (0/${reqQty} ใบ)
                </div>

                <!-- Fusion Stage -->
                <div id="aw-stage" class="aw-fusion-stage">
                    <div id="aw-aurora-disc" class="aw-aurora-disc"></div>
                    <div id="aw-starburst-rays" class="aw-starburst-rays"></div>
                    <div id="aw-magic-ring" style="position:absolute; top:50%; left:50%; width:130px; height:130px; border-radius:50%; border:2px dashed rgba(253,224,71,0.85); box-shadow:0 0 24px rgba(236,72,153,0.45), inset 0 0 20px rgba(56,189,248,0.45); animation:awPulseRing 3.2s linear infinite; z-index:2;"></div>
                    <div id="aw-inner-ring" style="position:absolute; top:50%; left:50%; width:104px; height:104px; border-radius:50%; border:2px solid rgba(56,189,248,0.65); border-top-color:#ec4899; border-bottom-color:#fde047; box-shadow:0 0 18px rgba(168,85,247,0.5); animation:awReverseRing 4s linear infinite; z-index:3;"></div>

                    <div id="aw-center-core" style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); z-index:5;">
                        <div id="aw-core-prism-frame" class="aw-core-prism-frame">
                            <div class="aw-core-inner">
                                <div class="aw-core-shimmer"></div>
                                <span style="position:relative; z-index:2; font-size:30px; filter:drop-shadow(0 0 10px ${meta.color}); line-height:1;">${meta.icon}</span>
                                <span style="position:relative; z-index:2; margin-top:3px; font-size:9.5px; font-weight:900; color:#fde047; letter-spacing:0.5px; text-shadow:0 1px 4px #000;">${itemGrade}</span>
                            </div>
                        </div>
                    </div>
                    ${cardsHtml}
                    ${diaHtml}
                </div>

                <div style="font-size:14.5px; font-weight:900; color:#fff; margin-top:2px; text-shadow:0 2px 8px rgba(0,0,0,0.8);">${itemName}</div>
                <div id="aw-result-badge" style="margin-top:5px; min-height:26px;">
                    <span style="font-size:11.5px; font-weight:800; color:#94a3b8;">Lv.29 ➔ กำลังปลุกพลัง...</span>
                </div>

                <button type="button" id="btn-aw-ceremony-close" style="display:none; margin-top:8px; padding:7px 22px; border-radius:10px; border:1.5px solid rgba(255,255,255,0.65); background:linear-gradient(135deg,#f59e0b,#eab308,#ec4899); color:#fff; text-shadow:0 1px 3px rgba(0,0,0,0.6); font-weight:900; font-size:12.5px; cursor:pointer; box-shadow:0 4px 18px rgba(236,72,153,0.55), 0 0 14px rgba(251,191,36,0.5);">
                    ✨ ยอดเยี่ยม! ปิดหน้าต่าง
                </button>
            </div>
        `;
        modal.style.display = 'flex';

        const closeModalFn = () => {
            if (Array.isArray(modal._awTimers)) {
                modal._awTimers.forEach(t => clearTimeout(t));
                modal._awTimers = [];
            }
            modal.style.display = 'none';
        };
        const closeBtn = document.getElementById('btn-aw-ceremony-close');
        if (closeBtn) closeBtn.onclick = closeModalFn;
        modal.onclick = (e) => {
            if (e.target === modal && closeBtn && closeBtn.style.display !== 'none') {
                closeModalFn();
            }
        };

        const stageEl = document.getElementById('aw-stage');
        const coreFrameEl = document.getElementById('aw-core-prism-frame');
        const coreWrapEl = document.getElementById('aw-center-core');
        const auroraEl = document.getElementById('aw-aurora-disc');
        const raysEl = document.getElementById('aw-starburst-rays');
        const flashEl = document.getElementById('aw-flash-overlay');
        const subEl = document.getElementById('aw-phase-sub');
        const titleEl = document.getElementById('aw-phase-title');
        const badgeEl = document.getElementById('aw-result-badge');
        const confBox = document.getElementById('aw-confetti-box');

        const spawnShockwave = (color, borderW = 3) => {
            if (!stageEl) return;
            const sw = document.createElement('div');
            sw.style.cssText = `position:absolute; top:50%; left:50%; width:86px; height:86px; border-radius:50%; border:${borderW}px solid ${color}; box-shadow:0 0 24px ${color}, inset 0 0 12px ${color}; animation:awShockwave 0.72s ease-out forwards; pointer-events:none; z-index:8;`;
            stageEl.appendChild(sw);
            schedule(() => sw.remove(), 750);
        };

        const spawnSparks = (count, colors) => {
            if (!stageEl) return;
            for (let s = 0; s < count; s++) {
                const sp = document.createElement('span');
                const ang = Math.random() * Math.PI * 2;
                const dist = 55 + Math.random() * 85;
                const sx = Math.round(Math.cos(ang) * dist) + 'px';
                const sy = Math.round(Math.sin(ang) * dist) + 'px';
                const c = colors[s % colors.length];
                const sz = 4 + Math.round(Math.random() * 4);
                sp.style.cssText = `position:absolute; top:50%; left:50%; width:${sz}px; height:${sz}px; border-radius:50%; background:${c}; box-shadow:0 0 10px ${c}; --sx:${sx}; --sy:${sy}; animation:awFloatSpark 0.85s ease-out forwards; pointer-events:none; z-index:9;`;
                stageEl.appendChild(sp);
                schedule(() => sp.remove(), 900);
            }
        };

        // Phase 1: Merge cards one by one in colorful spiral burst
        for (let i = 0; i < reqQty; i++) {
            schedule(() => {
                const waveColor = auraPalette[i % auraPalette.length];
                const cEl = document.getElementById(`aw-fly-card-${i}`);
                if (cEl) {
                    cEl.style.transform = 'translate(0px, 0px) scale(0.18) rotate(360deg)';
                    cEl.style.opacity = '0';
                }
                if (subEl) subEl.textContent = `กำลังหลอมรวม ${meta.title} (${i + 1}/${reqQty} ใบ)...`;
                if (coreFrameEl) {
                    const glow = 28 + (i + 1) * 10;
                    coreFrameEl.style.transform = 'scale(1.14)';
                    coreFrameEl.style.boxShadow = `0 0 ${glow}px ${waveColor}, 0 0 ${glow + 22}px rgba(251,191,36,0.9)`;
                    schedule(() => { if (coreFrameEl) coreFrameEl.style.transform = 'scale(1)'; }, 220);
                }
                spawnShockwave(waveColor, 3);
                spawnSparks(7, auraPalette);
            }, 340 + i * 420);
        }

        // Phase 2: Merge diamonds
        const p2Start = 340 + reqQty * 420 + 180;
        schedule(() => {
            if (subEl) subEl.textContent = `กำลังผสานพลังเพชร -${costDia.toLocaleString()} 💎 เข้าสู่แกนพลัง...`;
            diaPositions.forEach((_, idx) => {
                const dEl = document.getElementById(`aw-fly-dia-${idx}`);
                if (dEl) {
                    dEl.style.opacity = '1';
                    schedule(() => {
                        dEl.style.transform = 'translate(0px, 0px) scale(0.18) rotate(240deg)';
                        dEl.style.opacity = '0';
                    }, 110 + idx * 110);
                }
            });
            schedule(() => {
                spawnShockwave('#38bdf8', 3.5);
                spawnShockwave('#a855f7', 2.5);
                spawnSparks(12, ['#38bdf8', '#a855f7', '#fde047', '#ec4899']);
            }, 360);
        }, p2Start);

        // Phase 3: Awakening MAX Lv.30 Celebration with multi-color aura!
        const p3Start = p2Start + 880;
        schedule(() => {
            if (flashEl) {
                flashEl.style.animation = 'awFlashBurst 0.65s ease-out forwards';
            }
            spawnShockwave('#fde047', 4);
            schedule(() => spawnShockwave('#ec4899', 3.5), 140);
            schedule(() => spawnShockwave('#38bdf8', 3.5), 280);
            schedule(() => spawnShockwave('#34d399', 3), 420);
            spawnSparks(22, auraPalette);

            if (auroraEl) {
                auroraEl.style.opacity = '1';
                auroraEl.style.transform = 'translate(-50%,-50%) scale(1.18)';
            }
            if (raysEl) {
                raysEl.style.opacity = '0.88';
            }
            if (coreWrapEl) {
                coreWrapEl.style.animation = 'awCoreFloat 2.4s ease-in-out infinite';
            }
            if (coreFrameEl) {
                coreFrameEl.style.transform = 'scale(1.12)';
                coreFrameEl.style.boxShadow = '0 0 36px #fde047, 0 0 64px #ec4899, 0 0 92px #38bdf8, 0 0 118px #a855f7';
                coreFrameEl.style.animation = 'awRainbowText 2s linear infinite, awPrismAura 4s linear infinite';
            }
            if (titleEl) titleEl.innerHTML = '🎉 ยินดีด้วย! ปลุกพลัง Lv.30 MAX สำเร็จ!';
            if (subEl) subEl.innerHTML = '<span style="color:#6ee7b7;">พลังและออร่าทะลุขีดจำกัดสูงสุดแล้ว! ✨</span>';
            if (badgeEl) badgeEl.innerHTML = '<span class="aw-lv30-max-pill">👑 Lv.30 MAX</span>';
            if (closeBtn) closeBtn.style.display = 'inline-block';

            if (confBox) {
                for (let k = 0; k < 36; k++) {
                    const p = document.createElement('span');
                    const left = Math.random() * 100;
                    const delay = (Math.random() * 0.65).toFixed(2);
                    const dur = (1.6 + Math.random() * 1.3).toFixed(2);
                    const c = auraPalette[k % auraPalette.length];
                    const isOrb = k % 3 === 0;
                    p.style.cssText = `position:absolute; left:${left}%; top:-12px; width:${isOrb ? 7 : 8}px; height:${isOrb ? 7 : 12}px; background:${c}; border-radius:${isOrb ? '50%' : '2px'}; box-shadow:0 0 8px ${c}; animation:awConfettiFall ${dur}s ease-out ${delay}s forwards;`;
                    confBox.appendChild(p);
                }
            }
        }, p3Start);
    };
})(typeof window !== 'undefined' ? window : globalThis);

