/**
 * Showcase Background FX Engine (Shared by Game & Admin Panel)
 * Renders uploaded background images with AI-selected animated effects
 * (fireflies, twinkling stars, meteors, sakura, aurora, flying birds, bubbles, etc.)
 */
(function (global) {
    'use strict';

    const EFFECTS = [
        { key: 'fireflies_forest', label: '✨ หิ่งห้อยเรืองแสงในป่าเวทมนตร์ (เยอะจัดเต็ม)', icon: '✨', defaultTint: '#a3e635' },
        { key: 'fireflies_stars', label: '🌟 หิ่งห้อย + ดาวระยิบระยับ & แสงโบเก้', icon: '🌟', defaultTint: '#fde047' },
        { key: 'starfield_meteor', label: '🌠 ดาวระยิบระยับ & ดาวตกพาดผ่าน', icon: '🌠', defaultTint: '#818cf8' },
        { key: 'sky_clouds_birds', label: '🕊️ ฝูงนกบิน & ละอองแสงนภา (ไม่มีเมฆ)', icon: '🕊️', defaultTint: '#38bdf8' },
        { key: 'sakura_petals', label: '🌸 กลีบซากุระปลิวไสว + ละอองชมพู', icon: '🌸', defaultTint: '#f472b6' },
        { key: 'aurora_waves', label: '🌌 แสงเหนือออโรร่า + ดาวระยิบ', icon: '🌌', defaultTint: '#2dd4bf' },
        { key: 'ocean_bubbles', label: '🫧 ฟองน้ำทะเล & ประกายแสงใต้น้ำ', icon: '🫧', defaultTint: '#06b6d4' },
        { key: 'golden_sparkles', label: '👑 ละอองทองจักรพรรดิ & ดาวประกาย', icon: '✨', defaultTint: '#fbbf24' },
        { key: 'neon_cyber_grid', label: '⚡ กริดไซเบอร์ & อนุภาคนีออน', icon: '⚡', defaultTint: '#c084fc' },
        { key: 'snowfall_winter', label: '❄️ หิมะโปรยปรายฤดูหนาว', icon: '❄️', defaultTint: '#bae6fd' },
        { key: 'dragon_embers', label: '🔥 ประกายไฟเถ้าถ่านเพลิงมังกร', icon: '🔥', defaultTint: '#f97316' },
        { key: 'none', label: '🖼️ ภาพพื้นหลังล้วน (ไม่มีเอฟเฟกต์)', icon: '🖼️', defaultTint: '#94a3b8' }
    ];

    let styleInjected = false;
    function ensureStyles() {
        if (styleInjected || typeof document === 'undefined') return;
        styleInjected = true;
        const st = document.createElement('style');
        st.id = 'showcase-bg-fx-styles';
        st.textContent = `
            .scbg-root {
                position: absolute;
                inset: 0;
                overflow: hidden;
                border-radius: inherit;
                pointer-events: none;
                z-index: 0;
            }
            .scbg-img {
                position: absolute;
                inset: 0;
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                transform: scale(1.03);
            }
            .scbg-scrim {
                position: absolute;
                inset: 0;
                background: radial-gradient(circle at 50% 45%, rgba(2,6,23,0.18) 0%, rgba(2,6,23,0.62) 100%);
            }
            .scbg-fx-layer {
                position: absolute;
                inset: 0;
                overflow: hidden;
                pointer-events: none;
            }
            @keyframes scbgBirdFly {
                0% { transform: translate(-15%, 18px) scale(0.85); opacity: 0; }
                12% { opacity: 0.95; }
                50% { transform: translate(50%, -14px) scale(1); }
                88% { opacity: 0.95; }
                100% { transform: translate(118%, -26px) scale(0.8); opacity: 0; }
            }
            @keyframes scbgBirdWing {
                0%, 100% { transform: scaleY(1); }
                50% { transform: scaleY(-0.65); }
            }
            @keyframes scbgTwinkle {
                0%, 100% { opacity: 0.25; transform: scale(0.75); }
                50% { opacity: 1; transform: scale(1.3); }
            }
            @keyframes scbgFloatUp {
                0% { transform: translateY(15px) translateX(0px) scale(0.7); opacity: 0; }
                20% { opacity: 0.95; }
                80% { opacity: 0.85; }
                100% { transform: translateY(-130px) translateX(var(--dx, 18px)) scale(1.15); opacity: 0; }
            }
            @keyframes scbgFireflyDrift {
                0%, 100% { transform: translate(0px, 0px) scale(0.85); opacity: 0.25; }
                30% { transform: translate(var(--dx, 24px), var(--dy, -20px)) scale(1.25); opacity: 1; }
                65% { transform: translate(calc(var(--dx, 24px) * -0.6), calc(var(--dy, -20px) * 0.7)) scale(0.95); opacity: 0.7; }
            }
            @keyframes scbgMeteor {
                0% { transform: translate(0, 0) rotate(-32deg) scaleX(0.4); opacity: 0; }
                15% { opacity: 1; }
                75% { opacity: 0.85; }
                100% { transform: translate(-240px, 160px) rotate(-32deg) scaleX(1.1); opacity: 0; }
            }
            @keyframes scbgPetalFall {
                0% { transform: translateY(-20px) translateX(0px) rotate(0deg); opacity: 0; }
                15% { opacity: 0.95; }
                85% { opacity: 0.85; }
                100% { transform: translateY(115vh) translateX(var(--dx, 45px)) rotate(320deg); opacity: 0; }
            }
            @keyframes scbgAuroraWave {
                0%, 100% { transform: translateX(-8%) skewY(-3deg) scaleY(1); opacity: 0.45; }
                50% { transform: translateX(8%) skewY(3deg) scaleY(1.18); opacity: 0.75; }
            }
            @keyframes scbgCyberPulse {
                0%, 100% { opacity: 0.22; }
                50% { opacity: 0.5; }
            }
        `;
        document.head.appendChild(st);
    }

    function rand(min, max) {
        return min + Math.random() * (max - min);
    }

    function buildFxHtml(effectType, intensity = 100, tintColor = '#38bdf8') {
        const type = String(effectType || 'none');
        if (type === 'none') return '';
        const mult = Math.max(0.4, Math.min(2, (Number(intensity) || 100) / 100));
        const count = (base) => Math.max(4, Math.round(base * mult));
        let html = '';

        if (type === 'fireflies_forest' || type === 'fireflies_stars') {
            const n = count(type === 'fireflies_forest' ? 28 : 18);
            const col = tintColor || (type === 'fireflies_forest' ? '#a3e635' : '#fde047');
            for (let i = 0; i < n; i++) {
                const sz = rand(3, 7).toFixed(1);
                const x = rand(2, 97).toFixed(1);
                const y = rand(5, 95).toFixed(1);
                const dx = rand(-32, 32).toFixed(0) + 'px';
                const dy = rand(-28, 28).toFixed(0) + 'px';
                const dur = rand(3.2, 6.4).toFixed(2);
                const del = rand(0, 3.5).toFixed(2);
                html += `<span style="position:absolute; left:${x}%; top:${y}%; width:${sz}px; height:${sz}px; border-radius:50%; background:${col}; box-shadow:0 0 10px ${col}, 0 0 20px ${col}; --dx:${dx}; --dy:${dy}; animation:scbgFireflyDrift ${dur}s ease-in-out ${del}s infinite;"></span>`;
            }
        }

        if (type === 'starfield_meteor' || type === 'fireflies_stars' || type === 'aurora_waves') {
            const sn = count(type === 'starfield_meteor' ? 36 : 22);
            for (let i = 0; i < sn; i++) {
                const sz = rand(1.5, 3.8).toFixed(1);
                const x = rand(2, 98).toFixed(1);
                const y = rand(2, 96).toFixed(1);
                const dur = rand(1.8, 4.2).toFixed(2);
                const del = rand(0, 3).toFixed(2);
                html += `<span style="position:absolute; left:${x}%; top:${y}%; width:${sz}px; height:${sz}px; border-radius:50%; background:#ffffff; box-shadow:0 0 8px #fff, 0 0 14px ${tintColor || '#818cf8'}; animation:scbgTwinkle ${dur}s ease-in-out ${del}s infinite;"></span>`;
            }
        }

        if (type === 'starfield_meteor') {
            const mn = count(4);
            for (let i = 0; i < mn; i++) {
                const x = rand(40, 96).toFixed(1);
                const y = rand(4, 42).toFixed(1);
                const dur = rand(2.2, 4.0).toFixed(2);
                const del = rand(0, 5.5).toFixed(2);
                html += `<span style="position:absolute; left:${x}%; top:${y}%; width:75px; height:2px; border-radius:999px; background:linear-gradient(90deg, #ffffff, ${tintColor || '#818cf8'}, transparent); box-shadow:0 0 10px #fff; animation:scbgMeteor ${dur}s linear ${del}s infinite;"></span>`;
            }
        }

        if (type === 'aurora_waves') {
            const col = tintColor || '#2dd4bf';
            html += `<div style="position:absolute; left:-15%; right:-15%; top:-10%; height:58%; background:radial-gradient(ellipse at 35% 40%, ${col}44, transparent 60%), radial-gradient(ellipse at 70% 50%, #a855f744, transparent 62%); filter:blur(26px); animation:scbgAuroraWave 8s ease-in-out infinite;"></div>`;
        }

        if (type === 'sky_clouds_birds') {
            const bn = count(6);
            for (let i = 0; i < bn; i++) {
                const y = rand(12, 62).toFixed(1);
                const dur = rand(8, 14).toFixed(2);
                const del = rand(0, 7).toFixed(2);
                html += `<span style="position:absolute; left:0; top:${y}%; font-size:${rand(13, 20).toFixed(0)}px; filter:drop-shadow(0 2px 4px rgba(0,0,0,0.45)); animation:scbgBirdFly ${dur}s linear ${del}s infinite;"><span style="display:inline-block; animation:scbgBirdWing 0.55s ease-in-out infinite;">🕊️</span></span>`;
            }
        }

        if (type === 'sakura_petals' || type === 'snowfall_winter') {
            const pn = count(22);
            const isSnow = type === 'snowfall_winter';
            for (let i = 0; i < pn; i++) {
                const x = rand(2, 98).toFixed(1);
                const dx = rand(-55, 55).toFixed(0) + 'px';
                const dur = rand(5.5, 10.5).toFixed(2);
                const del = rand(0, 6).toFixed(2);
                if (isSnow) {
                    const sz = rand(3, 7).toFixed(1);
                    html += `<span style="position:absolute; left:${x}%; top:-12px; width:${sz}px; height:${sz}px; border-radius:50%; background:#ffffff; box-shadow:0 0 8px #bae6fd; --dx:${dx}; animation:scbgPetalFall ${dur}s linear ${del}s infinite;"></span>`;
                } else {
                    const sz = rand(7, 12).toFixed(1);
                    html += `<span style="position:absolute; left:${x}%; top:-14px; width:${sz}px; height:${(sz * 0.68).toFixed(1)}px; border-radius:70% 15% 70% 15%; background:linear-gradient(135deg, #fbcfe8, #f472b6); box-shadow:0 0 8px rgba(244,114,182,0.55); --dx:${dx}; animation:scbgPetalFall ${dur}s linear ${del}s infinite;"></span>`;
                }
            }
        }

        if (type === 'ocean_bubbles' || type === 'golden_sparkles' || type === 'dragon_embers') {
            const un = count(24);
            const col = type === 'ocean_bubbles' ? '#38bdf8' : (type === 'dragon_embers' ? '#f97316' : '#fbbf24');
            for (let i = 0; i < un; i++) {
                const x = rand(3, 97).toFixed(1);
                const y = rand(35, 98).toFixed(1);
                const dx = rand(-28, 28).toFixed(0) + 'px';
                const dur = rand(2.8, 5.8).toFixed(2);
                const del = rand(0, 4).toFixed(2);
                const sz = type === 'ocean_bubbles' ? rand(5, 12).toFixed(1) : rand(3, 6.5).toFixed(1);
                const bg = type === 'ocean_bubbles' ? 'rgba(186,230,253,0.22)' : col;
                const bdr = type === 'ocean_bubbles' ? `1.5px solid rgba(186,230,253,0.7)` : 'none';
                html += `<span style="position:absolute; left:${x}%; top:${y}%; width:${sz}px; height:${sz}px; border-radius:50%; background:${bg}; border:${bdr}; box-shadow:0 0 10px ${col}; --dx:${dx}; animation:scbgFloatUp ${dur}s ease-out ${del}s infinite;"></span>`;
            }
        }

        if (type === 'neon_cyber_grid') {
            const col = tintColor || '#c084fc';
            html += `<div style="position:absolute; inset:0; background-image:linear-gradient(${col}26 1px, transparent 1px), linear-gradient(90deg, ${col}26 1px, transparent 1px); background-size:36px 36px; animation:scbgCyberPulse 3.6s ease-in-out infinite;"></div>`;
        }

        return html;
    }

    function render(containerEl, bgObj) {
        if (!containerEl) return;
        ensureStyles();
        const old = containerEl.querySelector(':scope > .scbg-root');
        if (old) old.remove();

        if (!bgObj || (!bgObj.image_url && (!bgObj.effect_type || bgObj.effect_type === 'none'))) {
            return;
        }

        const root = document.createElement('div');
        root.className = 'scbg-root';

        if (bgObj.image_url) {
            const imgDiv = document.createElement('div');
            imgDiv.className = 'scbg-img';
            imgDiv.style.backgroundImage = `url("${String(bgObj.image_url).replace(/"/g, '\\"')}")`;
            root.appendChild(imgDiv);

            const scrim = document.createElement('div');
            scrim.className = 'scbg-scrim';
            root.appendChild(scrim);
        }

        const fxHtml = buildFxHtml(bgObj.effect_type, bgObj.effect_intensity, bgObj.tint_color);
        if (fxHtml) {
            const fxLayer = document.createElement('div');
            fxLayer.className = 'scbg-fx-layer';
            fxLayer.innerHTML = fxHtml;
            root.appendChild(fxLayer);
        }

        containerEl.insertBefore(root, containerEl.firstChild);
    }

    function analyzeImageAndSuggest(imgDataUrl, existingNames = []) {
        const usedSet = new Set(
            (Array.isArray(existingNames) ? existingNames : [])
                .map(n => String(n || '').trim().toLowerCase())
                .filter(Boolean)
        );
        const pickUnique = (pool) => {
            const unused = pool.filter(n => !usedSet.has(n.trim().toLowerCase()));
            if (unused.length > 0) return unused[Math.floor(Math.random() * unused.length)];
            const base = pool[Math.floor(Math.random() * pool.length)] || 'ทิวทัศน์เวทมนตร์';
            let idx = 2;
            while (usedSet.has(`${base} ${idx}`.toLowerCase())) idx++;
            return `${base} ${idx}`;
        };
        const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

        return new Promise((resolve) => {
            const fallbackPool = [
                'ห้วงดาราจักรนิรันดร์', 'ทิวทัศน์เวทมนตร์เรืองแสง', 'ม่านหมอกแห่งความฝัน',
                'อาณาจักรประกายดาว', 'วิมานแสงสวรรค์', 'พงไพรประกายทอง'
            ];
            const fallback = () => resolve({
                effect_type: pickRandom(['fireflies_forest', 'fireflies_stars', 'starfield_meteor', 'golden_sparkles', 'aurora_waves', 'sakura_petals']),
                tint_color: '#a3e635',
                effect_intensity: 115 + Math.floor(Math.random() * 40),
                suggested_name: pickUnique(fallbackPool),
                suggested_desc: 'พื้นหลังเอฟเฟกต์พิเศษเคลื่อนไหวสวยงาม'
            });

            if (!imgDataUrl || typeof document === 'undefined') return fallback();
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                try {
                    const c = document.createElement('canvas');
                    c.width = 24;
                    c.height = 24;
                    const ctx = c.getContext('2d');
                    ctx.drawImage(img, 0, 0, 24, 24);
                    const data = ctx.getImageData(0, 0, 24, 24).data;
                    let rSum = 0, gSum = 0, bSum = 0;
                    const total = 24 * 24;
                    for (let y = 0; y < 24; y++) {
                        for (let x = 0; x < 24; x++) {
                            const idx = (y * 24 + x) * 4;
                            rSum += data[idx];
                            gSum += data[idx + 1];
                            bSum += data[idx + 2];
                        }
                    }
                    const r = rSum / total, g = gSum / total, b = bSum / total;
                    const brightness = (r + g + b) / 3;

                    let candidates = ['fireflies_stars'];
                    let tint = '#fde047';
                    let namePool = fallbackPool;
                    let desc = 'พื้นหลังเอฟเฟกต์พิเศษเคลื่อนไหวสวยงาม';

                    if (brightness < 45) {
                        candidates = ['starfield_meteor', 'aurora_waves', 'neon_cyber_grid'];
                        tint = '#818cf8';
                        namePool = ['ห้วงดาราจักรนิรันดร์', 'ราตรีดาราจักร', 'แสงเหนือแห่งห้วงฝัน'];
                        desc = 'ห้วงอวกาศและกาแล็กซีหมุนวนพร้อมแสงดาวระยิบระยับ';
                    } else if (brightness < 75) {
                        candidates = ['starfield_meteor', 'fireflies_stars', 'aurora_waves', 'neon_cyber_grid'];
                        tint = b > r ? '#818cf8' : '#c084fc';
                        namePool = ['ราตรีดาราจักร', 'แสงเหนือแห่งห้วงฝัน', 'หิ่งห้อยรัตติกาล', 'ม่านฟ้าประดับดาวตก'];
                        desc = 'ท้องฟ้ายามค่ำคืนพร้อมหมู่ดาวและแสงระยิบระยับ';
                    } else if (b > r + 20 && b >= g) {
                        candidates = ['fireflies_stars', 'sky_clouds_birds', 'ocean_bubbles', 'snowfall_winter'];
                        tint = '#38bdf8';
                        namePool = ['นภาครามประกายดาว', 'ปักษาวายุอิสระ', 'มหาสมุทรประกายแสง', 'ทะเลดาวสีน้ำเงิน'];
                        desc = 'โทนสีฟ้าสดใสพร้อมละอองแสงและเอฟเฟกต์เคลื่อนไหว';
                    } else if (r > b + 30 && g < 150) {
                        candidates = ['dragon_embers', 'golden_sparkles', 'sakura_petals'];
                        tint = '#f97316';
                        namePool = ['อัสดงเพลิงมังกร', 'ประกายทองมหาเวทย์', 'เปลวสุริยันเรืองรอง'];
                        desc = 'โทนสีเพลิงอบอุ่นพร้อมประกายแสงลอยละล่อง';
                    } else if (r > 170 && b > 140 && g < r - 15) {
                        candidates = ['sakura_petals', 'golden_sparkles', 'fireflies_stars'];
                        tint = '#f472b6';
                        namePool = ['สวนซากุระสวรรค์', 'ม่านหมอกพฤกษาชมพู', 'ซากุระต้องแสงจันทร์'];
                        desc = 'กลีบซากุระและละอองแสงสีชมพูพริ้วไหว';
                    } else if (g > r + 15 && g > b + 15) {
                        candidates = ['fireflies_forest', 'fireflies_stars', 'aurora_waves'];
                        tint = '#a3e635';
                        namePool = ['พงไพรหิ่งห้อยเวทมนตร์', 'ทุ่งหิ่งห้อย & ดาวระยิบ', 'พนาสีมรกต'];
                        desc = 'ธรรมชาติสีเขียวมรกตพร้อมฝูงหิ่งห้อยเรืองแสง';
                    } else {
                        candidates = ['fireflies_stars', 'golden_sparkles', 'starfield_meteor', 'snowfall_winter'];
                        tint = '#fbbf24';
                        namePool = ['วิมานทองคำสวรรค์', 'เหมันต์ประกายเพชร', 'ปราสาทแสงทอง'];
                        desc = 'ฉากแสงสีทองประกายระยิบระยับสุดอลังการ';
                    }

                    resolve({
                        effect_type: pickRandom(candidates),
                        tint_color: tint,
                        effect_intensity: 110 + Math.floor(Math.random() * 45),
                        suggested_name: pickUnique(namePool),
                        suggested_desc: desc
                    });
                } catch (e) {
                    fallback();
                }
            };
            img.onerror = fallback;
            img.src = imgDataUrl;
        });
    }

    const PREFS_KEY = 'snake_board_bg_prefs_v1';

    function getBoardBgPrefs() {
        const def = { showInLobby: true, showInMatch: true, hideLobbyBoard: true, transparentShowcaseCard: true, opacity: 38 };
        try {
            const raw = localStorage.getItem(PREFS_KEY);
            if (!raw) return def;
            const p = JSON.parse(raw);
            return {
                showInLobby: p.showInLobby !== false,
                showInMatch: p.showInMatch !== false,
                hideLobbyBoard: p.hideLobbyBoard !== undefined ? Boolean(p.hideLobbyBoard) : true,
                transparentShowcaseCard: p.transparentShowcaseCard !== undefined ? Boolean(p.transparentShowcaseCard) : true,
                opacity: Math.max(10, Math.min(100, parseInt(p.opacity, 10) || 38))
            };
        } catch (e) {
            return def;
        }
    }

    function saveBoardBgPrefs(next) {
        const cur = getBoardBgPrefs();
        const merged = {
            showInLobby: next && next.showInLobby !== undefined ? Boolean(next.showInLobby) : cur.showInLobby,
            showInMatch: next && next.showInMatch !== undefined ? Boolean(next.showInMatch) : cur.showInMatch,
            hideLobbyBoard: next && next.hideLobbyBoard !== undefined ? Boolean(next.hideLobbyBoard) : cur.hideLobbyBoard,
            transparentShowcaseCard: next && next.transparentShowcaseCard !== undefined ? Boolean(next.transparentShowcaseCard) : cur.transparentShowcaseCard,
            opacity: next && next.opacity !== undefined ? Math.max(10, Math.min(100, parseInt(next.opacity, 10) || 38)) : cur.opacity
        };
        try { localStorage.setItem(PREFS_KEY, JSON.stringify(merged)); } catch (e) {}
        applyGlobalBoardBackground();
        if (next && next.transparentShowcaseCard !== undefined) {
            const scEl = typeof document !== 'undefined' ? document.getElementById('lobby-equipped-showcase') : null;
            if (scEl && scEl.style.display !== 'none' && typeof global.showLobbyEquippedShowcase === 'function') {
                global.showLobbyEquippedShowcase();
            }
        }
        return merged;
    }

    const DEFAULT_FALLBACK_BG = {
        id: 0,
        name: 'Default Cosmic Starfield',
        image_url: '',
        effect_type: 'starfield_meteor',
        effect_intensity: 115,
        tint_color: '#38bdf8'
    };

    function applyGlobalBoardBackground() {
        if (typeof document === 'undefined') return;
        const bg = global.equippedShowcaseBackground || DEFAULT_FALLBACK_BG;
        const prefs = getBoardBgPrefs();
        const isMatch = Boolean((global.game && global.game.isMatchActive) || (document.body && document.body.classList.contains('in-match-fullscreen')));
        if (!isMatch && prefs.hideLobbyBoard) {
            document.body.classList.add('hide-lobby-board');
        } else {
            document.body.classList.remove('hide-lobby-board');
        }
        const shouldShow = Boolean(bg && ((isMatch && prefs.showInMatch) || (!isMatch && prefs.showInLobby)));

        let layer = document.getElementById('global-board-bg-layer');
        if (!layer && shouldShow) {
            layer = document.createElement('div');
            layer.id = 'global-board-bg-layer';
            layer.style.cssText = 'position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; background:#070b12;';
            const canvasCont = document.getElementById('canvas-container');
            if (canvasCont && canvasCont.parentNode) {
                canvasCont.parentNode.insertBefore(layer, canvasCont);
            } else {
                document.body.insertBefore(layer, document.body.firstChild);
            }
        }

        if (shouldShow && layer) {
            document.body.classList.add('has-board-bg');
            layer.style.display = 'block';
            render(layer, bg);
            const root = layer.querySelector(':scope > .scbg-root');
            if (root) {
                root.style.opacity = (prefs.opacity / 100).toFixed(2);
                root.style.transition = 'opacity 0.25s ease';
            }
            if (global.game && global.game.scene && global.game.renderer) {
                if (global.game.scene.background && !global.game._savedBgColor) {
                    global.game._savedBgColor = global.game.scene.background.clone();
                }
                global.game.scene.background = null;
                global.game.renderer.setClearColor(0x000000, 0);
            }
        } else {
            document.body.classList.remove('has-board-bg');
            if (layer) layer.style.display = 'none';
            if (global.game && global.game.scene && global.game.renderer) {
                const restoreCol = global.game._savedBgColor || (typeof THREE !== 'undefined' ? new THREE.Color(0x090d16) : null);
                if (restoreCol) {
                    global.game.scene.background = restoreCol;
                    global.game.renderer.setClearColor(restoreCol, 1.0);
                }
            }
        }
    }

    global.applyGlobalBoardBackground = applyGlobalBoardBackground;

    global.ShowcaseBgFX = {
        EFFECTS,
        render,
        buildFxHtml,
        analyzeImageAndSuggest,
        getBoardBgPrefs,
        saveBoardBgPrefs,
        applyGlobalBoardBackground
    };

    if (typeof document !== 'undefined') {
        const syncInitialLobbyBoardClass = () => {
            try {
                const prefs = getBoardBgPrefs();
                const isMatch = Boolean((global.game && global.game.isMatchActive) || (document.body && document.body.classList.contains('in-match-fullscreen')));
                if (!isMatch && prefs.hideLobbyBoard && document.body) {
                    document.body.classList.add('hide-lobby-board');
                }
            } catch (e) {}
        };
        if (document.body) syncInitialLobbyBoardClass();
        else document.addEventListener('DOMContentLoaded', syncInitialLobbyBoardClass);
    }
})(typeof window !== 'undefined' ? window : globalThis);