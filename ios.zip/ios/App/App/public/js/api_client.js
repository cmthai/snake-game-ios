/**
 * api_client.js - Client integration layer for Snake & Ladder 3D Backend APIs
 * Connects to PHP 8.4 backend on Nginx/1.31.6
 */

// Global fetch interceptor for Native Capacitor Local Bundle (capacitor://localhost -> https://pmix01.thddns.net:7175/home/snake/api/...)
(function () {
    if (typeof window === 'undefined' || typeof window.fetch !== 'function' || !window.location || window._snakeFetchPatched) return;
    const proto = window.location.protocol;
    const host = window.location.hostname;
    const port = window.location.port;
    if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
        window._snakeFetchPatched = true;
        const _origFetch = window.fetch.bind(window);
        const _remoteBase = 'https://pmix01.thddns.net:7175/home/snake/';
        window.fetch = function (input, init) {
            if (typeof input === 'string' && /^\/?api\//i.test(input)) {
                input = _remoteBase + input.replace(/^\/+/, '');
            } else if (typeof Request !== 'undefined' && input instanceof Request && /^capacitor:\/\/localhost\/api\//i.test(input.url)) {
                input = new Request(_remoteBase + input.url.replace(/^capacitor:\/\/localhost\//i, ''), input);
            }
            return _origFetch(input, init);
        };
    }
})();

class SnakeApiClient {
    constructor(baseUrl = '') {
        if (!baseUrl && typeof window !== 'undefined' && window.location) {
            const proto = window.location.protocol;
            const host = window.location.hostname;
            const port = window.location.port;
            if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
                baseUrl = 'https://pmix01.thddns.net:7175/home/snake/';
            }
        }
        this.baseUrl = baseUrl;
        this.token = this.resolveToken();
        try {
            this.user = JSON.parse(localStorage.getItem('snake_user_data') || 'null');
        } catch (e) {
            this.user = null;
        }
    }

    resolveToken() {
        if (typeof window !== 'undefined' && window.__OAUTH_INSTANT_TOKEN__) {
            return String(window.__OAUTH_INSTANT_TOKEN__);
        }
        let t = localStorage.getItem('snake_auth_token') || localStorage.getItem('game_session_token');
        if (t) return t;
        try {
            const m = document.cookie.match(/(?:^|;\s*)snake_auth_token=([^;]+)/);
            if (m) return decodeURIComponent(m[1]);
        } catch (e) {}
        return '';
    }

    getToken() {
        if (!this.token) {
            this.token = this.resolveToken();
        }
        return this.token || '';
    }

    setToken(token) {
        this.token = token;
        localStorage.setItem('snake_auth_token', token);
        localStorage.setItem('game_session_token', token);
        try {
            if (token) {
                document.cookie = 'snake_auth_token=' + encodeURIComponent(token) + '; Max-Age=7776000; path=/; SameSite=Lax; Secure';
                document.cookie = 'snake_logged_out=; Max-Age=0; path=/';
            }
        } catch (e) {}
    }

    setAuth(token, user) {
        this.token = token;
        this.user = user;
        this.setToken(token);
        localStorage.setItem('snake_user_data', JSON.stringify(user));
    }

    clearAuth() {
        this.token = '';
        this.user = null;
        localStorage.removeItem('snake_auth_token');
        localStorage.removeItem('game_session_token');
        localStorage.removeItem('snake_user_data');
        try {
            document.cookie = 'snake_auth_token=; Max-Age=0; path=/;';
            document.cookie = 'snake_logged_out=1; Max-Age=31536000; path=/; SameSite=Lax';
        } catch (e) {}
    }

    async request(endpoint, options = {}) {
        if (!this.token) {
            this.token = this.resolveToken();
        }
        let url = this.baseUrl + endpoint;
        const method = (options.method || 'GET').toUpperCase();
        if (method === 'GET') {
            const sep = url.includes('?') ? '&' : '?';
            url += sep + '_t=' + Date.now();
        }
        if (this.token && !url.includes('token=')) {
            const sep = url.includes('?') ? '&' : '?';
            url += sep + 'token=' + encodeURIComponent(this.token);
        }
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            ...(this.token ? { 'Authorization': 'Bearer ' + this.token } : {}),
            ...(options.headers || {})
        };

        try {
            const res = await fetch(url, { ...options, headers, cache: 'no-store' });
            let data;
            try {
                data = await res.json();
            } catch (jsonErr) {
                const text = await res.text().catch(() => '');
                console.warn('API non-JSON response from ' + endpoint + ':', text);
                throw new Error('Invalid JSON response');
            }
            if (!res.ok && data && data.status !== 'error') {
                throw new Error(data.message || `HTTP ${res.status}`);
            }
            return data;
        } catch (err) {
            console.warn(`API Request Error [${endpoint}]:`, err);
            throw err;
        }
    }

    // --- Auth & Profile ---
    async loginByUsername(username) {
        return await this.request('api/auth.php?action=login_by_username', {
            method: 'POST',
            body: JSON.stringify({ username })
        });
    }

    async registerProfile(payload) {
        return await this.request('api/auth.php?action=register_profile', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async loginWithLine(payload) {
        return await this.request('api/auth.php?action=login_line', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async loginWithGoogle(payload) {
        return await this.request('api/auth.php?action=login_google', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async loginWithApple(payload) {
        return await this.request('api/auth.php?action=apple_login', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async getProfile() {
        return await this.request('api/auth.php?action=profile');
    }

    async syncProgress(payload = {}) {
        return await this.request('api/auth.php?action=sync_progress', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async inviteFriend(payload = {}) {
        return await this.request('api/auth.php?action=invite_friend', {
            method: 'POST',
            body: JSON.stringify(payload || {})
        });
    }

    async deleteAccount() {
        return await this.request('api/auth.php?action=delete_account', {
            method: 'POST',
            body: JSON.stringify({})
        });
    }

    async checkLoginRequest(usernameOrId) {
        return await this.request('api/auth.php?action=check_login_request', {
            method: 'POST',
            body: JSON.stringify({ username: usernameOrId })
        });
    }

    async cancelLoginRequest(requestId) {
        return await this.request('api/auth.php?action=cancel_login_request', {
            method: 'POST',
            body: JSON.stringify({ request_id: requestId })
        });
    }

    async checkSessionStatus() {
        return await this.request('api/auth.php?action=check_session_status');
    }

    async respondLoginRequest(requestId, decision) {
        return await this.request('api/auth.php?action=respond_login_request', {
            method: 'POST',
            body: JSON.stringify({ request_id: requestId, decision })
        });
    }

    // --- Shop, Inventory & Upgrades ---
    async getCatalog() {
        return await this.request('api/shop.php?action=get_catalog');
    }

    async buyItem(itemType, itemId, currency = 'DIAMOND') {
        return await this.request('api/shop.php?action=buy_item', {
            method: 'POST',
            body: JSON.stringify({ item_type: itemType, item_id: itemId, currency })
        });
    }

    async buyShopCustomItem(itemId) {
        return await this.request('api/shop.php?action=buy_shop_custom_item', {
            method: 'POST',
            body: JSON.stringify({ item_id: itemId })
        });
    }

    async equipItem(inventoryId) {
        return await this.request('api/shop.php?action=equip_item', {
            method: 'POST',
            body: JSON.stringify({ inventory_id: inventoryId })
        });
    }

    async upgradeCard(inventoryId, targetLevel = null) {
        const payload = { inventory_id: inventoryId };
        if (targetLevel !== null && targetLevel !== undefined) {
            payload.target_level = Number(targetLevel);
        }
        return await this.request('api/shop.php?action=upgrade_card', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    }

    async getInventory() {
        return await this.request('api/shop.php?action=inventory');
    }

    async getMailbox() {
        return await this.request('api/shop.php?action=mailbox');
    }

    async claimMail(mailId) {
        return await this.request('api/shop.php?action=claim_mail', {
            method: 'POST',
            body: JSON.stringify({ mail_id: mailId })
        });
    }

    async redeemPromoCode(code) {
        return await this.request('api/shop.php?action=redeem_code', {
            method: 'POST',
            body: JSON.stringify({ promo_code: code })
        });
    }

    async topupPurchase(packageId) {
        return await this.request('api/shop.php?action=topup_purchase', {
            method: 'POST',
            body: JSON.stringify({ package_id: packageId })
        });
    }

    async createPaymentOrder(packageId, method = 'promptpay') {
        return await this.request('api/shop.php?action=create_payment_order', {
            method: 'POST',
            body: JSON.stringify({ package_id: packageId, method })
        });
    }

    async checkPaymentStatus(orderNo, subAction = 'check') {
        return await this.request(`api/shop.php?action=check_payment_status&order_no=${encodeURIComponent(orderNo)}&sub=${encodeURIComponent(subAction)}`, {
            method: 'POST',
            body: JSON.stringify({ order_no: orderNo, sub_action: subAction })
        });
    }

    // --- Gacha & Events ---
    async gachaRoll(count = 1) {
        return await this.request('api/shop.php?action=gacha_roll', {
            method: 'POST',
            body: JSON.stringify({ count })
        });
    }

    async exchangeSPlusCard(characterId = 0, tierGrade = 'SS+') {
        return await this.request('api/shop.php?action=exchange_splus_card', {
            method: 'POST',
            body: JSON.stringify({ character_id: characterId, tier_grade: tierGrade })
        });
    }

    async exchangeDiceFromShadows(diceId = 0) {
        return await this.request('api/shop.php?action=exchange_dice_from_shadows', {
            method: 'POST',
            body: JSON.stringify({ dice_id: diceId })
        });
    }

    async getActiveEventGacha(category = 'ALL') {
        return await this.request(`api/shop.php?action=get_active_event_gacha&category=${encodeURIComponent(category)}`);
    }

    async rollEventGacha(count = 1, category = 'FRAME', currency = 'DIAMOND', packTier = 'SPECIAL') {
        return await this.request('api/shop.php?action=roll_event_gacha', {
            method: 'POST',
            body: JSON.stringify({ count, category, currency, pack_tier: packTier })
        });
    }

    // --- Magic Cubes ---
    async getUserCubes() {
        return await this.request('api/shop.php?action=get_user_cubes');
    }

    async equipCubeToSlot(userCubeId, slotIndex) {
        return await this.request('api/shop.php?action=equip_cube_to_slot', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId, slot_index: slotIndex })
        });
    }

    async removeCubeFromSlot(userCubeId) {
        return await this.request('api/shop.php?action=remove_cube_from_slot', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }

    async startSpinCube(userCubeId, currency = 'DIAMOND', slotIndex = 0) {
        return await this.request('api/shop.php?action=start_spin_cube', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId, currency, slot_index: slotIndex })
        });
    }

    async speedupCube(userCubeId) {
        return await this.request('api/shop.php?action=speedup_cube', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }

    async claimCubeReward(userCubeId) {
        return await this.request('api/shop.php?action=claim_cube_reward', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }

    // --- Leaderboard ---
    async getLeaderboard(type = 'all') {
        return await this.request(`api/leaderboard.php?type=${encodeURIComponent(type)}`);
    }

    // --- Matchmaking & Rooms ---
    async getRoomConfigs() {
        return await this.request('api/matchmaking.php?action=get_room_configs');
    }

    async createRoom(roomTier = '2M', mode = '2P', boardTheme = 'monopoly_thailand', isFriendRoom = false) {
        return await this.request('api/matchmaking.php?action=create_room', {
            method: 'POST',
            body: JSON.stringify({ room_tier: roomTier, mode, board_theme: boardTheme, is_friend_room: isFriendRoom })
        });
    }

    async joinRoomByCode(roomCode) {
        return await this.request('api/matchmaking.php?action=join_room_by_code', {
            method: 'POST',
            body: JSON.stringify({ room_code: roomCode })
        });
    }

    async startFriendRoom(roomId) {
        return await this.request('api/matchmaking.php?action=start_friend_room', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId })
        });
    }

    async leaveFriendRoom(roomId) {
        return await this.request('api/matchmaking.php?action=leave_friend_room', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId })
        });
    }

    async quickMatch(roomTier = '2M', mode = '2P', boardTheme = 'monopoly_thailand') {
        return await this.request('api/matchmaking.php?action=quick_match', {
            method: 'POST',
            body: JSON.stringify({ room_tier: roomTier, mode, board_theme: boardTheme })
        });
    }

    async checkRoomStatus(roomId) {
        return await this.request(`api/matchmaking.php?action=check_room_status&room_id=${encodeURIComponent(roomId)}`);
    }

    async triggerFastMatch(roomId) {
        return await this.request('api/matchmaking.php?action=fast_match', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId })
        });
    }

    async selectTurnCard(roomId, cardIndex) {
        return await this.request('api/matchmaking.php?action=select_turn_card', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId, card_index: cardIndex })
        });
    }

    async finishMatch(roomId, winnerUserId, isWinnerBot = false) {
        return await this.request('api/matchmaking.php?action=finish_match', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId, winner_user_id: winnerUserId, is_winner_bot: isWinnerBot })
        });
    }
}

if (typeof window !== 'undefined') {
    window.SnakeApiClient = SnakeApiClient;
    window.apiClient = new SnakeApiClient();
}
