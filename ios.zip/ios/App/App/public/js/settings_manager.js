/**
 * js/settings_manager.js
 * Game Settings Manager (Graphics, Audio, Board, Speed, Gacha Speed, Cache & Account)
 */
(function () {
    'use strict';

    const STORAGE_KEY = 'snake_game_settings_v1';

    const DEFAULT_SETTINGS = {
        graphics: 'medium',
        sfxVol: 85,
        sfxMuted: false,
        bgmVol: 70,
        bgmMuted: false,
        voiceVol: 90,
        voiceMuted: false,
        walkSpeed: 1.0,
        boardBadges: true,
        haptic: true,
        showFps: false,
        gachaSpeedSec: 0.10,
        gachaFastOpen: true
    };

    function loadSettings() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                return Object.assign({}, DEFAULT_SETTINGS, JSON.parse(raw));
            }
        } catch (e) { }
        return Object.assign({}, DEFAULT_SETTINGS);
    }

    function persistSettings(cfg) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
        } catch (e) { }
    }

    let currentSettings = loadSettings();

    window.applyGraphicsQuality = function (quality) {
        const q = ['low', 'medium', 'high'].includes(String(quality).toLowerCase()) ? String(quality).toLowerCase() : 'medium';
        currentSettings.graphics = q;
        persistSettings(currentSettings);
        ['low', 'medium', 'high'].forEach(k => {
            const btn = document.getElementById('btn-gfx-' + k);
            if (btn) btn.classList.toggle('active', k === q);
        });
        try {
            if (window.game && typeof window.game.setGraphicsQuality === 'function') {
                window.game.setGraphicsQuality(q);
            }
        } catch (e) { }
    };

    window.setAudioVolume = function (channel, val, source) {
        const ch = String(channel || '').toLowerCase();
        const v = Math.max(0, Math.min(100, parseInt(val, 10) || 0));
        if (ch === 'sfx') currentSettings.sfxVol = v;
        if (ch === 'bgm') currentSettings.bgmVol = v;
        if (ch === 'voice') currentSettings.voiceVol = v;
        persistSettings(currentSettings);

        const slider = document.getElementById(`setting-${ch}-vol-slider`);
        const num = document.getElementById(`setting-${ch}-vol-num`) || document.getElementById(`input-${ch}-vol`);
        if (slider && source !== 'slider') slider.value = v;
        if (num && source !== 'num') num.value = v;

        try {
            if (window.soundEngine) {
                if (ch === 'sfx' && typeof window.soundEngine.setSfxVolume === 'function') window.soundEngine.setSfxVolume(v / 100);
                if (ch === 'bgm' && typeof window.soundEngine.setBgmVolume === 'function') window.soundEngine.setBgmVolume(v / 100);
            }
            if (window.ThaiAudio) {
                if (ch === 'voice' && typeof window.ThaiAudio.setVoiceVolume === 'function') window.ThaiAudio.setVoiceVolume(v / 100);
                if (ch === 'sfx' && typeof window.ThaiAudio.setSfxVolume === 'function') window.ThaiAudio.setSfxVolume(v / 100);
            }
        } catch (e) { }
    };

    window.setAudioMute = function (channel, isMuted) {
        const ch = String(channel || '').toLowerCase();
        const muted = Boolean(isMuted);
        if (ch === 'sfx') currentSettings.sfxMuted = muted;
        if (ch === 'bgm') currentSettings.bgmMuted = muted;
        if (ch === 'voice') currentSettings.voiceMuted = muted;
        persistSettings(currentSettings);

        const chk = document.getElementById(`setting-${ch}-mute-check`);
        if (chk) chk.checked = !muted;

        try {
            if (window.soundEngine) {
                if (ch === 'sfx' && typeof window.soundEngine.setSfxMuted === 'function') window.soundEngine.setSfxMuted(muted);
                if (ch === 'bgm' && typeof window.soundEngine.setBgmMuted === 'function') window.soundEngine.setBgmMuted(muted);
            }
            if (window.ThaiAudio) {
                if (ch === 'voice' && typeof window.ThaiAudio.setMuted === 'function') window.ThaiAudio.setMuted(muted);
                if (ch === 'sfx' && typeof window.ThaiAudio.toggleSfx === 'function') window.ThaiAudio.toggleSfx(!muted);
            }
        } catch (e) { }
    };

    window.setWalkSpeed = function (speed) {
        const s = Math.max(0.5, Math.min(3.0, parseFloat(speed) || 1.0));
        currentSettings.walkSpeed = s;
        persistSettings(currentSettings);
        document.querySelectorAll('[onclick*="setWalkSpeed"]').forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('onclick')?.includes(s.toFixed(1)));
        });
        try {
            if (window.game && typeof window.game.setWalkSpeed === 'function') {
                window.game.setWalkSpeed(s);
            }
        } catch (e) { }
    };

    window.toggleBoardBadgesSetting = function () {
        const chk = document.getElementById('setting-board-badges-check');
        const enabled = chk ? Boolean(chk.checked) : !currentSettings.boardBadges;
        currentSettings.boardBadges = enabled;
        persistSettings(currentSettings);
        try {
            if (window.game && typeof window.game.toggleHologramBadges === 'function') {
                window.game.toggleHologramBadges(enabled);
            }
        } catch (e) { }
    };

    window.toggleHapticSetting = function (enabled) {
        currentSettings.haptic = Boolean(enabled);
        persistSettings(currentSettings);
    };

    window.toggleFpsSetting = function (enabled) {
        currentSettings.showFps = Boolean(enabled);
        persistSettings(currentSettings);
        const fpsEl = document.getElementById('fps-counter') || document.getElementById('fps-badge');
        if (fpsEl) fpsEl.style.display = currentSettings.showFps ? 'block' : 'none';
    };

    window.setGachaRevealInterval = function (sec, source) {
        const val = Math.max(0, Math.min(2, parseFloat(sec) || 0));
        currentSettings.gachaSpeedSec = val;
        persistSettings(currentSettings);
        try {
            localStorage.setItem('snake_gacha_reveal_interval_sec', String(val));
        } catch (e) { }
        const slider = document.getElementById('setting-gacha-speed-slider');
        const num = document.getElementById('setting-gacha-speed-num');
        if (slider && source !== 'slider') slider.value = Math.round(val * 100);
        if (num && source !== 'num') num.value = val.toFixed(2);
    };

    window.getGachaRevealIntervalSec = function () {
        return Number(currentSettings.gachaSpeedSec ?? 0.10);
    };

    window.toggleGachaFastOpenSetting = function (enabled) {
        currentSettings.gachaFastOpen = Boolean(enabled);
        persistSettings(currentSettings);
    };

    window.isGachaFastOpenEnabled = function () {
        return currentSettings.gachaFastOpen !== false;
    };

    window.clearGameCacheAction = async function () {
        try {
            if ('caches' in window && typeof caches.keys === 'function') {
                const keys = await caches.keys();
                await Promise.all(keys.map(k => caches.delete(k)));
            }
        } catch (e) { }
        if (typeof window.showToast === 'function') {
            window.showToast('✨ ล้างแคชเรียบร้อย กำลังรีโหลดหน้าเกม...');
        }
        setTimeout(() => {
            try {
                const u = new URL(window.location.href);
                u.searchParams.set('clear_cache', String(Date.now()));
                window.location.replace(u.toString());
            } catch (e) {
                window.location.reload();
            }
        }, 450);
    };

    window.settingsDeleteAccountAction = function () {
        if (typeof window.closeGameSettingsModal === 'function') {
            window.closeGameSettingsModal();
        } else if (typeof window.closeModal === 'function') {
            window.closeModal('modal-settings');
        }
        if (typeof window.deleteAccountAction === 'function') {
            window.deleteAccountAction();
        }
    };

    window.saveGameSettings = function (e) {
        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
        }
        persistSettings(currentSettings);
        if (typeof window.showToast === 'function') {
            window.showToast('💾 บันทึกการตั้งค่าเรียบร้อยแล้ว');
        }
        window.closeGameSettingsModal(e);
    };

    window.openGameSettingsModal = function (e) {
        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
        }
        try {
            currentSettings = loadSettings();
            ['sfx', 'bgm', 'voice'].forEach(ch => {
                const vol = currentSettings[ch + 'Vol'];
                const muted = Boolean(currentSettings[ch + 'Muted']);
                const s = document.getElementById(`setting-${ch}-vol-slider`);
                const n = document.getElementById(`setting-${ch}-vol-num`) || document.getElementById(`input-${ch}-vol`);
                const c = document.getElementById(`setting-${ch}-mute-check`);
                if (s) s.value = vol;
                if (n) n.value = vol;
                if (c) c.checked = !muted;
            });

            const badgeChk = document.getElementById('setting-board-badges-check');
            if (badgeChk) badgeChk.checked = currentSettings.boardBadges !== false;

            const hapticChk = document.getElementById('setting-haptic-check');
            if (hapticChk) hapticChk.checked = currentSettings.haptic !== false;

            const fpsChk = document.getElementById('setting-fps-check');
            if (fpsChk) fpsChk.checked = Boolean(currentSettings.showFps);

            const gachaFastChk = document.getElementById('setting-gacha-fast-open-check');
            if (gachaFastChk) gachaFastChk.checked = currentSettings.gachaFastOpen !== false;

            const isInMatch = Boolean(
                document.body.classList.contains('in-match-fullscreen') ||
                (window.game && window.game.isMatchActive)
            );
            const rowSurrender = document.getElementById('row-settings-surrender');
            if (rowSurrender) {
                rowSurrender.style.display = isInMatch ? 'flex' : 'none';
            }
        } catch (err) {
            console.warn('openGameSettingsModal warning:', err);
        }

        if (typeof window.openModal === 'function') {
            window.openModal('modal-settings');
        } else {
            const modal = document.getElementById('modal-settings');
            if (modal) modal.style.display = 'flex';
        }
    };

    window.closeGameSettingsModal = function (e) {
        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
        }
        const modal = document.getElementById('modal-settings');
        if (modal) {
            modal.classList.remove('active');
            modal.style.removeProperty('display');
            modal.style.setProperty('display', 'none', 'important');
            modal.style.display = 'none';
            modal.style.setProperty('visibility', 'hidden', 'important');
            modal.style.setProperty('opacity', '0', 'important');
            modal.style.setProperty('pointer-events', 'none', 'important');
        }
        if (typeof window.closeModal === 'function') {
            window.closeModal('modal-settings');
        }
        document.body.classList.remove('modal-open');
        const btnL = document.getElementById('btn-toggle-side-left');
        const btnR = document.getElementById('btn-toggle-side-right');
        if (btnL) btnL.classList.remove('modal-hidden');
        if (btnR) btnR.classList.remove('modal-hidden');
    };
})();

