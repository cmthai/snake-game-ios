/**
 * ⚙️ Game Settings Manager (ระบบตั้งค่าเกมส์)
 * รองรับ:
 * - ปรับระดับกราฟิก 3D (ต่ำ Low สำหรับโทรศัพท์รุ่นเก่า / กลาง Medium / สูง High)
 * - ปิด/เปิดเสียงเอฟเฟกต์ (SFX), เพลงบรรยากาศ (BGM), เสียงพากย์ไทย (Thai Voice) และสไลเดอร์เร่ง/หรี่เสียง
 * - ออกจากเกมส์ / ออกจากการแข่งขัน (Surrender / Exit to Lobby / Logout)
 * - ล้างแคชเกมส์ & รีเซ็ตไฟล์เกม (Clear Cache & Reload)
 * - ลบเกมส์ / ลบบัญชีผู้เล่น (Delete Account)
 * - ตั้งค่าอื่น ๆ: ความเร็วตัวหมาก, ป้ายชื่อช่องบนกระดาน, ระบบสั่น Haptic, แสดง FPS
 */

(function () {
    'use strict';

    // 1. Initial State from localStorage
    const isMobile = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
    const defaultQuality = isMobile ? 'medium' : 'high';

    window.gameSettings = {
        graphicsQuality: localStorage.getItem('snake_graphics_quality') || defaultQuality,
        sfxMuted: localStorage.getItem('snake_sound_muted') === 'true',
        sfxVolume: Number(localStorage.getItem('snake_sfx_volume') ?? 0.85),
        bgmMuted: localStorage.getItem('snake_bgm_muted') === 'true',
        bgmVolume: Number(localStorage.getItem('snake_bgm_volume') ?? 0.70),
        voiceEnabled: localStorage.getItem('snake_voice_enabled') !== 'false',
        voiceVolume: Number(localStorage.getItem('snake_voice_volume') ?? 0.90),
        walkSpeedMultiplier: Number(localStorage.getItem('snake_walk_speed_mult') ?? 1.0),
        boardBadges: localStorage.getItem('snake_board_badges') !== 'false',
        hapticEnabled: localStorage.getItem('snake_haptic_enabled') !== 'false',
        showFps: localStorage.getItem('snake_show_fps') === 'true',
        gachaRevealInterval: Number(localStorage.getItem('snake_gacha_reveal_interval') ?? 0.10),
        gachaFastOpen: localStorage.getItem('snake_gacha_fast_open') !== 'false'
    };

    /**
     * 🎮 ปรับระดับกราฟิก 3D (Graphics Quality)
     * 'low' | 'medium' | 'high'
     */
    window.applyGraphicsQuality = function (quality) {
        if (!['low', 'medium', 'high'].includes(quality)) quality = 'medium';
        window.gameSettings.graphicsQuality = quality;
        localStorage.setItem('snake_graphics_quality', quality);

        // อัปเดตใน Three.js Game Engine ทันที
        if (window.game && typeof window.game.setGraphicsQuality === 'function') {
            window.game.setGraphicsQuality(quality);
        }

        // อัปเดตสถานะปุ่มใน Modal
        updateQualityButtonsUI(quality);

        const qualityNames = {
            low: '🟢 ต่ำ (ประหยัดพลังงาน สำหรับมือถือรุ่นเก่า)',
            medium: '🟡 กลาง (สมดุล ลื่นไหล)',
            high: '🔴 สูง (คมชัดสมจริง เงา 3D เต็มรูปแบบ)'
        };

        if (typeof window.showToast === 'function') {
            window.showToast(`🎮 ปรับกราฟิกเป็น: ${qualityNames[quality]}`);
        }
    };

    function updateQualityButtonsUI(activeQuality) {
        ['low', 'medium', 'high'].forEach(q => {
            const btn = document.getElementById(`btn-quality-${q}`);
            if (btn) {
                if (q === activeQuality) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
        });
    }

    /**
     * 🔊 ตั้งค่าการปิด/เปิดเสียง (Mute / Unmute)
     */
    window.setAudioMute = function (type, isMuted) {
        const muted = Boolean(isMuted);

        if (type === 'sfx') {
            window.gameSettings.sfxMuted = muted;
            if (window.soundEngine && typeof window.soundEngine.setMute === 'function') {
                window.soundEngine.setMute(muted);
            }
        } else if (type === 'bgm') {
            window.gameSettings.bgmMuted = muted;
            if (window.soundEngine && typeof window.soundEngine.setBgmMute === 'function') {
                window.soundEngine.setBgmMute(muted);
            }
        } else if (type === 'voice') {
            window.gameSettings.voiceEnabled = !muted;
            localStorage.setItem('snake_voice_enabled', !muted ? 'true' : 'false');
            if (window.ThaiAudio && window.ThaiAudio.config) {
                window.ThaiAudio.config.voiceEnabled = !muted;
                if (typeof window.ThaiAudio.saveLocalPreferences === 'function') {
                    window.ThaiAudio.saveLocalPreferences();
                }
            }
        }

        // เล่นเสียงตอบสนองหากเป็นการเปิด
        if (!muted && type === 'sfx' && window.soundEngine && typeof window.soundEngine.playClick === 'function') {
            window.soundEngine.playClick();
        }
    };

    /**
     * 🎚️ ปรับระดับความดังเสียง (รองรับทั้ง Slider และพิมพ์ตัวเลข %)
     */
    window.setAudioVolume = function (type, val, triggerSource = 'slider') {
        let numVal = Number(val);
        if (isNaN(numVal)) numVal = 0;
        numVal = Math.max(0, Math.min(100, Math.round(numVal)));
        const normalized = numVal / 100;

        // ซิงก์ค่าระหว่าง Slider และช่อง Input ตัวเลข
        const sliderEl = document.getElementById(`setting-${type}-vol-slider`);
        const numInputEl = document.getElementById(`input-${type}-vol`);
        const labelEl = document.getElementById(`label-${type}-vol`);

        if (sliderEl && triggerSource !== 'slider') {
            sliderEl.value = numVal;
        }
        if (numInputEl && triggerSource !== 'num') {
            numInputEl.value = numVal;
        }
        if (labelEl) {
            labelEl.innerText = `${numVal}%`;
        }

        if (type === 'sfx') {
            window.gameSettings.sfxVolume = normalized;
            if (window.soundEngine && typeof window.soundEngine.setSfxVolume === 'function') {
                window.soundEngine.setSfxVolume(normalized);
            }
        } else if (type === 'bgm') {
            window.gameSettings.bgmVolume = normalized;
            localStorage.setItem('snake_bgm_volume', String(normalized));
            if (window.soundEngine && typeof window.soundEngine.setBgmVolume === 'function') {
                window.soundEngine.setBgmVolume(normalized);
            }
        } else if (type === 'voice') {
            window.gameSettings.voiceVolume = normalized;
            localStorage.setItem('snake_voice_volume', String(normalized));
            if (window.ThaiAudio && window.ThaiAudio.config) {
                window.ThaiAudio.config.voiceVolume = normalized;
                if (typeof window.ThaiAudio.saveLocalPreferences === 'function') {
                    window.ThaiAudio.saveLocalPreferences();
                }
            }
        }
    };

    /**
     * 🏃 ตั้งค่าความเร็วการเดินของตัวหมาก (Walk Speed Multiplier)
     */
    window.setWalkSpeed = function (multiplier) {
        const mult = Number(multiplier) || 1.0;
        window.gameSettings.walkSpeedMultiplier = mult;
        localStorage.setItem('snake_walk_speed_mult', String(mult));

        // อัปเดตปุ่มใน UI
        [1.0, 1.5, 2.0].forEach(m => {
            const btn = document.getElementById(`btn-walk-speed-${m.toFixed(1).replace('.', '_')}`);
            if (btn) {
                if (Math.abs(m - mult) < 0.1) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
        });

        const speedLabels = {
            1.0: 'ปกติ (1.0x)',
            1.5: 'เร็ว (1.5x)',
            2.0: 'เทอร์โบ (2.0x)'
        };
        if (typeof window.showToast === 'function') {
            window.showToast(`🏃 ความเร็วการเดิน: ${speedLabels[mult] || mult + 'x'}`);
        }
    };

    /**
     * 🏷️ สลับเปิด/ปิดป้ายชื่อช่องบนกระดาน (Board Tile Badges)
     */
    window.toggleBoardBadgesSetting = function () {
        if (typeof window.toggleBoardBadgesAction === 'function') {
            window.toggleBoardBadgesAction();
        }
        const isShown = Boolean(window.game && window.game.badgeConfig && window.game.badgeConfig.showBadges);
        window.gameSettings.boardBadges = isShown;
        localStorage.setItem('snake_board_badges', isShown ? 'true' : 'false');

        const chk = document.getElementById('setting-board-badges-check');
        if (chk) chk.checked = isShown;
    };

    /**
     * 📳 สลับเปิด/ปิดระบบสั่น (Haptic Feedback)
     */
    window.toggleHapticSetting = function (enabled) {
        window.gameSettings.hapticEnabled = Boolean(enabled);
        localStorage.setItem('snake_haptic_enabled', window.gameSettings.hapticEnabled ? 'true' : 'false');
        if (window.gameSettings.hapticEnabled && 'vibrate' in navigator) {
            try { navigator.vibrate(60); } catch (e) { }
        }
    };

    /**
     * ⚡ สลับแสดงผลตัววัด FPS (Frame Rate Monitor)
     */
    window.toggleFpsSetting = function (show) {
        window.gameSettings.showFps = Boolean(show);
        localStorage.setItem('snake_show_fps', window.gameSettings.showFps ? 'true' : 'false');

        const fpsEl = document.getElementById('ingame-fps-meter');
        if (fpsEl) {
            fpsEl.style.display = window.gameSettings.showFps ? 'inline-flex' : 'none';
        }
    };

    /**
     * 🎴 ระบบตั้งค่าเวลาเปิดแพ็คสุ่ม (Gacha Card Reveal Interval & Fast Open)
     * รองรับตั้งค่าเวลาห่างกันต่อใบ เช่น 0.10 วินาที
     */
    window.getGachaRevealIntervalSec = function () {
        const raw = localStorage.getItem('snake_gacha_reveal_interval');
        if (raw === null || raw === undefined) return 0.10; // ค่าเริ่มต้นที่แนะนำ 0.10 วิ
        const num = parseFloat(raw);
        return isNaN(num) ? 0.10 : Math.max(0, Math.min(2.0, num));
    };

    window.isGachaFastOpenEnabled = function () {
        return localStorage.getItem('snake_gacha_fast_open') !== 'false';
    };

    window.setGachaRevealInterval = function (val, triggerSource = 'button') {
        let num = parseFloat(val);
        if (isNaN(num)) num = 0.10;
        num = Math.max(0, Math.min(2.0, Math.round(num * 100) / 100));

        window.gameSettings.gachaRevealInterval = num;
        localStorage.setItem('snake_gacha_reveal_interval', num.toFixed(2));

        const slider = document.getElementById('setting-gacha-speed-slider');
        const input = document.getElementById('input-gacha-speed');
        if (slider && triggerSource !== 'slider') slider.value = Math.round(num * 100);
        if (input && triggerSource !== 'num') input.value = num.toFixed(2);

        // ไฮไลต์ปุ่ม Preset ความเร็วที่ตรงกับค่าปัจจุบัน
        [0.10, 0.25, 0.50, 1.00, 0.00].forEach(p => {
            const btn = document.getElementById(`btn-gacha-speed-${p.toFixed(2).replace('.', '_')}`);
            if (btn) {
                btn.classList.toggle('active', Math.abs(p - num) < 0.03);
            }
        });

        // อัปเดตข้อความบนปุ่มด่วนและหน้าสุ่มการ์ดทันที
        const quickPill = document.getElementById('gacha-quick-speed-pill-label');
        if (quickPill) quickPill.innerText = `${num.toFixed(2)} วิ`;
        const stage1Label = document.getElementById('gacha-stage1-speed-label');
        if (stage1Label) stage1Label.innerText = `${num.toFixed(2)} วิ`;
        const promptEl = document.getElementById('gacha-tap-prompt');
        if (promptEl) {
            promptEl.innerHTML = `⚡ แตะแพ็คเพื่อเปิดด่วน 5 ใบ (${num.toFixed(2)} วิ)`;
        }

        if (typeof window.showToast === 'function' && triggerSource !== 'slider') {
            window.showToast(`🎴 ตั้งเวลาเปิดการ์ด: ${num.toFixed(2)} วินาที/ใบ`);
        }
    };

    window.toggleGachaFastOpenSetting = function (enabled) {
        const isFast = Boolean(enabled);
        window.gameSettings.gachaFastOpen = isFast;
        localStorage.setItem('snake_gacha_fast_open', isFast ? 'true' : 'false');
        const chk = document.getElementById('setting-gacha-fast-open-check');
        if (chk) chk.checked = isFast;
        if (typeof window.showToast === 'function') {
            window.showToast(isFast ? '⚡ เปิดใช้งานโหมดเปิดด่วน 5 ใบ' : '⏱️ ปิดโหมดเปิดด่วน (ใช้ความเร็วปกติ)');
        }
    };

    window.cycleGachaRevealSpeed = function () {
        const current = window.getGachaRevealIntervalSec();
        let next = 0.10;
        if (Math.abs(current - 0.10) < 0.05) next = 0.25;
        else if (Math.abs(current - 0.25) < 0.05) next = 0.50;
        else if (Math.abs(current - 0.50) < 0.05) next = 1.00;
        else if (Math.abs(current - 1.00) < 0.05) next = 0.00;
        else next = 0.10;
        window.setGachaRevealInterval(next, 'button');
    };

    // เชื่อมต่อเข้ากับระบบ ThaiAudio ให้เรียกใช้งานได้เสมอ
    if (typeof window !== 'undefined') {
        if (!window.ThaiAudio) window.ThaiAudio = {};
        window.ThaiAudio.getCardRevealIntervalSec = window.getGachaRevealIntervalSec;
    }

    /**
     * 🚪 จัดการออกจากเกมส์ / สละสิทธิ์การแข่ง
     */
    window.settingsExitGameAction = function () {
        const isInMatch = Boolean(
            document.body.classList.contains('in-match-fullscreen') ||
            (window.game && window.game.isMatchActive)
        );

        if (isInMatch) {
            if (typeof window.closeModal === 'function') {
                window.closeModal('modal-settings');
            }
            if (typeof window.confirmExitMatchAction === 'function') {
                window.confirmExitMatchAction();
            } else if (typeof window.exitToHomeScreen === 'function') {
                window.exitToHomeScreen();
            }
        } else {
            if (typeof window.closeModal === 'function') {
                window.closeModal('modal-settings');
            }
            if (typeof window.logoutAction === 'function') {
                window.logoutAction();
            } else if (typeof window.showInGameConfirm === 'function') {
                window.showInGameConfirm(
                    'ต้องการออกจากระบบใช่หรือไม่?\n\nข้อมูลเพชร ทอง การ์ดไอเทม และความคืบหน้าทั้งหมดจะถูกบันทึกไว้ในบัญชีของคุณ',
                    async () => {
                        try {
                            if (window.apiClient) {
                                await window.apiClient.request('api/auth.php?action=logout', { method: 'POST' }).catch(() => {});
                            }
                        } catch (e) { }
                        if (typeof window.resetAllUserDataAndCaches === 'function') {
                            window.resetAllUserDataAndCaches(true);
                        }
                        if (typeof window.openAuthModal === 'function') {
                            window.openAuthModal();
                        } else {
                            location.reload();
                        }
                    },
                    'ยืนยันการออกจากระบบ',
                    '🚪'
                );
            } else {
                if (confirm('ต้องการออกจากระบบใช่หรือไม่?')) {
                    try {
                        if (window.apiClient) {
                            window.apiClient.request('api/auth.php?action=logout', { method: 'POST' }).catch(() => {});
                        }
                    } catch (e) { }
                    if (typeof window.resetAllUserDataAndCaches === 'function') {
                        window.resetAllUserDataAndCaches(true);
                    }
                    if (typeof window.openAuthModal === 'function') {
                        window.openAuthModal();
                    } else {
                        location.reload();
                    }
                }
            }
        }
    };

    /**
     * 🧹 ล้างแคชเกมส์และรีเซ็ตไฟล์เกม (Clear Cache & Reload)
     */
    window.clearGameCacheAction = function () {
        const confirmFunc = (typeof window.showInGameConfirm === 'function')
            ? window.showInGameConfirm
            : ((msg, onOk) => { if (confirm(msg)) onOk(); });

        confirmFunc(
            'คุณต้องการล้างแคชและรีเซ็ตไฟล์เกมชั่วคราวหรือไม่?\n\n(ระบบจะล้างแคชไฟล์ภาพและโหลดเวอร์ชันล่าสุดใหม่ทันที โดยข้อมูลบัญชี การ์ด เพชร และทอง จะยังคงอยู่ครบถ้วน)',
            async () => {
                try {
                    // เก็บ session บัญชีผู้เล่นไว้ไม่ให้หลุด
                    const preserveKeys = ['snake_auth_token', 'snake_active_session', 'snake_auth_user', 'snake_user_id'];
                    const saved = {};
                    preserveKeys.forEach(k => {
                        const v = localStorage.getItem(k);
                        if (v !== null) saved[k] = v;
                    });

                    // ล้างแคช service worker / cache storage ถ้ามี
                    if ('caches' in window) {
                        const keys = await caches.keys();
                        await Promise.all(keys.map(k => caches.delete(k)));
                    }

                    // ล้าง localStorage ชั่วคราวแล้วกู้ session กลับ
                    localStorage.clear();
                    Object.entries(saved).forEach(([k, v]) => localStorage.setItem(k, v));
                } catch (e) {
                    console.warn('[Settings] Cache clearing warning:', e);
                }

                if (typeof window.showToast === 'function') {
                    window.showToast('🧹 ล้างแคชเกมเรียบร้อย กำลังโหลดไฟล์เกมล่าสุด...');
                }
                setTimeout(() => {
                    const cleanUrl = window.location.origin + window.location.pathname + '?v=' + Date.now();
                    window.location.replace(cleanUrl);
                }, 500);
            },
            'ล้างแคช & รีโหลดไฟล์เกม',
            '🧹'
        );
    };

    /**
     * 🗑️ ลบเกมส์ / ลบบัญชีผู้เล่น
     */
    window.settingsDeleteAccountAction = function () {
        if (typeof window.closeModal === 'function') {
            window.closeModal('modal-settings');
        }
        if (typeof window.deleteAccountAction === 'function') {
            window.deleteAccountAction();
        }
    };

    /**
     * ⚙️ เปิดหน้าต่างตั้งค่าเกม (Populate Values & Open Modal)
     */
    window.saveGameSettings = function (e) {
        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
        }
        try {
            const s = window.gameSettings;
            localStorage.setItem('snake_graphics_quality', s.graphicsQuality);
            localStorage.setItem('snake_walk_speed_mult', String(s.walkSpeedMultiplier));
            localStorage.setItem('snake_sfx_volume', String(s.sfxVolume));
            localStorage.setItem('snake_bgm_volume', String(s.bgmVolume));
            localStorage.setItem('snake_voice_volume', String(s.voiceVolume));
            localStorage.setItem('snake_show_fps', s.showFps ? 'true' : 'false');
            localStorage.setItem('snake_haptic_enabled', s.hapticEnabled ? 'true' : 'false');
            localStorage.setItem('snake_gacha_reveal_interval', Number(s.gachaRevealInterval ?? 0.10).toFixed(2));
            localStorage.setItem('snake_gacha_fast_open', s.gachaFastOpen ? 'true' : 'false');
        } catch (err) {}
        if (typeof window.closeGameSettingsModal === 'function') {
            window.closeGameSettingsModal(e);
        } else if (typeof window.closeModal === 'function') {
            window.closeModal('modal-settings');
        }
        if (typeof window.showToast === 'function') window.showToast('✅ บันทึกการตั้งค่าเรียบร้อย');
    };

    let _lastSettingsModalOpenTime = 0;
    window.openGameSettingsModal = function (event) {
        if (event) {
            if (typeof event.stopPropagation === 'function') event.stopPropagation();
            if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
            if (event.type === 'touchend' && typeof event.preventDefault === 'function') {
                event.preventDefault();
            }
        }
        const now = Date.now();
        if (now - _lastSettingsModalOpenTime < 220) return;
        _lastSettingsModalOpenTime = now;

        // Force modal display immediately so UI opens with 0ms delay on mobile
        const modal = document.getElementById('modal-settings');
        if (modal) {
            modal._openedAt = now;
            modal.classList.add('active');
            modal.style.removeProperty('display');
            modal.style.display = 'flex';
            modal.style.setProperty('display', 'flex', 'important');
            modal.style.setProperty('opacity', '1', 'important');
            modal.style.setProperty('visibility', 'visible', 'important');
            modal.style.setProperty('z-index', '2147483000', 'important');
            modal.style.setProperty('pointer-events', 'auto', 'important');
            document.body.classList.add('modal-open');

            // Prevent ghost click / tap-through immediate backdrop dismissal on mobile
            modal.onclick = function (e) {
                if (e.target === modal) {
                    if (Date.now() - (modal._openedAt || 0) < 600) return;
                    window.closeGameSettingsModal(e);
                }
            };
            modal.ontouchend = function (e) {
                if (e.target === modal) {
                    if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
                    if (Date.now() - (modal._openedAt || 0) < 600) {
                        if (e && typeof e.preventDefault === 'function') e.preventDefault();
                        return;
                    }
                    window.closeGameSettingsModal(e);
                }
            };

            const content = modal.querySelector('.modal-content') || modal.querySelector('.settings-modal-box');
            if (content) content.scrollTop = 0;
            modal.scrollTop = 0;
        }

        try {
            const s = window.gameSettings || {};

            // ปุ่มบันทึก (สร้างครั้งเดียว ติดท้ายกล่องตั้งค่า)
            const box = document.querySelector('#modal-settings .settings-modal-box');
            if (box && !document.getElementById('btn-settings-save')) {
                const foot = document.createElement('div');
                foot.className = 'settings-save-footer';
                foot.innerHTML = '<button type="button" id="btn-settings-save" onclick="window.saveGameSettings(event)" ontouchend="window.saveGameSettings(event)">💾 บันทึก</button>';
                box.appendChild(foot);
            }

            // ผูก Event ให้ปุ่มปิดกากบาทสีแดง [X] และปุ่มบันทึกทำงาน 100% บนมือถือ
            const closeBtn = document.getElementById('btn-close-settings') || modal.querySelector('.modal-close');
            if (closeBtn) {
                closeBtn.onclick = function (e) {
                    if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
                    window.closeGameSettingsModal(e);
                };
                closeBtn.ontouchend = function (e) {
                    if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
                    if (e && typeof e.preventDefault === 'function') e.preventDefault();
                    window.closeGameSettingsModal(e);
                };
            }
            const saveBtn = document.getElementById('btn-settings-save');
            if (saveBtn) {
                saveBtn.onclick = function (e) {
                    if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
                    window.saveGameSettings(e);
                };
                saveBtn.ontouchend = function (e) {
                    if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
                    if (e && typeof e.preventDefault === 'function') e.preventDefault();
                    window.saveGameSettings(e);
                };
            }

            // 1. Graphics Quality Buttons
            if (s.graphicsQuality) updateQualityButtonsUI(s.graphicsQuality);

            // 2. Sound Controls
            const sfxMuteChk = document.getElementById('setting-sfx-mute-check');
            if (sfxMuteChk) sfxMuteChk.checked = !s.sfxMuted;

            const sfxVolSlider = document.getElementById('setting-sfx-vol-slider');
            const sfxVal = Math.round((s.sfxVolume ?? 0.85) * 100);
            if (sfxVolSlider) sfxVolSlider.value = sfxVal;
            const sfxInput = document.getElementById('input-sfx-vol');
            if (sfxInput) sfxInput.value = sfxVal;
            const sfxLabel = document.getElementById('label-sfx-vol');
            if (sfxLabel) sfxLabel.innerText = `${sfxVal}%`;

            const bgmMuteChk = document.getElementById('setting-bgm-mute-check');
            if (bgmMuteChk) bgmMuteChk.checked = !s.bgmMuted;

            const bgmVolSlider = document.getElementById('setting-bgm-vol-slider');
            const bgmVal = Math.round((s.bgmVolume ?? 0.70) * 100);
            if (bgmVolSlider) bgmVolSlider.value = bgmVal;
            const bgmInput = document.getElementById('input-bgm-vol');
            if (bgmInput) bgmInput.value = bgmVal;
            const bgmLabel = document.getElementById('label-bgm-vol');
            if (bgmLabel) bgmLabel.innerText = `${bgmVal}%`;

            const voiceMuteChk = document.getElementById('setting-voice-mute-check');
            if (voiceMuteChk) voiceMuteChk.checked = Boolean(s.voiceEnabled);

            const voiceVolSlider = document.getElementById('setting-voice-vol-slider');
            const voiceVal = Math.round((s.voiceVolume ?? 0.85) * 100);
            if (voiceVolSlider) voiceVolSlider.value = voiceVal;
            const voiceInput = document.getElementById('input-voice-vol');
            if (voiceInput) voiceInput.value = voiceVal;
            const voiceLabel = document.getElementById('label-voice-vol');
            if (voiceLabel) voiceLabel.innerText = `${voiceVal}%`;

            // 3. Gameplay Options
            [1.0, 1.5, 2.0].forEach(m => {
                const btn = document.getElementById(`btn-walk-speed-${m.toFixed(1).replace('.', '_')}`);
                if (btn) {
                    if (Math.abs(m - (s.walkSpeedMultiplier || 1.0)) < 0.1) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                }
            });

            const badgesChk = document.getElementById('setting-board-badges-check');
            if (badgesChk) {
                const currentBadgeState = Boolean(window.game && window.game.badgeConfig && window.game.badgeConfig.showBadges);
                badgesChk.checked = currentBadgeState;
            }

            const hapticChk = document.getElementById('setting-haptic-check');
            if (hapticChk) hapticChk.checked = Boolean(s.hapticEnabled);

            const fpsChk = document.getElementById('setting-fps-check');
            if (fpsChk) fpsChk.checked = Boolean(s.showFps);

            const notifBtn = document.getElementById('btn-toggle-phone-notifications');
            if (notifBtn) {
                const isGranted = (typeof Notification !== 'undefined' && Notification.permission === 'granted');
                if (isGranted) {
                    notifBtn.style.background = 'linear-gradient(135deg,#16a34a,#15803d)';
                    notifBtn.innerHTML = '<span>✅</span> เปิดใช้งานแล้ว';
                } else {
                    notifBtn.style.background = 'linear-gradient(135deg,#0284c7,#0369a1)';
                    notifBtn.innerHTML = '<span>🔔</span> เปิดใช้งาน';
                }
            }

            // 4. Gacha Pack Speed Controls
            const gachaInterval = typeof window.getGachaRevealIntervalSec === 'function' ? window.getGachaRevealIntervalSec() : 0.10;
            const gachaSlider = document.getElementById('setting-gacha-speed-slider');
            if (gachaSlider) gachaSlider.value = Math.round(gachaInterval * 100);
            const gachaInput = document.getElementById('input-gacha-speed');
            if (gachaInput) gachaInput.value = gachaInterval.toFixed(2);

            [0.10, 0.25, 0.50, 1.00, 0.00].forEach(p => {
                const btn = document.getElementById(`btn-gacha-speed-${p.toFixed(2).replace('.', '_')}`);
                if (btn) {
                    btn.classList.toggle('active', Math.abs(p - gachaInterval) < 0.03);
                }
            });

            const gachaFastChk = document.getElementById('setting-gacha-fast-open-check');
            if (gachaFastChk) gachaFastChk.checked = (typeof window.isGachaFastOpenEnabled === 'function') ? window.isGachaFastOpenEnabled() : true;

            // 5. Dynamic In-Match vs Lobby Action Context
            const isInMatch = Boolean(
                document.body.classList.contains('in-match-fullscreen') ||
                (window.game && window.game.isMatchActive)
            );

            const rowSurrender = document.getElementById('row-settings-surrender');
            if (rowSurrender) {
                rowSurrender.style.display = isInMatch ? 'flex' : 'none';
            }

            const exitBtn = document.getElementById('btn-settings-exit-game');
            const exitDesc = document.getElementById('desc-settings-exit-game');
            if (exitBtn) {
                if (isInMatch) {
                    exitBtn.innerHTML = '<span>🏳️</span> สละสิทธิ์ / ออกจากการแข่งขัน';
                    exitBtn.className = 'settings-btn danger';
                    if (exitDesc) exitDesc.innerText = 'ยอมแพ้การแข่งในกระดานปัจจุบันและกลับสู่หน้าหลักทันที';
                } else {
                    exitBtn.innerHTML = '<span>🚪</span> ออกจากระบบ (Logout)';
                    exitBtn.className = 'settings-btn warning';
                    if (exitDesc) exitDesc.innerText = 'ออกจากบัญชีผู้เล่นปัจจุบันและกลับสู่หน้าต่างเข้าสู่ระบบ';
                }
            }
        } catch (err) {
            console.warn('openGameSettingsModal populate warning:', err);
        }

        if (typeof window.openModal === 'function') {
            window.openModal('modal-settings');
        } else {
            const modal = document.getElementById('modal-settings');
            if (modal) modal.style.display = 'flex';
        }
    };

    window.closeGameSettingsModal = function (e) {
        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
        }
        const modal = document.getElementById('modal-settings');
        if (modal) {
            modal.classList.remove('active');
            modal.style.removeProperty('display');
            modal.style.setProperty('display', 'none', 'important');
            modal.style.display = 'none';
            modal.style.setProperty('visibility', 'hidden', 'important');
            modal.style.setProperty('opacity', '0', 'important');
            modal.style.setProperty('pointer-events', 'none', 'important');
        }
        if (typeof window.closeModal === 'function') {
            window.closeModal('modal-settings');
        }
        document.body.classList.remove('modal-open');
        const btnL = document.getElementById('btn-toggle-side-left');
        const btnR = document.getElementById('btn-toggle-side-right');
        if (btnL) btnL.classList.remove('modal-hidden');
        if (btnR) btnR.classList.remove('modal-hidden');
    };

    // Auto Apply On Engine Ready
    const initSettingsUI = () => {
        const bindTrigger = (id) => {
            const el = document.getElementById(id);
            if (!el) return;
            const handler = function (e) {
                if (e) {
                    if (typeof e.stopPropagation === 'function') e.stopPropagation();
                    if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                    if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
                }
                window.openGameSettingsModal(e);
            };
            el.onclick = handler;
            el.addEventListener('touchend', handler, { passive: false });
            el.addEventListener('pointerdown', (e) => { e.stopPropagation(); }, { passive: true });
            el.addEventListener('touchstart', (e) => { e.stopPropagation(); }, { passive: true });
            el.addEventListener('mousedown', (e) => { e.stopPropagation(); }, { passive: true });
        };
        bindTrigger('btn-open-settings');
        bindTrigger('btn-in-game-settings');
        bindTrigger('btn-top-floating-settings');

        const bindClose = (id) => {
            const el = document.getElementById(id);
            if (!el) return;
            const closeHandler = function (e) {
                if (e) {
                    if (typeof e.stopPropagation === 'function') e.stopPropagation();
                    if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                    if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
                }
                window.closeGameSettingsModal(e);
            };
            el.onclick = closeHandler;
            el.addEventListener('touchend', closeHandler, { passive: false });
            el.addEventListener('pointerdown', (e) => { e.stopPropagation(); }, { passive: true });
            el.addEventListener('touchstart', (e) => { e.stopPropagation(); }, { passive: true });
            el.addEventListener('mousedown', (e) => { e.stopPropagation(); }, { passive: true });
        };
        bindClose('btn-close-settings');

        setTimeout(() => {
            if (window.game && typeof window.game.setGraphicsQuality === 'function') {
                window.game.setGraphicsQuality(window.gameSettings.graphicsQuality);
            }
            if (window.gameSettings.showFps) {
                const fpsEl = document.getElementById('ingame-fps-meter');
                if (fpsEl) fpsEl.style.display = 'inline-flex';
            }
        }, 1200);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSettingsUI);
    } else {
        initSettingsUI();
    }

})();

