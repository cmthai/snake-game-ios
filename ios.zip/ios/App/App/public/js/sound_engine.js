/**
 * sound_engine.js - Master Web Audio Synthesizer & Hardware Audio Keep-Alive
 * 
 * แก้ปัญหาเสียงไม่ออก หรือต้องเปิดแท็บอื่นที่มีวิดีโอเสียงถึงจะออก:
 * 1. ระบบ Audio Keep-Alive (Continuous Inaudible Carrier): รักษาสตรีมเสียง WASAPI ของ Windows
 *    และเบราว์เซอร์ Chrome/Edge ให้ตื่นอยู่เสมอ Hardware DAC จะไม่หลับ (Sleep Mode)
 *    ทำให้เสียงเอฟเฟกต์ (เดิน, ทอยเต๋า, ตกงู, ขึ้นบันได) ดังชัดเจนทันทีโดยไม่ต้องเปิดแท็บวิดีโอช่วย
 * 2. Gesture Auto-Unlock: ปลดล็อก AudioContext ทันทีที่ผู้ใช้แตะหรือคลิกหน้าจอครั้งแรก
 * 3. ปุ่มเปิด/ปิดเสียง (Mute Toggle) ที่แถบด้านบน
 */

(function() {
    /**
     * ระบบเสียงบรรยากาศตอนเปิดเกมส์ (Lobby Ambient Sound / Opening Music)
     * - เล่นไฟล์ assets/audio/th/sound.mp3 (และ fallback dist/assets/audio/th/sound.mp3)
     * - เปิดวนทิ้งช่วง 1 วินาทีไปเรื่อยๆ (ended -> wait 1000ms -> play)
     * - เล่นเบาๆ (normalVolume = 0.22)
     * - Audio Ducking: เมื่อมีการทอยเต๋า หรือเอฟเฟกต์เสียงต่างๆ ให้ลดระดับเสียงลงชั่วคราว (duckVolume = 0.05)
     * - หยุดเล่นทันทีเมื่อเริ่มเล่นเกมส์ (isMatchActive === true)
     */
    class LobbyAmbientSound {
        constructor() {
            this.audio = null;
            this.sources = [
                'assets/audio/th/sound.mp3',
                'dist/assets/audio/th/sound.mp3'
            ];
            this.currentSrcIndex = 0;
            this.normalVolume = 0.22;
            this.duckVolume = 0.05;
            this.isDucked = false;
            this.duckTimeout = null;
            this.loopTimer = null;
            this.fadeInterval = null;
            this.isPlaying = false;
            this.manualStopped = false;
            this.gestureUnlocked = false;
        }

        init() {
            if (this.audio) return;
            try {
                this.audio = new Audio();
                this.audio.preload = 'auto';
                this.audio.loop = false; // ทิ้งช่วง 1 วินาทีเองผ่าน onended
                this.audio.volume = this.normalVolume;
                this.audio.src = this.sources[this.currentSrcIndex];

                this.audio.addEventListener('error', () => {
                    if (this.currentSrcIndex + 1 < this.sources.length) {
                        this.currentSrcIndex++;
                        this.audio.src = this.sources[this.currentSrcIndex];
                        if (this.isPlaying) {
                            this.audio.play().catch(() => {});
                        }
                    }
                });

                this.audio.addEventListener('ended', () => {
                    this.handleTrackEnded();
                });

                document.addEventListener('visibilitychange', () => {
                    if (document.hidden) {
                        if (this.audio && !this.audio.paused) {
                            this.audio.pause();
                        }
                    } else {
                        if (!this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isMuted)) {
                            this.play();
                        }
                    }
                });
            } catch (e) {
                console.warn('LobbyAmbientSound init error:', e);
            }
        }

        isMatchRunning() {
            return Boolean(window.game && window.game.isMatchActive && !window.game.isGameOver);
        }

        handleTrackEnded() {
            if (this.loopTimer) clearTimeout(this.loopTimer);
            if (this.isMatchRunning() || this.manualStopped || (window.soundEngine && window.soundEngine.isMuted)) {
                this.isPlaying = false;
                return;
            }

            // ทิ้งช่วง 1 วิ แล้วเริ่มเล่นใหม่ไปเรื่อยๆ
            this.loopTimer = setTimeout(() => {
                if (this.isMatchRunning() || this.manualStopped || (window.soundEngine && window.soundEngine.isMuted)) {
                    this.isPlaying = false;
                    return;
                }
                if (this.audio) {
                    this.audio.currentTime = 0;
                    this.audio.volume = this.isDucked ? this.duckVolume : this.normalVolume;
                    const p = this.audio.play();
                    if (p !== undefined) {
                        p.then(() => { this.isPlaying = true; }).catch(() => {});
                    }
                }
            }, 1000);
        }

        play() {
            if (this.isMatchRunning() || (window.soundEngine && window.soundEngine.isMuted)) {
                return;
            }
            this.init();
            this.manualStopped = false;
            if (this.loopTimer) clearTimeout(this.loopTimer);

            if (!this.audio) return;
            this.audio.volume = this.isDucked ? this.duckVolume : this.normalVolume;

            const playPromise = this.audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    this.isPlaying = true;
                }).catch(() => {
                    this.setupUnlockOnGesture();
                });
            }
        }

        setupUnlockOnGesture() {
            if (this.gestureUnlocked) return;
            const unlock = () => {
                this.gestureUnlocked = true;
                ['pointerdown', 'click', 'touchstart', 'keydown'].forEach(evt => {
                    document.removeEventListener(evt, unlock);
                });
                if (!this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isMuted)) {
                    this.play();
                }
            };
            ['pointerdown', 'click', 'touchstart', 'keydown'].forEach(evt => {
                document.addEventListener(evt, unlock, { passive: true, once: true });
            });
        }

        stop() {
            this.manualStopped = true;
            this.isPlaying = false;
            if (this.loopTimer) {
                clearTimeout(this.loopTimer);
                this.loopTimer = null;
            }
            if (this.audio) {
                this.fadeToVolume(0, 300, () => {
                    if (this.audio) {
                        this.audio.pause();
                        this.audio.currentTime = 0;
                    }
                });
            }
        }

        duck(durationMs = 1500, targetDuckVol = 0.05) {
            if (!this.audio || this.audio.paused || !this.isPlaying) return;
            this.isDucked = true;

            if (this.duckTimeout) {
                clearTimeout(this.duckTimeout);
            }

            // ค่อยๆ ลดระดับเสียงลงอย่างนุ่มนวล
            this.fadeToVolume(targetDuckVol, 120);

            // เมื่อเอฟเฟกต์จบ ค่อยๆ คืนระดับเสียงกลับขึ้นมาเท่าเดิม
            this.duckTimeout = setTimeout(() => {
                this.isDucked = false;
                if (!this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isMuted)) {
                    this.fadeToVolume(this.normalVolume, 350);
                }
            }, durationMs);
        }

        fadeToVolume(targetVol, durationMs = 200, callback = null) {
            if (!this.audio) {
                if (callback) callback();
                return;
            }
            if (this.fadeInterval) {
                clearInterval(this.fadeInterval);
                this.fadeInterval = null;
            }

            const startVol = this.audio.volume;
            const diff = targetVol - startVol;
            if (Math.abs(diff) < 0.01) {
                this.audio.volume = Math.max(0, Math.min(1, targetVol));
                if (callback) callback();
                return;
            }

            const steps = 10;
            const stepTime = Math.max(10, Math.floor(durationMs / steps));
            let step = 0;

            this.fadeInterval = setInterval(() => {
                step++;
                const newVol = startVol + (diff * (step / steps));
                if (this.audio) {
                    this.audio.volume = Math.max(0, Math.min(1, newVol));
                }
                if (step >= steps) {
                    clearInterval(this.fadeInterval);
                    this.fadeInterval = null;
                    if (this.audio) {
                        this.audio.volume = Math.max(0, Math.min(1, targetVol));
                    }
                    if (callback) callback();
                }
            }, stepTime);
        }
    }

    class SoundEngine {
        constructor() {
            this.ctx = null;
            this.masterGain = null;
            this.isMuted = localStorage.getItem('snake_sound_muted') === 'true';
            this.keepAliveNode = null;
            this.keepAliveGain = null;
            this.initialized = false;
            this.lobbyAmbient = new LobbyAmbientSound();
        }

        init() {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.init();
                this.startLobbyAmbient();
            }

            if (this.initialized && this.ctx) {
                if (this.ctx.state === 'suspended') {
                    this.ctx.resume().catch(() => {});
                }
                return;
            }

            try {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (!AudioCtx) return;
                this.ctx = new AudioCtx({ latencyHint: 'interactive' });

                this.masterGain = this.ctx.createGain();
                this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.85, this.ctx.currentTime);
                this.masterGain.connect(this.ctx.destination);

                // Keep-Alive Inaudible Carrier Node: รักษาสัญญาณเสียงให้ฮาร์ดแวร์ DAC ในคอมพิวเตอร์ตื่นอยู่เสมอ
                try {
                    this.keepAliveNode = this.ctx.createOscillator();
                    this.keepAliveGain = this.ctx.createGain();
                    this.keepAliveNode.type = 'sine';
                    this.keepAliveNode.frequency.setValueAtTime(440, this.ctx.currentTime);
                    // 0.00001 หูมนุษย์ไม่ได้ยิน 100% แต่ระบบปฏิบัติการจะเห็นเป็น active audio stream
                    this.keepAliveGain.gain.setValueAtTime(0.00001, this.ctx.currentTime);
                    this.keepAliveNode.connect(this.keepAliveGain);
                    this.keepAliveGain.connect(this.ctx.destination);
                    this.keepAliveNode.start();
                } catch (e) {
                    console.warn('Keep-alive node note:', e);
                }

                this.initialized = true;
                this.updateToggleButton();
            } catch (e) {
                console.warn('SoundEngine init note:', e);
            }
        }

        resume() {
            if (!this.initialized || !this.ctx) {
                this.init();
            } else if (this.ctx.state === 'suspended') {
                this.ctx.resume().catch(() => {});
            }
        }

        toggleMute() {
            this.resume();
            this.isMuted = !this.isMuted;
            localStorage.setItem('snake_sound_muted', this.isMuted ? 'true' : 'false');
            if (this.masterGain && this.ctx) {
                const now = this.ctx.currentTime;
                this.masterGain.gain.cancelScheduledValues(now);
                this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.85, now);
            }
            if (this.lobbyAmbient) {
                if (this.isMuted) {
                    this.lobbyAmbient.stop();
                } else if (!this.lobbyAmbient.isMatchRunning()) {
                    this.lobbyAmbient.play();
                }
            }
            this.updateToggleButton();
            if (typeof showToast === 'function') {
                showToast(this.isMuted ? '🔇 ปิดเสียงเอฟเฟกต์แล้ว' : '🔊 เปิดเสียงเอฟเฟกต์แล้ว');
            }
            if (!this.isMuted) {
                this.playClick();
            }
            return this.isMuted;
        }

        startLobbyAmbient() {
            if (this.lobbyAmbient && !this.isMuted) {
                this.lobbyAmbient.play();
            }
        }

        stopLobbyAmbient() {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.stop();
            }
        }

        duckLobbyAmbient(durationMs = 1500, duckVol = 0.05) {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.duck(durationMs, duckVol);
            }
        }

        updateToggleButton() {
            const btn = document.getElementById('btn-toggle-sound');
            if (btn) {
                btn.innerHTML = this.isMuted ? '🔇' : '🔊';
                btn.title = this.isMuted ? 'เปิดเสียงเอฟเฟกต์ (ขณะนี้ปิดอยู่)' : 'ปิดเสียงเอฟเฟกต์ (ขณะนี้เปิดอยู่)';
                btn.style.opacity = this.isMuted ? '0.5' : '1';
            }
        }

        // 1. เสียงก้าวเดินตัวหมาก (Step Pop)
        playStep() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(600, 0.06);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(480, now);
                osc.frequency.exponentialRampToValueAtTime(780, now + 0.05);
                gain.gain.setValueAtTime(0.28, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.13);
            } catch (e) {}
        }

        // 2. เสียงเขย่าทอยลูกเต๋า (Dice Roll Rattle)
        playDiceRoll() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1600, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                for (let i = 0; i < 5; i++) {
                    const delay = i * 0.09 + Math.random() * 0.03;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'triangle';
                    const freq = 220 + Math.random() * 200;
                    osc.frequency.setValueAtTime(freq, now + delay);
                    gain.gain.setValueAtTime(0.25, now + delay);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.06);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(now + delay);
                    osc.stop(now + delay + 0.07);
                }
            } catch (e) {}
        }

        // 3. เสียงลูกเต๋าตกกระทบพื้นกระดาน (Dice Land Thud)
        playDiceLand() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1200, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(170, now);
                osc.frequency.exponentialRampToValueAtTime(45, now + 0.14);
                gain.gain.setValueAtTime(0.35, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.16);
            } catch (e) {}
        }

        // 4. เสียงปีนบันได (Ladder Climb Musical Arpeggio)
        playLadder() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1800, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
                const now = this.ctx.currentTime;
                notes.forEach((freq, idx) => {
                    const t = now + idx * 0.18;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.26, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.3);
                });
            } catch (e) {}
        }

        // 5. เสียงงูกัดและสไลด์ตัวลง (Snake Bite Drop)
        playSnake() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1800, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(450, now);
                osc.frequency.exponentialRampToValueAtTime(120, now + 0.4);
                osc.frequency.exponentialRampToValueAtTime(55, now + 0.8);
                gain.gain.setValueAtTime(0.32, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.88);
            } catch (e) {}
        }

        // 5.1 เสียงงูและบันไดสลับตำแหน่งและเปลี่ยนสี (Magical Warp Shuffle)
        playWarp() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1200, 0.05);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(340, now);
                osc.frequency.exponentialRampToValueAtTime(820, now + 0.16);
                osc.frequency.exponentialRampToValueAtTime(420, now + 0.32);
                gain.gain.setValueAtTime(0.24, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.38);
            } catch (e) {}
        }

        // 6. เสียงฉลองชัยชนะ (Victory Fanfare)
        playWin() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(2500, 0.03);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51];
                const now = this.ctx.currentTime;
                notes.forEach((f, i) => {
                    const t = now + i * 0.14;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(f, t);
                    gain.gain.setValueAtTime(0.35, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.42);
                });
            } catch (e) {}
        }

        // 7. เสียงคลิกปุ่ม UI (Click Sound)
        playClick() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(350, 0.08);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(900, now);
                osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
                gain.gain.setValueAtTime(0.18, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.045);
            } catch (e) {}
        }

        // 8. เสียงเดินผ่านเมือง/ช่องกระดานแล้วนูนขึ้น (City Pop Bounce)
        playCityPop() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(600, 0.06);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(360, now);
                osc.frequency.exponentialRampToValueAtTime(680, now + 0.07);
                gain.gain.setValueAtTime(0.14, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.10);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.11);
            } catch (e) {}
        }

        // 9. เสียงสัญญาณเตือนภัยใกล้ถึงเส้นชัย 5-8 ช่อง (Near Finish Alert Fanfare)
        playNearFinish() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1800, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.08;
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.22, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.35);
                });
            } catch (e) {}
        }

        // 10. เสียงสัญญาณแจ้งเตือนเมื่อมีคน @ พูดถึงคุณ (Mention Notification Chime)
        playNotification() {
            if (this.isMuted) return;
            this.duckLobbyAmbient(1400, 0.04);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [659.25, 987.77]; // E5, B5 (Ding-Dong!)
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.12;
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.25, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.40);
                });
            } catch (e) {}
        }
    }

    const soundEngine = new SoundEngine();
    window.soundEngine = soundEngine;
    window.soundManager = soundEngine;

    window.toggleSoundAction = function() {
        soundEngine.toggleMute();
    };

    window.duckLobbyAmbientSound = function(durationMs, duckVol) {
        soundEngine.duckLobbyAmbient(durationMs, duckVol);
    };

    window.startLobbyAmbientSound = function() {
        soundEngine.startLobbyAmbient();
    };

    window.stopLobbyAmbientSound = function() {
        soundEngine.stopLobbyAmbient();
    };

    // ปลดล็อกระบบเสียงทันทีเมื่อผู้ใช้แตะหรือคลิกหน้าจอครั้งแรก
    const unlockEvents = ['pointerdown', 'click', 'touchstart', 'keydown'];
    const unlockHandler = function() {
        soundEngine.init();
        soundEngine.resume();
        soundEngine.startLobbyAmbient();
    };
    unlockEvents.forEach(evt => {
        document.addEventListener(evt, unlockHandler, { passive: true });
    });

    // เริ่มต้นสถานะปุ่มและเปิดเสียงบรรยากาศตอนเปิดเกมส์
    function bootSoundEngine() {
        soundEngine.updateToggleButton();
        soundEngine.init();
        soundEngine.startLobbyAmbient();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootSoundEngine);
    } else {
        bootSoundEngine();
    }
})();

