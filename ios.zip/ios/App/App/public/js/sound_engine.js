/**
 * sound_engine.js - Master Web Audio Synthesizer, BGM Player & iOS/Android Audio Unlock
 *
 * ระบบเสียงหลักของเกมกระดานบันไดงูเศรษฐี 3D:
 * 1. Gesture Auto-Unlock (iOS Safari / WKWebView / Android / Desktop):
 *    ปลดล็อก AudioContext ด้วย 1-sample silent buffer + HTML5 Audio warmup ทันทีที่ผู้ใช้แตะหน้าจอ
 *    และเล่น BGM ที่รออยู่ (pending) อัตโนมัติหลังปลดล็อกสำเร็จ
 * 2. BGM Player (Lobby Ambient & Gameplay BGM):
 *    ใช้ Web Audio Buffer + GainNode เป็นหลัก (เพื่อให้ปรับความดังและ Audio Ducking บน iOS ได้จริง
 *    เนื่องจาก iOS WebKit ไม่ยอมให้ปรับ HTMLAudioElement.volume) พร้อม HTML5 Audio fallback
 * 3. Synthesized Web Audio SFX: เสียงทอยเต๋า, ก้าวเดิน, วาร์ป, ขึ้นบันได, ตกงู, เหรียญ, การ์ด ฯลฯ
 * 4. Mute Toggle (`toggleSoundAction`) สำหรับปุ่มลำโพงบนแถบด้านบน
 */

(function () {
    'use strict';

    function calcPerceptualBgmVolume(rawSliderValue, maxMasterCeiling = 0.40) {
        const v = Math.max(0, Math.min(1, Number(rawSliderValue) || 0));
        if (v <= 0) return 0;
        return Math.pow(v, 1.85) * maxMasterCeiling;
    }

    function resolveBgmUrl(file) {
        const f = String(file || '').trim();
        if (!f) return '';
        if (/^(https?:|data:|blob:|capacitor:|\/)/i.test(f) || f.startsWith('assets/') || f.startsWith('dist/')) {
            return encodeURI(f);
        }
        return encodeURI('assets/audio/th/' + f);
    }

    class BgmTrackPlayer {
        constructor(engine, defaultSources, defaultNormalVol = 0.22, loopGapMs = 0) {
            this.engine = engine;
            this.sources = Array.isArray(defaultSources) ? defaultSources.slice() : [];
            this.currentSrcIndex = 0;
            this.normalVolume = defaultNormalVol;
            this.duckVolume = Math.min(0.05, defaultNormalVol * 0.25);
            this.enabled = true;
            this.loopGapMs = loopGapMs;
            this.isDucked = false;
            this.duckTimeout = null;
            this.loopTimer = null;
            this.isPlaying = false;
            this.wantsToPlay = false;
            this.manualStopped = false;

            // Web Audio nodes
            this.bufferCache = {};
            this.loadingUrl = null;
            this.sourceNode = null;
            this.gainNode = null;

            // HTML5 Audio fallback (exposed as `.audio` for compatibility checks)
            this.audio = null;
        }

        getEffectiveVolume() {
            if (!this.enabled || this.engine.isMuted || this.engine.isBgmMuted) return 0;
            const userScale = Math.max(0, Math.min(1, this.engine.bgmVolume));
            const base = this.isDucked ? this.duckVolume : this.normalVolume;
            return calcPerceptualBgmVolume(userScale, Math.max(0.05, base * 1.6));
        }

        applyVolume() {
            const vol = this.getEffectiveVolume();
            const ctx = this.engine.ctx;
            if (this.gainNode && ctx) {
                try {
                    this.gainNode.gain.setTargetAtTime(vol, ctx.currentTime, 0.08);
                } catch (e) {
                    try { this.gainNode.gain.value = vol; } catch (_) {}
                }
            }
            if (this.audio) {
                try {
                    this.audio.muted = (vol <= 0.0001);
                    this.audio.volume = Math.max(0, Math.min(1, vol));
                } catch (e) {}
            }
        }

        setConfig(file, volume, enabled) {
            if (file) {
                const resolved = resolveBgmUrl(file);
                if (resolved && this.sources[0] !== resolved) {
                    this.sources = [resolved, ...this.sources.filter(s => s !== resolved)];
                    this.currentSrcIndex = 0;
                    if (this.isPlaying) {
                        this.stop(false);
                        this.play();
                        return;
                    }
                }
            }
            if (volume !== undefined && !isNaN(Number(volume))) {
                this.normalVolume = Math.max(0, Math.min(1, Number(volume)));
                this.duckVolume = Math.min(0.05, this.normalVolume * 0.25);
            }
            if (enabled !== undefined) {
                this.enabled = Boolean(enabled);
                if (!this.enabled && this.isPlaying) {
                    this.stop(true);
                    return;
                }
            }
            this.applyVolume();
        }

        async _loadWebAudioBuffer(url) {
            if (this.bufferCache[url]) return this.bufferCache[url];
            const ctx = this.engine.ctx;
            if (!ctx || !url) return null;
            if (this.loadingUrl === url) return null;
            this.loadingUrl = url;
            try {
                const resp = await fetch(url);
                if (!resp.ok) return null;
                const arr = await resp.arrayBuffer();
                const buf = await new Promise((resolve, reject) => {
                    ctx.decodeAudioData(arr, resolve, reject);
                });
                this.bufferCache[url] = buf;
                return buf;
            } catch (e) {
                return null;
            } finally {
                if (this.loadingUrl === url) this.loadingUrl = null;
            }
        }

        _stopNodesOnly() {
            if (this.loopTimer) {
                clearTimeout(this.loopTimer);
                this.loopTimer = null;
            }
            if (this.sourceNode) {
                try {
                    this.sourceNode.onended = null;
                    this.sourceNode.stop();
                } catch (e) {}
                this.sourceNode = null;
            }
            if (this.audio) {
                try {
                    this.audio.pause();
                    this.audio.currentTime = 0;
                } catch (e) {}
            }
        }

        async play() {
            this.manualStopped = false;
            this.wantsToPlay = true;
            if (!this.enabled || this.engine.isMuted || this.engine.isBgmMuted) {
                this.isPlaying = false;
                return;
            }

            const ctx = this.engine.init();
            const srcUrl = this.sources[this.currentSrcIndex] || this.sources[0];
            if (!srcUrl) return;

            // Try Web Audio first when AudioContext is running (best for iOS volume & ducking)
            if (ctx && ctx.state === 'running') {
                const cached = this.bufferCache[srcUrl];
                if (cached) {
                    this._startWebAudioBuffer(cached);
                    return;
                }
                // Decode in background; start HTML5 fallback immediately if possible, or play buffer once ready
                this._loadWebAudioBuffer(srcUrl).then(buf => {
                    if (buf && this.wantsToPlay && !this.manualStopped && !this.sourceNode) {
                        if (this.audio && !this.audio.paused) {
                            try { this.audio.pause(); } catch (e) {}
                        }
                        this._startWebAudioBuffer(buf);
                    }
                });
            }

            this._startHtml5Fallback(srcUrl);
        }

        _startWebAudioBuffer(buffer) {
            const ctx = this.engine.ctx;
            if (!ctx || !buffer || this.manualStopped || !this.wantsToPlay) return;
            this._stopNodesOnly();

            try {
                if (!this.gainNode || this.gainNode.context !== ctx) {
                    this.gainNode = ctx.createGain();
                    this.gainNode.connect(ctx.destination);
                }
                const vol = this.getEffectiveVolume();
                this.gainNode.gain.setValueAtTime(vol, ctx.currentTime);

                const src = ctx.createBufferSource();
                src.buffer = buffer;
                src.loop = (this.loopGapMs <= 0);
                src.connect(this.gainNode);

                if (this.loopGapMs > 0) {
                    src.onended = () => {
                        if (this.sourceNode !== src) return;
                        this.sourceNode = null;
                        this.isPlaying = false;
                        if (this.wantsToPlay && !this.manualStopped && this.enabled) {
                            this.loopTimer = setTimeout(() => {
                                if (this.wantsToPlay && !this.manualStopped) {
                                    this.play();
                                }
                            }, this.loopGapMs);
                        }
                    };
                }

                src.start(0);
                this.sourceNode = src;
                this.isPlaying = true;
            } catch (e) {
                this.isPlaying = false;
            }
        }

        _startHtml5Fallback(srcUrl) {
            try {
                if (!this.audio) {
                    this.audio = new Audio();
                    this.audio.setAttribute('playsinline', 'true');
                    this.audio.setAttribute('webkit-playsinline', 'true');
                    this.audio.preload = 'auto';
                    this.audio.addEventListener('error', () => {
                        if (this.currentSrcIndex + 1 < this.sources.length) {
                            this.currentSrcIndex++;
                            this.audio.src = this.sources[this.currentSrcIndex];
                            if (this.wantsToPlay && !this.manualStopped) {
                                this.audio.play().catch(() => {});
                            }
                        }
                    });
                    this.audio.addEventListener('ended', () => {
                        this.isPlaying = false;
                        if (this.wantsToPlay && !this.manualStopped && this.enabled) {
                            if (this.loopGapMs > 0) {
                                this.loopTimer = setTimeout(() => {
                                    if (this.wantsToPlay && !this.manualStopped) {
                                        this.play();
                                    }
                                }, this.loopGapMs);
                            } else {
                                this.audio.currentTime = 0;
                                this.audio.play().catch(() => {});
                            }
                        }
                    });
                }

                this.audio.loop = (this.loopGapMs <= 0);
                if (this.audio.getAttribute('data-src') !== srcUrl) {
                    this.audio.setAttribute('data-src', srcUrl);
                    this.audio.src = srcUrl;
                }
                this.applyVolume();

                const p = this.audio.play();
                if (p && typeof p.then === 'function') {
                    p.then(() => {
                        this.isPlaying = true;
                    }).catch(() => {
                        this.isPlaying = false;
                    });
                } else {
                    this.isPlaying = !this.audio.paused;
                }
            } catch (e) {
                this.isPlaying = false;
            }
        }

        stop(isManual = true) {
            if (isManual) {
                this.manualStopped = true;
                this.wantsToPlay = false;
            }
            this.isPlaying = false;
            this._stopNodesOnly();
        }

        duck(durationMs = 2000) {
            if (!this.isPlaying) return;
            this.isDucked = true;
            this.applyVolume();
            if (this.duckTimeout) clearTimeout(this.duckTimeout);
            this.duckTimeout = setTimeout(() => {
                this.isDucked = false;
                this.applyVolume();
            }, Math.max(300, Number(durationMs) || 1800));
        }
    }

    class SoundEngine {
        constructor() {
            this.ctx = null;
            this.masterGain = null;
            this.sfxGain = null;
            this.isUnlocked = false;
            this.isMuted = false;
            this.isSfxMuted = false;
            this.isBgmMuted = false;
            this.sfxVolume = 0.85;
            this.bgmVolume = 0.70;
            this.bgmConfig = null;

            this._loadSavedPrefs();

            this.lobbyAmbient = new BgmTrackPlayer(
                this,
                ['assets/audio/th/sound.mp3', 'dist/assets/audio/th/sound.mp3'],
                0.22,
                1000
            );
            this.gameplayBgm = new BgmTrackPlayer(
                this,
                ['assets/audio/th/ongame.mp3', 'dist/assets/audio/th/ongame.mp3'],
                0.20,
                0
            );

            this._bindGlobalUnlock();
        }

        _loadSavedPrefs() {
            try {
                const mutedRaw = localStorage.getItem('snake_sound_muted');
                if (mutedRaw === '1' || mutedRaw === 'true') {
                    this.isMuted = true;
                }
                const rawSettings = localStorage.getItem('snake_game_settings_v1');
                if (rawSettings) {
                    const s = JSON.parse(rawSettings);
                    if (typeof s.sfxVol === 'number') this.sfxVolume = Math.max(0, Math.min(1, s.sfxVol / 100));
                    if (typeof s.bgmVol === 'number') this.bgmVolume = Math.max(0, Math.min(1, s.bgmVol / 100));
                    if (typeof s.sfxMuted === 'boolean') this.isSfxMuted = s.sfxMuted;
                    if (typeof s.bgmMuted === 'boolean') this.isBgmMuted = s.bgmMuted;
                }
            } catch (e) {}
        }

        init() {
            if (!this.ctx) {
                try {
                    const AudioCtx = window.AudioContext || window.webkitAudioContext;
                    if (AudioCtx) {
                        try {
                            this.ctx = new AudioCtx({ latencyHint: 'interactive' });
                        } catch (e) {
                            this.ctx = new AudioCtx();
                        }
                        this.masterGain = this.ctx.createGain();
                        this.masterGain.gain.value = this.isMuted ? 0 : 1;
                        this.masterGain.connect(this.ctx.destination);

                        this.sfxGain = this.ctx.createGain();
                        this.sfxGain.gain.value = (this.isMuted || this.isSfxMuted) ? 0 : this.sfxVolume;
                        this.sfxGain.connect(this.masterGain);
                    }
                } catch (e) {}
            }
            return this.ctx;
        }

        _syncGains() {
            if (!this.ctx) return;
            const now = this.ctx.currentTime;
            if (this.masterGain) {
                try {
                    this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : 1, now, 0.02);
                } catch (e) {
                    this.masterGain.gain.value = this.isMuted ? 0 : 1;
                }
            }
            if (this.sfxGain) {
                const sVol = (this.isMuted || this.isSfxMuted) ? 0 : this.sfxVolume;
                try {
                    this.sfxGain.gain.setTargetAtTime(sVol, now, 0.02);
                } catch (e) {
                    this.sfxGain.gain.value = sVol;
                }
            }
        }

        unlock() {
            const ctx = this.init();
            if (ctx) {
                if (ctx.state === 'suspended' || ctx.state === 'interrupted') {
                    ctx.resume().then(() => {
                        this._afterCtxRunning();
                    }).catch(() => {});
                }
                // 1-sample silent buffer unlock for iOS WebKit
                try {
                    const buf = ctx.createBuffer(1, 1, 22050);
                    const src = ctx.createBufferSource();
                    src.buffer = buf;
                    src.connect(ctx.destination);
                    src.start(0);
                } catch (e) {}

                if (ctx.state === 'running') {
                    this._afterCtxRunning();
                }
            }
        }

        _afterCtxRunning() {
            const wasUnlocked = this.isUnlocked;
            this.isUnlocked = true;
            // Resume any BGM that was blocked by iOS autoplay policy before first gesture
            if (this.lobbyAmbient.wantsToPlay && !this.lobbyAmbient.isPlaying && !this.lobbyAmbient.manualStopped) {
                const inMatch = Boolean(window.game && window.game.isMatchActive);
                if (!inMatch) {
                    this.lobbyAmbient.play();
                }
            }
            if (this.gameplayBgm.wantsToPlay && !this.gameplayBgm.isPlaying && !this.gameplayBgm.manualStopped) {
                this.gameplayBgm.play();
            }
            if (!wasUnlocked) {
                this._syncGains();
            }
        }

        _bindGlobalUnlock() {
            const handler = () => {
                this.unlock();
            };
            ['pointerdown', 'touchstart', 'touchend', 'click', 'keydown'].forEach(evt => {
                window.addEventListener(evt, handler, { passive: true, capture: true });
            });
            document.addEventListener('visibilitychange', () => {
                if (document.visibilityState === 'visible') {
                    if (this.ctx && (this.ctx.state === 'suspended' || this.ctx.state === 'interrupted')) {
                        this.ctx.resume().then(() => this._afterCtxRunning()).catch(() => {});
                    }
                }
            });
            window.addEventListener('pageshow', handler, { passive: true });
        }

        setSfxVolume(val) {
            this.sfxVolume = Math.max(0, Math.min(1, Number(val) || 0));
            this._syncGains();
        }

        setBgmVolume(val) {
            this.bgmVolume = Math.max(0, Math.min(1, Number(val) || 0));
            this.lobbyAmbient.applyVolume();
            this.gameplayBgm.applyVolume();
        }

        setSfxMuted(muted) {
            this.isSfxMuted = Boolean(muted);
            this._syncGains();
        }

        setBgmMuted(muted) {
            this.isBgmMuted = Boolean(muted);
            if (this.isBgmMuted) {
                if (this.lobbyAmbient.isPlaying) this.lobbyAmbient.stop(false);
                if (this.gameplayBgm.isPlaying) this.gameplayBgm.stop(false);
            } else {
                if (this.lobbyAmbient.wantsToPlay && !(window.game && window.game.isMatchActive)) {
                    this.lobbyAmbient.play();
                }
                if (this.gameplayBgm.wantsToPlay && (window.game && window.game.isMatchActive)) {
                    this.gameplayBgm.play();
                }
            }
            this.lobbyAmbient.applyVolume();
            this.gameplayBgm.applyVolume();
        }

        setMasterMuted(muted) {
            this.isMuted = Boolean(muted);
            try {
                localStorage.setItem('snake_sound_muted', this.isMuted ? '1' : '0');
            } catch (e) {}
            this._syncGains();
            if (this.isMuted) {
                if (this.lobbyAmbient.isPlaying) this.lobbyAmbient.stop(false);
                if (this.gameplayBgm.isPlaying) this.gameplayBgm.stop(false);
            } else {
                if (this.lobbyAmbient.wantsToPlay && !(window.game && window.game.isMatchActive)) {
                    this.lobbyAmbient.play();
                }
                if (this.gameplayBgm.wantsToPlay && (window.game && window.game.isMatchActive)) {
                    this.gameplayBgm.play();
                }
            }
            this.lobbyAmbient.applyVolume();
            this.gameplayBgm.applyVolume();
        }

        updateBgmSettings(cfg) {
            if (!cfg || typeof cfg !== 'object') return;
            this.bgmConfig = cfg;
            if (cfg.lobby) {
                this.lobbyAmbient.setConfig(cfg.lobby.file, cfg.lobby.volume, cfg.lobby.enabled);
            }
            if (cfg.gameplay) {
                this.gameplayBgm.setConfig(cfg.gameplay.file, cfg.gameplay.volume, cfg.gameplay.enabled);
            }
        }

        duckAllBgm(durationMs = 2000) {
            this.lobbyAmbient.duck(durationMs);
            this.gameplayBgm.duck(durationMs);
        }

        startLobbyAmbient() {
            if (window.game && window.game.isMatchActive) return;
            this.gameplayBgm.stop(true);
            this.lobbyAmbient.play();
        }

        stopLobbyAmbient() {
            this.lobbyAmbient.stop(true);
        }

        startGameplayBgm(stageTheme = 'classic', customBgmFile = '', customVol = undefined) {
            this.lobbyAmbient.stop(true);

            let fileToPlay = '';
            let volToPlay = undefined;
            let enabled = true;

            if (customBgmFile) {
                fileToPlay = customBgmFile;
                if (customVol !== undefined && !isNaN(Number(customVol))) {
                    volToPlay = Number(customVol);
                }
            } else if (this.bgmConfig) {
                const stages = this.bgmConfig.stages || {};
                const gp = this.bgmConfig.gameplay || {};
                const stageCfg = stageTheme && stages[stageTheme] ? stages[stageTheme] : null;
                if (stageCfg && stageCfg.file) {
                    fileToPlay = stageCfg.file;
                    volToPlay = stageCfg.volume;
                    enabled = stageCfg.enabled !== false;
                } else {
                    fileToPlay = gp.file || 'ongame.mp3';
                    volToPlay = gp.volume;
                    enabled = gp.enabled !== false;
                    if (gp.scope === 'selected' && Array.isArray(gp.selected_stages)) {
                        if (!gp.selected_stages.includes(stageTheme)) {
                            enabled = false;
                        }
                    }
                }
            }

            if (fileToPlay || volToPlay !== undefined || !enabled) {
                this.gameplayBgm.setConfig(fileToPlay, volToPlay, enabled);
            }
            if (enabled) {
                this.gameplayBgm.play();
            } else {
                this.gameplayBgm.stop(true);
            }
        }

        stopGameplayBgm() {
            this.gameplayBgm.stop(true);
        }

        stopAll() {
            this.lobbyAmbient.stop(true);
            this.gameplayBgm.stop(true);
        }

        // --- Synthesized Web Audio SFX Helpers ---
        _tone(freq, dur = 0.08, type = 'sine', gainVal = 0.25, slideTo = null, delay = 0) {
            if (this.isMuted || this.isSfxMuted) return;
            const ctx = this.init();
            if (!ctx || !this.sfxGain) return;
            if (ctx.state === 'suspended' || ctx.state === 'interrupted') {
                ctx.resume().catch(() => {});
            }
            try {
                const t0 = ctx.currentTime + delay;
                const osc = ctx.createOscillator();
                const g = ctx.createGain();
                osc.type = type;
                osc.frequency.setValueAtTime(Math.max(40, freq), t0);
                if (slideTo) {
                    osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t0 + dur);
                }
                g.gain.setValueAtTime(0.0001, t0);
                g.gain.linearRampToValueAtTime(Math.max(0.001, gainVal), t0 + 0.008);
                g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
                osc.connect(g);
                g.connect(this.sfxGain);
                osc.start(t0);
                osc.stop(t0 + dur + 0.02);
            } catch (e) {}
        }

        playClick() {
            this._tone(680, 0.045, 'triangle', 0.18, 920);
        }

        playStep() {
            this._tone(420, 0.055, 'sine', 0.20, 560);
        }

        playDiceRoll() {
            for (let i = 0; i < 4; i++) {
                this._tone(260 + i * 75, 0.045, 'triangle', 0.16, 180 + i * 50, i * 0.055);
            }
        }

        playDiceLand() {
            this._tone(220, 0.09, 'triangle', 0.26, 110);
            this._tone(520, 0.06, 'sine', 0.14, 340, 0.02);
        }

        playWarp() {
            this._tone(320, 0.24, 'sine', 0.24, 980);
            this._tone(640, 0.20, 'triangle', 0.14, 1320, 0.04);
        }

        playLadder() {
            [440, 554, 659, 880].forEach((f, i) => {
                this._tone(f, 0.10, 'triangle', 0.20, null, i * 0.065);
            });
        }

        playSnake() {
            [580, 460, 340, 210].forEach((f, i) => {
                this._tone(f, 0.11, 'sawtooth', 0.14, f * 0.8, i * 0.07);
            });
        }

        playCoins() {
            this._tone(1046, 0.07, 'sine', 0.20, null, 0);
            this._tone(1318, 0.12, 'sine', 0.22, null, 0.06);
        }

        playCash() {
            this.playCoins();
        }

        playCityPop() {
            this._tone(392, 0.08, 'triangle', 0.22, 587);
            this._tone(784, 0.12, 'sine', 0.18, null, 0.05);
        }

        playBuyoutCity() {
            this._tone(523, 0.08, 'triangle', 0.22);
            this._tone(659, 0.08, 'triangle', 0.22, null, 0.07);
            this._tone(1046, 0.16, 'sine', 0.24, null, 0.14);
        }

        playBuildSuperLandmark() {
            [523, 659, 784, 1046, 1318].forEach((f, i) => {
                this._tone(f, 0.14, 'triangle', 0.22, null, i * 0.06);
            });
        }

        playLevelUp() {
            [523, 659, 784, 1046].forEach((f, i) => {
                this._tone(f, 0.12, 'sine', 0.22, null, i * 0.07);
            });
        }

        playWin() {
            [523, 659, 784, 1046, 1318].forEach((f, i) => {
                this._tone(f, 0.18, 'triangle', 0.24, null, i * 0.09);
            });
        }

        playVictory() {
            this.playWin();
        }

        playSuccess() {
            this._tone(587, 0.08, 'sine', 0.20, null, 0);
            this._tone(880, 0.14, 'sine', 0.22, null, 0.07);
        }

        playAlert() {
            this._tone(740, 0.09, 'square', 0.12, null, 0);
            this._tone(587, 0.12, 'square', 0.12, null, 0.10);
        }

        playNotification() {
            this._tone(880, 0.08, 'sine', 0.18, null, 0);
            this._tone(1174, 0.12, 'sine', 0.18, null, 0.08);
        }

        playNearFinish() {
            this._tone(659, 0.09, 'triangle', 0.20, null, 0);
            this._tone(880, 0.11, 'triangle', 0.22, null, 0.09);
        }

        playCardRevealZap(preset = 'zap_classic', isRare = false, volume = 0.85) {
            const g = Math.max(0.05, Math.min(0.4, (Number(volume) || 0.85) * 0.28));
            if (isRare) {
                this._tone(523, 0.09, 'triangle', g, 1046, 0);
                this._tone(784, 0.11, 'sine', g, 1568, 0.05);
                this._tone(1046, 0.18, 'sine', g * 1.1, null, 0.11);
            } else {
                this._tone(480, 0.07, 'triangle', g, 960, 0);
                this._tone(880, 0.09, 'sine', g * 0.8, null, 0.03);
            }
        }

        playEffect(name) {
            const key = String(name || '').toUpperCase();
            if (key === 'READY') {
                this.playSuccess();
                return true;
            }
            this.playClick();
            return true;
        }
    }

    const engine = new SoundEngine();
    window.soundEngine = engine;

    window.startLobbyAmbientSound = function () {
        engine.startLobbyAmbient();
    };

    window.stopLobbyAmbientSound = function () {
        engine.stopLobbyAmbient();
    };

    window.startGameplayBgm = function (stageTheme, customBgmFile, customVol) {
        engine.startGameplayBgm(stageTheme, customBgmFile, customVol);
    };

    window.stopGameplayBgm = function () {
        engine.stopGameplayBgm();
    };

    function syncSoundToggleButton() {
        const btn = document.getElementById('btn-toggle-sound');
        if (!btn) return;
        const muted = Boolean(engine.isMuted);
        btn.textContent = muted ? '🔇' : '🔊';
        btn.title = muted
            ? 'เปิด/ปิดเสียงเอฟเฟกต์ (ขณะนี้ปิดอยู่)'
            : 'เปิด/ปิดเสียงเอฟเฟกต์ (ขณะนี้เปิดอยู่)';
        btn.classList.toggle('is-muted', muted);
    }

    window.toggleSoundAction = function () {
        const nextMuted = !engine.isMuted;
        engine.setMasterMuted(nextMuted);
        if (window.ThaiAudio && typeof window.ThaiAudio.toggleMaster === 'function') {
            window.ThaiAudio.toggleMaster(!nextMuted);
        }
        syncSoundToggleButton();
        if (!nextMuted) {
            engine.unlock();
            engine.playClick();
        }
        if (typeof window.showToast === 'function') {
            window.showToast(nextMuted ? '🔇 ปิดเสียงเกมแล้ว' : '🔊 เปิดเสียงเกมแล้ว');
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', syncSoundToggleButton);
    } else {
        syncSoundToggleButton();
    }
})();
