/**
 * sound_engine.js - Master Web Audio Synthesizer, BGM Player & Hardware Audio Keep-Alive
 * 
 * ระบบเสียงหลักของเกมกระดานบันไดงูเศรษฐี 3D:
 * 1. ระบบ Audio Keep-Alive (Continuous Inaudible Carrier): รักษาสตรีมเสียง WASAPI ของ Windows
 *    และเบราว์เซอร์ Chrome/Edge ให้ตื่นอยู่เสมอ Hardware DAC จะไม่หลับ (Sleep Mode)
 *    ทำให้เสียงเอฟเฟกต์ (เดิน, ทอยเต๋า, ตกงู, ขึ้นบันได) ดังชัดเจนทันทีโดยไม่ต้องเปิดแท็บวิดีโอช่วย
 * 2. Gesture Auto-Unlock: ปลดล็อก AudioContext ทันทีที่ผู้ใช้แตะหรือคลิกหน้าจอครั้งแรก
 * 3. ปุ่มเปิด/ปิดเสียง (Mute Toggle) ที่แถบด้านบน
 * 4. ระบบเพลงประกอบทั้ง Lobby Ambient Sound และ Gameplay BGM
 */

(function() {
    /**
     * คำนวณระดับความดังตาม Perceptual Curve (Steven's Power Law)
     * เพื่อให้แถบเลื่อน 1% - 15% เบาและนุ่มนวลจริง ไม่กระแทกหู และไม่กลบเสียงพากย์หรือเอฟเฟกต์
     */
    function calcPerceptualBgmVolume(rawSliderValue, maxMasterCeiling = 0.40) {
        const v = Math.max(0, Math.min(1, Number(rawSliderValue) || 0));
        if (v <= 0) return 0;
        return Math.pow(v, 1.85) * maxMasterCeiling;
    }

    /**
     * ระบบเสียงบรรยากาศตอนเปิดเกมส์ (Lobby Ambient Sound / Opening Music)
     * - เล่นไฟล์ assets/audio/th/sound.mp3 (และ fallback dist/assets/audio/th/sound.mp3)
     * - เปิดวนทิ้งช่วง 1 วินาทีไปเรื่อยๆ (ended -> wait 1000ms -> play)
     * - เล่นเบาๆ (normalVolume = 0.22)
     * - Audio Ducking: เมื่อมีการทอยเต๋า หรือเอฟเฟกต์เสียงต่างๆ ให้ลดระดับเสียงลงชั่วคราว (duckVolume = 0.05)
     * - หยุดเล่นทันทีเมื่อเริ่มเล่นเกมส์ (isMatchActive === true)
     */
    class LobbyAmbientSound {
        constructor() {
            this.audio = null;
            this.sources = [
                'assets/audio/th/sound.mp3',
                'dist/assets/audio/th/sound.mp3'
            ];
            this.currentSrcIndex = 0;
            this.normalVolume = 0.22;
            this.duckVolume = 0.05;
            this.isDucked = false;
            this.duckTimeout = null;
            this.loopTimer = null;
            this.fadeInterval = null;
            this.isPlaying = false;
            this.manualStopped = false;
            this.gestureUnlocked = false;
        }

        init() {
            if (this.audio) return;
            try {
                this.audio = new Audio();
                this.audio.preload = 'auto';
                this.audio.loop = false; // ทิ้งช่วง 1 วินาทีเองผ่าน onended
                this.audio.volume = this.normalVolume;
                this.audio.src = this.sources[this.currentSrcIndex];

                this.audio.addEventListener('error', () => {
                    if (this.currentSrcIndex + 1 < this.sources.length) {
                        this.currentSrcIndex++;
                        this.audio.src = this.sources[this.currentSrcIndex];
                        if (this.isPlaying) {
                            this.audio.play().catch(() => {});
                        }
                    }
                });

                this.audio.addEventListener('ended', () => {
                    this.handleTrackEnded();
                });

                document.addEventListener('visibilitychange', () => {
                    if (document.hidden) {
                        if (this.audio && !this.audio.paused) {
                            this.audio.pause();
                        }
                    } else {
                        if (!this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isMuted)) {
                            this.play();
                        }
                    }
                });
            } catch (e) {
                console.warn('LobbyAmbientSound init error:', e);
            }
        }

        isMatchRunning() {
            if (window.soundEngine && typeof window.soundEngine.isMatchRunning === 'function') {
                return window.soundEngine.isMatchRunning();
            }
            return Boolean(window.game && window.game.isMatchActive && !window.game.isGameOver);
        }

        handleTrackEnded() {
            if (this.loopTimer) clearTimeout(this.loopTimer);
            if (this.isMatchRunning() || this.manualStopped || (window.soundEngine && window.soundEngine.isMuted)) {
                this.isPlaying = false;
                return;
            }

            // ทิ้งช่วง 1 วิ แล้วเริ่มเล่นใหม่ไปเรื่อยๆ
            this.loopTimer = setTimeout(() => {
                if (this.isMatchRunning() || this.manualStopped || (window.soundEngine && window.soundEngine.isMuted)) {
                    this.isPlaying = false;
                    return;
                }
                if (this.audio) {
                    this.audio.currentTime = 0;
                    this.audio.volume = this.isDucked ? this.duckVolume : this.normalVolume;
                    const p = this.audio.play();
                    if (p !== undefined) {
                        p.then(() => { this.isPlaying = true; }).catch(() => {});
                    }
                }
            }, 1000);
        }

        play() {
            if (this.isMatchRunning() || (window.soundEngine && (window.soundEngine.isBgmMuted || window.soundEngine.isMuted))) {
                return;
            }
            this.manualStopped = false;
            this.init();
            if (!this.audio) return;

            if (this.loopTimer) clearTimeout(this.loopTimer);
            if (!this.audio.src || this.audio.src === '' || this.audio.src === window.location.href) {
                this.audio.src = this.sources[this.currentSrcIndex] || this.sources[0];
            }

            this.audio.volume = this.isDucked ? this.duckVolume : this.normalVolume;
            const playPromise = this.audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    this.isPlaying = true;
                }).catch(() => {
                    this.setupUnlockOnGesture();
                });
            }
        }

        setupUnlockOnGesture() {
            if (this.gestureUnlocked) return;
            const unlockHandler = () => {
                this.gestureUnlocked = true;
                ['click', 'touchstart', 'keydown'].forEach(evt => {
                    document.removeEventListener(evt, unlockHandler, true);
                });
                if (!this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isMuted)) {
                    this.play();
                }
            };
            ['click', 'touchstart', 'keydown'].forEach(evt => {
                document.addEventListener(evt, unlockHandler, { capture: true, passive: true });
            });
        }

        stop(immediate = false) {
            this.manualStopped = true;
            this.isPlaying = false;
            if (this.loopTimer) clearTimeout(this.loopTimer);
            if (this.duckTimeout) clearTimeout(this.duckTimeout);
            if (!this.audio) return;

            if (immediate) {
                if (this.fadeInterval) clearInterval(this.fadeInterval);
                this.audio.pause();
                this.audio.currentTime = 0;
            } else {
                this.fadeToVolume(0, 300, () => {
                    if (this.audio) {
                        this.audio.pause();
                        this.audio.currentTime = 0;
                    }
                });
            }
        }

        duck(durationMs = 1500, targetDuckVol = null) {
            if (!this.audio || this.audio.paused || !this.isPlaying) return;
            this.isDucked = true;
            if (this.duckTimeout) clearTimeout(this.duckTimeout);

            const softDefaultDuck = Math.min(this.normalVolume * 0.55, Math.max(0.012, this.normalVolume * 0.28));
            const effectiveDuck = (typeof targetDuckVol === 'number' && targetDuckVol < this.normalVolume)
                ? Math.max(0.005, targetDuckVol)
                : softDefaultDuck;

            this.fadeToVolume(effectiveDuck, 80);
            this.duckTimeout = setTimeout(() => {
                this.isDucked = false;
                if (this.isPlaying && this.audio && !this.audio.paused) {
                    this.fadeToVolume(this.normalVolume, 350);
                }
            }, durationMs);
        }

        fadeToVolume(targetVol, durationMs = 200, callback = null) {
            if (!this.audio) return;
            if (this.fadeInterval) clearInterval(this.fadeInterval);

            const startVol = this.audio.volume;
            const diff = targetVol - startVol;
            const stepTime = 25;
            const steps = Math.max(1, Math.floor(durationMs / stepTime));
            let step = 0;

            this.fadeInterval = setInterval(() => {
                step++;
                const newVol = startVol + (diff * (step / steps));
                if (this.audio) {
                    this.audio.volume = Math.max(0, Math.min(1, newVol));
                }
                if (step >= steps) {
                    clearInterval(this.fadeInterval);
                    this.fadeInterval = null;
                    if (this.audio) this.audio.volume = Math.max(0, Math.min(1, targetVol));
                    if (typeof callback === 'function') callback();
                }
            }, stepTime);
        }
    }

    /**
     * ระบบเพลงประกอบระหว่างแข่งขันในกระดาน (Gameplay BGM Sound)
     * - รองรับการเลือกเพลงตามด่าน (Stage BGM) หรือใช้เพลงเริ่มต้น (ongame.mp3)
     * - รองรับ Audio Ducking อัตโนมัติเมื่อมีการทอยเต๋า หรือเสียงพากย์ขานแต้ม
     */
    class GameplayBgmSound {
        constructor() {
            this.audio = null;
            this.currentSrc = '';
            this.currentBoard = '';
            this.normalVolume = 0.20;
            this.duckVolume = 0.03;
            this.isDucked = false;
            this.duckTimeout = null;
            this.fadeInterval = null;
            this.isPlaying = false;
            this.manualStopped = false;
            this.gestureUnlocked = false;
        }

        init() {
            if (this.audio) return;
            try {
                this.audio = new Audio();
                this.audio.preload = 'auto';
                this.audio.loop = true; // เพลงกระดานเล่นวนลูปอัตโนมัติ
                this.audio.volume = this.normalVolume;

                this.audio.addEventListener('error', (err) => {
                    console.warn('GameplayBgm audio load error:', this.currentSrc, err);
                    if (this.currentSrc && !this.currentSrc.includes('ongame.mp3')) {
                        // Fallback ไปเพลงเริ่มต้น
                        this.currentSrc = 'assets/audio/th/ongame.mp3';
                        this.audio.src = this.currentSrc;
                        if (this.isPlaying) {
                            this.audio.play().catch(() => {});
                        }
                    }
                });

                document.addEventListener('visibilitychange', () => {
                    if (document.hidden) {
                        if (this.audio && !this.audio.paused) {
                            this.audio.pause();
                        }
                    } else {
                        if (this.isMatchRunning() && !this.manualStopped && (!window.soundEngine || !window.soundEngine.isBgmMuted)) {
                            this.play(this.currentBoard);
                        }
                    }
                });
            } catch (e) {
                console.warn('GameplayBgmSound init error:', e);
            }
        }

        isMatchRunning() {
            if (window.soundEngine && typeof window.soundEngine.isMatchRunning === 'function') {
                return window.soundEngine.isMatchRunning();
            }
            return Boolean(window.game && window.game.isMatchActive && !window.game.isGameOver);
        }

        attachAutoplayUnlock() {
            if (this.gestureUnlocked) return;
            const events = ['click', 'touchstart', 'keydown'];
            const unlock = () => {
                if (this.isPlaying && (!window.soundEngine || !window.soundEngine.isBgmMuted)) {
                    if (this.audio && this.audio.paused) {
                        const p = this.audio.play();
                        if (p !== undefined) {
                            p.then(() => {
                                this.gestureUnlocked = true;
                                events.forEach(evt => {
                                    window.removeEventListener(evt, unlock, true);
                                });
                            }).catch(() => {});
                        }
                    } else {
                        this.gestureUnlocked = true;
                        events.forEach(evt => {
                            window.removeEventListener(evt, unlock, true);
                        });
                    }
                }
            };
            events.forEach(evt => {
                window.addEventListener(evt, unlock, { capture: true, passive: true });
            });
        }

        play(boardThemeOrCode = '', customFile = '', customVol = null) {
            if (window.soundEngine && window.soundEngine.isBgmMuted) {
                this.isPlaying = false;
                return;
            }
            this.manualStopped = false;
            this.init();

            if (window.soundEngine && window.soundEngine.lobbyAmbient) {
                window.soundEngine.lobbyAmbient.stop(true);
            }

            this.currentBoard = boardThemeOrCode || this.currentBoard || '';
            let targetFile = customFile;
            let targetVol = customVol;

            const bgmCfg = (window.ThaiAudio && window.ThaiAudio.bgmConfig) || (window.soundEngine && window.soundEngine.bgmConfig);
            const boardKey = boardThemeOrCode || (window.game && (window.game.boardTheme || window.game.boardCode)) || 'classic';

            if (!targetFile && bgmCfg) {
                if (bgmCfg.stages && bgmCfg.stages[boardKey] && bgmCfg.stages[boardKey].file) {
                    targetFile = bgmCfg.stages[boardKey].file;
                    if (targetVol === null && typeof bgmCfg.stages[boardKey].volume === 'number') {
                        targetVol = bgmCfg.stages[boardKey].volume;
                    }
                } else if (bgmCfg.gameplay && bgmCfg.gameplay.file) {
                    targetFile = bgmCfg.gameplay.file;
                    if (targetVol === null && typeof bgmCfg.gameplay.volume === 'number') {
                        targetVol = bgmCfg.gameplay.volume;
                    }
                }
            }

            if (!targetFile) {
                targetFile = 'ongame.mp3';
            }
            if (targetVol === null) {
                targetVol = 0.20;
            }

            // คำนวณระดับเสียงตาม Perceptual Curve
            const userBgmVol = Math.max(0, Math.min(1, Number(localStorage.getItem('snake_bgm_volume') || 0.70)));
            const perceptualVol = calcPerceptualBgmVolume(targetVol, 0.40);
            this.normalVolume = Math.min(0.35, perceptualVol * userBgmVol);
            this.duckVolume = Math.max(0.0002, this.normalVolume * 0.15);

            let audioSrc = targetFile;
            if (!audioSrc.startsWith('http://') && !audioSrc.startsWith('https://') && !audioSrc.startsWith('/')) {
                audioSrc = `assets/audio/th/${targetFile}`;
            }

            if (!this.audio) return;

            if (this.currentSrc !== audioSrc || this.audio.src !== audioSrc) {
                this.currentSrc = audioSrc;
                this.audio.src = audioSrc;
                this.audio.currentTime = 0;
            }

            this.audio.volume = this.isDucked ? this.duckVolume : this.normalVolume;
            const playPromise = this.audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    this.isPlaying = true;
                }).catch(() => {
                    this.isPlaying = true;
                    this.attachAutoplayUnlock();
                });
            } else {
                this.isPlaying = true;
            }
        }

        stop(immediate = false) {
            this.manualStopped = true;
            this.isPlaying = false;
            if (this.duckTimeout) clearTimeout(this.duckTimeout);
            if (!this.audio) return;

            if (immediate) {
                if (this.fadeInterval) clearInterval(this.fadeInterval);
                this.audio.pause();
                this.audio.currentTime = 0;
            } else {
                this.fadeToVolume(0, 300, () => {
                    if (this.audio) {
                        this.audio.pause();
                        this.audio.currentTime = 0;
                    }
                });
            }
        }

        duck(durationMs = 1800, targetDuckVol = null) {
            if (!this.audio || this.audio.paused || !this.isPlaying) return;
            this.isDucked = true;
            if (this.duckTimeout) clearTimeout(this.duckTimeout);

            const relDuck = Math.min(this.normalVolume * 0.55, Math.max(0.010, this.normalVolume * 0.28));
            const effectiveDuck = (typeof targetDuckVol === 'number' && targetDuckVol < this.normalVolume)
                ? Math.max(0.005, Math.min(targetDuckVol, relDuck))
                : relDuck;

            this.fadeToVolume(effectiveDuck, 80);
            this.duckTimeout = setTimeout(() => {
                this.isDucked = false;
                if (this.isPlaying && this.audio && !this.audio.paused) {
                    this.fadeToVolume(this.normalVolume, 350);
                }
            }, durationMs);
        }

        fadeToVolume(targetVol, durationMs = 300, callback = null) {
            if (!this.audio) return;
            if (this.fadeInterval) clearInterval(this.fadeInterval);

            const startVol = this.audio.volume;
            const target = Math.max(0, Math.min(1, targetVol));
            const steps = Math.max(1, Math.floor(durationMs / 25));
            let currentStep = 0;

            this.fadeInterval = setInterval(() => {
                currentStep++;
                const ratio = currentStep / steps;
                const newVol = startVol + (target - startVol) * ratio;
                if (this.audio) {
                    this.audio.volume = Math.max(0, Math.min(1, newVol));
                }
                if (currentStep >= steps) {
                    clearInterval(this.fadeInterval);
                    this.fadeInterval = null;
                    if (this.audio) this.audio.volume = target;
                    if (typeof callback === 'function') callback();
                }
            }, 25);
        }
    }

    class SoundEngine {
        constructor() {
            this.ctx = null;
            this.masterGain = null;
            this.isMuted = localStorage.getItem('snake_sound_muted') === 'true';
            this.isBgmMuted = localStorage.getItem('snake_bgm_muted') === 'true';
            this.lobbyAmbient = new LobbyAmbientSound();
            this.gameplayBgm = new GameplayBgmSound();
            this.keepAliveNode = null;
            this.keepAliveGain = null;
            this.initialized = false;
            this.bgmConfig = null;
        }

        init() {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.init();
                this.startLobbyAmbient();
            }

            if (this.initialized && this.ctx) {
                if (this.ctx.state === 'suspended') {
                    this.ctx.resume().catch(() => {});
                }
                return;
            }

            try {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (!AudioCtx) return;
                this.ctx = new AudioCtx({ latencyHint: 'interactive' });

                this.masterGain = this.ctx.createGain();
                const sfxVol = Math.max(0, Math.min(1, Number(localStorage.getItem('snake_sfx_volume') || 0.85)));
                this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : sfxVol * 0.85, this.ctx.currentTime);
                this.masterGain.connect(this.ctx.destination);

                // Keep-Alive Inaudible Carrier Node: รักษาสัญญาณเสียงให้ฮาร์ดแวร์ DAC ในคอมพิวเตอร์ตื่นอยู่เสมอ
                try {
                    this.keepAliveNode = this.ctx.createOscillator();
                    this.keepAliveGain = this.ctx.createGain();
                    this.keepAliveNode.type = 'sine';
                    this.keepAliveNode.frequency.setValueAtTime(440, this.ctx.currentTime);
                    this.keepAliveGain.gain.setValueAtTime(0.00001, this.ctx.currentTime);
                    this.keepAliveNode.connect(this.keepAliveGain);
                    this.keepAliveGain.connect(this.masterGain);
                    this.keepAliveNode.start();
                } catch (e) {
                    console.warn('Audio keep-alive node error:', e);
                }

                this.initialized = true;
            } catch (e) {
                console.warn('Web Audio init error:', e);
            }
        }

        resume() {
            if (this.ctx && this.ctx.state === 'suspended') {
                this.ctx.resume().catch(() => {});
            }
            if (this.lobbyAmbient && !this.isBgmMuted && !this.lobbyAmbient.isPlaying && !this.isMatchRunning()) {
                this.lobbyAmbient.play();
            }
        }

        toggleMute() {
            this.resume();
            this.isMuted = !this.isMuted;
            localStorage.setItem('snake_sound_muted', this.isMuted ? 'true' : 'false');
            if (this.masterGain && this.ctx) {
                const sfxVol = Math.max(0, Math.min(1, Number(localStorage.getItem('snake_sfx_volume') || 0.85)));
                this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : sfxVol * 0.85, this.ctx.currentTime);
            }
            this.updateToggleButton();
            if (!this.isMuted) {
                this.playClick();
            }
        }

        setMute(muted) {
            this.resume();
            this.isMuted = Boolean(muted);
            localStorage.setItem('snake_sound_muted', this.isMuted ? 'true' : 'false');
            if (this.masterGain && this.ctx) {
                const sfxVol = Math.max(0, Math.min(1, Number(localStorage.getItem('snake_sfx_volume') || 0.85)));
                this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : sfxVol * 0.85, this.ctx.currentTime);
            }
            this.updateToggleButton();
        }

        setMuted(muted) {
            return this.setMute(muted);
        }

        setSfxVolume(vol) {
            this.resume();
            const v = Math.max(0, Math.min(1, Number(vol) || 0.85));
            localStorage.setItem('snake_sfx_volume', v);
            if (this.masterGain && this.ctx && !this.isMuted) {
                this.masterGain.gain.setValueAtTime(v * 0.85, this.ctx.currentTime);
            }
        }

        setBgmVolume(vol) {
            this.resume();
            const v = Math.max(0, Math.min(1, Number(vol) || 0.70));
            localStorage.setItem('snake_bgm_volume', v);
            if (this.lobbyAmbient) {
                const baseLobby = this.bgmConfig?.lobby?.volume ?? 0.25;
                this.lobbyAmbient.normalVolume = Math.min(0.40, calcPerceptualBgmVolume(baseLobby, 0.45) * v);
                this.lobbyAmbient.duckVolume = Math.min(this.lobbyAmbient.normalVolume * 0.55, Math.max(0.012, this.lobbyAmbient.normalVolume * 0.28));
                if (this.lobbyAmbient.audio && !this.isBgmMuted) {
                    this.lobbyAmbient.audio.volume = this.lobbyAmbient.isDucked ? this.lobbyAmbient.duckVolume : this.lobbyAmbient.normalVolume;
                }
            }
            if (this.gameplayBgm) {
                const baseVol = this.bgmConfig?.gameplay?.volume ?? 0.20;
                this.gameplayBgm.normalVolume = Math.min(0.35, calcPerceptualBgmVolume(baseVol, 0.40) * v);
                this.gameplayBgm.duckVolume = Math.min(this.gameplayBgm.normalVolume * 0.55, Math.max(0.010, this.gameplayBgm.normalVolume * 0.28));
                if (this.gameplayBgm.audio && !this.isBgmMuted && this.gameplayBgm.isPlaying) {
                    this.gameplayBgm.audio.volume = this.gameplayBgm.isDucked ? this.gameplayBgm.duckVolume : this.gameplayBgm.normalVolume;
                }
            }
        }

        setBgmMute(muted) {
            this.resume();
            this.isBgmMuted = Boolean(muted);
            localStorage.setItem('snake_bgm_muted', this.isBgmMuted ? 'true' : 'false');
            if (this.lobbyAmbient) {
                if (this.isBgmMuted) {
                    this.lobbyAmbient.stop();
                } else if (!this.lobbyAmbient.isMatchRunning()) {
                    this.lobbyAmbient.play();
                }
            }
            if (this.gameplayBgm) {
                if (this.isBgmMuted) {
                    this.gameplayBgm.stop();
                } else if (this.gameplayBgm.isMatchRunning()) {
                    this.gameplayBgm.play(this.gameplayBgm.currentBoard);
                }
            }
        }

        setBgmMuted(muted) {
            return this.setBgmMute(muted);
        }

        isMatchRunning() {
            const hasGame = Boolean(window.game && window.game.isMatchActive && !window.game.isGameOver);
            const isBgmActive = Boolean(this.gameplayBgm && this.gameplayBgm.isPlaying);
            return hasGame || isBgmActive;
        }

        startLobbyAmbient() {
            if (this.isMatchRunning()) {
                this.stopLobbyAmbient();
                return;
            }
            if (this.lobbyAmbient && !this.isBgmMuted) {
                this.lobbyAmbient.play();
            }
        }

        stopLobbyAmbient() {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.stop(true);
            }
        }

        duckLobbyAmbient(durationMs = 1500, duckVol = null) {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.duck(durationMs, duckVol);
            }
        }

        startGameplayBgm(boardKey = '', customFile = '', customVol = null) {
            this.stopLobbyAmbient();
            if (this.gameplayBgm && !this.isBgmMuted) {
                this.gameplayBgm.play(boardKey, customFile, customVol);
            }
        }

        stopGameplayBgm() {
            if (this.gameplayBgm) {
                this.gameplayBgm.stop(true);
            }
        }

        stopAll() {
            this.stopGameplayBgm();
            this.stopLobbyAmbient();
        }

        duckGameplayBgm(durationMs = 1800, duckVol = null) {
            if (this.gameplayBgm) {
                this.gameplayBgm.duck(durationMs, duckVol);
            }
        }

        duckAllBgm(durationMs = 2000, duckVol = null) {
            if (this.lobbyAmbient) {
                this.lobbyAmbient.duck(durationMs, duckVol);
            }
            if (this.gameplayBgm) {
                this.gameplayBgm.duck(durationMs, duckVol);
            }
        }

        updateBgmSettings(cfg) {
            if (!cfg || typeof cfg !== 'object') return;
            this.bgmConfig = cfg;
            const userBgmVol = Math.max(0, Math.min(1, Number(localStorage.getItem('snake_bgm_volume') || 0.70)));
            if (cfg.lobby && this.lobbyAmbient) {
                if (cfg.lobby.file) {
                    const lobbySrc = (cfg.lobby.file.startsWith('http://') || cfg.lobby.file.startsWith('/')) ? cfg.lobby.file : `assets/audio/th/${cfg.lobby.file}`;
                    this.lobbyAmbient.sources = [lobbySrc];
                    if (this.lobbyAmbient.audio) {
                        this.lobbyAmbient.audio.src = lobbySrc;
                    }
                }
                if (typeof cfg.lobby.volume === 'number') {
                    this.lobbyAmbient.normalVolume = Math.min(0.40, calcPerceptualBgmVolume(cfg.lobby.volume, 0.45) * userBgmVol);
                    this.lobbyAmbient.duckVolume = Math.max(0.0005, this.lobbyAmbient.normalVolume * 0.15);
                    if (this.lobbyAmbient.audio && !this.isBgmMuted && !this.lobbyAmbient.isDucked) {
                        this.lobbyAmbient.audio.volume = this.lobbyAmbient.normalVolume;
                    }
                }
            }
            if (cfg.gameplay && this.gameplayBgm) {
                if (typeof cfg.gameplay.volume === 'number') {
                    this.gameplayBgm.normalVolume = Math.min(0.35, calcPerceptualBgmVolume(cfg.gameplay.volume, 0.40) * userBgmVol);
                    this.gameplayBgm.duckVolume = Math.max(0.0002, this.gameplayBgm.normalVolume * 0.15);
                    if (this.gameplayBgm.audio && !this.isBgmMuted && this.gameplayBgm.isPlaying && !this.gameplayBgm.isDucked) {
                        this.gameplayBgm.audio.volume = this.gameplayBgm.normalVolume;
                    }
                }
                if (this.gameplayBgm.isPlaying) {
                    this.gameplayBgm.play(this.gameplayBgm.currentBoard);
                }
            }
        }

        updateToggleButton() {
            const btn = document.getElementById('btn-toggle-sound');
            if (btn) {
                btn.innerHTML = this.isMuted ? '🔇' : '🔊';
                btn.title = this.isMuted ? 'เปิดเสียงเอฟเฟกต์ (ขณะนี้ปิดอยู่)' : 'ปิดเสียงเอฟเฟกต์ (ขณะนี้เปิดอยู่)';
                btn.style.opacity = this.isMuted ? '0.5' : '1';
            }
        }

        // 1. เสียงก้าวเดินตัวหมาก (Step Pop)
        playStep() {
            if (this.isMuted) return;
            // หากแอดมินตั้งค่าเสียงก้าวเดินใน Admin Panel ไว้ ให้ใช้เสียงของแอดมินแทน oscillator pop สังเคราะห์
            if (window.ThaiAudio && typeof window.ThaiAudio.isEventPlayable === 'function' && window.ThaiAudio.isEventPlayable('step')) {
                return;
            }
            this.duckAllBgm(500);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(480, now);
                osc.frequency.exponentialRampToValueAtTime(780, now + 0.05);
                gain.gain.setValueAtTime(0.28, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.13);
            } catch (e) {}
        }

        // 2. เสียงเขย่าทอยลูกเต๋า (Dice Roll Rattle)
        playDiceRoll() {
            if (this.isMuted) return;
            // หากแอดมินตั้งค่าเสียงทอยเต๋าใน Admin Panel ไว้ ให้ใช้เสียงของแอดมินแทน synthetic noise
            if (window.ThaiAudio && typeof window.ThaiAudio.isEventPlayable === 'function' && window.ThaiAudio.isEventPlayable('dice_roll')) {
                return;
            }
            this.duckAllBgm(1600);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                // สร้าง synthetic dice rattle noise
                const bufferSize = this.ctx.sampleRate * 0.45;
                const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
                const data = buffer.getChannelData(0);
                for (let i = 0; i < bufferSize; i++) {
                    data[i] = Math.random() * 2 - 1;
                }
                const noise = this.ctx.createBufferSource();
                noise.buffer = buffer;
                const filter = this.ctx.createBiquadFilter();
                filter.type = 'bandpass';
                filter.frequency.setValueAtTime(1400, this.ctx.currentTime);
                filter.Q.setValueAtTime(3.5, this.ctx.currentTime);

                const gain = this.ctx.createGain();
                gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.45);

                noise.connect(filter);
                filter.connect(gain);
                gain.connect(this.masterGain);
                noise.start();
            } catch (e) {}
        }

        // 3. เสียงลูกเต๋าตกกระทบพื้น (Dice Land Clack)
        playDiceLand() {
            if (this.isMuted) return;
            this.duckAllBgm(800);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                // Double clack
                [0, 0.045].forEach((delay, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'triangle';
                    const freq = idx === 0 ? 320 : 420;
                    osc.frequency.setValueAtTime(freq, now + delay);
                    gain.gain.setValueAtTime(0.25, now + delay);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.06);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(now + delay);
                    osc.stop(now + delay + 0.07);
                });
            } catch (e) {}
        }

        // 4. เสียงปีนบันได (Ladder Climb Musical Arpeggio)
        playLadder() {
            if (this.isMuted) return;
            this.duckAllBgm(1800);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
                const now = this.ctx.currentTime;
                notes.forEach((freq, idx) => {
                    const t = now + idx * 0.18;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.26, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.3);
                });
            } catch (e) {}
        }

        // 5. เสียงงูกัดและสไลด์ตัวลง (Snake Bite Drop)
        playSnake() {
            if (this.isMuted) return;
            this.duckAllBgm(1800);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(450, now);
                osc.frequency.exponentialRampToValueAtTime(120, now + 0.4);
                osc.frequency.exponentialRampToValueAtTime(55, now + 0.8);
                gain.gain.setValueAtTime(0.32, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.9);
            } catch (e) {}
        }

        // 5.1 เสียงงูและบันไดสลับตำแหน่งและเปลี่ยนสี (Magical Warp Shuffle)
        playWarp() {
            if (this.isMuted) return;
            this.duckAllBgm(2000);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [392.00, 523.25, 659.25, 783.99, 1046.50, 1318.51];
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.07;
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, t);
                    osc.frequency.exponentialRampToValueAtTime(freq * 1.5, t + 0.25);
                    gain.gain.setValueAtTime(0.24, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.38);
                });
            } catch (e) {}
        }

        // 6. เสียงเตือนตาเดินของคุณ (Your Turn Bell Chime)
        playTurnBell() {
            if (this.isMuted) return;
            this.duckAllBgm(1200);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                [880, 1760].forEach((freq) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, now);
                    gain.gain.setValueAtTime(0.30, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(now);
                    osc.stop(now + 0.65);
                });
            } catch (e) {}
        }

        // 6.1 เสียงยินดีชนะเลิศ (Victory Fanfare Chime)
        playWin() {
            if (this.isMuted) return;
            this.duckAllBgm(3500);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [261.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.12;
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.35, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.42);
                });
            } catch (e) {}
        }

        // 7. เสียงคลิกปุ่ม UI (Click Sound)
        playClick() {
            if (this.isMuted) return;
            this.duckAllBgm(350);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(900, now);
                osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
                gain.gain.setValueAtTime(0.18, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.045);
            } catch (e) {}
        }

        // 8. เสียงเดินผ่านเมือง/ช่องกระดานแล้วนูนขึ้น (City Pop Bounce)
        playCityPop() {
            if (this.isMuted) return;
            this.duckAllBgm(600);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(360, now);
                osc.frequency.exponentialRampToValueAtTime(680, now + 0.07);
                gain.gain.setValueAtTime(0.14, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.10);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.11);
            } catch (e) {}
        }

        // 9. เสียงสัญญาณเตือนภัยใกล้ถึงเส้นชัย 5-8 ช่อง (Near Finish Alert Fanfare)
        playNearFinish() {
            if (this.isMuted) return;
            this.duckAllBgm(1800);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.08;
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.22, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.35);
                });
            } catch (e) {}
        }

        // 10. เสียงสัญญาณแจ้งเตือนเมื่อมีคน @ พูดถึงคุณ (Mention Notification Chime)
        playNotification() {
            if (this.isMuted) return;
            this.duckAllBgm(1400);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const notes = [659.25, 987.77]; // E5, B5 (Ding-Dong!)
                notes.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const t = now + idx * 0.12;
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, t);
                    gain.gain.setValueAtTime(0.25, t);
                    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
                    osc.connect(gain);
                    gain.connect(this.masterGain);
                    osc.start(t);
                    osc.stop(t + 0.40);
                });
            } catch (e) {}
        }

        // Helper aliases
        playVictory() {
            return this.playWin();
        }

        playLevelUp() {
            return this.playWin();
        }

        playSuccess() {
            return this.playWin();
        }

        playAlert() {
            return this.playNearFinish();
        }

        playBuyoutCity() {
            return this.playCityPop();
        }

        playBuildSuperLandmark() {
            return this.playWin();
        }

        playCardRevealZap(preset = 'zap_classic', isRare = false, vol = 0.85) {
            if (this.isMuted) return;
            this.duckAllBgm(1200);
            this.resume();
            if (!this.ctx || !this.masterGain) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = isRare ? 'sawtooth' : 'sine';
                osc.frequency.setValueAtTime(isRare ? 700 : 520, now);
                osc.frequency.exponentialRampToValueAtTime(isRare ? 1400 : 1040, now + 0.15);
                gain.gain.setValueAtTime((vol || 0.85) * 0.30, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
                osc.connect(gain);
                gain.connect(this.masterGain);
                osc.start(now);
                osc.stop(now + 0.20);
            } catch (e) {}
        }

        playEffect(effectName) {
            const name = String(effectName || '').toUpperCase();
            if (name === 'CLICK' || name === 'READY') {
                return this.playClick();
            }
            if (name === 'WIN' || name === 'VICTORY') {
                return this.playWin();
            }
            if (name === 'STEP') {
                return this.playStep();
            }
            if (name === 'DICE') {
                return this.playDiceRoll();
            }
            return this.playClick();
        }
    }

    const soundEngine = new SoundEngine();
    window.soundEngine = soundEngine;
    window.soundManager = soundEngine; // Alias

    // Global helper shortcuts for backward compatibility
    window.playLobbyAmbientSound = function() {
        soundEngine.startLobbyAmbient();
    };

    window.stopLobbyAmbientSound = function() {
        soundEngine.stopLobbyAmbient();
    };

    window.duckLobbyAmbientSound = function(durationMs, duckVol) {
        soundEngine.duckLobbyAmbient(durationMs, duckVol);
    };

    window.playGameplayBgm = function(boardKey, customFile, customVol) {
        soundEngine.startGameplayBgm(boardKey, customFile, customVol);
    };

    window.stopGameplayBgm = function() {
        soundEngine.stopGameplayBgm();
    };

    window.duckGameplayBgm = function(durationMs, duckVol) {
        soundEngine.duckGameplayBgm(durationMs, duckVol);
    };

    window.duckAllBgm = function(durationMs, duckVol) {
        soundEngine.duckAllBgm(durationMs, duckVol);
    };

    // ปลดล็อกระบบเสียงทันทีเมื่อผู้ใช้แตะหรือคลิกหน้าจอครั้งแรก
    const unlockEvents = ['pointerdown', 'click', 'touchstart', 'keydown', 'mousedown'];
    const unlockHandler = function() {
        soundEngine.init();
        soundEngine.resume();
        soundEngine.startLobbyAmbient();
        if (window.ThaiAudio && typeof window.ThaiAudio.unlock === 'function') {
            window.ThaiAudio.unlock();
        }
    };
    unlockEvents.forEach(evt => {
        document.addEventListener(evt, unlockHandler, { capture: true, passive: true });
        window.addEventListener(evt, unlockHandler, { capture: true, passive: true });
    });

    // เริ่มต้นสถานะปุ่มและเปิดเสียงบรรยากาศตอนเปิดเกมส์
    function bootSoundEngine() {
        soundEngine.updateToggleButton();
        soundEngine.init();
        soundEngine.startLobbyAmbient();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootSoundEngine);
    } else {
        bootSoundEngine();
    }
})();