/**
 * sound_engine.js - Master Web Audio Synthesizer, BGM Player & Hardware Audio Keep-Alive
 * 
 * ระบบเสียงหลักของเกมกระดานบันไดงูเศรษฐี 3D:
 * 1. ระบบ Audio Keep-Alive (Continuous Inaudible Carrier): รักษาสตรีมเสียง WASAPI ของ Windows
 *    และเบราว์เซอร์ Chrome/Edge ให้ตื่นอยู่เสมอ Hardware DAC จะไม่หลับ (Sleep Mode)
 *    ทำให้เสียงเอฟเฟกต์ (เดิน, ทอยเต๋า, ตกงู, ขึ้นบันได) ดังชัดเจนทันทีโดยไม่ต้องเปิดแท็บวิดีโอช่วย
 * 2. Gesture Auto-Unlock: ปลดล็อก AudioContext ทันทีที่ผู้ใช้แตะหรือคลิกหน้าจอครั้งแรก
 * 3. ปุ่มเปิด/ปิดเสียง (Mute Toggle) ที่แถบด้านบน
 * 4. ระบบเพลงประกอบทั้ง Lobby Ambient Sound และ Gameplay BGM
 */

(function() {
    /**
     * คำนวณระดับความดังตาม Perceptual Curve (Steven's Power Law)
     * เพื่อให้แถบเลื่อน 1% - 15% เบาและนุ่มนวลจริง ไม่กระแทกหู และไม่กลบเสียงพากย์หรือเอฟเฟกต์
     */
    function calcPerceptualBgmVolume(rawSliderValue, maxMasterCeiling = 0.40) {
        const v = Math.max(0, Math.min(1, Number(rawSliderValue) || 0));
        if (v <= 0) return 0;
        return Math.pow(v, 1.85) * maxMasterCeiling;
    }

    /**
     * ระบบเสียงบรรยากาศตอนเปิดเกมส์ (Lobby Ambient Sound / Opening Music)
     * - เล่นไฟล์ assets/audio/th/sound.mp3 (และ fallback dist/assets/audio/th/sound.mp3)
     * - เปิดวนทิ้งช่วง 1 วินาทีไปเรื่อยๆ (ended -> wait 1000ms -> play)
     * - เล่นเบาๆ (normalVolume = 0.22)
     * - Audio Ducking: เมื่อมีการทอยเต๋า หรือเอฟเฟกต์เสียงต่างๆ ให้ลดระดับเสียงลงชั่วคราว (duckVolume = 0.05)
     * - หยุดเล่นทันทีเมื่อเริ่มเล่นเกมส์ (isMatchActive === true)
     */
    class LobbyAmbientSound {
        constructor() {
            this.audio = null;
            this.sources = [
                'assets/audio/th/sound.mp3',
                'dist/assets/audio/th/sound.mp3'
            ];
            this.currentSrcIndex = 0;
            this.normalVolume = 0.22;
            this.duckVolume = 0.05;
            this.isDucked = false;
            this.duckTimeout = null;
            this.loopTimer = null;
            this.fadeInterval = null;
            this.isPlaying = false;
            this.manualStopped = false;
            this.gestureUnlocked = false;
        }

        init() {
            if (this.audio) return;
            try {
                this.audio = new Audio();
                this.audio.preload = 'auto';
                this.audio.loop = false; // ทิ้งช่วง 1 วินาทีเองผ่าน onended
                this.audio.volume = this.normalVolume;
                this.audio.src = this.sources[this.currentSrcIndex];

                this.audio.addEventListener('error', () => {
                    if (this.currentSrcIndex + 1 < this.sources.length) {
                        this.currentSrcIndex++;
                        this.audio.src = this.sources[this.currentSrcIndex];
                        if (this.isPlaying) {
                            this.audio.play().catch(() => {});
                        }
                    }
                });

                t