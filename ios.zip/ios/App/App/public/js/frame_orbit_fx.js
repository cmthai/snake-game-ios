/**
 * 🌟 Frame Orbit FX Engine — ลูกเล่นวัตถุบิน/หมุนวนรอบกรอบสี่เหลี่ยม 50 รูปแบบ
 * ใช้ร่วมกันทั้ง Admin Panel (พรีวิว) และตัวเกม (Top Bar / คลังกรอบ / หน้าตรวจสอบกรอบ)
 *
 * การใช้งาน:
 *   FrameOrbitFX.html('snow_crystals')            -> string HTML (ใส่ใน container ที่ position:relative)
 *   FrameOrbitFX.render(containerEl, 'butterflies_neon')  -> แทรก/แทนที่ layer เดิมใน container
 *   FrameOrbitFX.label('firefly_glow')            -> ชื่อภาษาไทย
 *
 * motion:
 *   orbit   = เคลื่อนที่วนตามขอบสี่เหลี่ยม
 *   flutter = วนตามขอบ + กระพือ/ส่ายตัว (ผีเสื้อ, ค้างคาว, ผึ้ง)
 *   fall    = ร่วงหล่นจากบนลงล่างพร้อมส่ายไปมา (หิมะ, กลีบดอกไม้)
 *   rise    = ลอยขึ้นจากล่างขึ้นบน (ฟองหัวใจ, ประกายไฟ)
 *   twinkle = กะพริบวิบวับตามจุดรอบขอบกรอบ (ดาว, เพชร)
 *   wander  = ล่องลอยไปมาแบบสุ่มรอบกรอบ + กะพริบ (หิ่งห้อย)
 */
(function (global) {
    'use strict';

    // g = glyph list (emoji / text), dot = วาดเป็นจุดแสงกลมแทนตัวอักษร, c = สี/แสง, n = จำนวน, d = วินาทีต่อรอบ
    const P = {
        // ❄️ ธรรมชาติ & อากาศ
        snow_crystals:     { t: '❄️ หิมะคริสตัลขาวโปรยปราย',        g: ['❄', '❅', '❆'], c: '#e0f2fe', m: 'fall',    n: 12, d: 6 },
        firefly_glow:      { t: '✨ หิ่งห้อยแสงเรืองสีทองกะพริบ',    dot: true,            c: '#fde047', m: 'wander',  n: 12, d: 4 },
        cherry_blossom:    { t: '🌸 กลีบซากุระชมพูพลิ้วไหว',          g: ['🌸'],            c: '#f9a8d4', m: 'fall',    n: 9,  d: 7 },
        autumn_leaves:     { t: '🍁 ใบไม้ร่วงสีเพลิง',               g: ['🍁', '🍂'],      c: '#f97316', m: 'fall',    n: 9,  d: 7 },
        water_droplets:    { t: '💧 ละอองน้ำค้างวารีประกาย',          g: ['💧'],            c: '#38bdf8', m: 'fall',    n: 9,  d: 3.5 },
        wind_breeze:       { t: '🍃 สายลมพัดใบไม้เขียวขจี',           g: ['🍃'],            c: '#4ade80', m: 'orbit',   n: 6,  d: 5 },
        rain_drizzle:      { t: '🌧️ หยาดฝนคริสตัลส่องแสง',            g: ['╎'],             c: '#7dd3fc', m: 'fall',    n: 16, d: 1.6 },
        sun_flare:         { t: '☀️ ละอองสุริยะประกายเพลิง',          dot: true,            c: '#fb923c', m: 'twinkle', n: 12, d: 2.2 },
        dandelion_puff:    { t: '🌾 ปุยดอกแดนดิไลออนลอยลม',          g: ['❋', '✻'],        c: '#f8fafc', m: 'rise',    n: 9,  d: 7 },
        rose_petals:       { t: '🌹 กลีบกุหลาบแดงแห่งความรัก',        g: ['🌹', '🥀'],      c: '#e11d48', m: 'fall',    n: 8,  d: 7 },

        // 🦋 สัตว์วิเศษ & สิ่งมีชีวิต
        butterflies_neon:  { t: '🦋 ฝูงผีเสื้อราตรีนีออนบินวน',       g: ['🦋'],            c: '#60a5fa', m: 'flutter', n: 5,  d: 9 },
        golden_butterflies:{ t: '✨ ผีเสื้อทองคำบินร่ายรำ',            g: ['🦋'],            c: '#facc15', m: 'flutter', n: 5,  d: 9, f: 'sepia(1) saturate(4) hue-rotate(-15deg) brightness(1.15)' },
        blue_dragonfly:    { t: '🪰 แมลงปอครามประกายแสง',             g: ['🪰'],            c: '#22d3ee', m: 'flutter', n: 4,  d: 6 },
        spirit_birds:      { t: '🕊️ นกวิญญาณขาวบริสุทธิ์',            g: ['🕊️'],            c: '#ffffff', m: 'flutter', n: 4,  d: 8 },
        fairy_pixies:      { t: '🧚 แฟรี่ภูตจิ๋วพร้อมผงวิเศษ',         g: ['🧚', '✨'],      c: '#f0abfc', m: 'flutter', n: 6,  d: 8 },
        deepsea_jellyfish: { t: '🪼 แมงกะพรุนเรืองแสงใต้สมุทร',        g: ['🪼'],            c: '#a78bfa', m: 'rise',    n: 6,  d: 8 },
        phoenix_feathers:  { t: '🪶 ขนนกฟีนิกซ์เพลิงอมตะ',             g: ['🪶'],            c: '#f97316', m: 'orbit',   n: 6,  d: 7, f: 'sepia(1) saturate(5) hue-rotate(-30deg)' },
        koi_fish:          { t: '🐟 ปลาคราฟทองแหวกว่ายรอบกรอบ',       g: ['🐠', '🐟'],      c: '#fbbf24', m: 'orbit',   n: 4,  d: 9 },
        bat_swarm:         { t: '🦇 ฝูงค้างคาวรัตติกาลลึกลับ',         g: ['🦇'],            c: '#a855f7', m: 'flutter', n: 6,  d: 6 },
        bee_pollen:        { t: '🐝 ผึ้งทองคำและละอองเกสร',            g: ['🐝'],            c: '#facc15', m: 'flutter', n: 5,  d: 6 },

        // 💎 อัญมณี หิน & แร่ธาตุ
        floating_rocks:    { t: '🪨 เศษหินลอยเคว้ง (Antigravity)',     g: ['🪨'],            c: '#a8a29e', m: 'orbit',   n: 6,  d: 14, spin: true },
        ruby_gems:         { t: '💎 ทับทิมสีแดงเจิดจรัส',              g: ['💎'],            c: '#ef4444', m: 'orbit',   n: 6,  d: 10, f: 'hue-rotate(140deg) saturate(2)', spin: true },
        diamond_shards:    { t: '💠 เศษประกายเพชรประกายรุ้ง',          g: ['💠', '✧'],       c: '#e0f2fe', m: 'twinkle', n: 10, d: 2.4 },
        emerald_crystals:  { t: '❇️ ผลึกมรกตเรืองแสงสีเขียว',          g: ['❇️'],            c: '#34d399', m: 'orbit',   n: 6,  d: 10, spin: true },
        gold_nuggets:      { t: '🪙 ก้อนทองคำและเหรียญกษาปณ์',         g: ['🪙'],            c: '#fbbf24', m: 'orbit',   n: 6,  d: 9, spin: true },
        amethyst_clusters: { t: '🔮 ผลึกอเมทิสต์ม่วงเวทมนตร์',          g: ['🔮'],            c: '#c084fc', m: 'orbit',   n: 5,  d: 11, spin: true },
        sapphire_ice:      { t: '🧊 ผลึกไพลินน้ำแข็งแช่แข็ง',          g: ['🧊'],            c: '#7dd3fc', m: 'orbit',   n: 6,  d: 11, spin: true },
        amber_stones:      { t: '🟤 หินอำพันโบราณกะพริบ',              dot: true,            c: '#d97706', m: 'orbit',   n: 8,  d: 10 },
        pearl_orbs:        { t: '⚪ ไข่มุกราตรีเรืองแสงนวล',            dot: true,            c: '#f8fafc', m: 'rise',    n: 9,  d: 6 },
        obsidian_shards:   { t: '⬛ เศษหินออบซิเดียนสีดำขลับ',          g: ['◆', '⬥'],        c: '#6366f1', m: 'orbit',   n: 8,  d: 12, gc: '#0f0f17', spin: true },

        // ⭐ อวกาศ ดวงดาว & กาแล็กซี
        sparkle_stars:     { t: '⭐ ประกายดาวระยิบระยับ',              g: ['✦', '⭐', '✧'],  c: '#fde047', m: 'twinkle', n: 12, d: 2.2 },
        shooting_stars:    { t: '🌠 ดาวตกพุ่งผ่านรอบกรอบ',             g: ['🌠'],            c: '#fef08a', m: 'orbit',   n: 3,  d: 3 },
        orbiting_planets:  { t: '🪐 ดาวเคราะห์จิ๋วโคจรรอบกรอบ',        g: ['🪐', '🌍', '🌕'],c: '#93c5fd', m: 'orbit',   n: 3,  d: 12 },
        moon_crescents:    { t: '🌙 เสี้ยวจันทราเงินส่องประกาย',        g: ['🌙'],            c: '#fef9c3', m: 'orbit',   n: 4,  d: 10 },
        stardust_glitter:  { t: '✨ ผงละอองดวงดาวสีทอง',               dot: true,            c: '#fcd34d', m: 'twinkle', n: 18, d: 1.8 },
        cosmic_meteor:     { t: '☄️ อุกกาบาตดาวหางหางยาว',             g: ['☄️'],            c: '#fb923c', m: 'orbit',   n: 2,  d: 3.2 },
        solar_system:      { t: '🌌 มินิระบบสุริยะโคจรรอบ',            g: ['☀️', '🌍', '🪐', '🌑', '🔴'], c: '#fbbf24', m: 'orbit', n: 5, d: 14 },
        rainbow_prism:     { t: '🌈 แสงปริซึมสะท้อน 7 สี',             dot: true, rainbow: true, c: '#ffffff', m: 'orbit', n: 14, d: 6 },
        blackhole_vortex:  { t: '🌀 หลุมดำดูดละอองมวลสาร',             dot: true,            c: '#a855f7', m: 'orbit',   n: 16, d: 3, rev: true },
        supernova_burst:   { t: '💥 แสงวาบซูเปอร์โนวารอบกรอบ',         g: ['💥', '✺'],       c: '#f472b6', m: 'twinkle', n: 8,  d: 2.6 },

        // ⚔️ เวทมนตร์ สงคราม & แฟนตาซี
        flame_sparks:      { t: '🔥 ประกายลูกไฟเถ้าถ่านเพลิง',          g: ['🔥'],            c: '#f97316', m: 'rise',    n: 9,  d: 3.5 },
        electric_bolts:    { t: '⚡ สะเก็ดสายฟ้าฟาดเปรี๊ยะ',            g: ['⚡'],            c: '#38bdf8', m: 'twinkle', n: 8,  d: 1.4 },
        magic_runes:       { t: '🔤 อักษรรูนเวทมนตร์โบราณลอยวน',       g: ['ᚠ', 'ᚢ', 'ᚦ', 'ᚨ', 'ᚱ', 'ᚲ', 'ᛟ', 'ᛉ'], c: '#22d3ee', m: 'orbit', n: 8, d: 12 },
        golden_coins:      { t: '💰 เหรียญทองคำหล่นรอบกรอบ',           g: ['🪙', '💰'],      c: '#facc15', m: 'fall',    n: 8,  d: 4 },
        heart_bubbles:     { t: '💖 หัวใจฟองสบู่สีชมพูหวาน',            g: ['💖', '💕', '💗'],c: '#f472b6', m: 'rise',    n: 9,  d: 5 },
        music_notes:       { t: '🎵 ตัวโน้ตดนตรีบรรเลงลอยล่อง',        g: ['♪', '♫', '♬'],   c: '#a78bfa', m: 'rise',    n: 9,  d: 5 },
        cyber_cubes:       { t: '🧊 ลูกบาศก์ดิจิทัลไซเบอร์ 3D',         g: ['▣', '◩', '◪'],   c: '#00e5ff', m: 'orbit',   n: 8,  d: 7, spin: true },
        clover_lucky:      { t: '🍀 ใบโคลเวอร์ 4 แฉกนำโชค',            g: ['🍀'],            c: '#22c55e', m: 'orbit',   n: 6,  d: 10, spin: true },
        holy_cross:        { t: '✝️ ประกายกากบาทแสงศักดิ์สิทธิ์',        g: ['✚', '✦'],        c: '#fde68a', m: 'twinkle', n: 10, d: 2.5 },
        skull_souls:       { t: '💀 วิญญาณกะโหลกแค้นสีฟ้าคราม',         g: ['💀'],            c: '#22d3ee', m: 'flutter', n: 5,  d: 9 }
    };

    const RAINBOW = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#38bdf8', '#6366f1', '#a855f7'];

    const CSS = `
.fo-wrap{position:absolute;inset:0;pointer-events:none;z-index:7;container-type:size;overflow:visible;}
.fo-p{position:absolute;left:0;top:0;transform:translate(-50%,-50%);font-size:12px;font-size:clamp(7px,13cqmin,22px);line-height:1;will-change:left,top,opacity,transform;white-space:nowrap;}
.fo-p>i{display:inline-block;font-style:normal;}
.fo-dot{display:inline-block;width:.42em;height:.42em;border-radius:50%;}
.fo-orbit,.fo-flutter{animation:foSquare var(--d) linear infinite;animation-delay:var(--dl);}
.fo-rev{animation-direction:reverse;}
.fo-flutter>i{animation:foFlap .55s ease-in-out infinite alternate;}
.fo-spin>i{animation:foSpinSoft var(--d2,6s) linear infinite;}
.fo-fall{left:var(--x);animation:foFall var(--d) linear infinite;animation-delay:var(--dl);}
.fo-fall>i{animation:foSway 2.2s ease-in-out infinite alternate;}
.fo-rise{left:var(--x);animation:foRise var(--d) ease-in infinite;animation-delay:var(--dl);}
.fo-rise>i{animation:foSway 1.8s ease-in-out infinite alternate;}
.fo-twinkle{left:var(--x);top:var(--y);animation:foTwinkle var(--d) ease-in-out infinite;animation-delay:var(--dl);}
.fo-wander{left:var(--x);top:var(--y);animation:foWander var(--d) ease-in-out infinite alternate;animation-delay:var(--dl);}
.fo-wander>i{animation:foBlink 1.6s ease-in-out infinite alternate;animation-delay:var(--dl);}
@keyframes foSquare{0%{left:3%;top:3%}25%{left:97%;top:3%}50%{left:97%;top:97%}75%{left:3%;top:97%}100%{left:3%;top:3%}}
@keyframes foFlap{0%{transform:rotate(-14deg) scaleX(1)}100%{transform:rotate(14deg) scaleX(.72)}}
@keyframes foSpinSoft{from{transform:rotate(0)}to{transform:rotate(360deg)}}
@keyframes foFall{0%{top:-8%;opacity:0}12%{opacity:1}88%{opacity:1}100%{top:108%;opacity:0}}
@keyframes foRise{0%{top:108%;opacity:0}15%{opacity:1}85%{opacity:.9}100%{top:-8%;opacity:0}}
@keyframes foSway{0%{transform:translateX(-35%) rotate(-18deg)}100%{transform:translateX(35%) rotate(18deg)}}
@keyframes foTwinkle{0%,100%{opacity:0;transform:translate(-50%,-50%) scale(.3) rotate(0)}50%{opacity:1;transform:translate(-50%,-50%) scale(1.15) rotate(45deg)}}
@keyframes foWander{0%{transform:translate(-50%,-50%)}100%{transform:translate(calc(-50% + var(--dx)),calc(-50% + var(--dy)))}}
@keyframes foBlink{0%{opacity:.15}100%{opacity:1}}
@media (prefers-reduced-motion:reduce){.fo-p,.fo-p>i{animation-duration:0s!important;animation-iteration-count:1!important;}}
`;

    function injectCss() {
        if (typeof document === 'undefined' || document.getElementById('frame-orbit-fx-css')) return;
        const st = document.createElement('style');
        st.id = 'frame-orbit-fx-css';
        st.textContent = CSS;
        (document.head || document.documentElement).appendChild(st);
    }

    // จุดสุ่มบนแนวขอบสี่เหลี่ยม (คืนค่า % x,y) เพื่อให้ดาว/หิ่งห้อยอยู่รอบกรอบ ไม่บังใบหน้าตรงกลาง
    function perimeterPoint(rand) {
        const t = rand() * 4, off = rand() * 0.5;
        const jitter = (v) => Math.max(-4, Math.min(104, v + (rand() - 0.5) * 12));
        let x, y;
        if (t < 1) { x = t * 100; y = 2 + off * 6; }
        else if (t < 2) { x = 98 - off * 6; y = (t - 1) * 100; }
        else if (t < 3) { x = (3 - t) * 100; y = 98 - off * 6; }
        else { x = 2 + off * 6; y = (4 - t) * 100; }
        return [jitter(x), jitter(y)];
    }

    // PRNG แบบ seed เพื่อให้ HTML ที่ได้คงที่ต่อ key (ไม่กระโดดเวลารีเรนเดอร์)
    function seeded(str) {
        let h = 2166136261;
        for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
        return function () {
            h += 0x6D2B79F5; let t = h;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    function html(key, opts) {
        const p = P[key];
        if (!p) return '';
        injectCss();
        opts = opts || {};
        const density = Math.max(0.3, Math.min(2, opts.density || 1));
        const n = Math.max(2, Math.round(p.n * density));
        const rand = seeded(key);
        const glowBase = p.c;
        let out = `<div class="fo-wrap" data-orbit="${key}">`;
        for (let i = 0; i < n; i++) {
            const color = p.rainbow ? RAINBOW[i % RAINBOW.length] : glowBase;
            const d = (p.d * (0.85 + rand() * 0.3)).toFixed(2);
            let cls = 'fo-p fo-' + p.m + (p.rev ? ' fo-rev' : '') + (p.spin ? ' fo-spin' : '');
            let vars = `--d:${d}s;`;
            if (p.m === 'orbit' || p.m === 'flutter') {
                vars = `--d:${p.d}s;--dl:${(-(i / n) * p.d).toFixed(2)}s;--d2:${(4 + rand() * 6).toFixed(1)}s;`;
            } else if (p.m === 'fall' || p.m === 'rise') {
                vars += `--x:${(4 + rand() * 92).toFixed(1)}%;--dl:${(-rand() * p.d).toFixed(2)}s;`;
            } else {
                const [x, y] = perimeterPoint(rand);
                vars += `--x:${x.toFixed(1)}%;--y:${y.toFixed(1)}%;--dl:${(-rand() * p.d * 2).toFixed(2)}s;` +
                        `--dx:${((rand() - 0.5) * 30).toFixed(0)}cqmin;--dy:${((rand() - 0.5) * 30).toFixed(0)}cqmin;`;
            }
            const scale = (0.7 + rand() * 0.55).toFixed(2);
            const glow = `drop-shadow(0 0 3px ${color}) drop-shadow(0 0 6px ${color})`;
            const filt = (p.f ? p.f + ' ' : '') + glow;
            let inner;
            if (p.dot) {
                inner = `<i><span class="fo-dot" style="background:${color};box-shadow:0 0 4px ${color},0 0 9px ${color};"></span></i>`;
            } else {
                const g = p.g[i % p.g.length];
                inner = `<i style="color:${p.gc || color};">${g}</i>`;
            }
            out += `<span class="${cls}" style="${vars}font-size:calc(clamp(7px,13cqmin,22px) * ${scale});filter:${filt};">${inner}</span>`;
        }
        return out + '</div>';
    }

    function render(container, key, opts) {
        if (!container) return null;
        container.querySelectorAll(':scope > .fo-wrap').forEach(el => el.remove());
        if (!key || key === 'none' || !P[key]) return null;
        const tmp = document.createElement('div');
        tmp.innerHTML = html(key, opts);
        const wrap = tmp.firstElementChild;
        if (wrap) container.appendChild(wrap);
        return wrap;
    }

    const api = {
        PRESETS: P,
        keys: () => Object.keys(P),
        label: (key) => (P[key] ? P[key].t : ''),
        html,
        render,
        random: () => { const k = Object.keys(P); return k[Math.floor(Math.random() * k.length)]; }
    };

    global.FrameOrbitFX = api;
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectCss);
        else injectCss();
    }
})(typeof window !== 'undefined' ? window : this);
