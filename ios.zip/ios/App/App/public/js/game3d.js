/**
 * game3d.js - Ultra Full 3D WebGL Engine for Snake & Ladder 3D Game (Three.js)
 * Features:
 *  - Thai Province Names on every board tile (shuffled randomly)
 *  - Special Tiles: Chance (ช่องดวง), Tax (ช่องภาษี), Lucky Gamble (ช่องเสี่ยงโชค ชิงเพชร & ทองคำ)
 *  - 4 Dynamic 3D Environments (Cyber Neon, Golden Temple, Lava Volcano, Crystal Ice)
 *  - 3D Tumbling Physics-style Dice with procedural pip textures
 *  - 3D Animated Ladders, Realistic 3D Snakes with glowing eyes, 3D Chance Chests, 3D Prison Jail, 3D Tax Signs, 3D Lucky Roulette
 *  - Skill Calculations: Dice Control accuracy gauge, Knockback / Pull Back 5 or 8 tiles when landing on same square
 *  - Doubles Rule: 3 consecutive doubles = Sent to Jail for 2 turns
 *  - Jail Escape: Roll doubles OR pay Gold/Diamond
 *  - Victory condition: Tile 100 = Cinematic victory, confetti, ranking update to backend
 */

var THAI_PROVINCES = window.THAI_PROVINCES || [
    'กรุงเทพฯ', 'เชียงใหม่', 'ภูเก็ต', 'ขอนแก่น', 'ชลบุรี', 'นครราชสีมา', 'สงขลา', 'เชียงราย',
    'สุราษฎร์ธานี', 'อยุธยา', 'นนทบุรี', 'ปทุมธานี', 'สมุทรปราการ', 'นครปฐม', 'ระยอง', 'จันทบุรี',
    'ตราด', 'กระบี่', 'พังงา', 'ตรัง', 'สตูล', 'นครศรีธรรมราช', 'พัทลุง', 'ปัตตานี', 'ยะลา',
    'นราธิวาส', 'ชุมพร', 'ระนอง', 'ประจวบฯ', 'เพชรบุรี', 'ราชบุรี', 'กาญจนบุรี', 'สุพรรณบุรี',
    'สมุทรสาคร', 'สมุทรสงคราม', 'นครนายก', 'ปราจีนบุรี', 'สระแก้ว', 'ฉะเชิงเทรา', 'สระบุรี',
    'ลพบุรี', 'อ่างทอง', 'สิงห์บุรี', 'ชัยนาท', 'อุทัยธานี', 'นครสวรรค์', 'พิจิตร', 'พิษณุโลก',
    'กำแพงเพชร', 'เพชรบูรณ์', 'สุโขทัย', 'ตาก', 'อุตรดิตถ์', 'แพร่', 'น่าน', 'พะเยา', 'ลำปาง',
    'ลำพูน', 'แม่ฮ่องสอน', 'อุดรธานี', 'หนองคาย', 'บึงกาฬ', 'เลย', 'หนองบัวลำภู', 'สกลนคร',
    'นครพนม', 'มุกดาหาร', 'กาฬสินธุ์', 'มหาสารคาม', 'ร้อยเอ็ด', 'ยโสธร', 'อำนาจเจริญ',
    'อุบลราชธานี', 'ศรีสะเกษ', 'สุรินทร์', 'บุรีรัมย์', 'ชัยภูมิ',
    // Landmarks and famous tourist cities
    'พัทยา', 'เกาะสมุย', 'เขาใหญ่', 'หัวหิน', 'เกาะช้าง', 'เกาะเสม็ด', 'เกาะพีพี', 'เขาค้อ',
    'ภูกระดึง', 'ปาย', 'ชะอำ', 'บางแสน', 'เกาะพะงัน', 'เกาะล้าน', 'หาดใหญ่', 'เบตง',
    'ภูทับเบิก', 'ดอยอินทนนท์', 'ดอยสุเทพ', 'ภูชี้ฟ้า', 'อัมพวา', 'สยามสแควร์', 'เยาวราช', 'เส้นชัยสยาม'
];

// Global helper to open in-game player inspect popup safely from any click/touch context
window.showInGamePlayerPopup = function (playerIdx) {
    const g = window.game || window.game3D;
    if (g && typeof g.showInGamePlayerPopup === 'function') {
        g.showInGamePlayerPopup(playerIdx);
    }
};

window.handleCornerCardTap = function (e, playerIdx) {
    if (e) {
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
        if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
    }
    const now = Date.now();
    if (window._lastCornerCardTapTime && (now - window._lastCornerCardTapTime < 280)) {
        return;
    }
    window._lastCornerCardTapTime = now;
    window.showInGamePlayerPopup(playerIdx);
};

// Global helper แสดง Toast / Banner เมื่อแตะช่องสกิล/เต๋า/อัญมณี
window.showSkillSlotTip = function (e, type, title, desc) {
    if (e) {
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
        if (e.type === 'touchend' && typeof e.preventDefault === 'function') e.preventDefault();
    }
    const tipText = `${title ? title + ': ' : ''}${desc || ''}`;
    const g = window.game || window.game3D;
    if (g && typeof g.showSkillBanner === 'function') {
        g.showSkillBanner(tipText);
    } else if (typeof window.showToast === 'function') {
        window.showToast(tipText);
    } else {
        console.log('[Skill Tip]', tipText);
    }
};

function safeHexToRgba(hex, alpha = 1) {
    if (!hex) return `rgba(0, 229, 255, ${alpha})`;
    let c = String(hex).replace('#', '').trim();
    if (c.length === 8) {
        c = c.substring(0, 6);
    } else if (c.length === 3) {
        c = c.split('').map(x => x + x).join('');
    }
    const num = parseInt(c, 16);
    if (isNaN(num)) return `rgba(0, 229, 255, ${alpha})`;
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

class SnakeGame3D {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.clock = new THREE.Clock();

        // 3D Groups
        this.boardGroup = new THREE.Group();
        this.citiesGroup = new THREE.Group();
        this.pawnsGroup = new THREE.Group();
        this.diceGroup = new THREE.Group();
        this.effectsGroup = new THREE.Group();
        this.environmentGroup = new THREE.Group();

        // Global references & aliases for UI onclick handlers
        window.game3D = this;
        window.game = this;
        window.closeCityInspect = () => this.closeCityInspect();
        window.showInGamePlayerPopup = (idx) => this.showInGamePlayerPopup(idx);

        // 🏷️ 3D Badges, Hologram Labels & Text Customization State (ขนาด สี พื้นหลัง สีข้อความ)
        this.badgeConfig = this.loadBadgeConfig();

        // City / Landmark & Match Economy State (กติกาเกมเศรษฐี + บันไดงู 3D)
        this.cityStates = {};
        this.cityMeshes = {};
        this.isWaitingForCityAction = false;
        this.activeCityActionResolver = null;
        this.cityActionAutoChoice = null;
        this.cityActionInterval = null;
        this.selectedOddEvenMode = null;
        this.isGaugeHolding = false;
        this.gaugeCurrentProgress = 0.35;
        this.gaugeCurrentSegment = 2;
        this.matchConfig = {
            room_tier: '2M',
            entry_fee_gold: 2000,
            start_match_gold: 2000000,
            tax_amount: 50000,
            tax_percent: 20,
            city_base_cost: 120000,
            landmark_cost: 320000,
            toll_percent: 85,
            buyout_percent: 160
        };

        // Board & Coordinates (Default: 'ancient' = กระดานวิหารทองคำพญานาคราช)
        const savedTheme = localStorage.getItem('snake_board_theme');
        this.boardTheme = (savedTheme && ['classic', 'ancient', 'lava', 'ice'].includes(savedTheme)) ? savedTheme : 'ancient';
        this.boardLayout = localStorage.getItem('snake_board_layout') || 'square'; // 'square' | 'spiral' | 'hexagon'
        this.tiles = []; // 1..100 positions
        this.tileMeshes = [];
        this.boardSize = 10;
        this.tileSize = 6.2;
        this.tileGap = 0.4;

        // 3D Dice meshes
        this.diceMesh1 = null;
        this.diceMesh2 = null;
        this.diceMaterials = [];
        this.isDiceTumbling = false;

        // Game rules state
        this.players = [];
        this.currentTurnIndex = 0;
        this.isRolling = false;
        this.consecutiveDoubles = 0;
        this.isGameOver = false;
        this.isMatchActive = false;

        // Auto Mode state & 7-second turn timer
        this.isAutoMode = false;
        this.turnSecondsLeft = 20;
        this.turnCountdownInterval = null;
        this.autoTurnTimeout = null;

        // Province assignments
        this.tileProvinces = {};

        // Board Links (No overlapping tiles)
        this.ladders = {
            4: 14, 9: 31, 22: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91
        };
        this.snakes = {
            17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78
        };
        this.snakeTailToHead = {};
        for (const [h, t] of Object.entries(this.snakes)) {
            this.snakeTailToHead[Number(t)] = Number(h);
        }
        this.ladderObjects = {};
        this.snakeObjects = {};
        this.activeSpeechBubbles = new Map();

        this.chanceTiles = [11, 45, 76];     // ช่องดวง (Chance)
        this.taxTiles = [20, 52, 82];        // ช่องภาษี (Tax)
        this.gambleTiles = [15, 68, 88];     // ช่องเสี่ยงโชค (Lucky Gamble)
        this.destroyTiles = [26, 36, 90];    // 💥 ช่องสกิลลบเมืองคู่แข่ง (3 ช่อง กระจายห่างกันทั่วกระดาน)
        this.jailTile = 10;                  // เกาะร้าง (คุก)

        // Randomly shuffle Thai provinces across tiles
        this.initProvinces();

        // Theme specifications
        this.themes = {
            classic: {
                name: 'นีออนไซเบอร์ 3D (Cyber Neon)',
                bgColor: 0x070b14,
                fogColor: 0x070b14,
                tileEven: 0x111c30,
                tileOdd: 0x1a2a47,
                border: 0x00e5ff,
                ambient: 0x223a5e,
                light: 0x00e5ff,
                ladder: 0x00e5ff,
                snake: 0xff0055,
                particle: 0x00e5ff
            },
            ancient: {
                name: 'วิหารทองคำพญานาคราช (Golden Temple)',
                bgColor: 0x140e06,
                fogColor: 0x140e06,
                tileEven: 0x2e1f0a,
                tileOdd: 0x432d0f,
                border: 0xffd700,
                ambient: 0x5a4220,
                light: 0xffd700,
                ladder: 0xffd700,
                snake: 0x10b981,
                particle: 0xffea00
            },
            lava: {
                name: 'ภูเขาไฟลาวาเดือด (Lava Volcano)',
                bgColor: 0x140505,
                fogColor: 0x140505,
                tileEven: 0x2b0d0d,
                tileOdd: 0x3d1414,
                border: 0xff3d00,
                ambient: 0x451616,
                light: 0xff5722,
                ladder: 0xffab00,
                snake: 0x212121,
                particle: 0xff3d00
            },
            ice: {
                name: 'แดนน้ำแข็งคริสตัล (Crystal Ice)',
                bgColor: 0x06111a,
                fogColor: 0x06111a,
                tileEven: 0x0f2a3d,
                tileOdd: 0x163d59,
                border: 0x80d8ff,
                ambient: 0x1f4968,
                light: 0x40c4ff,
                ladder: 0x00b0ff,
                snake: 0x7c4dff,
                particle: 0x80d8ff
            }
        };

        this.initThree();
        this.generateDiceTextures();
        this.create3DDice();
        const initMode = (window.GAME_MODES_CONFIG && window.GAME_MODES_CONFIG.default_mode) || window.selectedHomeGameMode || 'MONOPOLY';
        if (String(initMode).toUpperCase() === 'MONOPOLY' && typeof this.buildMonopolyBoard32 === 'function') {
            this.buildMonopolyBoard32(window.ACTIVE_MONOPOLY_BOARD || null);
        } else {
            this.buildBoard();
        }
        this.animate();
    }

    initThree() {
        const width = this.container.clientWidth || window.innerWidth;
        const height = this.container.clientHeight || window.innerHeight;

        // Scene
        this.scene = new THREE.Scene();
        const activeBg = (this.themes[this.boardTheme] && this.themes[this.boardTheme].bgColor) || 0x070b12;
        this.scene.background = new THREE.Color(activeBg);
        this.scene.fog = new THREE.FogExp2((this.themes[this.boardTheme] && this.themes[this.boardTheme].fogColor) || activeBg, 0.007);

        // Camera (ขยับจุดศูนย์กลางและมุมมองขึ้นบน ไม่ชนบาร์สถานะด้านล่าง)
        this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
        this.camera.position.set(0, 45.0, 72.5);
        this.camera.lookAt(0, -6.0, 7.0);

        // Renderer (Memory-Optimized for Mobile iOS & Android & Low-End Phones)
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
        const savedQuality = (typeof localStorage !== 'undefined' && localStorage.getItem('snake_graphics_quality')) || (isMobileOrTablet ? 'medium' : 'high');
        this.graphicsQuality = savedQuality;

        try {
            this.renderer = new THREE.WebGLRenderer({
                antialias: savedQuality === 'high',
                alpha: true,
                powerPreference: (savedQuality === 'low' || isMobileOrTablet) ? 'default' : 'high-performance'
            });
        } catch (glInitErr) {
            console.warn('[SnakeGame3D] Primary WebGL init failed, retrying with safe fallback:', glInitErr);
            this.renderer = new THREE.WebGLRenderer({
                antialias: false,
                alpha: true,
                powerPreference: 'default',
                precision: 'mediump'
            });
        }
        this.renderer.setClearColor(activeBg, 1.0);
        if (typeof window.applyGlobalBoardBackground === 'function') {
            setTimeout(() => window.applyGlobalBoardBackground(), 50);
        }
        this.renderer.setSize(width, height);
        // ตั้งค่าเงาครั้งเดียวตอนเริ่มต้นเท่านั้น (ปิดบนมือถือ ประหยัดหน่วยความจำ GPU ป้องกัน Context Lost)
        this.renderer.shadowMap.enabled = (!isMobileOrTablet && savedQuality !== 'low');
        if (this.renderer.shadowMap.enabled) {
            this.renderer.shadowMap.type = (savedQuality === 'high') ? THREE.PCFSoftShadowMap : THREE.BasicShadowMap;
        }
        this.applyRendererQuality(savedQuality);
        const glDom = this.renderer.domElement;
        if (glDom) {
            glDom.style.touchAction = 'none';
            glDom.style.outline = 'none';
        }
        this.container.appendChild(glDom);

        // WebGL Context Lost & Restored Handlers: ป้องกันแอปเด้งดับหรือจอดำบน iOS และ Android
        this.isContextLost = false;
        this._glStats = { lost: 0, recreated: 0, renderErrors: 0, culprits: [], lastError: '', frames: 0 };
        this.attachContextHandlers(glDom);

        // OrbitControls
        if (window.THREE.OrbitControls) {
            this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
            this.controls.enableDamping = true;
            this.controls.dampingFactor = 0.05;
            this.controls.maxPolarAngle = Math.PI / 2.05;
            this.controls.minDistance = 20;
            this.controls.maxDistance = 200;
        }

        // Apply real-time camera fit based on viewport and board layout
        this.updateCameraFit(true);

        // Lighting
        this.ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
        this.scene.add(this.ambientLight);

        this.dirLight = new THREE.DirectionalLight(0xffffff, 1.3);
        this.dirLight.position.set(40, 90, 50);
        this.dirLight.castShadow = true;
        const shadowRes = isMobileOrTablet ? 1024 : 2048;
        this.dirLight.shadow.mapSize.width = shadowRes;
        this.dirLight.shadow.mapSize.height = shadowRes;
        this.scene.add(this.dirLight);

        const initialLightColor = (this.themes[this.boardTheme] && this.themes[this.boardTheme].light) ? this.themes[this.boardTheme].light : 0xffd700;
        this.pointLight = new THREE.PointLight(initialLightColor, 2, 120);
        this.pointLight.position.set(0, 25, 0);
        this.scene.add(this.pointLight);

        if (this.boardTheme === 'ancient') {
            this.ambientLight.color.setHex(0xfff3db);
            this.ambientLight.intensity = 1.0;
            this.dirLight.color.setHex(0xfff0cc);
        }

        // Groups
        this.scene.add(this.environmentGroup);
        this.scene.add(this.boardGroup);
        this.scene.add(this.citiesGroup);
        this.scene.add(this.pawnsGroup);
        this.scene.add(this.diceGroup);
        this.scene.add(this.effectsGroup);

        window.addEventListener('resize', () => this.onWindowResize());
        window.addEventListener('orientationchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
            setTimeout(() => this.onWindowResize(), 300);
        });
        if (window.screen && window.screen.orientation) {
            try {
                window.screen.orientation.addEventListener('change', () => {
                    setTimeout(() => this.onWindowResize(), 100);
                    setTimeout(() => this.onWindowResize(), 300);
                });
            } catch (e) { }
        }
        document.addEventListener('fullscreenchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
        });
        document.addEventListener('webkitfullscreenchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
        });
        window.addEventListener('beforeunload', () => {
            // ไม่บันทึกเพื่อป้องกันไม่ให้เกมเข้าเล่นเองอัตโนมัติเมื่อกดรีเฟรชหน้าเว็บ
        });
        window.addEventListener('pagehide', () => {
            // ไม่บันทึกเพื่อป้องกันไม่ให้เกมเข้าเล่นเองอัตโนมัติเมื่อกดรีเฟรชหน้าเว็บ
        });
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' || e.keyCode === 27) {
                this.closeCityInspect();
            }
        });

        // 🔍 เปิดระบบแตะ/คลิกช่องกระดานเพื่อดูข้อมูลเมือง สิ่งก่อสร้าง ค่าผ่านทาง และค่าซื้อต่อ
        this.setupTileInspectionClick();
        this.initDiceHoldChargeHandlers();
    }

    /**
     * ปรับระดับคุณภาพกราฟิก 3D (Graphics Quality): 'low' | 'medium' | 'high'
     * สำหรับโทรศัพท์รุ่นเก่า / เครื่องสเปกต่ำ / ประหยัดพลังงาน
     */
    setGraphicsQuality(level = 'medium') {
        this.graphicsQuality = level;
        try {
            localStorage.setItem('snake_graphics_quality', level);
        } catch (e) { }
        this.applyRendererQuality(level);
    }

    applyRendererQuality(level = 'medium') {
        if (!this.renderer) return;
        const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) ? window.devicePixelRatio : 1;
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));

        if (level === 'low') {
            this.renderer.setPixelRatio(0.75);
        } else if (level === 'high') {
            this.renderer.setPixelRatio(Math.min(dpr, 1.75));
        } else {
            this.renderer.setPixelRatio(Math.min(dpr, 1.15));
        }

        if (this.container) {
            const rawW = this.container.clientWidth || window.innerWidth || 800;
            const rawH = this.container.clientHeight || window.innerHeight || 600;
            const width = Math.max(320, rawW);
            const height = Math.max(240, rawH);
            this.renderer.setSize(width, height, false);
        }
    }

    onWindowResize() {
        this.updateCameraFit();
    }

    /**
     * คำนวณและปรับขนาดการเรนเดอร์ รวมถึงตำแหน่งกล้อง (Camera Position), 
     * ระดับการซูม (Field of View / FOV) และ Aspect Ratio แบบ Real-time
     * เพื่อให้กระดาน 3D (ทั้งหกเหลี่ยม สี่เหลี่ยม ก้นหอย) ขยับเข้ามาใกล้และขยายใหญ่
     * แสดงผลพอดีและเต็มหน้าจอแนวนอนในโหมดมือถือ ลดขอบดำซ้าย-ขวาและบน-ล่างให้เหลือเท่าที่จำเป็น
     */
    updateCameraFit(isInitial = false) {
        if (!this.camera || !this.renderer || !this.container) return;

        const rawW = this.container.clientWidth || window.innerWidth || 800;
        const rawH = this.container.clientHeight || window.innerHeight || 600;
        const width = Math.max(320, rawW);
        const height = Math.max(240, rawH);
        const aspect = Math.max(0.35, Math.min(3.5, width / height));

        // 1. อัปเดตขนาด Renderer
        this.renderer.setSize(width, height, false);

        // 2. คำนวณตำแหน่งกล้องและ FOV ให้กระดานเต็มหน้าจอตามรูปทรงและโหมดหน้าจอ (แนวนอน/แนวตั้ง)
        const layout = this.boardLayout || 'square';
        let fov = 42;
        let camX = 0;
        let camY = 47.0;
        let camZ = 63.0;
        let targetX = 0;
        let targetY = 0;
        let targetZ = 2.0;

        const isLandscape = aspect >= 1.0;
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
        const gridCols = (layout === 'rectangle') ? (this.customGridCols || 12) : (this.customGridCols || 10);
        const gridRows = (layout === 'rectangle') ? (this.customGridRows || 8) : (this.customGridRows || 10);
        const widthFactor = Math.max(1.0, gridCols / 10.5);

        if (isLandscape) {
            if (aspect >= 1.6) {
                // โหมดมือถือแนวนอน & จอกว้าง Widescreen (16:9, 19.5:9, 20:9 เช่น iPhone, Samsung)
                // ขยับตัวกระดานเข้ามาใกล้หน้าจอและขยายใหญ่ขึ้น ให้กระดานเต็มหน้าจอตามที่ผู้ใช้เน้นกรอบแดง
                fov = 41;
                if (layout === 'rectangle') {
                    camY = 44.0 * widthFactor;
                    camZ = 58.0 * widthFactor;
                    targetZ = 2.0;
                } else if (layout === 'square') {
                    camY = 47.0;
                    camZ = 63.0;
                    targetZ = 2.0;
                } else if (layout === 'spiral') {
                    camY = 45.0;
                    camZ = 60.0;
                    targetZ = 2.0;
                } else {
                    camY = 46.0 * widthFactor;
                    camZ = 62.0 * widthFactor;
                    targetZ = 2.0;
                }
            } else if (aspect >= 1.35) {
                // จอแล็ปท็อป/คอมพิวเตอร์ 16:10, 3:2
                fov = 42;
                if (layout === 'rectangle') {
                    camY = 48.0 * widthFactor;
                    camZ = 64.0 * widthFactor;
                    targetZ = 2.0;
                } else if (layout === 'square') {
                    camY = 50.0;
                    camZ = 66.0;
                    targetZ = 2.0;
                } else {
                    camY = 49.0;
                    camZ = 65.0;
                    targetZ = 2.0;
                }
            } else {
                // แท็บเล็ต 4:3 (iPad) หรือจอสี่เหลี่ยม
                fov = 43;
                const factor = (1.35 / Math.max(aspect, 1.0)) * widthFactor;
                camY = 52.0 * factor;
                camZ = 68.0 * factor;
                targetZ = 1.5;
            }
        } else {
            // โหมดแนวตั้ง (Mobile Portrait, aspect < 1.0)
            fov = 44;
            let boardRadius = (layout === 'rectangle') ? (gridCols * 3.8) : ((layout === 'square') ? 40.0 : (layout === 'spiral' ? 35.0 : 38.0));
            const radFov = (fov * Math.PI) / 180;
            const targetHalfWidth = boardRadius * 1.15;
            const dist = targetHalfWidth / (Math.tan(radFov / 2) * aspect);
            const pitch = 50 * Math.PI / 180;
            camY = dist * Math.sin(pitch);
            camZ = dist * Math.cos(pitch);
            targetZ = 0;
        }

        // ปรับสมดุลมุมกล้องให้อยู่ตรงกลางพื้นที่แสดงผลระหว่างสองแถบข้าง
        const boardScreenShiftX = 0;
        const boardScreenShiftY = isLandscape ? -5.0 : -3.0;
        const boardScreenShiftZ = isLandscape ? 3.5 : 2.0;

        camX -= boardScreenShiftX;
        targetX -= boardScreenShiftX;
        camY += boardScreenShiftY;
        camZ += boardScreenShiftZ;
        targetY += boardScreenShiftY;
        targetZ += boardScreenShiftZ;

        // รับประกันค่าตัวเลขต้องถูกต้องแน่นอน (Finite number check)
        if (!isFinite(camX) || !isFinite(camY) || !isFinite(camZ)) {
            camX = 0; camY = 47.0; camZ = 63.0;
        }
        if (!isFinite(targetX) || !isFinite(targetY) || !isFinite(targetZ)) {
            targetX = 0; targetY = -5.0; targetZ = 5.5;
        }

        // 3. ปรับค่า FOV, Aspect Ratio และสั่ง camera.updateProjectionMatrix()
        this.camera.fov = fov;
        this.camera.aspect = aspect;
        this.camera.position.set(camX, camY, camZ);
        this.camera.lookAt(targetX, targetY, targetZ);
        this.camera.updateProjectionMatrix();

        // 4. ซิงค์เป้าหมายการหมุน OrbitControls ให้ตรงกับตำแหน่งกึ่งกลางกระดาน
        if (this.controls) {
            this.controls.target.set(targetX, targetY, targetZ);
            this.controls.update();
        }
    }

    /**
     * ขยาย / ย่อมุมมองกระดาน 3D (Zoom In / Out)
     * delta > 0: ซูมเข้า (ขยาย), delta < 0: ซูมออก (ย่อ)
     */
    zoomBoard(delta = 0.15) {
        if (!this.camera || !this.controls) return;
        const target = this.controls.target.clone();
        const offset = this.camera.position.clone().sub(target);
        const currentDist = offset.length();
        const factor = 1 - delta;
        const newDist = currentDist * factor;
        const minDist = this.controls.minDistance || 15;
        const maxDist = this.controls.maxDistance || 220;
        if (newDist >= minDist && newDist <= maxDist) {
            offset.multiplyScalar(factor);
            this.camera.position.copy(target).add(offset);
            this.camera.lookAt(target);
            this.controls.update();
        }
    }

    /**
     * หมุนมุมมองกระดาน 3D รอบแกน Y (Rotate Board Yaw)
     * angleDeg: องศาที่ต้องการหมุน (+ ตามเข็ม, - ทวนเข็ม)
     */
    rotateBoard(angleDeg = 45) {
        if (!this.camera || !this.controls) return;
        const target = this.controls.target.clone();
        const angleRad = (angleDeg * Math.PI) / 180;
        const offset = this.camera.position.clone().sub(target);
        offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), angleRad);
        this.camera.position.copy(target).add(offset);
        this.camera.lookAt(target);
        this.controls.update();
    }

    /**
     * ปรับกระดานให้พอดีหน้าจออัตโนมัติ (Fit Board)
     */
    fitBoard() {
        this.updateCameraFit(false);
    }

    /**
     * ตั้งค่ามุมมองกล้องสำเร็จรูป (Camera Preset)
     */
    setCameraPreset(preset) {
        if (!this.camera || !this.controls) return;
        if (preset === 'fit') {
            this.updateCameraFit(false);
            return;
        }

        // รีเซ็ตสู่ฐานมุมมองมาตรฐานก่อนคำนวณ Preset
        this.updateCameraFit(false);
        const target = this.controls.target.clone();

        if (preset === 'topdown') {
            // มุมมองจากด้านบนตรง 2D
            const currentDist = this.camera.position.clone().sub(target).length();
            const topDist = Math.max(75, currentDist * 0.95);
            this.camera.position.set(target.x, target.y + topDist, target.z + 0.1);
            this.camera.lookAt(target);
            this.controls.update();
        } else if (preset === 'iso') {
            // มุมมองเฉียง 3D Isometric
            const currentDist = this.camera.position.clone().sub(target).length();
            const rad = Math.PI / 4;
            const distY = currentDist * 0.65;
            const distXZ = currentDist * 0.76;
            this.camera.position.set(
                target.x + distXZ * Math.sin(rad),
                target.y + distY,
                target.z + distXZ * Math.cos(rad)
            );
            this.camera.lookAt(target);
            this.controls.update();
        } else if (preset === 'closeup') {
            // โฟกัสระยะใกล้ (ซูมเข้า 35%)
            const offset = this.camera.position.clone().sub(target);
            offset.multiplyScalar(0.65);
            this.camera.position.copy(target).add(offset);
            this.camera.lookAt(target);
            this.controls.update();
        }
    }

    /**
     * Generate 6 procedural Dice Face textures with pips (dots)
     */
    generateDiceTextures() {
        this.diceMaterials = [];
        const pipConfigs = {
            1: [[0.5, 0.5]],
            2: [[0.25, 0.25], [0.75, 0.75]],
            3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
            4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
            5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
            6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
        };

        const faceOrder = [1, 6, 2, 5, 3, 4];

        faceOrder.forEach(num => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const ctx = canvas.getContext('2d');

            const grad = ctx.createLinearGradient(0, 0, 256, 256);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(1, '#e2e8f0');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 256, 256);

            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 12;
            ctx.strokeRect(6, 6, 244, 244);

            ctx.fillStyle = (num === 1) ? '#ef4444' : '#0f172a';
            const pips = pipConfigs[num];
            pips.forEach(([x, y]) => {
                ctx.beginPath();
                ctx.arc(x * 256, y * 256, num === 1 ? 32 : 22, 0, Math.PI * 2);
                ctx.fill();
            });

            const texture = new THREE.CanvasTexture(canvas);
            this.diceMaterials.push(new THREE.MeshStandardMaterial({
                map: texture,
                roughness: 0.15,
                metalness: 0.1
            }));
        });
    }

    /**
     * Create Two 3D Physics Dice meshes positioned over the board
     */
    create3DDice() {
        // ขนาดลูกเต๋า 3D ขยายใหญ่ขึ้น เด่นชัด คมชัดพิเศษ (จาก 4.8 เป็น 6.6)
        const diceGeo = new THREE.BoxGeometry(6.6, 6.6, 6.6);

        // ตำแหน่งลูกเต๋า 3D วางกึ่งกลางกระดาน (X = 0, Z = 0) สม่ำเสมอทุกกระดาน
        this.diceMesh1 = new THREE.Mesh(diceGeo, this.diceMaterials);
        this.diceMesh1.castShadow = true;
        this.diceMesh1.position.set(-5.2, 3.6, 0);

        this.diceMesh2 = new THREE.Mesh(diceGeo, this.diceMaterials);
        this.diceMesh2.castShadow = true;
        this.diceMesh2.position.set(5.2, 3.6, 0);

        this.diceGroup.add(this.diceMesh1);
        this.diceGroup.add(this.diceMesh2);

        // ซ่อนลูกเต๋า 3D เป็นค่าเริ่มต้น จะแสดงเฉพาะตอนเริ่มทอยเต๋า และเมื่อทอยเสร็จจะหายไปทันที
        this.diceGroup.visible = false;

        this.diceBasePos = { x: 0, y: 3.6, z: 0, scale: 1.0, spacing: 5.2 };
    }

    /**
     * แสดงลูกเต๋า 3D ขนาดใหญ่เด่นชัดขึ้นมากึ่งกลางกระดานเมื่อเริ่มทอยเต๋า
     */
    show3DDiceForRoll() {
        if (!this.diceGroup) return;
        const basePos = this.diceBasePos || { x: 0, y: 3.6, z: 0, scale: 1.0, spacing: 3.8 };
        const targetScale = basePos.scale || 1.0;
        const spacing = 3.8;
        const dx = 0; // กึ่งกลางกระดาน X = 0 เสมอ
        const dy = basePos.y || 3.4;
        const dz = this.isMonopolyBoardMode ? 7.5 : (basePos.z || 0);

        if (this.diceMesh1) {
            this.diceMesh1.position.set(dx - spacing, dy, dz + 0.6);
            this.diceMesh1.scale.set(targetScale, targetScale, targetScale);
        }
        if (this.diceMesh2) {
            this.diceMesh2.position.set(dx + spacing, dy, dz - 0.6);
            this.diceMesh2.scale.set(targetScale, targetScale, targetScale);
        }
        this.diceGroup.visible = true;
    }

    /**
     * คำนวณพิกัด 2D บนหน้าจอตรงกับกึ่งกลางกระดาน 3D เหนือลูกเต๋าพอดี (สไตล์ โหมดกระดาน 3D)
     */
    getBoardCenterScreenPosition() {
        if (!this.camera || !this.renderer || !this.renderer.domElement) {
            return { x: window.innerWidth / 2, y: window.innerHeight / 2 };
        }
        // พิกัด 3D กึ่งกลางกระดานเหนือลูกเต๋า: เมื่อเลื่อนลูกเต๋าลงมาที่ Z = 7.5 ให้ตัวเลขอยู่ด้านบนพอดี (Z = 2.0, Y = 6.5) ไม่บังลูกเต๋า
        const zPos = this.isMonopolyBoardMode ? 2.0 : 0;
        const pos = new THREE.Vector3(0, 6.5, zPos);
        pos.project(this.camera);

        const rect = this.renderer.domElement.getBoundingClientRect();
        const x = ((pos.x + 1) * 0.5) * rect.width + rect.left;
        const y = ((-pos.y + 1) * 0.5) * rect.height + rect.top;

        return {
            x: Math.max(50, Math.min(window.innerWidth - 50, x)),
            y: Math.max(70, Math.min(window.innerHeight - 80, y))
        };
    }

    /**
     * แสดงตัวเลขแต้มเต๋าและป้ายดับเบิ้ลกึ่งกลางกระดาน สไตล์ โหมดกระดาน 3D
     */
    showCenterDiceOutcomeBadge(total, isDouble = false, d1 = 1, d2 = 1) {
        // เฉพาะในโหมดเกมส์เศรษฐีเท่านั้น (โหมดบันไดงูไม่ต้อง)
        if (!this.isMonopolyBoardMode) return;
        const badge = document.getElementById('dice-center-outcome-badge');
        if (!badge) return;

        const numEl = document.getElementById('dice-badge-number');
        const dblTag = document.getElementById('dice-badge-double-tag');

        if (numEl) numEl.innerText = total;
        if (dblTag) {
            dblTag.style.display = isDouble ? 'flex' : 'none';
        }

        const screenPos = this.getBoardCenterScreenPosition();
        badge.style.left = `${screenPos.x}px`;
        badge.style.top = `${screenPos.y - (isDouble ? 28 : 18)}px`;

        badge.classList.remove('pop-out');
        badge.classList.add('pop-in');
        badge.style.display = 'flex';

        try {
            if (window.soundEngine && typeof window.soundEngine.playLevelUp === 'function') {
                window.soundEngine.playLevelUp();
            } else if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                window.soundEngine.playStep();
            }
        } catch (e) { }
    }

    hideCenterDiceOutcomeBadge() {
        const badge = document.getElementById('dice-center-outcome-badge');
        if (!badge || badge.style.display === 'none') return;

        badge.classList.remove('pop-in');
        badge.classList.add('pop-out');

        setTimeout(() => {
            if (badge && badge.classList.contains('pop-out')) {
                badge.style.display = 'none';
                badge.classList.remove('pop-out');
            }
        }, 260);
    }

    /**
     * ซ่อนลูกเต๋า 3D หลังจากทอยเสร็จ โดยให้เวลาผู้เล่นดูแต้มเต๋าชัดเจน (~420ms) แล้วค่อยๆ ย่อขนาดหายไป
     */
    async hide3DDiceAfterRoll() {
        if (!this.diceGroup) return;
        if (!this.diceGroup.visible) return;
        // หน่วงเวลาให้ผู้เล่นเห็นผลแต้มเต๋า 3D ชัดเจนเต็มตาก่อน
        await new Promise(r => setTimeout(r, 420));

        // หดขนาดลูกเต๋าลงจนหายไปอย่างนุ่มนวล
        const startScale = (this.diceBasePos && this.diceBasePos.scale) ? this.diceBasePos.scale : 1.0;
        const shrinkDuration = 220;
        const shrinkStart = performance.now();

        await new Promise(resolve => {
            const shrinkStep = (now) => {
                const shrinkElapsed = now - shrinkStart;
                const p = Math.min(shrinkElapsed / shrinkDuration, 1.0);
                const curScale = Math.max(0, (1.0 - p) * startScale);
                if (this.diceMesh1) this.diceMesh1.scale.set(curScale, curScale, curScale);
                if (this.diceMesh2) this.diceMesh2.scale.set(curScale, curScale, curScale);

                if (p < 1.0) {
                    requestAnimationFrame(shrinkStep);
                } else {
                    this.diceGroup.visible = false;
                    // รีเซ็ตสเกลกลับเป็นปกติเพื่อรอการทอยรอบถัดไป
                    if (this.diceMesh1) this.diceMesh1.scale.set(startScale, startScale, startScale);
                    if (this.diceMesh2) this.diceMesh2.scale.set(startScale, startScale, startScale);
                    resolve();
                }
            };
            requestAnimationFrame(shrinkStep);
        });
    }

    /**
     * แสดงเอฟเฟกต์อัญมณี 3D ขนาดยักษ์เด้งหมุนควงกึ่งกลางกระดานสไตล์ทอยเต๋า แล้วหายไปใน 2 วินาที (2000ms)
     * รองรับทั้ง 3D Mesh กึ่งกลางกระดาน และ 3D Overlay กึ่งกลางจอสำหรับ iOS, Android และ Web
     */
    showCenterGemActivationEffect(player = null, skillTitle = 'อัญมณีเวทมนตร์', gemShape = null, gemColor = null) {
        // ดึงข้อมูลผู้เล่นหากไม่ระบุ
        const activePlayer = player || (this.players && this.players[this.currentTurnIndex]) || (this.players && this.players[0]) || null;
        const pName = activePlayer?.username || (window.DEFAULT_USER?.username) || 'ผู้เล่น';

        // ดึงสีและรูปทรงอัญมณีที่เปิดใช้งานจริง (จับคู่ตามชื่อสกิลก่อน หากไม่พบใช้ชิ้นแรก)
        let colorHexStr = '#c084fc';
        let colorHexNum = 0xc084fc;
        let resolvedShape = (gemShape || 'triangle').toLowerCase();
        let resolvedGrade = 'SS+';
        let resolvedAura = 'pulse';
        let resolvedPfx = 'spark';
        let matchedGemName = 'อัญมณีมหาเวทย์';

        if (activePlayer) {
            const gems = this.getPlayerEquippedGems(activePlayer);
            if (gems && gems.length > 0) {
                const cleanSkill = String(skillTitle || '').toLowerCase();
                const matched = gems.find(g => g && (
                    (g.skill_name && cleanSkill.includes(String(g.skill_name).toLowerCase())) ||
                    (g.name && cleanSkill.includes(String(g.name).toLowerCase()))
                )) || gems[0];
                if (matched) {
                    if (!gemShape && matched.shape) resolvedShape = String(matched.shape).toLowerCase();
                    resolvedGrade = matched.grade || 'SS+';
                    resolvedAura = matched.aura_type || 'pulse';
                    resolvedPfx = matched.particle_fx || 'spark';
                    matchedGemName = matched.name || matchedGemName;
                    const colStr = gemColor || matched.gem_color || ((resolvedGrade === 'SS+') ? '#c084fc' : ((resolvedGrade === 'S+') ? '#00e5ff' : '#ffd700'));
                    if (typeof colStr === 'string') {
                        colorHexStr = colStr.startsWith('#') ? colStr : ('#' + colStr);
                        colorHexNum = parseInt(colorHexStr.replace('#', '0x'), 16) || 0xc084fc;
                    }
                }
            }
        }
        if (gemColor) {
            if (typeof gemColor === 'number') {
                colorHexNum = gemColor;
                colorHexStr = '#' + Number(gemColor).toString(16).padStart(6, '0');
            } else if (typeof gemColor === 'string') {
                colorHexStr = gemColor.startsWith('#') ? gemColor : ('#' + gemColor);
                colorHexNum = parseInt(colorHexStr.replace('#', '0x'), 16) || 0xc084fc;
            }
        }

        // =========================================================================
        // A) แสดงเอฟเฟกต์อัญมณีเด้งหมุนควงกึ่งกลางหน้าจอเหมือนทอยเต๋า 2 วินาที (iOS / Android / Web)
        // =========================================================================
        if (typeof document !== 'undefined') {
            if (!document.getElementById('center-gem-tumble-styles')) {
                const st = document.createElement('style');
                st.id = 'center-gem-tumble-styles';
                st.textContent = `
                    @keyframes gemCenterDiceBounce {
                        0%   { transform: translate(-50%, -50%) scale(0.2) translateY(60px); opacity: 0; }
                        18%  { transform: translate(-50%, -50%) scale(1.18) translateY(-38px); opacity: 1; }
                        34%  { transform: translate(-50%, -50%) scale(0.95) translateY(8px); opacity: 1; }
                        50%  { transform: translate(-50%, -50%) scale(1.08) translateY(-18px); opacity: 1; }
                        68%  { transform: translate(-50%, -50%) scale(1.0) translateY(0px); opacity: 1; }
                        82%  { transform: translate(-50%, -50%) scale(1.04) translateY(-4px); opacity: 1; }
                        100% { transform: translate(-50%, -50%) scale(0.25) translateY(-30px); opacity: 0; }
                    }
                    @keyframes gemIconSpinTumble {
                        0%   { transform: rotateY(0deg) rotateZ(-25deg) scale(0.7); }
                        25%  { transform: rotateY(360deg) rotateZ(18deg) scale(1.15); }
                        50%  { transform: rotateY(720deg) rotateZ(-10deg) scale(1.0); }
                        75%  { transform: rotateY(1080deg) rotateZ(6deg) scale(1.06); }
                        100% { transform: rotateY(1080deg) rotateZ(0deg) scale(1.0); }
                    }
                    #center-board-gem-tumble-fx {
                        position: fixed;
                        top: 46%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        z-index: 9600;
                        pointer-events: none;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        animation: gemCenterDiceBounce 2.0s cubic-bezier(0.22, 1, 0.36, 1) forwards;
                        will-change: transform, opacity;
                    }
                    .cbg-gem-orb-stage {
                        position: relative;
                        width: 126px;
                        height: 126px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        perspective: 600px;
                        -webkit-perspective: 600px;
                    }
                    .cbg-gem-tumble-inner {
                        width: 108px;
                        height: 108px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transform-style: preserve-3d;
                        -webkit-transform-style: preserve-3d;
                        animation: gemIconSpinTumble 1.25s cubic-bezier(0.22, 1, 0.36, 1) forwards;
                    }
                    .cbg-gem-banner-pill {
                        margin-top: 6px;
                        padding: 6px 18px;
                        border-radius: 999px;
                        background: linear-gradient(135deg, rgba(15, 23, 42, 0.94), rgba(9, 13, 22, 0.96));
                        border: 2px solid var(--gem-fx-col, #c084fc);
                        box-shadow: 0 0 22px var(--gem-fx-col, #c084fc), 0 6px 20px rgba(0, 0, 0, 0.75);
                        text-align: center;
                        white-space: nowrap;
                        font-family: 'Kanit', sans-serif;
                    }
                `;
                document.head.appendChild(st);
            }

            const prevHud = document.getElementById('center-board-gem-tumble-fx');
            if (prevHud && prevHud.parentNode) {
                prevHud.parentNode.removeChild(prevHud);
            }
            if (this._centerGemDomTimer) {
                clearTimeout(this._centerGemDomTimer);
                this._centerGemDomTimer = null;
            }

            const svgHtml = (typeof window.generateGemSvgPreview === 'function')
                ? window.generateGemSvgPreview(resolvedShape, resolvedGrade, 102, colorHexStr, resolvedAura, resolvedPfx, 'ultra')
                : `<div style="font-size:68px; filter:drop-shadow(0 0 18px ${colorHexStr});">💎</div>`;

            const hudEl = document.createElement('div');
            hudEl.id = 'center-board-gem-tumble-fx';
            hudEl.style.setProperty('--gem-fx-col', colorHexStr);
            hudEl.innerHTML = `
                <div class="cbg-gem-orb-stage">
                    <div class="cbg-gem-tumble-inner">${svgHtml}</div>
                </div>
                <div class="cbg-gem-banner-pill">
                    <div style="font-size:11.5px; font-weight:800; color:#fde047; line-height:1.2;">💎 สกิลอัญมณีทำงาน! (${pName})</div>
                    <div style="font-size:15px; font-weight:900; color:#ffffff; text-shadow:0 0 10px ${colorHexStr}; line-height:1.25;">✨ ${skillTitle}</div>
                </div>
            `;
            document.body.appendChild(hudEl);
            this._centerGemDomTimer = setTimeout(() => {
                if (hudEl && hudEl.parentNode) {
                    hudEl.parentNode.removeChild(hudEl);
                }
            }, 2000);
        }

        if (!this.scene) return;

        // ยกเลิกและเคลียร์เอฟเฟกต์ 3D เดิมถ้ากำลังทำงานอยู่
        if (this._centerGemAnimId) {
            cancelAnimationFrame(this._centerGemAnimId);
            this._centerGemAnimId = null;
        }
        if (this._centerGemTimeout) {
            clearTimeout(this._centerGemTimeout);
            this._centerGemTimeout = null;
        }

        if (!this.centerGemGroup) {
            this.centerGemGroup = new THREE.Group();
            this.centerGemGroup.name = 'centerGemGroup';
            this.scene.add(this.centerGemGroup);
        }

        const group = this.centerGemGroup;
        while (group.children.length > 0) {
            const child = group.children[0];
            group.remove(child);
            if (child.geometry) child.geometry.dispose();
            if (child.material) {
                if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
                else child.material.dispose();
            }
        }

        group.position.set(0, 0, 0);
        group.visible = true;

        // 1. วงแหวนเวทย์มนต์เรืองแสงบนพื้นกระดาน (Magic Summoning Seal Ring ขนาดใหญ่เท่าโซนทอยเต๋า)
        const sealRingGeo = new THREE.RingGeometry(4.2, 7.6, 48);
        const sealRingMat = new THREE.MeshBasicMaterial({
            color: colorHexNum,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.9,
            depthTest: false,
            blending: THREE.AdditiveBlending
        });
        const sealRingMesh = new THREE.Mesh(sealRingGeo, sealRingMat);
        sealRingMesh.rotation.x = -Math.PI / 2;
        sealRingMesh.position.set(0, 0.16, 0);
        sealRingMesh.renderOrder = 75;
        group.add(sealRingMesh);

        // วงแหวนเวทย์ชั้นใน (Inner Rotating Hexagram Ring)
        const innerRingGeo = new THREE.RingGeometry(1.8, 3.6, 6);
        const innerRingMat = new THREE.MeshBasicMaterial({
            color: 0xffffff,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.85,
            depthTest: false,
            blending: THREE.AdditiveBlending
        });
        const innerRingMesh = new THREE.Mesh(innerRingGeo, innerRingMat);
        innerRingMesh.rotation.x = -Math.PI / 2;
        innerRingMesh.position.set(0, 0.18, 0);
        innerRingMesh.renderOrder = 76;
        group.add(innerRingMesh);

        // 2. เสาลำแสงส่องสว่างพุ่งขึ้นสู่ฟ้า (Pillar of Divine Light)
        const beamGeo = new THREE.CylinderGeometry(2.6, 5.8, 16, 24, 1, true);
        const beamMat = new THREE.MeshBasicMaterial({
            color: colorHexNum,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.35,
            depthTest: false,
            blending: THREE.AdditiveBlending
        });
        const beamMesh = new THREE.Mesh(beamGeo, beamMat);
        beamMesh.position.set(0, 7.5, 0);
        beamMesh.renderOrder = 74;
        group.add(beamMesh);

        // 3. ตัวอัญมณีคริสตัล 3D ขนาดยักษ์กึ่งกลางกระดาน (Giant Faceted 3D Gem ขนาดเทียบเท่าลูกเต๋า 3D)
        let gemGeo;
        if (resolvedShape === 'square') {
            gemGeo = new THREE.OctahedronGeometry(3.8, 0);
        } else if (resolvedShape === 'pentagon') {
            gemGeo = new THREE.DodecahedronGeometry(3.6, 0);
        } else {
            gemGeo = new THREE.TetrahedronGeometry(4.2, 0);
        }

        const gemMat = new THREE.MeshStandardMaterial({
            color: colorHexNum,
            emissive: colorHexNum,
            emissiveIntensity: 1.4,
            roughness: 0.1,
            metalness: 0.9,
            depthTest: false
        });
        const gemMesh = new THREE.Mesh(gemGeo, gemMat);
        gemMesh.position.set(0, 4.8, 0);
        gemMesh.renderOrder = 80;
        group.add(gemMesh);

        // แกนคริสตัลสีขาวสว่างข้างใน (Inner Bright Core)
        const coreGeo = new THREE.OctahedronGeometry(1.6, 0);
        const coreMat = new THREE.MeshBasicMaterial({
            color: 0xffffff,
            transparent: true,
            opacity: 0.95,
            depthTest: false,
            blending: THREE.AdditiveBlending
        });
        const coreMesh = new THREE.Mesh(coreGeo, coreMat);
        gemMesh.add(coreMesh);

        // 4. ละอองดาวและคริสตัลบริวารหมุนวน (Orbiting Satellite Particles)
        const satellites = [];
        const satCount = 6;
        const satGeo = new THREE.OctahedronGeometry(0.24, 0);
        const satMat = new THREE.MeshBasicMaterial({
            color: 0xffffff,
            depthTest: false,
            blending: THREE.AdditiveBlending
        });
        for (let i = 0; i < satCount; i++) {
            const sat = new THREE.Mesh(satGeo, satMat);
            sat.userData = { angle: (i / satCount) * Math.PI * 2, radius: 2.5, speed: 3.5 + (i % 2) * 1.5 };
            sat.renderOrder = 81;
            group.add(sat);
            satellites.push(sat);
        }

        // 5. ป้ายโฮโลแกรม 3D ลอยแสดงชื่อสกิลอัญมณี (Holographic 3D Skill Tag)
        const tagCanvas = document.createElement('canvas');
        tagCanvas.width = 640;
        tagCanvas.height = 180;
        const tctx = tagCanvas.getContext('2d');

        // พื้นหลังป้ายสไตล์กระจกนีออน
        tctx.clearRect(0, 0, 640, 180);
        tctx.save();
        if (typeof tctx.roundRect === 'function') {
            tctx.roundRect(16, 16, 608, 148, 28);
        } else {
            tctx.rect(16, 16, 608, 148);
        }
        const grad = tctx.createLinearGradient(16, 16, 624, 164);
        grad.addColorStop(0, 'rgba(15, 23, 42, 0.95)');
        grad.addColorStop(0.5, 'rgba(30, 41, 59, 0.95)');
        grad.addColorStop(1, 'rgba(10, 15, 29, 0.95)');
        tctx.fillStyle = grad;
        tctx.fill();

        // ขอบนีออนเรืองแสง
        const borderHexStr = '#' + Number(colorHexNum).toString(16).padStart(6, '0');
        tctx.strokeStyle = borderHexStr;
        tctx.lineWidth = 5;
        tctx.shadowColor = borderHexStr;
        tctx.shadowBlur = 18;
        tctx.stroke();

        // ข้อความ
        tctx.shadowBlur = 0;
        tctx.textAlign = 'center';
        tctx.textBaseline = 'middle';
        tctx.font = 'bold 30px "Kanit", sans-serif';
        tctx.fillStyle = '#facc15';
        tctx.fillText(`💎 สกิลอัญมณีทำงาน! (${pName})`, 320, 58);

        tctx.font = '900 44px "Kanit", sans-serif';
        tctx.fillStyle = '#ffffff';
        tctx.shadowColor = borderHexStr;
        tctx.shadowBlur = 14;
        tctx.fillText(`✨ [${skillTitle}]`, 320, 114);
        tctx.restore();

        const tagTex = new THREE.CanvasTexture(tagCanvas);
        tagTex.anisotropy = 4;
        const tagSpriteMat = new THREE.SpriteMaterial({
            map: tagTex,
            transparent: true,
            depthTest: false,
            opacity: 1.0
        });
        const tagSprite = new THREE.Sprite(tagSpriteMat);
        tagSprite.scale.set(11.0, 3.1, 1);
        tagSprite.position.set(0, 7.8, 0);
        tagSprite.renderOrder = 85;
        group.add(tagSprite);

        // เล่นเสียงเอฟเฟกต์เวทมนตร์ / ทอยเต๋า
        if (window.soundEngine) {
            if (typeof window.soundEngine.playCardRevealZap === 'function') {
                window.soundEngine.playCardRevealZap('zap_classic', true, 0.9);
            } else if (typeof window.soundEngine.playDiceLand === 'function') {
                window.soundEngine.playDiceLand();
            }
        }

        // 6. แอนิเมชันทอยเด้งหมุนควงกึ่งกลางกระดาน และหายไปใน 2 วินาที (2000ms พอดี)
        const duration = 2000;
        const startTime = performance.now();

        const animStep = (now) => {
            const animElapsed = now - startTime;
            const progress = Math.min(animElapsed / duration, 1.0);

            // 1) ช่วงกระโดดเด้งหมุนขึ้นมา (0 - 450ms)
            if (animElapsed < 450) {
                const p1 = animElapsed / 450;
                const sc = Math.sin(p1 * Math.PI * 0.65) * 1.15;
                gemMesh.scale.set(sc, sc, sc);
                tagSprite.scale.set(11.0 * sc, 3.1 * sc, 1);
                gemMesh.rotation.x += 0.35;
                gemMesh.rotation.y += 0.45;
                gemMesh.rotation.z += 0.28;
                gemMesh.position.y = 1.2 + Math.sin(p1 * Math.PI * 0.8) * 3.6;
            }
            // 2) ช่วงลอยเด่นเปล่งประกายกลางกระดาน (450ms - 1550ms)
            else if (animElapsed < 1550) {
                const hoverT = (animElapsed - 450) * 0.006;
                const pulse = 1.0 + Math.sin(hoverT * 2.5) * 0.12;
                gemMesh.scale.set(pulse, pulse, pulse);
                gemMesh.position.y = 4.2 + Math.sin(hoverT * 2.0) * 0.35;
                gemMesh.rotation.y += 0.06;
                gemMesh.rotation.x += 0.03;
                beamMat.opacity = 0.35 + Math.sin(hoverT * 3.0) * 0.15;
            }
            // 3) ช่วงยุบตัวและหายไปจากกระดาน (1550ms - 2000ms)
            else {
                const p3 = (animElapsed - 1550) / 450;
                const fade = Math.max(0, 1.0 - p3);
                gemMesh.scale.set(fade, fade, fade);
                tagSprite.scale.set(11.0 * fade, 3.1 * fade, 1);
                beamMat.opacity = 0.35 * fade;
                sealRingMat.opacity = 0.9 * fade;
                innerRingMat.opacity = 0.85 * fade;
                satMat.opacity = fade;
            }

            sealRingMesh.rotation.z += 0.045;
            innerRingMesh.rotation.z -= 0.065;

            satellites.forEach(sat => {
                sat.userData.angle += 0.05 * (sat.userData.speed || 3.0);
                const a = sat.userData.angle;
                const r = sat.userData.radius || 2.5;
                sat.position.set(Math.cos(a) * r, gemMesh.position.y + Math.sin(a * 2.0) * 0.6, Math.sin(a) * r);
                sat.rotation.x += 0.08;
                sat.rotation.y += 0.08;
            });

            if (progress < 1.0) {
                this._centerGemAnimId = requestAnimationFrame(animStep);
            } else {
                group.visible = false;
                this._centerGemAnimId = null;
            }
        };

        this._centerGemAnimId = requestAnimationFrame(animStep);
    }

    setBoardTheme(themeName) {
        if (!this.themes[themeName]) return;
        this.boardTheme = themeName;
        try {
            localStorage.setItem('snake_board_theme', themeName);
        } catch (e) { }
        const th = this.themes[themeName];
        this.scene.background = new THREE.Color(th.bgColor);
        this._savedBgColor = this.scene.background.clone();
        this.scene.fog.color = new THREE.Color(th.fogColor);
        if (typeof window.applyGlobalBoardBackground === 'function') window.applyGlobalBoardBackground();
        this.pointLight.color = new THREE.Color(th.light);
        if (this.boardTheme === 'ancient') {
            if (this.ambientLight) {
                this.ambientLight.color.setHex(0xfff3db);
                this.ambientLight.intensity = 1.0;
            }
            if (this.dirLight) {
                this.dirLight.color.setHex(0xfff0cc);
            }
        } else {
            if (this.ambientLight) {
                this.ambientLight.color.setHex(0xffffff);
                this.ambientLight.intensity = 0.8;
            }
            if (this.dirLight) {
                this.dirLight.color.setHex(0xffffff);
            }
        }
        if (this.isMonopolyBoardMode && typeof this.buildMonopolyBoard32 === 'function') {
            this.buildMonopolyBoard32(this.activeMonopolyConfig || window.ACTIVE_MONOPOLY_BOARD || null);
        } else {
            this.buildBoard();
        }
        if (typeof this.rebuildAllCities3D === 'function') {
            this.rebuildAllCities3D();
        }

        // ปรับมุมกล้องให้ฟิตพอดีกับขนาดกระดานรูปทรงใหม่ทันที
        this.updateCameraFit();
        this.logMessage(`เปลี่ยนรูปแบบกระดานเป็น: ${th.name}`, 'highlight');
    }

    setBoardLayout(layoutName) {
        if (this.isMonopolyBoardMode) {
            this.boardLayout = 'hollow_ring';
            if (typeof this.buildMonopolyBoard32 === 'function') {
                this.buildMonopolyBoard32(this.activeMonopolyConfig || window.ACTIVE_MONOPOLY_BOARD || null);
            }
            return;
        }
        const valid = ['square', 'spiral', 'hexagon', 'rectangle', 'diamond_ring'];
        const isCustomLayout = String(layoutName || '').startsWith('custom_');
        if (!valid.includes(layoutName) && !isCustomLayout) layoutName = 'square';
        this.boardLayout = layoutName;
        try {
            localStorage.setItem('snake_board_layout', layoutName);
        } catch (e) { }

        this.buildBoard();
        if (typeof this.rebuildAllCities3D === 'function') {
            this.rebuildAllCities3D();
        }

        // ปรับมุมกล้องให้ฟิตพอดีกับขนาดกระดานรูปทรงใหม่ทันที
        this.updateCameraFit();

        // Reposition all active player pawns to match new layout coordinates
        const goalTileNum = this.totalTilesCount || 100;
        (this.players || []).forEach((p, idx) => {
            if (p && p.mesh && this.tiles[p.currentTile]) {
                const off = (typeof this.getPawnFrontOffset === 'function') ? this.getPawnFrontOffset(p, p.currentTile, idx) : { x: 0, z: 0 };
                const tPos = this.tiles[p.currentTile];
                p.mesh.position.set(tPos.x + off.x, (tPos.y || 0) + ((p.currentTile === 1 || p.currentTile === goalTileNum) ? 1.18 : 0.52), tPos.z + off.z);
            }
        });

        const layoutNames = {
            'square': 'กระดานสี่เหลี่ยมดั้งเดิม (Classic Square)',
            'rectangle': 'กระดานสี่เหลี่ยมผืนผ้าแนวกว้าง (Rectangle Widescreen)',
            'spiral': 'กระดานทรงกลมก้นหอย (Spiral Galaxy)',
            'hexagon': 'กระดานทรงหกเหลี่ยม (Hexagon Hive)',
            'diamond_ring': 'กระดานวงแหวนเพชร (Diamond Ring)'
        };
        this.logMessage(`เปลี่ยนรูปทรงกระดานเป็น: ${layoutNames[layoutName] || layoutName}`, 'highlight');
    }

    /**
     * สวมค่าการตั้งค่ากระดาน 3D จาก AI Board Studio (รูปทรงสี่เหลี่ยมผืนผ้า/หลายทรง, ชื่อเมือง, การ์ดดวง, เอฟเฟกต์, ตำแหน่งปุ่มทอย)
     */
    applyCustomBoardConfig(boardObj) {
        if (!boardObj || typeof boardObj !== 'object') return;
        this.activeCustomBoard = boardObj;
        this.boardLayout = boardObj.shape_type || 'rectangle';
        this.customGridCols = Math.max(4, Math.min(20, Number(boardObj.grid_cols) || 12));
        this.customGridRows = Math.max(4, Math.min(20, Number(boardObj.grid_rows) || 8));
        this.totalTilesCount = Math.max(20, Math.min(200, Number(boardObj.total_tiles) || 100));
        this.tileSize = Math.max(3.5, Math.min(9.5, Number(boardObj.tile_size) || 6.2));
        this.tileGap = Math.max(0.05, Math.min(2.0, Number(boardObj.tile_gap) || 0.4));

        // 1. Theme Colors
        const tc = boardObj.theme_config || {};
        const parseHexInt = (h, fallback) => {
            if (!h) return fallback;
            const clean = String(h).replace('#', '').trim();
            const v = parseInt(clean, 16);
            return isNaN(v) ? fallback : v;
        };
        const clampDarkBg = (hexVal, fallback = 0x060b16) => {
            const v = parseHexInt(hexVal, fallback);
            // ป้องกันสีพื้นหลังขาวโพลน (White Screen) ที่เกิดจาก AI Gen สีสว่างเกินไป
            const r = (v >> 16) & 255;
            const g = (v >> 8) & 255;
            const b = v & 255;
            const luma = 0.299 * r + 0.587 * g + 0.114 * b;
            if (luma > 140) return fallback;
            return v;
        };
        this.themes['custom_ai'] = {
            name: boardObj.board_name || 'AI 3D Board',
            bgColor: clampDarkBg(tc.bgColor, 0x060b16),
            fogColor: clampDarkBg(tc.fogColor || tc.bgColor, 0x060b16),
            tileEven: parseHexInt(tc.tileEven, 0x0f203c),
            tileOdd: parseHexInt(tc.tileOdd, 0x173058),
            border: parseHexInt(tc.border, 0x00e5ff),
            ambient: 0x334155,
            light: parseHexInt(tc.border, 0x00e5ff),
            ladder: parseHexInt(tc.ladder, 0x38bdf8),
            snake: parseHexInt(tc.snake, 0xf43f5e),
            particle: parseHexInt(tc.border, 0x00e5ff),
            cssEven: tc.tileEven || '#0f203c',
            cssOdd: tc.tileOdd || '#173058',
            cssBorder: tc.border || '#00e5ff'
        };
        this.boardTheme = 'custom_ai';

        const customBg = this.themes.custom_ai.bgColor || 0x070b12;
        if (this.scene) {
            this.scene.background = new THREE.Color(customBg);
            this._savedBgColor = this.scene.background.clone();
            if (this.scene.fog) this.scene.fog.color = new THREE.Color(this.themes.custom_ai.fogColor || customBg);
        }
        if (this.renderer) {
            this.renderer.setClearColor(customBg, 1.0);
        }
        if (typeof window.applyGlobalBoardBackground === 'function') window.applyGlobalBoardBackground();

        // 2. City Names
        if (boardObj.cities && typeof boardObj.cities === 'object') {
            this.tileProvinces = {};
            for (let i = 1; i <= 100; i++) {
                this.tileProvinces[i] = boardObj.cities[i] || boardObj.cities[String(i)] || THAI_PROVINCES[(i - 1) % THAI_PROVINCES.length];
            }
        }

        // 3. Special Tiles (Chance cards, Tax, Gamble, Destroy, Jail, Ladders, Snakes)
        const sp = boardObj.special_tiles || {};
        if (Array.isArray(sp.chanceTiles)) this.chanceTiles = sp.chanceTiles.map(Number);
        if (Array.isArray(sp.taxTiles)) this.taxTiles = sp.taxTiles.map(Number);
        if (Array.isArray(sp.gambleTiles)) this.gambleTiles = sp.gambleTiles.map(Number);
        if (Array.isArray(sp.destroyTiles)) this.destroyTiles = sp.destroyTiles.map(Number);
        if (sp.jailTile) this.jailTile = Number(sp.jailTile);
        if (sp.ladders && typeof sp.ladders === 'object' && Object.keys(sp.ladders).length > 0) {
            this.ladders = {};
            for (const [k, v] of Object.entries(sp.ladders)) {
                this.ladders[Number(k)] = Number(v);
            }
        }
        if (sp.snakes && typeof sp.snakes === 'object' && Object.keys(sp.snakes).length > 0) {
            this.snakes = {};
            this.snakeTailToHead = {};
            for (const [k, v] of Object.entries(sp.snakes)) {
                this.snakes[Number(k)] = Number(v);
                this.snakeTailToHead[Number(v)] = Number(k);
            }
        }

        // 4. Effects & Source Image Texture
        this.customEffects = boardObj.effects || {};
        if (this.dirLight && this.customEffects.lightIntensity) {
            this.dirLight.intensity = Number(this.customEffects.lightIntensity) || 1.3;
        }
        if (boardObj.source_image_url && boardObj.apply_board_texture && window.THREE) {
            try {
                new THREE.TextureLoader().load(
                    boardObj.source_image_url,
                    (tex) => {
                        this.customBoardSurfaceTexture = tex;
                        try {
                            this.buildBoard();
                            if (!this.isMatchActive && typeof this.setupIdlePreview === 'function') {
                                this.setupIdlePreview(window.DEFAULT_USER || null);
                            } else {
                                this.updateCameraFit();
                            }
                        } catch (texBuildErr) {
                            console.warn('[CustomBoard] Texture apply error:', texBuildErr);
                        }
                    },
                    undefined,
                    (err) => {
                        console.warn('[CustomBoard] Texture load fallback:', err);
                        this.customBoardSurfaceTexture = null;
                        try {
                            this.buildBoard();
                            if (!this.isMatchActive && typeof this.setupIdlePreview === 'function') {
                                this.setupIdlePreview(window.DEFAULT_USER || null);
                            } else {
                                this.updateCameraFit();
                            }
                        } catch (texFbErr) {
                            console.warn('[CustomBoard] Texture fallback build error:', texFbErr);
                        }
                    }
                );
            } catch (err) {
                console.warn('[CustomBoard] TextureLoader sync error:', err);
                this.customBoardSurfaceTexture = null;
            }
        } else {
            this.customBoardSurfaceTexture = null;
        }

        // 5. Roll Button Position, 3D Dice Position & Hollow Center Config
        const rb = boardObj.roll_btn_config || {};
        this.hollowCenter = Boolean(rb.hollowCenter);
        this.centerHoleCols = Math.max(2, Math.min(16, Number(rb.centerHoleCols) || 6));
        this.centerHoleRows = Math.max(1, Math.min(14, Number(rb.centerHoleRows) || 6));
        this.holeStartRow = (rb.holeStartRow !== undefined) ? Number(rb.holeStartRow) : 2;
        this.hollowMode = rb.hollowMode || 'grid_cutout';
        this.hollowStyle = rb.hollowStyle || 'arena_tray';
        this.shadowDiveAcrossCenter = (rb.shadowDiveAcrossCenter !== undefined) ? Boolean(rb.shadowDiveAcrossCenter) : true;
        this.shadowDiveStyle = rb.shadowDiveStyle || 'shadow_fade';
        this.shadowDiveDurationMs = Number(rb.shadowDiveDurationMs || 480);
        this.stepDurationMs = Number(rb.stepDurationMs || 380);
        this.badgeConfig = this.loadBadgeConfig();

        try {
            this.buildBoard();
            this.applyRollButtonPositionConfig(rb);
            if (typeof this.rebuildAllCities3D === 'function') {
                this.rebuildAllCities3D();
            }
            if (!this.isMatchActive && typeof this.setupIdlePreview === 'function') {
                this.setupIdlePreview(window.DEFAULT_USER || null);
            } else {
                this.updateCameraFit();
            }
            this.logMessage(`🗺️ โหลดกระดาน AI 3D: "${boardObj.board_name}" สำเร็จ!`, 'highlight');
        } catch (bBuildErr) {
            console.warn('[CustomBoard] Board build error:', bBuildErr);
            this.cancelCustomBoardConfig();
        }
    }

    /**
     * ยกเลิกกระดาน AI ที่กำหนดเอง และกลับสู่กระดานมาตรฐานของระบบ
     */
    /**
     * สร้างกระดานเกมส์เศรษฐี 32 ช่อง (9 ช่องต่อแถวรอบกรอบ) แยกจากกระดานบันไดงู
     */
    getDisplayTileNumber(tileNum) {
        const n = Number(tileNum) || 1;
        if (this.isMonopolyBoardMode) {
            return n <= 1 ? 'START' : String(n - 1);
        }
        return String(n);
    }

    getDefaultMonopoly32TilesFallback() {
        return [
            { index: 1, type: 'START', name: 'START', color: '#22c55e', price: 0, toll: 0, is_expensive: 0 },
            { index: 2, type: 'CITY', name: 'บึงกาฬ', color: '#ef4444', price: 100000, toll: 35000, is_expensive: 0 },
            { index: 3, type: 'CITY', name: 'กำแพงเพชร', color: '#ef4444', price: 130000, toll: 45500, is_expensive: 0 },
            { index: 4, type: 'CHANCE', name: 'การ์ดดวง', color: '#fbbf24', price: 0, toll: 0, is_expensive: 0 },
            { index: 5, type: 'TAX', name: 'ภาษี', color: '#64748b', price: 0, toll: 120000, is_expensive: 0 },
            { index: 6, type: 'CITY', name: 'บางแสน', color: '#06b6d4', price: 220000, toll: 77000, is_expensive: 0 },
            { index: 7, type: 'CITY', name: 'ประจวบฯ', color: '#06b6d4', price: 250000, toll: 87500, is_expensive: 0 },
            { index: 8, type: 'EXPRESSWAY', name: 'ทางด่วน', color: '#00e5ff', price: 0, toll: 0, is_expensive: 0 },
            { index: 9, type: 'ISLAND', name: 'เกาะร้าง', color: '#0ea5e9', price: 0, toll: 0, is_expensive: 0 },
            { index: 10, type: 'CITY', name: 'นครสวรรค์', color: '#ec4899', price: 340000, toll: 119000, is_expensive: 0 },
            { index: 11, type: 'CITY', name: 'กรุงเทพฯ', color: '#ec4899', price: 370000, toll: 129500, is_expensive: 0 },
            { index: 12, type: 'GAMBLE', name: 'สุ่มโบนัส', color: '#c084fc', price: 0, toll: 0, is_expensive: 0 },
            { index: 13, type: 'TAX', name: 'ภาษี', color: '#64748b', price: 0, toll: 180000, is_expensive: 0 },
            { index: 14, type: 'CITY', name: 'อุตรดิตถ์', color: '#f97316', price: 460000, toll: 161000, is_expensive: 0 },
            { index: 15, type: 'CITY', name: 'ยะลา', color: '#f97316', price: 490000, toll: 171500, is_expensive: 0 },
            { index: 16, type: 'CHANCE', name: 'การ์ดดวง', color: '#fbbf24', price: 0, toll: 0, is_expensive: 0 },
            { index: 17, type: 'OLYMPIC', name: 'พื้นที่คูณ 2,4,6,8', color: '#f59e0b', price: 0, toll: 0, is_expensive: 0 },
            { index: 18, type: 'CITY', name: 'เชียงใหม่', color: '#10b981', price: 580000, toll: 203000, is_expensive: 1 },
            { index: 19, type: 'CITY', name: 'ภูเก็ต', color: '#10b981', price: 610000, toll: 213500, is_expensive: 1 },
            { index: 20, type: 'CHANCE', name: 'การ์ดดวง', color: '#fbbf24', price: 0, toll: 0, is_expensive: 0 },
            { index: 21, type: 'DESTROY', name: 'พื้นที่ระเบิด', color: '#f43f5e', price: 0, toll: 0, is_expensive: 0 },
            { index: 22, type: 'CITY', name: 'นครนายก', color: '#8b5cf6', price: 700000, toll: 245000, is_expensive: 1 },
            { index: 23, type: 'CITY', name: 'หนองคาย', color: '#8b5cf6', price: 730000, toll: 255500, is_expensive: 1 },
            { index: 24, type: 'TAX', name: 'ภาษี', color: '#64748b', price: 0, toll: 240000, is_expensive: 0 },
            { index: 25, type: 'WORLD_TRAVEL', name: 'พื้นที่พิเศษ (เลือกเดิน)', color: '#0284c7', price: 0, toll: 0, is_expensive: 0 },
            { index: 26, type: 'CITY', name: 'ชลบุรี', color: '#3b82f6', price: 820000, toll: 287000, is_expensive: 1 },
            { index: 27, type: 'CITY', name: 'พะเยา', color: '#3b82f6', price: 850000, toll: 297500, is_expensive: 1 },
            { index: 28, type: 'GOD_TILE', name: 'พื้นที่พระเจ้า', color: '#eab308', price: 0, toll: 0, is_expensive: 0 },
            { index: 29, type: 'TAX', name: 'ภาษี', color: '#64748b', price: 0, toll: 300000, is_expensive: 0 },
            { index: 30, type: 'GAMBLE', name: 'สุ่มโบนัส', color: '#c084fc', price: 0, toll: 0, is_expensive: 0 },
            { index: 31, type: 'CITY', name: 'ราชบุรี', color: '#eab308', price: 970000, toll: 339500, is_expensive: 1 },
            { index: 32, type: 'CITY', name: 'อำนาจเจริญ', color: '#eab308', price: 1000000, toll: 350000, is_expensive: 1 }
        ];
    }

    buildMonopolyBoard32(monopolyCfg = null) {
        this.isMonopolyBoardMode = true;
        this.activeMonopolyConfig = monopolyCfg || window.ACTIVE_MONOPOLY_BOARD || {};
        this.activeCustomBoard = null;
        this.boardLayout = 'hollow_ring';
        this.customGridCols = 9;
        this.customGridRows = 9;
        this.totalTilesCount = 32;
        this.tileSize = 6.8;
        this.tileGap = 0.28;
        this.hollowCenter = true;
        this.hollowMode = 'ring_loop';
        this.centerHoleCols = 7;
        this.centerHoleRows = 7;
        this.hollowStyle = 'arena_tray';
        this.snakes = {};
        this.ladders = {};
        this.snakeTailToHead = {};
        this.ladderObjects = {};
        this.snakeObjects = {};

        const rawTiles = Array.isArray(this.activeMonopolyConfig?.tiles) && this.activeMonopolyConfig.tiles.length >= 32
            ? this.activeMonopolyConfig.tiles
            : this.getDefaultMonopoly32TilesFallback();
        const tiles = rawTiles.map((t, idx) => Object.assign({}, t, { index: Number(t.index || (idx + 1)) }));

        const chanceArr = [];
        const taxArr = [];
        const olympicArr = [];
        const worldTravelArr = [];
        const expresswayArr = [];
        const gambleArr = [];
        const destroyArr = [];
        const godArr = [];
        let islandTile = 9;
        let olympicTile = 17;
        let worldTravelTile = 25;

        this.tileProvinces = this.tileProvinces || {};
        this.provinces = this.provinces || [];

        tiles.forEach((t, idx) => {
            const num = Number(t.index || (idx + 1));
            const typ = String(t.type || 'CITY').toUpperCase();
            if (t.name) {
                this.tileProvinces[num] = t.name;
                this.provinces[num - 1] = t.name;
            }
            if (typ === 'CHANCE') chanceArr.push(num);
            else if (typ === 'TAX') taxArr.push(num);
            else if (typ === 'ISLAND') islandTile = num;
            else if (typ === 'OLYMPIC' || typ === 'MULTIPLIER_ZONE') {
                olympicTile = num;
                olympicArr.push(num);
            } else if (typ === 'WORLD_TRAVEL' || typ === 'SPECIAL_WARP') {
                worldTravelTile = num;
                worldTravelArr.push(num);
            } else if (typ === 'EXPRESSWAY') {
                expresswayArr.push(num);
            } else if (typ === 'GAMBLE' || typ === 'BONUS_GAME') {
                gambleArr.push(num);
            } else if (typ === 'DESTROY' || typ === 'BOMB_TILE') {
                destroyArr.push(num);
            } else if (typ === 'GOD_TILE') {
                godArr.push(num);
            }
        });

        this.chanceTiles = chanceArr;
        this.taxTiles = taxArr;
        this.jailTile = islandTile;
        this.olympicTile = olympicTile;
        this.olympicTiles = olympicArr.length > 0 ? olympicArr : [olympicTile];
        this.worldTravelTile = worldTravelTile;
        this.worldTravelTiles = worldTravelArr.length > 0 ? worldTravelArr : [worldTravelTile];
        this.expresswayTiles = expresswayArr;
        this.gambleTiles = gambleArr;
        this.destroyTiles = destroyArr;
        this.godTiles = godArr;
        this.monopolyTilesList = tiles;
        this.monopolyStageSkillCode = String(this.activeMonopolyConfig?.stage_skill_code || 'BLACK_HOLE').toUpperCase();
        this.monopolyStageSkillName = this.activeMonopolyConfig?.stage_skill_name || '🕳️ หลุมดำสุ่มย้ายทุกการทอย';
        let parsedSkCfg = {};
        try {
            parsedSkCfg = typeof this.activeMonopolyConfig?.stage_skill_config === 'string'
                ? JSON.parse(this.activeMonopolyConfig.stage_skill_config || '{}')
                : (this.activeMonopolyConfig?.stage_skill_config || {});
        } catch (e) { }
        this.monopolyStageSkillConfig = parsedSkCfg;
        this.monopolyBlackHoleTiles = [];
        this.monopolyFogTiles = [];
        this.monopolyHazardMeshes = [];

        if (typeof this.buildBoard === 'function') {
            this.buildBoard();
        }
        this.setupMonopolySnakesAndLadders();
        this.updateMonopolyExclusiveUI();
        if (!this.isMatchActive && typeof this.setupIdlePreview === 'function') {
            this.setupIdlePreview(window.DEFAULT_USER || null);
        } else if (typeof this.updateCameraFit === 'function') {
            this.updateCameraFit();
        }
    }

    /**
     * สุ่มย้ายตำแหน่งหลุมดำ (2 จุด) หรือหมอกพิษ (3 เมืองติดกัน) และสร้างเอฟเฟกต์ 3D บนกระดานเกมส์เศรษฐี
     */
    relocateMonopolyStageHazards(announce = false, rng = null) {
        if (!this.isMonopolyBoardMode || !this.effectsGroup) return;
        const rand = (typeof rng === 'function') ? rng : Math.random;

        // ล้างโมเดลหลุมดำ/หมอกเก่าออกก่อน
        if (Array.isArray(this.monopolyHazardMeshes)) {
            this.monopolyHazardMeshes.forEach(m => {
                try {
                    if (m.parent) m.parent.remove(m);
                    this.disposeHierarchy(m);
                } catch (e) { }
            });
        }
        this.monopolyHazardMeshes = [];
        this.monopolyBlackHoleTiles = [];
        this.monopolyFogTiles = [];

        const sk = this.monopolyStageSkillCode || 'BLACK_HOLE';

        if (sk === 'BLACK_HOLE') {
            const candidates = [];
            for (let t = 2; t <= 32; t++) {
                candidates.push(t);
            }
            for (let i = candidates.length - 1; i > 0; i--) {
                const j = Math.floor(rand() * (i + 1));
                const tmp = candidates[i];
                candidates[i] = candidates[j];
                candidates[j] = tmp;
            }
            this.monopolyBlackHoleTiles = candidates.slice(0, 2);

            this.renderMonopolyBlackHoleMeshes();

            if (announce) {
                this.logMessage(`🕳️ [สกิลด่าน: หลุมดำ] ย้ายหลุมดำไปที่ช่อง ${this.monopolyBlackHoleTiles.join(' และ ')}!`, 'skill');
            }
        } else if (sk === 'TOXIC_FOG') {
            // หา 3 เมือง/ช่องติดกันที่ไม่ใช่ช่องมุม (เช่น 2..6, 10..14, 18..22, 26..30)
            const validStarts = [2, 3, 4, 5, 6, 10, 11, 12, 13, 14, 18, 19, 20, 21, 22, 26, 27, 28, 29, 30];
            const startT = validStarts[Math.floor(rand() * validStarts.length)];
            this.monopolyFogTiles = [startT, startT + 1, startT + 2];

            this.renderMonopolyFogMeshes();

            if (announce) {
                const pct = Number(this.monopolyStageSkillConfig?.fog_percent || 10);
                this.logMessage(`🌫️ [สกิลด่าน: หมอกพิษ] ย้ายหมอกคลุม 3 ช่องติดกัน (${this.monopolyFogTiles.join(', ')}) เดินผ่านเสียเงิน ${pct}%!`, 'skill');
            }
        }
    }

    renderMonopolyBlackHoleMeshes() {
        (this.monopolyBlackHoleTiles || []).forEach(tNum => {
            const pos = this.tiles[tNum];
            if (!pos) return;
            const grp = new THREE.Group();
            const disc = new THREE.Mesh(
                new THREE.CircleGeometry(2.4, 24),
                new THREE.MeshBasicMaterial({ color: 0x090d16, transparent: true, opacity: 0.92, side: THREE.DoubleSide })
            );
            disc.rotation.x = -Math.PI / 2;
            const ring = new THREE.Mesh(
                new THREE.TorusGeometry(2.4, 0.22, 12, 32),
                new THREE.MeshBasicMaterial({ color: 0xa855f7, transparent: true, opacity: 0.9 })
            );
            ring.rotation.x = Math.PI / 2;
            grp.add(disc);
            grp.add(ring);
            grp.position.set(pos.x, (pos.y || 0) + 0.55, pos.z);
            this.boardGroup.add(grp);
            this.monopolyHazardMeshes.push(grp);
        });
    }

    renderMonopolyFogMeshes() {
        (this.monopolyFogTiles || []).forEach(tNum => {
            const pos = this.tiles[tNum];
            if (!pos) return;
            const grp = new THREE.Group();
            const fogCloud = new THREE.Mesh(
                new THREE.CylinderGeometry(2.6, 2.9, 1.3, 18),
                new THREE.MeshBasicMaterial({ color: 0x10b981, transparent: true, opacity: 0.38, depthWrite: false })
            );
            fogCloud.position.y = 0.65;
            const fogRing = new THREE.Mesh(
                new THREE.RingGeometry(2.2, 2.8, 24),
                new THREE.MeshBasicMaterial({ color: 0x34d399, transparent: true, opacity: 0.65, side: THREE.DoubleSide })
            );
            fogRing.rotation.x = -Math.PI / 2;
            fogRing.position.y = 0.12;
            grp.add(fogCloud);
            grp.add(fogRing);
            grp.position.set(pos.x, (pos.y || 0) + 0.45, pos.z);
            this.boardGroup.add(grp);
            this.monopolyHazardMeshes.push(grp);
        });
    }

    applySyncedMonopolyHazards(blackHoleTiles, fogTiles) {
        if (!this.isMonopolyBoardMode || !this.boardGroup || !this.tiles) return;
        const normList = (arr) => Array.isArray(arr) ? arr.map(Number).filter(n => n > 0) : [];
        const nextBH = normList(blackHoleTiles);
        const nextFog = normList(fogTiles);
        if (JSON.stringify(nextBH) === JSON.stringify(this.monopolyBlackHoleTiles || []) &&
            JSON.stringify(nextFog) === JSON.stringify(this.monopolyFogTiles || [])) {
            return;
        }
        if (Array.isArray(this.monopolyHazardMeshes)) {
            this.monopolyHazardMeshes.forEach(m => {
                try {
                    if (m.parent) m.parent.remove(m);
                    this.disposeHierarchy(m);
                } catch (e) { }
            });
        }
        this.monopolyHazardMeshes = [];
        this.monopolyBlackHoleTiles = nextBH;
        this.monopolyFogTiles = nextFog;
        if (nextBH.length > 0) this.renderMonopolyBlackHoleMeshes();
        if (nextFog.length > 0) this.renderMonopolyFogMeshes();
    }

    createSeededRng(seed) {
        let s = (Number(seed) || 1) >>> 0;
        if (s === 0) s = 1;
        return () => {
            s = (s + 0x6D2B79F5) >>> 0;
            let t = Math.imul(s ^ (s >>> 15), 1 | s);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    applySyncedSnakesAndLadders(laddersObj, snakesObj) {
        if (!this.boardGroup || !this.tiles) return;
        const normMap = (obj) => {
            const out = {};
            if (obj && typeof obj === 'object') {
                for (const [k, v] of Object.entries(obj)) {
                    const nk = Number(k);
                    const nv = Number(v);
                    if (nk > 0 && nv > 0) out[nk] = nv;
                }
            }
            return out;
        };
        const nextLadders = normMap(laddersObj);
        const nextSnakes = normMap(snakesObj);
        if (JSON.stringify(nextLadders) === JSON.stringify(this.ladders || {}) &&
            JSON.stringify(nextSnakes) === JSON.stringify(this.snakes || {})) {
            return;
        }

        if (this.ladderObjects) {
            for (const k in this.ladderObjects) {
                const obj = this.ladderObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.ladderObjects = {};
        this.ladders = nextLadders;

        if (this.snakeObjects) {
            for (const k in this.snakeObjects) {
                const obj = this.snakeObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.snakeObjects = {};
        this.snakes = nextSnakes;
        this.snakeTailToHead = {};
        for (const [hd, tl] of Object.entries(this.snakes)) {
            this.snakeTailToHead[Number(tl)] = Number(hd);
        }

        const ladderColors = [0xffd700, 0x00e5ff, 0x10b981, 0x38bdf8];
        let li = 0;
        for (const [st, en] of Object.entries(this.ladders)) {
            const s = Number(st);
            const e = Number(en);
            if (this.tiles[s] && this.tiles[e]) {
                this.create3DLadder(this.tiles[s], this.tiles[e], ladderColors[li % ladderColors.length], s, e);
                li++;
            }
        }

        const snakeColors = [0xef4444, 0xa855f7, 0x10b981, 0xf59e0b];
        let si = 0;
        for (const [hd, tl] of Object.entries(this.snakes)) {
            const h = Number(hd);
            const t = Number(tl);
            if (this.tiles[h] && this.tiles[t]) {
                this.create3DSnake(this.tiles[h], this.tiles[t], snakeColors[si % snakeColors.length], h, t);
                si++;
            }
        }

        if (typeof this.updateAllTileElevations === 'function') {
            this.updateAllTileElevations();
        }
    }

    setupMonopolySnakesAndLadders() {
        const rId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
        const rng = rId > 0 ? this.createSeededRng(rId * 131 + 17) : null;
        this.relocateMonopolySnakesAndLadders(false, rng);
    }

    relocateMonopolySnakesAndLadders(announce = false, rng = null) {
        if (!this.isMonopolyBoardMode || !this.boardGroup || !this.tiles) return;
        const rand = (typeof rng === 'function') ? rng : Math.random;

        // 1. นำบันได 3D เดิมออกจากกระดาน
        if (this.ladderObjects) {
            for (const k in this.ladderObjects) {
                const obj = this.ladderObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.ladderObjects = {};
        this.ladders = {};

        // 2. นำงู 3D เดิมออกจากกระดาน
        if (this.snakeObjects) {
            for (const k in this.snakeObjects) {
                const obj = this.snakeObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.snakeObjects = {};
        this.snakes = {};
        this.snakeTailToHead = {};

        // 3. สุ่มวางบันไดและงูให้สามารถย้ายไปลงที่ เกาะร้าง, มุมทั้ง 4 (START/เกาะร้าง/คูณ/พื้นที่พิเศษ), พื้นที่พิเศษ, ดวง, ภาษี หรือเมืองใดก็ได้ทั่วทั้งกระดาน 1..32!
        const used = new Set();

        const pickTileInRange = (min, max) => {
            const pool = [];
            for (let t = min; t <= max; t++) {
                if (!used.has(t)) pool.push(t);
            }
            if (pool.length === 0) return null;
            const chosen = pool[Math.floor(rand() * pool.length)];
            used.add(chosen);
            return chosen;
        };

        // สุ่มสร้างบันได 2 อัน (สามารถพาดไปลงเกาะร้าง มุม หรือพื้นที่พิเศษได้ทั้งกระดาน)
        const l1Start = pickTileInRange(2, 16);
        if (l1Start) {
            const l1End = pickTileInRange(Math.min(32, l1Start + 3), Math.min(32, l1Start + 14));
            if (l1End && l1End > l1Start) {
                this.ladders[l1Start] = l1End;
            } else {
                used.delete(l1Start);
            }
        }

        const l2Start = pickTileInRange(10, 26);
        if (l2Start) {
            const l2End = pickTileInRange(Math.min(32, l2Start + 3), 32);
            if (l2End && l2End > l2Start) {
                this.ladders[l2Start] = l2End;
            } else {
                used.delete(l2Start);
            }
        }

        // สุ่มสร้างงู 2 ตัว (สามารถพาดลงไปที่เกาะร้าง มุม จุด START หรือพื้นที่พิเศษได้ทั้งกระดาน)
        const s1Head = pickTileInRange(8, 20);
        if (s1Head) {
            const s1Tail = pickTileInRange(1, Math.max(1, s1Head - 3));
            if (s1Tail && s1Head > s1Tail) {
                this.snakes[s1Head] = s1Tail;
                this.snakeTailToHead[s1Tail] = s1Head;
            } else {
                used.delete(s1Head);
            }
        }

        const s2Head = pickTileInRange(18, 32);
        if (s2Head) {
            const s2Tail = pickTileInRange(1, Math.max(1, s2Head - 4));
            if (s2Tail && s2Head > s2Tail) {
                this.snakes[s2Head] = s2Tail;
                this.snakeTailToHead[s2Tail] = s2Head;
            } else {
                used.delete(s2Head);
            }
        }

        // สุ่มสีสวยงามและสร้างโมเดล 3D
        const ladderColors = [0xffd700, 0x00e5ff, 0x10b981, 0x38bdf8];
        let li = 0;
        for (const [st, en] of Object.entries(this.ladders)) {
            const s = Number(st);
            const e = Number(en);
            if (this.tiles[s] && this.tiles[e]) {
                this.create3DLadder(this.tiles[s], this.tiles[e], ladderColors[li % ladderColors.length], s, e);
                li++;
            }
        }

        const snakeColors = [0xef4444, 0xa855f7, 0x10b981, 0xf59e0b];
        let si = 0;
        for (const [hd, tl] of Object.entries(this.snakes)) {
            const h = Number(hd);
            const t = Number(tl);
            if (this.tiles[h] && this.tiles[t]) {
                this.create3DSnake(this.tiles[h], this.tiles[t], snakeColors[si % snakeColors.length], h, t);
                si++;
            }
        }

        if (announce) {
            const lStrs = Object.entries(this.ladders).map(([s, e]) => `${this.getDisplayTileNumber(s)}➜${this.getDisplayTileNumber(e)}`);
            const sStrs = Object.entries(this.snakes).map(([h, t]) => `${this.getDisplayTileNumber(h)}➔${this.getDisplayTileNumber(t)}`);
            this.logMessage(`🎲 [งู & บันได] สุ่มย้ายตำแหน่งใหม่ทั่วกระดาน! บันได: [${lStrs.join(', ') || '-'}] | งู: [${sStrs.join(', ') || '-'}]`, 'skill');
        }
    }

    triggerMonopolyStageSkillOnRoll(player) {
        if (!this.isMonopolyBoardMode || !player) return;

        // สุ่มย้ายงูกับบันไดไปทั้งกระดาน โดยทุกการทอย!
        this.relocateMonopolySnakesAndLadders(true);

        const sk = this.monopolyStageSkillCode || 'BLACK_HOLE';

        // ย้ายหลุมดำทุกครั้งที่ทอย / ย้ายหมอกแบบสุ่มทุกครั้งที่ทอย
        if (sk === 'BLACK_HOLE' || sk === 'TOXIC_FOG') {
            this.relocateMonopolyStageHazards(true);
        }

        // สกิลอื่นๆ ที่ทำงานเมื่อเริ่มทอย
        if (sk === 'CASINO_JACKPOT' && player.consecutiveDoubles > 0) {
            player.matchGold = (player.matchGold || 0) + 150000;
            this.showSkillBanner(`🎰 [สกิลด่าน: แจ็กพอตคาสิโน] ${player.username} รับโบนัส +150,000 ทอง!`);
        } else if (sk === 'CYBER_HACK' && Math.random() < 0.28) {
            const opps = (this.players || []).filter(p => p && p.id !== player.id && !p.isBankrupt && p.matchGold > 50000);
            if (opps.length > 0) {
                const vic = opps[Math.floor(Math.random() * opps.length)];
                const steal = Math.round(vic.matchGold * 0.05);
                vic.matchGold -= steal;
                player.matchGold += steal;
                this.showSkillBanner(`⚡ [ไซเบอร์แฮก] ${player.username} ดูดเงิน ${vic.username} +${this.formatCompactGold(steal)}!`);
            }
        } else if (sk === 'VOLCANO_ERUPT' && Math.random() < 0.22) {
            const oppKeys = Object.keys(this.cityStates || {}).filter(k => this.cityStates[k] && this.cityStates[k].ownerId !== player.id && !this.cityStates[k].isLandmark && this.cityStates[k].houses > 1);
            if (oppKeys.length > 0) {
                const k = oppKeys[Math.floor(Math.random() * oppKeys.length)];
                this.cityStates[k].houses = Math.max(1, this.cityStates[k].houses - 1);
                this.showSkillBanner(`🌋 [ภูเขาไฟปะทุ] ลดระดับบ้านคู่แข่งที่ช่อง ${k} ลง 1 หลัง!`);
            }
        } else if (sk === 'OLYMPIC_FEVER' && Math.random() < 0.25) {
            const ownKeys = Object.keys(this.cityStates || {}).filter(k => this.cityStates[k]);
            if (ownKeys.length > 0) {
                const k = ownKeys[Math.floor(Math.random() * ownKeys.length)];
                this.cityStates[k].multiplier = Math.min(8, (this.cityStates[k].multiplier || 1) * 2);
                this.showSkillBanner(`🏅 [โอลิมปิกทวีคูณ] ช่อง ${k} ค่าผ่านทางพุ่งเป็น X${this.cityStates[k].multiplier}!`);
            }
        }
    }

    handleMonopolyStepHazard(player, tileNum, isFinalStep = false) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt) return;
        const sk = this.monopolyStageSkillCode || 'BLACK_HOLE';

        // เดินผ่านหมอกพิษ 3 เมืองติดกัน: เงินหายไป %
        if (sk === 'TOXIC_FOG' && Array.isArray(this.monopolyFogTiles) && this.monopolyFogTiles.includes(tileNum)) {
            const pct = Math.max(1, Math.min(50, Number(this.monopolyStageSkillConfig?.fog_percent || 10)));
            const loss = Math.max(1000, Math.round((player.matchGold || 0) * (pct / 100)));
            player.matchGold = Math.max(0, (player.matchGold || 0) - loss);
            this.showSkillBanner(`🌫️ ${player.username} เดินผ่านหมอกพิษ (-${pct}%) เสียเงิน ${this.formatCompactGold(loss)}!`);
            this.logMessage(`🌫️ ${player.username} เดินผ่านหมอกช่อง ${tileNum} เสียเงิน ${pct}% (${this.formatCompactGold(loss)})`, 'warning');
            if (typeof this.updateMatchWealthHUD === 'function') this.updateMatchWealthHUD();
        }

        // ตกหลุมดำ: วาร์ปถอยหลังสุ่ม 3-6 ช่อง
        if (isFinalStep && sk === 'BLACK_HOLE' && Array.isArray(this.monopolyBlackHoleTiles) && this.monopolyBlackHoleTiles.includes(tileNum)) {
            const backSteps = Math.floor(Math.random() * 4) + 3;
            let dest = tileNum - backSteps;
            if (dest < 1) dest = 32 + dest;
            player.currentTile = dest;
            this.animatePawnToTile(player, dest, 450);
            this.showSkillBanner(`🕳️ ${player.username} ตกหลุมดำ! ถูกดูดวาร์ปถอยหลัง ${backSteps} ช่อง!`);
            this.logMessage(`🕳️ ${player.username} โดนหลุมดำดูดจากช่อง ${tileNum} ไปช่อง ${dest}!`, 'warning');
        }
    }

    async handleMonopolyStartTileUpgrade(player) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt || this.isGameOver) return;
        const ownedKeys = Object.keys(this.cityStates || {}).filter(k => {
            const tNum = Number(k);
            const st = this.cityStates[tNum];
            return st && this.isTileOwnedByPlayerOrTeam(tNum, player) && !st.isSuperLandmark;
        });
        if (ownedKeys.length === 0) {
            this.showSkillBanner(`🚩 ${player.username} ตกจุด START! (ยังไม่มีเมืองให้อัปเกรด)`);
            return;
        }

        const applyUpgradeOnTile = async (tileNum) => {
            const st = this.cityStates[tileNum];
            if (!st) return;
            const provName = this.getProvinceName(tileNum);
            const dispT = this.getDisplayTileNumber(tileNum);
            const costs = this.getTileBuildCosts(tileNum);
            const curLevel = Math.max(1, Number(st.level) || Number(st.houses) || 1);
            let actionText = '';
            let justBuiltLandmark = false;

            if (!st.isLandmark && curLevel < 3) {
                const nextLvl = curLevel + 1;
                st.level = nextLvl;
                st.houses = nextLvl;
                st.investedGold = (Number(st.investedGold) || 0) + (costs.unitCost || 120000);
                actionText = `สร้างเมืองเพิ่ม +1 หลัง (${nextLvl}/3 หลัง)`;
            } else if (!st.isLandmark) {
                st.level = 4;
                st.houses = 3;
                st.isLandmark = true;
                st.isSuperLandmark = false;
                st.multiplier = Math.max(2, Number(st.multiplier) || 2);
                st.investedGold = (Number(st.investedGold) || 0) + (costs.landmarkUpgrade || 320000);
                actionText = `อัปเกรดเป็น 🏛️ แลนด์มาร์ค!`;
                justBuiltLandmark = true;
            } else if (!st.isSuperLandmark) {
                st.level = 5;
                st.houses = 3;
                st.isLandmark = true;
                st.isSuperLandmark = true;
                st.multiplier = Math.max(4, Number(st.multiplier) || 4);
                st.investedGold = (Number(st.investedGold) || 0) + (costs.superLandmarkUpgrade || 450000);
                actionText = `อัปเกรดเป็น 👑 ซุปเปอร์แลนด์มาร์ค!`;
            }

            this.rebuildTileCity3D(tileNum);
            this.checkAndRefreshColorGroupBonus3D(tileNum, player);
            if (typeof this.updateMatchWealthHUD === 'function') this.updateMatchWealthHUD();
            const newToll = this.getTileToll(tileNum);
            this.showSkillBanner(`🚩 ตกจุด START! ${player.username} อัปเกรด [#${dispT} ${provName}] ➔ ${actionText} (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
            this.logMessage(`🚩 ${player.username} ตกจุด START อัปเกรด [#${dispT} ${provName}]: ${actionText} (ค่าผ่านทาง ${newToll.toLocaleString()} ทอง)`, 'skill');
            if (this.checkLineMonopolyVictory(player)) return;
            if (justBuiltLandmark) {
                await this.triggerLandmarkSkills(player, tileNum);
            }
        };

        ownedKeys.sort((a, b) => this.getTileToll(Number(b)) - this.getTileToll(Number(a)));
        const defaultTile = Number(ownedKeys[0]);

        if (player.is_bot || !this.isLocalPlayer(player) || this.isAutoMode) {
            await applyUpgradeOnTile(defaultTile);
            return;
        }

        // จิ้มเลือกเมืองของเรา/ทีมบนกระดาน 3D ได้โดยตรง (ไม่แสดง Popup บังกระดาน!)
        const ownedSet = new Set(ownedKeys.map(Number));
        const chosenTile = await this.pickTileDirectlyOnBoard3D({
            title: '🚩 ตกจุด START! จิ้มเลือกเมืองของคุณบนกระดานเพื่อสร้างเพิ่มฟรี',
            subText: '✨ จิ้มที่เมืองของคุณ/ทีมที่สว่างเด่นบนกระดาน เพื่อสร้างเพิ่ม +1 หลัง หรืออัปเกรดเป็นแลนด์มาร์ค / ซุปเปอร์แลนด์มาร์คทันที!',
            getTileMode: (t) => ownedSet.has(t) ? 'HIGHLIGHT' : 'DISABLED',
            defaultTile: defaultTile,
            timeoutSec: 15
        });

        if (chosenTile) {
            await applyUpgradeOnTile(chosenTile);
        }
    }

    exitMonopolyBoardMode() {
        if (!this.isMonopolyBoardMode) return;
        this.isMonopolyBoardMode = false;
        this.activeMonopolyConfig = null;
        this.monopolyTilesList = null;
        this.updateMonopolyExclusiveUI();
        this.cancelCustomBoardConfig();
    }

    cancelCustomBoardConfig() {
        this.activeCustomBoard = null;
        this.customBoardSurfaceTexture = null;
        this.customGridCols = 10;
        this.customGridRows = 10;
        this.totalTilesCount = 100;
        this.tileSize = 6.2;
        this.tileGap = 0.4;
        this.hollowCenter = false;
        this.centerHoleCols = 6;
        this.centerHoleRows = 6;
        this.holeStartRow = 2;
        this.hollowMode = 'grid_cutout';
        this.hollowStyle = 'arena_tray';
        this.shadowDiveAcrossCenter = true;
        this.shadowDiveStyle = 'shadow_fade';
        this.shadowDiveDurationMs = 480;
        this.stepDurationMs = 380;
        this.chanceTiles = [11, 45, 76];
        this.taxTiles = [20, 52, 82];
        this.gambleTiles = [15, 68, 88];
        this.destroyTiles = [26, 36, 90];
        this.jailTile = 10;
        this.initProvinces();
        this.applyRollButtonPositionConfig({ preset: 'bottom_center', offsetX: 0, offsetY: 0, scale: 100, dice3dPos: 'front_center' });
        this.boardTheme = 'ancient';
        this.boardLayout = 'square';
        this.buildBoard();
        if (!this.isMatchActive && typeof this.setupIdlePreview === 'function') {
            this.setupIdlePreview(window.DEFAULT_USER || null);
        } else {
            this.updateCameraFit();
        }
    }

    /**
     * คืนค่ามาตรฐานเริ่มต้นของป้ายโฮโลแกรม 3D และตัวหนังสือบนกระดาน
     */
    getDefaultBadgeConfig() {
        return {
            showBadges: false, // ปิดป้ายข้อความลอยไม่ให้บังกระดานเป็นค่าเริ่มต้น (เปิด/ปิดได้ใน Admin Panel)
            ladder: {
                show: false,
                scale: 1.0,
                textPrefix: 'ไต่ขึ้นไปช่อง',
                bg1: '#064e3b',
                bg2: '#059669',
                textColor: '#fef08a',
                borderColor: '#34d399'
            },
            snake: {
                show: false,
                scale: 1.0,
                textPrefix: 'ร่วงตกไปช่อง',
                bg1: '#7f1d1d',
                bg2: '#dc2626',
                textColor: '#fef08a',
                borderColor: '#fca5a5'
            },
            pawn: {
                scale: 1.0,
                prefix: '👑 คุณ: ',
                bg1: '#1e1b4b',
                bg2: '#1e3a8a',
                textColor: '#fef08a',
                borderColor: '#ffd700'
            },
            tile: {
                fontScale: 1.0,
                pillH: 114,
                numColor: '#38bdf8',
                provColor: '#ffffff',
                ladderPillBg: '#059669',
                snakePillBg: '#dc2626'
            }
        };
    }

    /**
     * โหลดการตั้งค่าป้าย 3D (จาก Custom Board หรือ localStorage ของผู้ดูแลระบบ)
     */
    loadBadgeConfig() {
        const defaults = this.getDefaultBadgeConfig();
        try {
            let b = null;
            if (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.badge_config) {
                b = this.activeCustomBoard.theme_config.badge_config;
            } else {
                const saved = localStorage.getItem('snake_badge_config');
                if (saved) {
                    b = JSON.parse(saved);
                }
            }
            if (typeof window !== "undefined" && window.SERVER_SHOW_BADGES !== undefined) {
                b = b || {};
                b.showBadges = Boolean(window.SERVER_SHOW_BADGES);
            }
            if (b) {
                const showBadges = b.showBadges !== undefined ? Boolean(b.showBadges) : false;
                return {
                    showBadges,
                    ladder: Object.assign({}, defaults.ladder, b.ladder || {}, {
                        show: (b.ladder && b.ladder.show !== undefined) ? Boolean(b.ladder.show) : showBadges
                    }),
                    snake: Object.assign({}, defaults.snake, b.snake || {}, {
                        show: (b.snake && b.snake.show !== undefined) ? Boolean(b.snake.show) : showBadges
                    }),
                    pawn: Object.assign({}, defaults.pawn, b.pawn || {}),
                    tile: Object.assign({}, defaults.tile, b.tile || {})
                };
            }
        } catch (e) {
            console.warn('Game3D: Could not load badge config:', e);
        }
        return defaults;
    }

    /**
     * อัปเดตและรีเฟรชการตั้งค่าป้าย 3D ทันที
     */
    updateBadgeConfig(newCfg = {}) {
        this.badgeConfig = Object.assign(this.getDefaultBadgeConfig(), newCfg);
        try {
            localStorage.setItem('snake_badge_config', JSON.stringify(this.badgeConfig));
        } catch (e) { }
    }

    /**
     * สลับเปิด/ปิดการแสดงป้ายข้อความ Hologram (งู/บันได) ทันทีแบบ Realtime
     */
    toggleHologramBadges(show) {
        const isVisible = Boolean(show);
        if (!this.badgeConfig) this.badgeConfig = this.loadBadgeConfig();
        this.badgeConfig.showBadges = isVisible;
        if (this.badgeConfig.ladder) this.badgeConfig.ladder.show = isVisible;
        if (this.badgeConfig.snake) this.badgeConfig.snake.show = isVisible;
        try {
            localStorage.setItem('snake_badge_config', JSON.stringify(this.badgeConfig));
        } catch (e) { }

        // อัปเดต visibility ของป้ายบันไดทั้งหมดที่มีอยู่
        if (this.ladderObjects) {
            Object.values(this.ladderObjects).forEach(obj => {
                if (obj && Array.isArray(obj.badges)) {
                    obj.badges.forEach(b => { if (b) b.visible = isVisible; });
                }
            });
        }

        // อัปเดต visibility ของป้ายงูทั้งหมดที่มีอยู่
        if (this.snakeObjects) {
            Object.values(this.snakeObjects).forEach(obj => {
                if (obj && Array.isArray(obj.badges)) {
                    obj.badges.forEach(b => { if (b) b.visible = isVisible; });
                }
            });
        }
    }

    /**
     * ตั้งค่าตำแหน่งปุ่มทอยลูกเต๋า (HUD .bottom-hud) และตำแหน่งลูกเต๋า 3D บนกระดาน
     */
    applyRollButtonPositionConfig(cfg = {}) {
        const preset = cfg.preset || 'bottom_center';
        const offX = Number(cfg.offsetX) || 0;
        const offY = Number(cfg.offsetY) || 0;
        const scale = (Number(cfg.scale) || 100) / 100;
        const hud = document.querySelector('.bottom-hud');
        if (hud) {
            hud.style.top = '';
            hud.style.bottom = '';
            hud.style.left = '';
            hud.style.right = '';
            hud.style.transform = '';

            if (preset === 'bottom_right') {
                hud.style.bottom = `calc(max(8px, env(safe-area-inset-bottom, 0px)) - ${offY}px)`;
                hud.style.right = `calc(max(16px, env(safe-area-inset-right, 0px)) - ${offX}px)`;
                hud.style.left = 'auto';
                hud.style.transform = `scale(${scale})`;
                hud.style.transformOrigin = 'bottom right';
            } else if (preset === 'bottom_left') {
                hud.style.bottom = `calc(max(8px, env(safe-area-inset-bottom, 0px)) - ${offY}px)`;
                hud.style.left = `calc(max(16px, env(safe-area-inset-left, 0px)) + ${offX}px)`;
                hud.style.right = 'auto';
                hud.style.transform = `scale(${scale})`;
                hud.style.transformOrigin = 'bottom left';
            } else if (preset === 'center_board') {
                hud.style.top = `calc(55% + ${offY}px)`;
                hud.style.left = `calc(50% + ${offX}px)`;
                hud.style.bottom = 'auto';
                hud.style.transform = `translate(-50%, -50%) scale(${scale})`;
                hud.style.transformOrigin = 'center center';
            } else if (preset === 'middle_right') {
                hud.style.top = `calc(50% + ${offY}px)`;
                hud.style.right = `calc(max(14px, env(safe-area-inset-right, 0px)) - ${offX}px)`;
                hud.style.left = 'auto';
                hud.style.bottom = 'auto';
                hud.style.transform = `translateY(-50%) scale(${scale})`;
                hud.style.transformOrigin = 'center right';
            } else if (preset === 'middle_left') {
                hud.style.top = `calc(50% + ${offY}px)`;
                hud.style.left = `calc(max(14px, env(safe-area-inset-left, 0px)) + ${offX}px)`;
                hud.style.right = 'auto';
                hud.style.bottom = 'auto';
                hud.style.transform = `translateY(-50%) scale(${scale})`;
                hud.style.transformOrigin = 'center left';
            } else if (preset === 'top_center') {
                hud.style.top = `calc(max(54px, env(safe-area-inset-top, 0px)) + ${offY}px)`;
                hud.style.left = `calc(50% + ${offX}px)`;
                hud.style.bottom = 'auto';
                hud.style.transform = `translateX(-50%) scale(${scale})`;
                hud.style.transformOrigin = 'top center';
            } else {
                // bottom_center or custom_xy
                hud.style.bottom = `calc(2px - ${offY}px)`;
                hud.style.left = `calc(50% + ${offX}px)`;
                hud.style.transform = `translateX(-50%) scale(${scale})`;
                hud.style.transformOrigin = 'bottom center';
            }
        }

        // 3D Dice: ตำแหน่งกึ่งกลางกระดานเสมอ (Center of Board: X = 0, Z = 0) ทุกกระดานตามคำขอผู้ใช้
        const dScale = Math.max(0.5, Math.min(2.0, (Number(cfg.diceScale) || 100) / 100));
        const dx = 0;
        const dz = 0;
        const spacing = 5.2 * dScale;
        const baseY = 3.6 * dScale;
        this.diceBasePos = { x: dx, y: baseY, z: dz, scale: dScale, spacing };

        if (this.diceMesh1 && this.diceMesh2) {
            this.diceMesh1.position.set(dx - spacing, baseY, dz);
            this.diceMesh2.position.set(dx + spacing, baseY, dz);
            this.diceMesh1.scale.set(dScale, dScale, dScale);
            this.diceMesh2.scale.set(dScale, dScale, dScale);
        }
        if (this.diceGroup && !this.isRolling) {
            this.diceGroup.visible = false;
        }
    }


    initProvinces() {
        this.tileProvinces = {};
        const shuffled = [...THAI_PROVINCES].sort(() => Math.random() - 0.5);
        for (let i = 1; i <= 100; i++) {
            this.tileProvinces[i] = shuffled[(i - 1) % shuffled.length];
        }
    }

    getProvinceName(tileNum) {
        if (this.isMonopolyBoardMode && Array.isArray(this.monopolyTilesList)) {
            const mt = this.monopolyTilesList[Number(tileNum) - 1];
            if (mt && mt.name) return mt.name;
        }
        return this.tileProvinces[tileNum] || 'สยาม';
    }

    createTileTexture(tileNum, provinceName, tileType, theme) {
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
        const canvasSize = isMobileOrTablet ? 256 : 512;
        const canvas = document.createElement('canvas');
        canvas.width = canvasSize;
        canvas.height = canvasSize;
        const ctx = canvas.getContext('2d');
        const s = canvasSize / 768;
        ctx.scale(s, s);

        // Theme and tile type styling
        let bgColor = (tileNum % 2 === 0) ? '#101a2e' : '#182742';
        let borderColor = '#00e5ff';
        let accentColor = '#38bdf8';
        let icon = '';
        let typeTag = '';
        let tagPillBg = null;
        let tagPillBorder = null;
        let monopolyCityBandColor = null;

        if (this.boardTheme === 'ancient') {
            bgColor = (tileNum % 2 === 0) ? '#281a08' : '#3c270d';
            borderColor = '#ffd700';
            accentColor = '#facc15';
        } else if (this.boardTheme === 'lava') {
            bgColor = (tileNum % 2 === 0) ? '#2a0909' : '#3b1212';
            borderColor = '#ff4d4d';
            accentColor = '#f97316';
        } else if (this.boardTheme === 'ice') {
            bgColor = (tileNum % 2 === 0) ? '#08253a' : '#0f3856';
            borderColor = '#67e8f9';
            accentColor = '#a5f3fc';
        } else if (this.boardTheme === 'custom_ai' && this.themes.custom_ai) {
            bgColor = (tileNum % 2 === 0) ? (this.themes.custom_ai.cssEven || '#0f203c') : (this.themes.custom_ai.cssOdd || '#173058');
            borderColor = this.themes.custom_ai.cssBorder || '#00e5ff';
            accentColor = borderColor;
        }

        const monoTile = (this.isMonopolyBoardMode && Array.isArray(this.monopolyTilesList))
            ? this.monopolyTilesList[tileNum - 1]
            : null;

        if (tileType === 'CHANCE') {
            bgColor = '#381f02';
            borderColor = '#f59e0b';
            accentColor = '#fbbf24';
            icon = '🎁';
            typeTag = 'ช่องดวง';
            tagPillBg = '#d97706';
            tagPillBorder = '#fef08a';
        } else if (tileType === 'TAX') {
            bgColor = '#3b0d0d';
            borderColor = '#ef4444';
            accentColor = '#f87171';
            icon = '💸';
            typeTag = 'ภาษี (TAX)';
            tagPillBg = '#dc2626';
            tagPillBorder = '#fca5a5';
        } else if (tileType === 'OLYMPIC') {
            bgColor = '#451a03';
            borderColor = '#f59e0b';
            accentColor = '#fde047';
            icon = '🏅';
            const fixedM = Number(monoTile?.special_multiplier || monoTile?.toll || 8);
            typeTag = (fixedM >= 2 && fixedM <= 16) ? `⚡ คูณ ${fixedM}` : '⚡ คูณ 8';
            tagPillBg = '#d97706';
            tagPillBorder = '#fef08a';
        } else if (tileType === 'EXPRESSWAY') {
            bgColor = '#042f4b';
            borderColor = '#00e5ff';
            accentColor = '#67e8f9';
            icon = '🛣️';
            typeTag = 'ทางด่วน (ไปได้ทุกที่)';
            tagPillBg = '#0284c7';
            tagPillBorder = '#a5f3fc';
        } else if (tileType === 'WORLD_TRAVEL') {
            bgColor = '#082f49';
            borderColor = '#38bdf8';
            accentColor = '#7dd3fc';
            icon = '✈️';
            typeTag = 'พื้นที่พิเศษ';
            tagPillBg = '#0284c7';
            tagPillBorder = '#bae6fd';
        } else if (tileType === 'GOD_TILE') {
            bgColor = '#422006';
            borderColor = '#fde047';
            accentColor = '#fef08a';
            icon = '👼';
            typeTag = 'พื้นที่พระเจ้า';
            tagPillBg = '#ca8a04';
            tagPillBorder = '#fef9c3';
        } else if (tileType === 'GAMBLE') {
            bgColor = '#2b0938';
            borderColor = '#c084fc';
            accentColor = '#e879f9';
            icon = '🎰';
            typeTag = this.isMonopolyBoardMode ? 'สุ่มโบนัส 💎/💰' : 'เสี่ยงโชค';
            tagPillBg = '#9333ea';
            tagPillBorder = '#f0abfc';
        } else if (tileType === 'DESTROY') {
            bgColor = '#3b0717';
            borderColor = '#f43f5e';
            accentColor = '#fb7185';
            icon = '💣';
            typeTag = this.isMonopolyBoardMode ? 'พื้นที่ระเบิด' : 'ลบเมืองคู่แข่ง';
            tagPillBg = '#e11d48';
            tagPillBorder = '#fda4af';
        } else if (tileType === 'JAIL') {
            bgColor = '#1e293b';
            borderColor = '#94a3b8';
            accentColor = '#cbd5e1';
            icon = '⛓️';
            typeTag = 'คุกเกาะร้าง';
            tagPillBg = '#475569';
            tagPillBorder = '#cbd5e1';
        } else if (tileType === 'GOAL') {
            bgColor = '#064e3b';
            borderColor = '#10b981';
            accentColor = '#34d399';
            icon = '🏆';
            typeTag = 'เส้นชัย GOAL';
            tagPillBg = '#059669';
            tagPillBorder = '#6ee7b7';
        } else if (tileType === 'START' || tileNum === 1) {
            bgColor = '#052e16';
            borderColor = '#22c55e';
            accentColor = '#4ade80';
            icon = '🚩';
            typeTag = this.isMonopolyBoardMode ? 'จุดเริ่มต้น' : 'จุดเส้นชัย';
            tagPillBg = '#16a34a';
            tagPillBorder = '#86efac';
        } else if (this.isMonopolyBoardMode && monoTile && String(monoTile.type || 'CITY').toUpperCase() === 'CITY' && monoTile.color) {
            // 🎨 โหมดเกมส์เศรษฐี: แสดงสีกลุ่มเมืองชัดเจน แต่ป้าย "คูณ 2" จะแสดงต่อเมื่อสร้างเมืองครบสี (หรือเมื่อกำหนดพิเศษให้เป็นเมืองคูณ เช่น คูณ 8)!
            const cHex = String(monoTile.color).trim();
            monopolyCityBandColor = cHex;
            bgColor = safeHexToRgba(cHex, 0.42);
            borderColor = cHex;
            accentColor = '#ffffff';
            icon = monoTile.is_expensive ? '💎' : '🏙️';

            const presetSpecialMult = Number(monoTile.special_multiplier || 0);
            const stNow = this.cityStates ? this.cityStates[tileNum] : null;
            const hasColorBonus = stNow ? this.hasMonopolyColorSetBonus(tileNum) : false;
            const cityMult = stNow ? Math.max(1, Number(stNow.multiplier) || 1, presetSpecialMult || 1) * (hasColorBonus ? 2 : 1) : presetSpecialMult;

            if (cityMult >= 2) {
                typeTag = `⚡ คูณ ${cityMult}`;
                tagPillBg = cityMult >= 4 ? '#d97706' : cHex;
                tagPillBorder = '#fef08a';
            } else {
                typeTag = '';
            }
        } else if (this.ladders[tileNum]) {
            icon = '🪜';
            typeTag = `⬆️ ขึ้นไป ${this.getDisplayTileNumber(this.ladders[tileNum])}`;
            borderColor = '#10b981';
            accentColor = '#34d399';
            tagPillBg = this.badgeConfig?.tile?.ladderPillBg || '#059669';
            tagPillBorder = '#6ee7b7';
        } else if (this.snakes[tileNum]) {
            icon = '🐍';
            typeTag = `⬇️ ร่วงลง ${this.getDisplayTileNumber(this.snakes[tileNum])}`;
            borderColor = '#f43f5e';
            accentColor = '#fb7185';
            tagPillBg = this.badgeConfig?.tile?.snakePillBg || '#dc2626';
            tagPillBorder = '#fca5a5';
        } else if (this.ladderEndToStart && this.ladderEndToStart[tileNum]) {
            icon = '🚩';
            typeTag = `ปลายทางบันได (${this.getDisplayTileNumber(this.ladderEndToStart[tileNum])})`;
            borderColor = '#10b981';
            accentColor = '#34d399';
            tagPillBg = '#059669';
            tagPillBorder = '#6ee7b7';
        } else if (this.snakeTailToHead && this.snakeTailToHead[tileNum]) {
            icon = '💧';
            typeTag = `จุดร่วงจาก ${this.getDisplayTileNumber(this.snakeTailToHead[tileNum])}`;
            borderColor = '#a855f7';
            accentColor = '#c084fc';
            tagPillBg = '#7c3aed';
            tagPillBorder = '#d8b4fe';
        }

        const tileCfg = this.badgeConfig?.tile || {};
        const fontScale = Number(tileCfg.fontScale) || 1.0;
        const pillH = Math.max(70, Math.min(140, Number(tileCfg.pillH) || 114));

        // Base dark slate underlayer + color fill
        ctx.fillStyle = '#090f1d';
        ctx.fillRect(0, 0, 768, 768);
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, 768, 768);

        // หากเป็นเมืองในโหมดเกมส์เศรษฐี ให้วาดแถบสีประจำกลุ่มเมืองด้านบนและด้านล่างให้สีสดเด่นชัด
        if (monopolyCityBandColor) {
            ctx.fillStyle = monopolyCityBandColor;
            ctx.fillRect(18, 18, 732, 148);
            ctx.fillStyle = safeHexToRgba(monopolyCityBandColor, 0.72);
            ctx.fillRect(18, 575, 732, 175);
        }

        // Inner card gradient
        const grad = ctx.createLinearGradient(0, 0, 768, 768);
        grad.addColorStop(0, 'rgba(255,255,255,0.16)');
        grad.addColorStop(1, 'rgba(0,0,0,0.42)');
        ctx.fillStyle = grad;
        ctx.fillRect(24, 24, 720, 720);

        // Outer border & Thick Aura Glow (ปรับความหนาแสงเออร่าตามที่ตั้งค่าในหน้า Admin)
        const boardAuraT = Number(this.monopolyStageSkillConfig?.aura_thickness || 2.2);
        const tileAuraT = Number(monoTile?.aura_thickness || boardAuraT || 2.2);
        const tileAuraCol = monoTile?.aura_color || borderColor;
        const showTileAura = (monoTile?.show_aura === 'ALWAYS') ||
            (monoTile?.show_aura !== 'OFF' && (Boolean(typeTag && typeTag.includes('คูณ')) || ['EXPRESSWAY', 'GOD_TILE', 'DESTROY', 'GAMBLE', 'OLYMPIC', 'WORLD_TRAVEL'].includes(tileType)));

        ctx.save();
        if (showTileAura) {
            ctx.shadowColor = tileAuraCol;
            ctx.shadowBlur = Math.round(28 * tileAuraT);
            ctx.strokeStyle = tileAuraCol;
            ctx.lineWidth = Math.round(18 * tileAuraT);
            ctx.strokeRect(20, 20, 728, 728);
        }
        ctx.strokeStyle = borderColor;
        ctx.lineWidth = monopolyCityBandColor ? Math.max(20, Math.round(14 * tileAuraT)) : 16;
        ctx.strokeRect(18, 18, 732, 732);
        ctx.restore();

        // Neon corners
        ctx.fillStyle = accentColor;
        ctx.fillRect(18, 18, 60, 14);
        ctx.fillRect(18, 18, 14, 60);
        ctx.fillRect(690, 18, 60, 14);
        ctx.fillRect(736, 18, 14, 60);
        ctx.fillRect(18, 736, 60, 14);
        ctx.fillRect(18, 690, 14, 60);
        ctx.fillRect(690, 736, 60, 14);
        ctx.fillRect(736, 690, 14, 60);

        // Tile Number (Top-Left): ในโหมดเกมส์เศรษฐี ช่องหลังปุ่ม START (tileNum=2 เช่น บึงกาฬ) คือหมายเลข 1!
        const dispTileStr = this.getDisplayTileNumber(tileNum);
        const isStartLabel = (dispTileStr === 'START');
        ctx.font = 'bold ' + Math.round((isStartLabel ? 72 : 96) * fontScale) + 'px "Kanit", "Prompt", sans-serif';
        ctx.fillStyle = monopolyCityBandColor ? '#ffffff' : (tileCfg.numColor || accentColor);
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.shadowColor = 'rgba(0,0,0,0.95)';
        ctx.shadowBlur = 14;
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 10;
        ctx.strokeText(dispTileStr, 46, 38);
        ctx.fillText(dispTileStr, 46, 38);

        // Icon (Top-Right): Crisp & Large
        if (icon) {
            ctx.font = Math.round(84 * fontScale) + 'px sans-serif';
            ctx.textAlign = 'right';
            ctx.shadowBlur = 14;
            ctx.fillText(icon, 720, 42);
        }

        // High-Contrast Solid Pill Container for Event / Indicator Tag (Center)
        if (typeTag) {
            const pillW = Math.min(680, Math.max(360, typeTag.length * 38 + 90));
            const pillX = 384 - pillW / 2;
            const pillY = 300;
            const pillRadius = pillH / 2;

            ctx.save();
            ctx.beginPath();
            ctx.roundRect(pillX, pillY, pillW, pillH, pillRadius);
            ctx.fillStyle = tagPillBg || 'rgba(15, 23, 42, 0.98)';
            ctx.shadowColor = tagPillBorder || accentColor;
            ctx.shadowBlur = 24;
            ctx.fill();

            ctx.strokeStyle = tagPillBorder || '#ffffff';
            ctx.lineWidth = 7;
            ctx.stroke();

            // Bold white text with black drop shadow
            ctx.font = '900 ' + Math.round(58 * fontScale) + 'px "Prompt", "Kanit", sans-serif';
            ctx.fillStyle = '#ffffff';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 14;
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 10;
            ctx.strokeText(typeTag, 384, pillY + pillH / 2 + 3);
            ctx.fillText(typeTag, 384, pillY + pillH / 2 + 3);
            ctx.restore();
        }

        // Thai Province Name (Bottom): Solid Bold White with Strong Black Outline
        ctx.save();
        ctx.font = 'bold ' + Math.round(82 * fontScale) + 'px "Kanit", "Prompt", sans-serif';
        ctx.fillStyle = tileCfg.provColor || '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 16;
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 12;
        ctx.strokeText(provinceName, 384, 715);
        ctx.fillText(provinceName, 384, 715);
        ctx.restore();

        const texture = new THREE.CanvasTexture(canvas);
        texture.minFilter = isMobileOrTablet ? THREE.LinearFilter : THREE.LinearMipmapLinearFilter;
        texture.magFilter = THREE.LinearFilter;
        texture.generateMipmaps = !isMobileOrTablet;
        texture.anisotropy = isMobileOrTablet ? 1 : 4;
        return texture;
    }

    refreshSingleTileTexture(tileNum) {
        const i = Number(tileNum);
        const mesh = this.tileMeshes ? this.tileMeshes[i] : null;
        if (!mesh) return;
        const theme = this.themes[this.boardTheme] || this.themes.ancient;
        const isChance = this.chanceTiles.includes(i);
        const isTax = this.taxTiles.includes(i);
        const isGamble = this.gambleTiles.includes(i);
        const isDestroy = this.destroyTiles && this.destroyTiles.includes(i);
        const isJail = (i === this.jailTile);
        const isOlympic = Boolean(this.isMonopolyBoardMode && ((Array.isArray(this.olympicTiles) && this.olympicTiles.includes(i)) || i === this.olympicTile));
        const isWorldTravel = Boolean(this.isMonopolyBoardMode && ((Array.isArray(this.worldTravelTiles) && this.worldTravelTiles.includes(i)) || i === this.worldTravelTile));
        const isExpressway = Boolean(this.isMonopolyBoardMode && Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(i));
        const isGodTile = Boolean(this.isMonopolyBoardMode && Array.isArray(this.godTiles) && this.godTiles.includes(i));
        const isGoal = (!this.isMonopolyBoardMode && i === 100);
        const isStart = (i === 1);
        let tileType = 'NORMAL';
        if (isGoal) tileType = 'GOAL';
        else if (isStart) tileType = 'START';
        else if (isExpressway) tileType = 'EXPRESSWAY';
        else if (isGodTile) tileType = 'GOD_TILE';
        else if (isOlympic) tileType = 'OLYMPIC';
        else if (isWorldTravel) tileType = 'WORLD_TRAVEL';
        else if (isGamble) tileType = 'GAMBLE';
        else if (isTax) tileType = 'TAX';
        else if (isChance) tileType = 'CHANCE';
        else if (isDestroy) tileType = 'DESTROY';
        else if (isJail) tileType = 'JAIL';

        const provinceName = this.getProvinceName(i);
        const newTex = this.createTileTexture(i, provinceName, tileType, theme);
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        const topMat = mats.length >= 3 ? mats[2] : mats[0];
        if (topMat) {
            if (topMat.map) {
                try { topMat.map.dispose(); } catch (e) { }
            }
            topMat.map = newTex;
            topMat.needsUpdate = true;
        }
    }

    createDestroySign(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(0.95, 1.15, 0.4, 16);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x881337, metalness: 0.8, roughness: 0.25 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        const ringGeo = new THREE.TorusGeometry(0.72, 0.14, 12, 28);
        const ringMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0xe11d48, emissiveIntensity: 0.6, metalness: 0.85, roughness: 0.15 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.55;
        group.add(ring);

        const bombGeo = new THREE.OctahedronGeometry(0.52);
        const bombMat = new THREE.MeshStandardMaterial({ color: 0xff0055, emissive: 0xff0055, emissiveIntensity: 0.85, metalness: 0.9, roughness: 0.1 });
        const bomb = new THREE.Mesh(bombGeo, bombMat);
        bomb.position.y = 1.35;
        group.add(bomb);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    createTaxSign(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(0.9, 1.1, 0.4, 16);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.8, roughness: 0.3 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        for (let c = 0; c < 3; c++) {
            const coinGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.18, 16);
            const coinMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2 });
            const coin = new THREE.Mesh(coinGeo, coinMat);
            coin.position.y = 0.3 + c * 0.2;
            group.add(coin);
        }

        const emblemGeo = new THREE.OctahedronGeometry(0.45);
        const emblemMat = new THREE.MeshBasicMaterial({ color: 0xff0055 });
        const emblem = new THREE.Mesh(emblemGeo, emblemMat);
        emblem.position.y = 1.3;
        group.add(emblem);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    createLuckyWheel3D(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(1.0, 1.2, 0.5, 20);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x7c3aed, metalness: 0.7, roughness: 0.2 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        const ringGeo = new THREE.TorusGeometry(0.7, 0.18, 12, 24);
        const ringMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.95, roughness: 0.1 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.5;
        group.add(ring);

        const gemGeo = new THREE.OctahedronGeometry(0.55);
        const gemMat = new THREE.MeshStandardMaterial({
            color: 0x00e5ff,
            emissive: 0x00e5ff,
            emissiveIntensity: 0.6,
            metalness: 0.3,
            roughness: 0.1
        });
        const gem = new THREE.Mesh(gemGeo, gemMat);
        gem.position.y = 1.35;
        group.add(gem);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    computeGameTileCoordinates(layout, gridCols, gridRows, totalTiles, tileSize, gap) {
        const step = tileSize + gap;
        const isHollow = Boolean(this.hollowCenter);
        const holeCols = Math.max(2, Math.min(16, Number(this.centerHoleCols) || 6));
        const holeRows = Math.max(1, Math.min(14, Number(this.centerHoleRows) || 6));
        const holeStartRow = (this.holeStartRow !== undefined) ? Number(this.holeStartRow) : 2;
        const hollowMode = this.hollowMode || 'grid_cutout';
        const coords = [];

        if (this.isMonopolyBoardMode && totalTiles === 32) {
            const sideN = 9;
            const span = (sideN - 1) * step;
            const halfSpan = span / 2;
            const mCoords = [];
            for (let k = 0; k < 32; k++) {
                let row = 9, col = 9;
                if (k <= 8) { row = 9; col = 9 - k; }
                else if (k <= 16) { row = 9 - (k - 8); col = 1; }
                else if (k <= 24) { row = 1; col = 1 + (k - 16); }
                else { row = 1 + (k - 24); col = 9; }
                const x = -halfSpan + (col - 1) * step;
                const z = -halfSpan + (row - 1) * step;
                mCoords.push({ x, z, tileW: tileSize, rotY: 0 });
            }
            return {
                coords: mCoords,
                totalSizeX: sideN * step,
                totalSizeZ: sideN * step,
                holeXLeft: -halfSpan + step * 0.5,
                holeXRight: halfSpan - step * 0.5,
                holeZBack: -halfSpan + step * 0.5,
                holeZFront: halfSpan - step * 0.5
            };
        }

        if (isHollow && hollowMode === 'ring_loop') {
            const halfHoleW = Math.max(step * 1.4, (holeCols * step) / 2 + step * 0.6);
            const halfHoleD = Math.max(step * 1.1, (holeRows * step) / 2 + step * 0.6);
            const ringCount = totalTiles <= 48 ? 1 : 2;
            const ringTotals = ringCount === 1
                ? [totalTiles]
                : [Math.ceil(totalTiles * 0.56), totalTiles - Math.ceil(totalTiles * 0.56)];

            for (let rIdx = 0; rIdx < ringTotals.length; rIdx++) {
                const countInRing = ringTotals[rIdx];
                const ringOffset = (ringTotals.length - 1 - rIdx) * step * 1.05;
                const rx = halfHoleW + ringOffset;
                const rz = halfHoleD + ringOffset;
                const perim = 4 * (rx + rz);

                for (let k = 0; k < countInRing; k++) {
                    const u = k / countInRing;
                    const d = u * perim;
                    let x = 0, z = 0;
                    const wSpan = 2 * rx;
                    const dSpan = 2 * rz;
                    if (d < wSpan) {
                        x = -rx + d;
                        z = rz;
                    } else if (d < wSpan + dSpan) {
                        x = rx;
                        z = rz - (d - wSpan);
                    } else if (d < 2 * wSpan + dSpan) {
                        x = rx - (d - (wSpan + dSpan));
                        z = -rz;
                    } else {
                        x = -rx;
                        z = -rz + (d - (2 * wSpan + dSpan));
                    }
                    coords.push({ x, z, rotY: 0, tileW: tileSize });
                }
            }
            const hW = holeCols * step;
            const hD = holeRows * step;
            return {
                coords,
                totalSizeX: (halfHoleW + ringTotals.length * step) * 2,
                totalSizeZ: (halfHoleD + ringTotals.length * step) * 2,
                holeW: hW,
                holeD: hD,
                holeXLeft: -hW / 2,
                holeXRight: hW / 2,
                holeZBack: -hD / 2,
                holeZFront: hD / 2
            };
        }

        if (isHollow && (layout === 'rectangle' || layout === 'square')) {
            const totalSizeX = gridCols * step;
            const totalSizeZ = gridRows * step;
            const startZ = totalSizeZ / 2 - tileSize / 2;

            const effHoleCols = Math.max(2, Math.min(gridCols - 2, Math.round(holeCols)));
            const leftCols = Math.max(1, Math.floor((gridCols - effHoleCols) / 2));
            const rightCols = Math.max(1, gridCols - effHoleCols - leftCols);

            const effHoleRows = Math.max(1, Math.min(gridRows - 1, Math.round(holeRows)));
            const rStart = (holeStartRow >= 1)
                ? Math.max(0, Math.min(gridRows - 1, Math.round(holeStartRow) - 1))
                : Math.max(0, Math.floor((gridRows - effHoleRows) / 2));
            const rEnd = Math.min(gridRows - 1, rStart + effHoleRows - 1);

            const leftW = leftCols * step;
            const rightW = rightCols * step;
            const holeXLeft = -totalSizeX / 2 + leftW;
            const holeXRight = totalSizeX / 2 - rightW;
            const holeZFront = totalSizeZ / 2 - rStart * step;
            const holeZBack = totalSizeZ / 2 - (rEnd + 1) * step;

            const weights = [];
            let sumWeights = 0;
            for (let r = 0; r < gridRows; r++) {
                const isRowHollow = (r >= rStart && r <= rEnd);
                const w = isRowHollow ? (leftCols + rightCols) : gridCols;
                weights.push(w);
                sumWeights += w;
            }

            const rowTileCounts = [];
            let accWeight = 0;
            let prevTotal = 0;
            for (let r = 0; r < gridRows; r++) {
                accWeight += weights[r];
                const targetCum = Math.round((accWeight / sumWeights) * totalTiles);
                const cnt = Math.max(2, targetCum - prevTotal);
                rowTileCounts.push(cnt);
                prevTotal += cnt;
            }
            const diff = totalTiles - prevTotal;
            if (diff !== 0) {
                rowTileCounts[gridRows - 1] = Math.max(2, rowTileCounts[gridRows - 1] + diff);
            }

            for (let r = 0; r < gridRows; r++) {
                const z = startZ - r * step;
                const k = rowTileCounts[r];
                const isRowHollow = (r >= rStart && r <= rEnd);
                const rowPts = [];

                if (!isRowHollow) {
                    const sX = totalSizeX / k;
                    const tW = Math.min(tileSize, Math.max(2.2, sX - gap));
                    for (let j = 0; j < k; j++) {
                        rowPts.push({
                            x: -totalSizeX / 2 + sX * (j + 0.5),
                            z,
                            rotY: 0,
                            tileW: tW
                        });
                    }
                } else {
                    const kLeft = Math.max(1, Math.round(k * (leftCols / (leftCols + rightCols))));
                    const kRight = Math.max(1, k - kLeft);
                    const sLeft = leftW / kLeft;
                    const tWLeft = Math.min(tileSize, Math.max(2.2, sLeft - gap));
                    for (let m = 0; m < kLeft; m++) {
                        rowPts.push({
                            x: -totalSizeX / 2 + sLeft * (m + 0.5),
                            z,
                            rotY: 0,
                            tileW: tWLeft
                        });
                    }
                    const sRight = rightW / kRight;
                    const tWRight = Math.min(tileSize, Math.max(2.2, sRight - gap));
                    for (let m = 0; m < kRight; m++) {
                        rowPts.push({
                            x: holeXRight + sRight * (m + 0.5),
                            z,
                            rotY: 0,
                            tileW: tWRight
                        });
                    }
                }

                if (r % 2 === 1) {
                    rowPts.reverse();
                }
                rowPts.forEach(pt => coords.push(pt));
            }

            return {
                coords,
                totalSizeX,
                totalSizeZ,
                holeW: holeXRight - holeXLeft,
                holeD: holeZFront - holeZBack,
                holeXLeft,
                holeXRight,
                holeZBack,
                holeZFront
            };
        }

        return null;
    }

    disposeHierarchy(root) {
        if (!root) return;
        root.traverse(obj => {
            if (obj.geometry) {
                try { obj.geometry.dispose(); } catch (e) { }
            }
            if (obj.material) {
                const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
                mats.forEach(m => {
                    if (!m) return;
                    try {
                        if (m.map) m.map.dispose();
                        if (m.lightMap) m.lightMap.dispose();
                        if (m.bumpMap) m.bumpMap.dispose();
                        if (m.normalMap) m.normalMap.dispose();
                        if (m.specularMap) m.specularMap.dispose();
                        if (m.envMap) m.envMap.dispose();
                        m.dispose();
                    } catch (e) { }
                });
            }
        });
    }

    buildBoard() {
        if (this.diceGroup && !this.isRolling) {
            this.diceGroup.visible = false;
        }
        while (this.boardGroup.children.length > 0) {
            const child = this.boardGroup.children[0];
            this.disposeHierarchy(child);
            this.boardGroup.remove(child);
        }
        this.tiles = [];
        this.tileMeshes = [];
        this.tileBorderMeshes = [];
        this.tileElevatedAuraMeshes = {};
        this.tileDepressedAreaMeshes = {};
        this.ladderObjects = {};
        this.snakeObjects = {};
        this.ladderEndToStart = {};
        if (this.ladders) {
            for (const [s, e] of Object.entries(this.ladders)) {
                this.ladderEndToStart[Number(e)] = Number(s);
            }
        }
        this.snakeTailToHead = {};
        if (this.snakes) {
            for (const [h, t] of Object.entries(this.snakes)) {
                this.snakeTailToHead[Number(t)] = Number(h);
            }
        }

        const theme = this.themes[this.boardTheme] || this.themes.ancient;
        const tileSize = this.tileSize;
        const gap = this.tileGap;
        const layout = this.boardLayout || 'square';
        const gridCols = (layout === 'rectangle') ? (this.customGridCols || 12) : (this.customGridCols || 10);
        const gridRows = (layout === 'rectangle') ? (this.customGridRows || 8) : (this.customGridRows || 10);
        const totalTiles = this.isMonopolyBoardMode ? 32 : 100;

        const hollowLayout = this.computeGameTileCoordinates(layout, gridCols, gridRows, totalTiles, tileSize, gap);
        this._hollowBounds = hollowLayout ? {
            xLeft: hollowLayout.holeXLeft,
            xRight: hollowLayout.holeXRight,
            zBack: hollowLayout.holeZBack,
            zFront: hollowLayout.holeZFront
        } : null;
        const totalSizeX = hollowLayout ? hollowLayout.totalSizeX : gridCols * (tileSize + gap);
        const totalSizeZ = hollowLayout ? hollowLayout.totalSizeZ : gridRows * (tileSize + gap);
        const startOffsetX = -totalSizeX / 2 + tileSize / 2;
        const startOffsetZ = (totalSizeZ / 2 - tileSize / 2);

        const frameColor = (this.boardTheme === 'ancient') ? 0x241808 : (theme.tileEven || 0x090e17);
        const frameMat = new THREE.MeshStandardMaterial({
            color: frameColor,
            map: this.customBoardSurfaceTexture || null,
            metalness: (this.boardTheme === 'ancient') ? 0.85 : 0.75,
            roughness: (this.boardTheme === 'ancient') ? 0.2 : 0.28
        });
        const frameBorderMat = new THREE.LineBasicMaterial({
            color: (this.boardTheme === 'ancient') ? 0xffd700 : theme.border,
            linewidth: 2.5
        });

        // 1. สร้างฐานกรอบกระดานตามรูปทรง (รองรับทั้งแบบเต็มกระดาน และ Hollow Center เว้นว่างตามแถวที่เลือก)
        if (hollowLayout) {
            const outerXLeft = -totalSizeX / 2 - 2.5;
            const outerXRight = totalSizeX / 2 + 2.5;
            const outerZBack = -totalSizeZ / 2 - 2.5;
            const outerZFront = totalSizeZ / 2 + 2.5;
            const outerW = outerXRight - outerXLeft;

            const inX1 = Math.max(outerXLeft + 2, hollowLayout.holeXLeft + 0.3);
            const inX2 = Math.min(outerXRight - 2, hollowLayout.holeXRight - 0.3);
            const inZ1 = Math.max(outerZBack + 1.5, hollowLayout.holeZBack + 0.3);
            const inZ2 = Math.min(outerZFront - 1.5, hollowLayout.holeZFront - 0.3);

            const innerW = Math.max(4, inX2 - inX1);
            const innerD = Math.max(4, inZ2 - inZ1);
            const holeCenterX = (inX1 + inX2) / 2;
            const holeCenterZ = (inZ1 + inZ2) / 2;

            const beamSpecs = [];
            if (inZ1 - outerZBack > 0.3) {
                beamSpecs.push({ w: outerW, d: inZ1 - outerZBack, x: 0, z: (outerZBack + inZ1) / 2 });
            }
            if (outerZFront - inZ2 > 0.3) {
                beamSpecs.push({ w: outerW, d: outerZFront - inZ2, x: 0, z: (inZ2 + outerZFront) / 2 });
            }
            if (inX1 - outerXLeft > 0.3) {
                beamSpecs.push({ w: inX1 - outerXLeft, d: innerD, x: (outerXLeft + inX1) / 2, z: holeCenterZ });
            }
            if (outerXRight - inX2 > 0.3) {
                beamSpecs.push({ w: outerXRight - inX2, d: innerD, x: (inX2 + outerXRight) / 2, z: holeCenterZ });
            }

            beamSpecs.forEach(bs => {
                const bGeo = new THREE.BoxGeometry(bs.w, 2.2, bs.d);
                const bMesh = new THREE.Mesh(bGeo, frameMat);
                bMesh.position.set(bs.x, -1.1, bs.z);
                bMesh.receiveShadow = true;
                this.boardGroup.add(bMesh);

                const bEdges = new THREE.LineSegments(new THREE.EdgesGeometry(bGeo), frameBorderMat);
                bEdges.position.set(bs.x, -1.1, bs.z);
                this.boardGroup.add(bEdges);
            });

            const hollowStyle = this.hollowStyle || 'arena_tray';
            if (hollowStyle === 'arena_tray') {
                const trayGeo = new THREE.BoxGeometry(innerW - 0.4, 0.55, innerD - 0.4);
                const trayMat = new THREE.MeshStandardMaterial({
                    color: theme.bgColor || 0x060b16,
                    metalness: 0.85,
                    roughness: 0.22
                });
                if (this.isMonopolyBoardMode) {
                    const mc = document.createElement('canvas');
                    mc.width = 512;
                    mc.height = 512;
                    const mctx = mc.getContext('2d');
                    const centerCol = this.activeMonopolyConfig?.center_bg_color || '#475569';
                    mctx.fillStyle = centerCol;
                    mctx.fillRect(0, 0, 512, 512);
                    const rad = mctx.createRadialGradient(256, 256, 40, 256, 256, 300);
                    rad.addColorStop(0, 'rgba(255,255,255,0.14)');
                    rad.addColorStop(1, 'rgba(0,0,0,0.35)');
                    mctx.fillStyle = rad;
                    mctx.fillRect(0, 0, 512, 512);
                    mctx.font = '900 54px "Kanit", sans-serif';
                    mctx.textAlign = 'center';
                    mctx.textBaseline = 'middle';
                    mctx.fillStyle = 'rgba(255,255,255,0.38)';
                    mctx.fillText('เกมเศรษฐี', 256, 256);
                    trayMat.map = new THREE.CanvasTexture(mc);
                    trayMat.color.setHex(0xffffff);
                    trayMat.roughness = 0.55;
                    trayMat.metalness = 0.25;
                }
                const trayMesh = new THREE.Mesh(trayGeo, trayMat);
                trayMesh.position.set(holeCenterX, -0.78, holeCenterZ);
                trayMesh.receiveShadow = true;
                this.boardGroup.add(trayMesh);
            } else if (hollowStyle === 'crystal_glass') {
                const glassGeo = new THREE.BoxGeometry(innerW - 0.4, 0.35, innerD - 0.4);
                const glassMat = new THREE.MeshStandardMaterial({
                    color: theme.border || 0x00e5ff,
                    transparent: true,
                    opacity: 0.22,
                    metalness: 0.9,
                    roughness: 0.1
                });
                const glassMesh = new THREE.Mesh(glassGeo, glassMat);
                glassMesh.position.set(holeCenterX, -0.35, holeCenterZ);
                this.boardGroup.add(glassMesh);
            }
        } else {
            let frameGeo;
            if (layout === 'spiral') {
                const outerR = 35.0;
                frameGeo = new THREE.CylinderGeometry(outerR + 4.5, outerR + 6.5, 2.2, 48);
            } else if (layout === 'hexagon') {
                const hexR = 38.5;
                frameGeo = new THREE.CylinderGeometry(hexR + 2.0, hexR + 4.5, 2.2, 6);
            } else {
                frameGeo = new THREE.BoxGeometry(totalSizeX + 5, 2.2, totalSizeZ + 5);
            }

            const frame = new THREE.Mesh(frameGeo, frameMat);
            frame.position.y = -1.1;
            if (layout === 'hexagon') frame.rotation.y = Math.PI / 6;
            frame.receiveShadow = true;
            this.boardGroup.add(frame);

            const frameBorderGeo = new THREE.EdgesGeometry(frameGeo);
            const frameBorder = new THREE.LineSegments(frameBorderGeo, frameBorderMat);
            frameBorder.position.y = -1.1;
            if (layout === 'hexagon') frameBorder.rotation.y = Math.PI / 6;
            this.boardGroup.add(frameBorder);
        }

        // 2. คำนวณพิกัดช่องและรูปทรงบล็อกตาม Layout (100 ช่องสำหรับบันไดงู หรือ 32 ช่องสำหรับเกมส์เศรษฐี 9 ช่อง/แถว)
        for (let i = 1; i <= totalTiles; i++) {
            let x = 0, y = 0, z = 0;
            let tileMeshRotationY = 0;
            let tileGeo;
            let isTileCylinder = false;

            const isChance = this.chanceTiles.includes(i);
            const isTax = this.taxTiles.includes(i);
            const isGamble = this.gambleTiles.includes(i);
            const isDestroy = this.destroyTiles && this.destroyTiles.includes(i);
            const isJail = (i === this.jailTile);
            const isOlympic = Boolean(this.isMonopolyBoardMode && ((Array.isArray(this.olympicTiles) && this.olympicTiles.includes(i)) || i === this.olympicTile));
            const isWorldTravel = Boolean(this.isMonopolyBoardMode && ((Array.isArray(this.worldTravelTiles) && this.worldTravelTiles.includes(i)) || i === this.worldTravelTile));
            const isExpressway = Boolean(this.isMonopolyBoardMode && Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(i));
            const isGodTile = Boolean(this.isMonopolyBoardMode && Array.isArray(this.godTiles) && this.godTiles.includes(i));
            const isGoal = (!this.isMonopolyBoardMode && i === 100);
            const isStart = (i === 1);

            const isLadderEnd = Boolean(this.ladderEndToStart && this.ladderEndToStart[i]);
            const isSnakeEnd = Boolean(this.snakeTailToHead && this.snakeTailToHead[i]);

            // ผู้ใช้กำหนด: "กระดาน แก้ไข บันได หรืองู หากพาดที่ไหน เมืองไหน ให้นูนขึ้น หากพื้นที่นั้นเป็นพื่นที่ไป และหากพื้นที่ลง ให้ยุบลงเล็กน้อย"
            // - ปลายทางบันไดที่ไต่ขึ้นไป (พื้นที่ไป) => เนินนูนสูงขึ้น +1.25
            // - ปลายทางงูที่ร่วงลงไป (พื้นที่ลง) => ยุบตัวลงเล็กน้อย -0.45
            let tileElev = 0;
            if (isLadderEnd) {
                tileElev = 0.30; // นูนขึ้นนิดเดียว (+0.30)
            } else if (isSnakeEnd) {
                tileElev = -0.20; // ยุบลงนิดเดียว (-0.20)
            }

            const baseTileH = 0.8;
            const tileH = Math.max(0.35, baseTileH + tileElev);
            const meshPosY = (tileH / 2) - 0.40;

            if (hollowLayout && hollowLayout.coords[i - 1]) {
                x = hollowLayout.coords[i - 1].x;
                z = hollowLayout.coords[i - 1].z;
                tileMeshRotationY = hollowLayout.coords[i - 1].rotY || 0;
                const tW = hollowLayout.coords[i - 1].tileW || tileSize;
                y = 0;
                tileGeo = new THREE.BoxGeometry(tW, tileH, tileSize);
            } else if (layout === 'spiral') {
                // 🌀 ทรงกลมก้นหอย: วน 3.8 รอบจากขอบนอกเข้าสู่ใจกลาง
                const u = (i - 1) / 99; // 0.0 (ขอบนอก ช่อง 1) -> 1.0 (ใจกลาง ช่อง 100)
                const spiralTurns = 3.8;
                const angle = u * spiralTurns * (Math.PI * 2) - Math.PI / 2;
                const maxR = 33.0;
                const minRatio = this.hollowCenter ? 0.62 : 0.93;
                const r = maxR * (1.0 - minRatio * u);
                x = r * Math.cos(angle);
                z = r * Math.sin(angle);
                y = 0;

                if (isGoal) {
                    tileGeo = new THREE.CylinderGeometry(3.6, 3.8, tileH, 24);
                    isTileCylinder = true;
                } else {
                    tileGeo = new THREE.BoxGeometry(4.8, tileH, 4.8);
                    tileMeshRotationY = -angle; // หมุนเอียงตามแนวโค้งของวงก้นหอย
                }
            } else if (layout === 'hexagon') {
                // ⬡ ทรงหกเหลี่ยมรังผึ้ง (Honeycomb Staggered Grid)
                const r = Math.floor((i - 1) / gridCols);
                const colInRow = (i - 1) % gridCols;
                const c = (r % 2 === 0) ? colInRow : (gridCols - 1 - colInRow);
                const hexStepX = 6.4;
                const hexStepZ = 5.7;
                const stagger = (r % 2 === 1) ? (hexStepX * 0.5) : 0;
                x = (-((gridCols - 1) / 2) * hexStepX) + c * hexStepX + stagger;
                z = (((gridRows - 1) / 2) * hexStepZ) - r * hexStepZ;
                y = 0;

                tileGeo = new THREE.CylinderGeometry(3.3, 3.3, tileH, 6);
                isTileCylinder = true;
                tileMeshRotationY = Math.PI / 6; // หันมุมหกเหลี่ยม
            } else if (layout === 'diamond_ring') {
                // ❖ วงแหวนเพชร
                const u = (i - 1) / 100;
                const ringLayer = Math.floor((i - 1) / 34);
                const angle = u * Math.PI * 6;
                const rx = (totalSizeX * 0.46) * (1 - ringLayer * 0.26);
                const rz = (totalSizeZ * 0.46) * (1 - ringLayer * 0.26);
                x = Math.cos(angle) * rx;
                z = Math.sin(angle) * rz;
                y = 0;
                tileGeo = new THREE.BoxGeometry(tileSize * 0.82, tileH, tileSize * 0.82);
            } else {
                // ▭ สี่เหลี่ยมผืนผ้า (Rectangle) หรือ 🟩 สี่เหลี่ยมจัตุรัส (Square)
                const row = Math.floor((i - 1) / gridCols);
                const colInRow = (i - 1) % gridCols;
                const col = (row % 2 === 0) ? colInRow : (gridCols - 1 - colInRow);
                x = startOffsetX + col * (tileSize + gap);
                z = startOffsetZ - row * (tileSize + gap);
                y = 0;

                tileGeo = new THREE.BoxGeometry(tileSize, tileH, tileSize);
            }

            this.tiles[i] = new THREE.Vector3(x, tileElev, z);

            let tileType = 'NORMAL';
            if (isGoal) tileType = 'GOAL';
            else if (isStart) tileType = 'START';
            else if (isExpressway) tileType = 'EXPRESSWAY';
            else if (isGodTile) tileType = 'GOD_TILE';
            else if (isOlympic) tileType = 'OLYMPIC';
            else if (isWorldTravel) tileType = 'WORLD_TRAVEL';
            else if (isGamble) tileType = 'GAMBLE';
            else if (isTax) tileType = 'TAX';
            else if (isChance) tileType = 'CHANCE';
            else if (isDestroy) tileType = 'DESTROY';
            else if (isJail) tileType = 'JAIL';

            let monoCityHexNum = null;
            if (this.isMonopolyBoardMode && tileType === 'NORMAL' && Array.isArray(this.monopolyTilesList) && this.monopolyTilesList[i - 1]?.color) {
                const parsedHex = parseInt(String(this.monopolyTilesList[i - 1].color).replace('#', ''), 16);
                if (!isNaN(parsedHex)) monoCityHexNum = parsedHex;
            }

            const sideMat = new THREE.MeshStandardMaterial({
                color: monoCityHexNum !== null ? monoCityHexNum : ((i % 2 === 0) ? theme.tileEven : theme.tileOdd),
                metalness: (this.boardTheme === 'ancient') ? 0.7 : 0.5,
                roughness: (this.boardTheme === 'ancient') ? 0.25 : 0.35
            });

            const provinceName = this.getProvinceName(i);
            const topTex = this.createTileTexture(i, provinceName, tileType, theme);
            const topMat = new THREE.MeshStandardMaterial({
                map: topTex,
                metalness: (this.boardTheme === 'ancient') ? 0.6 : 0.4,
                roughness: (this.boardTheme === 'ancient') ? 0.2 : 0.25,
                emissive: monoCityHexNum !== null ? monoCityHexNum : (isGoal ? 0x10b981 : (isStart ? 0x0284c7 : (isOlympic ? 0xd97706 : (isWorldTravel ? 0x0284c7 : (isGamble ? 0x6b21a8 : (isDestroy ? 0x881337 : (isTax ? 0x7f1d1d : (isChance ? 0x78350f : (this.boardTheme === 'ancient' ? 0x1a1204 : (isLadderEnd ? 0x064e3b : (isSnakeEnd ? 0x4c0519 : 0x000000))))))))))),
                emissiveIntensity: monoCityHexNum !== null ? 0.28 : (isStart ? 0.35 : (this.boardTheme === 'ancient' ? 0.2 : ((isLadderEnd || isSnakeEnd) ? 0.3 : 0.15)))
            });

            // สร้าง Mesh ตามทรง
            let tileMesh;
            if (isTileCylinder) {
                // CylinderGeometry material groups: [sideMat, topMat, bottomMat]
                tileMesh = new THREE.Mesh(tileGeo, [sideMat, topMat, sideMat]);
            } else {
                // BoxGeometry 6 faces: [right, left, top, bottom, front, back]
                tileMesh = new THREE.Mesh(tileGeo, [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
            }
            tileMesh.position.set(x, meshPosY, z);
            if (tileMeshRotationY) tileMesh.rotation.y = tileMeshRotationY;
            tileMesh.receiveShadow = true;
            tileMesh.userData = { tileNum: i };
            this.boardGroup.add(tileMesh);
            this.tileMeshes[i] = tileMesh;

            const edgeGeo = new THREE.EdgesGeometry(tileGeo);
            let borderColor = isGoal ? 0x00ffcc : (isStart ? 0x00e5ff : theme.border);
            if (this.isMonopolyBoardMode && Array.isArray(this.monopolyTilesList) && this.monopolyTilesList[i - 1]?.color) {
                const mHex = parseInt(String(this.monopolyTilesList[i - 1].color).replace('#', ''), 16);
                if (!isNaN(mHex)) borderColor = mHex;
            }
            if (isLadderEnd) borderColor = 0x34d399; // ออร่าเขียวมรกตเรืองแสงสำหรับเนินนูนบันได
            else if (isSnakeEnd) borderColor = 0xf43f5e; // ออร่าแดงทับทิมสำหรับหลุมยุบงู

            const edgeMat = new THREE.LineBasicMaterial({
                color: borderColor,
                linewidth: (isLadderEnd || isSnakeEnd) ? 2.5 : 1.5
            });
            const borderLine = new THREE.LineSegments(edgeGeo, edgeMat);
            borderLine.position.set(x, meshPosY, z);
            if (tileMeshRotationY) borderLine.rotation.y = tileMeshRotationY;
            this.boardGroup.add(borderLine);
            this.tileBorderMeshes[i] = borderLine;

            const topY = tileElev + 0.40;
            if (isChance) {
                this.createChanceChest(x, topY + 0.8, z);
            } else if (isTax) {
                this.createTaxSign(x, topY + 0.8, z);
            } else if (isOlympic || isGodTile) {
                this.createGoalTrophy(x, topY + 0.8, z);
            } else if (isWorldTravel || isExpressway) {
                this.createLuckyWheel3D(x, topY + 0.8, z);
            } else if (isGamble) {
                this.createLuckyWheel3D(x, topY + 0.8, z);
            } else if (isDestroy) {
                this.createDestroySign(x, topY + 0.8, z);
            } else if (isJail) {
                this.createPrisonJail(x, topY + 0.8, z);
            } else if (isStart) {
                this.createStartPointLandmark(x, topY, z);
            } else if (isGoal) {
                this.createGoalCityLandmark(x, topY, z);
            }

            // 🌟 แสงเออร่าประจำพื้นที่ 3D (แสดงตามความหนาที่ตั้งค่าในหน้า Admin)
            if (this.isMonopolyBoardMode && Array.isArray(this.monopolyTilesList)) {
                const mtCfg = this.monopolyTilesList[i - 1];
                const showMode = mtCfg?.show_aura || 'AUTO';
                const isAutoSpecialAura = (showMode === 'AUTO') && (Number(mtCfg?.special_multiplier) >= 2 || isExpressway || isGodTile || isDestroy || isGamble || isOlympic || isWorldTravel);
                if (showMode === 'ALWAYS' || isAutoSpecialAura) {
                    const bThick = Number(this.monopolyStageSkillConfig?.aura_thickness || 2.2);
                    const aThick = Math.max(0.8, Math.min(3.5, Number(mtCfg?.aura_thickness || bThick || 2.2)));
                    const aColStr = mtCfg?.aura_color || mtCfg?.color || '#38bdf8';
                    const aColHex = parseInt(String(aColStr).replace('#', ''), 16) || 0x38bdf8;
                    const innerR = Math.max(1.6, 2.55 - (0.28 * aThick));
                    const outerR = 2.65 + (0.22 * aThick);
                    const auraRing = new THREE.Mesh(
                        new THREE.RingGeometry(innerR, outerR, 32),
                        new THREE.MeshBasicMaterial({
                            color: aColHex,
                            side: THREE.DoubleSide,
                            transparent: true,
                            opacity: 0.78,
                            blending: THREE.AdditiveBlending
                        })
                    );
                    auraRing.rotation.x = -Math.PI / 2;
                    auraRing.position.set(x, topY + 0.06, z);
                    this.boardGroup.add(auraRing);
                }
            }
        }

        this.updateAllTileElevations();

        for (const [start, end] of Object.entries(this.ladders)) {
            const s = Number(start);
            const e = Number(end);
            if (this.tiles[s] && this.tiles[e]) {
                this.create3DLadder(this.tiles[s], this.tiles[e], theme.ladder, s, e);
            }
        }

        for (const [start, end] of Object.entries(this.snakes)) {
            const s = Number(start);
            const e = Number(end);
            if (this.tiles[s] && this.tiles[e]) {
                this.create3DSnake(this.tiles[s], this.tiles[e], theme.snake, s, e);
            }
        }
    }

    createChanceChest(x, y, z) {
        const chestGroup = new THREE.Group();
        const chestGeo = new THREE.BoxGeometry(1.8, 1.3, 1.3);
        const chestMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2 });
        const chest = new THREE.Mesh(chestGeo, chestMat);
        chestGroup.add(chest);

        const gemGeo = new THREE.OctahedronGeometry(0.5);
        const gemMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
        const gem = new THREE.Mesh(gemGeo, gemMat);
        gem.position.y = 1.2;
        chestGroup.add(gem);

        chestGroup.position.set(x, y, z);
        this.boardGroup.add(chestGroup);
    }

    createPrisonJail(x, y, z) {
        const jailGroup = new THREE.Group();
        const barGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.8, 8);
        const barMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95 });

        for (let i = -1; i <= 1; i += 0.7) {
            const bar = new THREE.Mesh(barGeo, barMat);
            bar.position.set(i, 0, 1.2);
            jailGroup.add(bar);
        }

        jailGroup.position.set(x, y, z);
        this.boardGroup.add(jailGroup);
    }

    createGoalTrophy(x, y, z) {
        const trophyGroup = new THREE.Group();
        const cupGeo = new THREE.CylinderGeometry(1.4, 0.4, 2.2, 16);
        const cupMat = new THREE.MeshStandardMaterial({ color: 0xffea00, metalness: 0.9, roughness: 0.1 });
        const cup = new THREE.Mesh(cupGeo, cupMat);
        trophyGroup.add(cup);

        trophyGroup.position.set(x, y, z);
        this.boardGroup.add(trophyGroup);
    }

    /**
     * 🏷️ ป้าย Hologram 3D Billboard ขนาดใหญ่คมชัดสูงพิเศษ (Ultra-Crisp 768x216)
     * ระบุชัดเจน 100% ว่าอันไหนขึ้น (⬆️ ไต่ขึ้นบันได) และอันไหนลง (⬇️ กับดักงูสไลด์ลง)
     */
    /**
     * ป้าย Hologram 3D สไตล์นีออนเรืองแสงขนาดใหญ่พิเศษ (1024x280) คมชัดระดับ Ultra-HD
     * ตัวหนังสือคมกริบ มองเห็นชัดเจน 100% จากระยะไกลและทุกมุมกล้อง 3D
     * ระบุชัดเจน: 🪜 ขึ้น (ไต่ขึ้นไปช่อง X) และ 🐍 ลง (ร่วงตกไปช่อง Y)
     */
    createHologramBadgeSprite(type, startTile, endTile) {
        // High-DPI Canvas ให้ตัวอักษรใหญ่ คมชัดพิเศษ อ่านได้ง่ายจากทุกมุมกล้อง (ปรับความละเอียดให้ประหยัดแรม ปลอดภัยบน iOS/Android)
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
        const canvas = document.createElement('canvas');
        const targetW = isMobileOrTablet ? 512 : 768;
        const targetH = Math.round(280 * (targetW / 1024));
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        const s = targetW / 1024;
        ctx.scale(s, s);

        const bCfg = this.badgeConfig || this.getDefaultBadgeConfig();
        const ladCfg = bCfg.ladder || {};
        const snkCfg = bCfg.snake || {};

        function roundRect(x, y, w, h, r) {
            ctx.beginPath();
            ctx.moveTo(x + r, y);
            ctx.lineTo(x + w - r, y);
            ctx.quadraticCurveTo(x + w, y, x + w, y + r);
            ctx.lineTo(x + w, y + h - r);
            ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
            ctx.lineTo(x + r, y + h);
            ctx.quadraticCurveTo(x, y + h, x, y + h - r);
            ctx.lineTo(x, y + r);
            ctx.quadraticCurveTo(x, y, x + r, y);
            ctx.closePath();
        }

        if (type === 'ladder_start') {
            // Neon Emerald Green (ทางขึ้น ⬆️) - กำหนดสีและข้อความตาม Admin Studio
            const ladBg1 = ladCfg.bg1 || '#064e3b';
            const ladBg2 = ladCfg.bg2 || '#059669';
            const ladBorder = ladCfg.borderColor || '#34d399';
            const ladTextCol = ladCfg.textColor || '#fef08a';
            const ladPrefix = ladCfg.textPrefix || 'ไต่ขึ้นไปช่อง';

            const grad = ctx.createLinearGradient(0, 0, 1024, 280);
            grad.addColorStop(0, ladBg1);
            grad.addColorStop(0.5, ladBg2);
            grad.addColorStop(1, ladBg1);
            ctx.fillStyle = grad;
            roundRect(12, 12, 1000, 256, 60);
            ctx.fill();

            // เรืองแสงนีออนขอบหนา
            ctx.strokeStyle = ladBorder;
            ctx.lineWidth = 14;
            ctx.shadowColor = ladBorder;
            ctx.shadowBlur = 28;
            roundRect(12, 12, 1000, 256, 60);
            ctx.stroke();

            // ขอบด้านในสีขาวเรืองแสง
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 3.5;
            ctx.shadowBlur = 0;
            roundRect(24, 24, 976, 232, 50);
            ctx.stroke();

            // Left Pill: [ 🪜 ขึ้น ] พื้นขาว ตัวหนังสือสีเข้มเด่นสะดุดตา
            ctx.fillStyle = '#ffffff';
            roundRect(32, 32, 280, 216, 44);
            ctx.fill();
            ctx.strokeStyle = ladBorder;
            ctx.lineWidth = 8;
            roundRect(32, 32, 280, 216, 44);
            ctx.stroke();

            ctx.fillStyle = ladBg1;
            ctx.font = '900 102px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = 'rgba(0,0,0,0.3)';
            ctx.shadowBlur = 6;
            ctx.fillText('🪜 ขึ้น', 172, 142);

            // Main Destination Text
            const ladderText = `${ladPrefix} ${this.getDisplayTileNumber(endTile)}`;
            ctx.font = '900 88px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'left';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 14;
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 16;
            ctx.strokeText(ladderText, 345, 142);
            ctx.fillStyle = ladTextCol;
            ctx.fillText(ladderText, 345, 142);
        } else if (type === 'snake_head') {
            // Danger Crimson Red (ทางลง ⬇️) - กำหนดสีและข้อความตาม Admin Studio
            const snkBg1 = snkCfg.bg1 || '#7f1d1d';
            const snkBg2 = snkCfg.bg2 || '#dc2626';
            const snkBorder = snkCfg.borderColor || '#fca5a5';
            const snkTextCol = snkCfg.textColor || '#fef08a';
            const snkPrefix = snkCfg.textPrefix || 'ร่วงตกไปช่อง';

            const grad = ctx.createLinearGradient(0, 0, 1024, 280);
            grad.addColorStop(0, snkBg1);
            grad.addColorStop(0.5, snkBg2);
            grad.addColorStop(1, snkBg1);
            ctx.fillStyle = grad;
            roundRect(12, 12, 1000, 256, 60);
            ctx.fill();

            ctx.strokeStyle = snkBorder;
            ctx.lineWidth = 14;
            ctx.shadowColor = snkBorder;
            ctx.shadowBlur = 28;
            roundRect(12, 12, 1000, 256, 60);
            ctx.stroke();

            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 3.5;
            ctx.shadowBlur = 0;
            roundRect(24, 24, 976, 232, 50);
            ctx.stroke();

            // Left Pill: [ 🐍 ลง ] พื้นขาว ตัวหนังสือแดงเข้ม ชัดเจน 100%
            ctx.fillStyle = '#ffffff';
            roundRect(32, 32, 280, 216, 44);
            ctx.fill();
            ctx.strokeStyle = snkBorder;
            ctx.lineWidth = 8;
            roundRect(32, 32, 280, 216, 44);
            ctx.stroke();

            ctx.fillStyle = snkBg1;
            ctx.font = '900 102px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = 'rgba(0,0,0,0.3)';
            ctx.shadowBlur = 6;
            ctx.fillText('🐍 ลง', 172, 142);

            // Main Destination Text
            const snakeText = `${snkPrefix} ${this.getDisplayTileNumber(endTile)}`;
            ctx.font = '900 88px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'left';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 14;
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 16;
            ctx.strokeText(snakeText, 345, 142);
            ctx.fillStyle = snkTextCol;
            ctx.fillText(snakeText, 345, 142);
        } else if (type === 'ladder_end') {
            // Cyan Arrival Badge (ปลายทางบันได 🏁)
            const ladBorder = ladCfg.borderColor || '#38bdf8';
            const grad = ctx.createLinearGradient(0, 0, 1024, 280);
            grad.addColorStop(0, '#075985');
            grad.addColorStop(0.5, '#0284c7');
            grad.addColorStop(1, '#0369a1');
            ctx.fillStyle = grad;
            roundRect(14, 14, 996, 252, 54);
            ctx.fill();

            ctx.strokeStyle = ladBorder;
            ctx.lineWidth = 12;
            ctx.shadowColor = ladBorder;
            ctx.shadowBlur = 24;
            roundRect(14, 14, 996, 252, 54);
            ctx.stroke();

            const endText = `🏁 ถึงช่อง ${endTile} (ปลายทาง)`;
            ctx.font = '900 90px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 14;
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 14;
            ctx.strokeText(endText, 512, 142);
            ctx.fillStyle = '#ffffff';
            ctx.fillText(endText, 512, 142);
        } else if (type === 'snake_tail') {
            // Violet Landing Badge (จุดร่วงของงู 💧)
            const snkBorder = snkCfg.borderColor || '#c084fc';
            const grad = ctx.createLinearGradient(0, 0, 1024, 280);
            grad.addColorStop(0, '#581c87');
            grad.addColorStop(0.5, '#7e22ce');
            grad.addColorStop(1, '#6b21a8');
            ctx.fillStyle = grad;
            roundRect(14, 14, 996, 252, 54);
            ctx.fill();

            ctx.strokeStyle = snkBorder;
            ctx.lineWidth = 12;
            ctx.shadowColor = snkBorder;
            ctx.shadowBlur = 24;
            roundRect(14, 14, 996, 252, 54);
            ctx.stroke();

            const tailText = `💧 จุดร่วงของงู (ช่อง ${endTile})`;
            ctx.font = '900 90px "Prompt", "Kanit", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 14;
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 14;
            ctx.strokeText(tailText, 512, 142);
            ctx.fillStyle = '#f5d0fe';
            ctx.fillText(tailText, 512, 142);
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.minFilter = isMobileOrTablet ? THREE.LinearFilter : THREE.LinearMipmapLinearFilter;
        tex.magFilter = THREE.LinearFilter;
        tex.generateMipmaps = !isMobileOrTablet;
        tex.anisotropy = isMobileOrTablet ? 1 : 4;
        const mat = new THREE.SpriteMaterial({
            map: tex,
            transparent: true,
            depthTest: false,
            depthWrite: false
        });
        const sprite = new THREE.Sprite(mat);

        // กำหนด Scale ตาม Badge Config (Admin Studio)
        let badgeScale = 1.0;
        if (type === 'ladder_start' || type === 'ladder_end') {
            badgeScale = Math.max(0.6, Math.min(2.0, Number(ladCfg.scale) || 1.0));
        } else if (type === 'snake_head' || type === 'snake_tail') {
            badgeScale = Math.max(0.6, Math.min(2.0, Number(snkCfg.scale) || 1.0));
        }
        sprite.scale.set(12.0 * badgeScale, 3.4 * badgeScale, 1);
        sprite.renderOrder = 95;
        return sprite;
    }

    create3DLadder(startPos, endPos, colorHex, startTile = 0, endTile = 0) {
        if (!startPos || !endPos) return;
        const ladderGroup = new THREE.Group();

        // 1. คำนวณพิกัดระดับ 3D ของทั้งจุดเริ่มและจุดปลาย (รองรับช่องนูนขึ้น / ยุบลง)
        const pStart = new THREE.Vector3(startPos.x, (startPos.y || 0) + 0.42, startPos.z);
        const pEnd = new THREE.Vector3(endPos.x, (endPos.y || 0) + 0.42, endPos.z);

        const dir = new THREE.Vector3().subVectors(pEnd, pStart);
        const dist = Math.max(dir.length(), 1.0);
        const dirNorm = dir.clone().normalize();

        // 2. เวกเตอร์แนวตั้งฉากตามแนวนอน (Horizontal Perpendicular Vector) สำหรับวางรางบันไดซ้าย-ขวา
        const flatDir = new THREE.Vector3(dir.x, 0, dir.z).normalize();
        const perp = new THREE.Vector3(flatDir.z, 0, -flatDir.x).normalize();
        // เวกเตอร์ชี้ขึ้นตามความลาดชันของบันได
        const up = new THREE.Vector3().crossVectors(dirNorm, perp).normalize();

        // ขนาดสัดส่วนบันได
        const ladderWidth = 2.4;
        const halfWidth = ladderWidth / 2;
        const railRadius = 0.22;
        const rungRadius = 0.14;
        const halfDist = dist / 2;

        const railMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            metalness: 0.85,
            roughness: 0.2,
            emissive: colorHex,
            emissiveIntensity: 0.35
        });

        const rungMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            metalness: 0.65,
            roughness: 0.3,
            emissive: 0x475569,
            emissiveIntensity: 0.2
        });

        // 3. รางบันไดซ้ายและขวา: ทอดตัวตามแกน Z ภายใน local space ของ ladderGroup
        const railGeo = new THREE.CylinderGeometry(railRadius, railRadius, dist, 12);

        const railL = new THREE.Mesh(railGeo, railMat);
        railL.position.set(-halfWidth, 0, 0);
        railL.rotation.x = Math.PI / 2; // หมุนนอนไปตามแกน Z
        ladderGroup.add(railL);

        const railR = new THREE.Mesh(railGeo, railMat);
        railR.position.set(halfWidth, 0, 0);
        railR.rotation.x = Math.PI / 2; // หมุนนอนไปตามแกน Z
        ladderGroup.add(railR);

        // 4. หัวครอบปลายบันไดทั้ง 4 จุด (สวยงาม มีมิติ ไม่เป็นท่อตัดเหลี่ยม)
        const capGeo = new THREE.SphereGeometry(railRadius * 1.3, 10, 10);
        [[-halfWidth, -halfDist], [-halfWidth, halfDist], [halfWidth, -halfDist], [halfWidth, halfDist]].forEach(([rx, rz]) => {
            const cap = new THREE.Mesh(capGeo, railMat);
            cap.position.set(rx, 0, rz);
            ladderGroup.add(cap);
        });

        // 5. ขั้นบันได (Rungs): วางขนานเชื่อมระหว่างรางซ้าย-ขวาตามแกน X
        const rungsCount = Math.max(2, Math.floor(dist / 2.6));
        const rungGeo = new THREE.CylinderGeometry(rungRadius, rungRadius, ladderWidth, 8);
        for (let i = 0; i < rungsCount; i++) {
            const rung = new THREE.Mesh(rungGeo, rungMat);
            rung.rotation.z = Math.PI / 2; // หมุนนอนไปตามแกน X
            const rungZ = -halfDist + (i + 1) * (dist / (rungsCount + 1));
            rung.position.set(0, 0, rungZ);
            ladderGroup.add(rung);
        }

        // 5.1 เพิ่มลูกศรนีออนเรืองแสงสีเขียวชี้ขึ้นตามขั้นบันได (Directional Upward Chevrons)
        // ระบุทิศทางการไต่ขึ้นไปยังปลายทาง (+Z direction) อย่างชัดเจน
        const arrowGeo = new THREE.ConeGeometry(0.5, 0.82, 3);
        const arrowMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
        [-halfDist * 0.45, 0, halfDist * 0.45].forEach(zPos => {
            const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
            arrowMesh.rotation.x = Math.PI / 2; // นอนราบบนขั้นบันได
            arrowMesh.rotation.z = Math.PI; // หัวลูกศรชี้พุ่งไปข้างหน้าตามแกน +Z (มุ่งหน้าไป endPos ปลายทาง)
            arrowMesh.position.set(0, rungRadius + 0.14, zPos);
            ladderGroup.add(arrowMesh);
        });

        // 6. ตำแหน่งกึ่งกลาง: คำนวณจาก pStart และ pEnd พร้อมยกขึ้นตามเวกเตอร์ up เล็กน้อยเพื่อให้ลอยเหนือผิวพอดี
        const midPoint = new THREE.Vector3().addVectors(pStart, pEnd).multiplyScalar(0.5);
        midPoint.addScaledVector(up, railRadius + 0.10);
        ladderGroup.position.copy(midPoint);

        // 7. กำหนดแกนมุมมอง 3D ให้บันได (Right-handed Orthonormal Basis)
        const rotMatrix = new THREE.Matrix4().makeBasis(perp, up, dirNorm);
        ladderGroup.quaternion.setFromRotationMatrix(rotMatrix);

        this.boardGroup.add(ladderGroup);

        const badges = [];
        const allowBadges = Boolean(this.badgeConfig?.showBadges) && (this.badgeConfig?.ladder?.show !== false);
        if (startTile && endTile && startPos && endPos) {
            // ป้าย Hologram ที่จุดเริ่มบันได (ทางขึ้น ⬆️)
            const startBadge = this.createHologramBadgeSprite('ladder_start', startTile, endTile);
            startBadge.position.set(startPos.x, (startPos.y || 0) + 3.2, startPos.z);
            startBadge.visible = allowBadges;
            this.boardGroup.add(startBadge);
            badges.push(startBadge);

            // ป้าย Hologram ที่ปลายทางบันได (จุดสิ้นสุด 🏁)
            const endBadge = this.createHologramBadgeSprite('ladder_end', startTile, endTile);
            endBadge.position.set(endPos.x, (endPos.y || 0) + 2.5, endPos.z);
            endBadge.visible = allowBadges;
            this.boardGroup.add(endBadge);
            badges.push(endBadge);
        }

        if (startTile) {
            this.ladderObjects[startTile] = { group: ladderGroup, startPos, endPos, badges };
        }
    }

    create3DSnake(headPos, tailPos, colorHex, startTile = 0, endTile = 0) {
        if (!headPos || !tailPos) return;
        const snakeGroup = new THREE.Group();

        const p0 = new THREE.Vector3(headPos.x, (headPos.y || 0) + 1.15, headPos.z);
        const p3 = new THREE.Vector3(tailPos.x, (tailPos.y || 0) + 0.45, tailPos.z);
        const flatDir = new THREE.Vector3(p3.x - p0.x, 0, p3.z - p0.z);
        const flatLen = Math.max(flatDir.length(), 1);
        flatDir.normalize();
        const perp = new THREE.Vector3(-flatDir.z, 0, flatDir.x);
        const waveAmp = Math.min(4.2, Math.max(2.2, flatLen * 0.16));

        const mid1 = new THREE.Vector3().lerpVectors(p0, p3, 0.33);
        mid1.addScaledVector(perp, waveAmp);
        mid1.y = (headPos.y || 0) + 3.6;

        const mid2 = new THREE.Vector3().lerpVectors(p0, p3, 0.68);
        mid2.addScaledVector(perp, -waveAmp * 0.85);
        mid2.y = THREE.MathUtils.lerp((headPos.y || 0) + 2.2, (tailPos.y || 0) + 1.6, 0.6);

        const curve = new THREE.CatmullRomCurve3([p0, mid1, mid2, p3]);

        // สร้างลำตัวงู 3D โค้งมนเรียวลงไปหาปลายหาง
        const segments = 48;
        const radialSegments = 14;
        const tubeGeo = new THREE.TubeGeometry(curve, segments, 0.62, radialSegments, false);
        const posAttr = tubeGeo.attributes.position;
        const frames = curve.computeFrenetFrames(segments, false);
        const centerPt = new THREE.Vector3();
        const vtx = new THREE.Vector3();
        for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            curve.getPointAt(t, centerPt);
            // ค่อยๆ เรียวเล็กที่ช่วงปลายหางอย่างเป็นธรรมชาติ
            const taper = t < 0.7 ? 1.0 : Math.max(0.18, 1.0 - ((t - 0.7) / 0.3) * 0.82);
            for (let j = 0; j <= radialSegments; j++) {
                const idx = i * (radialSegments + 1) + j;
                if (idx < posAttr.count) {
                    vtx.fromBufferAttribute(posAttr, idx);
                    vtx.sub(centerPt).multiplyScalar(taper).add(centerPt);
                    posAttr.setXYZ(idx, vtx.x, vtx.y, vtx.z);
                }
            }
        }
        tubeGeo.computeVertexNormals();

        const bodyMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            roughness: 0.24,
            metalness: 0.65,
            emissive: colorHex,
            emissiveIntensity: 0.28
        });
        const snakeMesh = new THREE.Mesh(tubeGeo, bodyMat);
        snakeMesh.castShadow = true;
        snakeGroup.add(snakeMesh);

        // หัวพญางู 3D ทรงมนพร้อมดวงตาคู่และลิ้นสองแฉก (ตรงตามรูป 1)
        const headGroup = new THREE.Group();
        headGroup.position.set(headPos.x, (headPos.y || 0) + 1.25, headPos.z);

        // หันหัวงูไปตามทิศลำตัว/กล้องอย่างสมจริง
        const lookTarget = new THREE.Vector3().lerpVectors(mid1, new THREE.Vector3(headPos.x, (headPos.y || 0) + 1.1, headPos.z + 4.5), 0.45);
        lookTarget.y = (headPos.y || 0) + 1.05;
        headGroup.lookAt(lookTarget);

        const craniumGeo = new THREE.SphereGeometry(1.05, 24, 18);
        craniumGeo.scale(1.08, 0.82, 1.32);
        const headMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            roughness: 0.2,
            metalness: 0.68,
            emissive: colorHex,
            emissiveIntensity: 0.32
        });
        const cranium = new THREE.Mesh(craniumGeo, headMat);
        cranium.castShadow = true;
        headGroup.add(cranium);

        // ขากรรไกรล่างขยับได้เล็กน้อย
        const lowerJawPivot = new THREE.Group();
        lowerJawPivot.position.set(0, -0.25, 0.2);
        const jawGeo = new THREE.SphereGeometry(0.76, 16, 12);
        jawGeo.scale(0.92, 0.36, 1.15);
        const jawMesh = new THREE.Mesh(jawGeo, headMat);
        jawMesh.position.set(0, 0, 0.28);
        lowerJawPivot.add(jawMesh);
        headGroup.add(lowerJawPivot);

        // ลิ้นงูสองแฉกเล็กๆ
        const tongueGroup = new THREE.Group();
        const tongueMat = new THREE.MeshBasicMaterial({ color: 0xff1744, side: THREE.DoubleSide });
        const tongueStem = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.65), tongueMat);
        tongueStem.position.set(0, -0.18, 1.35);
        tongueGroup.add(tongueStem);
        headGroup.add(tongueGroup);

        // ดวงตาคู่ทรงกลมพร้อมม่านตาคมชัด (ขาวอมเหลืองสว่าง + ตาดำ)
        const scleraGeo = new THREE.SphereGeometry(0.25, 14, 14);
        const scleraMat = new THREE.MeshBasicMaterial({ color: 0xfef9c3 });
        const pupilGeo = new THREE.SphereGeometry(0.13, 10, 10);
        const pupilMat = new THREE.MeshBasicMaterial({ color: 0x090d16 });

        [-0.52, 0.52].forEach(sideX => {
            const eyeWrap = new THREE.Group();
            eyeWrap.position.set(sideX, 0.44, 0.58);
            const sclera = new THREE.Mesh(scleraGeo, scleraMat);
            const pupil = new THREE.Mesh(pupilGeo, pupilMat);
            pupil.position.set(sideX * 0.08, 0.04, 0.16);
            eyeWrap.add(sclera);
            eyeWrap.add(pupil);
            headGroup.add(eyeWrap);
        });

        snakeGroup.add(headGroup);
        this.boardGroup.add(snakeGroup);

        const badges = [];
        const allowBadges = Boolean(this.badgeConfig?.showBadges) && (this.badgeConfig?.snake?.show !== false);
        if (startTile && endTile && headPos && tailPos) {
            // ป้าย Hologram เตือนภัยที่หัวงู (ทางสไลด์ลง ⬇️)
            const headBadge = this.createHologramBadgeSprite('snake_head', startTile, endTile);
            headBadge.position.set(headPos.x, (headPos.y || 0) + 4.8, headPos.z);
            headBadge.visible = allowBadges;
            this.boardGroup.add(headBadge);
            badges.push(headBadge);

            // ป้าย Hologram ที่ปลายหางงู (จุดร่วงลง 💧)
            const tailBadge = this.createHologramBadgeSprite('snake_tail', startTile, endTile);
            tailBadge.position.set(tailPos.x, (tailPos.y || 0) + 2.5, tailPos.z);
            tailBadge.visible = allowBadges;
            this.boardGroup.add(tailBadge);
            badges.push(tailBadge);
        }

        if (startTile) {
            this.snakeObjects[startTile] = {
                group: snakeGroup,
                curve,
                headGroup,
                headPos: headPos.clone(),
                lowerJawPivot,
                tongueGroup,
                phaseOffset: startTile * 0.65,
                isAnimating: false,
                badges
            };
        }
    }

    disposeHierarchy(node) {
        if (!node) return;
        node.traverse(child => {
            if (child.isMesh) {
                if (child.geometry) child.geometry.dispose();
                if (child.material) {
                    if (Array.isArray(child.material)) {
                        child.material.forEach(m => m && m.dispose && m.dispose());
                    } else if (child.material.dispose) {
                        child.material.dispose();
                    }
                }
            }
        });
    }

    generateRandomBoardLinks(reservedTiles = new Set()) {
        const usedTiles = new Set(reservedTiles);
        usedTiles.add(1);
        usedTiles.add(100);

        const ladders = {};
        const snakes = {};

        function pickRandomTile(min, max) {
            const available = [];
            for (let i = min; i <= max; i++) {
                if (!usedTiles.has(i)) available.push(i);
            }
            if (available.length === 0) return null;
            return available[Math.floor(Math.random() * available.length)];
        }

        // 1. สุ่มบันได 7-8 จุด กระจายตัวสม่ำเสมอทุกช่วงความสูงของกระดาน
        const ladderSpecs = [
            { minS: 3, maxS: 12, minClimb: 10, maxClimb: 22 },
            { minS: 14, maxS: 24, minClimb: 12, maxClimb: 25 },
            { minS: 22, maxS: 36, minClimb: 15, maxClimb: 32 },
            { minS: 32, maxS: 48, minClimb: 16, maxClimb: 38 },
            { minS: 44, maxS: 58, minClimb: 14, maxClimb: 28 },
            { minS: 55, maxS: 68, minClimb: 12, maxClimb: 24 },
            { minS: 66, maxS: 78, minClimb: 10, maxClimb: 20 },
            { minS: 78, maxS: 88, minClimb: 5, maxClimb: 10 }
        ];

        for (const spec of ladderSpecs) {
            const s = pickRandomTile(spec.minS, spec.maxS);
            if (!s) continue;
            usedTiles.add(s);

            const minEnd = Math.min(98, s + spec.minClimb);
            const maxEnd = Math.min(98, s + spec.maxClimb);
            const e = pickRandomTile(minEnd, maxEnd);
            if (!e) {
                usedTiles.delete(s);
                continue;
            }
            usedTiles.add(e);
            ladders[s] = e;
        }

        // 2. สุ่มงู 7-8 ตัว กระจายตัวจากช่วงบนลงมาช่วงล่าง
        const snakeSpecs = [
            { minH: 93, maxH: 99, minDrop: 20, maxDrop: 50 },
            { minH: 84, maxH: 94, minDrop: 18, maxDrop: 42 },
            { minH: 74, maxH: 86, minDrop: 16, maxDrop: 36 },
            { minH: 63, maxH: 75, minDrop: 14, maxDrop: 32 },
            { minH: 52, maxH: 64, minDrop: 12, maxDrop: 26 },
            { minH: 40, maxH: 53, minDrop: 12, maxDrop: 22 },
            { minH: 27, maxH: 40, minDrop: 10, maxDrop: 18 },
            { minH: 16, maxH: 26, minDrop: 6, maxDrop: 12 }
        ];

        for (const spec of snakeSpecs) {
            const h = pickRandomTile(spec.minH, spec.maxH);
            if (!h) continue;
            usedTiles.add(h);

            const minTail = Math.max(2, h - spec.maxDrop);
            const maxTail = Math.max(2, h - spec.minDrop);
            const t = pickRandomTile(minTail, maxTail);
            if (!t) {
                usedTiles.delete(h);
                continue;
            }
            usedTiles.add(t);
            snakes[h] = t;
        }

        return { ladders, snakes };
    }

    randomizeAndRelocateSnakesAndLadders(forceAll = false) {
        if (!this.boardGroup || !this.tiles) return;

        // ตรวจสอบว่ามีบันไดและงูอยู่บนกระดานแล้วหรือไม่
        const hasExistingLadders = this.ladderObjects && Object.keys(this.ladderObjects).length > 0;
        const hasExistingSnakes = this.snakeObjects && Object.keys(this.snakeObjects).length > 0;

        // หากยังไม่มีบันไดหรืองูอยู่เลย หรือกำหนด forceAll ให้สร้างใหม่ทั้งหมด
        if ((!hasExistingLadders && !hasExistingSnakes) || forceAll) {
            this.rebuildAllSnakesAndLadders();
            return;
        }

        // ⭐ ตามความต้องการของผู้เล่น: สุ่มย้ายงูกับบันได 2 อัน (บันได 1 อัน และงู 1 ตัว) ก่อนการทอยแต่ละรอบ
        this.relocateSingleRandomBoardLink('LADDER');
        this.relocateSingleRandomBoardLink('SNAKE');
        this.updateAllTileElevations();
    }

    /**
     * สุ่มย้ายตำแหน่งบันได หรืองู 1 อัน ต่อการเรียก
     */
    relocateSingleRandomBoardLink(preferredType = null) {
        if (!this.boardGroup || !this.tiles) return;

        const ladderPalette = [
            0xffd700, // ทองคำราชันย์ (Royal Gold)
            0x00e5ff, // นีออนไซเบอร์ฟ้า (Cyber Cyan)
            0xf43f5e, // ทับทิมกุหลาบ (Ruby Rose)
            0xa855f7, // อเมทิสต์ม่วง (Violet)
            0xffffff, // ไดมอนด์แพลทินัม (Diamond Platinum)
            0x10b981, // หยกมรกต (Emerald)
            0xfb923c, // ส้มทองสุริยัน (Solar Orange)
            0x38bdf8  // สกายบลูประกาย (Sky Blue)
        ];

        const snakePalette = [
            0x10b981, // มรกตเขียวมังกร (Emerald Dragon)
            0xef4444, // อสรพิษเพลิงแดง (Crimson Fire)
            0x0284c7, // พญานาคราชฟ้าคราม (Sapphire Cyan)
            0x9333ea, // อสรพิษอเมทิสต์ม่วง (Amethyst Purple)
            0xf59e0b, // งูหลามทองคำอำพัน (Golden Amber)
            0x14b8a6, // เทอร์ควอยซ์นีออน (Neon Teal)
            0xec4899, // พิษพิงค์ไดมอนด์ (Hot Pink Mamba)
            0x6366f1  // อสรพิษอินดิโก้ (Indigo Viper)
        ];

        if (!this.ladders) this.ladders = {};
        if (!this.snakes) this.snakes = {};
        if (!this.ladderObjects) this.ladderObjects = {};
        if (!this.snakeObjects) this.snakeObjects = {};
        if (!this.snakeTailToHead) this.snakeTailToHead = {};

        const ladderKeys = Object.keys(this.ladders).map(Number);
        const snakeKeys = Object.keys(this.snakes).map(Number);

        if (ladderKeys.length === 0 && snakeKeys.length === 0) {
            this.rebuildAllSnakesAndLadders();
            return;
        }

        // สุ่มเลือกชนิดที่จะย้าย: บันได หรืองู
        let targetType = preferredType;
        if (!targetType) {
            if (ladderKeys.length > 0 && snakeKeys.length > 0) {
                targetType = Math.random() < 0.5 ? 'LADDER' : 'SNAKE';
            } else if (snakeKeys.length > 0) {
                targetType = 'SNAKE';
            } else {
                targetType = 'LADDER';
            }
        }
        if (targetType === 'LADDER' && ladderKeys.length === 0 && snakeKeys.length > 0) {
            targetType = 'SNAKE';
        }
        if (targetType === 'SNAKE' && snakeKeys.length === 0 && ladderKeys.length > 0) {
            targetType = 'LADDER';
        }

        // 1. รวมช่องห้ามวางทับ (คุก, จุดสตาร์ท, เส้นชัย, ช่องพิเศษ, ตำแหน่งผู้เล่นปัจจุบัน)
        const usedTiles = new Set([
            this.jailTile || 10,
            1, 100,
            ...(this.chanceTiles || []),
            ...(this.taxTiles || []),
            ...(this.gambleTiles || []),
            ...(this.destroyTiles || []),
            ...(this.players ? this.players.map(p => p.currentTile) : [])
        ]);

        if (targetType === 'LADDER') {
            // เลือกบันได 1 อันแบบสุ่มเพื่อย้าย
            const oldStart = ladderKeys[Math.floor(Math.random() * ladderKeys.length)];
            const oldEnd = this.ladders[oldStart];

            // ถอดบันไดเก่าออก
            if (this.ladderObjects[oldStart]) {
                const obj = this.ladderObjects[oldStart];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
                delete this.ladderObjects[oldStart];
            }
            delete this.ladders[oldStart];

            // รวบรวมตำแหน่งที่บันไดอื่นและงูทั้งหมดใช้อยู่
            for (const [s, e] of Object.entries(this.ladders)) {
                usedTiles.add(Number(s));
                usedTiles.add(Number(e));
            }
            for (const [h, t] of Object.entries(this.snakes)) {
                usedTiles.add(Number(h));
                usedTiles.add(Number(t));
            }

            // สุ่มหาตำแหน่งบันไดใหม่ (จุดเริ่ม 3-82, ไต่ขึ้น 8-32 ช่อง)
            let newStart = null;
            let newEnd = null;
            const ladderCandidateSpecs = [
                { minS: 3, maxS: 18, minClimb: 10, maxClimb: 24 },
                { minS: 18, maxS: 38, minClimb: 14, maxClimb: 30 },
                { minS: 35, maxS: 58, minClimb: 12, maxClimb: 26 },
                { minS: 55, maxS: 78, minClimb: 10, maxClimb: 20 },
                { minS: 75, maxS: 86, minClimb: 5, maxClimb: 10 }
            ].sort(() => Math.random() - 0.5);

            for (const spec of ladderCandidateSpecs) {
                for (let attempt = 0; attempt < 20; attempt++) {
                    const s = spec.minS + Math.floor(Math.random() * (spec.maxS - spec.minS + 1));
                    if (usedTiles.has(s) || !this.tiles[s]) continue;
                    const climb = spec.minClimb + Math.floor(Math.random() * (spec.maxClimb - spec.minClimb + 1));
                    const e = s + climb;
                    if (e <= 98 && !usedTiles.has(e) && this.tiles[e]) {
                        newStart = s;
                        newEnd = e;
                        break;
                    }
                }
                if (newStart && newEnd) break;
            }

            if (!newStart || !newEnd) {
                newStart = oldStart;
                newEnd = oldEnd;
            }

            // บันทึกและสร้างบันได 3D ใหม่เพียง 1 ตัว
            this.ladders[newStart] = newEnd;
            this.updateAllTileElevations();
            const color = ladderPalette[Math.floor(Math.random() * ladderPalette.length)];
            this.create3DLadder(this.tiles[newStart], this.tiles[newEnd], color, newStart, newEnd);

            if (this.ladderObjects[newStart] && this.ladderObjects[newStart].group) {
                const grp = this.ladderObjects[newStart].group;
                grp.scale.set(0.1, 0.1, 0.1);
                const startTime = performance.now();
                const animateScale = () => {
                    const ladderElapsed = performance.now() - startTime;
                    const progress = Math.min(1, ladderElapsed / 280);
                    const scale = progress >= 1 ? 1 : (1 + 1.2 * Math.pow(progress - 1, 3) + 0.8 * Math.pow(progress - 1, 2));
                    if (grp && grp.scale) grp.scale.set(scale, scale, scale);
                    if (progress < 1) requestAnimationFrame(animateScale);
                };
                requestAnimationFrame(animateScale);
            }

            if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
                window.soundEngine.playWarp();
            }
            this.logMessage(`🪜 บันไดเคลื่อนย้ายสลับที่! (เดิมช่อง ${oldStart} ➔ ย้ายมาช่อง ${newStart} ไต่ขึ้น ${newEnd})`, 'highlight');
        } else {
            // เลือกงู 1 ตัวแบบสุ่มเพื่อย้าย
            const oldHead = snakeKeys[Math.floor(Math.random() * snakeKeys.length)];
            const oldTail = this.snakes[oldHead];

            // ถอดงูเก่าออก
            if (this.snakeObjects[oldHead]) {
                const obj = this.snakeObjects[oldHead];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
                delete this.snakeObjects[oldHead];
            }
            delete this.snakes[oldHead];
            if (this.snakeTailToHead && this.snakeTailToHead[oldTail] === oldHead) {
                delete this.snakeTailToHead[oldTail];
            }

            // รวบรวมตำแหน่งที่บันไดทั้งหมดและงูอื่นใช้อยู่
            for (const [s, e] of Object.entries(this.ladders)) {
                usedTiles.add(Number(s));
                usedTiles.add(Number(e));
            }
            for (const [h, t] of Object.entries(this.snakes)) {
                usedTiles.add(Number(h));
                usedTiles.add(Number(t));
            }

            // สุ่มหาตำแหน่งงูใหม่ (หัว 18-98, ร่วงลง 8-38 ช่อง)
            let newHead = null;
            let newTail = null;
            const snakeCandidateSpecs = [
                { minH: 85, maxH: 98, minDrop: 20, maxDrop: 45 },
                { minH: 68, maxH: 86, minDrop: 16, maxDrop: 36 },
                { minH: 48, maxH: 70, minDrop: 14, maxDrop: 30 },
                { minH: 30, maxH: 52, minDrop: 12, maxDrop: 24 },
                { minH: 16, maxH: 32, minDrop: 6, maxDrop: 14 }
            ].sort(() => Math.random() - 0.5);

            for (const spec of snakeCandidateSpecs) {
                for (let attempt = 0; attempt < 20; attempt++) {
                    const h = spec.minH + Math.floor(Math.random() * (spec.maxH - spec.minH + 1));
                    if (usedTiles.has(h) || !this.tiles[h]) continue;
                    const drop = spec.minDrop + Math.floor(Math.random() * (spec.maxDrop - spec.minDrop + 1));
                    const t = h - drop;
                    if (t >= 2 && !usedTiles.has(t) && this.tiles[t]) {
                        newHead = h;
                        newTail = t;
                        break;
                    }
                }
                if (newHead && newTail) break;
            }

            if (!newHead || !newTail) {
                newHead = oldHead;
                newTail = oldTail;
            }

            // บันทึกและสร้างงู 3D ใหม่เพียง 1 ตัว
            this.snakes[newHead] = newTail;
            this.updateAllTileElevations();
            const color = snakePalette[Math.floor(Math.random() * snakePalette.length)];
            this.create3DSnake(this.tiles[newHead], this.tiles[newTail], color, newHead, newTail);

            if (this.snakeObjects[newHead] && this.snakeObjects[newHead].group) {
                const grp = this.snakeObjects[newHead].group;
                grp.scale.set(0.1, 0.1, 0.1);
                const startTime = performance.now();
                const animateScale = () => {
                    const snakeElapsed = performance.now() - startTime;
                    const progress = Math.min(1, snakeElapsed / 280);
                    const scale = progress >= 1 ? 1 : (1 + 1.2 * Math.pow(progress - 1, 3) + 0.8 * Math.pow(progress - 1, 2));
                    if (grp && grp.scale) grp.scale.set(scale, scale, scale);
                    if (progress < 1) requestAnimationFrame(animateScale);
                };
                requestAnimationFrame(animateScale);
            }

            if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
                window.soundEngine.playWarp();
            }
            this.logMessage(`🐍 อสรพิษเลื้อยสลับจุดใหม่! (เดิมหัวช่อง ${oldHead} ➔ สุ่มย้ายไปหัวช่อง ${newHead} ร่วงลง ${newTail})`, 'highlight');
        }
    }

    /**
     * อัปเดตระดับความสูง Y ของช่องกระดานทั้งหมดตามตำแหน่งบันไดและงู
     * - ปลายทางบันได (พื้นที่ไป) => นูนขึ้น (+1.25)
     * - ปลายทางงู (พื้นที่ลง) => ยุบลงเล็กน้อย (-0.45)
     * - อัปเดตความสูงของเมือง 3D และตัวหมากผู้เล่นที่ยืนอยู่บนช่อง
     */

    /**
     * สร้าง Texture แสงออร่าเรืองแสงสำหรับช่องที่นูนขึ้น (ปลายทางบันได / เมืองนูน)
     */
    createElevatedTileAuraTexture() {
        if (this._elevatedTileAuraTex) return this._elevatedTileAuraTex;
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');
        const cx = 128, cy = 128;

        const radGrad = ctx.createRadialGradient(cx, cy, 25, cx, cy, 126);
        radGrad.addColorStop(0, 'rgba(52, 211, 153, 0.55)');
        radGrad.addColorStop(0.40, 'rgba(56, 189, 248, 0.42)');
        radGrad.addColorStop(0.72, 'rgba(0, 229, 255, 0.25)');
        radGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = radGrad;
        ctx.fillRect(0, 0, 256, 256);

        ctx.beginPath();
        ctx.arc(cx, cy, 96, 0, Math.PI * 2);
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 4.5;
        ctx.shadowColor = '#00e5ff';
        ctx.shadowBlur = 14;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(cx, cy, 82, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.lineWidth = 2;
        ctx.stroke();

        const tex = new THREE.CanvasTexture(canvas);
        this._elevatedTileAuraTex = tex;
        return tex;
    }

    /**
     * สร้าง Texture พื้นผิวแสดงพื้นที่ของช่องที่ยุบลง (ปลายทางงู / เมืองยุบ - ไม่ต้องมีแสงออร่า แต่แสดงพื้นที่ชัดเจน)
     */
    createDepressedTileFootprintTexture() {
        if (this._depressedTileFootprintTex) return this._depressedTileFootprintTex;
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = 'rgba(76, 5, 25, 0.65)';
        ctx.fillRect(0, 0, 256, 256);

        ctx.strokeStyle = 'rgba(244, 63, 94, 0.45)';
        ctx.lineWidth = 2;
        for (let x = 32; x < 256; x += 32) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, 256);
            ctx.stroke();
        }
        for (let y = 32; y < 256; y += 32) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(256, y);
            ctx.stroke();
        }

        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 9;
        ctx.strokeRect(6, 6, 244, 244);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 2.5;
        ctx.strokeRect(14, 14, 228, 228);

        const tex = new THREE.CanvasTexture(canvas);
        this._depressedTileFootprintTex = tex;
        return tex;
    }

    updateAllTileElevations() {
        this.ladderEndToStart = {};
        if (this.ladders) {
            for (const [s, e] of Object.entries(this.ladders)) {
                this.ladderEndToStart[Number(e)] = Number(s);
            }
        }
        this.snakeTailToHead = {};
        if (this.snakes) {
            for (const [h, t] of Object.entries(this.snakes)) {
                this.snakeTailToHead[Number(t)] = Number(h);
            }
        }

        const baseTileH = 0.8;
        const theme = (this.themes && this.themes[this.boardTheme]) || (this.themes && this.themes.ancient) || {};

        for (let i = 1; i <= 100; i++) {
            if (!this.tiles || !this.tiles[i]) continue;
            const isLadderEnd = Boolean(this.ladderEndToStart && this.ladderEndToStart[i]);
            const isSnakeEnd = Boolean(this.snakeTailToHead && this.snakeTailToHead[i]);

            let tileElev = 0;
            if (isLadderEnd) {
                tileElev = 0.30; // นูนขึ้นนิดเดียว (+0.30)
            } else if (isSnakeEnd) {
                tileElev = -0.20; // ยุบลงนิดเดียว (-0.20)
            }

            this.tiles[i].y = tileElev;

            const tileMesh = this.tileMeshes ? this.tileMeshes[i] : null;
            const borderLine = this.tileBorderMeshes ? this.tileBorderMeshes[i] : null;
            const tileH = Math.max(0.35, baseTileH + tileElev);
            const meshPosY = (tileH / 2) - 0.40;

            if (tileMesh) {
                tileMesh.position.y = meshPosY;
                tileMesh.scale.y = tileH / baseTileH;
            }
            if (borderLine) {
                borderLine.position.y = meshPosY;
                borderLine.scale.y = tileH / baseTileH;
                if (borderLine.material && borderLine.material.color) {
                    const isGoal = (i === 100);
                    const isStart = (i === 1);
                    let borderColor = isGoal ? 0x00ffcc : (isStart ? 0x00e5ff : (theme.border || 0xffffff));
                    if (isLadderEnd) borderColor = 0x34d399;
                    else if (isSnakeEnd) borderColor = 0xf43f5e;
                    borderLine.material.color.setHex(borderColor);
                }
            }

            // หากมีเมือง 3D สร้างอยู่บนช่องนี้ ปรับระดับความสูงให้ตั้งอยู่บนพื้นผิวช่องพอดี
            if (this.cityMeshes && this.cityMeshes[i]) {
                this.cityMeshes[i].position.y = tileElev;
            }

            // ผู้ใช้กำหนด: "เมืองที่นูนกับยุบไม่ต้องนูนเยอะนิดเดียวพร้อมแสงเออร่า ส่วนที่ยุบเหมือนกันนิดเดีนวไม่ต้องมีแสงเออร่าแต่ขอแสดงพื้นที่ด้วย"
            // 1) ช่องนูน (ปลายบันได): แสดงแสงออร่าเรืองแสง
            if (isLadderEnd) {
                if (!this.tileElevatedAuraMeshes) this.tileElevatedAuraMeshes = {};
                let auraMesh = this.tileElevatedAuraMeshes[i];
                if (!auraMesh) {
                    const auraTex = this.createElevatedTileAuraTexture();
                    const auraMat = new THREE.MeshBasicMaterial({
                        map: auraTex,
                        transparent: true,
                        opacity: 0.88,
                        depthWrite: false,
                        blending: THREE.AdditiveBlending,
                        side: THREE.DoubleSide
                    });
                    const tSize = (this.tileSize || 4.8);
                    auraMesh = new THREE.Mesh(new THREE.PlaneGeometry(tSize * 0.98, tSize * 0.98), auraMat);
                    auraMesh.rotation.x = -Math.PI / 2;
                    this.boardGroup.add(auraMesh);
                    this.tileElevatedAuraMeshes[i] = auraMesh;
                }
                auraMesh.position.set(this.tiles[i].x, tileElev + 0.415, this.tiles[i].z);
                auraMesh.visible = true;
            } else if (this.tileElevatedAuraMeshes && this.tileElevatedAuraMeshes[i]) {
                this.tileElevatedAuraMeshes[i].visible = false;
            }

            // 2) ช่องยุบ (ปลายงู): ไม่ต้องมีแสงออร่า แต่ขอแสดงพื้นที่ด้วย
            if (isSnakeEnd) {
                if (!this.tileDepressedAreaMeshes) this.tileDepressedAreaMeshes = {};
                let areaMesh = this.tileDepressedAreaMeshes[i];
                if (!areaMesh) {
                    const footTex = this.createDepressedTileFootprintTexture();
                    const footMat = new THREE.MeshBasicMaterial({
                        map: footTex,
                        transparent: true,
                        opacity: 0.88,
                        depthWrite: false,
                        side: THREE.DoubleSide
                    });
                    const tSize = (this.tileSize || 4.8);
                    areaMesh = new THREE.Mesh(new THREE.PlaneGeometry(tSize * 0.94, tSize * 0.94), footMat);
                    areaMesh.rotation.x = -Math.PI / 2;
                    this.boardGroup.add(areaMesh);
                    this.tileDepressedAreaMeshes[i] = areaMesh;
                }
                areaMesh.position.set(this.tiles[i].x, tileElev + 0.405, this.tiles[i].z);
                areaMesh.visible = true;
            } else if (this.tileDepressedAreaMeshes && this.tileDepressedAreaMeshes[i]) {
                this.tileDepressedAreaMeshes[i].visible = false;
            }
        }

        // รีเซ็ตตำแหน่งตัวหมากให้วางบนพื้นผิวช่องตามระดับความสูงใหม่
        if (this.players) {
            this.players.forEach(p => {
                if (p && p.currentTile) {
                    this.realignPawnsOnTile(p.currentTile);
                }
            });
        }
    }

    /**
     * สร้างบันไดและงูชุดเต็มทั้งหมดบนกระดาน (ใช้เมื่อเริ่มเกมครั้งแรกหรือรีเซ็ตกระดาน)
     */
    rebuildAllSnakesAndLadders() {
        if (!this.boardGroup || !this.tiles) return;

        // 1. นำบันได 3D เดิมออกจากกระดานและล้างหน่วยความจำ
        if (this.ladderObjects) {
            for (const k in this.ladderObjects) {
                const obj = this.ladderObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.ladderObjects = {};

        // 2. นำงู 3D เดิมออกจากกระดานและล้างหน่วยความจำ
        if (this.snakeObjects) {
            for (const k in this.snakeObjects) {
                const obj = this.snakeObjects[k];
                if (obj && obj.group) {
                    this.boardGroup.remove(obj.group);
                    this.disposeHierarchy(obj.group);
                }
                if (obj && obj.badges) {
                    obj.badges.forEach(b => {
                        this.boardGroup.remove(b);
                        this.disposeHierarchy(b);
                    });
                }
            }
        }
        this.snakeObjects = {};

        // 3. กำหนดช่องห้ามวางทับ (คุก, ช่องดวง, ภาษี, เสี่ยงโชค, สกิลทำลาย, จุดผู้เล่นยืนอยู่)
        const reserved = new Set([
            this.jailTile || 10,
            ...(this.chanceTiles || []),
            ...(this.taxTiles || []),
            ...(this.gambleTiles || []),
            ...(this.destroyTiles || []),
            ...(this.players ? this.players.map(p => p.currentTile) : [])
        ]);

        // 4. สุ่มคำนวณตำแหน่งช่องใหม่ทั้งหมด
        const { ladders, snakes } = this.generateRandomBoardLinks(reserved);
        this.ladders = ladders;
        this.snakes = snakes;
        this.updateAllTileElevations();

        // 5. สุ่มสีสันสวยงามสดใสให้กับบันไดและงูทุกรอบ
        const ladderPalette = [
            0xffd700, // ทองคำราชันย์ (Royal Gold)
            0x00e5ff, // นีออนไซเบอร์ฟ้า (Cyber Cyan)
            0xf43f5e, // ทับทิมกุหลาบ (Ruby Rose)
            0xa855f7, // อเมทิสต์ม่วง (Violet)
            0xffffff, // ไดมอนด์แพลทินัม (Diamond Platinum)
            0x10b981, // หยกมรกต (Emerald)
            0xfb923c, // ส้มทองสุริยัน (Solar Orange)
            0x38bdf8  // สกายบลูประกาย (Sky Blue)
        ].sort(() => Math.random() - 0.5);

        const snakePalette = [
            0x10b981, // มรกตเขียวมังกร (Emerald Dragon)
            0xef4444, // อสรพิษเพลิงแดง (Crimson Fire)
            0x0284c7, // พญานาคราชฟ้าคราม (Sapphire Cyan)
            0x9333ea, // อสรพิษอเมทิสต์ม่วง (Amethyst Purple)
            0xf59e0b, // งูหลามทองคำอำพัน (Golden Amber)
            0x14b8a6, // เทอร์ควอยซ์นีออน (Neon Teal)
            0xec4899, // พิษพิงค์ไดมอนด์ (Hot Pink Mamba)
            0x6366f1  // อสรพิษอินดิโก้ (Indigo Viper)
        ].sort(() => Math.random() - 0.5);

        const animGroups = [];

        // 6. สร้างบันได 3D ตำแหน่งใหม่พร้อมสีสุ่มสดใส
        let lIdx = 0;
        for (const [start, end] of Object.entries(this.ladders)) {
            const sTile = Number(start);
            const eTile = Number(end);
            if (this.tiles[sTile] && this.tiles[eTile]) {
                const color = ladderPalette[lIdx % ladderPalette.length];
                this.create3DLadder(this.tiles[sTile], this.tiles[eTile], color, sTile, eTile);
                if (this.ladderObjects[sTile] && this.ladderObjects[sTile].group) {
                    this.ladderObjects[sTile].group.scale.set(0.15, 0.15, 0.15);
                    animGroups.push(this.ladderObjects[sTile].group);
                }
                lIdx++;
            }
        }

        // 7. สร้างงู 3D ตำแหน่งใหม่พร้อมสีสุ่มสดใส
        let sIdx = 0;
        for (const [head, tail] of Object.entries(this.snakes)) {
            const hTile = Number(head);
            const tTile = Number(tail);
            if (this.tiles[hTile] && this.tiles[tTile]) {
                const color = snakePalette[sIdx % snakePalette.length];
                this.create3DSnake(this.tiles[hTile], this.tiles[tTile], color, hTile, tTile);
                if (this.snakeObjects[hTile] && this.snakeObjects[hTile].group) {
                    this.snakeObjects[hTile].group.scale.set(0.15, 0.15, 0.15);
                    animGroups.push(this.snakeObjects[hTile].group);
                }
                sIdx++;
            }
        }

        // 8. แอนิเมชัน Pop-In Scale เด้งขยายตัวอย่างนุ่มนวล
        const startTime = performance.now();
        function animateScaleIn() {
            const landmarkElapsed = performance.now() - startTime;
            const progress = Math.min(1, landmarkElapsed / 280);
            const scale = progress >= 1 ? 1 : (1 + 1.2 * Math.pow(progress - 1, 3) + 0.8 * Math.pow(progress - 1, 2));
            animGroups.forEach(g => {
                if (g && g.scale) g.scale.set(scale, scale, scale);
            });
            if (progress < 1) {
                requestAnimationFrame(animateScaleIn);
            }
        }
        requestAnimationFrame(animateScaleIn);

        // 9. เสียงเอฟเฟกต์กาลเวลา & ข้อความแจ้งเตือน
        if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
            window.soundEngine.playWarp();
        }
        this.logMessage('🌀 จัดเตรียมเส้นทางกระดาน 3D: วางงูและบันไดชุดสมบูรณ์เรียบร้อยแล้ว!', 'highlight');
    }

    /**
     * โหมดสแตนด์บายบนหน้าหลัก (ยังไม่ได้กดทดลองเล่น หรือยังไม่ได้เข้าห้องแข่งขัน)
     * แสดงเฉพาะหมากของผู้เล่นที่จุด START (ช่อง 1) โดยไม่เริ่มทอยเองและไม่นับถอยหลังเข้า AUTO
     */
    setupIdlePreview(userProfile = null) {
        // กันการสร้างหมากซ้ำรัว ๆ ช่วงเปิดเกม (ถูกเรียกจากหลายจุดพร้อมกัน ทำให้ GPU memory พุ่งจน WebGL ดับ)
        const _u = userProfile || window.DEFAULT_USER || {};
        const _sig = [_u.id, _u.username, _u.avatar_url || _u.picture || _u.pictureUrl, _u.dice_skin].join('|');
        const _now = Date.now();
        if (!this.isMatchActive && this._lastIdleSig === _sig && this._lastIdleAt && (_now - this._lastIdleAt) < 1500 && this.pawnsGroup && this.pawnsGroup.children.length > 0) {
            return;
        }
        this._lastIdleSig = _sig;
        this._lastIdleAt = _now;
        const reqTiles = this.isMonopolyBoardMode ? 32 : 100;
        if (!this.tiles || this.tiles.length < reqTiles || !this.boardGroup || this.boardGroup.children.length === 0) {
            this.buildBoard();
            if (this.isMonopolyBoardMode && typeof this.setupMonopolySnakesAndLadders === 'function') {
                this.setupMonopolySnakesAndLadders();
            }
        }
        if (typeof window.stopGameplayBgm === 'function') {
            window.stopGameplayBgm();
        }
        if (window.soundEngine && typeof window.soundEngine.startLobbyAmbient === 'function') {
            window.soundEngine.startLobbyAmbient();
        }
        this.clearTurnTimers();
        this.stopMultiplayerSync();
        if (this.matchConfig) {
            this.matchConfig.roomId = null;
        }

        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }
        this.matchTimeRemaining = this.getMatchDurationSeconds ? this.getMatchDurationSeconds() : 600;
        this.matchStartTime = null;
        this.closeCityActionPrompt(null);
        this.clearAllCities3D();
        this.isMatchActive = false;
        this.isGameOver = false;
        this.isRolling = false;
        this.isAutoMode = false;
        this.currentTurnIndex = 0;
        if (this.diceGroup) this.diceGroup.visible = false;
        if (typeof window.showLobbyEquippedShowcase === 'function') {
            setTimeout(() => {
                if (!this.isMatchActive) window.showLobbyEquippedShowcase();
            }, 350);
        }

        while (this.pawnsGroup.children.length > 0) {
            const oldPawn = this.pawnsGroup.children[0];
            this.pawnsGroup.remove(oldPawn);
            try { this.disposeHierarchy(oldPawn); } catch (e) { }
        }
        this.players = [];
        this.updateMatchWealthHUD();

        const u = userProfile || window.DEFAULT_USER || {};
        let myName = u.displayName || u.name || u.username || 'ผู้เล่น';
        if (myName === 'เขียนศักดิ์' || myName === 'Google Player') {
            myName = 'ผู้เล่น';
        }
        const activeAvatar = (typeof window.getActivePlayerAvatarUrl === 'function')
            ? window.getActivePlayerAvatarUrl(u)
            : (u.avatar_url || u.pictureUrl || u.picture || 'avatars/avatar_01.svg');
        const pSkin = u.dice_skin || window.DEFAULT_USER?.dice_skin || 'ClassicWoodDice';
        const pDiceName = u.equipped_dice_name || window.DEFAULT_USER?.equipped_dice_name || 'ลูกเต๋าไม้คลาสสิก 3D';

        const initialGems = (typeof window.getEquippedGemsList === 'function' ? window.getEquippedGemsList() : [])
            || u.equipped_gems
            || window.DEFAULT_USER?.equipped_gems
            || (window.playerGemsData?.equippedSlots ? window.playerGemsData.equippedSlots.filter(Boolean) : []);

        const pData = {
            id: u.id || 1,
            username: myName,
            auth_provider: u.auth_provider || 'guest',
            picture: activeAvatar,
            pictureUrl: activeAvatar,
            avatar_url: activeAvatar,
            character_grade: u.character_grade || window.DEFAULT_USER?.character_grade || 'SS+',
            equipped_gems: initialGems,
            equippedGems: initialGems,
            team: 'NONE',
            team_name: '',
            color: 0x00e5ff,
            is_bot: false,
            is_awakened: true,
            dice_skin: pSkin,
            dice_name: pDiceName,
            skill: { code: 'PULL_BACK_8', power: 8 },
            dice_control_rate: 35
        };

        const pawnGroup = this.createPawnMesh(0x00e5ff, true, pData);
        this.pawnsGroup.add(pawnGroup);

        const playerObj = {
            ...pData,
            mesh: pawnGroup,
            currentTile: 1,
            isAwakened: true,
            jailTurns: 0,
            consecutiveDoubles: 0,
            equippedGems: initialGems,
            shieldLayers: 0
        };
        this.setPawnPosition(playerObj, 1, 0);
        this.showLandingPin(1);

        const syncRoomId = Number(this.matchConfig?.roomId || window.currentRoomId || 0);
        if (syncRoomId > 0 && this.isMonopolyBoardMode) {
            if (typeof this.relocateMonopolySnakesAndLadders === 'function') {
                this.relocateMonopolySnakesAndLadders(false, this.createSeededRng(syncRoomId * 131 + 17));
            }
            if (typeof this.relocateMonopolyStageHazards === 'function') {
                this.relocateMonopolyStageHazards(false, this.createSeededRng(syncRoomId * 131 + 31));
            }
        }
        this.players.push(playerObj);
        this.rebuildSideGems3D(pawnGroup, playerObj.equippedGems);
        if (playerObj.equippedGems && playerObj.equippedGems.length > 0) {
            this.rebuildGemOrbit3D(playerObj);
        }
        this.applyDiceSkinForPlayer(playerObj);

        const feed = document.getElementById('log-feed');
        if (feed) feed.innerHTML = '';
        this.logMessage('✨ พร้อมเริ่มเล่น! เลือก "ห้องแข่งขัน" หรือกดปุ่ม "ทดลองเล่น" เพื่อเริ่มเกม', 'highlight');

        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            rollBtn.disabled = false;
            rollBtn.classList.remove('auto-active');
            rollBtn.style.opacity = '1';
            rollBtn.innerHTML = `<span>🎲</span> ทอย`;
        }

        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }
        this.updateCameraFit(false);
    }

    isLocalHostPlayer() {
        const localIdx = this.getLocalPlayerIndex();
        const firstHumanIdx = (this.players || []).findIndex(p => p && !p.is_bot);
        return localIdx !== -1 && localIdx === firstHumanIdx;
    }

    isMultiplayerSyncMatch() {
        const rId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
        if (!this.isMatchActive || window.isPracticeMatch || !(rId > 0)) return false;
        return (this.players || []).filter(p => p && !p.is_bot).length >= 2;
    }

    buildMultiplayerStateSnapshot() {
        return {
            currentTurnIndex: this.currentTurnIndex,
            consecutiveDoubles: this.consecutiveDoubles || 0,
            matchTimeRemaining: this.matchTimeRemaining,
            cityStates: this.cityStates || {},
            ladders: { ...(this.ladders || {}) },
            snakes: { ...(this.snakes || {}) },
            blackHoleTiles: Array.isArray(this.monopolyBlackHoleTiles) ? [...this.monopolyBlackHoleTiles] : [],
            fogTiles: Array.isArray(this.monopolyFogTiles) ? [...this.monopolyFogTiles] : [],
            players: (this.players || []).map(p => ({
                id: p.id,
                user_id: p.user_id || p.id,
                currentTile: Number(p.currentTile || 1),
                matchGold: Number(p.matchGold || 0),
                jailTurns: Number(p.jailTurns || 0),
                consecutiveDoubles: Number(p.consecutiveDoubles || 0),
                totalRollsCount: Number(p.totalRollsCount || 0),
                isBankrupt: Boolean(p.isBankrupt)
            }))
        };
    }

    updateSyncDebugBadge(extra) {
        try {
            const showBadge = Boolean(
                window.__SYNC_DEBUG === true ||
                localStorage.getItem('snake_sync_debug') === '1'
            );
            if (!showBadge) {
                const old = document.getElementById('sync-debug-badge');
                if (old) old.remove();
                return;
            }
            let el = document.getElementById('sync-debug-badge');
            if (!el) {
                el = document.createElement('div');
                el.id = 'sync-debug-badge';
                el.style.cssText = 'position:fixed;left:6px;bottom:4px;z-index:99999;font:10px monospace;color:#0f0;background:rgba(0,0,0,.55);padding:2px 5px;border-radius:4px;pointer-events:none;opacity:0.8;';
                document.body.appendChild(el);
            }
            const st = this._syncStats || (this._syncStats = { sent: 0, recv: 0, err: 0 });
            const ver = window.__GAME_OTA_VERSION__ || 'local';
            el.textContent = `SYNC v${ver} r${window.currentRoomId} seq${this._syncLastSeq || 0} tx${st.sent} rx${st.recv} er${st.err} pk${st.pollOk || 0}/${st.pollFail || 0} t${this.currentTurnIndex} ${this._syncState || 'NOSTART'}${extra ? ' ' + extra : ''}`;
        } catch (e) { }
    }

    async pushMultiplayerSyncEvent(eventType, payload) {
        const roomId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
        if (!(roomId > 0)) return;
        const st = this._syncStats || (this._syncStats = { sent: 0, recv: 0, err: 0 });
        try {
            const tok = (window.apiClient && (typeof window.apiClient.getToken === 'function' ? window.apiClient.getToken() : window.apiClient.token)) || localStorage.getItem('snake_auth_token') || '';
            const bUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
            const myId = Number(window.DEFAULT_USER?.id || 0);
            const r = await fetch(`${bUrl}api/match_sync.php?action=push_event`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...(tok ? { 'Authorization': 'Bearer ' + tok } : {})
                },
                body: JSON.stringify({
                    room_id: roomId,
                    user_id: myId,
                    event_type: eventType,
                    payload: payload || {}
                })
            }).then(x => x.json());
            if (r && r.status === 'success') st.sent++; else st.err++;
        } catch (e) { st.err++; }
        this.updateSyncDebugBadge();
    }

    ensureMultiplayerSync() {
        if (this._syncPollInterval) return;
        if (!this.isMatchActive || this.isGameOver) {
            this._syncState = `IDLE act=${this.isMatchActive ? 1 : 0} over=${this.isGameOver ? 1 : 0}`;
            this.updateSyncDebugBadge();
            return;
        }
        if (!this.isMultiplayerSyncMatch()) {
            const rId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
            this._syncState = `WAIT rid=${rId} prac=${window.isPracticeMatch ? 1 : 0} hum=${(this.players || []).filter(p => p && !p.is_bot).length}`;
            this.updateSyncDebugBadge();
            return;
        }
        this.startMultiplayerSync();
    }

    startMultiplayerSync() {
        this.stopMultiplayerSync();
        if (!this.isMultiplayerSyncMatch()) {
            const rId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
            const humans = (this.players || []).filter(p => p && !p.is_bot).length;
            const remoteHumans = (this.players || []).filter(p => p && !p.is_bot && !this.isLocalPlayer(p)).length;
            this._syncState = `OFF rid=${rId} prac=${window.isPracticeMatch ? 1 : 0} hum=${humans} rem=${remoteHumans} act=${this.isMatchActive ? 1 : 0}`;
            this.updateSyncDebugBadge();
            return;
        }
        this._syncState = `ON hum=${(this.players || []).filter(p => p && !p.is_bot).length} me=${this.getLocalPlayerIndex()}`;
        this.updateSyncDebugBadge();
        this._syncLastSeq = 0;
        this._syncSeenSeqs = new Set();
        this._pendingSyncStates = [];
        this._syncEventQueue = [];
        this._isApplyingRemoteAction = false;
        this._remoteRollMeta = null;
        this.pollMultiplayerSync();
        this._syncPollInterval = setInterval(() => this.pollMultiplayerSync(), 700);
    }

    stopMultiplayerSync() {
        if (this._syncPollInterval) {
            clearInterval(this._syncPollInterval);
            this._syncPollInterval = null;
        }
        if (this._remoteWaitTimeout) {
            clearTimeout(this._remoteWaitTimeout);
            this._remoteWaitTimeout = null;
        }
        this._syncPollInFlight = false;
        this._isApplyingRemoteAction = false;
        this._syncEventQueue = [];
        this._remoteRollMeta = null;
        try {
            const oldBadge = document.getElementById('sync-debug-badge');
            if (oldBadge) oldBadge.remove();
        } catch (e) { }
    }

    async pollMultiplayerSync() {
        if (!this.isMatchActive || this.isGameOver || this._syncPollInFlight) return;
        const roomId = Number(window.currentRoomId || this.matchConfig?.roomId || 0);
        if (!(roomId > 0)) return;

        this._syncPollInFlight = true;
        try {
            const bUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
            const stp = this._syncStats || (this._syncStats = { sent: 0, recv: 0, err: 0 });
            const ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            const abortTimer = ctrl ? setTimeout(() => ctrl.abort(), 6000) : null;
            const res = await fetch(`${bUrl}api/match_sync.php?action=poll&room_id=${roomId}&after_seq=${this._syncLastSeq || 0}&_=${Date.now()}`, {
                cache: 'no-store',
                ...(ctrl ? { signal: ctrl.signal } : {})
            })
                .then(r => r.json())
                .catch(() => null);
            if (abortTimer) clearTimeout(abortTimer);
            if (!res || res.status !== 'success' || !Array.isArray(res.events)) {
                stp.pollFail = (stp.pollFail || 0) + 1;
                this.updateSyncDebugBadge();
                return;
            }
            stp.pollOk = (stp.pollOk || 0) + 1;

            const myId = Number(window.DEFAULT_USER?.id || 0);
            this._syncEventQueue = this._syncEventQueue || [];
            for (const ev of res.events) {
                const seq = Number(ev.seq || 0);
                if (seq > (this._syncLastSeq || 0)) this._syncLastSeq = seq;
                if (this._syncSeenSeqs && this._syncSeenSeqs.has(seq)) continue;
                if (this._syncSeenSeqs) this._syncSeenSeqs.add(seq);

                // ข้าม event ที่เครื่องเราเป็นคนส่งเอง
                if (myId > 0 && Number(ev.user_id) === myId) continue;

                const evType = String(ev.event_type || '').toUpperCase();
                const payload = ev.payload || {};
                if (evType === 'ROLL' || evType === 'STATE') {
                    this._syncEventQueue.push({ type: evType, payload });
                    (this._syncStats || (this._syncStats = { sent: 0, recv: 0, err: 0 })).recv++;
                }
            }
            this.updateSyncDebugBadge();
            this.processMultiplayerSyncQueue();
        } finally {
            this._syncPollInFlight = false;
        }
    }

    processMultiplayerSyncQueue() {
        if (!this.isMatchActive || this.isGameOver) return;
        if (this.isRolling || this._isApplyingRemoteAction) return;
        if (!Array.isArray(this._syncEventQueue) || this._syncEventQueue.length === 0) return;

        while (this._syncEventQueue.length > 0 && !this.isRolling && !this._isApplyingRemoteAction) {
            const ev = this._syncEventQueue.shift();
            if (!ev) continue;
            const payload = ev.payload || {};
            if (ev.type === 'ROLL') {
                const pIdx = Number(payload.playerIndex);
                const targetPlayer = Array.isArray(this.players) ? this.players[pIdx] : null;
                if (!targetPlayer || this.isLocalPlayer(targetPlayer)) {
                    continue;
                }
                if (this.currentTurnIndex !== pIdx) {
                    const retries = Number(ev._retryCount || 0);
                    if (retries < 12) {
                        ev._retryCount = retries + 1;
                        this._syncEventQueue.unshift(ev);
                        setTimeout(() => {
                            if (typeof this.processMultiplayerSyncQueue === 'function') {
                                this.processMultiplayerSyncQueue();
                            }
                        }, 250);
                        break;
                    }
                    continue;
                }
                if (payload.ladders && payload.snakes && typeof this.applySyncedSnakesAndLadders === 'function') {
                    this.applySyncedSnakesAndLadders(payload.ladders, payload.snakes);
                }
                if ((payload.blackHoleTiles || payload.fogTiles) && typeof this.applySyncedMonopolyHazards === 'function') {
                    this.applySyncedMonopolyHazards(payload.blackHoleTiles, payload.fogTiles);
                }
                this._isApplyingRemoteAction = true;
                this._activeRemoteRollEvent = ev;
                this._remoteRollMeta = {
                    ladders: payload.ladders || null,
                    snakes: payload.snakes || null,
                    blackHoleTiles: payload.blackHoleTiles || null,
                    fogTiles: payload.fogTiles || null,
                    goBackward: Boolean(payload.goBackward)
                };
                this.rollDice([Number(payload.d1) || 1, Number(payload.d2) || 1], Boolean(payload.isAuto));
                break;
            } else if (ev.type === 'STATE') {
                this.applyRemoteStateSnapshot(payload);
            }
        }
    }

    applyRemoteStateSnapshot(snap) {
        if (!snap || !this.isMatchActive || this.isGameOver) return;
        this._isApplyingRemoteAction = false;
        this._activeRemoteRollEvent = null;
        this._remoteRollMeta = null;
        if (this._remoteWaitTimeout) {
            clearTimeout(this._remoteWaitTimeout);
            this._remoteWaitTimeout = null;
        }

        if (snap.ladders && snap.snakes && typeof this.applySyncedSnakesAndLadders === 'function') {
            this.applySyncedSnakesAndLadders(snap.ladders, snap.snakes);
        }
        if ((snap.blackHoleTiles || snap.fogTiles) && typeof this.applySyncedMonopolyHazards === 'function') {
            this.applySyncedMonopolyHazards(snap.blackHoleTiles, snap.fogTiles);
        }

        if (snap.cityStates && typeof snap.cityStates === 'object') {
            this.cityStates = snap.cityStates;
            if (typeof this.rebuildAllCities3D === 'function') {
                this.rebuildAllCities3D();
            }
        }

        if (Array.isArray(snap.players) && Array.isArray(this.players)) {
            snap.players.forEach((sp, i) => {
                const lp = this.players[i];
                if (!lp) return;
                const prevTile = Number(lp.currentTile || 1);
                const targetTile = Number(sp.currentTile || 1);
                const tileChanged = prevTile !== targetTile;
                lp.currentTile = targetTile;
                lp.matchGold = Number(sp.matchGold ?? lp.matchGold);
                lp.jailTurns = Number(sp.jailTurns ?? 0);
                lp.consecutiveDoubles = Number(sp.consecutiveDoubles ?? 0);
                if (sp.totalRollsCount !== undefined) {
                    lp.totalRollsCount = Number(sp.totalRollsCount || 0);
                    if (typeof this.createOrUpdatePawnShieldVisual === 'function') {
                        this.createOrUpdatePawnShieldVisual(lp);
                    }
                }
                lp.isBankrupt = Boolean(sp.isBankrupt);
                if (tileChanged && typeof this.realignPawnsOnTile === 'function') {
                    this.realignPawnsOnTile(prevTile);
                    this.realignPawnsOnTile(targetTile);
                }
            });
        }

        if (typeof snap.currentTurnIndex === 'number' && snap.currentTurnIndex >= 0 && snap.currentTurnIndex < this.players.length) {
            this.currentTurnIndex = snap.currentTurnIndex;
        }
        if (typeof snap.consecutiveDoubles === 'number') {
            this.consecutiveDoubles = snap.consecutiveDoubles;
        }
        if (typeof this.updateMatchWealthHUD === 'function') {
            this.updateMatchWealthHUD();
        }

        if (snap.winnerIndex !== null && snap.winnerIndex !== undefined && this.players[snap.winnerIndex] && !this.isGameOver) {
            this._isApplyingRemoteAction = true;
            this.handleVictory(this.players[snap.winnerIndex], snap.winReason || 'BANKRUPTCY');
            this._isApplyingRemoteAction = false;
            return;
        }

        this.beginTurn();
    }

    isLocalPlayer(player) {
        if (!player) return false;
        if (player.is_bot) return false;
        if (player.is_local_user !== undefined) return Boolean(player.is_local_user);
        const myId = window.DEFAULT_USER?.id;
        if (myId !== undefined && myId !== null && (String(player.id) === String(myId) || String(player.user_id) === String(myId))) {
            return true;
        }
        if (window.DEFAULT_USER?.username && player.username === window.DEFAULT_USER.username) {
            return true;
        }
        const firstHuman = (this.players || []).find(p => !p.is_bot);
        return Boolean(firstHuman && player === firstHuman);
    }

    getLocalPlayerIndex() {
        if (!this.players || this.players.length === 0) return -1;
        const idx = this.players.findIndex(p => this.isLocalPlayer(p));
        if (idx !== -1) return idx;
        return this.players.findIndex(p => !p.is_bot);
    }

    setupPlayers(playersData, options = {}) {
        if (typeof window.hideLobbyEquippedShowcase === 'function') {
            window.hideLobbyEquippedShowcase();
        }
        this.closeCityActionPrompt(null);
        this.clearAllCities3D();
        this._tripleColorVictoryTriggered = false;
        this._lineMonopolyTriggered = false;
        this._lastMonopolyVictoryWarnKey = null;
        this.clearMonopolyColorVictoryAura();

        const incomingCfg = options.roomConfig
            || (typeof window.getActiveRoomEconomyConfig === 'function' ? window.getActiveRoomEconomyConfig() : null)
            || {};
        this.matchConfig = {
            room_tier: incomingCfg.room_tier || (window.isPracticeMatch ? 'PRACTICE' : '2M'),
            entry_fee_gold: Number(incomingCfg.entry_fee_gold ?? 2000),
            start_match_gold: Number(incomingCfg.start_match_gold ?? 2000000),
            tax_amount: Number(incomingCfg.tax_amount ?? 50000),
            tax_percent: Number(incomingCfg.tax_percent ?? 20),
            city_base_cost: Number(incomingCfg.city_base_cost ?? 120000),
            landmark_cost: Number(incomingCfg.landmark_cost ?? 320000),
            toll_percent: Number(incomingCfg.toll_percent ?? 85),
            buyout_percent: Number(incomingCfg.buyout_percent ?? 160),
            gameMode: options.gameMode || window.currentActiveGameMode || '2P',
            roomId: options.roomId || window.currentRoomId || null
        };

        if (options.roomId) {
            window.currentRoomId = options.roomId;
        } else if (!window.isPracticeMatch && !window.currentRoomId) {
            window.currentRoomId = 'room_' + Date.now();
            this.matchConfig.roomId = window.currentRoomId;
        }
        if (options.gameMode) {
            window.currentActiveGameMode = options.gameMode;
        }

        const targetMode = options.gameMode || window.currentActiveGameMode || this.matchConfig?.gameMode || '2P';
        const expectedCount = (targetMode === '2P') ? 2 : ((targetMode === '3P') ? 3 : 4);

        let safePlayersData = Array.isArray(playersData) ? [...playersData] : [];
        if (safePlayersData.length < expectedCount) {
            const missing = expectedCount - safePlayersData.length;
            const used = safePlayersData.map(p => p.username || '');
            const extras = (typeof window.pickUniqueOpponentProfiles === 'function')
                ? window.pickUniqueOpponentProfiles(missing, used)
                : [];
            const isTeam = (targetMode === 'TEAM');
            for (let i = 0; i < missing; i++) {
                const prof = extras[i] || { username: `คู่แข่ง #${safePlayersData.length + 1}`, avatar_url: 'avatars/google_avatar.png' };
                const pIdx = safePlayersData.length;
                const bGrade = prof.char_grade || (typeof window.getRandomBotCardGrade === 'function' ? window.getRandomBotCardGrade() : 'S+');
                const bLevel = prof.level || (typeof window.getRandomBotLevel === 'function' ? window.getRandomBotLevel() : (Math.floor(Math.random() * 11) + 20));
                safePlayersData.push({
                    id: 901 + pIdx,
                    username: prof.username,
                    avatar_url: prof.avatar_url,
                    picture: prof.avatar_url,
                    team: isTeam ? ((pIdx % 2 === 0) ? 'A' : 'B') : 'NONE',
                    team_name: isTeam ? ((pIdx % 2 === 0) ? 'ทีมฟ้า' : 'ทีมแดง') : '',
                    is_bot: true,
                    is_awakened: true,
                    color: pIdx === 1 ? 0xf43f5e : (pIdx === 2 ? 0xffd700 : 0xa855f7),
                    level: bLevel,
                    char_level: bLevel,
                    char_grade: bGrade,
                    character_grade: bGrade,
                    grade: bGrade,
                    dice_control_rate: 70,
                    win_rate_bonus: 30,
                    roll_rate: 75,
                    play_skill_rate: 35,
                    skill: { code: 'PULL_BACK_8', power: 8 }
                });
            }
        }

        while (this.pawnsGroup.children.length > 0) {
            this.pawnsGroup.remove(this.pawnsGroup.children[0]);
        }
        this.players = [];

        if (options.clearLog !== false) {
            const feed = document.getElementById('log-feed');
            if (feed) feed.innerHTML = '';
        }

        const defaultColors = [0x00e5ff, 0xf43f5e, 0xffd700, 0xa855f7];
        const usedNames = [];
        const oppProfiles = (typeof window.pickUniqueOpponentProfiles === 'function')
            ? window.pickUniqueOpponentProfiles(safePlayersData.length, [safePlayersData[0]?.username || ''])
            : [];

        safePlayersData.forEach((p, idx) => {
            const color = p.color || defaultColors[idx % defaultColors.length];
            const isAwakened = Boolean(p.is_awakened);

            // ตรวจสอบไม่ให้มีข้อความคำว่า "บอท" / "AI" หากมีชื่ออยู่แล้วให้ล็อกชื่อเดิมไว้จนจบเกม
            if (p.is_bot && oppProfiles.length > 0) {
                const prof = oppProfiles[idx % oppProfiles.length];
                const isLegacy = typeof window.isLegacyBotDisplayName === 'function'
                    ? window.isLegacyBotDisplayName(p.username)
                    : /บอท|🤖|\(AI\)/i.test(String(p.username || ''));
                if (isLegacy || !p.username) {
                    p.username = prof.username;
                }
                if (!p.avatar_url || !p.picture || String(p.avatar_url).includes('google_avatar') || String(p.avatar_url).includes('unsplash.com')) {
                    p.avatar_url = prof.avatar_url;
                    p.picture = prof.picture;
                }
            }
            if (p.username) usedNames.push(p.username);

            const isHuman = !p.is_bot;
            const u = window.DEFAULT_USER || {};
            const myId = u.id;
            const isLocalUser = isHuman && (Boolean(p.is_local_user || p.is_me) || (myId ? (String(p.id) === String(myId) || String(p.user_id) === String(myId)) : (idx === 0)));

            if (isLocalUser && (!p.equipped_gems || p.equipped_gems.length === 0)) {
                const localGems = (typeof window.getEquippedGemsList === 'function' ? window.getEquippedGemsList() : [])
                    || window.DEFAULT_USER?.equipped_gems
                    || [];
                p.equipped_gems = localGems;
                p.equippedGems = localGems;
            }

            const resolvedHumanName = (typeof window.getActivePlayerName === 'function')
                ? window.getActivePlayerName(u)
                : (u.displayName || u.name || u.username || 'ผู้เล่น');
            let finalName = isLocalUser ? resolvedHumanName : (p.username || p.displayName || p.name || 'ผู้เล่น');
            if (isLocalUser && (finalName === 'เขียนศักดิ์' || finalName === 'ผู้เล่น' || finalName === 'Google Player')) {
                finalName = (typeof window.getActivePlayerName === 'function') ? window.getActivePlayerName(u) : resolvedHumanName;
            }

            const pForMesh = { ...p, username: finalName, is_local_user: isLocalUser, playerIndex: idx };
            const pawnGroup = this.createPawnMesh(color, isAwakened, pForMesh);
            this.pawnsGroup.add(pawnGroup);

            const botSkins = ['AuroraCrystalDice', 'EmperorGoldDice', 'CyberNeonDice', 'RubyFireDice'];
            const botDiceNames = [
                'ลูกเต๋าคริสตัลออโรร่า 3D',
                'ลูกเต๋าทองคำจักรพรรดิ 3D',
                'ลูกเต๋าไซเบอร์นีออน 3D',
                'ลูกเต๋าทับทิมเพลิงมังกร 3D'
            ];

            const pSkin = p.dice_skin || (!isLocalUser
                ? botSkins[idx % botSkins.length]
                : (window.DEFAULT_USER?.dice_skin || 'ClassicWoodDice'));
            const pDiceName = p.dice_name || (!isLocalUser
                ? botDiceNames[idx % botDiceNames.length]
                : (window.DEFAULT_USER?.equipped_dice_name || 'ลูกเต๋าไม้คลาสสิก 3D'));

            const playerObj = {
                ...p,
                username: finalName,
                is_local_user: isLocalUser,
                mesh: pawnGroup,
                currentTile: 1,
                color: color,
                isAwakened: isAwakened,
                jailTurns: 0,
                consecutiveDoubles: 0,
                matchGold: (p.matchGold !== undefined) ? Number(p.matchGold) : this.matchConfig.start_match_gold,
                isBankrupt: Boolean(p.isBankrupt),
                loanCount: Number(p.loanCount || 0),
                win_rate_bonus: Number(p.win_rate_bonus ?? (p.is_bot ? 12 : (window.DEFAULT_USER?.win_rate_bonus ?? 25))),
                roll_rate: Number(p.roll_rate ?? (p.is_bot ? 20 : (window.DEFAULT_USER?.roll_rate ?? 35))),
                play_skill_rate: Number(p.play_skill_rate ?? (p.is_bot ? 15 : (window.DEFAULT_USER?.play_skill_rate ?? 25))),
                char_grade: p.char_grade || (p.is_bot ? 'A+' : (window.DEFAULT_USER?.char_grade || 'S')),
                dice_skin: pSkin,
                dice_name: pDiceName,
                skill: p.skill || { code: 'PULL_BACK_5', power: 5 },
                equippedGems: p.equipped_gems || p.equippedGems || (isLocalUser && window.playerGemsData?.equippedSlots ? window.playerGemsData.equippedSlots.filter(Boolean) : []),
                shieldLayers: 0,
                totalRollsCount: 0
            };

            this.setPawnPosition(playerObj, 1, idx);
            this.players.push(playerObj);
            if (typeof this.createOrUpdatePawnShieldVisual === 'function') {
                this.createOrUpdatePawnShieldVisual(playerObj);
            }
            if (playerObj.equippedGems && playerObj.equippedGems.length > 0) {
                this.rebuildGemOrbit3D(playerObj);
            }
        });
        this.showLandingPin(1);

        const syncRoomId = Number(this.matchConfig?.roomId || window.currentRoomId || 0);
        if (syncRoomId > 0 && this.isMonopolyBoardMode) {
            if (typeof this.relocateMonopolySnakesAndLadders === 'function') {
                this.relocateMonopolySnakesAndLadders(false, this.createSeededRng(syncRoomId * 131 + 17));
            }
            if (typeof this.relocateMonopolyStageHazards === 'function') {
                this.relocateMonopolyStageHazards(false, this.createSeededRng(syncRoomId * 131 + 31));
            }
        }

        this.isGameOver = false;
        this.isRolling = false;
        this.currentTurnIndex = (typeof options.startTurnIndex === 'number' && options.startTurnIndex >= 0 && options.startTurnIndex < this.players.length)
            ? options.startTurnIndex
            : 0;
        this.isAutoMode = false;
        this.isMatchActive = options.autoStart !== false;
        if (typeof window.applyGlobalBoardBackground === 'function') {
            window.applyGlobalBoardBackground();
        }
        this.clearTurnTimers();

        if (this.isMatchActive) {
            this.matchStartTime = Date.now();
            this.matchTimeRemaining = this.getMatchDurationSeconds ? this.getMatchDurationSeconds() : 600;
            if (typeof window.stopLobbyAmbientSound === 'function') {
                window.stopLobbyAmbientSound();
            }
            if (typeof window.startGameplayBgm === 'function') {
                const activeTheme = this.boardTheme || (this.activeCustomBoard && this.activeCustomBoard.board_code) || 'classic';
                const customBgm = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_file) || '';
                const customVol = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_volume);
                window.startGameplayBgm(activeTheme, customBgm, customVol);
            }
        }

        this.updateMatchWealthHUD();

        if (this.isMatchActive) {
            this.logMessage(`💰 เงินทองเริ่มต้นในกระดานคนละ ${this.formatCompactGold(this.matchConfig.start_match_gold)} (${this.matchConfig.start_match_gold.toLocaleString()} ทอง)! สร้างได้สูงสุด 3 เมือง & อัปแลนด์มาร์คคูณ X2-X8!`, 'highlight');
            this.startMatchTimer(this.matchStartTime);

            // 🎙️ เสียงลำดับการทอย (Turn Order 1-4 เช่น ได้ทอยเป็นคนแรก, ได้ทอยเป็นคนที่ 2, 3, 4)
            const humanIdx = this.getLocalPlayerIndex();
            const humanTurnOrder = (humanIdx !== -1) ? (humanIdx + 1) : 1;
            const rankNames = ['คนแรก (มือ 1)', 'คนที่สอง (มือ 2)', 'คนที่สาม (มือ 3)', 'คนที่สี่ (มือ 4)'];
            const myRankName = rankNames[humanTurnOrder - 1] || `คนที่ ${humanTurnOrder}`;
            this.logMessage(`🎯 ลำดับการเล่นของคุณ: ได้ทอยเป็น${myRankName}!`, 'info');

            // อัปเดตสถานะเทิร์นและล็อกปุ่มทอยทันทีระหว่างแสดงแบนเนอร์ลำดับการทอย (กันปุ่มทอยขึ้นทั้งสองฝั่ง)
            this.updateActiveTurnUI();
            this.hideMonopolyCenterRollStation(true);
            this.hideMonopolyTilePathMarkers();
            const preTurnRollBtn = document.getElementById('btn-roll-dice');
            const firstActive = this.players?.[this.currentTurnIndex];
            const isFirstMyTurn = Boolean(firstActive && this.isLocalPlayer(firstActive));
            if (preTurnRollBtn) {
                preTurnRollBtn.disabled = true;
                preTurnRollBtn.classList.remove('auto-active');
                if (isFirstMyTurn) {
                    preTurnRollBtn.style.display = 'inline-flex';
                    preTurnRollBtn.style.opacity = '0.75';
                    preTurnRollBtn.innerHTML = '<span>⏳</span> เตรียมเริ่ม...';
                } else {
                    preTurnRollBtn.style.display = 'none';
                }
            }

            // เริ่มซิงค์ทันทีตั้งแต่เข้าเกม (ไม่รอให้แบนเนอร์ลำดับการทอยปิด) เพื่อให้ไม่พลาด event แรก
            if (typeof this.startMultiplayerSync === 'function') {
                this.startMultiplayerSync();
            }

            // 🌟 แสดงแบนเนอร์ลำดับการทอยกลางจอ พร้อมขานเสียงพากย์ภาษาไทยอย่างชัดเจน แล้วจึงเริ่มตาเดิน
            this.showTurnOrderSplash(humanTurnOrder, () => {
                if (!this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble && !this.isWaitingForBoardPick) {
                    this.beginTurn();
                }
                if (typeof this.ensureMultiplayerSync === 'function') {
                    this.ensureMultiplayerSync();
                }
                // บันทึกสถานะเฉพาะเมื่อเริ่มการแข่งขันจริง
                this.saveGameState();
            });
        } else {
            this.updateActiveTurnUI();
            this.updateAutoToggleUI();
        }

        this.updateMonopolyExclusiveUI();

        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }
    }

    /**
     * บันทึกสถานะการเล่นลง LocalStorage อัตโนมัติ (รองรับการหลุด / เน็ตตัด / ปิดแอปแล้วกลับเข้ามาเล่นต่อทันที)
     */
    saveGameState() {
        if (!this.isMatchActive || this.isGameOver || !this.players || this.players.length === 0) {
            return;
        }
        const isPractice = Boolean(window.isPracticeMatch);
        if (!isPractice && !window.currentRoomId) {
            window.currentRoomId = this.matchConfig?.roomId || ('room_' + Date.now());
        }
        try {
            const effectiveMode = this.matchConfig?.gameMode || window.currentActiveGameMode || (this.players.length === 2 ? '2P' : (this.players.length === 3 ? '3P' : '4P'));
            const effectiveRoomId = isPractice ? null : window.currentRoomId;
            const effectiveTier = window.currentActiveRoomTier || this.matchConfig?.room_tier || (isPractice ? 'PRACTICE' : '2M');
            const state = {
                userId: window.DEFAULT_USER?.id || null,
                roomId: effectiveRoomId,
                roomTier: effectiveTier,
                gameMode: effectiveMode,
                isPracticeMatch: isPractice,
                boardLayout: this.boardLayout || localStorage.getItem('snake_board_layout') || 'square',
                boardTheme: this.boardTheme,
                currentTurnIndex: this.currentTurnIndex,
                isAutoMode: Boolean(this._manualAutoMode ?? this.isAutoMode),
                consecutiveDoubles: this.consecutiveDoubles || 0,
                isGameOver: this.isGameOver,
                tileProvinces: this.tileProvinces,
                matchConfig: { ...this.matchConfig, roomId: effectiveRoomId, room_tier: effectiveTier, gameMode: effectiveMode },
                cityStates: this.cityStates,
                timestamp: Date.now(),
                matchStartTime: this.matchStartTime || (Date.now() - (600 - (this.matchTimeRemaining || 600)) * 1000),
                matchTimeRemaining: this.matchTimeRemaining ?? (this.getMatchDurationSeconds ? this.getMatchDurationSeconds() : 600),
                players: this.players.map(p => ({
                    id: p.id,
                    username: p.username,
                    avatar_url: p.avatar_url || p.picture || '',
                    picture: p.picture || p.avatar_url || '',
                    team: p.team || 'NONE',
                    team_name: p.team_name || '',
                    color: p.color,
                    is_bot: Boolean(p.is_bot),
                    is_awakened: Boolean(p.is_awakened),
                    skill: p.skill,
                    dice_control_rate: p.dice_control_rate,
                    win_rate_bonus: p.win_rate_bonus,
                    roll_rate: p.roll_rate,
                    play_skill_rate: p.play_skill_rate,
                    char_grade: p.char_grade,
                    matchGold: p.matchGold,
                    isBankrupt: Boolean(p.isBankrupt),
                    currentTile: p.currentTile,
                    jailTurns: p.jailTurns,
                    consecutiveDoubles: p.consecutiveDoubles
                })),
                recentLogs: this.getRecentLogs()
            };
            const json = JSON.stringify(state);
            localStorage.setItem('snake_active_session', json);
            try { sessionStorage.setItem('snake_active_session_backup', json); } catch (e) { }
            if (state.userId) {
                localStorage.setItem(`snake_active_session_user_${state.userId}`, json);
            }
        } catch (e) {
            console.warn('saveGameState error:', e);
        }
    }

    clearSavedSession() {
        if (typeof window.stopGameplayBgm === 'function') {
            window.stopGameplayBgm();
        }
        try {
            localStorage.removeItem('snake_active_session');
            try { sessionStorage.removeItem('snake_active_session_backup'); } catch (e) { }
            if (window.DEFAULT_USER?.id) {
                localStorage.removeItem(`snake_active_session_user_${window.DEFAULT_USER.id}`);
            }
            const keysToRemove = [];
            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (k && k.startsWith('snake_active_session_user_')) {
                    keysToRemove.push(k);
                }
            }
            keysToRemove.forEach(k => localStorage.removeItem(k));
        } catch (e) { }
    }

    getRecentLogs() {
        try {
            const feed = document.getElementById('log-feed');
            if (!feed) return [];
            const items = feed.querySelectorAll('.log-item');
            const logs = [];
            items.forEach(it => {
                logs.push({ text: it.innerText, className: it.className });
            });
            return logs.slice(-20);
        } catch (e) {
            return [];
        }
    }

    restoreRecentLogs(logs) {
        try {
            const feed = document.getElementById('log-feed');
            if (!feed || !Array.isArray(logs)) return;
            feed.innerHTML = '';
            logs.forEach(item => {
                const div = document.createElement('div');
                div.className = item.className || 'log-item';
                div.innerText = item.text || '';
                feed.appendChild(div);
            });
            feed.scrollTop = feed.scrollHeight;
        } catch (e) { }
    }

    restoreGameState() {
        let raw = localStorage.getItem('snake_active_session');
        if (!raw && window.DEFAULT_USER?.id) {
            raw = localStorage.getItem(`snake_active_session_user_${window.DEFAULT_USER.id}`);
        }
        if (!raw) {
            try { raw = sessionStorage.getItem('snake_active_session_backup'); } catch (e) { }
        }
        if (!raw) return false;
        try {
            const saved = JSON.parse(raw);
            if (!saved || saved.isGameOver || !saved.players || saved.players.length === 0) return false;

            const reqRestoreTiles = this.isMonopolyBoardMode ? 32 : 100;
            if (!this.tiles || this.tiles.length < reqRestoreTiles || !this.boardGroup || this.boardGroup.children.length === 0) {
                this.buildBoard();
                if (this.isMonopolyBoardMode && typeof this.setupMonopolySnakesAndLadders === 'function') {
                    this.setupMonopolySnakesAndLadders();
                }
            }
            this.clearAllCities3D();
            if (saved.matchConfig) {
                this.matchConfig = { ...this.matchConfig, ...saved.matchConfig };
            }

            while (this.pawnsGroup.children.length > 0) {
                this.pawnsGroup.remove(this.pawnsGroup.children[0]);
            }
            this.players = [];

            // ตรวจสอบและซ่อมแซมจำนวนผู้เล่นหากน้อยกว่าโหมดที่เล่น (เช่น เดี่ยว 4 หรือ ทีม ต้องมี 4 คนเสมอ!)
            const targetMode = saved.matchConfig?.gameMode || saved.gameMode || window.currentActiveGameMode || (saved.players.length >= 4 ? '4P' : (saved.players.length === 3 ? '3P' : '2P'));
            const expectedCount = (targetMode === '2P') ? 2 : ((targetMode === '3P') ? 3 : 4);
            if (saved.players.length < expectedCount) {
                const missing = expectedCount - saved.players.length;
                const used = saved.players.map(p => p.username || '');
                const extra = (typeof window.pickUniqueOpponentProfiles === 'function')
                    ? window.pickUniqueOpponentProfiles(missing, used)
                    : [];
                for (let i = 0; i < missing; i++) {
                    const prof = extra[i] || { username: `คู่แข่ง #${saved.players.length + 1}`, avatar_url: 'avatars/google_avatar.png' };
                    const pIdx = saved.players.length;
                    const bGrade = prof.char_grade || (typeof window.getRandomBotCardGrade === 'function' ? window.getRandomBotCardGrade() : 'S+');
                    const bLevel = prof.level || (typeof window.getRandomBotLevel === 'function' ? window.getRandomBotLevel() : (Math.floor(Math.random() * 11) + 20));
                    saved.players.push({
                        id: 901 + pIdx,
                        username: prof.username,
                        avatar_url: prof.avatar_url,
                        picture: prof.avatar_url,
                        team: targetMode === 'TEAM' ? ((pIdx % 2 === 0) ? 'A' : 'B') : 'NONE',
                        is_bot: true,
                        is_awakened: true,
                        currentTile: 1,
                        matchGold: saved.matchConfig?.start_match_gold || 2000000,
                        isBankrupt: false,
                        level: bLevel,
                        char_level: bLevel,
                        char_grade: bGrade,
                        character_grade: bGrade,
                        grade: bGrade,
                        dice_control_rate: 70,
                        win_rate_bonus: 30,
                        roll_rate: 75,
                        play_skill_rate: 35,
                        color: pIdx === 1 ? 0xf43f5e : (pIdx === 2 ? 0xffd700 : 0xa855f7)
                    });
                }
            }

            saved.players.forEach((p, idx) => {
                if (p.is_bot && (String(p.avatar_url).includes('unsplash.com') || String(p.avatar_url).includes('google_avatar'))) {
                    const fallbackUrl = (typeof window.getDeterministicRealisticAvatar === 'function')
                        ? window.getDeterministicRealisticAvatar(p.username || `bot_${idx}`, idx)
                        : `avatars/bots/bot_${idx % 2 === 0 ? 'f' : 'm'}01.jpg`;
                    p.avatar_url = fallbackUrl;
                    p.picture = fallbackUrl;
                }
                const color = p.color || 0x00e5ff;
                const isAwakened = Boolean(p.is_awakened);
                const resolvedGems = (!p.is_bot)
                    ? ((typeof window.getEquippedGemsList === 'function' ? window.getEquippedGemsList() : null) || p.equippedGems || p.equipped_gems || window.DEFAULT_USER?.equipped_gems || [])
                    : (p.equippedGems || p.equipped_gems || []);
                p.equippedGems = resolvedGems;
                p.equipped_gems = resolvedGems;
                const pawnGroup = this.createPawnMesh(color, isAwakened, p);
                pawnGroup.visible = !p.isBankrupt;
                this.pawnsGroup.add(pawnGroup);

                const playerObj = {
                    ...p,
                    mesh: pawnGroup,
                    currentTile: p.currentTile || 1,
                    color: color,
                    isAwakened: isAwakened,
                    jailTurns: p.jailTurns || 0,
                    consecutiveDoubles: p.consecutiveDoubles || 0,
                    matchGold: (p.matchGold !== undefined) ? Number(p.matchGold) : (this.matchConfig.start_match_gold || 2000000),
                    isBankrupt: Boolean(p.isBankrupt),
                    equippedGems: resolvedGems,
                    skill: p.skill || { code: 'PULL_BACK_5', power: 5 }
                };

                this.setPawnPosition(playerObj, p.currentTile || 1, idx);
                this.players.push(playerObj);
                this.rebuildSideGems3D(pawnGroup, resolvedGems);
                if (resolvedGems && resolvedGems.length > 0) {
                    this.rebuildGemOrbit3D(playerObj);
                }
            });

            if (saved.cityStates && typeof saved.cityStates === 'object') {
                this.cityStates = saved.cityStates;
                this.rebuildAllCities3D();
            }
            this.updateMatchWealthHUD();

            window.isPracticeMatch = Boolean(saved.isPracticeMatch);
            window.currentRoomId = window.isPracticeMatch ? null : (saved.roomId || window.currentRoomId || ('room_' + Date.now()));
            window.currentActiveRoomTier = saved.roomTier || saved.matchConfig?.room_tier || (window.isPracticeMatch ? 'PRACTICE' : '2M');
            window.currentActiveGameMode = targetMode;

            this.isGameOver = false;
            this.isRolling = false;
            this.isMatchActive = true;
            if (typeof window.applyGlobalBoardBackground === 'function') {
                window.applyGlobalBoardBackground();
            }
            if (typeof window.stopLobbyAmbientSound === 'function') {
                window.stopLobbyAmbientSound();
            }
            if (typeof window.startGameplayBgm === 'function') {
                const activeTheme = this.boardTheme || (this.activeCustomBoard && this.activeCustomBoard.board_code) || 'classic';
                const customBgm = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_file) || '';
                const customVol = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_volume);
                window.startGameplayBgm(activeTheme, customBgm, customVol);
            }
            this.currentTurnIndex = (saved.currentTurnIndex >= 0 && saved.currentTurnIndex < this.players.length) ? saved.currentTurnIndex : 0;
            this.consecutiveDoubles = saved.consecutiveDoubles || 0;
            this._manualAutoMode = Boolean(saved.isAutoMode ?? false);
            this.isAutoMode = Boolean(saved.isAutoMode ?? false);

            // คืนค่า Log ล่าสุด
            if (saved.recentLogs && saved.recentLogs.length > 0) {
                this.restoreRecentLogs(saved.recentLogs);
            }

            // คำนวณเวลาการแข่งขันที่ผ่านไป (10 นาที หรือ 600 วินาที)
            const matchStart = Number(saved.matchStartTime || saved.timestamp || Date.now());
            this.matchStartTime = matchStart;
            const elapsedSinceStart = Math.floor((Date.now() - matchStart) / 1000);

            // หากผ่านไปเกิน 10 นาทีแล้ว (เช่น ผู้เล่นหลุดไป 30 นาที) ให้ตัดจบตัดสินผู้ชนะด้วยสินทรัพย์ทันที!
            if (elapsedSinceStart >= (this.getMatchDurationSeconds ? this.getMatchDurationSeconds() : 600)) {
                this.matchTimeRemaining = 0;
                this.updateMatchTimerHUD();
                setTimeout(() => {
                    this.handleMatchTimeoutVictory();
                }, 400);
                return true;
            }

            // หากยังไม่หมด 10 นาที ให้เริ่มนับเวลาต่อตามเวลาจริงที่เหลือ
            this.startMatchTimer(matchStart);

            // หากมีหมากในกระดานที่ค้างอยู่บนช่องงูหรือบันได ให้ทำงานดึงตัวละครทันที!
            setTimeout(async () => {
                if (!this.isMatchActive) return;
                let triggeredAny = false;
                for (const p of this.players) {
                    if (this.ladders[p.currentTile] || this.snakes[p.currentTile] || (this.snakeTailToHead && this.snakeTailToHead[p.currentTile])) {
                        await this.checkAndTriggerBoardLinks(p);
                        triggeredAny = true;
                    }
                }
                if (triggeredAny) {
                    this.updateActiveTurnUI();
                    this.saveGameState();
                }
            }, 650);

            if (!this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble && !this.isWaitingForBoardPick) {
                this.beginTurn();
            }
            this.updateCameraFit(false);
            return true;
        } catch (e) {
            console.warn('restoreGameState error:', e);
            return false;
        }
    }

    /**
     * รองรับการพักหน้าจอ (Sleep / Tab change / Minimize)
     */
    handleVisibilityChange() {
        if (!this.isMatchActive) return;
        if (document.visibilityState === 'hidden') {
            this.saveGameState();
        } else if (document.visibilityState === 'visible') {
            if (this.clock) this.clock.getDelta();

            if (this.isMatchActive && !this.isGameOver) {
                // หากหน้าจอดับหรือหลุดไปขณะกำลังทอย ให้เคลียร์สถานะค้าง
                if (this.isRolling && !this.isDiceTumbling) {
                    this.isRolling = false;
                }
                // จัดตำแหน่งหมากให้ตรงกับช่องปัจจุบันทันที
                (this.players || []).forEach(p => {
                    if (p && !p.isBankrupt && p.currentTile) {
                        this.realignPawnsOnTile(p.currentTile);
                    }
                });
                const active = this.players[this.currentTurnIndex];
                if (active) {
                    if (active.is_bot) {
                        this.clearTurnTimers();
                        this.autoTurnTimeout = setTimeout(() => {
                            if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                                this.rollDice();
                            }
                        }, 500);
                    } else if (!this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (!this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble && !this.isWaitingForBoardPick) {
                            this.beginTurn();
                        }
                    }
                }
            }
        }
    }

    async animate3DDiceTumble(targetD1, targetD2) {
        this.isDiceTumbling = true;
        if (window.soundEngine && typeof window.soundEngine.playDiceRoll === 'function') {
            window.soundEngine.playDiceRoll();
        }
        if (window.ThaiAudio && typeof window.ThaiAudio.playDiceRoll === 'function') {
            window.ThaiAudio.playDiceRoll();
        }
        const duration = 1200;
        const startTime = performance.now();

        const faceRotations = {
            1: new THREE.Euler(0, 0, Math.PI / 2),
            2: new THREE.Euler(0, 0, 0),
            3: new THREE.Euler(-Math.PI / 2, 0, 0),
            4: new THREE.Euler(Math.PI / 2, 0, 0),
            5: new THREE.Euler(Math.PI, 0, 0),
            6: new THREE.Euler(0, 0, -Math.PI / 2)
        };

        const targetRot1 = faceRotations[targetD1] || new THREE.Euler(0, 0, 0);
        const targetRot2 = faceRotations[targetD2] || new THREE.Euler(0, 0, 0);

        const basePos = this.diceBasePos || { x: 0, y: 3.6, z: 0, scale: 1.0, spacing: 5.2 };
        const bx = 0;
        const by = basePos.y || 3.6;
        const bz = this.isMonopolyBoardMode ? 7.5 : (basePos.z || 0);
        const bSpace = basePos.spacing || 5.2;

        if (document.hidden || this._fastSimulationActive) {
            this.diceMesh1.position.set(bx - bSpace, by, bz);
            this.diceMesh2.position.set(bx + bSpace, by, bz);
            this.diceMesh1.rotation.copy(targetRot1);
            this.diceMesh2.rotation.copy(targetRot2);
            this.isDiceTumbling = false;
            return Promise.resolve();
        }

        return new Promise(resolve => {
            const animateStep = (time) => {
                const diceElapsed = time - startTime;
                const progress = Math.min(diceElapsed / duration, 1);

                if (progress < 1) {
                    this.diceMesh1.position.x = bx - bSpace;
                    this.diceMesh2.position.x = bx + bSpace;
                    this.diceMesh1.position.y = by + 1.0 + Math.sin(progress * Math.PI * 3) * 6.0;
                    this.diceMesh2.position.y = by + 1.0 + Math.sin(progress * Math.PI * 3.5) * 6.5;

                    // การเคลื่อนที่แกน Z: เด้งลอยในแนวกึ่งกลางกระดาน และไม่เลยต่ำกว่าเส้นแดง (ไม่เกิน Z = 15.0 เสมอ)
                    const tumbleZ = bz - Math.sin((1 - progress) * Math.PI) * 2.2;
                    this.diceMesh1.position.z = tumbleZ;
                    this.diceMesh2.position.z = tumbleZ;

                    this.diceMesh1.rotation.x += 0.45;
                    this.diceMesh1.rotation.y += 0.55;
                    this.diceMesh1.rotation.z += 0.35;

                    this.diceMesh2.rotation.x -= 0.5;
                    this.diceMesh2.rotation.y += 0.4;
                    this.diceMesh2.rotation.z += 0.6;

                    requestAnimationFrame(animateStep);
                } else {
                    const finalSpace = 3.8;
                    this.diceMesh1.position.set(bx - finalSpace, by, bz + 0.6);
                    this.diceMesh2.position.set(bx + finalSpace, by, bz - 0.6);
                    this.diceMesh1.rotation.copy(targetRot1);
                    this.diceMesh2.rotation.copy(targetRot2);
                    this.diceMesh1.rotation.y += 0.12;
                    this.diceMesh2.rotation.y -= 0.15;
                    this.isDiceTumbling = false;
                    if (window.soundEngine && typeof window.soundEngine.playDiceLand === 'function') {
                        window.soundEngine.playDiceLand();
                    }
                    resolve();
                }
            };
            requestAnimationFrame(animateStep);
        });
    }

    async rollDice(forcedValues = null, isAuto = false) {
        if (!this.isMatchActive || this.isRolling || this.isWaitingForBoardPick || this.isGameOver || this.isWaitingForGamble || this.isWaitingForCityAction) {
            // ป้องกันแฟลก _isApplyingRemoteAction ค้างเมื่อ rollDice ถูกปฏิเสธ (ทำให้คิวซิงค์ตายถาวร)
            if (this._isApplyingRemoteAction) {
                this._isApplyingRemoteAction = false;
                const savedEv = this._activeRemoteRollEvent;
                this._activeRemoteRollEvent = null;
                if (Array.isArray(this._syncEventQueue) && forcedValues) {
                    this._syncEventQueue.unshift(savedEv || {
                        type: 'ROLL',
                        payload: {
                            playerIndex: this.currentTurnIndex,
                            d1: forcedValues[0],
                            d2: forcedValues[1],
                            isAuto: isAuto,
                            ladders: this._remoteRollMeta?.ladders || null,
                            snakes: this._remoteRollMeta?.snakes || null,
                            blackHoleTiles: this._remoteRollMeta?.blackHoleTiles || null,
                            fogTiles: this._remoteRollMeta?.fogTiles || null
                        }
                    });
                    setTimeout(() => this.processMultiplayerSyncQueue && this.processMultiplayerSyncQueue(), 600);
                }
            }
            return;
        }
        const player = this.players[this.currentTurnIndex];
        if (!player || player.isBankrupt) {
            this._isApplyingRemoteAction = false;
            return;
        }
        // ห้ามทอยแทนผู้เล่นคนจริงอีกเครื่อง (ป้องกัน AUTO/ตัวจับเวลาเก่าทอยหมากของเพื่อนจากเครื่องเรา)
        if (!this._isApplyingRemoteAction && !player.is_bot && !this.isLocalPlayer(player) && typeof this.isMultiplayerSyncMatch === 'function' && this.isMultiplayerSyncMatch()) {
            return;
        }

        // ปลดล็อกระบบเสียง iOS/Android และเริ่มเพลงเล่นเกมส์ทันทีที่มีการคลิกทอยเต๋า
        if (window.ThaiAudio && typeof window.ThaiAudio.unlock === 'function') {
            window.ThaiAudio.unlock();
        }
        if (typeof window.startGameplayBgm === 'function' && window.soundEngine && !window.soundEngine.isBgmMuted) {
            if (!window.soundEngine.gameplayBgm || !window.soundEngine.gameplayBgm.isPlaying || (window.soundEngine.gameplayBgm.audio && window.soundEngine.gameplayBgm.audio.paused)) {
                const activeTheme = this.boardTheme || (this.activeCustomBoard && this.activeCustomBoard.board_code) || 'classic';
                const customBgm = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_file) || '';
                const customVol = (this.activeCustomBoard && this.activeCustomBoard.theme_config && this.activeCustomBoard.theme_config.bgm_volume);
                window.startGameplayBgm(activeTheme, customBgm, customVol);
            }
        }

        this.clearTurnTimers();
        this.isRolling = true;
        const isBackwardRoll = Boolean(
            this._isApplyingRemoteAction
                ? this._remoteRollMeta?.goBackward
                : (this.isMonopolyBoardMode && this._turnDirectionSkillActive && this.turnRollDirection === 'BACKWARD')
        );
        this._turnDirectionSkillActive = false;
        if (typeof this.hideTurnDirectionBar === 'function') this.hideTurnDirectionBar();
        this.hideMonopolyCenterRollStation();
        this.hideMonopolyTilePathMarkers();
        if (typeof this.updateMatchWealthHUD === 'function') this.updateMatchWealthHUD();
        this.currentTurnRollCount = (this.currentTurnRollCount || 0) + 1;
        const wasStartProtected = this.isStartProtected(player);
        player.totalRollsCount = (player.totalRollsCount || 0) + 1;
        if (wasStartProtected && typeof this.createOrUpdatePawnShieldVisual === 'function') {
            this.createOrUpdatePawnShieldVisual(player);
        }

        // Watchdog: ป้องกันค้างไม่ให้ทอยไม่ได้ถาวร (ถ้าค้างเกิน 8 วินาทีให้ปลดล็อคเริ่มตาใหม่ทันที)
        if (this._rollingWatchdog) clearTimeout(this._rollingWatchdog);
        this._rollingWatchdog = setTimeout(() => {
            if (this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble) {
                console.warn('Watchdog: isRolling stuck >8s, auto recovering...');
                this._syncState = `WD stage=${this._rollStage || '?'} cur=${this.players?.[this.currentTurnIndex]?.currentTile}`;
                try { this.updateSyncDebugBadge(); } catch (e) { }
                this.isRolling = false;
                this.isDiceTumbling = false;
                this.isWaitingForCityAction = false;
                this.isWaitingForGamble = false;
                if (!this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble && !this.isWaitingForBoardPick) {
                    this.beginTurn();
                }
            }
        }, 8000);

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            if (this.isAutoMode && !player.is_bot) {
                // ให้ปุ่มกดได้ตลอดเวลาเพื่อแตะยกเลิก AUTO และกลับมาเล่นเองได้ทันทีแม้ระหว่างกำลังทอย
                rollBtn.disabled = false;
                rollBtn.classList.add('auto-active');
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>⚡</span> AUTO`;
            } else {
                rollBtn.disabled = true;
                rollBtn.innerHTML = `<span>🎲</span> รอ...`;
            }
        }

        // 🌀 สุ่มย้ายตำแหน่งและเปลี่ยนสีสันของงูและบันไดทุกการเริ่มทอย (เฉพาะเครื่องเจ้าของตาเดิน เพื่อไม่ให้กระดาน 2 เครื่องสุ่มต่างกัน)
        if (!this._isApplyingRemoteAction) {
            if (!this.isMonopolyBoardMode) {
                this.randomizeAndRelocateSnakesAndLadders();
            } else {
                this.triggerMonopolyStageSkillOnRoll(player);
            }
        }

        try {
            let d1 = forcedValues ? forcedValues[0] : Math.floor(Math.random() * 6) + 1;
            let d2 = forcedValues ? forcedValues[1] : Math.floor(Math.random() * 6) + 1;

            if (this.isMultiplayerSyncMatch() && !this._isApplyingRemoteAction && (this.isLocalPlayer(player) || (player.is_bot && this.isLocalHostPlayer()))) {
                this.pushMultiplayerSyncEvent('ROLL', {
                    playerIndex: this.currentTurnIndex,
                    d1,
                    d2,
                    isAuto: Boolean(isAuto),
                    ladders: { ...(this.ladders || {}) },
                    snakes: { ...(this.snakes || {}) },
                    blackHoleTiles: Array.isArray(this.monopolyBlackHoleTiles) ? [...this.monopolyBlackHoleTiles] : [],
                    fogTiles: Array.isArray(this.monopolyFogTiles) ? [...this.monopolyFogTiles] : [],
                    goBackward: isBackwardRoll
                });
            }

            const diceControlRate = player.dice_control_rate || 20;
            if (!forcedValues && Math.random() * 100 < diceControlRate) {
                this.showSkillBanner(`🎲 สกิลทอยแม่นยำทำงาน! (${diceControlRate}%)`);
                this.logMessage(`🎲 ${player.username} ควบคุมพลังลูกเต๋าแม่นยำ!`, 'skill');

                // Trigger Antigravity Story Dialogue & Blade Emission Glow
                if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
                    const charName = player.character_name || player.username || 'นักรบดาบชมพู';
                    const dialogueText = player.skill_dialogue || '✨ เพลงดาบประกายชมพูผ่ามิติ! ทอยเต๋าติดดับเบิ้ล 100%!';
                    window.ag.ui.showDialogue({
                        speaker: `🌸 ${charName}`,
                        text: dialogueText,
                        avatar: player.avatar_url || 'avatars/avatar_01.png',
                        duration: 3500
                    });
                }
            }

            // 🛡️ ตรวจสอบสกิลอัญมณีทุกการทอยเต๋า (เช่น เสกโล่คุ้มกัน 1-3 ชั้น, บัฟพิเศษ)
            this._rollStage = 'gem';
            this.triggerGemSkillsOnRoll(player);

            // แสดงลูกเต๋า 3D ขนาดยักษ์เด่นชัดขึ้นมาเมื่อเริ่มทอย
            this.show3DDiceForRoll();

            this._rollStage = 'tumble';
            await this.animate3DDiceTumble(d1, d2);
            this._rollStage = 'afterTumble';

            const dice1El = document.getElementById('dice-1');
            const dice2El = document.getElementById('dice-2');
            if (dice1El) dice1El.innerText = d1;
            if (dice2El) dice2El.innerText = d2;

            const total = d1 + d2;
            const isDouble = (d1 === d2);

            // ⭐ แสดงตัวเลขและป้ายดับเบิ้ลกึ่งกลางกระดาน สไตล์ โหมดกระดาน 3D
            this.showCenterDiceOutcomeBadge(total, isDouble, d1, d2);

            // 🎙️ เล่นเสียงขานแต้มลูกเต๋าภาษาไทย (เช่น "สาม", "สี่", "สิบสอง" หรือ "ดับเบิล สิบสอง")
            if (window.ThaiAudio && typeof window.ThaiAudio.playDiceOutcome === 'function') {
                window.ThaiAudio.playDiceOutcome(total, isDouble, d1, d2);
            }

            // หน่วงเวลาหลังทอยเต๋า: โหมดเกมส์เศรษฐีรอชมป้ายตัวเลข ~1150ms, โหมดบันไดงูรอสั้น ~350ms
            await new Promise(r => setTimeout(r, this.isMonopolyBoardMode ? 1150 : 350));

            // ปิดตัวเลข และค่อยๆ ย่อลูกเต๋า 3D หายไปจากกระดาน
            this.hideCenterDiceOutcomeBadge();
            this._rollStage = 'hideDice';
            await this.hide3DDiceAfterRoll();
            this._rollStage = 'afterHide';

            const dName = player.dice_name || (window.DICE_SKIN_PRESETS && window.DICE_SKIN_PRESETS[player.dice_skin]?.name) || 'ลูกเต๋า 3D';
            const autoTag = (!player.is_bot && (isAuto || this.isAutoMode)) ? ' ⚡[AUTO]' : '';

            // 🎯 แสดงตำแหน่งเป้าหมายปลายทางชัดเจนทันทีเมื่อทอยเต๋าเสร็จ
            const goalTileNum = this.totalTilesCount || 100;
            const destTargetTile = this.isMonopolyBoardMode
                ? (((player.currentTile + total - 1) % 32) + 1)
                : ((player.currentTile + total <= goalTileNum)
                    ? (player.currentTile + total)
                    : Math.max(1, goalTileNum - (total - (goalTileNum - player.currentTile))));
            this.showDestinationBeacon(destTargetTile, total, player);
            this.logMessage(`🎲 ${player.username}${autoTag} ใช้ [${dName}] ทอยได้ [${d1}] + [${d2}] = ${total} ${isDouble ? '🔥 แต้มเบิ้ล!' : ''}`, isDouble ? 'highlight' : '');
            if (isDouble && !player.isBankrupt && !this.isGameOver && typeof this.triggerGemDoubleRollSalarySkill === 'function') {
                this.triggerGemDoubleRollSalarySkill(player);
            }

            const wasInJail = Boolean(player.jailTurns > 0);
            if (player.jailTurns > 0) {
                if (isDouble) {
                    player.jailTurns = 0;
                    this.showSkillBanner(`🎉 ${player.username} ทอยได้แต้มเบิ้ล [${d1}][${d2}]! หลบหนีออกจากเกาะร้างสำเร็จ!`);
                    if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
                        window.ag.ui.showDialogue({
                            speaker: `🎉 ${player.username}`,
                            text: `✨ ทอยได้แต้มเบิ้ล [${d1}][${d2}]! หลบหนีออกจากเกาะร้างสำเร็จ! เดินทางต่อทันที`,
                            avatar: player.avatar_url || 'avatars/avatar_01.png',
                            duration: 3000
                        });
                    }
                    this.logMessage(`🎉 ${player.username} ทอยได้แต้มเบิ้ล [${d1}][${d2}]! หลบหนีออกจากเกาะร้างสำเร็จ!`, 'highlight');
                    if (typeof window.closeModal === 'function') {
                        window.closeModal('modal-jail');
                    }
                    this._rollStage = 'move'; await this.movePlayer(player, total, { isBackward: isBackwardRoll }); this._rollStage = 'afterMove';
                } else {
                    player.jailTurns--;
                    if (player.jailTurns <= 0) {
                        player.jailTurns = 0;
                        this.showSkillBanner(`🔓 ${player.username} ครบกำหนดติดเกาะร้างแล้ว!`);
                        if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
                            window.ag.ui.showDialogue({
                                speaker: `🔓 ${player.username}`,
                                text: `🔓 ครบกำหนดโทษติดเกาะร้างแล้ว! ในตาถัดไปจะสามารถทอยเต๋าได้ตามปกติ`,
                                avatar: player.avatar_url || 'avatars/avatar_01.png',
                                duration: 3000
                            });
                        }
                        this.logMessage(`🔓 ${player.username} ครบกำหนด 2 ตา พ้นโทษเกาะร้างแล้ว! ในตาถัดไปจะทอยได้ตามปกติ`, 'highlight');
                    } else {
                        this.showSkillBanner(`⏳ ทอยไม่เบิ้ล [${d1}][${d2}]! ยังคงติดเกาะร้าง (เหลืออีก ${player.jailTurns} ตา)`);
                        if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
                            window.ag.ui.showDialogue({
                                speaker: `⏳ ${player.username}`,
                                text: `⏳ ทอยได้ [${d1}][${d2}] ไม่ใช่แต้มเบิ้ล! ยังคงติดเกาะร้าง (เหลืออีก ${player.jailTurns} ตา หรือจ่ายค่าประกันตัวเพื่อออก)`,
                                avatar: player.avatar_url || 'avatars/avatar_01.png',
                                duration: 3000
                            });
                        }
                        this.logMessage(`⏳ ${player.username} ทอยได้ [${d1}][${d2}] ไม่ใช่แต้มเบิ้ล! ติดเกาะร้าง (เหลืออีก ${player.jailTurns} ตา หรือจ่ายเพื่อออก)`, 'highlight');
                    }
                    if (typeof window.closeModal === 'function') {
                        window.closeModal('modal-jail');
                    }
                    this.endTurn(false);
                    return;
                }
            } else {
                if (isDouble) {
                    player.consecutiveDoubles++;
                    this.consecutiveDoubles = player.consecutiveDoubles;
                    this.logMessage(`🔥 ${player.username} ทอยเบิ้ลครั้งที่ ${player.consecutiveDoubles}!`, 'highlight');
                    const maxDoublesLimit = (window.GAME_RULES && window.GAME_RULES.jail_consecutive_doubles !== undefined) ? Number(window.GAME_RULES.jail_consecutive_doubles) : 3;
                    if (player.consecutiveDoubles >= maxDoublesLimit) {
                        player.consecutiveDoubles = 0;
                        this.consecutiveDoubles = 0;
                        await this.sendToJail(player);
                        return;
                    }
                } else {
                    player.consecutiveDoubles = 0;
                    this.consecutiveDoubles = 0;
                }

                this._rollStage = 'move'; await this.movePlayer(player, total, { isBackward: isBackwardRoll }); this._rollStage = 'afterMove';
            }

            if (this.isGameOver) return;
            // 🚨 หากตกเกาะร้าง หรืออยู่ในเกาะร้าง สิทธิ์ทอยเบิ้ลถูกยกเลิก และเทิร์นถูกจบไปแล้ว
            if (player.jailTurns > 0 || player.currentTile === this.jailTile) {
                return;
            }

            const hasExtraTurn = !wasInJail && isDouble && !this.isGameOver && !player.isBankrupt && player.jailTurns === 0;
            if (hasExtraTurn) {
                this.logMessage(`⚡ ${player.username} ได้สิทธิ์ทอยเพิ่มอีก 1 ครั้งจากแต้มเบิ้ล!`, 'highlight');
            }

            this.endTurn(hasExtraTurn);
        } catch (e) {
            console.error('Error during rollDice:', e);
            this.endTurn(false);
        } finally {
            if (this._rollingWatchdog) {
                clearTimeout(this._rollingWatchdog);
                this._rollingWatchdog = null;
            }
            this.hideCenterDiceOutcomeBadge();
            if (this.diceGroup) this.diceGroup.visible = false;
            this.isRolling = false;
            if (!this._isApplyingRemoteAction && typeof this.processMultiplayerSyncQueue === 'function') {
                this.processMultiplayerSyncQueue();
            }
        }
    }

    async movePlayer(player, steps, moveOpts = {}) {
        const goalTile = this.totalTilesCount || 100;
        const startTile = player.currentTile;
        let stepCountIdx = 0;

        // ตรวจสอบสกิลเริ่มตาเดินเมื่อมีคู่แข่งอยู่ช่องเดียวกัน
        await this.checkAndTriggerPassKick(player, startTile);

        if (steps <= 0) {
            // เดินถอยหลังตามปกติกรณีแต้มติดลบ (ถ้ามี)
            const targetTile = Math.max(1, startTile + steps);
            for (let t = startTile - 1; t >= targetTile; t--) {
                stepCountIdx++;
                if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                    window.soundEngine.playStep();
                }
                if (window.ThaiAudio && typeof window.ThaiAudio.playStep === 'function') {
                    window.ThaiAudio.playStep(stepCountIdx);
                }
                await this.animatePawnToTile(player, t, this.getStepDuration());
                await this.checkAndTriggerPassKick(player, t);
            }
            player.currentTile = targetTile;
        } else if (this.isMonopolyBoardMode) {
            // 🧭 สกิลอัญมณี: เดินหน้าหรือถอยหลังตามทิศทางที่เลือกไว้ตอนเริ่มเทิร์น (หรือสุ่มเลือกหากยังไม่ได้ทอยสกิล)
            let goBackwardSteps = Boolean(moveOpts && moveOpts.isBackward);
            if (!goBackwardSteps && !this._isApplyingRemoteAction && !this._turnDirectionRolledThisTurn && steps > 0) {
                const mGems = this.getPlayerEquippedGems(player);
                const mEff = this.aggregateGemEffects(mGems);
                if (mEff.forward_backward_move && (Math.random() * 100 < (mEff.forward_backward_rate || 50))) {
                    const fTile = ((startTile - 1 + steps) % 32) + 1;
                    const bTile = ((startTile - 1 - steps + 320) % 32) + 1;
                    if (fTile !== bTile) {
                        const rateTxt = mEff.forward_backward_rate || 50;
                        const lvTxt = mEff.forward_backward_gem_level || 1;
                        const skTitle = mEff.forward_backward_name || 'เลือกทอยหน้า-หลัง';
                        this.showSkillBanner(`🧭✨ [อัญมณี Lv.${lvTxt} • ${rateTxt}%] สุ่มติดสกิล "${skTitle}"! เลือกเดินหน้า (+${steps}) หรือ ถอยหลัง (-${steps})`);
                        this.logMessage(`🧭 [สกิลอัญมณี ${rateTxt}%] ${player.username} สุ่มติดสกิล "${skTitle}" เลือกเดินหน้า #${fTile} หรือถอยหลัง #${bTile}`, 'skill');

                        let pickedTile = fTile;
                        if (player.is_bot || !this.isLocalPlayer(player) || this.isAutoMode) {
                            const fSt = this.cityStates?.[fTile];
                            const bSt = this.cityStates?.[bTile];
                            const fOpp = fSt && !this.isTileOwnedByPlayerOrTeam(fTile, player);
                            const bGood = (!bSt && this.isBuildableTile(bTile)) || (bSt && this.isTileOwnedByPlayerOrTeam(bTile, player));
                            if (fOpp && bGood) pickedTile = bTile;
                        } else {
                            pickedTile = await this.pickTileDirectlyOnBoard3D({
                                title: `🧭 สกิลอัญมณี (${rateTxt}%): เลือกเดินหน้าหรือถอยหลัง ${steps} ช่อง!`,
                                subText: `✨ จิ้มช่อง [#${this.getDisplayTileNumber(fTile)} ${this.getProvinceName(fTile)}] (เดินหน้า) หรือ [#${this.getDisplayTileNumber(bTile)} ${this.getProvinceName(bTile)}] (ถอยหลัง)`,
                                getTileMode: (t) => (t === fTile || t === bTile) ? 'HIGHLIGHT' : 'DISABLED',
                                defaultTile: fTile,
                                timeoutSec: 12
                            });
                        }
                        if (Number(pickedTile) === bTile) {
                            goBackwardSteps = true;
                        }
                    }
                }
            }

            // โหมดเกมส์เศรษฐี 32 ช่อง: เดินวนรอบกระดาน 1 -> 32 -> 1 (เดินหน้าหรือถอยหลังตามสกิล)
            let cur = startTile;
            for (let s = 1; s <= steps; s++) {
                cur = goBackwardSteps
                    ? ((cur <= 1) ? 32 : (cur - 1))
                    : ((cur >= 32) ? 1 : (cur + 1));
                stepCountIdx++;
                if (!goBackwardSteps && cur === 1 && startTile !== 1) {
                    this.handlePassFinishLine(player);
                }
                if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                    window.soundEngine.playStep();
                }
                if (window.ThaiAudio && typeof window.ThaiAudio.playStep === 'function') {
                    window.ThaiAudio.playStep(stepCountIdx);
                }
                await this.animatePawnToTile(player, cur, this.getStepDuration());
                this.handleMonopolyStepHazard(player, cur, s === steps);
                await this.checkAndTriggerPassKick(player, cur);
            }
            player.currentTile = cur;
        } else if (startTile + steps <= goalTile) {
            // กรณีเดินไปข้างหน้าไม่เกินเส้นชัย (หรือถึงเส้นชัยพอดี)
            const targetTile = startTile + steps;
            for (let t = startTile + 1; t <= targetTile; t++) {
                stepCountIdx++;
                if (t === 1 && startTile !== 1) {
                    this.handlePassFinishLine(player);
                }
                if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                    window.soundEngine.playStep();
                }
                if (window.ThaiAudio && typeof window.ThaiAudio.playStep === 'function') {
                    window.ThaiAudio.playStep(stepCountIdx);
                }
                await this.animatePawnToTile(player, t, this.getStepDuration());
                await this.checkAndTriggerPassKick(player, t);
            }
            player.currentTile = targetTile;
        } else {
            // กรณีทอยเกินเส้นชัย (Overshoot):
            // 1. เดินไปข้างหน้าจนแตะเส้นชัยก่อน
            // 2. แสดงเอฟเฟกต์เด้งชนเส้นชัย
            // 3. เดินถอยหลังตามจำนวนแต้มที่เหลือทีละช่อง
            const forwardSteps = Math.max(0, goalTile - startTile);
            const overshoot = steps - forwardSteps;
            const bounceTile = Math.max(1, goalTile - overshoot);

            // เฟสที่ 1: เดินก้าวไปข้างหน้าจนถึงเส้นชัย
            if (forwardSteps > 0) {
                for (let t = startTile + 1; t <= goalTile; t++) {
                    stepCountIdx++;
                    if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                        window.soundEngine.playStep();
                    }
                    if (window.ThaiAudio && typeof window.ThaiAudio.playStep === 'function') {
                        window.ThaiAudio.playStep(stepCountIdx);
                    }
                    await this.animatePawnToTile(player, t, this.getStepDuration());
                    await this.checkAndTriggerPassKick(player, t);
                }
                player.currentTile = goalTile;
                this.updateActiveTurnUI();
            }

            // 🏁 ผู้เล่นเดินแตะ/ผ่านจุดเส้นชัย: แจกทองตามกติกา (เฉพาะทอยครั้งแรกของเทิร์นเท่านั้น)
            this.handlePassFinishLine(player);

            // แจ้งเตือนและแสดงเอฟเฟกต์เด้งชนเส้นชัย
            if (typeof this.showSkillBanner === 'function') {
                this.showSkillBanner(`⚡ ${player.username} ทอยได้ ${steps} เกินเส้นชัย! ชนเส้นชัยแล้วเด้งถอยหลัง ${overshoot} ช่อง!`);
            }
            this.logMessage(`⚡ ${player.username} ทอยได้ ${steps} แต้ม เดินแตะเส้นชัยช่อง ${goalTile} แล้วเด้งถอยหลัง ${overshoot} ช่อง ไปยังช่อง ${bounceTile}!`, 'highlight');

            if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
                window.soundEngine.playWarp();
            }
            await new Promise(r => setTimeout(r, 360));

            // เฟสที่ 2: เดินถอยหลังจากเส้นชัยกลับมายังช่อง bounceTile ทีละก้าว
            for (let t = goalTile - 1; t >= bounceTile; t--) {
                stepCountIdx++;
                if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                    window.soundEngine.playStep();
                }
                if (window.ThaiAudio && typeof window.ThaiAudio.playStep === 'function') {
                    window.ThaiAudio.playStep(stepCountIdx);
                }
                await this.animatePawnToTile(player, t, this.getStepDuration());
                await this.checkAndTriggerPassKick(player, t);
            }
            player.currentTile = bounceTile;
        }

        this.updateActiveTurnUI();
        this.hideDestinationBeacon(true);
        this.showLandingPin(player.currentTile);
        this.saveGameState();
        this.checkNearFinishAlerts();

        if (!this.isMonopolyBoardMode && player.currentTile >= goalTile) {
            this.handleVictory(player, 'FINISH_LINE');
            return;
        }

        // 🪜 1. ตรวจสอบช่องบันได (Ladder): ให้สร้างเมือง / จ่ายค่าผ่านทางก่อน ถึงจะปีนบันไดขึ้นไป!
        if (this.ladders[player.currentTile]) {
            const ladderStart = player.currentTile;
            const ladderEnd = this.ladders[ladderStart];

            // สร้างเมืองก่อนถึงขึ้นบันได ("แต่หากเป็นของฝ่ายตรงข้ามบังคับจ่ายทันทีซื้อต่อไม่ได้ หากเป็นของเราซื้อเมืองเพิ่มได้")
            if (this.isBuildableTile(ladderStart)) {
                await this.handleCityTileLanding(player, { allowBuyout: false, isPostBounce: false });
                if (this.isGameOver || player.isBankrupt) return;
            }

            // ปีนบันไดขึ้นไปยังยอดบันได (ซึ่งอาจเป็นเมือง, เกาะร้าง, มุม หรือพื้นที่พิเศษก็ได้!)
            if (window.soundEngine && typeof window.soundEngine.playLadder === 'function') {
                window.soundEngine.playLadder();
            }
            if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                window.ThaiAudio.playIfConfigured('ladder_climb');
            }
            this.logMessage(`🪜 ${player.username} เจอช่องบันได! ไต่ขึ้นจาก ${this.getDisplayTileNumber(ladderStart)} ไป ${this.getDisplayTileNumber(ladderEnd)} (${this.getProvinceName(ladderEnd)})!`, 'highlight');
            await this.animatePawnToTile(player, ladderEnd, 900);
            player.currentTile = ladderEnd;
            this.showLandingPin(ladderEnd);
            this.checkNearFinishAlerts();

            if (!this.isMonopolyBoardMode && player.currentTile >= goalTile) {
                this.handleVictory(player, 'FINISH_LINE');
                return;
            }
            // ปล่อยให้ไหลลงไปประมวลผลช่องปลายทาง (ไม่ว่าจะเป็น เกาะร้าง, พื้นที่พิเศษ, พื้นที่คูณ, ดวง, ภาษี, START หรือเมือง!)
        }
        // 🐍 2. ตรวจสอบช่องงู (Snake): ให้สร้างเมือง / จ่ายค่าผ่านทางก่อน ถึงจะสไลด์ลงหางงู!
        else if (this.snakes[player.currentTile]) {
            const snakeHead = player.currentTile;
            const snakeEnd = this.snakes[snakeHead];

            // สร้างเมืองก่อนถึงสไลด์ลงหางงู ("แต่หากเป็นของฝ่ายตรงข้ามบังคับจ่ายทันทีซื้อต่อไม่ได้ หากเป็นของเราซื้อเมืองเพิ่มได้")
            if (this.isBuildableTile(snakeHead)) {
                await this.handleCityTileLanding(player, { allowBuyout: false, isPostBounce: false });
                if (this.isGameOver || player.isBankrupt) return;
            }

            // ตรวจสอบสกิลเกราะคุ้มกันหัวงู
            const playerGems = this.getPlayerEquippedGems(player);
            const playerEffects = this.aggregateGemEffects(playerGems);

            if (playerEffects.immune_snake || (player.skill && player.skill.code === 'SHIELD_TRAP' && Math.random() < 0.85)) {
                this.showSkillBanner(`🛡️ สกิลเกราะคุ้มกันหัวงูทำงาน! ยกเลิกการสไลด์ลง!`);
                this.logMessage(`🛡️ ${player.username} ใช้เกราะคุ้มกันหัวงู ป้องกันกับดักงูสำเร็จ!`, 'skill');
                this.triggerShieldPulseEffect(player);
                this.checkOpponentCollision(player);
                return;
            } else if (player.shieldLayers && player.shieldLayers > 0) {
                player.shieldLayers--;
                this.createOrUpdatePawnShieldVisual(player);
                this.showSkillBanner(`🛡️ ม่านพลังโล่สลายกับดักงูสำเร็จ! ไม่โดนสไลด์ลง (เหลือโล่ ${player.shieldLayers} ชั้น)!`);
                this.logMessage(`🛡️ ${player.username} เสียสละโล่คุ้มกัน 1 ชั้น สลายกับดักงูสำเร็จ (เหลือโล่ ${player.shieldLayers} ชั้น)!`, 'skill');
                this.triggerShieldPulseEffect(player);
                this.checkOpponentCollision(player);
                return;
            } else {
                // สไลด์ลงหางงู (ซึ่งอาจเป็นเมือง, เกาะร้าง, มุม หรือพื้นที่พิเศษก็ได้!)
                if (window.soundEngine && typeof window.soundEngine.playSnake === 'function') {
                    window.soundEngine.playSnake();
                }
                if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                    window.ThaiAudio.playIfConfigured('snake_bite');
                }
                this.logMessage(`🐍 ${player.username} ตกช่องงู! สไลด์ลงจาก ${this.getDisplayTileNumber(snakeHead)} ไป ${this.getDisplayTileNumber(snakeEnd)} (${this.getProvinceName(snakeEnd)})...`, 'highlight');
                await this.animatePawnToTile(player, snakeEnd, 900);
                player.currentTile = snakeEnd;
                this.showLandingPin(snakeEnd);
                this.checkNearFinishAlerts();
                // ปล่อยให้ไหลลงไปประมวลผลช่องปลายทาง (ไม่ว่าจะเป็น เกาะร้าง, พื้นที่พิเศษ, พื้นที่คูณ, ดวง, ภาษี, START หรือเมือง!)
            }
        }

        if (!this.isMonopolyBoardMode && player.currentTile >= goalTile) {
            this.handleVictory(player, 'FINISH_LINE');
            return;
        }

        // 🚨 ตรวจสอบการตกช่องเกาะร้าง (Jail Tile)
        if (player.currentTile === this.jailTile) {
            player.jailTurns = (window.GAME_RULES && window.GAME_RULES.jail_max_turns !== undefined) ? Number(window.GAME_RULES.jail_max_turns) : 2;
            player.consecutiveDoubles = 0;
            this.consecutiveDoubles = 0;
            if (window.ThaiAudio && typeof window.ThaiAudio.playIslandTrap === 'function') {
                window.ThaiAudio.playIslandTrap();
            }

            const jailMsg = (!player.is_bot && this.isLocalPlayer(player))
                ? `คุณตกช่องเกาะร้าง! ต้องติดเกาะร้างเป็นเวลา ${player.jailTurns} ตา (งดทอยในตานี้)`
                : `${player.username} ตกช่องเกาะร้าง! ต้องติดเกาะร้างเป็นเวลา ${player.jailTurns} ตา (งดทอย)`;

            // 1. แสดง popup เกาะร้าง โดยเอากรอบแดง (ปุ่มกดทั้ง 3) ออก
            if (this.isLocalPlayer(player) && typeof window.openJailModal === 'function') {
                window.openJailModal(player, false);
            }

            if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
                window.ag.ui.showDialogue({
                    speaker: `🏝️ ${player.username}`,
                    text: `🚨 ${jailMsg}`,
                    avatar: player.avatar_url || 'avatars/avatar_01.png',
                    duration: 2000
                });
            } else {
                this.showSkillBanner(`🚨 ${player.username} ตกช่องเกาะร้าง! ติดเกาะร้าง 2 ตา!`);
            }
            this.logMessage(`🚨 ${player.username} ตกช่องเกาะร้าง! ต้องติดเกาะร้าง 2 ตา (งดทอยในตานี้)`, 'highlight');

            // 2. แสดง 2 วินาทีแล้วปิด popup เองอัตโนมัติ
            if (this.isLocalPlayer(player)) {
                await new Promise(resolve => setTimeout(resolve, 2000));
                if (typeof window.closeModal === 'function') {
                    window.closeModal('modal-jail');
                }
            } else {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            // 3. หลังติดเกาะร้าง ให้งดทอย ไม่มีผลแต้มเบิ้ล (ไม่ให้ทอยต่อ) และส่งต่อให้คนอื่นทอยทันที
            this.endTurn(false);
            return;
        }

        // ตรวจสอบกับดักหลุมดำมิติ 3D (Black Hole Trap)
        if (this.activeBlackHoles && this.activeBlackHoles[player.currentTile]) {
            const bh = this.activeBlackHoles[player.currentTile];
            const bhOwner = this.players.find(p => String(p.id) === String(bh.ownerId));
            const isBhSelf = String(bh.ownerId) === String(player.id);
            const isBhTeammate = Boolean(!isBhSelf && player.team && player.team !== 'NONE' && bhOwner && player.team === bhOwner.team);

            if (!isBhSelf && !isBhTeammate) {
                const vicGems = this.getPlayerEquippedGems(player);
                const vicEff = this.aggregateGemEffects(vicGems);
                const lmProv = this.getProvinceName(bh.destinationTile);

                if (vicEff.immune_kick) {
                    this.showSkillBanner(`🛡️ สกิล [ต้านแรงดึงดูด] ของ ${player.username} ทำงาน! รอดพ้นจากหลุมดำ!`);
                    this.logMessage(`🛡️ สกิลป้องกันของ ${player.username} ต้านทานแรงดูดหลุมดำสำเร็จ!`, 'skill');
                    this.triggerShieldPulseEffect(player);
                } else if (player.shieldLayers && player.shieldLayers > 0) {
                    player.shieldLayers--;
                    this.createOrUpdatePawnShieldVisual(player);
                    this.showSkillBanner(`🛡️ โล่ม่านพลังของ ${player.username} ดูดซับพลังหลุมดำได้สำเร็จ! (เหลือโล่ ${player.shieldLayers} ชั้น)`);
                    this.logMessage(`🛡️ โล่ของ ${player.username} ป้องกันหลุมดำได้สำเร็จ (เหลือโล่ ${player.shieldLayers} ชั้น)`, 'skill');
                    this.triggerShieldPulseEffect(player);
                } else {
                    this.showSkillBanner(`🕳️ ${player.username} ตกหลุมดำมิติ! ถูกดูดทะลุมิติไปยังแลนด์มาร์ค [${lmProv}] (ช่อง ${bh.destinationTile})!`);
                    this.logMessage(`🕳️ ${player.username} เหยียบหลุมดำช่อง ${player.currentTile}! วาร์ปตรงไปยังแลนด์มาร์คช่อง ${bh.destinationTile}!`, 'highlight');
                    await this.animateBlackHoleSuckAndTeleport(player, player.currentTile, bh.destinationTile);
                    player.currentTile = bh.destinationTile;
                    this.showLandingPin(player.currentTile);
                    this.removeBlackHole(player.currentTile);
                }
            }
        }

        if (this._isApplyingRemoteAction) {
            return;
        }

        // Special tile events
        if (this.isMonopolyBoardMode && player.currentTile === 1) {
            await this.handleMonopolyStartTileUpgrade(player);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.isMonopolyBoardMode && ((Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(player.currentTile)) || (Array.isArray(this.worldTravelTiles) && this.worldTravelTiles.includes(player.currentTile)) || player.currentTile === this.worldTravelTile)) {
            const isExp = Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(player.currentTile);
            await this.handleMonopolyWorldTravelTile(player, player.currentTile, isExp);
            if (this.isGameOver || player.isBankrupt) return;
            return;
        } else if (this.isMonopolyBoardMode && Array.isArray(this.godTiles) && this.godTiles.includes(player.currentTile)) {
            await this.handleMonopolyGodTile(player, player.currentTile);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.isMonopolyBoardMode && ((Array.isArray(this.olympicTiles) && this.olympicTiles.includes(player.currentTile)) || player.currentTile === this.olympicTile)) {
            await this.handleMonopolyOlympicTile(player, player.currentTile);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.chanceTiles.includes(player.currentTile)) {
            await this.handleChanceTile(player);
            if (this.isGameOver || player.isBankrupt) return;
            if (!this.isMonopolyBoardMode && player.currentTile >= goalTile) {
                this.handleVictory(player, 'FINISH_LINE');
                return;
            }
        } else if (this.taxTiles.includes(player.currentTile)) {
            await this.handleTaxTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.gambleTiles.includes(player.currentTile)) {
            await this.handleGambleTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.destroyTiles && this.destroyTiles.includes(player.currentTile)) {
            await this.handleDestroySkillTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        }

        // ระบบเมือง 1-3 หลัง, แลนด์มาร์ค, เก็บค่าผ่านทาง, ซื้อต่อเมือง และคูณ X2/X4/X6/X8
        if (!this.isGameOver && !player.isBankrupt && this.isBuildableTile(player.currentTile)) {
            await this.handleCityTileLanding(player);
            if (this.isGameOver || player.isBankrupt) return;
        }

        this.checkOpponentCollision(player);
    }

    /**
     * 🏁 รางวัลเดินผ่านจุดเส้นชัย (Finish Line Lap Gold Reward)
     * กติกา: ผ่านได้ทอง แต่ต้องทอยครั้งแรกของเทิร์นเท่านั้น หากทอยเบิ้ล หรือทอยครั้งที่ 2-3 ในเทิร์น จะไม่ได้ทอง
     */
    handlePassFinishLine(player) {
        if (!player || player.isBankrupt || this.isGameOver) return;
        const salaryGold = (window.GAME_RULES && window.GAME_RULES.lap_salary_gold !== undefined)
            ? Number(window.GAME_RULES.lap_salary_gold)
            : 200000;
        if (salaryGold <= 0) return;

        if (this.currentTurnRollCount === 1) {
            player.matchGold = (player.matchGold || 0) + salaryGold;
            this.updateMatchWealthHUD();
            if (typeof this.showSkillBanner === 'function') {
                this.showSkillBanner(`🏁 ${player.username} ผ่านจุดเส้นชัย! ได้รับเงินรางวัล +${salaryGold.toLocaleString()} ทอง!`);
            }
            this.logMessage(`🏁 ${player.username} เดินผ่านจุดเส้นชัย ได้รับเงินรางวัล +${salaryGold.toLocaleString()} ทอง (ทอยครั้งแรกของเทิร์น)`, 'highlight');
            if (window.soundEngine && typeof window.soundEngine.playCoins === 'function') {
                window.soundEngine.playCoins();
            } else if (window.soundEngine && typeof window.soundEngine.playCash === 'function') {
                window.soundEngine.playCash();
            }
        } else {
            this.logMessage(`🏁 ${player.username} เดินผ่านจุดเส้นชัย แต่เป็นการทอยครั้งที่ ${this.currentTurnRollCount} (ทอยเบิ้ล) จึงไม่ได้รับเงินรางวัลทองตามกติกา`, 'highlight');
        }
    }

    isStartProtected(player) {
        return Boolean(player && !player.isBankrupt && (player.totalRollsCount || 0) === 0 && Number(player.currentTile || 1) === 1);
    }

    hasBuiltAnyCity(player) {
        if (!player || !this.cityStates) return false;
        return Object.values(this.cityStates).some(st => st && String(st.ownerId) === String(player.id));
    }

    canUseAttackSkillsAgainstOpponents(player) {
        if (!player) return false;
        // หากยังไม่ได้สร้างเมืองและยังทอยไม่ถึงครั้งที่ 2 (เช่น เพิ่งทอยครั้งแรกจากจุดสตาร์ท) จะยังไม่ใช้สกิลโจมตีคู่แข่ง
        if ((player.totalRollsCount || 0) < 2 && !this.hasBuiltAnyCity(player)) {
            return false;
        }
        return true;
    }

    checkOpponentCollision(activePlayer) {
        if (!activePlayer || activePlayer.isBankrupt) return;
        if (!this.canUseAttackSkillsAgainstOpponents(activePlayer)) return;
        const currentTile = activePlayer.currentTile;
        const opponents = this.players.filter(
            p => p.id !== activePlayer.id && !p.isBankrupt && p.currentTile === currentTile && p.currentTile > 1
        );

        if (opponents.length === 0) return;

        // หากช่องนี้มีเมืองและเป็นของฝ่ายตรงข้าม เจ้าของเมืองจะได้รับการปกป้อง (ไม่โดนดึงถอยหลังเด็ดขาด)
        const cityOwnerId = this.cityStates[currentTile]?.ownerId;

        // หากผู้เล่นมีสกิลอัญมณีเตะส่งข้ามมิติลงเมืองแพง ให้ทำงานก่อน
        const activeGems = this.getPlayerEquippedGems(activePlayer);
        const activeEff = this.aggregateGemEffects(activeGems);
        if (activeEff.pass_kick) {
            this.checkAndTriggerPassKick(activePlayer, currentTile);
            return;
        }

        const skill = activePlayer.skill || {};
        let pullBackTiles = (skill.code === 'PULL_BACK_8' || activePlayer.isAwakened) ? 8 : 5;

        opponents.forEach(async (opp) => {
            // หาก opp ยังไม่ทอยครั้งแรกที่จุดสตาร์ท มีโล่ห์ป้องกันจุดเริ่มต้น
            if (this.isStartProtected(opp)) {
                this.showSkillBanner(`🛡️ โล่จุดเริ่มต้นของ ${opp.username} ทำงาน! ป้องกันสกิลคู่แข่ง!`);
                this.logMessage(`🛡️ โล่จุดเริ่มต้นของ ${opp.username} ป้องกันการถูกดึงถอยหลังของ ${activePlayer.username} สำเร็จ!`, 'skill');
                this.triggerShieldPulseEffect(opp);
                return;
            }

            // หาก opp เป็นเจ้าของเมืองนี้ ไม่สามารถดึงเจ้าของเมืองถอยหลังได้
            if (cityOwnerId && String(cityOwnerId) === String(opp.id)) return;

            // หากเป็นเพื่อนร่วมทีมกัน ไม่ดึงเพื่อนถอยหลัง
            if (activePlayer.team && activePlayer.team !== 'NONE' && activePlayer.team === opp.team) return;

            // 🛡️ ตรวจสอบระบบสกิลป้องกันของผู้ถูกกระทำ (Victim Defensive Hooks)
            const oppGems = this.getPlayerEquippedGems(opp);
            const oppEffects = this.aggregateGemEffects(oppGems);

            // 1. สกิลป้องกันการถูกเตะ / ดึงถอยหลัง 100% (Immune Kick)
            if (oppEffects.immune_kick) {
                this.showSkillBanner(`🛡️ สกิล [${oppEffects.immune_kick_name || 'ป้องกันการเตะ'}] ของ ${opp.username} ทำงาน! ต้านทานแรงเตะได้ 100%!`);
                this.logMessage(`🛡️ ${opp.username} มีสกิลป้องกันการเตะ ป้องกันการดึงถอยหลังของ ${activePlayer.username} สำเร็จ!`, 'skill');
                this.triggerShieldPulseEffect(opp);
                return;
            }

            // 2. ม่านพลังโล่คุ้มกันดูดซับแรงเตะ (Shield Layer Absorption)
            if (opp.shieldLayers && opp.shieldLayers > 0) {
                opp.shieldLayers--;
                this.createOrUpdatePawnShieldVisual(opp);
                this.showSkillBanner(`🛡️ ม่านพลังโล่ของ ${opp.username} สลายแรงกระแทก! ป้องกันการถูกเตะสำเร็จ! (เหลือโล่ ${opp.shieldLayers} ชั้น)`);
                this.logMessage(`🛡️ โล่ของ ${opp.username} สลายแรงกระแทก ป้องกันการถูกเตะสำเร็จ (เหลือโล่ ${opp.shieldLayers} ชั้น)`, 'skill');
                this.triggerShieldPulseEffect(opp);
                return;
            }

            this.showSkillBanner(`⚡ สกิล ${activePlayer.username} ทำงาน! ดึง ${opp.username} ถอยหลัง ${pullBackTiles} ช่อง!`);
            this.logMessage(`⚡ สกิลพิเศษ! ${activePlayer.username} ดึง ${opp.username} ถอยหลัง ${pullBackTiles} ช่อง!`, 'skill');

            const newTile = Math.max(1, opp.currentTile - pullBackTiles);
            await this.animatePawnToTile(opp, newTile, 750);
            opp.currentTile = newTile;
            this.showLandingPin(newTile);

            if (this.ladders[opp.currentTile] || this.snakes[opp.currentTile]) {
                await this.checkAndTriggerBoardLinks(opp);
            }
            if (this.isBuildableTile(opp.currentTile)) {
                await this.handleCityTileLanding(opp, { isPostBounce: true, allowBuyout: false });
            }
        });

        // 💰 ตรวจสอบการดูดเงิน / ขโมยทองเมื่อเดินชน (Steal Gold Effect Hook)
        if (activeEff.steal_gold) {
            const stealRate = activeEff.steal_rate || 85;
            if (Math.random() * 100 < stealRate) {
                opponents.forEach(opp => {
                    if (activePlayer.team && activePlayer.team !== 'NONE' && activePlayer.team === opp.team) return;

                    const oppGems = this.getPlayerEquippedGems(opp);
                    const oppEffects = this.aggregateGemEffects(oppGems);

                    // ตรวจสอบว่าคู่แข่งมีสกิลป้องกันการดูดเงินหรือไม่
                    if (oppEffects.immune_steal) {
                        this.showSkillBanner(`🛡️ สกิล [${oppEffects.immune_steal_name || 'ป้องกันการดูดเงิน'}] ของ ${opp.username} ทำงาน! ป้องกันทองได้ 100%!`);
                        this.logMessage(`🛡️ ${opp.username} มีสกิลป้องกันการดูดเงิน! การขโมยทองของ ${activePlayer.username} ไร้ผล!`, 'skill');
                        this.triggerShieldPulseEffect(opp);
                        return;
                    }

                    if (this.isStartProtected(opp)) {
                        this.showSkillBanner(`🛡️ โล่จุดเริ่มต้นของ ${opp.username} ป้องกันเวทดูดเงินสำเร็จ!`);
                        this.triggerShieldPulseEffect(opp);
                        return;
                    }
                    if (opp.shieldLayers && opp.shieldLayers > 0) {
                        opp.shieldLayers--;
                        this.createOrUpdatePawnShieldVisual(opp);
                        this.showSkillBanner(`🛡️ โล่ของ ${opp.username} ป้องกันเวทดูดเงินสำเร็จ! ไม่เสียทอง (เหลือโล่ ${opp.shieldLayers} ชั้น)!`);
                        this.logMessage(`🛡️ โล่ของ ${opp.username} ป้องกันการถูกดูดทองสำเร็จ! (เหลือโล่ ${opp.shieldLayers} ชั้น)`, 'skill');
                        this.triggerShieldPulseEffect(opp);
                        return;
                    }

                    const oppGold = Number(opp.matchGold) || 0;
                    const stealAmount = Math.min(oppGold, Math.round((this.matchConfig?.city_base_cost || 120000) * 0.75));
                    if (stealAmount > 0) {
                        opp.matchGold -= stealAmount;
                        activePlayer.matchGold = (Number(activePlayer.matchGold) || 0) + stealAmount;
                        this.updateMatchWealthHUD();
                        this.showSkillBanner(`🧲 สกิลดูดเงินทำงาน! ${activePlayer.username} ขโมยทองจาก ${opp.username} +${this.formatCompactGold(stealAmount)} 💰!`);
                        this.logMessage(`🧲 ${activePlayer.username} ดูดเงินจาก ${opp.username} จำนวน ${stealAmount.toLocaleString()} ทอง!`, 'skill');
                    }
                });
            }
        }
    }

    async sendToJail(player) {
        player.currentTile = this.jailTile;
        player.jailTurns = (window.GAME_RULES && window.GAME_RULES.jail_max_turns !== undefined) ? Number(window.GAME_RULES.jail_max_turns) : 2;
        player.consecutiveDoubles = 0;
        this.consecutiveDoubles = 0;
        if (window.ThaiAudio && typeof window.ThaiAudio.playIslandTrap === 'function') {
            window.ThaiAudio.playIslandTrap();
        }
        await this.animatePawnToTile(player, this.jailTile, 750);

        const jailMsg = (!player.is_bot && this.isLocalPlayer(player))
            ? `คุณทำผิดกฎทอยเบิ้ล 3 ครั้งติด ต้องติดเกาะร้างเป็นเวลา ${player.jailTurns} ตา (งดทอยในตานี้)`
            : `${player.username} ทำผิดกฎทอยเบิ้ล 3 ครั้ง ส่งไปติดเกาะร้าง ${player.jailTurns} ตา`;

        // 1. แสดง popup เกาะร้าง โดยเอากรอบแดงออก
        if (this.isLocalPlayer(player) && typeof window.openJailModal === 'function') {
            window.openJailModal(player, false);
        }

        if (window.ag && window.ag.ui && typeof window.ag.ui.showDialogue === 'function') {
            window.ag.ui.showDialogue({
                speaker: `🏝️ ${player.username}`,
                text: `🚨 ${jailMsg}`,
                avatar: player.avatar_url || 'avatars/avatar_01.png',
                duration: 2000
            });
        } else {
            this.showSkillBanner(`🚨 ${player.username} ทอยเบิ้ล 3 ครั้งติด! ส่งไปติดเกาะร้าง 2 ตา!`);
        }
        this.logMessage(`🚨 ${player.username} ทำผิดกฎทอยเบิ้ล 3 ครั้ง ส่งไปติดเกาะร้าง 2 ตา (งดทอยในตานี้)!`, 'highlight');

        // 2. แสดง 2 วินาทีแล้วปิด popup เอง
        if (this.isLocalPlayer(player)) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            if (typeof window.closeModal === 'function') {
                window.closeModal('modal-jail');
            }
        } else {
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // 3. ยกเลิกสิทธิ์ทอยต่อ และจบเทิร์น
        this.endTurn(false);
    }

    async handleChanceTile(player) {
        const bonusMatchGold = Math.round((this.matchConfig?.city_base_cost || 120000) * 1.25);
        const chances = [
            { text: 'โชคดี! ก้าวกระโดดพุ่งไปข้างหน้า 3 ช่อง', move: 3 },
            { text: `ได้รับโบนัสเงินทุนในกระดาน +${this.formatCompactGold(bonusMatchGold)}!`, matchGold: bonusMatchGold },
            { text: 'ติดหล่มทราย! ถอยหลัง 2 ช่อง', move: -2 }
        ];
        const card = chances[Math.floor(Math.random() * chances.length)];
        this.showSkillBanner(`🎁 ช่องดวง (Chance): ${card.text}`);
        this.logMessage(`🎁 ${player.username} ได้การ์ดดวง: ${card.text}`, 'highlight');

        if (card.matchGold) {
            player.matchGold = (Number(player.matchGold) || 0) + card.matchGold;
            this.updateMatchWealthHUD();
        }
        if (card.move) {
            const nextT = Math.max(1, Math.min(100, player.currentTile + card.move));
            await this.animatePawnToTile(player, nextT, 500);
            player.currentTile = nextT;
            this.checkNearFinishAlerts();
            await this.checkAndTriggerBoardLinks(player);
        }
    }

    getPawnFrontOffset(player, targetTileNum, explicitIndex) {
        const t = Math.min(Math.max(Number(targetTileNum) || 1, 1), 100);
        const idx = explicitIndex !== undefined ? explicitIndex : Math.max(0, this.players.indexOf(player));

        // ช่อง Start (1) และ เส้นชัย (100): ให้ตัวผู้เล่นหลักอยู่แถวหน้าเสมอ
        if (t === 1 || t === 100) {
            const startSlots = [
                { x: -0.95, z: 0.95 },
                { x: 0.95, z: 0.95 },
                { x: -0.95, z: -0.35 },
                { x: 0.95, z: -0.35 }
            ];
            return startSlots[idx % startSlots.length];
        }

        // นับจำนวนผู้เล่นที่ยืนอยู่ในช่องเดียวกัน (ไม่รวมคนล้มละลาย)
        const sameTilePlayers = (this.players || []).filter(
            p => p && !p.isBankrupt && (p === player || p.currentTile === t)
        );
        if (sameTilePlayers.length <= 1) {
            // ยืนคนเดียว: ยืนกึ่งกลางด้านหน้าสุดของช่อง (พ้นหน้าตึกเมือง/แลนด์มาร์ค 100%)
            return { x: 0, z: 1.52 };
        }

        // ยืนหลายคนในช่องเดียวกัน: เรียงแถวด้านหน้าช่อง (+z) โดยให้ตัวผู้เล่นเราอยู่หน้าสุดเสมอ
        sameTilePlayers.sort((a, b) => {
            if (Boolean(a.is_bot) !== Boolean(b.is_bot)) return a.is_bot ? 1 : -1;
            return this.players.indexOf(a) - this.players.indexOf(b);
        });
        const slotIdx = Math.max(0, sameTilePlayers.indexOf(player));
        const multiFrontSlots = [
            { x: -1.02, z: 1.58 },
            { x: 1.02, z: 1.58 },
            { x: -1.68, z: 1.05 },
            { x: 1.68, z: 1.05 }
        ];
        return multiFrontSlots[slotIdx % multiFrontSlots.length];
    }

    realignPawnsOnTile(tileNum, excludePlayer = null) {
        const t = Number(tileNum);
        if (!t || t < 1 || t > 100 || !this.tiles[t]) return;
        const tilePos = this.tiles[t];
        const baseY = (tilePos.y || 0) + ((t === 1 || t === 100) ? 1.18 : 0.52);
        (this.players || []).forEach((p, idx) => {
            if (!p || p === excludePlayer || p.isBankrupt || p.currentTile !== t || !p.mesh) return;
            const off = this.getPawnFrontOffset(p, t, idx);
            p.mesh.position.set(tilePos.x + off.x, baseY, tilePos.z + off.z);
        });
    }

    /**
     * ดึงค่าระยะเวลาการเดินต่อก้าว (ไม่ให้เดินเร็วเกินไป / ปรับได้จาก Admin)
     */
    getStepDuration() {
        if (this._fastSimulationActive) return 0;
        const dur = Number(
            this.stepDurationMs ??
            this.activeCustomBoard?.roll_btn_config?.stepDurationMs ??
            this.matchConfig?.step_duration_ms ??
            380
        );
        const speedMultiplier = (window.gameSettings && window.gameSettings.walkSpeedMultiplier)
            ? window.gameSettings.walkSpeedMultiplier
            : Number((typeof localStorage !== 'undefined' && localStorage.getItem('snake_walk_speed_mult')) || 1.0);
        const adjusted = Math.round(dur / Math.max(0.5, speedMultiplier));
        return Math.max(120, Math.min(1200, adjusted));
    }

    /**
     * ตรวจสอบว่าก้าวเดินนี้ข้ามพื้นที่ว่างตรงกลาง (Hollow Center Gap) หรือไม่
     */
    isStepCrossingCenterHole(startPos, endPos, prevTile, targetTileNum) {
        if (!this.hollowCenter) return false;
        if (!startPos || !endPos) return false;

        const dx = endPos.x - startPos.x;
        const dz = endPos.z - startPos.z;
        const dist = Math.sqrt(dx * dx + dz * dz);

        const normalStepDist = (this.tileSize || 6.2) * 1.85;

        // หากระยะก้าวไกลกว่าช่องปกติ (ข้ามช่องว่างตรงกลางระหว่างซ้าย-ขวา)
        if (dist > normalStepDist) {
            return true;
        }

        // หรือจุดกึ่งกลางของวิถีตกอยู่ในพื้นที่ Hollow Center
        if (this._hollowBounds) {
            const hb = this._hollowBounds;
            const midX = (startPos.x + endPos.x) / 2;
            const midZ = (startPos.z + endPos.z) / 2;
            if (midX >= hb.xLeft - 1.2 && midX <= hb.xRight + 1.2 && midZ >= hb.zBack - 1.2 && midZ <= hb.zFront + 1.2) {
                return true;
            }
        }

        return false;
    }

    /**
     * สร้างพื้นผิววงแหวนเงามืด / หลุมดำมิติ สำหรับมุดหายตัว
     */
    createShadowPuddleTexture(colorHex = '#7c3aed') {
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');
        const cx = 128;
        const cy = 128;

        // Dark shadowy void center
        const grad = ctx.createRadialGradient(cx, cy, 10, cx, cy, 120);
        grad.addColorStop(0, '#020006');
        grad.addColorStop(0.35, '#0e051d');
        grad.addColorStop(0.65, safeHexToRgba(colorHex, 0.8));
        grad.addColorStop(0.85, safeHexToRgba(colorHex, 0.27));
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, 120, 0, Math.PI * 2);
        ctx.fill();

        // Runic shadow ring
        ctx.lineWidth = 3.5;
        ctx.strokeStyle = safeHexToRgba(colorHex, 0.87);
        ctx.setLineDash([12, 8]);
        ctx.beginPath();
        ctx.arc(cx, cy, 85, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 2;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.arc(cx, cy, 105, 0, Math.PI * 2);
        ctx.stroke();

        return new THREE.CanvasTexture(canvas);
    }

    /**
     * 👥 แอนิเมชันมุดหายเป็นเงาจางๆ ข้ามตรงกลางไปโผล่ช่องถัดไป (Shadow Burrow / Fade Warp)
     */
    async animateShadowDiveAcrossCenter(player, startPos, endPos, targetTileNum, duration = 480) {
        if (!player || !player.mesh) return;

        // เล่นเสียงประตูมิติ / วาร์ปเงา
        if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
            try { window.soundEngine.playWarp(); } catch (e) { }
        }

        const shadowStyle = this.shadowDiveStyle || 'shadow_fade';
        const auraColor = (shadowStyle === 'portal_dark') ? '#00e5ff' : ((shadowStyle === 'smoke_burst') ? '#f43f5e' : '#a855f7');
        const puddleTex = this.createShadowPuddleTexture(auraColor);

        // 1. วงแหวนเงามืดที่จุดเริ่มต้น (Departure Shadow Puddle)
        const puddleGeo = new THREE.PlaneGeometry(3.6, 3.6);
        const puddleMatStart = new THREE.MeshBasicMaterial({
            map: puddleTex,
            transparent: true,
            opacity: 0,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        const puddleMeshStart = new THREE.Mesh(puddleGeo, puddleMatStart);
        puddleMeshStart.rotation.x = -Math.PI / 2;
        puddleMeshStart.position.set(startPos.x, 0.08, startPos.z);
        this.scene.add(puddleMeshStart);

        // เก็บ Material และค่าความโปร่งใสเดิมของชิ้นส่วนตัวละคร
        const mats = [];
        player.mesh.traverse(child => {
            if (child.isMesh && child.material) {
                if (Array.isArray(child.material)) {
                    child.material.forEach(m => mats.push({ mat: m, origOpacity: m.opacity !== undefined ? m.opacity : 1.0, origTransparent: m.transparent }));
                } else {
                    mats.push({ mat: child.material, origOpacity: child.material.opacity !== undefined ? child.material.opacity : 1.0, origTransparent: child.material.transparent });
                }
            }
        });

        const setPawnOpacity = (alpha) => {
            mats.forEach(item => {
                item.mat.transparent = true;
                item.mat.opacity = item.origOpacity * Math.max(0, Math.min(1, alpha));
            });
        };

        const halfDur = Math.max(140, Math.round(duration * 0.5));

        // -------------------------------------------------------------
        // เฟส 1: มุดลงดินเป็นเงาจางๆ ที่จุดเริ่มต้น (Sink & Fade Out)
        // -------------------------------------------------------------
        await new Promise(resolve => {
            const t0 = performance.now();
            const animateDive = (now) => {
                const diveElapsed = now - t0;
                const p = Math.min(1, diveElapsed / halfDur);
                const ease = p * p;

                // ยุบตัวลงใต้พื้น (Sink Y down -0.9)
                player.mesh.position.y = startPos.y - ease * 0.9;

                // หดตัวเล็กลง
                const s = 1.0 - ease * 0.85;
                player.mesh.scale.set(s, s, s);

                // จางหายแบบเงาจางๆ
                setPawnOpacity(1 - ease);

                // ขยายวงแหวนเงาบนพื้น
                puddleMatStart.opacity = Math.sin(p * Math.PI) * 0.95;
                puddleMeshStart.scale.setScalar(0.6 + p * 0.8);
                puddleMeshStart.rotation.z += 0.04;

                if (p < 1) {
                    requestAnimationFrame(animateDive);
                } else {
                    this.scene.remove(puddleMeshStart);
                    puddleMatStart.dispose();
                    resolve();
                }
            };
            requestAnimationFrame(animateDive);
        });

        // -------------------------------------------------------------
        // เฟส 2: ย้ายตำแหน่งใต้ดินไปยังช่องปลายทาง (Underground Teleport)
        // -------------------------------------------------------------
        player.mesh.position.set(endPos.x, endPos.y - 0.9, endPos.z);
        player.mesh.scale.set(0.15, 0.15, 0.15);
        setPawnOpacity(0);

        // วงแหวนเงามืดที่ช่องปลายทาง (Arrival Shadow Puddle)
        const puddleMatEnd = new THREE.MeshBasicMaterial({
            map: puddleTex,
            transparent: true,
            opacity: 0,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        const puddleMeshEnd = new THREE.Mesh(puddleGeo, puddleMatEnd);
        puddleMeshEnd.rotation.x = -Math.PI / 2;
        puddleMeshEnd.position.set(endPos.x, 0.08, endPos.z);
        this.scene.add(puddleMeshEnd);

        // -------------------------------------------------------------
        // เฟส 3: โผล่ขึ้นมาจากเงาที่ช่องถัดไป (Rise & Fade In)
        // -------------------------------------------------------------
        await new Promise(resolve => {
            const t0 = performance.now();
            const animateRise = (now) => {
                const riseElapsed = now - t0;
                const p = Math.min(1, riseElapsed / halfDur);
                const ease = p * (2 - p);

                // ลอยตัวขึ้นมาจากใต้พื้นสู่ระดับปกติ
                player.mesh.position.y = (endPos.y - 0.9) + ease * 0.9;

                // ขยายขนาดกลับสู่ขนาดปกติ 1.0
                const s = 0.15 + ease * 0.85;
                player.mesh.scale.set(s, s, s);

                // ค่อยๆ ปรากฏตัวชัดขึ้นจากเงาจางๆ
                setPawnOpacity(ease);

                // วงแหวนเงาค่อยๆ หดและจางหายไป
                puddleMatEnd.opacity = (1 - ease) * 0.95;
                puddleMeshEnd.scale.setScalar(1.4 - ease * 0.6);
                puddleMeshEnd.rotation.z += 0.04;

                if (p < 1) {
                    requestAnimationFrame(animateRise);
                } else {
                    this.scene.remove(puddleMeshEnd);
                    puddleMatEnd.dispose();
                    puddleGeo.dispose();
                    resolve();
                }
            };
            requestAnimationFrame(animateRise);
        });

        // คืนค่า Material ดั้งเดิม
        mats.forEach(item => {
            item.mat.opacity = item.origOpacity;
            item.mat.transparent = item.origTransparent;
        });
        player.mesh.position.copy(endPos);
        player.mesh.scale.set(1, 1, 1);
        this.realignPawnsOnTile(targetTileNum);
    }

    async animatePawnToTile(player, targetTileNum, duration) {
        const dest = this.tiles[targetTileNum];
        if (!dest || !player || !player.mesh) return;

        const actualDuration = (duration !== undefined && duration !== 220) ? duration : this.getStepDuration();

        const prevTile = player.currentTile;
        player.currentTile = targetTileNum;
        if (prevTile && prevTile !== targetTileNum) {
            this.realignPawnsOnTile(prevTile, player);
        }

        const idx = Math.max(0, this.players.indexOf(player));
        const offset = this.getPawnFrontOffset(player, targetTileNum, idx);
        const endPos = dest.clone();
        endPos.x += offset.x;
        endPos.z += offset.z;
        endPos.y = (dest.y || 0) + ((targetTileNum === 1 || targetTileNum === 100) ? 1.18 : 0.52);

        if (document.hidden || actualDuration === 0 || this._fastSimulationActive) {
            player.mesh.position.copy(endPos);
            this.triggerTileStepPop(targetTileNum);
            this.realignPawnsOnTile(targetTileNum);
            return Promise.resolve();
        }

        const startPos = player.mesh.position.clone();

        // 👥 เมื่อเดินผ่านช่องว่างตรงกลาง ให้มุดหายเป็นเงาจางๆ ไปโผล่ช่องถัดไป (Shadow Burrow Warp)
        if (this.shadowDiveAcrossCenter && this.isStepCrossingCenterHole(startPos, endPos, prevTile, targetTileNum)) {
            const diveDur = Number(this.shadowDiveDurationMs || Math.max(480, Math.round(actualDuration * 1.3)));
            await this.animateShadowDiveAcrossCenter(player, startPos, endPos, targetTileNum, diveDur);
            this.triggerTileStepPop(targetTileNum);
            return;
        }

        return new Promise(resolve => {
            const startTime = performance.now();
            let hasPopped = false;

            const dx = endPos.x - startPos.x;
            const dz = endPos.z - startPos.z;
            const dist = Math.sqrt(dx * dx + dz * dz);
            const dirX = dist > 0.01 ? dx / dist : 0;
            const dirZ = dist > 0.01 ? dz / dist : 0;

            const step = (time) => {
                const leapElapsed = time - startTime;
                const progress = Math.min(leapElapsed / actualDuration, 1);

                // พลังกระโดดก้าวขาเป็นคลื่นทรงพลัง (Running Leap Arc)
                const jumpArc = Math.sin(progress * Math.PI) * 2.45;

                player.mesh.position.lerpVectors(startPos, endPos, progress);
                player.mesh.position.y += jumpArc;

                // แอนิเมชันวิ่ง เอียงตัวไปข้างหน้า และส่ายตัวซ้าย-ขวาสลับก้าว (Running Tilt & Footstep Wobble)
                if (player.mesh.userData) {
                    const runPitch = Math.sin(progress * Math.PI) * 0.28;
                    const runWobble = Math.sin(progress * Math.PI * 2) * 0.12;
                    const stretch = progress < 0.45
                        ? 1.0 + Math.sin((progress / 0.45) * Math.PI) * 0.14
                        : 1.0 - Math.sin(((progress - 0.45) / 0.55) * Math.PI) * 0.10;

                    player.mesh.userData.runMotion = {
                        pitch: runPitch,
                        wobble: runWobble,
                        stretch: stretch,
                        dirX: dirX,
                        dirZ: dirZ
                    };
                }

                // เมื่อเท้าแตะลงบนเมือง (Touchdown at progress >= 0.65) กระตุ้นเอฟเฟกต์เมืองนูนขึ้นทันที!
                if (progress >= 0.65 && !hasPopped) {
                    hasPopped = true;
                    this.triggerTileStepPop(targetTileNum);
                    if (typeof this.createStepShockwave === 'function') {
                        this.createStepShockwave(endPos, player.color || 0x00e5ff);
                    }
                }

                if (progress < 1) {
                    requestAnimationFrame(step);
                } else {
                    player.mesh.position.copy(endPos);
                    if (player.mesh.userData) {
                        delete player.mesh.userData.runMotion;
                    }
                    this.realignPawnsOnTile(targetTileNum);
                    resolve();
                }
            };
            requestAnimationFrame(step);
        });
    }

    endTurn(hasExtraTurn = false) {
        this.isRolling = false;
        this.clearTurnTimers();
        if (this.isGameOver) return;

        if (this._isApplyingRemoteAction) {
            this._isApplyingRemoteAction = false;
            this._activeRemoteRollEvent = null;
            this._remoteRollMeta = null;
            if (typeof this.processMultiplayerSyncQueue === 'function' && Array.isArray(this._syncEventQueue) && this._syncEventQueue.length > 0) {
                setTimeout(() => this.processMultiplayerSyncQueue(), 0);
                return;
            }
            // รอ STATE snapshot จากเครื่องเจ้าของตาเดิน (fallback 25 วินาทีหากเน็ตหลุด)
            if (this._remoteWaitTimeout) clearTimeout(this._remoteWaitTimeout);
            this._remoteWaitTimeout = setTimeout(() => {
                if (this.isMatchActive && !this.isGameOver && !this.isRolling) {
                    this.updateMatchWealthHUD();
                }
            }, 25000);
            return;
        }

        const curr = this.players[this.currentTurnIndex];
        const shouldBroadcastState = this.isMultiplayerSyncMatch() && curr && (this.isLocalPlayer(curr) || (curr.is_bot && this.isLocalHostPlayer()));

        if (!hasExtraTurn || !curr || curr.isBankrupt) {
            this.currentTurnRollCount = 0;
            this.totalTurnsPlayed = (this.totalTurnsPlayed || 0) + 1;
            let guard = 0;
            do {
                this.currentTurnIndex = (this.currentTurnIndex + 1) % this.players.length;
                guard++;
            } while (this.players[this.currentTurnIndex]?.isBankrupt && guard <= this.players.length);
        }

        if (shouldBroadcastState) {
            this.pushMultiplayerSyncEvent('STATE', this.buildMultiplayerStateSnapshot());
        }

        this.updateMatchWealthHUD();
        this.saveGameState();
        this.beginTurn();
    }

    showTurnDirectionBar() {
        const bar = document.getElementById('fb-direction-bar');
        if (bar) bar.style.display = 'flex';
        this.setTurnRollDirection(this.turnRollDirection || 'FORWARD');
    }

    hideTurnDirectionBar() {
        const bar = document.getElementById('fb-direction-bar');
        if (bar) bar.style.display = 'none';
    }

    setTurnRollDirection(dir) {
        const cleanDir = (dir === 'BACKWARD') ? 'BACKWARD' : 'FORWARD';
        this.turnRollDirection = cleanDir;
        const btnF = document.getElementById('btn-dir-forward');
        const btnB = document.getElementById('btn-dir-backward');
        if (btnF) btnF.classList.toggle('active', cleanDir === 'FORWARD');
        if (btnB) btnB.classList.toggle('active', cleanDir === 'BACKWARD');
    }

    clearTurnTimers() {
        if (this.turnCountdownInterval) {
            clearInterval(this.turnCountdownInterval);
            this.turnCountdownInterval = null;
        }
        if (this.autoTurnTimeout) {
            clearTimeout(this.autoTurnTimeout);
            this.autoTurnTimeout = null;
        }
    }

    beginTurn() {
        if (typeof this.ensureMultiplayerSync === 'function') this.ensureMultiplayerSync();
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();
        this.updateMatchWealthHUD();

        if (!this.isMatchActive || this.isGameOver || !this.players || this.players.length === 0) return;
        let active = this.players[this.currentTurnIndex];
        if (!active || active.isBankrupt) {
            const aliveIdx = this.players.findIndex(p => !p.isBankrupt);
            if (aliveIdx === -1) return;
            this.currentTurnIndex = aliveIdx;
            active = this.players[aliveIdx];
        }

        this.applyDiceSkinForPlayer(active);

        const rollBtn = document.getElementById('btn-roll-dice');
        const isMyTurn = this.isLocalPlayer(active);

        // 🚨 หากถึงตาผู้เล่นที่ติดเกาะร้าง ให้แสดง popup นี้ขึ้นมาทันที!
        if (active.jailTurns > 0) {
            if (!isMyTurn) {
                // บอทหรือคู่แข่งติดเกาะร้าง: ลุ้นทอยเบิ้ล
                if (rollBtn) {
                    rollBtn.disabled = true;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '0.6';
                    rollBtn.innerHTML = `<span>🏝️</span> เกาะร้าง...`;
                }
                if (active.is_bot) {
                    this.autoTurnTimeout = setTimeout(() => {
                        if (this.isMatchActive && !this.isGameOver && !this.isRolling) {
                            this.rollDice();
                        }
                    }, (document.hidden ? 500 : 1200));
                }
                return;
            } else if (this.isAutoMode) {
                // โหมด AUTO: ผู้เล่นลุ้นทอยแต้มเบิ้ลอัตโนมัติ
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                }
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, (document.hidden ? 400 : 900));
                return;
            } else {
                // ผู้เล่นจริง (Local Player) ถึงตาเราทอย -> แสดง popup ติดเกาะร้างขึ้นมาทันที พร้อมนับถอยหลังตามที่กำหนดจาก Admin
                const maxTurnSec = (window.GAME_RULES && window.GAME_RULES.turn_time_limit !== undefined) ? Number(window.GAME_RULES.turn_time_limit) : 20;
                this.turnSecondsLeft = maxTurnSec;
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>🏝️</span> เกาะร้าง <span class="roll-timer-badge">(${maxTurnSec}วิ)</span>`;
                }
                if (typeof window.openJailModal === 'function') {
                    window.openJailModal(active, true);
                }
                this.turnCountdownInterval = setInterval(() => {
                    if (!this.isMatchActive || this.isRolling || this.isGameOver) {
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        return;
                    }
                    this.turnSecondsLeft--;
                    if (this.turnSecondsLeft > 0) {
                        if (rollBtn && !this.isAutoMode) {
                            rollBtn.innerHTML = `<span>🏝️</span> เกาะร้าง <span class="roll-timer-badge">(${this.turnSecondsLeft}วิ)</span>`;
                        }
                    } else {
                        // เกิน 20 วินาทีไม่ได้เลือก -> เปลี่ยนเป็นเล่น AUTO ทันที และทอยแต้มดับเบิลเพื่อพยายามออกจากเกาะ
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.enableAutoMode(true);
                    }
                }, 1000);
                return;
            }
        }

        if (!isMyTurn) {
            // ตาของคู่แข่ง (บอท หรือผู้เล่นคู่แข่ง)
            // 🚫 ห้ามเล่นเสียง "ถึงตาคุณแล้ว" เพราะเป็นตาคู่แข่ง! ให้แสดง/ได้ยินเฉพาะฝั่งคู่แข่งเท่านั้น เราจะไม่ได้ยิน
            this.hideMonopolyCenterRollStation(true);
            this.hideMonopolyTilePathMarkers();

            if (rollBtn) {
                if (this.isAutoMode) {
                    // ขณะติด AUTO อยู่ แม้เป็นตาคู่แข่ง ผู้เล่นก็สามารถแตะปุ่มเพื่อยกเลิก AUTO กลับมาเล่นเองในตาถัดไปได้ทันที
                    rollBtn.style.display = 'inline-flex';
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                } else {
                    rollBtn.style.display = 'none';
                    rollBtn.disabled = true;
                    rollBtn.classList.remove('auto-active');
                }
            }
            if (active.is_bot) {
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (this.isMonopolyBoardMode) {
                            // 🎲 แสดงอนิเมชันหลอดชาร์จพลังคู่แข่งบนการ์ด สไตล์ โหมดกระดาน 3D (แบบคลิป 1)
                            this.animateOpponentGaugeRoll(active);
                        } else {
                            this.rollDice();
                        }
                    }
                }, (document.hidden ? 400 : 700));
            }
        } else {
            // 🎯 ตาของเรา (Local Player) — รอให้คู่แข่งจบการตัดสินใจ/จ่ายค่าผ่านทางก่อน และเล่นเสียง "ถึงตาคุณแล้ว" เฉพาะรอบแรกปกติ
            // 🚫 หากเป็นการทอยดับเบิลครั้งที่ 2 หรือ ครั้งที่ 3 ไม่ต้องมีเสียง "ถึงตาคุณแล้ว"
            const isConsecutiveDoubleTurn = Boolean((active.consecutiveDoubles && active.consecutiveDoubles > 0) || (this.consecutiveDoubles && this.consecutiveDoubles > 0));
            const turnAudioKey = `${this.matchStartTime || 0}_${this.currentTurnIndex}_${this.totalTurnsPlayed || 0}`;
            const isBusyWaiting = Boolean(this._isApplyingRemoteAction || this.isRolling || this.isWaitingForCityAction || this.isWaitingForGamble || this.isWaitingForBoardPick);

            if (!isConsecutiveDoubleTurn && !isBusyWaiting && this._lastTurnAudioKey !== turnAudioKey) {
                this._lastTurnAudioKey = turnAudioKey;
                if (window.ThaiAudio && typeof window.ThaiAudio.playYourTurn === 'function') {
                    window.ThaiAudio.playYourTurn(false);
                }
            } else if (isConsecutiveDoubleTurn) {
                // แจ้งเตือนข้อความให้ทอยต่อ (เมื่อได้แต้มดับเบิลครั้งที่ 2 หรือ 3)
                if (typeof window.showToast === 'function') {
                    const rollNum = (active.consecutiveDoubles || this.consecutiveDoubles || 1) + 1;
                    window.showToast(`🔥 แต้มเบิ้ล! ทอยต่อครั้งที่ ${rollNum}`);
                }
            }

            // 🧭 สกิลอัญมณี: เริ่มเทิร์นสุ่มแสดงปุ่มเลือก "ทอยเดินหน้า / ทอยถอยหลัง"
            if (this.isMonopolyBoardMode && !isBusyWaiting && this._turnDirectionRolledKey !== turnAudioKey) {
                this._turnDirectionRolledKey = turnAudioKey;
                this._turnDirectionRolledThisTurn = true;
                this._turnDirectionSkillActive = false;
                this.turnRollDirection = 'FORWARD';
                this.hideTurnDirectionBar();
                const tGems = this.getPlayerEquippedGems(active);
                const tEff = this.aggregateGemEffects(tGems);
                if (tEff.forward_backward_move && (Math.random() * 100 < (tEff.forward_backward_rate || 50))) {
                    this._turnDirectionSkillActive = true;
                    this.showTurnDirectionBar();
                    const rateTxt = tEff.forward_backward_rate || 50;
                    const lvTxt = tEff.forward_backward_gem_level || 1;
                    const skTitle = tEff.forward_backward_name || 'เลือกทอยหน้า-หลัง';
                    this.showSkillBanner(`🧭✨ [อัญมณี Lv.${lvTxt} • ${rateTxt}%] สกิล "${skTitle}" ทำงาน! กดเลือก ทอยเดินหน้า หรือ ทอยถอยหลัง ได้เลย`);
                    this.logMessage(`🧭 [สกิลอัญมณี ${rateTxt}%] ${active.username} เปิดใช้ "${skTitle}" เลือกทิศทางเดินหน้า-ถอยหลังก่อนทอย!`, 'skill');
                }
            }

            if (this.isAutoMode) {
                // อยู่ในโหมด AUTO อยู่แล้ว -> เล่นต่อเนื่องอัตโนมัติจนกว่าผู้เล่นจะกดกลับมาเล่นเอง
                this.hideMonopolyCenterRollStation();
                this.hideMonopolyTilePathMarkers();
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                }
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, (document.hidden ? 400 : 900));
            } else {
                // โหมดเล่นเอง: แสดงปุ่มทอยกลมและปุ่มคู่/คี่กลางวงเวียนกระดาน พร้อมตัวเลข 1..12 มาร์คบนช่องเดิน (แบบคลิป 2)
                if (this.isMonopolyBoardMode) {
                    this.showMonopolyCenterRollStation();
                    this.updateDiceGaugeVisual(0.02);
                } else {
                    this.hideMonopolyCenterRollStation();
                    this.hideMonopolyTilePathMarkers();
                }

                // เริ่มนับถอยหลัง 20 วินาที (หากเกิน 20วิ ให้เปลี่ยนเป็นเล่น auto และทอยให้อัตโนมัติ)
                this.turnSecondsLeft = 20;
                const rollLabel = isConsecutiveDoubleTurn
                    ? `<span>🎲</span> ทอยต่อ <span class="roll-timer-badge">(20วิ)</span>`
                    : `<span>🎲</span> ทอย <span class="roll-timer-badge">(20วิ)</span>`;
                if (rollBtn) {
                    rollBtn.style.display = 'inline-flex';
                    rollBtn.disabled = false;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = rollLabel;
                }
                this.turnCountdownInterval = setInterval(() => {
                    if (this.isGaugeHolding) return;
                    if (!this.isMatchActive || this.isRolling || this.isGameOver || this.isWaitingForGamble || this.isWaitingForCityAction) {
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        return;
                    }
                    this.turnSecondsLeft--;
                    if (this.turnSecondsLeft > 0) {
                        if (rollBtn && !this.isAutoMode) {
                            const activeRollLabel = isConsecutiveDoubleTurn
                                ? `<span>🎲</span> ทอยต่อ <span class="roll-timer-badge">(${this.turnSecondsLeft}วิ)</span>`
                                : `<span>🎲</span> ทอย <span class="roll-timer-badge">(${this.turnSecondsLeft}วิ)</span>`;
                            rollBtn.innerHTML = activeRollLabel;
                        }
                    } else {
                        // เกิน 20 วินาทีไม่ได้กดทอย -> เปลี่ยนเป็นเล่น AUTO ทันที และทอยเต๋า
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        this.enableAutoMode(true);
                    }
                }, 1000);
            }
        }
    }

    enableAutoMode(triggerRollNow = false) {
        this.isAutoMode = true;
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        // หากกำลังเปิดหน้าต่างเลือกสร้างเมือง/แลนด์มาร์คค้างอยู่ ให้ตัดสินใจอัตโนมัติทันที
        if (this.isWaitingForCityAction && this.activeCityActionResolver) {
            this.closeCityActionPrompt(this.cityActionAutoChoice);
        }

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            rollBtn.disabled = false;
            rollBtn.classList.add('auto-active');
            rollBtn.style.opacity = '1';
            rollBtn.innerHTML = `<span>⚡</span> AUTO`;
        }

        this.logMessage('⚡ ระบบเปลี่ยนเป็นเล่นอัตโนมัติ (AUTO)', 'highlight');
        if (typeof this.showSkillBanner === 'function') {
            this.showSkillBanner('⚡ เข้าสู่โหมดเล่นอัตโนมัติ (AUTO)');
        }
        if (typeof window.showToast === 'function') {
            window.showToast('⚡ เข้าสู่โหมดเล่นอัตโนมัติ (AUTO)');
        }

        if (triggerRollNow) {
            const active = this.players[this.currentTurnIndex];
            if (active && this.isLocalPlayer(active) && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                this.rollDice(null, true);
            }
        }
    }

    disableAutoMode() {
        this.isAutoMode = false;
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        const rollBtn = document.getElementById('btn-roll-dice');
        const active = this.players ? this.players[this.currentTurnIndex] : null;
        if (rollBtn) {
            rollBtn.classList.remove('auto-active');
            if (!this.isMatchActive) {
                rollBtn.style.display = 'inline-flex';
                rollBtn.disabled = false;
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>🎲</span> ทอย`;
            } else if (active && !this.isLocalPlayer(active)) {
                rollBtn.style.display = 'none';
                rollBtn.disabled = true;
                rollBtn.style.opacity = '0.6';
                rollBtn.innerHTML = `<span>🎲</span> รอ...`;
            } else if (this.isRolling) {
                rollBtn.disabled = true;
                rollBtn.style.opacity = '0.7';
                rollBtn.innerHTML = `<span>🎲</span> เดิน...`;
            } else {
                rollBtn.style.display = 'inline-flex';
                rollBtn.disabled = false;
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>🎲</span> ทอย`;
            }
        }

        // 🚨 CRITICAL FIX: หากเป็นตาของบอทอยู่ ต้องตั้งเวลาให้บอททอยต่อทันที อย่าให้บอทค้าง!
        if (this.isMatchActive && active && active.is_bot && !this.isRolling && !this.isGameOver) {
            this.autoTurnTimeout = setTimeout(() => {
                if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                    this.rollDice();
                }
            }, 600);
        }

        this.logMessage('🎮 ยกเลิกโหมด AUTO กลับสู่การเล่นด้วยตนเอง', 'highlight');
        if (typeof this.showSkillBanner === 'function') {
            this.showSkillBanner('🎮 สลับกลับมาเล่นด้วยตนเองแล้ว!');
        }
        if (typeof window.showToast === 'function') {
            window.showToast('🎮 สลับกลับมาเล่นด้วยตนเองแล้ว!');
        }
    }

    toggleAutoMode() {
        if (!this.isMatchActive) {
            if (typeof window.showToast === 'function') {
                window.showToast('🎮 กรุณากดปุ่ม "ทอย" หรือเข้า "ห้องแข่งขัน" ก่อนเปิดโหมด AUTO');
            }
            return;
        }
        if (this.isAutoMode) {
            this._manualAutoMode = false;
            this.disableAutoMode();
            const active = this.players[this.currentTurnIndex];
            if (active && this.isLocalPlayer(active) && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                if (!this.isRolling && !this.isWaitingForCityAction && !this.isWaitingForGamble && !this.isWaitingForBoardPick) {
                    this.beginTurn();
                }
            }
        } else {
            this._manualAutoMode = true;
            this.enableAutoMode(false);
            const active = this.players[this.currentTurnIndex];
            if (active && this.isLocalPlayer(active) && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, 600);
            }
        }
    }

    updateAutoToggleUI() {
        const toggleBtn = document.getElementById('btn-auto-toggle');
        if (!toggleBtn) return;
        if (this.isMatchActive && this.isAutoMode) {
            toggleBtn.classList.add('active');
            toggleBtn.innerHTML = `<span>⚡</span> AUTO: เปิด`;
            toggleBtn.setAttribute('title', 'แตะเพื่อปิดโหมดเล่นอัตโนมัติ (กลับมาเล่นเอง)');
        } else {
            toggleBtn.classList.remove('active');
            toggleBtn.innerHTML = `<span>⚡</span> AUTO`;
            toggleBtn.setAttribute('title', this.isMatchActive ? 'แตะเพื่อเปิดโหมดเล่นอัตโนมัติ' : 'กดเริ่มเกมก่อนเพื่อใช้งานโหมดเล่นอัตโนมัติ');
        }
    }

    /**
     * ระบบสลับการใช้งานการ์ด คู่ / คี่ (Odd / Even Roll Control) สไตล์ โหมดกระดาน 3D
     */
    getOddEvenDiamondCost() {
        const cfg = (typeof window.getActiveRoomEconomyConfig === 'function')
            ? window.getActiveRoomEconomyConfig()
            : null;
        const raw = (this.matchConfig && this.matchConfig.odd_even_diamond_cost !== undefined)
            ? this.matchConfig.odd_even_diamond_cost
            : (cfg && cfg.odd_even_diamond_cost !== undefined ? cfg.odd_even_diamond_cost : 5);
        return Math.max(0, Number(raw) || 0);
    }

    async toggleOddEvenRoll(mode) {
        if (this.isRolling || this.isGameOver || !this.isMatchActive) return;
        const player = this.players ? this.players[this.currentTurnIndex] : null;
        if (!player || player.is_bot || !this.isLocalPlayer(player)) return;

        if (this.selectedOddEvenMode === mode) {
            this.selectedOddEvenMode = null;
            this.updateOddEvenButtonsUI();
            return;
        }

        const chargeKey = (mode === 'ODD') ? 'oddCharges' : 'evenCharges';
        if (player[chargeKey] === undefined) player[chargeKey] = 3;
        const charges = Number(player[chargeKey]) || 0;
        const labelTh = (mode === 'ODD') ? 'คี่' : 'คู่';

        if (charges <= 0) {
            if (this._buyingOddEvenCharge) return;
            const cost = this.getOddEvenDiamondCost();
            const isPractice = Boolean(window.isPracticeMatch);
            if (!isPractice && cost > 0) {
                const curDia = Number(window.DEFAULT_USER?.diamonds ?? window.DEFAULT_USER?.diamond ?? 0);
                if (curDia < cost) {
                    this.showSkillBanner(`💎 เพชรไม่พอ! ต้องใช้ ${cost} เพชรเพื่อซื้อสิทธิ์ [${labelTh}] เพิ่ม`);
                    if (typeof window.showToast === 'function') {
                        window.showToast(`💎 เพชรไม่พอ (ต้องการ ${cost} เพชร)`);
                    }
                    return;
                }
                this._buyingOddEvenCharge = true;
                try {
                    const tok = (window.apiClient && (typeof window.apiClient.getToken === 'function' ? window.apiClient.getToken() : window.apiClient.token)) || localStorage.getItem('snake_auth_token') || '';
                    const bUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
                    const tier = this.matchConfig?.room_tier || window.currentActiveRoomTier || '2M';
                    const res = await fetch(`${bUrl}api/matchmaking.php?action=buy_odd_even_charge`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', ...(tok ? { 'Authorization': 'Bearer ' + tok } : {}) },
                        body: JSON.stringify({ room_tier: tier })
                    }).then(r => r.json()).catch(() => null);
                    if (!res || res.status !== 'success') {
                        this.showSkillBanner(res?.message || `💎 เพชรไม่พอ (ต้องการ ${cost} เพชร)`);
                        return;
                    }
                    if (window.DEFAULT_USER) {
                        window.DEFAULT_USER.diamonds = Number(res.diamond ?? (curDia - cost));
                        window.DEFAULT_USER.diamond = window.DEFAULT_USER.diamonds;
                    }
                    if (typeof window.updateLobbyCurrencyHUD === 'function') {
                        window.updateLobbyCurrencyHUD();
                    }
                    player[chargeKey] = 1;
                    this.logMessage(`💎 ${player.username} ใช้ ${cost} เพชร ซื้อสิทธิ์การ์ด [${labelTh}] เพิ่ม 1 ครั้ง!`, 'highlight');
                } finally {
                    this._buyingOddEvenCharge = false;
                }
            } else if (isPractice) {
                player[chargeKey] = 1;
            } else {
                player[chargeKey] = 1;
            }
        }

        this.selectedOddEvenMode = mode;
        this.showSkillBanner(`🎯 เปิดใช้การ์ด [${labelTh}]! บังคับออกแต้ม${labelTh}ในรอบนี้`);
        try {
            if (window.soundEngine && typeof window.soundEngine.playCoins === 'function') {
                window.soundEngine.playCoins();
            }
        } catch (e) { }
        this.updateOddEvenButtonsUI();
    }

    updateMonopolyExclusiveUI() {
        const gaugePanel = document.getElementById('dice-gauge-panel');
        const btnOdd = document.getElementById('btn-dice-odd');
        const btnEven = document.getElementById('btn-dice-even');
        const centerBadge = document.getElementById('dice-center-outcome-badge');
        const holdCountdown = document.getElementById('roll-hold-countdown');
        const rollBtn = document.getElementById('btn-roll-dice');

        if (this.isMonopolyBoardMode) {
            if (gaugePanel) gaugePanel.style.display = 'none';
            const active = this.players ? this.players[this.currentTurnIndex] : null;
            const isMyActiveTurn = Boolean(this.isMatchActive && active && this.isLocalPlayer(active) && !this.isRolling && !this.isGameOver && !this.isAutoMode);
            if (btnOdd) btnOdd.style.display = (this.isMatchActive && !this.isGameOver) ? 'inline-flex' : 'none';
            if (btnEven) btnEven.style.display = (this.isMatchActive && !this.isGameOver) ? 'inline-flex' : 'none';
            if (rollBtn) {
                rollBtn.title = 'กดค้างเพื่อวิ่งหลอดพลังทอยเต๋า (ปล่อยเพื่อทอย / ครบ 15 วิ ทอยอัตโนมัติ)';
            }
            this.updateOddEvenButtonsUI();
            if (isMyActiveTurn) {
                this.showMonopolyCenterRollStation();
                this.updateDiceGaugeVisual(0.02);
            } else {
                this.hideMonopolyCenterRollStation();
            }
        } else {
            // 🐍 โหมดบันไดงู: ซ่อนหลอดเกจโค้ง, ปุ่มคู่/คี่, ป้ายตัวเลขกึ่งกลางกระดาน, และตัวนับถอยหลังกดค้าง
            if (gaugePanel) gaugePanel.style.display = 'none';
            if (btnOdd) btnOdd.style.display = 'none';
            if (btnEven) btnEven.style.display = 'none';
            if (centerBadge) centerBadge.style.display = 'none';
            if (holdCountdown) holdCountdown.style.display = 'none';
            this.hideMonopolyCenterRollStation();
            this.hideMonopolyTilePathMarkers();
            if (rollBtn) {
                rollBtn.title = 'ทอยลูกเต๋า';
            }
            this.selectedOddEvenMode = null;
        }
    }

    updateOddEvenButtonsUI() {
        if (!this.isMonopolyBoardMode) {
            const btnOdd = document.getElementById('btn-dice-odd');
            const btnEven = document.getElementById('btn-dice-even');
            if (btnOdd) btnOdd.style.display = 'none';
            if (btnEven) btnEven.style.display = 'none';
            return;
        }
        const btnOdd = document.getElementById('btn-dice-odd');
        const btnEven = document.getElementById('btn-dice-even');
        if (btnOdd) btnOdd.style.display = (this.isMatchActive && !this.isGameOver) ? 'inline-flex' : 'none';
        if (btnEven) btnEven.style.display = (this.isMatchActive && !this.isGameOver) ? 'inline-flex' : 'none';
        const badgeOdd = document.getElementById('badge-odd-count');
        const badgeEven = document.getElementById('badge-even-count');

        const centerBtnOdd = document.getElementById('btn-center-odd');
        const centerBtnEven = document.getElementById('btn-center-even');
        const centerBadgeOdd = document.getElementById('center-badge-odd-count');
        const centerBadgeEven = document.getElementById('center-badge-even-count');

        const activePlayer = (this.players && this.players[this.currentTurnIndex]) || null;
        const localPlayer = (this.players && this.players.find(p => this.isLocalPlayer(p))) || activePlayer;
        const isMyTurn = Boolean(this.isMatchActive && activePlayer && this.isLocalPlayer(activePlayer) && !this.isRolling && !this.isGameOver);
        const oddCount = localPlayer ? ((localPlayer.oddCharges !== undefined) ? localPlayer.oddCharges : 3) : 3;
        const evenCount = localPlayer ? ((localPlayer.evenCharges !== undefined) ? localPlayer.evenCharges : 3) : 3;
        const diaCost = this.getOddEvenDiamondCost();

        const updateBadge = (el, cnt) => {
            if (!el) return;
            if (cnt > 0) {
                el.innerText = cnt;
                el.classList.remove('is-diamond');
            } else {
                el.innerText = diaCost > 0 ? `💎${diaCost}` : '0';
                el.classList.add('is-diamond');
            }
        };
        updateBadge(badgeOdd, oddCount);
        updateBadge(badgeEven, evenCount);
        updateBadge(centerBadgeOdd, oddCount);
        updateBadge(centerBadgeEven, evenCount);

        const isOddActive = isMyTurn && (this.selectedOddEvenMode === 'ODD');
        const isEvenActive = isMyTurn && (this.selectedOddEvenMode === 'EVEN');

        if (btnOdd) {
            btnOdd.classList.toggle('active', isOddActive);
            btnOdd.disabled = !isMyTurn;
        }
        if (centerBtnOdd) {
            centerBtnOdd.classList.toggle('active', isOddActive);
            centerBtnOdd.disabled = !isMyTurn;
        }

        if (btnEven) {
            btnEven.classList.toggle('active', isEvenActive);
            btnEven.disabled = !isMyTurn;
        }
        if (centerBtnEven) {
            centerBtnEven.classList.toggle('active', isEvenActive);
            centerBtnEven.disabled = !isMyTurn;
        }

        // กรองการแสดงตัวเลข 1..12 บนช่องกระดาน หากเลือกโหมดคี่ หรือ คู่
        const markerContainer = document.getElementById('monopoly-tile-path-markers');
        if (markerContainer) {
            const pills = markerContainer.getElementsByClassName('monopoly-tile-step-pill');
            for (let i = 0; i < pills.length; i++) {
                const pill = pills[i];
                const step = i + 1;
                if (isOddActive && step % 2 === 0) {
                    pill.classList.add('is-dimmed');
                } else if (isEvenActive && step % 2 !== 0) {
                    pill.classList.add('is-dimmed');
                } else {
                    pill.classList.remove('is-dimmed');
                }
            }
        }
    }

    showMonopolyCenterRollStation() {
        if (!this.isMonopolyBoardMode || this.isRolling || this.isGameOver || !this.isMatchActive || this.isWaitingForBoardPick) return;
        const active = this.players ? this.players[this.currentTurnIndex] : null;
        if (!active || !this.isLocalPlayer(active)) return;

        // แสดงสถานีทอยพร้อมหลอดเกจโค้งกลางกระดาน (สไตล์ โหมดกระดาน 3D แบบรูป 1 & 2) เฉพาะตาเรา
        const station = document.getElementById('monopoly-center-roll-station');
        if (station) {
            station.style.display = 'flex';
            this.updateOddEvenButtonsUI();
            this.updateMonopolyCenterRollStationPosition();
            this.updateDiceGaugeVisual(0);
        }
        this.showMonopolyTilePathMarkers();
    }

    hideMonopolyCenterRollStation(force = false) {
        if (!force && this._keepRollStationUntil && Date.now() < this._keepRollStationUntil) {
            return;
        }
        const station = document.getElementById('monopoly-center-roll-station');
        if (station) {
            station.style.display = 'none';
        }
        this.hideMonopolyTilePathMarkers();
    }

    showMonopolyTilePathMarkers() {
        if (!this.isMonopolyBoardMode || !this.isMatchActive || this.isRolling || this.isGameOver || this.isWaitingForBoardPick || this.isAutoMode) {
            this.hideMonopolyTilePathMarkers();
            return;
        }
        const active = this.players ? this.players[this.currentTurnIndex] : null;
        if (!active || !this.isLocalPlayer(active) || (active.jailTurns || 0) > 0) {
            this.hideMonopolyTilePathMarkers();
            return;
        }

        const container = document.getElementById('monopoly-tile-path-markers');
        if (!container) return;

        const curTile = Number(active.currentTile || 1);
        let html = '';
        for (let step = 1; step <= 12; step++) {
            const targetTile = ((curTile - 1 + step) % 32) + 1;
            html += `<div class="monopoly-tile-step-pill" id="monopoly-step-pill-${step}" data-tile="${targetTile}">${step}</div>`;
        }
        container.innerHTML = html;
        container.style.display = 'block';
        this.updateMonopolyTilePathMarkerPositions();
        this.updateOddEvenButtonsUI();
    }

    hideMonopolyTilePathMarkers() {
        const container = document.getElementById('monopoly-tile-path-markers');
        if (container) {
            container.style.display = 'none';
            container.innerHTML = '';
        }
    }

    updateMonopolyTilePathMarkerPositions() {
        const container = document.getElementById('monopoly-tile-path-markers');
        if (!container || container.style.display === 'none' || !this.camera || !this.renderer) return;

        const rect = this.renderer.domElement.getBoundingClientRect();
        const pills = container.getElementsByClassName('monopoly-tile-step-pill');
        for (let i = 0; i < pills.length; i++) {
            const pill = pills[i];
            const tileNum = Number(pill.getAttribute('data-tile'));
            if (tileNum && this.tiles && this.tiles[tileNum]) {
                const t = this.tiles[tileNum];
                const v = new THREE.Vector3(t.x, (t.y || 0) + 1.2, t.z);
                v.project(this.camera);
                if (v.z < 1) {
                    const sx = ((v.x + 1) * 0.5) * rect.width + rect.left;
                    const sy = ((-v.y + 1) * 0.5) * rect.height + rect.top;
                    pill.style.left = `${sx}px`;
                    pill.style.top = `${sy}px`;
                    pill.style.display = 'flex';
                } else {
                    pill.style.display = 'none';
                }
            }
        }
    }

    updateMonopolyCenterRollStationPosition() {
        const station = document.getElementById('monopoly-center-roll-station');
        if (!station || station.style.display === 'none' || !this.camera || !this.renderer) return;

        const rect = this.renderer.domElement.getBoundingClientRect();
        const v = new THREE.Vector3(0, 0.5, 0);
        v.project(this.camera);
        if (v.z < 1) {
            const sx = ((v.x + 1) * 0.5) * rect.width + rect.left;
            const sy = ((-v.y + 1) * 0.5) * rect.height + rect.top;
            station.style.left = `${sx}px`;
            station.style.top = `${sy}px`;
        }
    }

    startDiceCharge(e) {
        if (!this.isMonopolyBoardMode) return;
        if (this.isRolling || this.isWaitingForBoardPick || this.isGameOver || !this.isMatchActive) return;
        const player = this.players ? this.players[this.currentTurnIndex] : null;
        if (!player || !this.isLocalPlayer(player)) return;

        if (e) {
            if (typeof e.stopPropagation === 'function') e.stopPropagation();
            if (e.type && (e.type.startsWith('touch') || e.type.startsWith('pointer')) && typeof e.preventDefault === 'function') {
                e.preventDefault();
            }
        }

        if (this.isAutoMode) {
            this.toggleAutoMode();
            return;
        }

        if (player.jailTurns > 0) {
            if (typeof window.openJailModal === 'function') {
                window.openJailModal(player);
            }
            return;
        }

        if (this.isGaugeHolding) return;
        this.isGaugeHolding = true;
        this.gaugeHoldStartTime = performance.now();

        let myIndex = this.getLocalPlayerIndex();
        if (myIndex === -1) myIndex = 0;

        this.showMonopolyCenterRollStation();
        this.updateDiceGaugeVisual(0.02);

        const centerRollBtn = document.getElementById('btn-center-roll');
        if (centerRollBtn) centerRollBtn.classList.add('is-pressed');
        const chargeStation = document.getElementById('monopoly-center-roll-station');
        if (chargeStation) chargeStation.classList.add('is-charging');

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) rollBtn.classList.add('is-pressed');

        const gaugeFill = document.getElementById(`lgr-gauge-fill-${myIndex}`);

        // Speed: 850ms per sweep (วิ่งไป-กลับลื่นไหลชัดเจนจนกว่าจะปล่อยปุ่มทอย)
        const sweepPeriod = 850;

        let remainingSec = 15;
        const timerEl = document.getElementById('center-roll-timer');
        const rpTimerEl = document.getElementById('rp-gauge-timer');
        const holdCountdownEl = document.getElementById('roll-hold-countdown');
        const bottomTimerBadge = rollBtn ? rollBtn.querySelector('.roll-timer-badge') : null;
        if (timerEl) {
            timerEl.innerText = `${remainingSec}s`;
            timerEl.style.display = 'inline-block';
        }
        if (rpTimerEl) {
            rpTimerEl.innerText = `⏱️ ${remainingSec}วิ`;
            rpTimerEl.style.display = 'inline-block';
        }
        if (holdCountdownEl) {
            holdCountdownEl.innerText = `${remainingSec}s`;
            holdCountdownEl.style.display = 'inline-block';
        }
        if (bottomTimerBadge) {
            bottomTimerBadge.innerText = `(${remainingSec}วิ)`;
        }

        if (this.gaugeHoldTimeoutInterval) clearInterval(this.gaugeHoldTimeoutInterval);
        this.gaugeHoldTimeoutInterval = setInterval(() => {
            remainingSec--;
            const secClamped = Math.max(0, remainingSec);
            if (timerEl) timerEl.innerText = `${secClamped}s`;
            if (rpTimerEl) rpTimerEl.innerText = `⏱️ ${secClamped}วิ`;
            if (holdCountdownEl) holdCountdownEl.innerText = `${secClamped}s`;
            if (bottomTimerBadge) bottomTimerBadge.innerText = `(${secClamped}วิ)`;
            if (remainingSec <= 0) {
                this.stopDiceCharge(null, true);
            }
        }, 1000);

        const updateChargeFrame = () => {
            if (!this.isGaugeHolding) return false;
            const gaugeElapsed = Math.max(0, performance.now() - this.gaugeHoldStartTime);

            // Ping-pong: ไปถึงสุดหลอดแล้วย้อนกลับไปมาตลอดเวลาจนกว่าจะปล่อยปุ่มทอย
            const phase = (gaugeElapsed % (sweepPeriod * 2)) / sweepPeriod;
            const progress = phase <= 1 ? phase : (2 - phase);

            this.currentDiceProgress = progress;

            let seg = 1;
            if (progress < 0.25) seg = 1;
            else if (progress < 0.50) seg = 2;
            else if (progress < 0.75) seg = 3;
            else seg = 4;
            this.currentDiceSegment = seg;

            if (gaugeFill) {
                gaugeFill.style.width = `${(progress * 100).toFixed(1)}%`;
            }

            this.updateDiceGaugeVisual(progress);
            return true;
        };

        const loop = () => {
            if (!updateChargeFrame()) return;
            this.diceChargeAnimId = requestAnimationFrame(loop);
        };

        if (this.diceChargeAnimId) cancelAnimationFrame(this.diceChargeAnimId);
        if (this._diceChargeFallbackInterval) clearInterval(this._diceChargeFallbackInterval);
        this._diceChargeFallbackInterval = setInterval(updateChargeFrame, 16);
        this.diceChargeAnimId = requestAnimationFrame(loop);
    }

    stopDiceCharge(e, isTimeoutAuto = false) {
        if (!this.isGaugeHolding) return;
        this.isGaugeHolding = false;

        if (this._diceChargeFallbackInterval) {
            clearInterval(this._diceChargeFallbackInterval);
            this._diceChargeFallbackInterval = null;
        }

        if (this.diceChargeAnimId) {
            cancelAnimationFrame(this.diceChargeAnimId);
            this.diceChargeAnimId = null;
        }
        if (this.gaugeHoldTimeoutInterval) {
            clearInterval(this.gaugeHoldTimeoutInterval);
            this.gaugeHoldTimeoutInterval = null;
        }

        const centerRollBtn = document.getElementById('btn-center-roll');
        if (centerRollBtn) centerRollBtn.classList.remove('is-pressed');
        const chargeStationEnd = document.getElementById('monopoly-center-roll-station');
        if (chargeStationEnd) chargeStationEnd.classList.remove('is-charging');

        this._lastGaugeReleaseTime = Date.now();
        const timerEl = document.getElementById('center-roll-timer');
        if (timerEl) timerEl.style.display = 'none';
        const rpTimerEl = document.getElementById('rp-gauge-timer');
        if (rpTimerEl) rpTimerEl.style.display = 'none';
        const holdCountdownEl = document.getElementById('roll-hold-countdown');
        if (holdCountdownEl) holdCountdownEl.style.display = 'none';

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) rollBtn.classList.remove('is-pressed');

        let myIndex = this.getLocalPlayerIndex();
        if (myIndex === -1) myIndex = 0;

        const cardGaugeWrap = document.getElementById(`lgr-gauge-card-${myIndex}`);
        if (cardGaugeWrap) {
            cardGaugeWrap.classList.add('gauge-flash');
            setTimeout(() => {
                if (cardGaugeWrap) {
                    cardGaugeWrap.classList.remove('is-charging');
                    cardGaugeWrap.classList.remove('gauge-flash');
                    const fill = document.getElementById(`lgr-gauge-fill-${myIndex}`);
                    if (fill) fill.style.width = '0%';
                }
            }, 300);
        }

        if (isTimeoutAuto) {
            this.hideMonopolyCenterRollStation();
            this.enableAutoMode(false);
            this.showSkillBanner('⏳ กดค้างเกิน 15 วิ! ระบบทอยเต๋าและเปิดโหมด AUTO อัตโนมัติ');
            this.rollDiceFromGauge(this.currentDiceSegment || 2, true);
        } else {
            const pressElapsed = performance.now() - (this.gaugeHoldStartTime || 0);
            const isQuickTap = (pressElapsed < 130);
            const targetSegment = isQuickTap ? (Math.floor(Math.random() * 4) + 1) : (this.currentDiceSegment || 2);
            const visualProg = isQuickTap ? ((targetSegment - 0.5) * 0.25) : (this.currentDiceProgress || 0.35);

            // แสดงเอฟเฟ็คหลอดพุ่งไปที่ตำแหน่งพลังทอยให้เห็นชัดเจนก่อนปิดหลอด
            const stationEl = document.getElementById('monopoly-center-roll-station');
            if (stationEl) {
                stationEl.style.display = 'flex';
                stationEl.classList.add('is-charging');
            }
            const rpFillEl = document.getElementById('rp-gauge-fill');
            if (rpFillEl) {
                rpFillEl.style.transition = isQuickTap ? 'width 0.22s ease-out' : 'none';
                if (isQuickTap) void rpFillEl.offsetWidth;
            }
            this._keepRollStationUntil = Date.now() + 380;
            this.updateDiceGaugeVisual(visualProg);

            setTimeout(() => {
                this._keepRollStationUntil = 0;
                if (rpFillEl) rpFillEl.style.transition = 'none';
                if (stationEl) stationEl.classList.remove('is-charging');
                this.hideMonopolyCenterRollStation(true);
            }, 400);

            this.rollDiceFromGauge(targetSegment, false);
        }
    }

    animateOpponentGaugeRoll(opponent) {
        if (!this.isMonopolyBoardMode || this.isRolling || this.isGameOver || !this.isMatchActive) return;
        const oppIdx = this.players.indexOf(opponent);
        const cardGaugeWrap = document.getElementById(`lgr-gauge-card-${oppIdx >= 0 ? oppIdx : 0}`);
        const gaugeFill = document.getElementById(`lgr-gauge-fill-${oppIdx >= 0 ? oppIdx : 0}`);

        if (cardGaugeWrap) cardGaugeWrap.classList.add('is-charging');
        const stationEl = document.getElementById('monopoly-center-roll-station');
        if (stationEl) {
            stationEl.style.display = 'flex';
            stationEl.classList.add('is-charging');
            this.updateMonopolyCenterRollStationPosition();
        }

        const targetProg = 0.35 + Math.random() * 0.52;
        const chargeDuration = 700 + Math.random() * 300;
        const startTime = performance.now();

        const oppLoop = (now) => {
            const oppElapsed = now - startTime;
            const p = Math.min(1, oppElapsed / chargeDuration);
            const cur = p * targetProg;

            if (gaugeFill) {
                gaugeFill.style.width = `${(cur * 100).toFixed(1)}%`;
            }
            this.updateDiceGaugeVisual(cur);

            if (p < 1) {
                requestAnimationFrame(oppLoop);
            } else {
                if (cardGaugeWrap) {
                    cardGaugeWrap.classList.add('gauge-flash');
                    setTimeout(() => {
                        if (cardGaugeWrap) {
                            cardGaugeWrap.classList.remove('is-charging');
                            cardGaugeWrap.classList.remove('gauge-flash');
                            if (gaugeFill) gaugeFill.style.width = '0%';
                        }
                    }, 300);
                }
                this._keepRollStationUntil = Date.now() + 210;
                setTimeout(() => {
                    this._keepRollStationUntil = 0;
                    if (stationEl) stationEl.classList.remove('is-charging');
                    this.hideMonopolyCenterRollStation(true);
                }, 220);

                let seg = 1;
                if (targetProg < 0.25) seg = 1;
                else if (targetProg < 0.50) seg = 2;
                else if (targetProg < 0.75) seg = 3;
                else seg = 4;

                this.rollDiceFromGauge(seg, false);
            }
        };

        requestAnimationFrame(oppLoop);
    }

    updateDiceGaugeVisual(progress) {
        const clampedProg = Math.max(0, Math.min(1, progress));

        // 🎯 หลอดพลังทอยใหม่ (แนวนอน) กลางกระดาน — ใช้ GPU transform (scaleX + translate3d) เพื่อลื่นไหล 60fps บน iOS
        const rpFill = document.getElementById('rp-gauge-fill');
        const rpRunner = document.getElementById('rp-gauge-runner');
        const rpRange = document.getElementById('rp-gauge-range');
        const scaleVal = clampedProg.toFixed(4);
        if (rpFill) {
            rpFill.style.webkitTransform = `scaleX(${scaleVal}) translateZ(0)`;
            rpFill.style.transform = `scaleX(${scaleVal}) translateZ(0)`;
        }
        if (rpRunner) {
            const trackW = (rpRunner.parentElement && rpRunner.parentElement.clientWidth) ? rpRunner.parentElement.clientWidth : 244;
            const runnerX = (trackW * clampedProg).toFixed(1);
            rpRunner.style.webkitTransform = `translate3d(${runnerX}px, 0, 0)`;
            rpRunner.style.transform = `translate3d(${runnerX}px, 0, 0)`;
        }
        const rpSeg = clampedProg < 0.25 ? 1 : (clampedProg < 0.5 ? 2 : (clampedProg < 0.75 ? 3 : 4));
        const rpLabels = { 1: 'ช่อง 2-3', 2: 'ช่อง 4-6', 3: 'ช่อง 7-9', 4: 'ช่อง 10-12' };
        if (rpRange) rpRange.textContent = rpLabels[rpSeg];
        for (let z = 1; z <= 4; z++) {
            const zEl = document.getElementById('rp-zone-' + z);
            if (zEl) zEl.classList.toggle('active', z === rpSeg);
        }

        // 🌟 1. Center Curved Arc Gauge สไตล์ โหมดกระดาน 3D (แบบรูป 1 & 2 ตรงกลางกระดาน)
        const centerFill = document.getElementById('center-gauge-fill-path');
        const centerMaxLen = 230;
        if (centerFill) {
            centerFill.style.strokeDashoffset = `${centerMaxLen * (1 - clampedProg)}`;
        }

        const centerFlare = document.getElementById('center-gauge-flare');
        if (centerFlare) {
            if (clampedProg <= 0.01) {
                centerFlare.style.display = 'none';
            } else {
                centerFlare.style.display = 'block';
                const t = clampedProg;
                const cx = (1 - t) * (1 - t) * 24 + 2 * (1 - t) * t * 130 + t * t * 236;
                const cy = (1 - t) * (1 - t) * 54 + 2 * (1 - t) * t * 12 + t * t * 54;
                centerFlare.setAttribute('cx', cx.toFixed(1));
                centerFlare.setAttribute('cy', cy.toFixed(1));
            }
        }

        const num4 = document.getElementById('center-gauge-num-4');
        const num7 = document.getElementById('center-gauge-num-7');
        const num10 = document.getElementById('center-gauge-num-10');
        if (num4) {
            if (clampedProg >= 0.25) num4.classList.add('active');
            else num4.classList.remove('active');
        }
        if (num7) {
            if (clampedProg >= 0.50) num7.classList.add('active');
            else num7.classList.remove('active');
        }
        if (num10) {
            if (clampedProg >= 0.75) num10.classList.add('active');
            else num10.classList.remove('active');
        }

        // 2. Legacy Bottom Gauge (เผื่อเปิดใช้งาน)
        const fillPath = document.getElementById('gauge-fill-path');
        const highlightG = document.getElementById('gauge-active-highlight');
        const rectEl = document.getElementById('gauge-highlight-rect');
        const flareEl = document.getElementById('gauge-highlight-flare');

        const maxLen = 236;
        const currentLen = clampedProg * maxLen;

        if (fillPath) {
            fillPath.style.strokeDashoffset = `${maxLen - currentLen}`;
        }

        // กำหนดตำแหน่งโซน 1..4 (2-3, 4-6, 7-9, 10-12)
        let segment = 1;
        if (clampedProg < 0.25) segment = 1;      // 2-3
        else if (clampedProg < 0.50) segment = 2; // 4-6
        else if (clampedProg < 0.75) segment = 3; // 7-9
        else segment = 4;                         // 10-12

        this.gaugeCurrentSegment = segment;
        this.gaugeCurrentProgress = clampedProg;

        // พิกัดกรอบไฮไลต์และประกายแสงสำหรับ 4 โซน
        const segPositions = {
            1: { x: 14, y: 22, w: 54, h: 26, fx: 43, fy: 32 },
            2: { x: 72, y: 10, w: 58, h: 28, fx: 101, fy: 24 },
            3: { x: 130, y: 10, w: 58, h: 28, fx: 159, fy: 24 },
            4: { x: 188, y: 22, w: 56, h: 26, fx: 217, fy: 32 }
        };

        const pos = segPositions[segment];
        if (highlightG && pos) {
            highlightG.style.display = 'block';
            if (rectEl) {
                rectEl.setAttribute('x', pos.x);
                rectEl.setAttribute('y', pos.y);
                rectEl.setAttribute('width', pos.w);
                rectEl.setAttribute('height', pos.h);
            }
            if (flareEl) {
                flareEl.setAttribute('cx', pos.fx);
                flareEl.setAttribute('cy', pos.fy);
            }
        }

        // ไฮไลต์ข้อความตัวเลข 4 โซน
        for (let s = 1; s <= 4; s++) {
            const lbl = document.getElementById(`gauge-lbl-${s}`);
            if (lbl) {
                if (s === segment) {
                    lbl.classList.add('active');
                } else {
                    lbl.classList.remove('active');
                }
            }
        }

        return segment;
    }

    initDiceHoldChargeHandlers() {
        if (this._diceGaugeHandlersInit) return;
        this._diceGaugeHandlersInit = true;

        const centerRollBtn = document.getElementById('btn-center-roll');
        const centerGaugeWrapper = document.getElementById('monopoly-center-gauge-wrapper');
        const rollBtn = document.getElementById('btn-roll-dice');
        const gaugePanel = document.getElementById('dice-gauge-panel');

        const onDown = (e) => {
            if (e && (e.type === 'touchstart' || (e.type === 'pointerdown' && e.pointerType === 'touch'))) {
                this._activeTouchCharge = true;
            }
            this.startDiceCharge(e);
        };
        const onUp = (e) => {
            if (e && e.type === 'pointercancel' && (this._activeTouchCharge || e.pointerType === 'touch')) return;
            if (e && e.type === 'touchcancel' && this.isGaugeHolding && (performance.now() - (this.gaugeHoldStartTime || 0)) < 250) return;
            if (e && (e.type === 'touchend' || e.type === 'touchcancel' || (e.type === 'pointerup' && e.pointerType === 'touch'))) {
                this._activeTouchCharge = false;
            }
            this.stopDiceCharge(e);
        };
        const preventCtx = (e) => { if (e && typeof e.preventDefault === 'function') e.preventDefault(); };

        if (centerRollBtn) {
            centerRollBtn.addEventListener('pointerdown', onDown, { passive: false });
            centerRollBtn.addEventListener('touchstart', onDown, { passive: false });
            centerRollBtn.addEventListener('mousedown', onDown);
            centerRollBtn.addEventListener('contextmenu', preventCtx);
        }
        if (centerGaugeWrapper) {
            centerGaugeWrapper.addEventListener('pointerdown', onDown, { passive: false });
            centerGaugeWrapper.addEventListener('touchstart', onDown, { passive: false });
            centerGaugeWrapper.addEventListener('mousedown', onDown);
            centerGaugeWrapper.addEventListener('contextmenu', preventCtx);
        }
        if (rollBtn) {
            rollBtn.addEventListener('pointerdown', onDown, { passive: false });
            rollBtn.addEventListener('touchstart', onDown, { passive: false });
            rollBtn.addEventListener('mousedown', onDown);
            rollBtn.addEventListener('contextmenu', preventCtx);
        }
        if (gaugePanel) {
            gaugePanel.addEventListener('pointerdown', onDown, { passive: false });
            gaugePanel.addEventListener('touchstart', onDown, { passive: false });
            gaugePanel.addEventListener('mousedown', onDown);
            gaugePanel.addEventListener('contextmenu', preventCtx);
        }

        window.addEventListener('pointerup', onUp);
        window.addEventListener('pointercancel', onUp);
        window.addEventListener('touchend', onUp);
        window.addEventListener('touchcancel', onUp);
        window.addEventListener('mouseup', onUp);

        // รีเซ็ตเกจให้แสดงโซน 2 (4-6) เป็นค่าเริ่มต้น
        this.updateDiceGaugeVisual(0.35);
        this.updateMonopolyExclusiveUI();
    }

    rollDiceFromGauge(segmentIdx, isAuto = false) {
        if (this.isRolling || this.isWaitingForBoardPick || this.isGameOver || !this.isMatchActive) return;
        this.hideMonopolyCenterRollStation();
        this.hideMonopolyTilePathMarkers();

        const segRanges = {
            1: [2, 3],
            2: [4, 5, 6],
            3: [7, 8, 9],
            4: [10, 11, 12]
        };

        let candidateSums = segRanges[segmentIdx] || [4, 5, 6];
        const mode = this.selectedOddEvenMode;
        const player = this.players ? this.players[this.currentTurnIndex] : null;

        if (mode && player) {
            if (mode === 'ODD') {
                const oddCandidates = candidateSums.filter(s => s % 2 !== 0);
                if (oddCandidates.length > 0) candidateSums = oddCandidates;
                player.oddCharges = Math.max(0, ((player.oddCharges !== undefined) ? player.oddCharges : 3) - 1);
                this.showSkillBanner(`🎯✨ [การ์ดคี่ทำงาน!] ${player.username} บังคับทอยออกแต้มคี่! (เหลือฟรี ${player.oddCharges} ครั้ง)`);
                this.logMessage(`🎯 ${player.username} ใช้สิทธิ์การ์ด [คี่] (เหลือ ${player.oddCharges} ครั้ง)`, 'skill');
            } else if (mode === 'EVEN') {
                const evenCandidates = candidateSums.filter(s => s % 2 === 0);
                if (evenCandidates.length > 0) candidateSums = evenCandidates;
                player.evenCharges = Math.max(0, ((player.evenCharges !== undefined) ? player.evenCharges : 3) - 1);
                this.showSkillBanner(`✨💎 [การ์ดคู่ทำงาน!] ${player.username} บังคับทอยออกแต้มคู่! (เหลือฟรี ${player.evenCharges} ครั้ง)`);
                this.logMessage(`🎯 ${player.username} ใช้สิทธิ์การ์ด [คู่] (เหลือ ${player.evenCharges} ครั้ง)`, 'skill');
            }
            try {
                if (window.soundEngine && typeof window.soundEngine.playCardRevealZap === 'function') {
                    window.soundEngine.playCardRevealZap('zap_classic', false, 0.75);
                }
            } catch (e) { }
            this.selectedOddEvenMode = null;
            this.updateOddEvenButtonsUI();
        }

        // สุ่มเลือกผลรวมแต้มจากตัวเลือกที่เป็นไปได้
        const chosenSum = candidateSums[Math.floor(Math.random() * candidateSums.length)];

        // แยกแต้มออกเป็นลูกเต๋า 2 ลูก (d1, d2)
        const validPairs = [];
        for (let a = 1; a <= 6; a++) {
            const b = chosenSum - a;
            if (b >= 1 && b <= 6) {
                validPairs.push([a, b]);
            }
        }

        let chosenPair = validPairs[Math.floor(Math.random() * validPairs.length)];
        // โอกาส 40% ที่จะติดดับเบิ้ลหากผลรวมเป็นเลขคู่
        if (chosenSum % 2 === 0 && Math.random() < 0.40) {
            const dbl = validPairs.find(([a, b]) => a === b);
            if (dbl) chosenPair = dbl;
        }

        this.rollDice(chosenPair, isAuto);
    }

    handleRollButtonClick() {
        if (window.ThaiAudio && typeof window.ThaiAudio.unlock === 'function') {
            window.ThaiAudio.unlock();
        }
        if (!this.isMatchActive) {
            if (typeof window.openPracticeBoardSelectModal === 'function') {
                window.openPracticeBoardSelectModal();
            } else if (typeof window.startExplicitPracticeMatch === 'function') {
                window.startExplicitPracticeMatch();
            }
            return;
        }

        // 🚨 Watchdog / stuck recovery: หากผู้เล่นกดปุ่มทอย แล้วพบว่าสถานะทอยค้างโดยไม่มีการหมุนเต๋า ให้ปลดล็อคทันที
        if (this.isRolling && !this.isDiceTumbling) {
            console.warn('Force clearing stuck isRolling on player button click');
            this.isRolling = false;
        }

        const active = this.players[this.currentTurnIndex];
        if (active && active.jailTurns > 0 && this.isLocalPlayer(active) && !this.isAutoMode) {
            // หากติดเกาะร้างอยู่ เมื่อกดปุ่มทอย ให้เปิด popup เกาะร้าง
            if (typeof window.openJailModal === 'function') {
                window.openJailModal(active);
            }
            return;
        }

        if (this.isAutoMode) {
            // ผู้เล่นกลับมาเล่นแล้วกดปุ่มเพื่อเล่น -> ยกเลิก AUTO
            this.disableAutoMode();
            const activeNow = this.players[this.currentTurnIndex];
            if (activeNow && this.isLocalPlayer(activeNow) && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                this.rollDice();
            } else if (activeNow && !this.isLocalPlayer(activeNow)) {
                if (typeof window.showToast === 'function') {
                    window.showToast('🎮 กำลังรอคู่แข่ง จะกลับมาเล่นเองในตาของคุณทันที!');
                }
            }
            return;
        }

        if (this.isMonopolyBoardMode) {
            // โหมดเกมส์เศรษฐี: ถ้าเพิ่งปล่อยปุ่มชาร์จพลัง หรืออยู่ระหว่างหมุนเต๋า ไม่ให้ทอยซ้ำซ้อนจาก event click
            if (this.isRolling || this.isGaugeHolding) return;
            if (this._lastGaugeReleaseTime && (Date.now() - this._lastGaugeReleaseTime < 650)) return;
            this.clearTurnTimers();
            this.rollDiceFromGauge(Math.floor(Math.random() * 4) + 1);
            return;
        }

        // โหมดบันไดงู: กดทอยตามปกติ -> เคลียร์เวลานับถอยหลัง แล้วทอยทันที (ไม่ต้องมีเกจ ไม่ต้องกดค้าง)
        this.clearTurnTimers();
        this.rollDice();
    }

    updateActiveTurnUI() {
        const turnEl = document.getElementById('turn-status-text');
        if (!this.isMatchActive) {
            if (turnEl) {
                turnEl.innerHTML = `พร้อมเริ่มเล่น <span style="font-size:12px;font-weight:normal;opacity:0.85;">(กด "ทดลองเล่น" หรือเลือก "ห้องแข่งขัน")</span>`;
                turnEl.style.color = '#38bdf8';
            }
            return;
        }
        const active = this.players[this.currentTurnIndex];
        if (!active) return;
        if (turnEl) {
            const teamBadge = active.team_name ? `[${active.team_name}] ` : '';
            const autoBadge = (!active.is_bot && this.isAutoMode) ? ' <span class="auto-turn-pill">⚡ AUTO</span>' : '';
            const goldBadge = active.matchGold !== undefined ? ` • 💰${this.formatCompactGold(active.matchGold)}` : '';
            if (active.jailTurns > 0) {
                turnEl.innerHTML = `<span style="color:#ef4444;font-weight:700;">🚨 ติดเกาะร้าง (เหลืออีก ${active.jailTurns} ตา): ${teamBadge}${active.username}${autoBadge}</span>`;
                turnEl.style.color = '#ef4444';
            } else {
                const isDoubleTurn = Boolean((active.consecutiveDoubles && active.consecutiveDoubles > 0) || (this.consecutiveDoubles && this.consecutiveDoubles > 0));
                const doubleBadge = isDoubleTurn ? ` <span class="badge badge-gold" style="font-size:11px; margin-left:4px;">🔥 เบิ้ลทอยต่อ (ครั้งที่ ${(active.consecutiveDoubles || this.consecutiveDoubles || 1) + 1})</span>` : '';
                turnEl.innerHTML = `ตาของ: ${teamBadge}${active.username}${autoBadge}${doubleBadge} <span style="font-size:12px;font-weight:normal;opacity:0.9;">(ช่อง ${active.currentTile}: ${this.getProvinceName(active.currentTile)}${goldBadge})</span>`;
                turnEl.style.color = '#00e5ff';
            }
            turnEl.style.color = `#${active.color.toString(16).padStart(6, '0')}`;
        }
        this.updateMatchWealthHUD();
        this.updateOddEvenButtonsUI();
    }

    handleVictory(winner, winReason = 'FINISH_LINE', extra = {}) {
        if (this.isGameOver) return;
        if (this.isMonopolyBoardMode && winReason === 'FINISH_LINE') return;
        const shouldSyncGameOver = this.isMultiplayerSyncMatch() && !this._isApplyingRemoteAction;
        this.isGameOver = true;
        this.isMatchActive = false;

        // สั่งหยุดเพลงเล่นเกมส์ และเปิดเพลงบรรยากาศล็อบบี้กลับมาหลังจากจบการแข่งขัน
        if (typeof window.stopGameplayBgm === 'function') {
            window.stopGameplayBgm();
        }
        if (typeof window.startLobbyAmbientSound === 'function') {
            setTimeout(() => {
                if (!this.isMatchActive) {
                    window.startLobbyAmbientSound();
                }
            }, 3000);
        }

        if (shouldSyncGameOver) {
            const winIdx = winner ? this.players.indexOf(winner) : -1;
            this.pushMultiplayerSyncEvent('STATE', {
                ...this.buildMultiplayerStateSnapshot(),
                winnerIndex: winIdx >= 0 ? winIdx : null,
                winReason: winReason || ''
            });
        }
        this.stopMultiplayerSync();

        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }

        // 🎙️ เล่นเสียงจบเกมส์ (ชนะการแข่งขัน หรือ แพ้ซะแล้ว)
        const localPlayer = (this.players || []).find(p => this.isLocalPlayer(p));
        const isHumanWinner = Boolean(
            winner && (
                this.isLocalPlayer(winner) ||
                (winner.team && winner.team !== 'NONE' && localPlayer && localPlayer.team === winner.team)
            )
        );
        if (window.ThaiAudio && typeof window.ThaiAudio.playGameOver === 'function') {
            window.ThaiAudio.playGameOver(isHumanWinner);
        } else if (isHumanWinner && window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
            window.ThaiAudio.playIfConfigured('victory');
        }

        // จัดอันดับผู้เล่น: หากเป็นการแข่งทีม ให้สมาชิกทีมชนะอยู่ด้านบนเสมอ (ไม่จัดอันดับเดี่ยวปะปนกัน)
        const isTeamMode = Boolean(winner && winner.team && winner.team !== 'NONE');
        const winningTeam = winner?.team;

        this.lastMatchRankedPlayers = (this.players && this.players.length > 0)
            ? [...this.players].sort((a, b) => {
                // 1. ผู้ชนะการแข่งขัน (Winner) ต้องอยู่อันดับที่ 1 เสมอ 100%
                if (winner) {
                    if (isTeamMode && winningTeam) {
                        const aWin = (a.team === winningTeam);
                        const bWin = (b.team === winningTeam);
                        if (aWin !== bWin) return aWin ? -1 : 1;
                        if (a.id === winner.id) return -1;
                        if (b.id === winner.id) return 1;
                    } else {
                        if (a.id === winner.id) return -1;
                        if (b.id === winner.id) return 1;
                    }
                }
                // 2. ผู้เล่นที่ล้มละลายอยู่อันดับท้าย
                if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
                // 3. เรียงตามระยะใกล้เส้นชัย (ช่องสูงสุด)
                const tileA = Number(a.currentTile ?? a.tileIndex ?? 0);
                const tileB = Number(b.currentTile ?? b.tileIndex ?? 0);
                if (tileA !== tileB) return tileB - tileA;
                // 4. สินทรัพย์รวม
                const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
                if (diff !== 0) return diff;
                return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
            }).map(p => {
                let pUsername = p.username;
                const isLocalP = Boolean(p.is_local_user || p.is_me);
                if (isLocalP) {
                    pUsername = (typeof window.getActivePlayerName === 'function')
                        ? window.getActivePlayerName()
                        : (p.username || 'ผู้เล่น');
                }
                const pAvatar = (isLocalP && typeof window.getActivePlayerAvatarUrl === 'function')
                    ? window.getActivePlayerAvatarUrl()
                    : (p.avatar_url || p.picture || 'avatars/google_avatar.png');
                return {
                    id: p.id,
                    username: pUsername,
                    avatar_url: pAvatar,
                    color: p.color,
                    is_bot: p.is_bot,
                    team: p.team,
                    team_name: p.team_name,
                    matchGold: p.matchGold,
                    totalAssets: this.getPlayerTotalAssets(p),
                    cityCounts: this.getPlayerCityCounts(p),
                    isBankrupt: p.isBankrupt
                };
            })
            : [];

        this.clearTurnTimers();
        this.closeCityActionPrompt(null);
        this.clearSavedSession();
        if (this.isAutoMode) {
            this.isAutoMode = false;
            this.updateAutoToggleUI();
        }
        this.updateMatchWealthHUD();
        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }

        if (isHumanWinner) {
            if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
                window.soundEngine.playWin();
            }
        } else if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
            window.soundEngine.playAlert();
        }

        // แสดงแบนเนอร์ผลแพ้-ชนะกลางกระดาน (หากเราล้มละลาย/แพ้ ให้แสดงแพ้ ไม่ใช่เอฟเฟ็คชนะ)
        this.showVictorySplash(winner, winReason, isHumanWinner);

        if (winReason === 'TRIPLE_COLOR_VICTORY') {
            this.showSkillBanner(`🌈👑 ${winner.username} ชนะ TRIPLE COLOR VICTORY ครองครบ 3 สี (6 เมือง)!`);
            this.logMessage(`🌈👑 ${winner.username} คว้าชัยชนะแบบ Triple Color Domination ครองเมืองครบ 3 สี (6 เมือง) สุดยิ่งใหญ่! โบนัสรางวัลคูณ 3!`, 'highlight');
        } else if (winReason === 'VERTICAL_LINE_VICTORY') {
            this.showSkillBanner(`👑 ${winner.username} ชนะ TRIPLE COLUMN DOMINATION ครองแนวตั้งครบแถว! (รางวัล X3)`);
            this.logMessage(`👑 ${winner.username} คว้าชัยชนะแบบ Column Domination ครองเมืองแนวตั้งครบแถว! โบนัสรางวัลคูณ 3!`, 'highlight');
        } else if (winReason === 'HORIZONTAL_LINE_VICTORY') {
            this.showSkillBanner(`🎉 ${winner.username} ชนะ LINE DOMINATION ครองแนวนอนครบแถว! (รางวัล X2)`);
            this.logMessage(`🎉 ${winner.username} คว้าชัยชนะแบบ Line Domination ครองเมืองแนวนอนครบแถว! โบนัสรางวัลคูณ 2!`, 'highlight');
        } else if (winReason === 'BANKRUPTCY') {
            this.showSkillBanner(`🏆 ${winner.username} ชนะล้มละลาย! คู่แข่งเงินหมดกระดาน!`);
            this.logMessage(`🏆 ${winner.username} คว้าชัยชนะแบบล้มละลายคู่แข่ง! เหลือรอดเป็นมหาเศรษฐีหนึ่งเดียว!`, 'highlight');
        } else if (winReason === 'TIME_OUT') {
            const winnerAssets = this.formatCompactGold(this.getPlayerTotalAssets(winner));
            this.showSkillBanner(`⏰ หมดเวลา ${Math.round((this.matchTimeLimit || 600) / 60)} นาที! ${winner.username} ชนะด้วยสินทรัพย์รวมสูงสุด ${winnerAssets}!`);
            this.logMessage(`⏰ หมดเวลาการแข่งขัน ${Math.round((this.matchTimeLimit || 600) / 60)} นาที! ${winner.username} คว้าชัยชนะด้วยทองและสิ่งก่อสร้างรวมสูงสุด (${winnerAssets})!`, 'highlight');
        } else {
            this.showSkillBanner(`🏆 ${winner.username} พิชิตเส้นชัยช่อง 100 ชนะการแข่งขัน!`);
            this.logMessage(`🏆 ${winner.username} พิชิตเส้นชัยช่อง 100 ชนะการแข่งขันสำเร็จ!`, 'highlight');
        }

        if (isHumanWinner && window.confetti) {
            window.confetti({ particleCount: 220, spread: 100, origin: { y: 0.55 } });
        }

        if (window.onGameFinished) {
            window.onGameFinished(winner, winReason, extra);
        }
    }

    /**
     * แบนเนอร์ขานลำดับการเริ่มทอย (Turn Order Splash) สไตล์กระดาน 3D Tycoon 3D
     * - ขานลำดับ 1-4: ได้ทอยเป็นคนแรก, คนที่สอง, คนที่สาม, คนที่สี่
     * - ขานเสียงพากย์ภาษาไทยตามลำดับที่ได้ โดยไม่ถูกเสียงอื่นตัดรบกวน
     */
    showTurnOrderSplash(orderNum = 1, callback = null) {
        const n = Math.max(1, Math.min(4, parseInt(orderNum) || 1));
        const humanIdx = this.getLocalPlayerIndex();
        const me = (humanIdx !== -1 && this.players) ? this.players[humanIdx] : (this.players ? this.players[0] : null);
        const myName = me ? (me.username || 'คุณ') : 'คุณ';
        const myAvatar = me ? (me.avatar_url || me.picture || 'avatars/avatar_01.svg') : 'avatars/avatar_01.svg';
        const total = (this.players && this.players.length) ? this.players.length : 2;

        const rankConfigs = {
            1: {
                title: 'ได้ทอยเป็นคนแรก!',
                subtitle: 'คุณได้สิทธิ์เริ่มเดินเป็นคนแรก (มือ 1 🚀)',
                badge: 'ลำดับที่ 1 / ' + total,
                icon: '🥇',
                theme: 'turn-order-splash-1'
            },
            2: {
                title: 'ได้ทอยเป็นคนที่สอง!',
                subtitle: 'คุณได้สิทธิ์เริ่มเดินคนที่สอง (มือ 2 🎲)',
                badge: 'ลำดับที่ 2 / ' + total,
                icon: '🥈',
                theme: 'turn-order-splash-2'
            },
            3: {
                title: 'ได้ทอยเป็นคนที่สาม!',
                subtitle: 'คุณได้สิทธิ์เริ่มเดินคนที่สาม (มือ 3 🎲)',
                badge: 'ลำดับที่ 3 / ' + total,
                icon: '🥉',
                theme: 'turn-order-splash-3'
            },
            4: {
                title: 'ได้ทอยเป็นคนที่สี่!',
                subtitle: 'คุณได้สิทธิ์เริ่มเดินคนที่สี่ (มือ 4 🎲)',
                badge: 'ลำดับที่ 4 / ' + total,
                icon: '🎖️',
                theme: 'turn-order-splash-4'
            }
        };

        const cfg = rankConfigs[n] || rankConfigs[1];

        let splashEl = document.getElementById('turn-order-announcement-overlay');
        if (!splashEl) {
            splashEl = document.createElement('div');
            splashEl.id = 'turn-order-announcement-overlay';
            splashEl.className = 'turn-order-splash-overlay';
            document.body.appendChild(splashEl);
        }

        splashEl.innerHTML = `
            <div class="turn-order-splash-card ${cfg.theme}">
                <div class="turn-splash-header-badge">${cfg.badge}</div>
                <div class="turn-splash-avatar-wrap">
                    <img src="${myAvatar}" class="turn-splash-avatar" alt="${myName}" onerror="this.src='avatars/avatar_01.svg'">
                    <div class="turn-splash-rank-emblem">${cfg.icon}</div>
                </div>
                <div class="turn-splash-player-name">${myName}</div>
                <div class="turn-splash-main-title">${cfg.title}</div>
                <div class="turn-splash-subtitle">${cfg.subtitle}</div>
                <div class="turn-splash-ready-pill">✦ แตะเพื่อเริ่มทันที ✦</div>
            </div>
        `;

        splashEl.style.display = 'flex';
        splashEl.classList.remove('fade-out');

        // 🎙️ ขานเสียงพากย์ภาษาไทยตามลำดับการทอยที่ได้ (1..4) หากยังไม่ได้ขานตอนเปิดการ์ด
        const justPlayedOrderVoice = Boolean(
            window.ThaiAudio
            && window.ThaiAudio.lastVoiceEventKey === ('turn_order_' + n)
            && (Date.now() - (window.ThaiAudio.lastVoicePlayTime || 0)) < 3500
        );
        if (!justPlayedOrderVoice) {
            if (window.ThaiAudio && typeof window.ThaiAudio.playTurnOrder === 'function') {
                window.ThaiAudio.playTurnOrder(n);
            } else if (window.ThaiAudio && typeof window.ThaiAudio.playGameStart === 'function') {
                window.ThaiAudio.playGameStart(n === 1);
            }
        }

        if (window.soundEngine && typeof window.soundEngine.playCardRevealZap === 'function') {
            window.soundEngine.playCardRevealZap('zap_classic', false, 0.75);
        }

        let isDismissed = false;
        const dismiss = () => {
            if (isDismissed) return;
            isDismissed = true;
            splashEl.classList.add('fade-out');
            setTimeout(() => {
                splashEl.style.display = 'none';
                if (typeof callback === 'function') {
                    callback();
                }
            }, 300);
        };

        splashEl.onclick = dismiss;
        splashEl.ontouchend = dismiss;

        setTimeout(() => {
            dismiss();
        }, 2200);
    }

    /**
     * แบนเนอร์แอนิเมชันเฉลิมฉลองชัยชนะกลางจอ (สไตล์ในคลิปเกมเศรษฐี)
     * - ชนะล้มละลาย: "ชนะแบบล้มละลาย" + "โบนัส X 2"
     * - ชนะเส้นชัย: "ถึงเส้นชัย"
     * - ชนะวิคเตอรี่: "วิคเตอรี่ X2" (หรือ X3) + "โบนัส X 2"
     */
    showVictorySplash(winner, winReason, isLocalWin = true) {
        let splashEl = document.getElementById('in-game-victory-splash');
        if (!splashEl) {
            splashEl = document.createElement('div');
            splashEl.id = 'in-game-victory-splash';
            splashEl.className = 'in-game-victory-splash';
            document.body.appendChild(splashEl);
        }

        let welcomeTitle = 'ยินดีด้วย!';
        let mainText = 'ชนะแบบล้มละลาย';
        let bonusPillText = 'โบนัส X 2';
        let themeClass = 'splash-bankruptcy';
        let iconBadge = '💥';

        if (!isLocalWin) {
            welcomeTitle = 'เสียใจด้วย!';
            themeClass = 'splash-defeat';
            iconBadge = '💸';
            const winnerName = (winner && winner.username) ? winner.username : 'คู่แข่ง';
            if (winReason === 'BANKRUPTCY') {
                mainText = 'คุณล้มละลาย!';
                bonusPillText = `${winnerName} ชนะการแข่งขัน`;
            } else if (winReason === 'TIME_OUT') {
                mainText = 'แพ้ (หมดเวลา)';
                bonusPillText = `${winnerName} สินทรัพย์สูงกว่า`;
            } else {
                mainText = 'แพ้การแข่งขัน';
                bonusPillText = `${winnerName} ชนะการแข่งขัน`;
            }
        } else if (winReason === 'BANKRUPTCY') {
            mainText = 'ชนะแบบล้มละลาย';
            bonusPillText = 'โบนัส X 2';
            themeClass = 'splash-bankruptcy';
            iconBadge = '💥';
        } else if (winReason === 'FINISH_LINE') {
            mainText = 'ถึงเส้นชัย';
            bonusPillText = 'พิชิตช่อง 100';
            themeClass = 'splash-finish';
            iconBadge = '🚩';
        } else if (winReason === 'HORIZONTAL_LINE_VICTORY') {
            mainText = 'วิคเตอรี่ X2';
            bonusPillText = 'โบนัส X 2';
            themeClass = 'splash-victory';
            iconBadge = '🎉';
        } else if (winReason === 'VERTICAL_LINE_VICTORY') {
            mainText = 'วิคเตอรี่ X3';
            bonusPillText = 'โบนัส X 3';
            themeClass = 'splash-victory';
            iconBadge = '👑';
        } else if (winReason === 'TIME_OUT') {
            mainText = 'หมดเวลาแข่งขัน';
            bonusPillText = 'สินทรัพย์รวมสูงสุด';
            themeClass = 'splash-timeout';
            iconBadge = '⏰';
        }

        splashEl.innerHTML = `
            <div class="victory-splash-card ${themeClass}">
                <div class="splash-welcome-title">${welcomeTitle}</div>
                <div class="splash-main-row">
                    <span class="splash-icon">${iconBadge}</span>
                    <span class="splash-text">${mainText}</span>
                </div>
                <div class="splash-bonus-tag">${bonusPillText}</div>
            </div>
        `;
        splashEl.style.display = 'flex';
        splashEl.classList.remove('fade-out');

        setTimeout(() => {
            splashEl.classList.add('fade-out');
            setTimeout(() => {
                splashEl.style.display = 'none';
            }, 450);
        }, 1800);
    }

    /**
     * สร้างแลนด์มาร์กจุดสตาร์ท 3D (ช่อง 1: Grand Start Circle Pad)
     * - แท่นพลาซ่าทรงกลมพร้อมขอบเรืองแสงนีออนสีฟ้า และข้อความ "START" / "🚩 จุดเริ่มต้น 🚩"
     */
    createStartPointLandmark(x, y, z) {
        const startGroup = new THREE.Group();
        startGroup.position.set(x, y, z);

        const baseGeo = new THREE.CylinderGeometry(4.8, 5.2, 0.7, 36);
        const baseMat = new THREE.MeshStandardMaterial({
            color: 0x07263e,
            metalness: 0.85,
            roughness: 0.25,
            emissive: 0x0284c7,
            emissiveIntensity: 0.35
        });
        const base = new THREE.Mesh(baseGeo, baseMat);
        base.position.y = 0.35;
        startGroup.add(base);

        const rimGeo = new THREE.TorusGeometry(5.0, 0.15, 16, 48);
        const rimMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.85 });
        const rim = new THREE.Mesh(rimGeo, rimMat);
        rim.rotation.x = Math.PI / 2;
        rim.position.y = 0.71;
        startGroup.add(rim);

        const startCanvas = document.createElement('canvas');
        startCanvas.width = 512;
        startCanvas.height = 512;
        const sCtx = startCanvas.getContext('2d');

        const bgGrad = sCtx.createRadialGradient(256, 256, 30, 256, 256, 256);
        bgGrad.addColorStop(0, '#0a365c');
        bgGrad.addColorStop(0.65, '#062038');
        bgGrad.addColorStop(1, '#020e1a');
        sCtx.fillStyle = bgGrad;
        sCtx.beginPath();
        sCtx.arc(256, 256, 250, 0, Math.PI * 2);
        sCtx.fill();

        sCtx.strokeStyle = '#00e5ff';
        sCtx.lineWidth = 10;
        sCtx.shadowColor = '#00e5ff';
        sCtx.shadowBlur = 24;
        sCtx.beginPath();
        sCtx.arc(256, 256, 240, 0, Math.PI * 2);
        sCtx.stroke();

        sCtx.save();
        sCtx.strokeStyle = '#38bdf8';
        sCtx.lineWidth = 4;
        sCtx.setLineDash([16, 12]);
        sCtx.shadowColor = '#38bdf8';
        sCtx.shadowBlur = 12;
        sCtx.beginPath();
        sCtx.arc(256, 256, 210, 0, Math.PI * 2);
        sCtx.stroke();
        sCtx.restore();

        sCtx.strokeStyle = 'rgba(0, 229, 255, 0.4)';
        sCtx.lineWidth = 3;
        sCtx.beginPath();
        sCtx.arc(256, 256, 175, 0, Math.PI * 2);
        sCtx.stroke();

        sCtx.font = '900 80px Kanit, Montserrat, Arial, sans-serif';
        sCtx.textAlign = 'center';
        sCtx.textBaseline = 'middle';
        sCtx.shadowColor = '#00e5ff';
        sCtx.shadowBlur = 30;
        sCtx.strokeStyle = '#00e5ff';
        sCtx.lineWidth = 8;
        sCtx.strokeText('FINISH', 256, 220);

        sCtx.fillStyle = '#ffffff';
        sCtx.shadowBlur = 15;
        sCtx.fillText('FINISH', 256, 220);

        sCtx.font = '700 34px Kanit, sans-serif';
        sCtx.shadowColor = '#0284c7';
        sCtx.shadowBlur = 16;
        sCtx.fillStyle = '#7dd3fc';
        sCtx.fillText('🏁 จุดเส้นชัย 🏁', 256, 305);

        const startTex = new THREE.CanvasTexture(startCanvas);
        startTex.needsUpdate = true;

        const padGeo = new THREE.CircleGeometry(4.75, 48);
        const padMat = new THREE.MeshStandardMaterial({
            map: startTex,
            roughness: 0.25,
            metalness: 0.5,
            emissive: 0x0284c7,
            emissiveIntensity: 0.35,
            side: THREE.DoubleSide
        });
        const pad = new THREE.Mesh(padGeo, padMat);
        pad.rotation.x = -Math.PI / 2;
        pad.position.y = 0.72;
        startGroup.add(pad);

        const innerRingGeo = new THREE.TorusGeometry(3.6, 0.06, 8, 36);
        const innerRingMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending });
        const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
        innerRing.rotation.x = Math.PI / 2;
        innerRing.position.y = 0.73;
        startGroup.add(innerRing);

        const startLight = new THREE.PointLight(0x00e5ff, 2.0, 20);
        startLight.position.set(0, 2.5, 0);
        startGroup.add(startLight);

        this.boardGroup.add(startGroup);
        this.startAnimations = { rim, innerRing, light: startLight };
    }

    /**
     * เส้นชัย 3D (ช่อง 100): วิหารมหานครมรกต-ทองคำ + ซุ้มประตูชัย + ลำแสงทองพุ่งขึ้นฟ้า (ตรงตามรูป 1)
     */
    createGoalCityLandmark(x, y, z) {
        const goalGroup = new THREE.Group();
        goalGroup.position.set(x, y, z);

        // 1. ฐานพระนครมหาราชวังวงกลมขนาดใหญ่ + ขอบทองคำเรืองแสง
        const baseGeo = new THREE.CylinderGeometry(5.2, 5.6, 1.0, 32);
        const baseMat = new THREE.MeshStandardMaterial({
            color: 0x064e3b,
            metalness: 0.85,
            roughness: 0.2,
            emissive: 0x047857,
            emissiveIntensity: 0.35
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.y = 0.5;
        goalGroup.add(baseMesh);

        const trimGeo = new THREE.TorusGeometry(5.4, 0.18, 10, 48);
        const trimMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            metalness: 0.95,
            roughness: 0.1,
            emissive: 0xb45309,
            emissiveIntensity: 0.45
        });
        const trim = new THREE.Mesh(trimGeo, trimMat);
        trim.rotation.x = Math.PI / 2;
        trim.position.y = 0.95;
        goalGroup.add(trim);

        // โดมพลังงานทรงกระบอกโปร่งแสงโอบล้อมวิหาร
        const domeGeo = new THREE.CylinderGeometry(4.6, 5.1, 4.2, 32, 1, true);
        const domeMat = new THREE.MeshBasicMaterial({
            color: 0xfacc15,
            transparent: true,
            opacity: 0.24,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        const dome = new THREE.Mesh(domeGeo, domeMat);
        dome.position.y = 3.0;
        // goalGroup.add(dome); // ปิดการแสดงผลแท่ง/โดมทรงกระบอกสีฟ้าตามความต้องการผู้ใช้

        // 2. ตึกระฟ้าจำลองมหานคร 4 มุม พร้อมเส้นขอบนีออนและยอดคริสตัล
        const towerConfigs = [
            { tx: -2.0, tz: -2.0, h: 5.5, w: 1.1, c: 0x0284c7 },
            { tx: 2.0, tz: -2.0, h: 7.0, w: 1.3, c: 0x06b6d4 },
            { tx: -2.2, tz: 1.6, h: 6.0, w: 1.2, c: 0x8b5cf6 },
            { tx: 2.2, tz: 1.6, h: 4.8, w: 1.0, c: 0x10b981 }
        ];

        towerConfigs.forEach(cfg => {
            const twGeo = new THREE.BoxGeometry(cfg.w, cfg.h, cfg.w);
            const twMat = new THREE.MeshStandardMaterial({
                color: cfg.c,
                metalness: 0.8,
                roughness: 0.2,
                emissive: cfg.c,
                emissiveIntensity: 0.28
            });
            const tower = new THREE.Mesh(twGeo, twMat);
            tower.position.set(cfg.tx, cfg.h / 2 + 0.8, cfg.tz);
            goalGroup.add(tower);

            const spireGeo = new THREE.ConeGeometry(0.35, 1.8, 6);
            const spireMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x00ffff, emissiveIntensity: 0.85 });
            const spire = new THREE.Mesh(spireGeo, spireMat);
            spire.position.set(cfg.tx, cfg.h + 1.7, cfg.tz);
            goalGroup.add(spire);

            const edgeG = new THREE.EdgesGeometry(twGeo);
            const edgeM = new THREE.LineBasicMaterial({ color: 0x00ffff });
            const wire = new THREE.LineSegments(edgeG, edgeM);
            wire.position.copy(tower.position);
            goalGroup.add(wire);
        });

        // 3. ซุ้มประตูวิหารทองคำด้านหน้า (Golden Front Gate)
        const gateGoldMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            metalness: 0.92,
            roughness: 0.15,
            emissive: 0x92400e,
            emissiveIntensity: 0.4
        });
        [-1.35, 1.35].forEach(px => {
            const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 3.4, 12), gateGoldMat);
            pillar.position.set(px, 2.5, 2.8);
            goalGroup.add(pillar);
        });
        const lintel = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.55, 0.55), gateGoldMat);
        lintel.position.set(0, 4.3, 2.8);
        goalGroup.add(lintel);

        // 4. พระเจดีย์ทองคำและเพชรชัยชนะลอยหมุนตรงกลาง
        const pagodaOrb = new THREE.Group();
        const pagodaSpire = new THREE.Mesh(new THREE.ConeGeometry(1.1, 4.2, 8), gateGoldMat);
        pagodaSpire.position.y = 3.2;
        pagodaOrb.add(pagodaSpire);
        goalGroup.add(pagodaOrb);

        const diamond = new THREE.Mesh(
            new THREE.OctahedronGeometry(0.75),
            new THREE.MeshBasicMaterial({ color: 0xfffbeb })
        );
        diamond.position.y = 6.2;
        goalGroup.add(diamond);

        // 5. วงแหวนเวทมนตร์สีทอง 2 ชั้น + ลำแสงสปอตไลท์ทองคำพุ่งทะลุฟ้า
        const auraRing1 = new THREE.Mesh(
            new THREE.TorusGeometry(5.85, 0.1, 8, 48),
            new THREE.MeshBasicMaterial({ color: 0xffea00, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending })
        );
        auraRing1.rotation.x = Math.PI / 2;
        auraRing1.position.y = 1.05;
        goalGroup.add(auraRing1);

        const auraRing2 = new THREE.Mesh(
            new THREE.TorusGeometry(4.1, 0.08, 8, 40),
            new THREE.MeshBasicMaterial({ color: 0xfff176, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending })
        );
        auraRing2.rotation.x = Math.PI / 2;
        auraRing2.position.y = 4.6;
        goalGroup.add(auraRing2);

        const beamGeo = new THREE.CylinderGeometry(3.8, 5.4, 44, 32, 1, true);
        const beamMat = new THREE.MeshBasicMaterial({
            color: 0xffd54f,
            transparent: true,
            opacity: 0.24,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        const beam = new THREE.Mesh(beamGeo, beamMat);
        beam.position.y = 22.8;
        // goalGroup.add(beam); // ปิดการแสดงผลเสาลำแสงทรงกระบอกพุ่งขึ้นฟ้า

        // แสงไฟสีทองส่องสว่างลงพื้นกระดานรอบเส้นชัยเหมือนรูป 1
        const goalLight = new THREE.PointLight(0xffca28, 3.2, 38);
        goalLight.position.set(0, 5.5, 2.0);
        goalGroup.add(goalLight);

        this.boardGroup.add(goalGroup);
        this.goalAnimations = {
            beam,
            auraRing1,
            auraRing2,
            pagodaOrb,
            diamond,
            light: goalLight
        };
    }

    /**
     * ตรวจสอบแหล่งรูปโปรไฟล์ของผู้เล่น (Google / LINE / Guest)
     */
    resolvePlayerAvatarInfo(playerData = {}) {
        const provRaw = String(
            playerData.auth_provider ||
            (playerData.line_id ? 'line' : (playerData.google_id ? 'google' : '')) ||
            window.DEFAULT_USER?.auth_provider ||
            localStorage.getItem('snake_auth_provider') ||
            ''
        ).toLowerCase();

        let provider = provRaw || 'guest';
        const isLocal = Boolean(playerData && (playerData.is_local_user || playerData.is_me));
        // ใช้รูปภาพของ playerData โดยตรงก่อนเสมอ เพื่อไม่ให้รูปโปรไฟล์ของไอดีก่อนหน้าติดค้าง
        let avatarUrl = playerData.avatar_url || playerData.pictureUrl || playerData.picture || '';
        if (!avatarUrl && isLocal && typeof window.getActivePlayerAvatarUrl === 'function' && !playerData.is_bot) {
            avatarUrl = window.getActivePlayerAvatarUrl(playerData);
        }
        if (!avatarUrl) {
            avatarUrl = isLocal
                ? (window.DEFAULT_USER?.avatar_url || window.DEFAULT_USER?.pictureUrl || window.DEFAULT_USER?.picture || 'avatars/avatar_01.svg')
                : 'avatars/google_avatar.png';
        }

        return { provider, avatarUrl };
    }

    /**
     * สร้างพื้นผิวแสงเรืองออร่ารอบกรอบสี่เหลี่ยมของตัวหมาก (Square Aura Glow Texture)
     */
    createPawnCardAuraTexture(hexColor = '#00e5ff', isHuman = true, secondaryColor = '#ffd700') {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 614;
        const ctx = canvas.getContext('2d');
        const w = 512, h = 614;
        const cx = w / 2, cy = h / 2;
        const mainCol = hexColor || '#00e5ff';
        const secCol = secondaryColor || (isHuman ? '#ffd700' : mainCol);

        // 1. รังสีเรืองแสงออร่ารอบกรอบสี่เหลี่ยม (Radial Aura Halo สีเดียวกับกรอบ/เออร่า)
        const radGrad = ctx.createRadialGradient(cx, cy, 52, cx, cy, Math.max(cx, cy));
        radGrad.addColorStop(0, 'rgba(255,255,255,0.72)');
        radGrad.addColorStop(0.32, safeHexToRgba(secCol, isHuman ? 0.72 : 0.55));
        radGrad.addColorStop(0.68, safeHexToRgba(mainCol, 0.78));
        radGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = radGrad;
        ctx.fillRect(0, 0, w, h);

        // 2. กรอบแสงนีออนฟุ้งสี่เหลี่ยมมนสองชั้น (Dual Glowing Neon Bevel สีเดียวกับกรอบการ์ด)
        ctx.save();
        const bevelGrad = ctx.createLinearGradient(36, 36, w - 36, h - 36);
        bevelGrad.addColorStop(0, mainCol);
        bevelGrad.addColorStop(0.5, secCol);
        bevelGrad.addColorStop(1, mainCol);
        ctx.shadowColor = mainCol;
        ctx.shadowBlur = 40;
        ctx.strokeStyle = bevelGrad;
        ctx.lineWidth = 18;
        if (typeof ctx.roundRect === 'function') {
            ctx.beginPath();
            ctx.roundRect(36, 36, w - 72, h - 72, 34);
            ctx.stroke();
        } else {
            ctx.strokeRect(36, 36, w - 72, h - 72);
        }

        // เส้นขาวประกายคริสตัลชั้นใน
        ctx.shadowColor = secCol;
        ctx.shadowBlur = 16;
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 4.5;
        if (typeof ctx.roundRect === 'function') {
            ctx.beginPath();
            ctx.roundRect(46, 46, w - 92, h - 92, 26);
            ctx.stroke();
        } else {
            ctx.strokeRect(46, 46, w - 92, h - 92);
        }
        ctx.restore();

        const tex = new THREE.CanvasTexture(canvas);
        return tex;
    }

    createPawnAuraRingTexture(hexColor = '#00e5ff', isHuman = true, secondaryColor = '#ffd700') {
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');
        const cx = 128;
        const cy = 128;
        const mainCol = hexColor || '#00e5ff';
        const secCol = secondaryColor || (isHuman ? '#fde047' : mainCol);

        // วงแสงฟุ้งรอบนอก (สีเดียวกับกรอบ/เออร่าการ์ด)
        const radGrad = ctx.createRadialGradient(cx, cy, 80, cx, cy, 126);
        radGrad.addColorStop(0, 'rgba(255,255,255,0)');
        radGrad.addColorStop(0.55, safeHexToRgba(secCol, isHuman ? 0.45 : 0.28));
        radGrad.addColorStop(0.82, safeHexToRgba(mainCol, 0.62));
        radGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = radGrad;
        ctx.fillRect(0, 0, 256, 256);

        // เส้นโค้งพลังงานเวทย์ 4 แฉก + ดาวเพชร 8 มุม
        ctx.save();
        ctx.translate(cx, cy);
        ctx.strokeStyle = secCol;
        ctx.shadowColor = mainCol;
        ctx.shadowBlur = 14;
        ctx.lineWidth = isHuman ? 6.5 : 4.5;
        for (let i = 0; i < 4; i++) {
            const startA = (i * Math.PI) / 2 + 0.14;
            const endA = startA + Math.PI / 2 - 0.28;
            ctx.beginPath();
            ctx.arc(0, 0, 108, startA, endA);
            ctx.stroke();
        }

        const starCount = isHuman ? 8 : 4;
        for (let i = 0; i < starCount; i++) {
            const ang = (i * Math.PI * 2) / starCount;
            const sx = Math.cos(ang) * 114;
            const sy = Math.sin(ang) * 114;
            ctx.fillStyle = i % 2 === 0 ? '#ffffff' : secCol;
            ctx.beginPath();
            ctx.arc(sx, sy, isHuman ? 5.5 : 4, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();

        const tex = new THREE.CanvasTexture(canvas);
        tex.anisotropy = 4;
        return tex;
    }

    drawPawnNameTagCanvas(canvas, username = '', hexColor = '#00e5ff', isBot = false, isLocalUser = !isBot) {
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);
        const s = w / 1024;
        ctx.save();
        ctx.scale(s, s);

        const bCfg = this.badgeConfig || this.getDefaultBadgeConfig();
        const pawnCfg = bCfg.pawn || {};

        const cleanName = String(username || (isBot ? 'Player' : 'ผู้เล่น'))
            .replace(/🤖|บอท|\(AI\)/gi, '')
            .trim();
        const shortName = Array.from(cleanName).slice(0, 12).join('') + (Array.from(cleanName).length > 12 ? '…' : '');
        const pfx = pawnCfg.prefix !== undefined ? pawnCfg.prefix : '👑 คุณ: ';
        const label = isBot ? `🤖 ${shortName}` : (isLocalUser ? `${pfx}${shortName}` : shortName);

        ctx.save();
        ctx.shadowColor = (isBot || !isLocalUser) ? hexColor : (pawnCfg.borderColor || '#fbbf24');
        ctx.shadowBlur = (isBot || !isLocalUser) ? 22 : 32;

        const bgGrad = ctx.createLinearGradient(20, 16, 1024 - 20, 180);
        if (!isBot && isLocalUser) {
            const pBg1 = pawnCfg.bg1 || '#1e1b4b';
            const pBg2 = pawnCfg.bg2 || '#1e3a8a';
            bgGrad.addColorStop(0, pBg1);
            bgGrad.addColorStop(0.5, pBg2);
            bgGrad.addColorStop(1, '#0f172a');
        } else {
            bgGrad.addColorStop(0, '#090d16');
            bgGrad.addColorStop(0.5, '#1e293b');
            bgGrad.addColorStop(1, '#090d16');
        }

        ctx.fillStyle = bgGrad;
        ctx.strokeStyle = !isBot ? (pawnCfg.borderColor || '#ffd700') : hexColor;
        ctx.lineWidth = !isBot ? 14 : 10;
        ctx.beginPath();
        ctx.roundRect(24, 16, 1024 - 48, 166, 83);
        ctx.fill();
        ctx.stroke();

        // ลูกศรชี้ลงตรงกลางหัวตัวหมาก
        ctx.beginPath();
        ctx.moveTo(1024 / 2 - 28, 180);
        ctx.lineTo(1024 / 2, 228);
        ctx.lineTo(1024 / 2 + 28, 180);
        ctx.closePath();
        ctx.fillStyle = !isBot ? (pawnCfg.borderColor || '#ffd700') : hexColor;
        ctx.fill();
        ctx.restore();

        if (!isBot) {
            // เส้นเรืองแสงสีฟ้าด้านในกรอบทอง
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 4.5;
            ctx.beginPath();
            ctx.roundRect(36, 28, 1024 - 72, 142, 71);
            ctx.stroke();
        }

        ctx.font = !isBot ? '900 78px "Prompt", "Kanit", sans-serif' : '900 72px "Prompt", "Kanit", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 14;
        ctx.strokeText(label, 1024 / 2, 102);

        ctx.fillStyle = !isBot ? (pawnCfg.textColor || '#fef08a') : '#ffffff';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 14;
        ctx.fillText(label, 1024 / 2, 102);
        ctx.restore();
    }

    /**
     * สร้างหมากผู้เล่น 3D สุดเด่น (ฐานหมาก 3D เรืองแสง + วงเวทย์พื้น + เหรียญโปรไฟล์ลอยด้านหน้าสุดไม่โดนตึกบัง + มงกุฎ & ป้ายชื่อ "👑 คุณ")
     */

    /**
     * สร้าง 3D Arrow ชี้เหนือหัวผู้เล่นหลัก พร้อมป้าย "👇 ตัวเรา (YOU)" ชัดเจน 100%
     */

    /**
     * วาดรูปดาว 5 แฉกใน 2D Canvas คมชัดสูง
     */
    draw5PointStar(ctx, cx, cy, outerRadius, innerRadius, fillStyle, strokeStyle = null, lineWidth = 0) {
        let rot = -Math.PI / 2;
        const step = Math.PI / 5;
        ctx.save();
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
            const ox = cx + Math.cos(rot) * outerRadius;
            const oy = cy + Math.sin(rot) * outerRadius;
            if (i === 0) ctx.moveTo(ox, oy);
            else ctx.lineTo(ox, oy);
            rot += step;
            const ix = cx + Math.cos(rot) * innerRadius;
            const iy = cy + Math.sin(rot) * innerRadius;
            ctx.lineTo(ix, iy);
            rot += step;
        }
        ctx.closePath();
        if (fillStyle) {
            ctx.fillStyle = fillStyle;
            ctx.fill();
        }
        if (strokeStyle && lineWidth > 0) {
            ctx.strokeStyle = strokeStyle;
            ctx.lineWidth = lineWidth;
            ctx.stroke();
        }
        ctx.restore();
    }

    /**
     * 🎯 สัญลักษณ์บนหัวตัวละครผู้เล่น (รูป 2: Red Overhead Pin with Glowing Gold Star)
     * - ทรงกรวยสีแดงคว่ำชี้ลงหัว (Inverted Red Cone)
     * - จานขอบบานสีแดง (Flared Red Saucer / Flange)
     * - ถ้วยทรงกระบอกสีแดงด้านบน (Upper Red Cylindrical Crown)
     * - หน้าตัดด้านบนติดรูปดาวสีทองเรืองแสง (Glowing Yellow Star on flat top circle)
     */
    createPlayerOverheadIndicator(cardH, pScale = 1.0) {
        const group = new THREE.Group();
        const baseRenderOrder = 95;

        // กลุ่มหมุดสีแดง 3D หมุนวนได้รอบตัว (รูป 2)
        const pinGroup = new THREE.Group();

        const redMat = new THREE.MeshStandardMaterial({
            color: 0xef4444,
            emissive: 0xb91c1c,
            emissiveIntensity: 0.42,
            metalness: 0.22,
            roughness: 0.28,
            depthTest: false,
            depthWrite: false
        });

        // 1. กรวยคว่ำสีแดงชี้ลงหัวตัวละคร
        const coneH = 1.15 * pScale;
        const coneR = 0.72 * pScale;
        const coneGeo = new THREE.ConeGeometry(coneR, coneH, 32);
        const coneMesh = new THREE.Mesh(coneGeo, redMat);
        coneMesh.rotation.x = Math.PI; // คว่ำลงให้ปลายแหลมชี้ลง
        coneMesh.position.y = (coneH / 2); // จุดปลายแหลมแตะที่ y=0
        coneMesh.renderOrder = baseRenderOrder + 3;
        pinGroup.add(coneMesh);

        // 2. จานขอบบานสีแดงทรงจานบิน/ขอบกว้าง (Middle Flared Saucer)
        const saucerRTop = 1.28 * pScale;
        const saucerRBot = 1.05 * pScale;
        const saucerH = 0.22 * pScale;
        const saucerGeo = new THREE.CylinderGeometry(saucerRTop, saucerRBot, saucerH, 32);
        const saucerMesh = new THREE.Mesh(saucerGeo, redMat);
        saucerMesh.position.y = coneH + (saucerH / 2);
        saucerMesh.renderOrder = baseRenderOrder + 4;
        pinGroup.add(saucerMesh);

        // 3. ทรงกระบอกสีแดงส่วนบน (Upper Cylindrical Crown)
        const cupR = 0.70 * pScale;
        const cupH = 0.58 * pScale;
        const cupGeo = new THREE.CylinderGeometry(cupR, cupR, cupH, 32);
        const cupMesh = new THREE.Mesh(cupGeo, redMat);
        cupMesh.position.y = coneH + saucerH + (cupH / 2);
        cupMesh.renderOrder = baseRenderOrder + 5;
        pinGroup.add(cupMesh);

        // 4. หน้าตัดวงกลมด้านบน + รูปดาวสีทองเรืองแสง (Top Star Circle)
        const starCanvas = document.createElement('canvas');
        starCanvas.width = 256;
        starCanvas.height = 256;
        const sCtx = starCanvas.getContext('2d');
        sCtx.clearRect(0, 0, 256, 256);

        // พื้นหลังวงกลมสีแดงสดเหลือบมิติ
        const rGrad = sCtx.createRadialGradient(128, 128, 15, 128, 128, 124);
        rGrad.addColorStop(0, '#f87171');
        rGrad.addColorStop(0.55, '#dc2626');
        rGrad.addColorStop(1, '#991b1b');
        sCtx.fillStyle = rGrad;
        sCtx.beginPath();
        sCtx.arc(128, 128, 124, 0, Math.PI * 2);
        sCtx.fill();

        // ขอบทองประกายรอบหน้าตัด
        sCtx.strokeStyle = 'rgba(254, 240, 138, 0.9)';
        sCtx.lineWidth = 6;
        sCtx.stroke();

        // วาดดาวสีทอง 5 แฉกตรงกลาง (Golden Five-Point Star)
        sCtx.save();
        sCtx.shadowColor = '#fde047';
        sCtx.shadowBlur = 18;
        this.draw5PointStar(sCtx, 128, 128, 62, 28, '#fef08a', '#eab308', 4);
        sCtx.restore();

        const starTex = new THREE.CanvasTexture(starCanvas);
        starTex.minFilter = THREE.LinearFilter;
        starTex.magFilter = THREE.LinearFilter;
        const starMat = new THREE.MeshBasicMaterial({
            map: starTex,
            transparent: true,
            depthTest: false,
            depthWrite: false
        });
        const topStarDisc = new THREE.Mesh(new THREE.CircleGeometry(cupR * 0.98, 32), starMat);
        topStarDisc.rotation.x = -Math.PI / 2; // หันหน้าขึ้นฟ้า
        topStarDisc.position.y = coneH + saucerH + cupH + (0.01 * pScale);
        topStarDisc.renderOrder = baseRenderOrder + 6;
        pinGroup.add(topStarDisc);

        // ปรับมุมเอียงมาด้านหน้าเล็กน้อยเพื่อให้เห็นดาวและมิติด้านบนชัดเจน 100% จากมุมมองเกม
        pinGroup.rotation.x = 0.28;
        group.add(pinGroup);

        // 5. ป้ายสไปรต์ตัวหนังสือ "👇 ตัวเรา (YOU)" คมชัดสูง ลอยเหนือหมุดแดง
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 140;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, 512, 140);
        ctx.save();
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 18;

        const grad = ctx.createLinearGradient(0, 0, 512, 0);
        grad.addColorStop(0, '#b91c1c');
        grad.addColorStop(0.5, '#ef4444');
        grad.addColorStop(1, '#b91c1c');
        ctx.fillStyle = grad;

        const r = 24, x = 30, y = 20, w = 452, h = 90;
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
        ctx.fill();

        ctx.lineWidth = 5;
        ctx.strokeStyle = '#fde047';
        ctx.stroke();
        ctx.restore();

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '900 38px "Prompt", "Noto Sans Thai", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        ctx.fillText('👇 ตัวเรา (YOU)', 256, 68);

        const badgeTex = new THREE.CanvasTexture(canvas);
        badgeTex.minFilter = THREE.LinearFilter;
        badgeTex.magFilter = THREE.LinearFilter;
        const badgeMat = new THREE.SpriteMaterial({
            map: badgeTex,
            transparent: true,
            depthTest: false,
            depthWrite: false
        });
        const badgeSprite = new THREE.Sprite(badgeMat);
        badgeSprite.scale.set(4.4 * pScale, 1.35 * pScale, 1);
        badgeSprite.position.set(0, coneH + saucerH + cupH + 1.25 * pScale, 0.08);
        badgeSprite.renderOrder = baseRenderOrder + 7;
        group.add(badgeSprite);

        group.position.set(0, cardH / 2 + 2.35 * pScale, 0);
        return { group, coneMesh: pinGroup, haloMesh: null, pinGroup, baseY: cardH / 2 + 2.35 * pScale };
    }

    /**
     * แสดงตำแหน่งเป้าหมายปลายทางชัดเจน 3D เมื่อทอยเต๋าได้หรือเดินไปถึง
     */
    showDestinationBeacon(targetTileNum, totalSteps = 0, player = null) {
        if (!this.tiles || !this.tiles[targetTileNum]) return;
        const tPos = this.tiles[targetTileNum];
        const tileSize = this.tileSize || 6.2;
        const cityName = this.getProvinceName ? this.getProvinceName(targetTileNum) : `ช่อง ${targetTileNum}`;
        const goalTileNum = this.totalTilesCount || 100;

        let iconEmoji = '🎯';
        let specialTag = '✨ จุดหมายปลายทาง';
        let mainColor = '#00e5ff';
        let secondaryColor = '#ffd700';

        if (targetTileNum >= goalTileNum) {
            iconEmoji = '👑';
            specialTag = '🏆 เส้นชัยแห่งชัยชนะ!';
            mainColor = '#ffd700';
            secondaryColor = '#f59e0b';
        } else if (this.ladders && this.ladders[targetTileNum]) {
            iconEmoji = '🪜';
            specialTag = `🪜 บันไดทางลัดสู่ช่อง ${this.ladders[targetTileNum]}!`;
            mainColor = '#10b981';
            secondaryColor = '#6ee7b7';
        } else if (this.snakes && this.snakes[targetTileNum]) {
            iconEmoji = '🐍';
            specialTag = `⚠️ ระวัง! กับดักงูสไลด์ลงช่อง ${this.snakes[targetTileNum]}!`;
            mainColor = '#ef4444';
            secondaryColor = '#f87171';
        } else if (this.tileTypes && this.tileTypes[targetTileNum] === 'TAX') {
            iconEmoji = '💰';
            specialTag = '🏛️ ช่องเสียภาษีทรัพย์สิน';
            mainColor = '#f59e0b';
        } else if (this.tileTypes && this.tileTypes[targetTileNum] === 'CHANCE') {
            iconEmoji = '🎁';
            specialTag = '✨ หีบสมบัติเสี่ยงดวง';
            mainColor = '#a855f7';
        } else {
            iconEmoji = '🏙️';
            specialTag = `🏙️ เมือง ${cityName}`;
        }

        if (!this.destinationBeacon) {
            this.destinationBeacon = new THREE.Group();

            // 1. แผ่นเรืองแสงวงแหวนเวทย์มนตร์ 3D ความละเอียดสูงบนพื้นช่อง (High-Res Magic Mandala Floor Pad)
            const padCanvas = document.createElement('canvas');
            padCanvas.width = 1024;
            padCanvas.height = 1024;
            const padTex = new THREE.CanvasTexture(padCanvas);
            const padMat = new THREE.MeshBasicMaterial({
                map: padTex,
                transparent: true,
                opacity: 0.96,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const padMesh = new THREE.Mesh(new THREE.PlaneGeometry(tileSize * 1.05, tileSize * 1.05), padMat);
            padMesh.rotation.x = -Math.PI / 2;
            padMesh.position.y = 0.08;
            padMesh.renderOrder = 40;
            this.destinationBeacon.add(padMesh);
            this.destinationBeaconPad = { mesh: padMesh, canvas: padCanvas, tex: padTex };

            // 2. 💎 หมุดเพชรคริสตัลนีออน 3D ลอยหมุนชี้เป้าสุดพรีเมียม (Premium 3D Floating Diamond Target Marker)
            // (แทนที่แท่งทรงกระบอกสีฟ้าเดิม ด้วยอัญมณีลอยหมุนเรืองแสงประกายทองและนีออนสวยเด่น คมชัด สะอาดตา)
            const diamondGroup = new THREE.Group();
            diamondGroup.position.y = 2.65;

            const diamondGeo = new THREE.OctahedronGeometry(1.15, 0);
            const diamondMat = new THREE.MeshStandardMaterial({
                color: 0xffd700,
                emissive: 0x00e5ff,
                emissiveIntensity: 0.70,
                metalness: 0.88,
                roughness: 0.16
            });
            const diamondMesh = new THREE.Mesh(diamondGeo, diamondMat);
            diamondMesh.scale.set(0.95, 1.45, 0.95);
            diamondGroup.add(diamondMesh);

            const diamondWireMat = new THREE.MeshBasicMaterial({
                color: 0xffffff,
                wireframe: true,
                transparent: true,
                opacity: 0.65
            });
            const diamondWire = new THREE.Mesh(diamondGeo, diamondWireMat);
            diamondWire.scale.set(0.98, 1.48, 0.98);
            diamondGroup.add(diamondWire);

            // วงแหวนพลังงานนีออนโอบล้อมเพชร
            const haloRing = new THREE.Mesh(
                new THREE.TorusGeometry(1.42, 0.065, 8, 36),
                new THREE.MeshBasicMaterial({
                    color: 0x00e5ff,
                    transparent: true,
                    opacity: 0.88,
                    blending: THREE.AdditiveBlending
                })
            );
            haloRing.rotation.x = Math.PI / 2;
            diamondGroup.add(haloRing);

            // หัวลูกศรกรวยทองคว่ำชี้ลงกึ่งกลางช่อง (Arrow Pointer Downwards)
            const ptrGeo = new THREE.ConeGeometry(0.46, 0.85, 16);
            const ptrMat = new THREE.MeshStandardMaterial({
                color: 0xffd700,
                emissive: 0xffaa00,
                emissiveIntensity: 0.75,
                metalness: 0.90,
                roughness: 0.15
            });
            const ptrMesh = new THREE.Mesh(ptrGeo, ptrMat);
            ptrMesh.rotation.x = Math.PI;
            ptrMesh.position.y = -1.18;
            diamondGroup.add(ptrMesh);

            diamondGroup.renderOrder = 88;
            this.destinationBeacon.add(diamondGroup);
            this.destinationDiamond = diamondGroup;
            this.destDiamondHalo = haloRing;

            // 3. ป้ายบิลบอร์ดขนาดยักษ์คมชัด ลอยเหนือช่อง (Ultra-Crisp 3D Floating Glassmorphism Badge)
            // วางตำแหน่งที่ความสูง y = 5.6 พอเหมาะ ไม่สูงลอยลิบจนหลุดจอ และมองเห็นชัดเจนทั้งบน iOS และ Android
            const billboardCanvas = document.createElement('canvas');
            billboardCanvas.width = 1200;
            billboardCanvas.height = 340;
            const billboardTex = new THREE.CanvasTexture(billboardCanvas);
            const billboardMat = new THREE.SpriteMaterial({
                map: billboardTex,
                transparent: true,
                depthTest: false,
                depthWrite: false
            });
            const billboardSprite = new THREE.Sprite(billboardMat);
            billboardSprite.scale.set(10.8, 3.06, 1);
            billboardSprite.position.y = 5.6;
            billboardSprite.renderOrder = 160;
            this.destinationBeacon.add(billboardSprite);
            this.destinationBillboard = { sprite: billboardSprite, canvas: billboardCanvas, tex: billboardTex };
            this.destBillboardBaseY = 5.6;

            this.scene.add(this.destinationBeacon);
        }

        // วาดแผ่นเป้าหมายบนพื้น (High-Res 1024x1024 Magic Floor Mandala)
        const pCtx = this.destinationBeaconPad.canvas.getContext('2d');
        pCtx.clearRect(0, 0, 1024, 1024);
        pCtx.save();
        pCtx.translate(512, 512);

        // Radial glow background
        const radGrad = pCtx.createRadialGradient(0, 0, 60, 0, 0, 490);
        radGrad.addColorStop(0, 'rgba(255, 215, 0, 0.60)');
        radGrad.addColorStop(0.35, 'rgba(0, 229, 255, 0.42)');
        radGrad.addColorStop(0.70, 'rgba(255, 215, 0, 0.20)');
        radGrad.addColorStop(1, 'rgba(0, 229, 255, 0)');
        pCtx.fillStyle = radGrad;
        pCtx.beginPath();
        pCtx.arc(0, 0, 490, 0, Math.PI * 2);
        pCtx.fill();

        // Outer neon gold ring
        pCtx.strokeStyle = '#ffd700';
        pCtx.lineWidth = 14;
        pCtx.shadowColor = '#ffd700';
        pCtx.shadowBlur = 24;
        pCtx.beginPath();
        pCtx.arc(0, 0, 430, 0, Math.PI * 2);
        pCtx.stroke();

        // Inner dashed cyan ring
        pCtx.strokeStyle = '#00e5ff';
        pCtx.lineWidth = 10;
        pCtx.shadowColor = '#00e5ff';
        pCtx.shadowBlur = 20;
        pCtx.setLineDash([32, 20]);
        pCtx.beginPath();
        pCtx.arc(0, 0, 350, 0, Math.PI * 2);
        pCtx.stroke();
        pCtx.setLineDash([]);

        // Star / Compass ticks
        pCtx.strokeStyle = '#ffffff';
        pCtx.lineWidth = 6;
        for (let i = 0; i < 8; i++) {
            const ang = (i * Math.PI) / 4;
            pCtx.beginPath();
            pCtx.moveTo(Math.cos(ang) * 270, Math.sin(ang) * 270);
            pCtx.lineTo(Math.cos(ang) * 330, Math.sin(ang) * 330);
            pCtx.stroke();
        }

        // Center bright jewel core
        pCtx.fillStyle = '#ffffff';
        pCtx.shadowColor = '#00e5ff';
        pCtx.shadowBlur = 30;
        pCtx.beginPath();
        pCtx.arc(0, 0, 52, 0, Math.PI * 2);
        pCtx.fill();

        pCtx.restore();
        this.destinationBeaconPad.tex.needsUpdate = true;

        // วาดป้ายบิลบอร์ดขนาดยักษ์คมชัด ลอยเหนือช่อง (1200 x 340)
        const bCtx = this.destinationBillboard.canvas.getContext('2d');
        bCtx.clearRect(0, 0, 1200, 340);
        bCtx.save();
        bCtx.shadowColor = mainColor || '#00e5ff';
        bCtx.shadowBlur = 26;

        const bgGrad = bCtx.createLinearGradient(0, 0, 1200, 340);
        bgGrad.addColorStop(0, '#061426');
        bgGrad.addColorStop(0.5, '#0b2647');
        bgGrad.addColorStop(1, '#051120');
        bCtx.fillStyle = bgGrad;

        const bx = 24, by = 18, bw = 1152, bh = 304, br = 42;
        bCtx.beginPath();
        bCtx.moveTo(bx + br, by);
        bCtx.arcTo(bx + bw, by, bx + bw, by + bh, br);
        bCtx.arcTo(bx + bw, by + bh, bx, by + bh, br);
        bCtx.arcTo(bx, by + bh, bx, by, br);
        bCtx.arcTo(bx, by, bx + bw, by, br);
        bCtx.closePath();
        bCtx.fill();

        // Double border: gold and secondary
        bCtx.lineWidth = 8;
        bCtx.strokeStyle = secondaryColor || '#ffd700';
        bCtx.stroke();

        bCtx.lineWidth = 3;
        bCtx.strokeStyle = mainColor || '#00e5ff';
        bCtx.stroke();
        bCtx.restore();

        // Icon Circle on Left
        bCtx.save();
        bCtx.fillStyle = 'rgba(255, 255, 255, 0.12)';
        bCtx.beginPath();
        bCtx.arc(155, 170, 95, 0, Math.PI * 2);
        bCtx.fill();
        bCtx.lineWidth = 6;
        bCtx.strokeStyle = mainColor || '#00e5ff';
        bCtx.shadowColor = mainColor || '#00e5ff';
        bCtx.shadowBlur = 18;
        bCtx.stroke();
        bCtx.font = '92px sans-serif';
        bCtx.textAlign = 'center';
        bCtx.textBaseline = 'middle';
        bCtx.fillText(iconEmoji, 155, 175);
        bCtx.restore();

        // Text Content on Right
        bCtx.textAlign = 'left';
        bCtx.textBaseline = 'middle';

        // 1. Top row: Destination badge & step count
        bCtx.font = '700 36px "Prompt", sans-serif';
        bCtx.fillStyle = '#38bdf8';
        bCtx.shadowColor = 'rgba(56, 189, 248, 0.8)';
        bCtx.shadowBlur = 12;
        const stepTxt = totalSteps > 0 ? ` (ทอยได้ ${totalSteps} แต้ม)` : '';
        bCtx.fillText(`🎯 เป้าหมายปลายทาง${stepTxt}`, 280, 80);

        // 2. Middle row: City / Tile name (Bold & Crisp)
        bCtx.font = '900 64px "Prompt", sans-serif';
        bCtx.fillStyle = '#ffffff';
        bCtx.shadowColor = 'rgba(0, 0, 0, 0.95)';
        bCtx.shadowBlur = 14;
        bCtx.fillText(`${cityName} [ช่อง ${targetTileNum}]`, 280, 165);

        // 3. Bottom row: Special info / Event tag pill
        bCtx.font = '600 36px "Prompt", sans-serif';
        bCtx.fillStyle = secondaryColor || '#ffd700';
        bCtx.shadowColor = secondaryColor || '#ffd700';
        bCtx.shadowBlur = 10;
        bCtx.fillText(specialTag, 280, 248);

        this.destinationBillboard.tex.needsUpdate = true;

        this.destinationBeacon.position.set(tPos.x, tPos.y || 0, tPos.z);
        this.destinationBeacon.visible = true;
        this.currentTargetTile = targetTileNum;
        if (this.landingPinGroup) {
            this.landingPinGroup.visible = false;
        }
    }

    /**
     * ซ่อนเป้าหมายปลายทาง พร้อมเอฟเฟกต์พลุ/แสงระเบิดลงช่องถึงที่หมาย (Landing Arrival Burst)
     */
    hideDestinationBeacon(showBurst = true) {
        if (!this.destinationBeacon || !this.destinationBeacon.visible) return;
        if (showBurst && this.currentTargetTile && this.tiles[this.currentTargetTile]) {
            const tPos = this.tiles[this.currentTargetTile];
            this.triggerLandingArrivalFX(tPos);
        }
        this.destinationBeacon.visible = false;
        this.currentTargetTile = null;
    }

    /**
     * เอฟเฟกต์เมื่อตัวหมากเดินทางมาถึงปลายทาง (วงแหวนระเบิดแสงเรืองรอง + พลุอนุภาค)
     */
    triggerLandingArrivalFX(pos) {
        if (!this.scene) return;
        const ringGeo = new THREE.RingGeometry(0.8, 3.8, 32);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0x00e5ff,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 1.0,
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });
        const burstRing = new THREE.Mesh(ringGeo, ringMat);
        burstRing.rotation.x = -Math.PI / 2;
        burstRing.position.set(pos.x, (pos.y || 0) + 0.2, pos.z);
        burstRing.renderOrder = 80;
        this.scene.add(burstRing);

        let startT = performance.now();
        const animBurst = () => {
            const burstElapsed = (performance.now() - startT) / 550;
            if (burstElapsed >= 1.0) {
                this.scene.remove(burstRing);
                ringGeo.dispose();
                ringMat.dispose();
                return;
            }
            const s = 1.0 + burstElapsed * 1.8;
            burstRing.scale.set(s, s, s);
            burstRing.material.opacity = (1.0 - burstElapsed);
            requestAnimationFrame(animBurst);
        };
        requestAnimationFrame(animBurst);
    }

    /**
     * 📍 สร้างหมุดปลายทางลงช่อง 3D (รูป 1: Green Landing Pin with Star)
     * - ทรงกรวยสีเขียวมะนาว/มรกตชี้ลงช่อง (Inverted Lime Green Cone)
     * - ขอบจานโค้งมน (Rounded Flared Rim)
     * - โดมด้านบนพร้อมรูปดาวสีเขียวเข้มเรืองแสง (Dome top with Dark Green Star in glowing disc)
     * - เงาสะท้อนนุ่มนวลบนพื้นช่อง (Soft Radial Shadow on Tile Floor)
     */
    createLandingPin() {
        if (this.landingPinGroup) return this.landingPinGroup;

        const group = new THREE.Group();
        group.name = 'landingPinGroup';

        // 1. เงาสะท้อนนุ่มนวลบนพื้นช่อง (Soft Radial Drop Shadow on Tile)
        const shadowCanvas = document.createElement('canvas');
        shadowCanvas.width = 256;
        shadowCanvas.height = 256;
        const sCtx = shadowCanvas.getContext('2d');
        sCtx.clearRect(0, 0, 256, 256);
        const radG = sCtx.createRadialGradient(128, 128, 10, 128, 128, 120);
        radG.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
        radG.addColorStop(0.35, 'rgba(15, 45, 10, 0.40)');
        radG.addColorStop(0.70, 'rgba(34, 197, 94, 0.22)');
        radG.addColorStop(1, 'rgba(0, 0, 0, 0)');
        sCtx.fillStyle = radG;
        sCtx.beginPath();
        sCtx.arc(128, 128, 120, 0, Math.PI * 2);
        sCtx.fill();

        const shadowTex = new THREE.CanvasTexture(shadowCanvas);
        const shadowMat = new THREE.MeshBasicMaterial({
            map: shadowTex,
            transparent: true,
            opacity: 0.90,
            depthWrite: false
        });
        const shadowMesh = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 3.6), shadowMat);
        shadowMesh.rotation.x = -Math.PI / 2;
        shadowMesh.position.y = 0.08;
        shadowMesh.renderOrder = 42;
        group.add(shadowMesh);

        // 2. ตัวหมุดสีเขียว 3D (รูป 1: Green 3D Pin Body)
        const pinBody = new THREE.Group();
        pinBody.name = 'landingPinBody';

        const limeMat = new THREE.MeshStandardMaterial({
            color: 0x84cc16,
            emissive: 0x22c55e,
            emissiveIntensity: 0.45,
            metalness: 0.18,
            roughness: 0.22
        });

        // กรวยคว่ำสีเขียวชี้ลงพื้นช่อง
        const coneH = 1.85;
        const coneR = 1.22;
        const coneGeo = new THREE.ConeGeometry(coneR, coneH, 32);
        const coneMesh = new THREE.Mesh(coneGeo, limeMat);
        coneMesh.rotation.x = Math.PI; // คว่ำลง
        coneMesh.position.y = (coneH / 2); // ปลายแหลมแตะที่ y=0
        coneMesh.renderOrder = 85;
        pinBody.add(coneMesh);

        // ขอบจานโค้งมนตรงกลาง
        const rimH = 0.35;
        const rimRTop = 1.48;
        const rimRBot = 1.22;
        const rimGeo = new THREE.CylinderGeometry(rimRTop, rimRBot, rimH, 32);
        const rimMesh = new THREE.Mesh(rimGeo, limeMat);
        rimMesh.position.y = coneH + (rimH / 2);
        rimMesh.renderOrder = 86;
        pinBody.add(rimMesh);

        // โดมกลมมนด้านบน (Rounded Top Dome)
        const domeGeo = new THREE.SphereGeometry(rimRTop, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
        const domeMesh = new THREE.Mesh(domeGeo, limeMat);
        domeMesh.position.y = coneH + rimH;
        pinBody.add(domeMesh);

        // หน้าตัดวงกลมและดาวสีเขียวเข้มตรงกลาง (รูป 1)
        const starCanvas = document.createElement('canvas');
        starCanvas.width = 256;
        starCanvas.height = 256;
        const stCtx = starCanvas.getContext('2d');
        stCtx.clearRect(0, 0, 256, 256);

        // พื้นหลังวงกลมสีเขียวอ่อนนวลประกายแสง
        const stGrad = stCtx.createRadialGradient(128, 128, 15, 128, 128, 124);
        stGrad.addColorStop(0, '#ffffff');
        stGrad.addColorStop(0.35, '#d9f99d');
        stGrad.addColorStop(0.70, '#84cc16');
        stGrad.addColorStop(1, '#4d7c0f');
        stCtx.fillStyle = stGrad;
        stCtx.beginPath();
        stCtx.arc(128, 128, 124, 0, Math.PI * 2);
        stCtx.fill();

        // ดาวสีเขียวสดใสตรงกลาง
        stCtx.save();
        stCtx.shadowColor = '#16a34a';
        stCtx.shadowBlur = 14;
        this.draw5PointStar(stCtx, 128, 128, 62, 28, '#22c55e', '#15803d', 4);
        stCtx.restore();

        const starTex = new THREE.CanvasTexture(starCanvas);
        starTex.minFilter = THREE.LinearFilter;
        starTex.magFilter = THREE.LinearFilter;
        const starMat = new THREE.MeshBasicMaterial({
            map: starTex,
            transparent: true,
            depthWrite: false
        });
        const starDisc = new THREE.Mesh(new THREE.CircleGeometry(1.18, 32), starMat);
        starDisc.rotation.x = -Math.PI / 2;
        starDisc.position.y = coneH + rimH + 0.22;
        starDisc.renderOrder = 88;
        pinBody.add(starDisc);

        // เอียงมาด้านหน้าเล็กน้อยให้สอดคล้องกับมุมมองเกมแบบในรูป 1
        pinBody.rotation.x = 0.28;
        pinBody.position.y = 1.35; // ความสูงลอยเหนือพื้น
        group.add(pinBody);

        this.landingPinGroup = group;
        this.landingPinBody = pinBody;
        this.landingPinShadow = shadowMesh;
        this.landingPinBaseY = 1.35;

        if (this.scene) {
            this.scene.add(group);
        }
        return group;
    }

    /**
     * 📍 แสดงหมุดปลายทางลงช่อง (รูป 1) ไปยังช่องที่กำหนด
     */
    showLandingPin(tileNum) {
        if (!this.tiles || !this.tiles[tileNum]) return;
        const tPos = this.tiles[tileNum];
        const pin = this.createLandingPin();
        pin.position.set(tPos.x, (tPos.y || 0), tPos.z);
        pin.visible = true;
        this.currentLandingTile = tileNum;
    }

    createPawnMesh(color, isAwakened, playerData = {}) {
        const pawnGroup = new THREE.Group();
        const isBot = Boolean(playerData.is_bot);
        const rimColor = isAwakened ? 0x00e5ff : (color || 0x00e5ff);
        const hexStr = '#' + Number(rimColor).toString(16).padStart(6, '0');
        const baseRenderOrder = isBot ? 56 : 72;
        const pScaleInit = Math.max(0.6, Math.min(2.0, Number(this.badgeConfig?.pawn?.scale) || 1.0));
        const cardW = (isBot ? 2.8 : 3.2) * pScaleInit;
        const cardH = cardW * 1.2;
        const trayW = cardW * 0.34;
        const trayH = cardH;
        const cardOffset = -trayW * 0.45;
        const trayOffset = cardW * 0.5 + trayW * 0.08;
        const baseFloatY = isBot ? 2.55 : 2.85;

        const groundAuraGeo = new THREE.RingGeometry(1.15, 1.85, 32);
        const groundAuraMat = new THREE.MeshBasicMaterial({
            color: rimColor,
            transparent: true,
            opacity: isAwakened ? 0.6 : 0.4,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        const groundAuraMesh = new THREE.Mesh(groundAuraGeo, groundAuraMat);
        groundAuraMesh.rotation.x = -Math.PI / 2;
        groundAuraMesh.position.y = 0.08;
        pawnGroup.add(groundAuraMesh);

        const beamGeo = new THREE.CylinderGeometry(0.45, 1.55, 4.5, 24, 1, true);
        const beamMat = new THREE.MeshBasicMaterial({
            color: rimColor,
            transparent: true,
            opacity: isAwakened ? 0.14 : 0.08,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        const spotlightBeam = new THREE.Mesh(beamGeo, beamMat);
        spotlightBeam.position.y = 2.25;
        pawnGroup.add(spotlightBeam);

        const badgeGroup = new THREE.Group();
        badgeGroup.position.set(0, baseFloatY, 0);

        const auraCvs = document.createElement('canvas');
        auraCvs.width = 128;
        auraCvs.height = 128;
        const aCtx = auraCvs.getContext('2d');
        const aGrad = aCtx.createRadialGradient(64, 64, 10, 64, 64, 62);
        aGrad.addColorStop(0, 'rgba(255,255,255,0.9)');
        aGrad.addColorStop(0.55, 'rgba(255,255,255,0.35)');
        aGrad.addColorStop(1, 'rgba(255,255,255,0)');
        aCtx.fillStyle = aGrad;
        aCtx.fillRect(0, 0, 128, 128);
        const cardAuraTex = new THREE.CanvasTexture(auraCvs);

        const auraRingMat = new THREE.MeshBasicMaterial({
            map: cardAuraTex,
            color: rimColor,
            transparent: true,
            opacity: isAwakened ? 0.55 : 0.35,
            depthTest: false,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });

        const auraRingMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(cardW * 1.65, cardH * 1.65),
            auraRingMat
        );
        auraRingMesh.position.set(cardOffset, 0, -0.04);
        auraRingMesh.renderOrder = baseRenderOrder - 1;
        badgeGroup.add(auraRingMesh);

        // วงแหวนเออร่าแจ้งเตือนใกล้ถึงเส้นชัย 5-8 ช่อง (Near Finish Alert Aura)
        const nearFinishAuraMat = new THREE.MeshBasicMaterial({
            map: cardAuraTex,
            color: 0xffa500,
            transparent: true,
            opacity: 0,
            depthTest: false,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
        const nearFinishAura = new THREE.Mesh(
            new THREE.PlaneGeometry(cardW * 2.0, cardH * 2.0),
            nearFinishAuraMat
        );
        nearFinishAura.position.set(cardOffset, 0, -0.06);
        nearFinishAura.renderOrder = baseRenderOrder - 2;
        nearFinishAura.visible = false;
        badgeGroup.add(nearFinishAura);

        // แคนวาสสำหรับการ์ดตัวละครฝั่งซ้าย (Left Character Card)
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 614;
        const avatarTex = new THREE.CanvasTexture(canvas);
        avatarTex.anisotropy = 8;

        const avatarMat = new THREE.MeshBasicMaterial({
            map: avatarTex,
            transparent: true,
            alphaTest: 0.05,
            depthTest: false,
            depthWrite: false,
            side: THREE.DoubleSide
        });

        // แผ่นการ์ดตัวละคร (Card Mesh)
        const cardGeo = new THREE.PlaneGeometry(cardW, cardH);
        const circularMesh = new THREE.Mesh(cardGeo, avatarMat); // circularMesh alias for backwards compatibility
        circularMesh.position.set(cardOffset, 0, 0.04);
        circularMesh.renderOrder = baseRenderOrder + 1;
        badgeGroup.add(circularMesh);

        // กรอบสี่เหลี่ยมเรืองแสง 3D Neon Frame Border ครอบเฉพาะการ์ดตัวละคร
        const frameBorderGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(cardW + 0.08, cardH + 0.08, 0.06));
        const rimMat = new THREE.LineBasicMaterial({
            color: rimColor,
            depthTest: false,
            depthWrite: false
        });
        const torusFrame = new THREE.LineSegments(frameBorderGeo, rimMat); // torusFrame alias for color updates
        torusFrame.position.set(cardOffset, 0, 0);
        torusFrame.renderOrder = baseRenderOrder + 2;
        badgeGroup.add(torusFrame);

        const pScale = Math.max(0.6, Math.min(2.0, Number(this.badgeConfig?.pawn?.scale) || 1.0));
        let overheadInd = null;
        const pIdxCheck = (playerData && (playerData.playerIndex !== undefined ? playerData.playerIndex : (playerData.index !== undefined ? playerData.index : (playerData.player_index !== undefined ? playerData.player_index : 0)))) || 0;
        const isLocalUser = Boolean(playerData && (playerData.is_local_user || playerData.is_me || (!playerData.is_bot && pIdxCheck === 0 && typeof playerData.is_local_user === 'undefined' && typeof playerData.is_me === 'undefined')));
        let outerGoldRim = null;
        let crownGem = null;
        if (isLocalUser) {
            // 🎯 ลูกศรชี้บนหัวผู้เล่นหลัก + ป้าย "👇 ตัวเรา (YOU)" เหนือการ์ดตัวละคร
            overheadInd = this.createPlayerOverheadIndicator(cardH, pScale);
            overheadInd.group.position.x = cardOffset;
            badgeGroup.add(overheadInd.group);

            // กรอบทองคำซ้อนชั้นนอกสำหรับการ์ดผู้เล่นจริง
            const outerGoldFrameGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(cardW + 0.22, cardH + 0.22, 0.04));
            outerGoldRim = new THREE.LineSegments(
                outerGoldFrameGeo,
                new THREE.LineBasicMaterial({
                    color: 0xffd700,
                    depthTest: false,
                    depthWrite: false
                })
            );
            outerGoldRim.position.set(cardOffset, 0, 0);
            outerGoldRim.renderOrder = baseRenderOrder + 2;
            badgeGroup.add(outerGoldRim);

            // มงกุฎเพชรทองคำ 3D บนยอดกรอบตัวผู้เล่นของเรา
            crownGem = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.26),
                new THREE.MeshBasicMaterial({
                    color: 0xffe066,
                    depthTest: false,
                    depthWrite: false
                })
            );
            crownGem.position.set(cardOffset, cardH / 2 + 0.28, 0.06);
            crownGem.renderOrder = baseRenderOrder + 3;
            badgeGroup.add(crownGem);
        }

        // =========================================================================
        // 💎 ถาดอัญมณี 3 ช่องด้านนอกกรอบการ์ดฝั่งขวา (Gem Sockets Tray Outside Frame)
        // =========================================================================
        const sideTrayCanvas = document.createElement('canvas');
        sideTrayCanvas.width = 240;
        sideTrayCanvas.height = 720;
        const sideTrayTex = new THREE.CanvasTexture(sideTrayCanvas);
        sideTrayTex.anisotropy = 8;
        const sideTrayMat = new THREE.MeshBasicMaterial({
            map: sideTrayTex,
            transparent: true,
            alphaTest: 0.02,
            depthTest: false,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        const sideTrayMesh = new THREE.Mesh(new THREE.PlaneGeometry(trayW, trayH), sideTrayMat);
        sideTrayMesh.position.set(trayOffset, 0, 0.06);
        sideTrayMesh.renderOrder = baseRenderOrder + 3;
        badgeGroup.add(sideTrayMesh);

        // 💎 ระบบอัญมณีสวมใส่วนรอบตัวละคร 3D (Gem Orbit System)
        const gemOrbitGroup = new THREE.Group();
        const pIndexNum = (playerData && (playerData.playerIndex !== undefined ? playerData.playerIndex : (playerData.index !== undefined ? playerData.index : (playerData.player_index !== undefined ? playerData.player_index : 0)))) || 0;
        gemOrbitGroup.name = 'gemOrbitGroup_' + pIndexNum;
        gemOrbitGroup.position.set(cardOffset, cardH * 0.45, 0);
        badgeGroup.add(gemOrbitGroup);
        const resolvedInitialGems = playerData.equippedGems || playerData.equipped_gems || (!isBot && typeof window.getEquippedGemsList === 'function' ? window.getEquippedGemsList() : []) || (!isBot && window.DEFAULT_USER?.equipped_gems) || [];

        // ✨ ระบบเอฟเฟกต์หมุนเออร่าและประกายดาว 3D ประจำช่องอัญมณีข้างกรอบ
        const sideGemsGroup = new THREE.Group();
        sideGemsGroup.name = 'sideGemsGroup_' + pIndexNum;
        sideGemsGroup.position.set(trayOffset, 0, 0.08);
        badgeGroup.add(sideGemsGroup);

        // 3. ป้ายชื่อลอยเหนือหัว ("👑 คุณ: [ชื่อ]" ขนาดใหญ่ คมชัดพิเศษ มองเห็นชัดเจน 100%)
        const isMobileOrTablet = (typeof window !== 'undefined') && (window.innerWidth <= 1024 || /Android|iPhone|iPad|iPod|Safari/i.test(navigator.userAgent));
        const nameCanvas = document.createElement('canvas');
        nameCanvas.width = isMobileOrTablet ? 512 : 1024;
        nameCanvas.height = isMobileOrTablet ? 130 : 260;
        const username = playerData.displayName || playerData.name || playerData.username || '';
        this.drawPawnNameTagCanvas(nameCanvas, username, hexStr, isBot, isLocalUser);
        const nameTex = new THREE.CanvasTexture(nameCanvas);
        nameTex.minFilter = isMobileOrTablet ? THREE.LinearFilter : THREE.LinearMipmapLinearFilter;
        nameTex.magFilter = THREE.LinearFilter;
        nameTex.generateMipmaps = !isMobileOrTablet;
        nameTex.anisotropy = isMobileOrTablet ? 1 : 4;
        const nameSprite = new THREE.Sprite(
            new THREE.SpriteMaterial({
                map: nameTex,
                transparent: true,
                depthTest: false,
                depthWrite: false
            })
        );
        nameSprite.scale.set((isBot ? 8.2 : 9.8) * pScale, (isBot ? 2.08 : 2.5) * pScale, 1);
        nameSprite.position.set(cardOffset, cardH / 2 + (isBot ? 1.05 : 1.35) * pScale, 0.1);
        nameSprite.renderOrder = baseRenderOrder + 6;
        badgeGroup.add(nameSprite);

        pawnGroup.add(badgeGroup);

        const { provider, avatarUrl } = isBot
            ? { provider: 'bot', avatarUrl: playerData.picture || playerData.pictureUrl || playerData.avatar_url || '' }
            : this.resolvePlayerAvatarInfo(playerData);

        pawnGroup.userData = {
            badgeGroup,
            baseFloatY,
            circularMesh,
            torusFrame,
            outerGoldRim,
            crownGem,
            auraRingMesh,
            nearFinishAura,
            nearFinishAuraMat,
            playerIndicator: (!isBot && overheadInd) ? overheadInd.group : null,
            indicatorCone: (!isBot && overheadInd) ? overheadInd.coneMesh : null,
            indicatorHalo: (!isBot && overheadInd) ? overheadInd.haloMesh : null,
            playerIndicatorBaseY: (!isBot && overheadInd) ? overheadInd.baseY : 0,
            groundAuraMesh,
            spotlightBeam,
            nameCanvas,
            nameTex,
            nameSprite,
            isBot,
            avatarCanvas: canvas,
            avatarTex,
            avatarMat,
            sideTrayCanvas,
            sideTrayTex,
            sideTrayMat,
            sideTrayMesh,
            cardOffset,
            trayOffset,
            colorHex: color,
            provider,
            isAwakened,
            character_grade: playerData.character_grade || null,
            aura_type: playerData.aura_type || null,
            cardW,
            cardH,
            trayW,
            trayH,
            gemOrbitGroup,
            equippedGems: resolvedInitialGems,
            sideGemsGroup,
            playerData
        };

        this.rebuildSideGems3D(pawnGroup, resolvedInitialGems);

        this.applyAvatarTextureToPawn(
            pawnGroup,
            avatarUrl,
            username,
            color,
            isBot,
            provider,
            playerData.character_grade || null,
            playerData.aura_type || null
        );

        if (this.camera) {
            badgeGroup.lookAt(this.camera.position);
        }

        // โหลดโมเดล 3D Mesh จริง (GLB, GLTF, FBX, OBJ, BLEND) หากตัวละครมีการติดตั้งโมเดล 3D
        const model3dUrl = playerData.model_3d_url || (playerData.is_bot ? '' : window.DEFAULT_USER?.model_3d_url);
        const modelFormat = playerData.model_format || (playerData.is_bot ? '' : window.DEFAULT_USER?.model_format);
        if (model3dUrl && window.ag && window.ag.space && typeof window.ag.space.load3DModel === 'function') {
            window.ag.space.load3DModel(model3dUrl, { format: modelFormat, targetHeight: isBot ? 2.2 : 2.6 }).then(res => {
                if (res && res.group) {
                    res.group.position.y = 0.35;
                    pawnGroup.add(res.group);
                    badgeGroup.position.y = baseFloatY + 1.25;
                    pawnGroup.userData.model3dGroup = res.group;
                    pawnGroup.userData.model3dMixer = res.mixer;
                }
            }).catch(e => {
                console.warn('Game3D: Could not load 3D pawn model:', e);
            });
        }

        return pawnGroup;
    }

    /**
     * วาดและโหลดรูปโปรไฟล์ลงบนแผ่นตัวหมากทรงกลม 512x512 พร้อมขอบสีและเออร่า
     */
    applyAvatarTextureToPawn(pawnGroup, avatarUrl, username = '', colorHex = 0x00e5ff, isBot = false, provider = '', grade = null, auraType = null, equippedGems = null) {
        if (!pawnGroup || !pawnGroup.userData || !pawnGroup.userData.avatarCanvas) return;
        const canvas = pawnGroup.userData.avatarCanvas;
        const size = canvas.width || 512;
        const center = size / 2;
        const outerRadius = center - 6;
        const imageRadius = outerRadius - 14;
        const ctx = canvas.getContext('2d');
        const tex = pawnGroup.userData.avatarTex;

        let resolvedProvider = provider || pawnGroup.userData.provider || '';
        let resolvedUrl = avatarUrl;
        if (!isBot && (!resolvedUrl || !resolvedProvider)) {
            const info = this.resolvePlayerAvatarInfo({
                picture: avatarUrl,
                pictureUrl: avatarUrl,
                auth_provider: resolvedProvider
            });
            if (!resolvedUrl) resolvedUrl = info.avatarUrl;
            if (!resolvedProvider) resolvedProvider = info.provider;
        }
        pawnGroup.userData.provider = resolvedProvider;
        pawnGroup.userData.avatarUrl = resolvedUrl;
        pawnGroup.userData.username = username;
        pawnGroup.userData.colorHex = colorHex;
        pawnGroup.userData.isBot = isBot;
        if (equippedGems) pawnGroup.userData.equippedGems = equippedGems;

        const resolvedGrade = (
            grade ||
            pawnGroup.userData.character_grade ||
            (!isBot ? (window.equippedFrameGrade || window.DEFAULT_USER?.character_grade || localStorage.getItem('snake_equipped_frame_grade')) : null) ||
            'A'
        ).toUpperCase();
        const resolvedAura = (
            auraType ||
            pawnGroup.userData.aura_type ||
            (!isBot ? (window.equippedFrameAura || localStorage.getItem('snake_equipped_frame_aura')) : '') ||
            ''
        );
        pawnGroup.userData.character_grade = resolvedGrade;
        pawnGroup.userData.aura_type = resolvedAura;

        let primaryBorderColor = '#00e5ff';
        let secondaryBorderColor = '#ffd700';
        let shadowBlurVal = 22;
        const auraLow = String(resolvedAura || '').toLowerCase();
        if (isBot) {
            primaryBorderColor = '#' + (colorHex || 0xff3d00).toString(16).padStart(6, '0');
            secondaryBorderColor = primaryBorderColor;
            shadowBlurVal = 14;
        } else if (auraLow === 'orange' || auraLow === 'fire') {
            primaryBorderColor = '#ff6a00';
            secondaryBorderColor = '#fde047';
            shadowBlurVal = 32;
        } else if (auraLow === 'crimson' || auraLow === 'red') {
            primaryBorderColor = '#ff2244';
            secondaryBorderColor = '#fca5a5';
            shadowBlurVal = 32;
        } else if (auraLow === 'purple' || auraLow === 'cosmic' || auraLow === 'vortex') {
            primaryBorderColor = '#c084fc';
            secondaryBorderColor = '#38bdf8';
            shadowBlurVal = 32;
        } else if (auraLow === 'rainbow') {
            primaryBorderColor = '#00e5ff';
            secondaryBorderColor = '#ec4899';
            shadowBlurVal = 34;
        } else if (resolvedGrade === 'SS+' || auraLow === 'gold' || auraLow === 'divine') {
            primaryBorderColor = '#ffd700';
            secondaryBorderColor = '#fffbeb';
            shadowBlurVal = 32;
        } else if (resolvedGrade === 'S+' || auraLow === 'yellow') {
            primaryBorderColor = '#facc15';
            secondaryBorderColor = '#fef08a';
            shadowBlurVal = 26;
        } else if (resolvedGrade === 'S' || auraLow === 'cyan' || auraLow === 'electric') {
            primaryBorderColor = '#00e5ff';
            secondaryBorderColor = '#bae6fd';
            shadowBlurVal = 22;
        } else if (resolvedGrade === 'A+' || auraLow === 'white') {
            primaryBorderColor = '#ffffff';
            secondaryBorderColor = '#cbd5e1';
            shadowBlurVal = 16;
        } else {
            primaryBorderColor = '#00e5ff';
            secondaryBorderColor = '#ffd700';
            shadowBlurVal = 18;
        }

        pawnGroup.userData.primaryBorderColor = primaryBorderColor;
        pawnGroup.userData.secondaryBorderColor = secondaryBorderColor;
        pawnGroup.userData.shadowBlurVal = shadowBlurVal;

        if (pawnGroup.userData.torusFrame && pawnGroup.userData.torusFrame.material) {
            const cObj = new THREE.Color(primaryBorderColor);
            pawnGroup.userData.torusFrame.material.color.copy(cObj);
            if (pawnGroup.userData.torusFrame.material.emissive) {
                pawnGroup.userData.torusFrame.material.emissive.copy(cObj);
            }
        }
        if (pawnGroup.userData.outerGoldRim && pawnGroup.userData.outerGoldRim.material) {
            pawnGroup.userData.outerGoldRim.material.color.set(secondaryBorderColor);
        }
        if (pawnGroup.userData.auraRingMesh && pawnGroup.userData.auraRingMesh.material) {
            const newAuraTex = this.createPawnCardAuraTexture(primaryBorderColor, !isBot, secondaryBorderColor);
            pawnGroup.userData.auraRingMesh.material.map = newAuraTex;
            pawnGroup.userData.auraRingMesh.material.needsUpdate = true;
        }
        if (pawnGroup.userData.groundAuraMesh && pawnGroup.userData.groundAuraMesh.material) {
            const newGroundTex = this.createPawnAuraRingTexture(primaryBorderColor, !isBot, secondaryBorderColor);
            pawnGroup.userData.groundAuraMesh.material.map = newGroundTex;
            pawnGroup.userData.groundAuraMesh.material.needsUpdate = true;
        }

        if (pawnGroup.userData.nameCanvas && pawnGroup.userData.nameTex) {
            this.drawPawnNameTagCanvas(
                pawnGroup.userData.nameCanvas,
                username,
                primaryBorderColor,
                Boolean(isBot)
            );
            pawnGroup.userData.nameTex.needsUpdate = true;
        }

        const canvasW = canvas.width || 512;
        const canvasH = canvas.height || 614;

        // ฟังก์ชันวาดอัญมณีเหลี่ยมประกายแสงพร้อมวงแหวนวงโคจรและประกายดาวตรงตามภาพต้นแบบ
        const drawFacetedGemOnCanvas = (targetCtx, cx, cy, dsize = 112, shape = 'triangle', gemColor = '#c084fc') => {
            targetCtx.save();
            const r = dsize / 2;
            const s = String(shape || 'triangle').toLowerCase();
            const color = gemColor || (s.includes('tri') ? '#c084fc' : (s.includes('sq') || s.includes('dia') ? '#38bdf8' : '#fbbf24'));

            const shadeColor = (hex, pct) => {
                if (typeof window.adjustColorBrightness === 'function') {
                    return window.adjustColorBrightness(hex, pct);
                }
                let c = String(hex || '#c084fc').replace('#', '');
                if (c.length === 3) c = c.split('').map(x => x + x).join('');
                const num = parseInt(c, 16) || 0xc084fc;
                const amt = Math.round(2.55 * pct);
                const R = Math.min(255, Math.max(0, (num >> 16) + amt));
                const G = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amt));
                const B = Math.min(255, Math.max(0, (num & 0x0000FF) + amt));
                return '#' + ((1 << 24) + (R << 16) + (G << 8) + B).toString(16).slice(1);
            };
            const lightCol = shadeColor(color, 42);
            const darkCol = shadeColor(color, -38);
            const deepCol = shadeColor(color, -55);

            // 1. วงแหวนวงโคจรเส้นประเรืองแสงรอบอัญมณี (Rotating Dashed Circular Orbit Ring)
            targetCtx.save();
            targetCtx.beginPath();
            targetCtx.arc(cx, cy, r * 1.06, 0, Math.PI * 2);
            targetCtx.setLineDash([5, 5]);
            targetCtx.strokeStyle = lightCol;
            targetCtx.lineWidth = 2.6;
            targetCtx.shadowColor = color;
            targetCtx.shadowBlur = 12;
            targetCtx.stroke();
            targetCtx.restore();

            // 2. รังสีเรืองแสงออร่ารอบอัญมณี
            const gemGlow = targetCtx.createRadialGradient(cx, cy, 2, cx, cy, r * 0.98);
            gemGlow.addColorStop(0, lightCol + 'aa');
            gemGlow.addColorStop(0.55, color + '55');
            gemGlow.addColorStop(1, 'transparent');
            targetCtx.fillStyle = gemGlow;
            targetCtx.beginPath();
            targetCtx.arc(cx, cy, r * 0.98, 0, Math.PI * 2);
            targetCtx.fill();

            // 3. วาดรูปทรงอัญมณี (Triangle 🔺, Pentagon ⬠, หรือ Square/Diamond 🔷)
            targetCtx.save();
            targetCtx.shadowColor = color;
            targetCtx.shadowBlur = 14;

            if (s.includes('tri')) {
                // ทรงสามเหลี่ยมพีระมิด (Faceted Triangle 🔺) ตามรูปต้นแบบ 1
                const topY = cy - r * 0.78;
                const botY = cy + r * 0.62;
                const leftX = cx - r * 0.78;
                const rightX = cx + r * 0.78;
                const coreX = cx;
                const coreY = cy + r * 0.10;

                // Facet ซ้าย (เฉดกลางเข้ม)
                targetCtx.beginPath();
                targetCtx.moveTo(cx, topY);
                targetCtx.lineTo(leftX, botY);
                targetCtx.lineTo(coreX, coreY);
                targetCtx.closePath();
                targetCtx.fillStyle = color;
                targetCtx.fill();

                // Facet ขวา (เฉดลาเวนเดอร์สว่างสะท้อนแสงตามรูป 1)
                targetCtx.beginPath();
                targetCtx.moveTo(cx, topY);
                targetCtx.lineTo(rightX, botY);
                targetCtx.lineTo(coreX, coreY);
                targetCtx.closePath();
                targetCtx.fillStyle = lightCol;
                targetCtx.fill();

                // Facet ล่าง (เฉดเข้มลึก)
                targetCtx.beginPath();
                targetCtx.moveTo(leftX, botY);
                targetCtx.lineTo(rightX, botY);
                targetCtx.lineTo(coreX, coreY);
                targetCtx.closePath();
                targetCtx.fillStyle = deepCol;
                targetCtx.fill();

                // เส้นแบ่งเหลี่ยมภายใน
                targetCtx.beginPath();
                targetCtx.moveTo(cx, topY); targetCtx.lineTo(coreX, coreY);
                targetCtx.moveTo(leftX, botY); targetCtx.lineTo(coreX, coreY);
                targetCtx.moveTo(rightX, botY); targetCtx.lineTo(coreX, coreY);
                targetCtx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
                targetCtx.lineWidth = 1.6;
                targetCtx.stroke();

                // ขอบนอกเรืองแสง
                targetCtx.beginPath();
                targetCtx.moveTo(cx, topY); targetCtx.lineTo(rightX, botY); targetCtx.lineTo(leftX, botY); targetCtx.closePath();
                targetCtx.strokeStyle = lightCol;
                targetCtx.lineWidth = 2.4;
                targetCtx.stroke();

                // จุดแสงสีขาวกึ่งกลาง (White Center Spot)
                targetCtx.beginPath();
                targetCtx.arc(coreX, coreY, 4.2, 0, Math.PI * 2);
                targetCtx.fillStyle = '#ffffff';
                targetCtx.shadowColor = '#ffffff';
                targetCtx.shadowBlur = 10;
                targetCtx.fill();
            } else if (s.includes('penta')) {
                // ทรงห้าเหลี่ยม (Faceted Pentagon ⬠)
                const pts = [];
                const innerPts = [];
                for (let a = 0; a < 5; a++) {
                    const angle = -Math.PI / 2 + (a * 2 * Math.PI) / 5;
                    pts.push({ x: cx + Math.cos(angle) * r * 0.78, y: cy + Math.sin(angle) * r * 0.78 });
                    innerPts.push({ x: cx + Math.cos(angle) * r * 0.42, y: cy + Math.sin(angle) * r * 0.42 });
                }
                for (let a = 0; a < 5; a++) {
                    const next = (a + 1) % 5;
                    targetCtx.beginPath();
                    targetCtx.moveTo(cx, cy);
                    targetCtx.lineTo(pts[a].x, pts[a].y);
                    targetCtx.lineTo(pts[next].x, pts[next].y);
                    targetCtx.closePath();
                    targetCtx.fillStyle = a === 0 || a === 1 ? lightCol : (a === 2 || a === 3 ? darkCol : color);
                    targetCtx.fill();
                }
                targetCtx.beginPath();
                targetCtx.moveTo(innerPts[0].x, innerPts[0].y);
                for (let a = 1; a < 5; a++) targetCtx.lineTo(innerPts[a].x, innerPts[a].y);
                targetCtx.closePath();
                targetCtx.fillStyle = color;
                targetCtx.fill();
                targetCtx.strokeStyle = '#ffffff';
                targetCtx.lineWidth = 1.5;
                targetCtx.stroke();

                targetCtx.beginPath();
                targetCtx.moveTo(pts[0].x, pts[0].y);
                for (let a = 1; a < 5; a++) targetCtx.lineTo(pts[a].x, pts[a].y);
                targetCtx.closePath();
                targetCtx.strokeStyle = lightCol;
                targetCtx.lineWidth = 2.2;
                targetCtx.stroke();

                targetCtx.beginPath();
                targetCtx.arc(cx, cy, 4.0, 0, Math.PI * 2);
                targetCtx.fillStyle = '#ffffff';
                targetCtx.fill();
            } else {
                // ทรงสี่เหลี่ยมข้าวหลามตัด (Faceted Square / Diamond 🔷)
                const outerR = r * 0.80;
                const innerR = r * 0.42;
                const top = { x: cx, y: cy - outerR };
                const right = { x: cx + outerR, y: cy };
                const bot = { x: cx, y: cy + outerR };
                const left = { x: cx - outerR, y: cy };

                const quadPts = [top, right, bot, left];
                const quadCols = [lightCol, color, deepCol, darkCol];
                for (let q = 0; q < 4; q++) {
                    const nq = (q + 1) % 4;
                    targetCtx.beginPath();
                    targetCtx.moveTo(cx, cy);
                    targetCtx.lineTo(quadPts[q].x, quadPts[q].y);
                    targetCtx.lineTo(quadPts[nq].x, quadPts[nq].y);
                    targetCtx.closePath();
                    targetCtx.fillStyle = quadCols[q];
                    targetCtx.fill();
                }

                targetCtx.beginPath();
                targetCtx.moveTo(cx, cy - innerR);
                targetCtx.lineTo(cx + innerR, cy);
                targetCtx.lineTo(cx, cy + innerR);
                targetCtx.lineTo(cx - innerR, cy);
                targetCtx.closePath();
                targetCtx.fillStyle = lightCol;
                targetCtx.fill();
                targetCtx.strokeStyle = '#ffffff';
                targetCtx.lineWidth = 1.6;
                targetCtx.stroke();

                targetCtx.beginPath();
                targetCtx.moveTo(top.x, top.y);
                targetCtx.lineTo(right.x, right.y);
                targetCtx.lineTo(bot.x, bot.y);
                targetCtx.lineTo(left.x, left.y);
                targetCtx.closePath();
                targetCtx.strokeStyle = '#ffffff';
                targetCtx.lineWidth = 2.2;
                targetCtx.stroke();

                targetCtx.beginPath();
                targetCtx.arc(cx, cy, 3.8, 0, Math.PI * 2);
                targetCtx.fillStyle = '#ffffff';
                targetCtx.fill();
            }
            targetCtx.restore();

            // 4. ประกายดาววิบวับ 4 แฉกครบ 4 มุมตามรูปต้นแบบ 1 (Twinkling Sparkle Stars ✦)
            const sparks = [
                { x: cx - r * 0.60, y: cy - r * 0.48, sz: 8.5, col: '#ffffff' },
                { x: cx + r * 0.58, y: cy - r * 0.44, sz: 6.5, col: '#fef08a' },
                { x: cx + r * 0.64, y: cy + r * 0.52, sz: 5.5, col: '#67e8f9' },
                { x: cx - r * 0.64, y: cy + r * 0.58, sz: 6.5, col: lightCol }
            ];
            sparks.forEach(sp => {
                targetCtx.save();
                targetCtx.shadowColor = sp.col;
                targetCtx.shadowBlur = 8;
                targetCtx.fillStyle = sp.col;
                targetCtx.beginPath();
                targetCtx.moveTo(sp.x, sp.y - sp.sz);
                targetCtx.quadraticCurveTo(sp.x, sp.y, sp.x + sp.sz, sp.y);
                targetCtx.quadraticCurveTo(sp.x, sp.y, sp.x, sp.y + sp.sz);
                targetCtx.quadraticCurveTo(sp.x, sp.y, sp.x - sp.sz, sp.y);
                targetCtx.quadraticCurveTo(sp.x, sp.y, sp.x, sp.y - sp.sz);
                targetCtx.closePath();
                targetCtx.fill();
                targetCtx.restore();
            });

            targetCtx.restore();
        };

        const drawFacetedDiamond = (targetCtx, cx, cy, dsize = 64) => {
            drawFacetedGemOnCanvas(targetCtx, cx, cy, dsize, 'diamond', '#00e5ff');
        };

        // =========================================================================
        // 1. วาดการ์ดตัวละครฝั่งซ้าย (Left Character Card) บรรจุในกรอบอย่างสวยงาม
        // =========================================================================
        const drawCharacterCard = (imgObj = null) => {
            ctx.clearRect(0, 0, canvasW, canvasH);
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            const cardX = 8;
            const cardY = 8;
            const cardW = canvasW - 16;
            const cardH = canvasH - 16;
            const cardRadius = 30;

            ctx.save();
            ctx.beginPath();
            if (typeof ctx.roundRect === 'function') {
                ctx.roundRect(cardX, cardY, cardW, cardH, cardRadius);
            } else {
                ctx.rect(cardX, cardY, cardW, cardH);
            }
            ctx.closePath();
            ctx.clip();

            // 1. วาดรูปโปรไฟล์หรือพื้นหลังการ์ด
            if (imgObj) {
                const imgW = imgObj.naturalWidth || imgObj.width || cardW;
                const imgH = imgObj.naturalHeight || imgObj.height || cardH;
                const scale = Math.max(cardW / imgW, cardH / imgH);
                const drawW = imgW * scale;
                const drawH = imgH * scale;
                const offsetX = cardX + (cardW - drawW) / 2;
                const offsetY = cardY + (cardH - drawH) / 2;
                ctx.drawImage(imgObj, offsetX, offsetY, drawW, drawH);
            } else {
                const bgGrad = ctx.createRadialGradient(cardX + cardW / 2, cardY + cardH * 0.44, 20, cardX + cardW / 2, cardY + cardH / 2, cardW);
                bgGrad.addColorStop(0, '#1e293b');
                bgGrad.addColorStop(1, '#090d16');
                ctx.fillStyle = bgGrad;
                ctx.fillRect(cardX, cardY, cardW, cardH);

                ctx.font = `bold ${Math.round(cardW * 0.38)}px "Kanit", sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#ffffff';
                const cleanName = String(username || '').replace(/🤖|บอท|\(AI\)/gi, '').trim();
                const label = cleanName ? Array.from(cleanName)[0].toUpperCase() : '👤';
                ctx.fillText(label, cardX + cardW / 2, cardY + cardH * 0.44);
            }

            ctx.restore(); // คลาย clip (ไม่มีวงกลมทับใบหน้าด้านใน แสดงเอฟเฟกต์เฉพาะที่ขอบกรอบเท่านั้น)

            // 2. เอฟเฟกต์แสงออร่าที่ขอบกรอบการ์ดสี่เหลี่ยม (Frame Border Aura & Corner Effects Only)
            ctx.save();
            ctx.beginPath();
            if (typeof ctx.roundRect === 'function') {
                ctx.roundRect(cardX, cardY, cardW, cardH, cardRadius);
            } else {
                ctx.rect(cardX, cardY, cardW, cardH);
            }
            const borderGrad = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
            borderGrad.addColorStop(0, primaryBorderColor);
            borderGrad.addColorStop(0.5, secondaryBorderColor || '#ffe600');
            borderGrad.addColorStop(1, primaryBorderColor);
            ctx.strokeStyle = borderGrad;
            ctx.lineWidth = 12;
            ctx.shadowColor = primaryBorderColor;
            ctx.shadowBlur = shadowBlurVal;
            ctx.stroke();

            // เส้นประกายคริสตัลชั้นในตามแนวขอบกรอบสี่เหลี่ยม
            ctx.beginPath();
            if (typeof ctx.roundRect === 'function') {
                ctx.roundRect(cardX + 6, cardY + 6, cardW - 12, cardH - 12, Math.max(4, cardRadius - 5));
            } else {
                ctx.rect(cardX + 6, cardY + 6, cardW - 12, cardH - 12);
            }
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
            ctx.lineWidth = 2.8;
            ctx.shadowColor = secondaryBorderColor || '#ffffff';
            ctx.shadowBlur = 10;
            ctx.stroke();
            ctx.shadowBlur = 0;

            // 4. ป้ายเกรดตัวละครมุมบนซ้าย (Top-Left SS+ Emblem)
            const displayGrade = resolvedGrade || 'SS+';
            ctx.font = '900 italic 52px "Kanit", sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.lineWidth = 8;
            ctx.strokeStyle = '#000000';
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 8;
            ctx.strokeText(displayGrade, cardX + 18, cardY + 16);
            ctx.fillStyle = '#fff000';
            ctx.shadowBlur = 0;
            ctx.fillText(displayGrade, cardX + 18, cardY + 16);

            // 5. ป้ายเลเวลมุมล่างขวา (Bottom-Right Lv30 Badge)
            const pLevel = (!isBot && window.DEFAULT_USER?.level) ? window.DEFAULT_USER.level : 30;
            ctx.font = '900 italic 42px "Kanit", sans-serif';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'bottom';
            ctx.lineWidth = 7;
            ctx.strokeStyle = '#000000';
            ctx.shadowColor = '#000000';
            ctx.shadowBlur = 8;
            ctx.strokeText('Lv.' + pLevel, cardX + cardW - 16, cardY + cardH - 14);
            ctx.fillStyle = '#fff000';
            ctx.shadowBlur = 0;
            ctx.fillText('Lv.' + pLevel, cardX + cardW - 16, cardY + cardH - 14);

            ctx.restore();
            tex.needsUpdate = true;
            if (pawnGroup.userData.avatarMat) {
                pawnGroup.userData.avatarMat.needsUpdate = true;
            }
        };

        // =========================================================================
        // 2. วาดคอลัมน์ถาดอัญมณี 3 ช่องนอกกรอบ (Right Gem Sockets Tray Outside Frame)
        // =========================================================================
        const drawSideTraySockets = () => {
            if (!pawnGroup.userData || !pawnGroup.userData.sideTrayCanvas) return;
            const tCanvas = pawnGroup.userData.sideTrayCanvas;
            const tctx = tCanvas.getContext('2d');
            const tw = tCanvas.width || 240;
            const th = tCanvas.height || 720;

            tctx.clearRect(0, 0, tw, th);
            tctx.imageSmoothingEnabled = true;
            tctx.imageSmoothingQuality = 'high';

            // ดึงรายการอัญมณีที่ติดตั้งจริง
            let equippedList = [];
            if (Array.isArray(pawnGroup.userData?.equippedGems) && pawnGroup.userData.equippedGems.length > 0) {
                equippedList = pawnGroup.userData.equippedGems;
            } else if (!isBot) {
                if (typeof window.getEquippedGemsList === 'function') {
                    equippedList = window.getEquippedGemsList() || [];
                }
                if ((!equippedList || equippedList.length === 0) && window.playerGemsData?.equippedSlots) {
                    equippedList = Array.isArray(window.playerGemsData.equippedSlots)
                        ? window.playerGemsData.equippedSlots.filter(Boolean)
                        : Object.values(window.playerGemsData.equippedSlots).filter(Boolean);
                }
                if ((!equippedList || equippedList.length === 0) && Array.isArray(window.DEFAULT_USER?.equipped_gems)) {
                    equippedList = window.DEFAULT_USER.equipped_gems;
                }
            } else if (isBot) {
                equippedList = pawnGroup.userData?.playerData?.equipped_gems || [];
            }

            const slots = [null, null, null];
            if (Array.isArray(equippedList)) {
                equippedList.forEach(g => {
                    if (!g) return;
                    const s = (Number(g.slot_index) >= 1 && Number(g.slot_index) <= 3) ? (Number(g.slot_index) - 1) : -1;
                    if (s >= 0) slots[s] = g;
                });
                let nextIdx = 0;
                equippedList.forEach(g => {
                    if (!g) return;
                    if (Number(g.slot_index) >= 1 && Number(g.slot_index) <= 3) return;
                    while (nextIdx < 3 && slots[nextIdx]) nextIdx++;
                    if (nextIdx < 3) {
                        slots[nextIdx] = g;
                        nextIdx++;
                    }
                });
            }

            // แสดงถาด 3 ช่องข้างกรอบเสมอ (ช่องที่ยังไม่สวมใส่จะแสดงเฉพาะกรอบรูปทรงอัญมณี 3 เหลี่ยม / 4 เหลี่ยม / 5 เหลี่ยม)
            if (pawnGroup.userData.sideTrayMesh) pawnGroup.userData.sideTrayMesh.visible = true;
            if (pawnGroup.userData.sideGemsGroup) pawnGroup.userData.sideGemsGroup.visible = true;

            // 1. ถาดแคปซูลแก้วเรืองแสงครอบ 3 ช่อง สีเงา/เออร่าเดียวกับกรอบการ์ด (Aura-Tinted Glass Capsule Outer Tray)
            const frameMainCol = primaryBorderColor || '#00e5ff';
            const frameSecCol = secondaryBorderColor || '#ffd700';
            const pad = 12;
            tctx.save();

            // เงาออร่าฟุ้งรอบถาดให้เป็นสีเดียวกับกรอบการ์ด/เออร่า
            tctx.shadowColor = frameMainCol;
            tctx.shadowBlur = Math.max(18, shadowBlurVal || 22);

            tctx.beginPath();
            if (typeof tctx.roundRect === 'function') {
                tctx.roundRect(pad, pad, tw - pad * 2, th - pad * 2, 36);
            } else {
                tctx.rect(pad, pad, tw - pad * 2, th - pad * 2);
            }
            const trayGrad = tctx.createLinearGradient(0, 0, tw, th);
            trayGrad.addColorStop(0, safeHexToRgba(frameMainCol, 0.58));
            trayGrad.addColorStop(0.5, safeHexToRgba(frameSecCol, 0.42));
            trayGrad.addColorStop(1, safeHexToRgba(frameMainCol, 0.64));
            tctx.fillStyle = trayGrad;
            tctx.fill();

            // ขอบนีออนไล่เฉดสีเดียวกับกรอบการ์ดและเออร่า
            const trayBorderGrad = tctx.createLinearGradient(pad, pad, tw - pad, th - pad);
            trayBorderGrad.addColorStop(0, frameMainCol);
            trayBorderGrad.addColorStop(0.5, frameSecCol);
            trayBorderGrad.addColorStop(1, frameMainCol);
            tctx.strokeStyle = trayBorderGrad;
            tctx.lineWidth = 6.5;
            tctx.shadowColor = frameMainCol;
            tctx.shadowBlur = Math.max(18, shadowBlurVal || 22);
            tctx.stroke();

            // เส้นประกายคริสตัลชั้นในของถาดแคปซูล (เหมือนขอบชั้นในของการ์ด)
            tctx.beginPath();
            if (typeof tctx.roundRect === 'function') {
                tctx.roundRect(pad + 5, pad + 5, tw - (pad + 5) * 2, th - (pad + 5) * 2, 31);
            } else {
                tctx.rect(pad + 5, pad + 5, tw - (pad + 5) * 2, th - (pad + 5) * 2);
            }
            tctx.strokeStyle = 'rgba(255, 255, 255, 0.88)';
            tctx.lineWidth = 2.2;
            tctx.shadowColor = frameSecCol;
            tctx.shadowBlur = 10;
            tctx.stroke();
            tctx.shadowBlur = 0;

            // สีขอบนีออนประจำ 3 ช่องและสีอัญมณีผสานกับสีกรอบการ์ด/เออร่า
            const slotColors = [frameMainCol, frameSecCol, frameMainCol];
            const defaultGemColors = ['#c084fc', '#38bdf8', '#fbbf24'];
            const defaultShapes = ['triangle', 'square', 'pentagon'];
            const boxW = 186;
            const boxH = 186;
            const boxRadius = 32;
            const bx = Math.round((tw - boxW) / 2);
            const boxYs = [37, 267, 497];

            for (let i = 0; i < 3; i++) {
                const by = boxYs[i];
                const gem = slots[i];
                const slotColor = (gem && gem.gem_color) ? gem.gem_color : slotColors[i];
                const gemColor = (gem && gem.gem_color) ? gem.gem_color : defaultGemColors[i];
                const gemShape = (gem && gem.shape) ? gem.shape : defaultShapes[i];
                const cx = bx + boxW / 2;
                const cy = by + boxH / 2;

                // 2. กล่องสี่เหลี่ยมมุมมนพร้อมสีเงา/พื้นหลังเรืองแสงตามกรอบการ์ด (Aura-Tinted Socket Box)
                tctx.save();
                tctx.beginPath();
                if (typeof tctx.roundRect === 'function') {
                    tctx.roundRect(bx, by, boxW, boxH, boxRadius);
                } else {
                    tctx.rect(bx, by, boxW, boxH);
                }
                const boxGrad = tctx.createLinearGradient(bx, by, bx + boxW, by + boxH);
                if (gem) {
                    boxGrad.addColorStop(0, safeHexToRgba(slotColor, 0.52));
                    boxGrad.addColorStop(0.5, safeHexToRgba(frameMainCol, 0.36));
                    boxGrad.addColorStop(1, safeHexToRgba(slotColor, 0.58));
                } else {
                    boxGrad.addColorStop(0, safeHexToRgba(frameMainCol, 0.48));
                    boxGrad.addColorStop(0.5, safeHexToRgba(frameSecCol, 0.32));
                    boxGrad.addColorStop(1, safeHexToRgba(frameMainCol, 0.54));
                }
                tctx.shadowColor = gem ? slotColor : frameMainCol;
                tctx.shadowBlur = gem ? 18 : 15;
                tctx.fillStyle = boxGrad;
                tctx.fill();

                // แสงออร่าเรืองรองกึ่งกลางช่อง (แสดงทั้งตอนใส่อัญมณีและช่องว่างเพื่อให้สีเงาเข้ากับกรอบการ์ด)
                const glowCol = gem ? gemColor : (i % 2 === 0 ? frameMainCol : frameSecCol);
                const spotGrad = tctx.createRadialGradient(cx, cy, 4, cx, cy, boxW * 0.48);
                spotGrad.addColorStop(0, safeHexToRgba(glowCol, gem ? 0.62 : 0.45));
                spotGrad.addColorStop(0.55, safeHexToRgba(frameMainCol, gem ? 0.28 : 0.22));
                spotGrad.addColorStop(1, 'transparent');
                tctx.fillStyle = spotGrad;
                tctx.beginPath();
                tctx.arc(cx, cy, boxW * 0.46, 0, Math.PI * 2);
                tctx.fill();

                // ขอบช่องอัญมณีสีเดียวกับกรอบการ์ด/เออร่า
                const boxBorderGrad = tctx.createLinearGradient(bx, by, bx + boxW, by + boxH);
                boxBorderGrad.addColorStop(0, gem ? slotColor : frameMainCol);
                boxBorderGrad.addColorStop(0.5, frameSecCol);
                boxBorderGrad.addColorStop(1, gem ? slotColor : frameMainCol);
                tctx.strokeStyle = boxBorderGrad;
                tctx.lineWidth = gem ? 5.5 : 4.2;
                tctx.shadowColor = gem ? slotColor : frameMainCol;
                tctx.shadowBlur = gem ? 18 : 14;
                tctx.stroke();
                tctx.shadowBlur = 0;

                if (gem) {
                    // 3. วาดอัญมณีเหลี่ยมประกายแสงขนาดใหญ่คมชัด (เฉพาะช่องที่ใส่อัญมณีจริง)
                    drawFacetedGemOnCanvas(tctx, cx, cy, 112, gemShape, gemColor);
                } else {
                    // ยังไม่ได้สวมใส่อัญมณี: แสดงกรอบเส้นรูปทรงอัญมณีเรืองแสงสีเดียวกับกรอบการ์ด/เออร่า
                    const sides = (gemShape === 'triangle') ? 3 : ((gemShape === 'square' || gemShape === 'diamond') ? 4 : 5);
                    const r = 46;
                    tctx.save();
                    tctx.beginPath();
                    for (let k = 0; k < sides; k++) {
                        const ang = -Math.PI / 2 + (k * 2 * Math.PI / sides) + (sides === 4 ? Math.PI / 4 : 0);
                        const px = cx + r * Math.cos(ang);
                        const py = cy + r * Math.sin(ang);
                        if (k === 0) tctx.moveTo(px, py);
                        else tctx.lineTo(px, py);
                    }
                    tctx.closePath();
                    tctx.fillStyle = safeHexToRgba(frameSecCol, 0.22);
                    tctx.fill();
                    tctx.setLineDash([10, 6]);
                    tctx.strokeStyle = frameSecCol;
                    tctx.shadowColor = frameMainCol;
                    tctx.shadowBlur = 12;
                    tctx.lineWidth = 4.8;
                    tctx.stroke();
                    tctx.setLineDash([]);
                    tctx.restore();
                }

                tctx.restore();
            }

            tctx.restore();
            if (pawnGroup.userData.sideTrayTex) {
                pawnGroup.userData.sideTrayTex.needsUpdate = true;
            }
            if (pawnGroup.userData.sideTrayMat) {
                pawnGroup.userData.sideTrayMat.needsUpdate = true;
            }
        };

        const drawFullCardAndGemsComposition = (imgObj = null) => {
            drawCharacterCard(imgObj);

            // การแสดงผลถาดอัญมณี 3 ช่อง ควบคุมโดย drawSideTraySockets() ตามอัญมณีที่ใส่จริง

            const effectiveCardOffset = pawnGroup.userData.cardOffset || -0.52;
            const effectiveTrayOffset = pawnGroup.userData.trayOffset || 1.98;

            if (pawnGroup.userData.circularMesh) pawnGroup.userData.circularMesh.position.x = effectiveCardOffset;
            if (pawnGroup.userData.torusFrame) pawnGroup.userData.torusFrame.position.x = effectiveCardOffset;
            if (pawnGroup.userData.outerGoldRim) pawnGroup.userData.outerGoldRim.position.x = effectiveCardOffset;
            if (pawnGroup.userData.crownGem) pawnGroup.userData.crownGem.position.x = effectiveCardOffset;
            if (pawnGroup.userData.auraRingMesh) pawnGroup.userData.auraRingMesh.position.x = effectiveCardOffset;
            if (pawnGroup.userData.nearFinishAura) pawnGroup.userData.nearFinishAura.position.x = effectiveCardOffset;
            if (pawnGroup.userData.nameSprite) pawnGroup.userData.nameSprite.position.x = effectiveCardOffset;
            if (pawnGroup.userData.playerIndicator) pawnGroup.userData.playerIndicator.position.x = effectiveCardOffset;
            if (pawnGroup.userData.gemOrbitGroup) pawnGroup.userData.gemOrbitGroup.position.x = effectiveCardOffset;

            if (pawnGroup.userData.sideTrayMesh) pawnGroup.userData.sideTrayMesh.position.x = effectiveTrayOffset;
            if (pawnGroup.userData.sideGemsGroup) pawnGroup.userData.sideGemsGroup.position.x = effectiveTrayOffset;

            drawSideTraySockets();
        };

        const drawFallbackBadge = () => {
            drawFullCardAndGemsComposition(null);
        };

        const drawLoadedImage = (imgObj) => {
            drawFullCardAndGemsComposition(imgObj);
        };

        drawFallbackBadge();

        if (!resolvedUrl && isBot && typeof window.buildOpponentAvatarSvgDataUrl === 'function') {
            resolvedUrl = window.buildOpponentAvatarSvgDataUrl(Math.floor(Math.random() * 16));
        }

        if (!resolvedUrl) return;

        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.referrerPolicy = 'no-referrer';
        img.onload = () => drawLoadedImage(img);
        img.onerror = () => {
            if (/^https?:\/\//i.test(resolvedUrl) && !resolvedUrl.includes('avatar_proxy')) {
                const proxyImg = new Image();
                proxyImg.crossOrigin = 'anonymous';
                proxyImg.onload = () => drawLoadedImage(proxyImg);
                proxyImg.src = 'api/auth.php?action=avatar_proxy&url=' + encodeURIComponent(resolvedUrl);
            } else if (!String(resolvedUrl).includes('google_avatar.png')) {
                const fb = new Image();
                fb.onload = () => drawLoadedImage(fb);
                fb.src = 'avatars/google_avatar.png';
            }
        };
        img.src = resolvedUrl;
    }

    /**
     * อัปเดตรูปโปรไฟล์บนหมากผู้เล่น (เรียกจาก ui.js หลังล็อกอิน / สวมใส่กรอบ)
     */
    updatePlayerPawnAvatar(playerIndex = 0, avatarUrlOrUserObj = '', username = '', provider = '', grade = null, auraType = null) {
        if (this.isMatchActive && this.players && this.players.length > 0) {
            const targetP = this.players[playerIndex];
            if (!targetP || !this.isLocalPlayer(targetP)) {
                const localIdx = (typeof this.getLocalPlayerIndex === 'function') ? this.getLocalPlayerIndex() : -1;
                if (localIdx === -1) return;
                playerIndex = localIdx;
            }
        }
        if (!this.players || !this.players[playerIndex]) {
            // หากอยู่ในโหมดสแตนด์บาย (Idle Lobby) และมีหมาก 3D อยู่บนกระดาน ให้รีเฟรชภาพของหมากนั้นทันที
            if (this.pawnsGroup && this.pawnsGroup.children.length > 0) {
                const pawn = this.pawnsGroup.children[0];
                let resolvedUrl = typeof avatarUrlOrUserObj === 'object' ? (avatarUrlOrUserObj.avatar_url || avatarUrlOrUserObj.picture || avatarUrlOrUserObj.pictureUrl) : avatarUrlOrUserObj;
                if (!resolvedUrl && typeof window.getActivePlayerAvatarUrl === 'function') {
                    resolvedUrl = window.getActivePlayerAvatarUrl(avatarUrlOrUserObj);
                }
                const uname = username || (typeof avatarUrlOrUserObj === 'object' ? (avatarUrlOrUserObj.displayName || avatarUrlOrUserObj.name || avatarUrlOrUserObj.username) : '') || pawn.userData?.username || '';
                this.applyAvatarTextureToPawn(pawn, resolvedUrl, uname, pawn.userData?.colorHex || 0x00e5ff, false, provider, grade, auraType);
                this.rebuildSideGems3D(pawn);
            }
            return;
        }
        const p = this.players[playerIndex];

        let resolvedUrl = '';
        let resolvedProvider = provider;

        if (avatarUrlOrUserObj && typeof avatarUrlOrUserObj === 'object') {
            const info = this.resolvePlayerAvatarInfo(avatarUrlOrUserObj);
            resolvedUrl = info.avatarUrl;
            resolvedProvider = info.provider;
            if (!username) {
                username = avatarUrlOrUserObj.displayName || avatarUrlOrUserObj.name || avatarUrlOrUserObj.username || '';
            }
        } else {
            resolvedUrl = String(avatarUrlOrUserObj || '').trim();
            if (!resolvedUrl) {
                const info = this.resolvePlayerAvatarInfo(p);
                resolvedUrl = info.avatarUrl;
                if (!resolvedProvider) resolvedProvider = info.provider;
            }
        }

        if (username) p.username = username;
        if (resolvedProvider) p.auth_provider = resolvedProvider;
        if (resolvedUrl) {
            p.avatar_url = resolvedUrl;
            p.picture = resolvedUrl;
            p.pictureUrl = resolvedUrl;
        }
        if (grade) p.character_grade = grade;
        if (auraType) p.aura_type = auraType;

        if (p.mesh) {
            this.applyAvatarTextureToPawn(
                p.mesh,
                resolvedUrl || p.avatar_url || p.picture || p.pictureUrl,
                p.username,
                p.color,
                Boolean(p.is_bot),
                resolvedProvider,
                grade || p.character_grade,
                auraType || p.aura_type
            );
            this.rebuildSideGems3D(p.mesh, p.equippedGems || p.equipped_gems);
        }
        this.updateActiveTurnUI();
        this.hideDestinationBeacon(true);
        this.saveGameState();
    }

    /**
     * แสดงกล่องข้อความ / อิโมจิ (Speech Bubble) ลอยเหนือหัวตัวหมาก 3D
     */
    showSpeechBubble(playerIndexOrObj = 0, message = '', durationMs = 4000) {
        const text = String(message || '').trim();
        if (!text || !this.players || !this.players.length) return;

        let pIndex = 0;
        let player = null;
        if (typeof playerIndexOrObj === 'number') {
            pIndex = playerIndexOrObj;
            player = this.players[pIndex];
        } else if (playerIndexOrObj && typeof playerIndexOrObj === 'object') {
            player = playerIndexOrObj;
            pIndex = Math.max(0, this.players.indexOf(player));
        }
        if (!player || !player.mesh) return;

        // ตรวจสอบว่าถ้าคนพูดเป็นคนอื่นและ @ หาผู้เล่นหลัก ให้ขึ้นแจ้งเตือน "ชื่อ..พูดถึงคุณ"
        if (pIndex !== 0 && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
            const speakerName = player.username || player.displayName || 'ผู้เล่น';
            const speakerAvatar = player.avatar_url || player.picture || 'avatars/google_avatar.png';
            if (typeof window.notifyUserMentioned === 'function') {
                window.notifyUserMentioned(speakerName, text, speakerAvatar);
            }
        }

        if (!this.activeSpeechBubbles) this.activeSpeechBubbles = new Map();
        const prev = this.activeSpeechBubbles.get(pIndex);
        if (prev) {
            clearTimeout(prev.timer);
            if (prev.el && prev.el.parentNode) prev.el.parentNode.removeChild(prev.el);
            this.activeSpeechBubbles.delete(pIndex);
        }

        const bubble = document.createElement('div');
        bubble.className = 'pawn-speech-bubble';
        bubble.style.cssText = 'position:fixed;z-index:2100;pointer-events:none;background:rgba(15,23,42,0.92);color:#ffffff;border:1.5px solid #00e5ff;border-radius:16px;padding:6px 14px;font-size:15px;font-weight:700;box-shadow:0 6px 20px rgba(0,229,255,0.3);transform:translate(-50%,-100%);transition:opacity 0.3s ease;white-space:nowrap;';
        bubble.textContent = text;
        document.body.appendChild(bubble);

        const timer = setTimeout(() => {
            bubble.style.opacity = '0';
            setTimeout(() => {
                if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
            }, 300);
            this.activeSpeechBubbles.delete(pIndex);
        }, durationMs);

        this.activeSpeechBubbles.set(pIndex, { player, el: bubble, timer });
        this.updateSpeechBubblesPosition();
    }

    updateSpeechBubblesPosition() {
        if (!this.activeSpeechBubbles || this.activeSpeechBubbles.size === 0) return;
        if (!this.camera || !this.renderer || !this.renderer.domElement) return;

        const canvasRect = this.renderer.domElement.getBoundingClientRect();
        const worldPos = new THREE.Vector3();

        for (const [, item] of this.activeSpeechBubbles.entries()) {
            if (!item.player || !item.player.mesh || !item.el) continue;
            worldPos.set(
                item.player.mesh.position.x,
                item.player.mesh.position.y + 3.8,
                item.player.mesh.position.z
            );
            worldPos.project(this.camera);
            if (worldPos.z > 1) {
                item.el.style.display = 'none';
                continue;
            }
            item.el.style.display = 'block';
            const sx = canvasRect.left + (worldPos.x * 0.5 + 0.5) * canvasRect.width;
            const sy = canvasRect.top + (-worldPos.y * 0.5 + 0.5) * canvasRect.height;
            item.el.style.left = `${sx}px`;
            item.el.style.top = `${sy}px`;
        }
    }

    /**
     * วางหมากไว้โซนด้านหน้าของช่องเสมอ (+z ฝั่งเข้าหากล้อง) เพื่อไม่ให้โดนเมือง/แลนด์มาร์คด้านหลังบัง
     */
    setPawnPosition(player, tileNum, pIndex) {
        const idx = pIndex !== undefined ? pIndex : this.players.indexOf(player);
        const target = Math.min(Math.max(tileNum || 1, 1), 100);
        const prevTile = player.currentTile;
        player.currentTile = target;

        const offset = this.getPawnFrontOffset(player, target, idx >= 0 ? idx : 0);
        const tilePos = this.tiles[target] || this.tiles[1];

        if (player.mesh && tilePos) {
            player.mesh.position.copy(tilePos);
            player.mesh.position.x += offset.x;
            player.mesh.position.z += offset.z;
            player.mesh.position.y = (tilePos.y || 0) + ((target === 1 || target === 100) ? 1.18 : 0.52);
        }

        if (prevTile && prevTile !== target) {
            this.realignPawnsOnTile(prevTile);
        }
        this.realignPawnsOnTile(target);
    }

    async checkAndTriggerBoardLinks(player) {
        if (!player) return;
        let movedByLink = false;
        if (this.ladders[player.currentTile]) {
            const ladderEnd = this.ladders[player.currentTile];
            if (window.soundEngine && typeof window.soundEngine.playLadder === 'function') {
                window.soundEngine.playLadder();
            }
            this.logMessage(`🪜 ${player.username} เจอช่องบันได! ไต่ขึ้นจาก ${this.getDisplayTileNumber(player.currentTile)} ไป ${this.getDisplayTileNumber(ladderEnd)} (${this.getProvinceName(ladderEnd)})!`, 'highlight');
            await this.animatePawnToTile(player, ladderEnd, 900);
            player.currentTile = ladderEnd;
            this.showLandingPin(ladderEnd);
            movedByLink = true;
        } else if (this.snakes[player.currentTile]) {
            const snakeEnd = this.snakes[player.currentTile];
            if (window.soundEngine && typeof window.soundEngine.playSnake === 'function') {
                window.soundEngine.playSnake();
            }
            this.logMessage(`🐍 ${player.username} ตกช่องงู! สไลด์ลงจาก ${this.getDisplayTileNumber(player.currentTile)} ไป ${this.getDisplayTileNumber(snakeEnd)} (${this.getProvinceName(snakeEnd)})...`, 'highlight');
            await this.animatePawnToTile(player, snakeEnd, 900);
            player.currentTile = snakeEnd;
            this.showLandingPin(snakeEnd);
            movedByLink = true;
        }

        if (movedByLink) {
            const dest = player.currentTile;
            if (this.isMonopolyBoardMode && dest === 1) {
                await this.handleMonopolyStartTileUpgrade(player);
            } else if (dest === this.jailTile) {
                player.jailTurns = 2;
                this.showSkillBanner(`🏝️ ${player.username} ตกช่องเกาะร้าง! ติดเกาะ 2 ตา!`);
            } else if (this.isMonopolyBoardMode && ((Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(dest)) || (Array.isArray(this.worldTravelTiles) && this.worldTravelTiles.includes(dest)) || dest === this.worldTravelTile)) {
                const isExp = Array.isArray(this.expresswayTiles) && this.expresswayTiles.includes(dest);
                await this.handleMonopolyWorldTravelTile(player, dest, isExp);
            } else if (this.isMonopolyBoardMode && Array.isArray(this.godTiles) && this.godTiles.includes(dest)) {
                await this.handleMonopolyGodTile(player, dest);
            } else if (this.isMonopolyBoardMode && ((Array.isArray(this.olympicTiles) && this.olympicTiles.includes(dest)) || dest === this.olympicTile)) {
                await this.handleMonopolyOlympicTile(player, dest);
            } else if (this.gambleTiles && this.gambleTiles.includes(dest)) {
                await this.handleGambleTile(player);
            } else if (this.destroyTiles && this.destroyTiles.includes(dest)) {
                await this.handleDestroySkillTile(player);
            } else if (this.chanceTiles.includes(dest)) {
                await this.handleChanceTile(player);
            } else if (this.taxTiles.includes(dest)) {
                await this.handleTaxTile(player);
            } else if (this.isBuildableTile(dest)) {
                await this.handleCityTileLanding(player, { isPostBounce: true, allowBuyout: false });
            }
        }
    }

    roundMatchGold(val) {
        const n = Math.max(0, Number(val) || 0);
        if (n === 0) return 0;
        if (n < 50000) return Math.max(100, Math.round(n / 100) * 100);
        if (n < 500000) return Math.round(n / 1000) * 1000;
        return Math.round(n / 5000) * 5000;
    }

    /**
     * คำนวณภาษีช่อง TAX ตามจำนวนเมือง & มูลค่าก่อสร้างรวมของผู้เล่น (ยิ่งมีเมืองเยอะ ค่าก่อสร้างเยอะ ยิ่งจ่ายเยอะ!)
     */
    calculateDynamicTax(player) {
        const baseTax = Math.max(0, Number(this.matchConfig?.tax_amount ?? 50000));
        const basePct = Math.max(1, Number(this.matchConfig?.tax_percent ?? 20));

        let totalConstruction = 0;
        let cities = 0;
        let landmarks = 0;
        let ownedProvinces = 0;

        if (player && this.cityStates) {
            for (const st of Object.values(this.cityStates)) {
                if (st && String(st.ownerId) === String(player.id)) {
                    ownedProvinces++;
                    totalConstruction += Number(st.investedGold) || 0;
                    if (st.isLandmark) {
                        landmarks++;
                    } else {
                        cities += Math.max(1, Number(st.level) || 1);
                    }
                }
            }
        }

        if (totalConstruction <= 0) {
            return {
                totalTax: baseTax,
                baseTax,
                constructionTax: 0,
                effectivePct: 0,
                basePct,
                totalConstruction: 0,
                cities: 0,
                landmarks: 0,
                ownedProvinces: 0
            };
        }

        // อัตราภาษีก้าวหน้า: อัตราภาษีพื้นฐาน + 2% ต่อเมืองที่สร้าง + 5% ต่อแลนด์มาร์ค
        const progressiveBonusPct = (cities * 2) + (landmarks * 5);
        const effectivePct = basePct + progressiveBonusPct;
        const constructionTax = this.roundMatchGold((totalConstruction * effectivePct) / 100);
        const totalTax = baseTax + constructionTax;

        return {
            totalTax,
            baseTax,
            constructionTax,
            effectivePct,
            basePct,
            totalConstruction,
            cities,
            landmarks,
            ownedProvinces
        };
    }

    async handleTaxTile(player) {
        const taxInfo = this.calculateDynamicTax(player);
        const tax = taxInfo.totalTax;
        const currGold = Number(player.matchGold) || 0;

        if (tax <= 0) {
            this.showSkillBanner(`💸 ช่องภาษี! ${player.username} ยังไม่มีเมืองในครอบครอง ไม่เสียภาษี!`);
            this.logMessage(`💸 ${player.username} ตกช่องภาษี (ยังไม่มีเมืองและฐานภาษีเป็น 0 ไม่เสียภาษี)`, 'highlight');
            return;
        }

        const propSummary = taxInfo.totalConstruction > 0
            ? `${taxInfo.cities}🏠 ${taxInfo.landmarks}🏛️ ค่าก่อสร้างรวม ${this.formatCompactGold(taxInfo.totalConstruction)} • ภาษี ${taxInfo.effectivePct}%`
            : 'ยังไม่มีเมือง • เก็บเฉพาะภาษีขั้นต่ำ';

        // แสดง popup ข้อความจ่ายภาษี หากนานเกิน 20 วินาทีเปลี่ยนเป็นเล่น AUTO และชำระภาษีอัตโนมัติ
        if (!player.is_bot && !this.isAutoMode) {
            await this.openCityActionPrompt({
                icon: '💸',
                title: 'ตกช่องสรรพากร! จ่ายภาษีทรัพย์สิน',
                subtitle: `คำนวณภาษีตามเมืองและแลนด์มาร์คในครอบครอง (${propSummary})`,
                walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${currGold.toLocaleString()}</strong> 💰 | ยอดภาษี: <strong style="color:#ff4d4d;">${tax.toLocaleString()}</strong> 💰</span>`,
                defaultChoice: currGold >= tax ? 'PAY_TAX' : 'BANKRUPT',
                timeoutSec: 20,
                options: [
                    {
                        icon: currGold >= tax ? '💸' : '⚠️',
                        label: currGold >= tax ? `จ่ายภาษีทันที (-${this.formatCompactGold(tax)})` : `ทองไม่พอจ่าย (ล้มละลาย)`,
                        costLabel: `${this.formatCompactGold(tax)} 💰`,
                        subLabel: currGold >= tax ? `ทองคงเหลือ ${(currGold - tax).toLocaleString()} 💰` : `ขาดอีก ${(tax - currGold).toLocaleString()} 💰`,
                        value: currGold >= tax ? 'PAY_TAX' : 'BANKRUPT',
                        className: currGold >= tax ? 'landmark-btn recommended' : 'bankrupt-btn'
                    }
                ]
            });
        }

        if (currGold < tax) {
            this.showSkillBanner(`💥 ${player.username} ทองไม่พอจ่ายภาษีทรัพย์สิน ${this.formatCompactGold(tax)} (${propSummary}) — ล้มละลาย!`);
            this.logMessage(`💸 ${player.username} ตกช่องภาษี (${propSummary}) ต้องจ่าย ${tax.toLocaleString()} ทอง แต่มีเพียง ${currGold.toLocaleString()} ทอง!`, 'highlight');
            player.matchGold = 0;
            this.updateMatchWealthHUD();
            this.handleBankruptcy(player, null, 'ไม่สามารถจ่ายค่าภาษีทรัพย์สินได้');
            return;
        }

        player.matchGold = currGold - tax;
        this.updateMatchWealthHUD();
        this.updateActiveTurnUI();

        if (taxInfo.totalConstruction > 0) {
            this.showSkillBanner(`💸 กรมสรรพากร! ${player.username} (${propSummary}) จ่ายภาษี -${this.formatCompactGold(tax)}!`);
            this.logMessage(
                `💸 [ภาษีตามเมือง] ${player.username} มี ${taxInfo.cities} เมือง ${taxInfo.landmarks} แลนด์มาร์ค (ค่าก่อสร้างรวม ${taxInfo.totalConstruction.toLocaleString()} ทอง • อัตรา ${taxInfo.effectivePct}%) จ่ายภาษี ${tax.toLocaleString()} ทอง (คงเหลือ ${player.matchGold.toLocaleString()} ทอง)`,
                'highlight'
            );
        } else {
            this.showSkillBanner(`💸 ช่องภาษี! ${player.username} (ยังไม่มีเมือง) จ่ายภาษีขั้นต่ำ -${this.formatCompactGold(tax)}`);
            this.logMessage(
                `💸 ${player.username} ตกช่องภาษี (ยังไม่มีเมือง) จ่ายภาษีขั้นต่ำ ${tax.toLocaleString()} ทอง (คงเหลือ ${player.matchGold.toLocaleString()} ทอง)`,
                'highlight'
            );
        }
    }

    // =========================================================================
    // 🏙️ 3D CITIES (1-3 เมือง), LANDMARKS, TOLL, BUYOUT, X2-X8 SKILL MULTIPLIER & BANKRUPTCY
    // =========================================================================

    formatCompactGold(val) {
        const n = Math.max(0, Math.round(Number(val) || 0));
        if (n >= 1000000) {
            const m = n / 1000000;
            return (m % 1 === 0 ? m.toFixed(0) : m.toFixed(2).replace(/\.?0+$/, '')) + 'M';
        }
        return n.toLocaleString();
    }

    isBuildableTile(tileNum) {
        const t = Number(tileNum);
        const maxT = this.isMonopolyBoardMode ? 32 : 99;
        if (t <= 1 || t > maxT) return false;
        if (t === this.jailTile) return false;
        if (this.chanceTiles.includes(t)) return false;
        if (this.taxTiles.includes(t)) return false;
        if (this.gambleTiles.includes(t)) return false;
        if (this.destroyTiles && this.destroyTiles.includes(t)) return false;
        if (this.isMonopolyBoardMode) {
            if (t === this.olympicTile || (Array.isArray(this.olympicTiles) && this.olympicTiles.includes(t))) return false;
            if (t === this.worldTravelTile || (Array.isArray(this.worldTravelTiles) && this.worldTravelTiles.includes(t))) return false;
            const mt = Array.isArray(this.monopolyTilesList) ? this.monopolyTilesList[t - 1] : null;
            if (mt && String(mt.type || 'CITY').toUpperCase() !== 'CITY') return false;
        }
        return true;
    }

    clearBoardTileSelectionVisuals() {
        this.isWaitingForBoardPick = false;
        this._onBoardTilePickCallback = null;
        this._boardPickClickableSet = null;
        if (this._boardPickHudEl) {
            if (this._boardPickHudEl.parentNode) this._boardPickHudEl.parentNode.removeChild(this._boardPickHudEl);
            this._boardPickHudEl = null;
        }
        if (this._boardPickTimerInterval) {
            clearInterval(this._boardPickTimerInterval);
            this._boardPickTimerInterval = null;
        }
        if (this._boardPickGroup) {
            if (this.effectsGroup) this.effectsGroup.remove(this._boardPickGroup);
            this.disposeHierarchy(this._boardPickGroup);
            this._boardPickGroup = null;
        }
        if (Array.isArray(this._savedTilePickStates)) {
            this._savedTilePickStates.forEach(item => {
                if (item.mesh) {
                    item.mesh.position.y = item.origY;
                }
                if (Array.isArray(item.matStates)) {
                    item.matStates.forEach(ms => {
                        if (ms.mat) {
                            ms.mat.transparent = ms.transparent;
                            ms.mat.opacity = ms.opacity;
                            if (ms.mat.emissiveIntensity !== undefined) ms.mat.emissiveIntensity = ms.emissiveIntensity;
                            ms.mat.needsUpdate = true;
                        }
                    });
                }
                if (Array.isArray(item.cityMatStates)) {
                    item.cityMatStates.forEach(cms => {
                        if (cms.mat) {
                            cms.mat.transparent = cms.transparent;
                            cms.mat.opacity = cms.opacity;
                            cms.mat.needsUpdate = true;
                        }
                    });
                }
            });
            this._savedTilePickStates = null;
        }
    }

    async pickTileDirectlyOnBoard3D({ title, subText, getTileMode, defaultTile, timeoutSec = 15, extraTopHtml = '', onTopMounted = null }) {
        this.clearBoardTileSelectionVisuals();
        this.isWaitingForBoardPick = true;
        this.hideMonopolyCenterRollStation(true);
        this.hideMonopolyTilePathMarkers();
        const rollBtnLock = document.getElementById('btn-roll-dice');
        if (rollBtnLock) {
            rollBtnLock.disabled = true;
            rollBtnLock.style.opacity = '0.5';
            rollBtnLock.innerHTML = '<span>⏳</span> เลือกช่อง...';
        }

        const maxT = this.isMonopolyBoardMode ? 32 : 100;
        const savedStates = [];
        const pickGroup = new THREE.Group();
        pickGroup.name = 'boardDirectPickGroup';
        const clickableSet = new Set();
        this._boardPickClickableSet = clickableSet;

        for (let i = 1; i <= maxT; i++) {
            const mesh = this.tileMeshes ? this.tileMeshes[i] : null;
            const pos = this.tiles ? this.tiles[i] : null;
            if (!mesh || !pos) continue;

            const mode = getTileMode(i); // 'HIGHLIGHT' | 'DIM_CLICKABLE' | 'DISABLED'
            const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            const matStates = mats.map(m => ({
                mat: m,
                transparent: m ? m.transparent : false,
                opacity: m ? m.opacity : 1,
                emissiveIntensity: m ? m.emissiveIntensity : 0.2
            }));

            const cityMatStates = [];
            if (this.cityMeshes && this.cityMeshes[i]) {
                this.cityMeshes[i].traverse(ch => {
                    if (ch.isMesh && ch.material) {
                        const cMats = Array.isArray(ch.material) ? ch.material : [ch.material];
                        cMats.forEach(cm => {
                            if (cm) cityMatStates.push({ mat: cm, transparent: cm.transparent, opacity: cm.opacity });
                        });
                    }
                });
            }

            savedStates.push({ tileNum: i, mesh, origY: mesh.position.y, matStates, cityMatStates });

            if (mode === 'HIGHLIGHT') {
                clickableSet.add(i);
                // ยกช่องขึ้นเด่นๆ + เรืองแสงสว่างชัด
                mesh.position.y = mesh.position.y + 0.45;
                mats.forEach(m => {
                    if (!m) return;
                    m.transparent = false;
                    m.opacity = 1.0;
                    if (m.emissiveIntensity !== undefined) m.emissiveIntensity = Math.max(0.65, m.emissiveIntensity || 0.65);
                    m.needsUpdate = true;
                });

                const monoCol = this.monopolyTilesList?.[i - 1]?.color;
                const ringHex = monoCol ? (parseInt(String(monoCol).replace('#', ''), 16) || 0x00e5ff) : 0x00e5ff;

                // วงแหวนและแผ่นแสงไฮไลท์เด่นบนช่องที่เรา/เมืองว่าง/ดวง เลือกได้
                const markerGrp = new THREE.Group();
                markerGrp.position.set(pos.x, (pos.y || 0) + 0.92, pos.z);
                markerGrp.userData = { tileNum: i };

                const ringMesh = new THREE.Mesh(
                    new THREE.RingGeometry(2.15, 2.95, 32),
                    new THREE.MeshBasicMaterial({ color: ringHex, side: THREE.DoubleSide, transparent: true, opacity: 0.96, blending: THREE.AdditiveBlending })
                );
                ringMesh.rotation.x = -Math.PI / 2;
                ringMesh.userData = { tileNum: i };
                markerGrp.add(ringMesh);

                const hitDisc = new THREE.Mesh(
                    new THREE.CircleGeometry(3.1, 24),
                    new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending })
                );
                hitDisc.rotation.x = -Math.PI / 2;
                hitDisc.userData = { tileNum: i };
                markerGrp.add(hitDisc);

                const arrowCone = new THREE.Mesh(
                    new THREE.ConeGeometry(0.55, 1.25, 12),
                    new THREE.MeshBasicMaterial({ color: 0xfde047 })
                );
                arrowCone.rotation.x = Math.PI;
                arrowCone.position.y = 1.85;
                arrowCone.userData = { tileNum: i };
                markerGrp.add(arrowCone);

                pickGroup.add(markerGrp);
            } else if (mode === 'DIM_CLICKABLE') {
                clickableSet.add(i);
                // เมืองของคู่แข่ง: แสดงแบบจางๆ แต่สามารถจิ้มที่กระดานเพื่อเดินไปหาและซื้อเมืองต่อได้!
                mats.forEach(m => {
                    if (!m) return;
                    m.transparent = true;
                    m.opacity = 0.28;
                    if (m.emissiveIntensity !== undefined) m.emissiveIntensity = 0.04;
                    m.needsUpdate = true;
                });
                cityMatStates.forEach(cms => {
                    if (cms.mat) {
                        cms.mat.transparent = true;
                        cms.mat.opacity = 0.32;
                        cms.mat.needsUpdate = true;
                    }
                });

                const dimHitDisc = new THREE.Mesh(
                    new THREE.CircleGeometry(3.1, 20),
                    new THREE.MeshBasicMaterial({ color: 0x94a3b8, side: THREE.DoubleSide, transparent: true, opacity: 0.08 })
                );
                dimHitDisc.rotation.x = -Math.PI / 2;
                dimHitDisc.position.set(pos.x, (pos.y || 0) + 0.50, pos.z);
                dimHitDisc.userData = { tileNum: i };
                pickGroup.add(dimHitDisc);
            } else {
                // DISABLED: จางลงและไม่รับคลิก
                mats.forEach(m => {
                    if (!m) return;
                    m.transparent = true;
                    m.opacity = 0.22;
                    if (m.emissiveIntensity !== undefined) m.emissiveIntensity = 0.02;
                    m.needsUpdate = true;
                });
                cityMatStates.forEach(cms => {
                    if (cms.mat) {
                        cms.mat.transparent = true;
                        cms.mat.opacity = 0.25;
                        cms.mat.needsUpdate = true;
                    }
                });
            }
        }

        this._savedTilePickStates = savedStates;
        if (this.effectsGroup) {
            this.effectsGroup.add(pickGroup);
        }
        this._boardPickGroup = pickGroup;

        return await new Promise((resolve) => {
            let remSec = timeoutSec;
            const bar = document.createElement('div');
            bar.id = 'board-direct-pick-bar';
            bar.style.cssText = 'position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); z-index:2147483500; background:linear-gradient(165deg,rgba(20,28,48,0.94),rgba(8,12,22,0.96)); border:none; border-radius:16px; padding:10px 18px; box-shadow:0 14px 40px rgba(0,0,0,0.85), 0 0 20px rgba(0,229,255,0.22), inset 0 1px 0 rgba(255,255,255,0.2); color:#fff; font-family:"Kanit",sans-serif; text-align:center; pointer-events:none; max-width:min(76vw, 440px);';
            bar.innerHTML = `
                        <div style="display:flex; align-items:center; justify-content:center; gap:8px; flex-wrap:wrap;">
                            <span style="font-size:14.5px; font-weight:900; color:#38bdf8;">${title}</span>
                            <span id="board-pick-timer-badge" style="background:#e11d48; color:#fff; font-size:11.5px; font-weight:900; padding:2px 8px; border-radius:999px;">⏳ ${remSec}s</span>
                        </div>
                        <div style="font-size:11.5px; color:#fde047; font-weight:700; margin-top:2px;">${subText}</div>
                        ${extraTopHtml}
                    `;
            document.body.appendChild(bar);
            this._boardPickHudEl = bar;
            if (typeof onTopMounted === 'function') onTopMounted(bar);

            let finished = false;
            const finishPick = (chosenTile) => {
                if (finished) return;
                finished = true;
                this.clearBoardTileSelectionVisuals();
                resolve(chosenTile);
            };

            this._onBoardTilePickCallback = (clickedTile) => {
                if (clickableSet.has(Number(clickedTile))) {
                    finishPick(Number(clickedTile));
                }
            };

            this._boardPickTimerInterval = setInterval(() => {
                remSec--;
                const tb = document.getElementById('board-pick-timer-badge');
                if (tb) tb.innerText = `⏳ ${Math.max(0, remSec)}s`;
                if (remSec <= 0) {
                    finishPick(defaultTile);
                }
            }, 1000);
        });
    }

    async handleMonopolyOlympicTile(player, tileNum) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt || this.isGameOver) return;
        const ownedKeys = Object.keys(this.cityStates || {}).filter(k => {
            return this.isTileOwnedByPlayerOrTeam(Number(k), player);
        });

        // สุ่มตัวคูณว่าจะให้คูณเท่าไหร่จาก [2, 4, 6, 8] (สุ่มอัตโนมัติ ไม่ใช่ให้เลือก)
        const multPool = [2, 4, 6, 8];
        const selectedMult = multPool[Math.floor(Math.random() * multPool.length)];

        if (ownedKeys.length === 0) {
            const bonusGold = 100000;
            player.matchGold = (Number(player.matchGold) || 0) + bonusGold;
            this.updateMatchWealthHUD();
            this.showSkillBanner(`🏅🎰 ${player.username} ตกพื้นที่คูณ 2,4,6,8! สุ่มได้ X${selectedMult} (ยังไม่มีเมือง • รับโบนัส +100,000 ทอง)`);
            this.logMessage(`🏅🎰 ${player.username} ตกพื้นที่คูณ สุ่มได้ X${selectedMult} แต่ยังไม่มีเมือง จึงได้รับเงินสนับสนุน +100,000 ทอง`, 'skill');
            return;
        }

        const applyMultOnCity = (targetTileNum) => {
            const st = this.cityStates[targetTileNum];
            if (!st) return;
            const curM = Number(st.multiplier) || 1;
            const nextM = Math.max(curM, Math.min(8, selectedMult));
            st.multiplier = nextM;
            this.rebuildTileCity3D(targetTileNum);
            const pName = this.getProvinceName(targetTileNum);
            const dispT = this.getDisplayTileNumber(targetTileNum);
            const newToll = this.getTileToll(targetTileNum);
            this.showSkillBanner(`🏅🎰 [พื้นที่คูณ 2,4,6,8!] สุ่มได้ตัวคูณ X${selectedMult}! เพิ่มที่ [#${dispT} ${pName}] สำเร็จ! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
            this.logMessage(`🏅🎰 ${player.username} ตกพื้นที่คูณ สุ่มได้รับตัวคูณ X${selectedMult} นำไปเพิ่มที่เมือง [#${dispT} ${pName}] ค่าผ่านทางพุ่งเป็น ${newToll.toLocaleString()} ทอง!`, 'highlight');
            this.updateMatchWealthHUD();
        };

        ownedKeys.sort((a, b) => this.getTileToll(Number(b)) - this.getTileToll(Number(a)));
        const defaultTile = Number(ownedKeys[0]);

        if (player.is_bot || !this.isLocalPlayer(player) || this.isAutoMode) {
            applyMultOnCity(defaultTile);
            return;
        }

        this.showSkillBanner(`🏅🎰 ${player.username} ตกพื้นที่คูณ! สุ่มวงล้อได้ตัวคูณ "X${selectedMult}"!`);

        const ownedSet = new Set(ownedKeys.map(Number));
        const chosenTile = await this.pickTileDirectlyOnBoard3D({
            title: `🏅🎰 สุ่มได้ตัวคูณ "X${selectedMult}"! แตะเลือกเมืองของคุณบนกระดาน`,
            subText: `✨ ระบบสุ่มตัวคูณได้ "X${selectedMult}" เรียบร้อย! จิ้มที่เมืองของคุณ/ทีมที่สว่างเด่นบนกระดานเพื่อรับตัวคูณทันที`,
            getTileMode: (t) => ownedSet.has(t) ? 'HIGHLIGHT' : 'DISABLED',
            defaultTile: defaultTile,
            timeoutSec: 15
        });

        if (chosenTile) {
            applyMultOnCity(chosenTile);
        }
    }

    async handleMonopolyGodTile(player, tileNum) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt || this.isGameOver) return;

        const eligibleTiles = [];
        const eligibleSet = new Set();
        for (let t = 2; t <= 32; t++) {
            if (!this.isBuildableTile(t)) continue;
            const st = this.cityStates[t];
            if (!st) {
                eligibleTiles.push({ tileNum: t, mode: 'EMPTY_TO_LM' });
                eligibleSet.add(t);
            } else if (this.isTileOwnedByPlayerOrTeam(t, player) && !st.isSuperLandmark) {
                eligibleTiles.push({ tileNum: t, mode: st.isLandmark ? 'LM_TO_SLM' : 'CITY_TO_LM' });
                eligibleSet.add(t);
            }
        }

        if (eligibleTiles.length === 0) {
            const bonus = 250000;
            player.matchGold = (Number(player.matchGold) || 0) + bonus;
            this.updateMatchWealthHUD();
            this.showSkillBanner(`👼 ${player.username} ตกพื้นที่พระเจ้า! รับพรทองคำ +250,000 ทอง!`);
            return;
        }

        const applyGodBlessing = async (chosenTile) => {
            const item = eligibleTiles.find(x => x.tileNum === Number(chosenTile)) || eligibleTiles[0];
            if (!item) return;
            const t = item.tileNum;
            const prov = this.getProvinceName(t);
            const dispT = this.getDisplayTileNumber(t);
            const basePrice = Number(this.monopolyTilesList?.[t - 1]?.price) || 350000;

            if (item.mode === 'LM_TO_SLM') {
                const st = this.cityStates[t];
                st.level = 5;
                st.isLandmark = true;
                st.isSuperLandmark = true;
                st.multiplier = Math.max(4, Number(st.multiplier) || 4);
                st.investedGold = (Number(st.investedGold) || basePrice) + 450000;
                this.rebuildTileCity3D(t);
                this.checkAndRefreshColorGroupBonus3D(t, player);
                this.updateMatchWealthHUD();
                const newToll = this.getTileToll(t);
                this.showSkillBanner(`👼👑 [พื้นที่พระเจ้า!] ${player.username} อัปเกรด [#${dispT} ${prov}] เป็น "ซุปเปอร์แลนด์มาร์ค" ทันที! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
                this.logMessage(`👼👑 [พรพระเจ้า] ${player.username} ยกระดับแลนด์มาร์ค [#${dispT} ${prov}] เป็นซุปเปอร์แลนด์มาร์คขั้นสูงสุดฟรีทันที!`, 'highlight');
            } else {
                const prevSt = this.cityStates[t];
                this.cityStates[t] = {
                    ownerId: prevSt?.ownerId || player.id,
                    ownerIndex: prevSt?.ownerIndex ?? this.players.indexOf(player),
                    color: prevSt?.color || player.color,
                    level: 4,
                    houses: 3,
                    isLandmark: true,
                    isSuperLandmark: false,
                    multiplier: Math.max(2, Number(prevSt?.multiplier) || 2),
                    investedGold: (Number(prevSt?.investedGold) || 0) + basePrice + 320000
                };
                this.rebuildTileCity3D(t);
                this.checkAndRefreshColorGroupBonus3D(t, player);
                this.updateMatchWealthHUD();
                const newToll = this.getTileToll(t);
                this.showSkillBanner(`👼🏛️ [พื้นที่พระเจ้า!] ${player.username} เสก "แลนด์มาร์ค" ที่ [#${dispT} ${prov}] ทันที! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
                this.logMessage(`👼🏛️ [พรพระเจ้า] ${player.username} สร้างแลนด์มาร์คที่ [#${dispT} ${prov}] ทันทีโดยไม่ต้องเสียทอง!`, 'highlight');
            }

            if (this.checkLineMonopolyVictory(player)) return;
            await this.triggerLandmarkSkills(player, t);
        };

        const slmCand = eligibleTiles.find(x => x.mode === 'LM_TO_SLM');
        const defaultPick = (slmCand || eligibleTiles[0]).tileNum;

        if (player.is_bot || !this.isLocalPlayer(player) || this.isAutoMode) {
            await applyGodBlessing(defaultPick);
            return;
        }

        const chosen = await this.pickTileDirectlyOnBoard3D({
            title: '👼 พื้นที่พระเจ้า! จิ้มเลือกช่องบนกระดานเพื่อสร้างแลนด์มาร์คทันที',
            subText: 'จิ้มที่พื้นที่ว่าง หรือเมืองของเรา/ทีมที่สว่างเด่นอยู่บนกระดาน (หากเป็นแลนด์มาร์คจะขึ้นซุปเปอร์แลนด์มาร์คทันที!)',
            getTileMode: (t) => eligibleSet.has(t) ? 'HIGHLIGHT' : 'DISABLED',
            defaultTile: defaultPick,
            timeoutSec: 15
        });

        if (chosen) {
            await applyGodBlessing(chosen);
        }
    }

    async handleMonopolyWorldTravelTile(player, tileNum, isExpressway = false) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt || this.isGameOver) return;

        const pickSmartDestinationForBot = () => {
            const colorGroups = {};
            (this.monopolyTilesList || []).forEach((t, idx) => {
                const tIdx = Number(t.index || (idx + 1));
                if (t && t.type === 'CITY' && t.color) {
                    const c = String(t.color).toLowerCase();
                    if (!colorGroups[c]) colorGroups[c] = [];
                    colorGroups[c].push(tIdx);
                }
            });
            for (const indices of Object.values(colorGroups)) {
                const owned = indices.filter(i => this.isTileOwnedByPlayerOrTeam(i, player));
                if (owned.length === indices.length - 1) {
                    const miss = indices.find(i => !owned.includes(i) && (!this.cityStates[i] || !this.cityStates[i].isLandmark));
                    if (miss) return miss;
                }
            }
            const emptyCities = [];
            for (let i = 2; i <= 32; i++) {
                if (this.isBuildableTile(i) && !this.cityStates[i]) emptyCities.push(i);
            }
            if (emptyCities.length > 0) return emptyCities[Math.floor(Math.random() * emptyCities.length)];
            return 1;
        };

        let targetDest = null;
        if (player.is_bot || !this.isLocalPlayer(player) || this.isAutoMode) {
            targetDest = pickSmartDestinationForBot();
        } else {
            // จิ้มเลือกช่องบนกระดาน 3D ได้โดยตรง (ไม่แสดง Popup บังกระดาน!):
            // - พื้นที่เรา/ทีม, พื้นที่ว่างๆ, หรือพื้นที่ดวง/โบนัส/พิเศษ แสดงสว่างเด่นๆ ('HIGHLIGHT')
            // - พื้นที่ของคู่แข่ง แสดงแบบจางๆ ('DIM_CLICKABLE') แต่สามารถจิ้มเดินไปหาเพื่อซื้อเมืองต่อได้!
            targetDest = await this.pickTileDirectlyOnBoard3D({
                title: isExpressway ? '🛣️ ทางด่วนพิเศษ! จิ้มเลือกช่องบนกระดานเพื่อเดินไปทันที' : '✈️ พื้นที่พิเศษ! จิ้มเลือกช่องบนกระดานเพื่อเดินไปทันที',
                subText: '✨ ช่องสว่างเด่น = เมืองเรา / เมืองว่าง / ดวง • 🌫️ ช่องจาง = เมืองคู่แข่ง (จิ้มเพื่อเดินไปซื้อเมืองต่อได้)',
                getTileMode: (t) => {
                    if (t === Number(tileNum)) return 'DISABLED';
                    const st = this.cityStates ? this.cityStates[t] : null;
                    if (st) {
                        return this.isTileOwnedByPlayerOrTeam(t, player) ? 'HIGHLIGHT' : 'DIM_CLICKABLE';
                    }
                    if (t === this.jailTile || (this.taxTiles && this.taxTiles.includes(t))) {
                        return 'DIM_CLICKABLE';
                    }
                    return 'HIGHLIGHT';
                },
                defaultTile: pickSmartDestinationForBot(),
                timeoutSec: 15
            });
        }

        if (!targetDest || targetDest < 1 || targetDest > 32) return;
        const destName = this.getProvinceName(targetDest);
        const dispDest = this.getDisplayTileNumber(targetDest);
        this.showSkillBanner(`✈️ [พื้นที่พิเศษ!] ${player.username} เลือกบินลัดฟ้าไปลง [${dispDest === 'START' ? 'START' : '#' + dispDest} ${destName}]!`);
        this.logMessage(`✈️ ${player.username} ใช้พื้นที่พิเศษ วาร์ปไปลงช่อง ${dispDest} (${destName})!`, 'highlight');

        await this.animatePawnToTile(player, targetDest, 800);
        player.currentTile = targetDest;
        this.showLandingPin(targetDest);

        if (targetDest === 1) {
            await this.handleMonopolyStartTileUpgrade(player);
        } else if (Array.isArray(this.godTiles) && this.godTiles.includes(targetDest)) {
            await this.handleMonopolyGodTile(player, targetDest);
        } else if ((Array.isArray(this.olympicTiles) && this.olympicTiles.includes(targetDest)) || targetDest === this.olympicTile) {
            await this.handleMonopolyOlympicTile(player, targetDest);
        } else if (this.gambleTiles && this.gambleTiles.includes(targetDest)) {
            await this.handleGambleTile(player);
        } else if (this.destroyTiles && this.destroyTiles.includes(targetDest)) {
            await this.handleDestroySkillTile(player);
        } else if (this.chanceTiles.includes(targetDest)) {
            await this.handleChanceTile(player);
        } else if (this.taxTiles.includes(targetDest)) {
            await this.handleTaxTile(player);
        } else if (targetDest === this.jailTile) {
            player.jailTurns = 2;
            this.showSkillBanner(`🏝️ ${player.username} ไปติดเกาะร้าง 2 ตา!`);
        } else if (this.isBuildableTile(targetDest)) {
            await this.handleCityTileLanding(player);
        }
    }

    // -------------------------------------------------------------
    // LINE & COLUMN MONOPOLY VICTORY SYSTEM (วิคเตอรี่ครองแถว แนวนอน x2 / แนวตั้ง x3)
    // -------------------------------------------------------------
    getTilesInRow(r) {
        const tiles = [];
        const start = r * 10 + 1;
        for (let i = 0; i < 10; i++) {
            tiles.push(start + i);
        }
        return tiles;
    }

    getTilesInCol(c) {
        const tiles = [];
        for (let r = 0; r < 10; r++) {
            const colInRow = (r % 2 === 0) ? c : (9 - c);
            tiles.push(r * 10 + colInRow + 1);
        }
        return tiles;
    }

    isTileOwnedByPlayerOrTeam(tileNum, player) {
        const st = this.cityStates[tileNum];
        if (!st || !st.ownerId) return false;
        if (String(st.ownerId) === String(player.id)) return true;
        if (player.team && player.team !== 'NONE') {
            const owner = this.players.find(p => String(p.id) === String(st.ownerId));
            if (owner && owner.team && owner.team === player.team) {
                return true;
            }
        }
        return false;
    }

    updateMonopolyVictoryWarningAuras() {
        if (!this.isMonopolyBoardMode || !Array.isArray(this.monopolyTilesList) || this.isGameOver || this._tripleColorVictoryTriggered) {
            return;
        }
        const colorGroups = {};
        this.monopolyTilesList.forEach((t, idx) => {
            if (t && t.type === 'CITY' && t.color) {
                const col = String(t.color).trim().toLowerCase();
                const tileIdx = Number(t.index || (idx + 1));
                if (!colorGroups[col]) colorGroups[col] = [];
                colorGroups[col].push(tileIdx);
            }
        });

        const auraTilesSet = new Set();
        let warningCandidate = null;

        (this.players || []).forEach(p => {
            if (!p || p.isBankrupt) return;
            const completedColors = [];
            const partialColors = [];
            for (const [colHex, tileIndices] of Object.entries(colorGroups)) {
                if (tileIndices.length < 2) continue;
                const ownedTiles = tileIndices.filter(t => this.isTileOwnedByPlayerOrTeam(t, p));
                if (ownedTiles.length === tileIndices.length) {
                    completedColors.push({ color: colHex, tiles: tileIndices });
                } else if (ownedTiles.length === tileIndices.length - 1) {
                    const missingTiles = tileIndices.filter(t => !ownedTiles.includes(t));
                    partialColors.push({ color: colHex, tiles: tileIndices, owned: ownedTiles, missing: missingTiles });
                }
            }
            if (completedColors.length >= 2) {
                completedColors.forEach(c => c.tiles.forEach(t => auraTilesSet.add(t)));
                if (partialColors.length >= 1) {
                    partialColors.forEach(pc => pc.tiles.forEach(t => auraTilesSet.add(t)));
                    if (!warningCandidate) {
                        warningCandidate = { player: p, completedColors, candidate: partialColors[0] };
                    }
                } else {
                    // ครองครบ 2 สีแล้ว: แสดงเออร่าที่ 2 สีที่ครองอยู่ให้เห็นว่าใกล้ชนะวิคเตอรี่!
                    if (!warningCandidate) {
                        warningCandidate = { player: p, completedColors, candidate: null };
                    }
                }
            }
        });

        if (auraTilesSet.size > 0) {
            this.showMonopolyColorVictoryAura(Array.from(auraTilesSet));
            if (warningCandidate && warningCandidate.candidate) {
                const p = warningCandidate.player;
                const teamTxt = (p.team && p.team !== 'NONE') ? ` [ทีม ${p.team}]` : '';
                const missingTileNum = warningCandidate.candidate.missing[0];
                const missingProvName = this.getProvinceName(missingTileNum);
                const dispMiss = this.getDisplayTileNumber(missingTileNum);
                const warnKey = `${p.id}_${warningCandidate.candidate.color}_${missingTileNum}`;
                if (this._lastMonopolyVictoryWarnKey !== warnKey) {
                    this._lastMonopolyVictoryWarnKey = warnKey;
                    const alertMsg = `⚠️ เตือนภัยวิคเตอรี่! ${p.username}${teamTxt} ครองครบ 2 สีแล้ว! ขาดอีกแค่ [#${dispMiss} ${missingProvName}] จะครบ 3 สี ชนะ TRIPLE COLOR VICTORY ทันที!`;
                    this.showSkillBanner(alertMsg);
                    this.logMessage(`🚨 ${alertMsg}`, 'highlight');
                }
            }
        } else {
            this.clearMonopolyColorVictoryAura();
            this._lastMonopolyVictoryWarnKey = null;
        }
    }

    checkMonopolyTripleColorVictory(player) {
        if (!this.isMonopolyBoardMode || !player || player.isBankrupt || this.isGameOver || this._tripleColorVictoryTriggered) {
            return false;
        }
        if (!Array.isArray(this.monopolyTilesList) || this.monopolyTilesList.length === 0) {
            return false;
        }

        // 1. จัดกลุ่มเมืองตามสี (8 สี สีละ 2 เมือง รวม 16 เมือง)
        const colorGroups = {};
        this.monopolyTilesList.forEach((t, idx) => {
            if (t && t.type === 'CITY' && t.color) {
                const col = String(t.color).trim().toLowerCase();
                const tileIdx = Number(t.index || (idx + 1));
                if (!colorGroups[col]) colorGroups[col] = [];
                colorGroups[col].push(tileIdx);
            }
        });

        // 2. ตรวจสอบสถานะการครอบครองของ player (หรือทีมในโหมด 2v2)
        const completedColors = [];
        for (const [colHex, tileIndices] of Object.entries(colorGroups)) {
            if (tileIndices.length < 2) continue;
            const ownedTiles = tileIndices.filter(t => this.isTileOwnedByPlayerOrTeam(t, player));
            if (ownedTiles.length === tileIndices.length) {
                completedColors.push({ color: colHex, tiles: tileIndices });
            }
        }

        // 3. เงื่อนไขชนะ Triple Color Victory: ครองครบ 3 สี!
        if (completedColors.length >= 3) {
            this.triggerMonopolyTripleColorVictory(player, completedColors);
            return true;
        }

        // 4. อัปเดตแสงเออร่าแจ้งเตือนใกล้ชนะวิคเตอรี่ของผู้เล่นทุกคนบนกระดาน
        this.updateMonopolyVictoryWarningAuras();

        return false;
    }

    showMonopolyColorVictoryAura(tiles, targetColor = null) {
        if (!this.effectsGroup) return;
        this.clearMonopolyColorVictoryAura();

        const auraGroup = new THREE.Group();
        auraGroup.name = 'monopolyVictoryAuraGroup';

        tiles.forEach((tNum, idx) => {
            const pos = this.tiles[tNum];
            if (!pos) return;

            const tileInfo = (this.monopolyTilesList || [])[tNum - 1];
            let colorHex = 0xffd700;
            if (tileInfo && tileInfo.color) {
                colorHex = parseInt(String(tileInfo.color).replace('#', ''), 16) || 0xffd700;
            }

            const cityAura = new THREE.Group();
            cityAura.position.set(pos.x, (pos.y || 0) + 0.35, pos.z);

            // วงแหวนเออร่าเรืองแสงบนพื้น
            const ringGeo = new THREE.RingGeometry(2.0, 2.75, 32);
            const ringMat = new THREE.MeshBasicMaterial({
                color: colorHex,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.95
            });
            const ringMesh = new THREE.Mesh(ringGeo, ringMat);
            ringMesh.rotation.x = -Math.PI / 2;
            cityAura.add(ringMesh);

            // แผ่นพลังงานเรืองแสง additive
            const discGeo = new THREE.CircleGeometry(2.0, 32);
            const discMat = new THREE.MeshBasicMaterial({
                color: colorHex,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.45,
                blending: THREE.AdditiveBlending
            });
            const discMesh = new THREE.Mesh(discGeo, discMat);
            discMesh.rotation.x = -Math.PI / 2;
            cityAura.add(discMesh);

            // เสาแสงเตือนทะยานขึ้นฟ้า
            const beamGeo = new THREE.CylinderGeometry(1.8, 1.8, 16, 24, 1, true);
            const beamMat = new THREE.MeshBasicMaterial({
                color: colorHex,
                transparent: true,
                opacity: 0.32,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending
            });
            const beamMesh = new THREE.Mesh(beamGeo, beamMat);
            beamMesh.position.y = 8;
            cityAura.add(beamMesh);

            cityAura.userData = {
                ringMesh,
                discMesh,
                beamMesh,
                phase: idx * 0.5
            };

            auraGroup.add(cityAura);
        });

        this.effectsGroup.add(auraGroup);
        this.monopolyVictoryAuraGroup = auraGroup;
    }

    clearMonopolyColorVictoryAura() {
        if (this.monopolyVictoryAuraGroup) {
            try {
                if (this.effectsGroup) this.effectsGroup.remove(this.monopolyVictoryAuraGroup);
                this.disposeHierarchy(this.monopolyVictoryAuraGroup);
            } catch (e) { }
            this.monopolyVictoryAuraGroup = null;
        }
    }

    triggerMonopolyTripleColorVictory(player, completedColors) {
        if (this.isGameOver || this._tripleColorVictoryTriggered) return;
        this._tripleColorVictoryTriggered = true;
        this.isTurnProcessing = true;

        const teamTxt = (player.team && player.team !== 'NONE') ? ` [ทีม ${player.team}]` : '';

        // รวบรวมเมืองทั้งหมดใน 3 สีที่ชนะ (6 เมือง)
        const all6Tiles = [];
        completedColors.slice(0, 3).forEach(c => all6Tiles.push(...c.tiles));

        // 1. แสดงเออร่าชัยชนะที่ 6 เมือง
        this.showMonopolyColorVictoryAura(all6Tiles);
        this.triggerLineMonopolyWavePop(all6Tiles);

        // 2. ประกาศแบนเนอร์และข้อความ
        this.showSkillBanner(`🌈👑 TRIPLE COLOR VICTORY! ${player.username}${teamTxt} ครองเมืองครบ 3 สี (6 เมือง) ชนะเลิศ! (รางวัล X3)`);
        this.logMessage(`🌈👑 ${player.username}${teamTxt} สร้างประวัติศาสตร์ครองเมืองครบเซ็ต 3 สี (6 เมือง) สมบูรณ์แบบ! คว้าชัยชนะแบบ TRIPLE COLOR VICTORY โบนัสรางวัลคูณ 3!`, 'highlight');

        // 3. เสียงเฉลิมฉลองและพลุ
        try {
            if (window.soundEngine) {
                if (typeof window.soundEngine.playWin === 'function') window.soundEngine.playWin();
                setTimeout(() => {
                    if (typeof window.soundEngine.playLevelUp === 'function') window.soundEngine.playLevelUp();
                }, 500);
            }
        } catch (e) { }

        if (window.confetti) {
            window.confetti({ particleCount: 320, spread: 140, origin: { y: 0.5 } });
            setTimeout(() => {
                if (window.confetti) window.confetti({ particleCount: 220, spread: 110, origin: { y: 0.6 } });
            }, 600);
        }

        // 4. หน่วงเวลา 3 วินาทีก่อนสรุปชัยชนะ
        setTimeout(() => {
            this.handleVictory(player, 'TRIPLE_COLOR_VICTORY', { lineMultiplier: 3 });
        }, 3000);
    }

    checkLineMonopolyVictory(player) {
        if (!player || player.isBankrupt || this.isGameOver) return false;

        // ในโหมดกระดานเศรษฐี: ตรวจสอบชัยชนะครองครบ 3 สี (6 เมือง) และแสงเออร่าเตือนภัย
        if (this.isMonopolyBoardMode) {
            if (this.checkMonopolyTripleColorVictory(player)) return true;
        }

        if (this._lineMonopolyTriggered) return false;

        // 1. ตรวจสอบแนวตั้ง (Vertical Columns 0..9) -> ชนะคูณ 3 (ตรวจสอบก่อนเนื่องจากโบนัสสูงสุด x3)
        for (let c = 0; c < 10; c++) {
            const colTiles = this.getTilesInCol(c);
            const buildableInCol = colTiles.filter(t => this.isBuildableTile(t));
            if (buildableInCol.length >= 3 && buildableInCol.every(t => this.isTileOwnedByPlayerOrTeam(t, player))) {
                this.triggerLineMonopolyVictory(player, colTiles, buildableInCol, true); // แนวตั้ง x3
                return true;
            }
        }

        // 2. ตรวจสอบแนวนอน (Horizontal Rows 0..9) -> ชนะคูณ 2
        for (let r = 0; r < 10; r++) {
            const rowTiles = this.getTilesInRow(r);
            const buildableInRow = rowTiles.filter(t => this.isBuildableTile(t));
            if (buildableInRow.length >= 3 && buildableInRow.every(t => this.isTileOwnedByPlayerOrTeam(t, player))) {
                this.triggerLineMonopolyVictory(player, rowTiles, buildableInRow, false); // แนวนอน x2
                return true;
            }
        }

        // 3. ตรวจสอบแจ้งเตือนล่วงหน้าหากขาดอีกแค่ 1 เมืองจะครองแถว
        this.checkLineMonopolyOneAwayWarning(player);

        return false;
    }

    checkLineMonopolyOneAwayWarning(player) {
        if (!player || player.isBankrupt || this.isGameOver || this._oneAwayWarnedThisTurn) return;

        // ตรวจสอบแนวตั้ง
        for (let c = 0; c < 10; c++) {
            const colTiles = this.getTilesInCol(c);
            const buildable = colTiles.filter(t => this.isBuildableTile(t));
            const owned = buildable.filter(t => this.isTileOwnedByPlayerOrTeam(t, player));
            if (buildable.length >= 3 && owned.length === buildable.length - 1) {
                this._oneAwayWarnedThisTurn = true;
                this.showSkillBanner(`⚠️ ระวัง! ${player.username} ขาดอีกแค่ 1 เมืองจะชนะครองแนวตั้ง (รางวัล X3)!`);
                return;
            }
        }

        // ตรวจสอบแนวนอน
        for (let r = 0; r < 10; r++) {
            const rowTiles = this.getTilesInRow(r);
            const buildable = rowTiles.filter(t => this.isBuildableTile(t));
            const owned = buildable.filter(t => this.isTileOwnedByPlayerOrTeam(t, player));
            if (buildable.length >= 3 && owned.length === buildable.length - 1) {
                this._oneAwayWarnedThisTurn = true;
                this.showSkillBanner(`⚠️ ระวัง! ${player.username} ขาดอีกแค่ 1 เมืองจะชนะครองแนวนอน (รางวัล X2)!`);
                return;
            }
        }
    }

    triggerLineMonopolyVictory(player, lineTiles, buildableTiles, isVertical) {
        if (this.isGameOver || this._lineMonopolyTriggered) return;
        this._lineMonopolyTriggered = true;
        this.isTurnProcessing = true;

        const mult = isVertical ? 3 : 2;
        const winReason = isVertical ? 'VERTICAL_LINE_VICTORY' : 'HORIZONTAL_LINE_VICTORY';
        const lineName = isVertical ? 'แนวตั้ง (Triple Column Domination)' : 'แนวนอน (Line Domination)';
        const teamTxt = (player.team && player.team !== 'NONE') ? ` [ทีม ${player.team}]` : '';

        // 1. แจ้งเตือนแบนเนอร์และบันทึกประวัติการแข่งขัน
        this.showSkillBanner(`⚡ วิคเตอรี่! ${player.username}${teamTxt} ครองเมือง${lineName} ครบแถว! (รางวัล X${mult})`);
        this.logMessage(`👑 ${player.username}${teamTxt} สร้างเมืองยึดครอง${lineName} ครบแถวสำเร็จ! คว้าชัยชนะแบบวิคเตอรี่ (คะแนนอันดับ ทอง และเพชร คูณ ${mult})!`, 'highlight');

        // 2. เอฟเฟกต์เสาลำแสงและเออร่าเรืองแสงทั้งแถว
        this.triggerLineMonopolyAura(lineTiles, isVertical);

        // 3. แถวกระดานและตึกเมืองนูนขึ้นลงคลื่นพลัง 3D
        this.triggerLineMonopolyWavePop(lineTiles);

        // 4. เสียงเพลง & พลุเฉลิมฉลอง
        try {
            if (window.soundEngine) {
                if (typeof window.soundEngine.playWin === 'function') window.soundEngine.playWin();
                setTimeout(() => {
                    if (typeof window.soundEngine.playLevelUp === 'function') window.soundEngine.playLevelUp();
                }, 500);
            }
        } catch (e) { }

        if (window.confetti) {
            window.confetti({ particleCount: 260, spread: 130, origin: { y: 0.5 } });
            setTimeout(() => {
                if (window.confetti) window.confetti({ particleCount: 200, spread: 100, origin: { y: 0.6 } });
            }, 600);
        }

        // 5. หน่วงเวลา 2.8 วินาทีให้ผู้เล่นเห็นคลื่นนูนและเออร่าทั้งแถวก่อนเปิดหน้าต่างผลการแข่งขัน
        setTimeout(() => {
            this.handleVictory(player, winReason, { lineMultiplier: mult });
        }, 2800);
    }

    triggerLineMonopolyWavePop(lineTiles) {
        if (!this.tileMeshes) return;
        const now = Date.now();
        lineTiles.forEach((tNum, idx) => {
            const tm = this.tileMeshes[tNum];
            if (tm) {
                if (!tm.userData.origY) tm.userData.origY = tm.position.y;
                tm.userData.wavePop = {
                    startTime: now + idx * 75,
                    duration: 3200,
                    origY: tm.userData.origY
                };
            }
            if (this.cityMeshes && this.cityMeshes[tNum]) {
                const cg = this.cityMeshes[tNum];
                if (!cg.userData.origY) cg.userData.origY = cg.position.y;
                cg.userData.wavePop = {
                    startTime: now + idx * 75,
                    duration: 3200,
                    origY: cg.userData.origY
                };
            }
        });
        this._activeLineWaveTiles = [...lineTiles];
    }

    triggerLineMonopolyAura(lineTiles, isVertical) {
        if (this.lineMonopolyAuraGroup) {
            this.effectsGroup.remove(this.lineMonopolyAuraGroup);
            this.lineMonopolyAuraGroup = null;
        }

        const auraGroup = new THREE.Group();
        auraGroup.name = 'lineMonopolyAuraGroup';
        const auraColor = isVertical ? 0xff2a85 : 0xffd700; // แนวตั้ง x3 ชมพู/นีออน, แนวนอน x2 ทองเรืองรอง
        const beaconColor = isVertical ? 0xa855f7 : 0xfbbf24;

        lineTiles.forEach((tNum, idx) => {
            const pos = this.tiles[tNum];
            if (!pos) return;

            const tileAura = new THREE.Group();
            tileAura.position.set(pos.x, (pos.y || 0) + 0.35, pos.z);

            // 1. วงแหวนเออร่าเรืองแสงพื้น (Ground Aura Ring)
            const ringGeo = new THREE.RingGeometry(1.65, 2.15, 32);
            const ringMat = new THREE.MeshBasicMaterial({
                color: auraColor,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.95
            });
            const ringMesh = new THREE.Mesh(ringGeo, ringMat);
            ringMesh.rotation.x = -Math.PI / 2;
            tileAura.add(ringMesh);

            // 2. แผ่นพลังงานเรืองแสง (Energy Disc)
            const discGeo = new THREE.CircleGeometry(1.6, 28);
            const discMat = new THREE.MeshBasicMaterial({
                color: 0xffffff,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.35,
                blending: THREE.AdditiveBlending
            });
            const discMesh = new THREE.Mesh(discGeo, discMat);
            discMesh.rotation.x = -Math.PI / 2;
            tileAura.add(discMesh);

            // 3. เสาลำแสงทะยานขึ้นฟ้า (Vertical Light Beam)
            const beamGeo = new THREE.CylinderGeometry(1.4, 1.4, 12, 24, 1, true);
            const beamMat = new THREE.MeshBasicMaterial({
                color: beaconColor,
                transparent: true,
                opacity: 0.38,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending
            });
            const beamMesh = new THREE.Mesh(beamGeo, beamMat);
            beamMesh.position.y = 6;
            // tileAura.add(beamMesh); // ปิดแท่งแสงสีฟ้าบนช่องผูกขาด
            tileAura.userData.beam = beamMesh;
            tileAura.userData.phase = idx * 0.4;

            auraGroup.add(tileAura);
        });

        this.effectsGroup.add(auraGroup);
        this.lineMonopolyAuraGroup = auraGroup;
    }

    getTileScaleFactor(tileNum) {
        if (this.isMonopolyBoardMode) {
            const disp = Math.max(1, Math.min(31, Number(tileNum) - 1));
            return 1 + ((disp - 1) / 30) * 9; // 1.0x ที่ #1 ถึง 10.0x ที่ #31
        }
        // จังหวัดยิ่งใกล้เส้นชัย มูลค่าและค่าผ่านทางยิ่งสูงขึ้น (1.00x -> 1.85x)
        return 1 + ((Math.max(2, Math.min(99, tileNum)) - 2) / 97) * 0.85;
    }

    getTileBuildCosts(tileNum) {
        if (this.isMonopolyBoardMode) {
            const monoTile = Array.isArray(this.monopolyTilesList) ? this.monopolyTilesList[Number(tileNum) - 1] : null;
            const disp = Math.max(1, Math.min(31, Number(tileNum) - 1));
            const base = (monoTile && Number(monoTile.price) > 0)
                ? Number(monoTile.price)
                : (100000 + (disp - 1) * 30000);
            const lmBase = Math.round(base * 2.5);
            const slmBase = Math.round(lmBase * 1.75); // ซุปเปอร์แลนด์มาร์ค
            return {
                city1: base,
                city2: base * 2,
                city3: base * 3,
                unitCost: base,
                landmarkUpgrade: lmBase,
                superLandmarkUpgrade: slmBase
            };
        }
        const factor = this.getTileScaleFactor(tileNum);
        const base = this.roundMatchGold((Number(this.matchConfig?.city_base_cost) || 120000) * factor);
        const lmBase = this.roundMatchGold((Number(this.matchConfig?.landmark_cost) || 320000) * factor);
        const slmBase = this.roundMatchGold(lmBase * 1.75); // ซุปเปอร์แลนด์มาร์ค
        return {
            city1: base,
            city2: base * 2,
            city3: base * 3,
            unitCost: base,
            landmarkUpgrade: lmBase,
            superLandmarkUpgrade: slmBase
        };
    }

    hasMonopolyColorSetBonus(tileNum) {
        if (!this.isMonopolyBoardMode || !Array.isArray(this.monopolyTilesList)) return false;
        const st = this.cityStates[tileNum];
        if (!st || !st.ownerId) return false;
        const ownerPlayer = (this.players || []).find(p => String(p.id) === String(st.ownerId)) || { id: st.ownerId, team: 'NONE' };
        const curTile = this.monopolyTilesList[tileNum - 1];
        if (!curTile || curTile.type !== 'CITY' || !curTile.color) return false;
        const targetColor = String(curTile.color).trim().toLowerCase();
        const sameColorIndices = [];
        this.monopolyTilesList.forEach((mt, idx) => {
            if (mt && mt.type === 'CITY' && String(mt.color || '').trim().toLowerCase() === targetColor) {
                sameColorIndices.push(Number(mt.index || (idx + 1)));
            }
        });
        if (sameColorIndices.length < 2) return false;
        return sameColorIndices.every(idx => this.isTileOwnedByPlayerOrTeam(idx, ownerPlayer));
    }

    checkAndRefreshColorGroupBonus3D(tileNum, player = null) {
        if (!this.isMonopolyBoardMode || !Array.isArray(this.monopolyTilesList)) return;
        const curTile = this.monopolyTilesList[Number(tileNum) - 1];
        if (!curTile || curTile.type !== 'CITY' || !curTile.color) return;
        const targetColor = String(curTile.color).trim().toLowerCase();
        const sameColorIndices = [];
        this.monopolyTilesList.forEach((mt, idx) => {
            if (mt && mt.type === 'CITY' && String(mt.color || '').trim().toLowerCase() === targetColor) {
                sameColorIndices.push(Number(mt.index || (idx + 1)));
            }
        });
        const hasBonus = this.hasMonopolyColorSetBonus(tileNum);
        sameColorIndices.forEach(idx => {
            this.refreshSingleTileTexture(idx);
            if (this.cityStates[idx]) {
                this.rebuildTileCity3D(idx);
            }
        });
        if (hasBonus && player) {
            const names = sameColorIndices.map(i => `#${this.getDisplayTileNumber(i)} ${this.getProvinceName(i)}`).join(' + ');
            this.showSkillBanner(`🎨 [ครบเซ็ตสี คูณ 2!] ${player.username} ครองเมืองสีเดียวกันครบเซ็ต (${names}) เปิดแสงเออร่า ค่าผ่านทางคูณ 2 ทั้งสีทันที!`);
            this.logMessage(`🎨 [โบนัสครบสี คูณ 2] ${player.username} (หรือทีม) สร้างเมืองครบสีเดียวกัน (${names}) เปิดแสงเออร่าเมืองคูณ ค่าผ่านทางคูณ 2 ทั้งสีทันที!`, 'skill');
        }
    }

    getTileToll(tileNum) {
        const st = this.cityStates[tileNum];
        if (!st) return 0;
        const tollPct = (Number(this.matchConfig?.toll_percent) || 85) / 100;
        let landmarkBonus = 1.0;
        if (st.isSuperLandmark) landmarkBonus = 2.45;
        else if (st.isLandmark) landmarkBonus = 1.45;
        const colorSetMult = this.hasMonopolyColorSetBonus(tileNum) ? 2 : 1;
        const presetSpecialMult = Number(this.monopolyTilesList?.[tileNum - 1]?.special_multiplier || 0);
        const baseMult = Math.max(1, Number(st.multiplier) || 1, presetSpecialMult || 1);
        const mult = baseMult * colorSetMult;
        const customBaseToll = (this.isMonopolyBoardMode && this.monopolyTilesList?.[tileNum - 1]?.toll > 0) ? Number(this.monopolyTilesList[tileNum - 1].toll) : 0;
        const dragonMult = (this.isMonopolyBoardMode && this.monopolyStageSkillCode === 'DRAGON_AURA' && st.isLandmark) ? 1.5 : 1.0;
        const baseVal = customBaseToll > 0 ? (customBaseToll * (Number(st.houses) || 1)) : ((Number(st.investedGold) || 10000) * tollPct);
        const raw = baseVal * landmarkBonus * dragonMult * mult;
        return Math.max(500, this.roundMatchGold(raw));
    }

    getTileBuyoutCost(tileNum) {
        const st = this.cityStates[tileNum];
        if (!st || st.isLandmark) return Infinity;
        const buyPct = (Number(this.matchConfig?.buyout_percent) || 160) / 100;
        const raw = (Number(st.investedGold) || 10000) * buyPct;
        return Math.max(1000, this.roundMatchGold(raw));
    }

    getPlayerTotalAssets(player) {
        if (!player || player.isBankrupt) return 0;
        let propVal = 0;
        for (const st of Object.values(this.cityStates)) {
            if (st && String(st.ownerId) === String(player.id)) {
                propVal += Number(st.investedGold) || 0;
            }
        }
        return (Number(player.matchGold) || 0) + propVal;
    }

    getPlayerCityCounts(player) {
        let cities = 0;
        let landmarks = 0;
        let superLandmarks = 0;
        if (!player) return { cities, landmarks, superLandmarks };
        for (const st of Object.values(this.cityStates)) {
            if (st && String(st.ownerId) === String(player.id)) {
                if (st.isSuperLandmark) superLandmarks++;
                else if (st.isLandmark) landmarks++;
                else cities += Number(st.level) || 1;
            }
        }
        return { cities, landmarks, superLandmarks };
    }

    getMatchDurationSeconds() {
        const mins = (window.GAME_RULES && window.GAME_RULES.match_duration_minutes !== undefined)
            ? Number(window.GAME_RULES.match_duration_minutes)
            : 10;
        const clampedMins = Math.max(1, Math.min(60, isNaN(mins) ? 10 : mins));
        return Math.round(clampedMins * 60);
    }

    startMatchTimer(customStartTime = null) {
        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }

        this.matchTimeLimit = this.getMatchDurationSeconds();
        if (customStartTime) {
            this.matchStartTime = Number(customStartTime);
        } else if (!this.matchStartTime) {
            this.matchStartTime = Date.now();
        }

        const elapsedSec = Math.floor((Date.now() - this.matchStartTime) / 1000);
        this.matchTimeRemaining = Math.max(0, this.matchTimeLimit - elapsedSec);

        // หากเวลาในการแข่งขันผ่านไปเกิน 10 นาทีแล้ว (เช่น ผู้เล่นหลุดไป 30 นาทีแล้วกลับมา) ให้ตัดสินผู้ชนะทันที!
        if (this.matchTimeRemaining <= 0 || elapsedSec >= this.matchTimeLimit) {
            this.matchTimeRemaining = 0;
            this.updateMatchTimerHUD();
            setTimeout(() => {
                this.handleMatchTimeoutVictory();
            }, 400);
            return;
        }

        this.warned1Min = (this.matchTimeRemaining <= 60);
        this.warned30Sec = (this.matchTimeRemaining <= 30);

        this.updateMatchTimerHUD();

        this.matchTimerInterval = setInterval(() => {
            if (!this.isMatchActive || this.isGameOver) {
                if (this.matchTimerInterval) {
                    clearInterval(this.matchTimerInterval);
                    this.matchTimerInterval = null;
                }
                return;
            }

            const currentElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
            this.matchTimeRemaining = Math.max(0, this.matchTimeLimit - currentElapsed);

            this.updateMatchTimerHUD();

            // เตือนเมื่อเหลือ 1 นาที (60 วินาที)
            if (this.matchTimeRemaining <= 60 && this.matchTimeRemaining > 30 && !this.warned1Min) {
                this.warned1Min = true;
                if (typeof showToast === 'function') {
                    showToast('⏰ เหลือเวลาอีก 1 นาที! ใครมีทองและสิ่งก่อสร้างรวมเยอะสุดจะชนะ!');
                }
                this.logMessage('⚠️ [แจ้งเตือนเวลา] เหลือเวลาแข่งขันอีก 1 นาทีสุดท้าย! เร่งสร้างเมืองและทำแต้ม!', 'warning');
                if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                    window.soundEngine.playAlert();
                }
            }
            // เตือนเมื่อเหลือ 30 วินาที
            else if (this.matchTimeRemaining <= 30 && this.matchTimeRemaining > 0 && !this.warned30Sec) {
                this.warned30Sec = true;
                if (typeof showToast === 'function') {
                    showToast('🚨 30 วินาทีสุดท้าย! ระบบจะตัดสินผู้ชนะจากสินทรัพย์และสิ่งก่อสร้างรวม!');
                }
                this.logMessage('🚨 [แจ้งเตือนเวลา] 30 วินาทีสุดท้าย! ผู้ที่มีทองและมูลค่าสิ่งก่อสร้างสูงสุดจะคว้าชัยชนะทันที!', 'warning');
                if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                    window.soundEngine.playAlert();
                }
            }

            // หมดเวลา 10 นาที (0 วินาที)
            if (this.matchTimeRemaining <= 0) {
                if (this.matchTimerInterval) {
                    clearInterval(this.matchTimerInterval);
                    this.matchTimerInterval = null;
                }
                this.handleMatchTimeoutVictory();
            }
        }, 1000);
    }

    updateMatchTimerHUD() {
        const el = document.getElementById('match-timer-digits');
        const pill = document.getElementById('match-timer-hud-pill');
        const ring = document.getElementById('timer-ring-progress');
        const tag = document.getElementById('timer-badge-tag');
        if (!el) return;

        const rem = Math.max(0, this.matchTimeRemaining ?? 600);
        const mins = Math.floor(rem / 60);
        const secs = rem % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        el.innerText = timeStr;

        if (ring) {
            const pct = ((rem / 600) * 100).toFixed(1);
            ring.setAttribute('stroke-dasharray', `${pct}, 100`);
        }

        let badgeText = '⚡ แข่งขัน 10 นาที';
        let stateClass = 'match-timer-hud-pill';

        if (rem <= 30) {
            badgeText = '🚨 ตัดสินผู้ชนะ!';
            stateClass = 'match-timer-hud-pill urgent-30';
        } else if (rem <= 60) {
            badgeText = '⚠️ 1 นาทีสุดท้าย!';
            stateClass = 'match-timer-hud-pill urgent-60';
        } else if (rem <= 120) {
            badgeText = '⚡ 2 นาทีสุดท้าย';
            stateClass = 'match-timer-hud-pill urgent-120';
        }

        if (tag) tag.innerText = badgeText;
        if (pill) pill.className = stateClass;
    }

    handleMatchTimeoutVictory() {
        if (this.isGameOver) return;

        // คัดเลือกคนที่มีสินทรัพย์รวมสูงสุด (ทองสด + มูลค่าสิ่งก่อสร้าง/เมือง/แลนด์มาร์ค)
        const ranked = [...this.players].sort((a, b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        });

        const winner = ranked[0] || this.players[0];
        this.handleVictory(winner, 'TIME_OUT');
    }

    formatLineRichCash(val) {
        const num = Math.max(0, Math.floor(Number(val) || 0));
        if (num >= 1000000000) {
            return (num / 1000000000).toFixed(1) + 'B';
        }
        if (num >= 1000000) {
            const m = Math.floor(num / 1000000);
            const k = Math.floor((num % 1000000) / 1000);
            return k > 0 ? `${m}M${String(k).padStart(3, '0')}` : `${m}M`;
        }
        if (num >= 1000) {
            return `${Math.floor(num / 1000)}K`;
        }
        return String(num);
    }

    getPlayerSkillBadges(p) {
        const isHuman = !p.is_bot;
        const u = window.DEFAULT_USER || {};
        const pGrade = isHuman
            ? (u.char_grade || u.equipped_character?.grade || p.char_grade || 'SS+')
            : (p.char_grade || p.character_grade || p.grade || (typeof window.getRandomBotCardGrade === 'function' ? window.getRandomBotCardGrade() : 'S+'));

        // Slot 1: ลูกเต๋า (Dice)
        const diceName = p.dice_name || 'ลูกเต๋าควบคุม';
        const diceRate = p.dice_control_rate || (p.is_bot ? 45 : 55);
        const diceSlot = {
            type: 'dice',
            icon: '🎲',
            grade: 'S+',
            title: diceName,
            sub: `${diceRate}%`,
            desc: `สถิติควบคุมเต๋า +${diceRate}%`
        };

        // Slot 2 & Slot 3: อัญมณี 1 & 2 (Gems)
        const equippedGems = (typeof this.getPlayerEquippedGems === 'function') ? this.getPlayerEquippedGems(p) : [];

        // Slot 2: Gem 1
        const g1 = (equippedGems && equippedGems[0]) ? equippedGems[0] : null;
        const gem1Slot = g1 ? {
            type: 'gem1',
            icon: '💎',
            grade: g1.grade || 'S+',
            title: g1.name || g1.skill_name || 'อัญมณีพิทักษ์',
            sub: `${g1.trigger_rate_percent || 80}%`,
            desc: `${g1.skill_name || 'โล่ป้องกัน'} (${g1.trigger_rate_percent || 80}%)`
        } : {
            type: 'gem1',
            icon: '🛡️',
            grade: 'S+',
            title: 'โล่คุ้มกันเวทย์',
            sub: '85%',
            desc: 'ป้องกันกับดักและการโจมตี 85%'
        };

        // Slot 3: Gem 2
        const g2 = (equippedGems && equippedGems[1]) ? equippedGems[1] : null;
        const gem2Slot = g2 ? {
            type: 'gem2',
            icon: '🔮',
            grade: g2.grade || 'S+',
            title: g2.name || g2.skill_name || 'อัญมณีเวทมนตร์',
            sub: `${g2.trigger_rate_percent || 75}%`,
            desc: `${g2.skill_name || 'พลังเวท'} (${g2.trigger_rate_percent || 75}%)`
        } : {
            type: 'gem2',
            icon: '🧲',
            grade: 'S+',
            title: 'แม่เหล็กดูดทอง',
            sub: '75%',
            desc: 'ดึงดูดและแย่งชิงค่าผ่านทาง 75%'
        };

        // Slot 4: สกิลการ์ด (Card Skill)
        const cardSkillTitle = (p.skill && (p.skill.name || p.skill.title))
            || (p.skill && p.skill.code === 'PULL_BACK_8' ? 'ดึงดูด 8 ช่อง' : 'สกิลการ์ดเทพ');
        const cardSkillRate = (p.skill && (p.skill.power || p.skill.rate)) || 80;
        const cardSlot = {
            type: 'cardskill',
            icon: '⚡',
            grade: pGrade,
            title: cardSkillTitle,
            sub: `${cardSkillRate}%`,
            desc: `สกิลการ์ดตัวละคร: ทำงาน ${cardSkillRate}%`
        };

        return [diceSlot, gem1Slot, gem2Slot, cardSlot];
    }

    updateMatchWealthHUD() {
        const hud = document.getElementById('match-wealth-hud');
        if (!hud) return;
        if (!this.isMatchActive || !this.players || this.players.length === 0) {
            hud.style.display = 'none';
            hud.innerHTML = '';
            return;
        }
        hud.style.display = 'block';

        const activePlayer = this.players[this.currentTurnIndex];

        // Format 10-minute timer with High-Tech Esports Dial
        if (this.isMatchActive && this.matchStartTime) {
            const curElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
            this.matchTimeRemaining = Math.max(0, (this.matchTimeLimit || 600) - curElapsed);
        }
        const rem = Math.max(0, this.matchTimeRemaining ?? 600);
        const mins = Math.floor(rem / 60);
        const secs = rem % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

        let timerClass = '';
        if (rem <= 30) {
            timerClass = 'urgent-30';
        } else if (rem <= 60) {
            timerClass = 'urgent-60';
        } else if (rem <= 120) {
            timerClass = 'urgent-120';
        }

        const timerHtml = `
            <div class="match-timer-hud-pill ${timerClass}" id="match-timer-hud-pill" title="เวลาแข่งขันคงเหลือ">
                <div class="timer-digits-line" style="display:flex; align-items:center; gap:3px;">
                    <span style="font-size:12px;">⏱️</span>
                    <span id="match-timer-digits" class="timer-digits-text">${timeStr}</span>
                </div>
            </div>
        `;

        // ค้นหาตำแหน่งของผู้เล่นเรา (Human Player) ในลำดับการเล่น
        let myIndex = this.getLocalPlayerIndex();
        if (myIndex === -1) myIndex = 0;
        const N = this.players.length;

        // จัดอันดับสินทรัพย์รวม (Rank 1 -> 4) สำหรับแสดงเหรียญรางวัล
        const rankedPlayers = [...this.players].sort((a, b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        });

        // กำหนดตำแหน่ง 4 มุมตามกติกา:
        // - มุมล่างขวา (br): มุมของเราเสมอ
        // - วนซ้าย:
        //   - หากเราคนที่ 1: ล่างซ้าย=2, บนซ้าย=3, บนขวา=4
        //   - หากเราคนที่ 2: ล่างซ้าย=3, บนซ้าย=4, บนขวา=1
        //   - หากเราคนที่ 3: ล่างซ้าย=4, บนซ้าย=1, บนขวา=2
        //   - หากเราคนที่ 4: ล่างซ้าย=1, บนซ้าย=2, บนขวา=3
        const cornerAssignments = [];

        const isTeamMatch = (N === 4) && (this.gameMode === 'TEAM' || window.currentActiveGameMode === 'TEAM');
        const myTeam = (this.players[myIndex] && this.players[myIndex].team) ? this.players[myIndex].team : 'A';
        const usedTeamOppCorners = [];

        this.players.forEach((p, turnIdx) => {
            let corner = 'br';
            if (turnIdx === myIndex) {
                corner = 'br'; // มุมล่างขวา คือมุมของเรา
            } else if (isTeamMatch) {
                const isPartner = Boolean(p.is_friend_partner || (p.team && myTeam && p.team === myTeam));
                if (isPartner) {
                    corner = 'tl'; // มุมบนซ้าย คือเพื่อนร่วมทีมของเราเสมอ
                } else {
                    const nextOppCorner = !usedTeamOppCorners.includes('bl') ? 'bl' : 'tr';
                    usedTeamOppCorners.push(nextOppCorner);
                    corner = nextOppCorner;
                }
            } else if (N === 4) {
                const offset = (turnIdx - myIndex + 4) % 4;
                if (offset === 1) corner = 'bl'; // มุมล่างซ้าย
                else if (offset === 2) corner = 'tl'; // มุมบนซ้าย
                else if (offset === 3) corner = 'tr'; // มุมบนขวา
            } else if (N === 2) {
                corner = 'tl'; // 1v1 วางตรงข้ามมุมบนซ้าย
            } else if (N === 3) {
                const offset = (turnIdx - myIndex + 3) % 3;
                if (offset === 1) corner = 'bl';
                else if (offset === 2) corner = 'tl';
            }
            cornerAssignments.push({ player: p, turnIdx, corner });
        });

        const isMonopoly = Boolean(this.isMonopolyBoardMode || this.gameMode === 'MONOPOLY' || window.currentActiveGameMode === 'MONOPOLY');

        const cardsHtml = cornerAssignments.map(({ player: p, turnIdx, corner }) => {
            const rankIdx = rankedPlayers.indexOf(p);
            const rankNum = rankIdx >= 0 ? rankIdx + 1 : turnIdx + 1;
            const isTurn = (p.id === activePlayer?.id) && !p.isBankrupt && !this.isGameOver;
            const hexColor = '#' + (Number(p.color) || 0x00e5ff).toString(16).padStart(6, '0');
            const isMe = (turnIdx === myIndex);
            const isHuman = isMe;
            const u = window.DEFAULT_USER || {};
            const myRealName = u.displayName || u.name || u.username || 'ผู้เล่น';
            const myRealAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl() : (u.avatar_url || u.picture);
            const avatar = isMe ? myRealAvatar : (p.avatar_url || p.picture || 'avatars/google_avatar.png');
            let pName = isMe ? myRealName : (p.username || 'ผู้เล่น');
            if (isMe && (pName === 'เขียนศักดิ์' || pName === 'ผู้เล่น' || pName === 'Google Player')) {
                pName = myRealName;
            }
            const totalAssets = this.getPlayerTotalAssets(p);
            const counts = this.getPlayerCityCounts(p);
            const isFirst = (rankNum === 1);

            const alignClass = (corner === 'tr' || corner === 'br') ? 'align-right' : 'align-left';
            const cashLabel = p.isBankrupt ? 'ล้มละลาย' : this.formatLineRichCash(p.matchGold);
            const totalLabel = p.isBankrupt ? '0' : this.formatLineRichCash(totalAssets);

            let landCapsuleText = '';
            let landCapsuleIcon = '';
            let landCapsuleTitle = '';
            let pedestalContent = '';
            let pedestalTitle = '';

            if (isMonopoly) {
                landCapsuleText = String(counts.cities || 0);
                landCapsuleIcon = '🏝️';
                landCapsuleTitle = `เมือง/เกาะที่ครอบครอง: ${counts.cities || 0} แห่ง`;
                pedestalContent = `⛵ 🏛️${counts.landmarks + (counts.superLandmarks || 0)}`;
                pedestalTitle = `แลนด์มาร์ค: ${counts.landmarks + (counts.superLandmarks || 0)} แห่ง`;
            } else {
                landCapsuleText = `ช่อง ${p.currentTile || 1}`;
                landCapsuleIcon = '🏁';
                landCapsuleTitle = `ตำแหน่งบนกระดาน: ช่อง ${p.currentTile || 1}/100`;
                pedestalContent = `🪜 ${p.currentTile || 1}/100`;
                pedestalTitle = `เป้าหมายเส้นชัยช่อง 100`;
            }

            const _fx = this._skillFx;
            const _fxOn = Boolean(_fx && Date.now() < _fx.until && (_fx.playerId === p.id || _fx.playerIdx === turnIdx));
            const skillBadges = _fxOn ? this.getPlayerSkillBadges(p).filter(s => s.type === _fx.type) : [];
            const skillsHtml = skillBadges.map(s => `
            <div class="lgr-skill-slot ${s.type.startsWith('gem') ? 'slot-gem' : ''} skill-fx-active"
                 onclick="window.showSkillSlotTip(event, '${s.type}', '${s.title.replace(/'/g, "\\'")}', '${s.desc.replace(/'/g, "\\'")}');"
                 ontouchend="window.showSkillSlotTip(event, '${s.type}', '${s.title.replace(/'/g, "\\'")}', '${s.desc.replace(/'/g, "\\'")}');"
                 title="${s.title}: ${s.desc}">
                <span class="lgr-slot-grade">${s.grade}</span>
                <span class="lgr-slot-icon">${s.icon}</span>
                <span class="lgr-slot-sub">${s.sub}</span>
            </div>
        `).join('');

            return `
            <div class="corner-hud-slot corner-${corner}"
                 onclick="window.handleCornerCardTap(event, ${turnIdx});"
                 ontouchend="window.handleCornerCardTap(event, ${turnIdx});"
                 title="แตะเพื่อดูรายละเอียดผู้เล่น: ${pName}">
                <div class="lgr-hud-card ${alignClass} ${isFirst ? 'is-rank-1' : ''} ${isTurn ? 'is-active-turn' : ''} ${(isTurn && this.isRolling) ? 'rolling-pop' : ''} ${p.isBankrupt ? 'bankrupt' : ''} ${isHuman ? 'is-me-card' : ''}"
                     style="--p-color:${hexColor};"
                     onclick="window.handleCornerCardTap(event, ${turnIdx});"
                     ontouchend="window.handleCornerCardTap(event, ${turnIdx});">

                    <!-- Row 1: Top (Avatar + Main Capsule) -->
                    <div class="lgr-row-top" onclick="window.handleCornerCardTap(event, ${turnIdx});">
                        <div class="lgr-avatar-box">
                            <img src="${avatar}" class="lgr-avatar-img" onerror="this.onerror=null;this.src='avatars/google_avatar.png';">
                            <div class="lgr-ability-badge" title="Character Ability">
                                <span class="lgr-ability-card-icon">🎴</span>
                                <span class="lgr-ability-text">Ability</span>
                            </div>
                            ${isFirst ? '<div class="lgr-crown-badge" title="ผู้นำอันดับ 1">👑</div>' : ''}
                        </div>

                        <div class="lgr-capsule-col">
                            <div class="lgr-card-gauge-wrapper" id="lgr-gauge-card-${turnIdx}" title="หลอดชาร์จพลังเต๋า">
                                <div class="lgr-card-gauge-fill" id="lgr-gauge-fill-${turnIdx}"></div>
                            </div>
                            <div class="lgr-capsule">
                                <div class="lgr-capsule-upper">
                                    <div class="lgr-cash-group">
                                        <span class="lgr-cash-icon">💵</span>
                                        <span class="lgr-cash-val">${cashLabel}</span>
                                    </div>
                                    <span class="lgr-rank-digit rank-${rankNum}">${rankNum}</span>
                                </div>
                                <div class="lgr-capsule-lower">
                                    <span class="lgr-total-label">รวม</span>
                                    <span class="lgr-total-val">${totalLabel}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 2: Mid (Island/Tile count capsule + Boat/Pedestal) -->
                    <div class="lgr-row-mid" onclick="window.handleCornerCardTap(event, ${turnIdx});">
                        <div class="lgr-land-capsule" title="${landCapsuleTitle}">
                            <span class="lgr-land-num">${landCapsuleText}</span>
                            <span class="lgr-land-icon">${landCapsuleIcon}</span>
                        </div>
                        <div class="lgr-pedestal-boat" title="${pedestalTitle}">
                            ${pedestalContent}
                        </div>
                    </div>

                    <!-- Row 3: 4 Skills Slots (Dice, Gem 1, Gem 2, Card Skill) -->
                    <div class="lgr-row-skills ${skillBadges.length ? 'has-fx' : 'is-empty'}">
                        ${skillsHtml}
                    </div>
                </div>
            </div>
        `;
        }).join('');

        hud.innerHTML = timerHtml + cardsHtml;
    }

    /**
     * แสดง Popup รายละเอียดผู้เล่นเมื่อแตะการ์ดที่มุมจอ (In-Game Player Inspect Popup)
     */
    showInGamePlayerPopup(playerIdx) {
        if (!this.players || this.players.length === 0) return;
        const idx = Number(playerIdx);
        const p = (!isNaN(idx) && this.players[idx]) || this.players.find(x => x.id == playerIdx) || this.players[0];
        if (!p) return;

        // คำนวณอันดับปัจจุบันแบบเรียลไทม์
        const rankedPlayers = [...this.players].sort((a, b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        });
        const rankIdx = rankedPlayers.indexOf(p);
        const rankNum = rankIdx >= 0 ? rankIdx + 1 : playerIdx + 1;
        const isFirst = (rankNum === 1);

        const isMe = this.isLocalPlayer(p);
        const isHuman = isMe;
        const u = window.DEFAULT_USER || {};
        const myRealName = u.displayName || u.name || u.username || 'ผู้เล่น';
        const myRealAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl() : (u.avatar_url || u.picture);
        const avatar = isMe ? myRealAvatar : (p.avatar_url || p.picture || 'avatars/google_avatar.png');
        let pName = isMe ? myRealName : (p.username || 'ผู้เล่น');
        if (isMe && (pName === 'เขียนศักดิ์' || pName === 'ผู้เล่น' || pName === 'Google Player')) {
            pName = myRealName;
        }

        const totalAssets = this.getPlayerTotalAssets(p);
        const counts = this.getPlayerCityCounts(p);
        const pGrade = isHuman
            ? (u.char_grade || u.equipped_character?.grade || p.char_grade || 'SS+')
            : (p.char_grade || p.character_grade || p.grade || (typeof window.getRandomBotCardGrade === 'function' ? window.getRandomBotCardGrade() : 'S+'));
        const pLevel = isHuman
            ? (parseInt(u.char_level || u.equipped_character?.level) || 30)
            : (parseInt(p.level || p.char_level) || (typeof window.getRandomBotLevel === 'function' ? window.getRandomBotLevel() : 25));

        const curTile = p.currentTile || 1;
        let tileName = '🏁 จุดเส้นชัย (ช่อง 1)';
        if (curTile === 100) {
            tileName = '🏁 เส้นชัย (ช่อง 100)';
        } else if (typeof THAI_PROVINCES !== 'undefined' && THAI_PROVINCES[(curTile - 1) % THAI_PROVINCES.length]) {
            tileName = `ช่อง ${curTile} (${THAI_PROVINCES[(curTile - 1) % THAI_PROVINCES.length]})`;
        } else {
            tileName = `ช่องที่ ${curTile}`;
        }

        const isTurn = (p.id === this.activePlayer?.id) && !p.isBankrupt && !this.isGameOver;
        const statusText = p.isBankrupt
            ? '<span style="color:#ef4444; font-weight:800;">💥 ล้มละลายแล้ว</span>'
            : (isTurn
                ? '<span style="color:#00e5ff; font-weight:800;">🎲 กำลังถึงตาเดิน (Active)</span>'
                : '<span style="color:#94a3b8; font-weight:600;">⏳ รอตาเดิน</span>');

        const rankTitles = {
            1: '👑 ผู้นำอันดับ 1 (ครองสินทรัพย์สูงสุด)',
            2: '🥈 อันดับที่ 2',
            3: '🥉 อันดับที่ 3',
            4: '4️⃣ อันดับที่ 4'
        };
        const rankHeaderTitle = rankTitles[rankNum] || `อันดับที่ ${rankNum}`;

        // ดึงรายการอัญมณีที่สวมใส่จริงของผู้เล่นคนนี้ (1-3 ชิ้นตามเกรดการ์ด)
        const equippedGems = this.getPlayerEquippedGems(p);
        const maxSlots = (pGrade === 'SS+' ? 3 : (pGrade === 'S+' ? 2 : 1));
        let gemsListHtml = '';
        for (let sIdx = 0; sIdx < maxSlots; sIdx++) {
            const g = (equippedGems && equippedGems[sIdx]) ? equippedGems[sIdx] : null;
            if (g) {
                const gColor = g.gem_color || (g.grade === 'SS+' ? '#c084fc' : (g.grade === 'S+' ? '#38bdf8' : '#ffd700'));
                const svgIcon = (typeof window.generateGemSvgPreview === 'function')
                    ? window.generateGemSvgPreview(g.shape || 'pentagon', g.grade || 'SS+', 30, gColor, g.aura_type || 'pulse', g.particle_fx || 'spark', 'high')
                    : `<span style="font-size:16px;">💎</span>`;
                gemsListHtml += `
                    <div style="background:rgba(15,23,42,0.85); border:1px solid ${gColor}66; border-radius:8px; padding:4px 8px; display:flex; align-items:center; gap:8px; box-shadow:0 0 8px ${gColor}22;">
                        <div style="width:30px; height:30px; display:flex; align-items:center; justify-content:center; filter:drop-shadow(0 0 5px ${gColor}); flex-shrink:0;">
                            ${svgIcon}
                        </div>
                        <div style="min-width:0; flex:1; text-align:left;">
                            <div style="font-size:11px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                ${g.name || 'อัญมณีมหาเวทย์'} <span style="font-size:9.5px; color:${gColor}; font-weight:900;">[เกรด ${g.grade || 'SS+'}]</span>
                            </div>
                            <div style="font-size:10px; color:#fde047; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                ⚡ ${g.skill_name || 'สกิลอัญมณี'} (${g.trigger_rate_percent || 80}%)
                            </div>
                        </div>
                    </div>
                `;
            } else {
                const shapeNames = ['🔺 3 เหลี่ยม', '🔷 4 เหลี่ยม', '⬠ 5 เหลี่ยม'];
                const shapeIcons = ['△', '□', '⬠'];
                gemsListHtml += `
                    <div style="background:rgba(15,23,42,0.45); border:1px dashed rgba(148,163,184,0.35); border-radius:8px; padding:5px 8px; display:flex; align-items:center; gap:8px; opacity:0.75;">
                        <div style="width:28px; height:28px; display:flex; align-items:center; justify-content:center; font-size:16px; color:#94a3b8; border:1px dashed rgba(148,163,184,0.45); border-radius:6px;">
                            ${shapeIcons[sIdx] || '◇'}
                        </div>
                        <div style="font-size:10px; color:#94a3b8; font-weight:600;">
                            ช่องที่ ${sIdx + 1} (${shapeNames[sIdx] || 'กรอบอัญมณี'} • ยังไม่ได้สวมใส่)
                        </div>
                    </div>
                `;
            }
        }

        let modal = document.getElementById('modal-ingame-player-inspect');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'modal-ingame-player-inspect';
            modal.className = 'modal-overlay';
            document.body.appendChild(modal);
        }
        modal.style.cssText = 'position:fixed !important; inset:0 !important; width:100vw !important; height:100dvh !important; display:flex !important; align-items:center !important; justify-content:center !important; z-index:1000200 !important; background:rgba(0,0,0,0.65) !important; backdrop-filter:blur(4px) !important; -webkit-backdrop-filter:blur(4px) !important; pointer-events:auto !important; touch-action:manipulation !important; padding:10px !important; box-sizing:border-box !important;';

        const safeInspectName = String(pName || '').replace(/['"]/g, '');
        const friendActionHtml = (!isHuman && typeof window.renderFriendActionButtonHtml === 'function')
            ? window.renderFriendActionButtonHtml({
                user_id: p.id || p.user_id || (900 + playerIdx),
                username: safeInspectName,
                avatar_url: avatar,
                level: pLevel,
                char_grade: pGrade,
                clan_name: p.clan_name || (playerIdx % 2 === 1 ? '@PIMMY' : 'บ้านมังกรทองคำ')
            }, 'ingame')
            : (!isHuman ? `
                <button type="button" id="btn-ingame-add-friend" onclick="event.stopPropagation(); if (typeof window.sendFriendRequestFromInspect === 'function') window.sendFriendRequestFromInspect('${safeInspectName}', '${avatar}', ${pLevel}, '${pGrade}', 'ingame');"
                    style="margin-top:6px; padding:5px 12px; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer; border:1px solid #10b981; background:linear-gradient(135deg, #059669, #10b981); color:#fff; display:inline-flex; align-items:center; gap:5px;">
                    <span>➕</span> <span>เพิ่มเพื่อน</span>
                </button>
            ` : '');

        modal.innerHTML = `
            <div class="modal-content glass-panel ingame-player-inspect-card" onclick="event.stopPropagation();" style="position:relative !important; z-index:1000201 !important; touch-action:manipulation !important; width:min(90vw, 340px) !important; max-width:340px !important; padding:12px 14px !important; border-radius:18px !important; border:none !important; background:linear-gradient(165deg, rgba(20,32,56,0.98), rgba(8,14,26,0.99)) !important; box-shadow:0 24px 50px rgba(0,0,0,0.92), 0 8px 24px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.18) !important;">
                <!-- Header -->
                <div style="display:flex; align-items:center; justify-content:space-between; border-bottom:none; box-shadow:0 4px 12px rgba(0,0,0,0.45); padding-bottom:6px; margin-bottom:8px;">
                    <div style="display:flex; align-items:center; gap:6px;">
                        <span style="font-size:16px;">👤</span>
                        <span style="font-size:13px; font-weight:800; color:#00e5ff;">ข้อมูลผู้เล่นในการแข่งขัน</span>
                    </div>
                    <button type="button" id="btn-inspect-close-x" class="modal-close" onclick="event.stopPropagation(); window.closeInGamePlayerInspectModal();" style="width:28px; height:28px; font-size:18px; line-height:26px; border-radius:50%; border:none; background:rgba(239,68,68,0.85); color:#fff; cursor:pointer; display:flex; align-items:center; justify-content:center; touch-action:manipulation; box-shadow:0 2px 6px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.25);">&times;</button>
                </div>

                <!-- Hero Section: Larger Avatar (68px) + Info -->
                <div class="ingame-inspect-hero ${isFirst ? 'is-first-hero' : ''}" style="display:flex; align-items:center; gap:10px; background:rgba(255,255,255,0.04); border-radius:12px; padding:8px 10px; margin-bottom:8px; border:none; box-shadow:0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.12);">
                    <div class="ingame-hero-avatar-wrap" style="width:68px !important; height:68px !important; min-width:68px !important; border-radius:50%; position:relative; flex-shrink:0; border:none; box-shadow:0 0 16px ${isFirst ? 'rgba(255,215,0,0.6)' : 'rgba(0,229,255,0.4)'}; background:#0f172a; overflow:hidden;">
                        <img src="${avatar}" class="ingame-hero-avatar-img" onerror="this.onerror=null;this.src='avatars/google_avatar.png';" style="width:100% !important; height:100% !important; object-fit:cover !important;">
                        <span class="ingame-hero-grade tag-${String(pGrade).toLowerCase().replace('+', 'plus')}" style="position:absolute; bottom:1px; right:2px; font-size:10px; font-weight:900; z-index:2; padding:0 4px; border-radius:4px; line-height:1.2;">${pGrade}</span>
                    </div>
                    <div class="ingame-hero-details" style="min-width:0; flex:1; text-align:left;">
                        <div class="ingame-hero-name-row" style="font-size:14px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:flex; align-items:center; gap:6px;">
                            <span class="ingame-hero-name">${pName}</span>
                            ${isHuman ? '<span class="corner-card-me-tag" style="font-size:9.5px; padding:1px 5px;">คุณ</span>' : ''}
                        </div>
                        <div style="font-size:11px; color:#cbd5e1; margin-top:2px;">
                            การ์ด: <strong style="color:#ffd700;">Lv.${pLevel}</strong> • ทอย: <strong style="color:#38bdf8;">คนที่ ${playerIdx + 1} (P${playerIdx + 1})</strong>
                        </div>
                        <div class="ingame-rank-banner ${isFirst ? 'banner-first' : ''}" style="font-size:10.5px; font-weight:800; color:${isFirst ? '#ffd700' : '#38bdf8'}; margin-top:2px; display:inline-block; padding:1px 6px; border-radius:6px; background:${isFirst ? 'rgba(255,215,0,0.15)' : 'rgba(56,189,248,0.15)'}; border:none; box-shadow:0 2px 6px rgba(0,0,0,0.3);">
                            ${rankHeaderTitle}
                        </div>
                        ${!isHuman ? `<div id="ingame-inspect-friend-action-wrap" style="margin-top:4px;">${friendActionHtml}</div>` : ''}
                    </div>
                </div>

                <!-- Stats Compact 2x2 Grid -->
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:8px;">
                    <div style="background:linear-gradient(160deg, rgba(26,36,58,0.85) 0%, rgba(13,19,32,0.95) 100%); border:none; box-shadow:0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1); border-radius:10px; padding:6px 8px; text-align:left;">
                        <div style="font-size:9.5px; color:#94a3b8; font-weight:600;">💰 สินทรัพย์รวม</div>
                        <div style="font-size:12px; font-weight:900; color:#ffd700;">${totalAssets.toLocaleString()} 💰</div>
                    </div>
                    <div style="background:linear-gradient(160deg, rgba(26,36,58,0.85) 0%, rgba(13,19,32,0.95) 100%); border:none; box-shadow:0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1); border-radius:10px; padding:6px 8px; text-align:left;">
                        <div style="font-size:9.5px; color:#94a3b8; font-weight:600;">💰 เงินสดในกระดาน</div>
                        <div style="font-size:12px; font-weight:900; color:#38bdf8;">${(Number(p.matchGold) || 0).toLocaleString()} 💰</div>
                    </div>
                    <div style="background:linear-gradient(160deg, rgba(26,36,58,0.85) 0%, rgba(13,19,32,0.95) 100%); border:none; box-shadow:0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1); border-radius:10px; padding:6px 8px; text-align:left;">
                        <div style="font-size:9.5px; color:#94a3b8; font-weight:600;">🏠 เมือง / 🏛️ แลนด์มาร์ค</div>
                        <div style="font-size:12px; font-weight:900; color:#a78bfa;">${counts.cities} เมือง • ${counts.landmarks + (counts.superLandmarks || 0)} แห่ง</div>
                    </div>
                    <div style="background:linear-gradient(160deg, rgba(26,36,58,0.85) 0%, rgba(13,19,32,0.95) 100%); border:none; box-shadow:0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1); border-radius:10px; padding:6px 8px; text-align:left;">
                        <div style="font-size:9.5px; color:#94a3b8; font-weight:600;">📍 ตำแหน่งกระดาน</div>
                        <div style="font-size:11.5px; font-weight:800; color:#34d399; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${tileName}</div>
                    </div>
                </div>

                <!-- 💎 Equipped Gems Section (อัญมณีที่สวมใส่) -->
                <div style="background:rgba(30,27,75,0.4); border:1.5px solid rgba(192,132,252,0.35); border-radius:10px; padding:7px 8px; margin-bottom:8px; text-align:left;">
                    <div style="font-size:11px; font-weight:900; color:#c4b5fd; margin-bottom:5px; display:flex; align-items:center; gap:5px;">
                        <span>💎</span> <span>อัญมณีมหาเวทย์ที่สวมใส่</span>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        ${gemsListHtml}
                    </div>
                </div>

                <!-- Close Button -->
                <div style="text-align:center;">
                    <button type="button" id="btn-inspect-close-action" class="btn btn-secondary" onclick="event.stopPropagation(); window.closeInGamePlayerInspectModal();" style="width:100%; padding:7px 14px; border-radius:8px; font-weight:800; font-size:12px; background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.2); color:#fff; cursor:pointer; touch-action:manipulation;">
                        ปิดหน้าต่าง
                    </button>
                </div>
            </div>
        `;

        modal.style.display = 'flex';
        modal.classList.add('active');

        // ผูก Event ปิดสำหรับ Touch และ Click บน Android / iOS
        const doClose = (e) => {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            window.closeInGamePlayerInspectModal();
        };

        const btnX = modal.querySelector('#btn-inspect-close-x');
        if (btnX) {
            btnX.onclick = doClose;
            btnX.ontouchend = doClose;
        }

        const btnAction = modal.querySelector('#btn-inspect-close-action');
        if (btnAction) {
            btnAction.onclick = doClose;
            btnAction.ontouchend = doClose;
        }

        modal.onclick = (e) => {
            if (e.target === modal) doClose(e);
        };
        modal.ontouchend = (e) => {
            if (e.target === modal) doClose(e);
        };

        if (typeof window.openModal === 'function') {
            window.openModal('modal-ingame-player-inspect');
        }
        modal.style.display = 'flex';
    }

    clearAllCities3D() {
        const prevCityKeys = Object.keys(this.cityStates || {});
        this.cityStates = {};
        this.cityMeshes = {};
        if (this.isMonopolyBoardMode && typeof this.refreshSingleTileTexture === 'function') {
            prevCityKeys.forEach(k => this.refreshSingleTileTexture(Number(k)));
        }
        if (this.citiesGroup) {
            while (this.citiesGroup.children.length > 0) {
                this.citiesGroup.remove(this.citiesGroup.children[0]);
            }
        }
        if (this.lineMonopolyAuraGroup) {
            this.effectsGroup.remove(this.lineMonopolyAuraGroup);
            this.lineMonopolyAuraGroup = null;
        }
        this.clearMonopolyColorVictoryAura();
        this._activeLineWaveTiles = [];
        this._lineMonopolyTriggered = false;
        this._tripleColorVictoryTriggered = false;
        this._oneAwayWarnedThisTurn = false;
        this._lastMonopolyVictoryWarnKey = null;
    }

    rebuildAllCities3D() {
        if (!this.citiesGroup) return;
        while (this.citiesGroup.children.length > 0) {
            this.citiesGroup.remove(this.citiesGroup.children[0]);
        }
        this.cityMeshes = {};
        for (const tileKey of Object.keys(this.cityStates)) {
            const tNum = Number(tileKey);
            if (this.cityStates[tNum]) {
                this.rebuildTileCity3D(tNum);
            }
        }
    }

    getCityFacadeMaterials(ownerColor, styleType = 'villa') {
        if (!this.cityFacadeMatCache) this.cityFacadeMatCache = {};
        const hex = '#' + (Number(ownerColor) || 0x00e5ff).toString(16).padStart(6, '0');
        const key = `${hex}_${styleType}`;
        if (this.cityFacadeMatCache[key]) return this.cityFacadeMatCache[key];

        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');

        const emCanvas = document.createElement('canvas');
        emCanvas.width = 256;
        emCanvas.height = 256;
        const emCtx = emCanvas.getContext('2d');
        emCtx.fillStyle = '#000000';
        emCtx.fillRect(0, 0, 256, 256);

        const drawLitWindow = (x, y, w, h, mainCol = '#fef08a', glowCol = '#f59e0b') => {
            // กรอบหน้าต่างบนพื้นผิวหลัก
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(x - 3, y - 3, w + 6, h + 6);
            const grad = ctx.createLinearGradient(x, y, x, y + h);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.35, mainCol);
            grad.addColorStop(1, glowCol);
            ctx.fillStyle = grad;
            ctx.fillRect(x, y, w, h);

            // เส้นแบ่งกระจก
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.45)';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, w, h);
            if (w >= 26) {
                ctx.beginPath();
                ctx.moveTo(x + w / 2, y);
                ctx.lineTo(x + w / 2, y + h);
                ctx.stroke();
            }

            // แผนที่เรืองแสง (Emissive)
            emCtx.shadowColor = glowCol;
            emCtx.shadowBlur = 10;
            emCtx.fillStyle = mainCol;
            emCtx.fillRect(x, y, w, h);
            emCtx.shadowBlur = 0;
        };

        if (styleType === 'villa') {
            // ผนังวิลล่าหรูสีครีมมุก + แถบบัวสีเจ้าของเมือง + ซุ้มประตูทอง
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#fffbeb');
            wallGrad.addColorStop(1, '#e2e8f0');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // แถบบัวบน-ล่างสีผู้เล่นและทองคำ
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 26);
            ctx.fillRect(0, 232, 256, 24);
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 24, 256, 7);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 4, 256, 12);

            // หน้าต่างวิลล่าส่องสว่างอบอุ่นซ้าย-ขวา
            drawLitWindow(28, 68, 62, 74, '#fef08a', '#f59e0b');
            drawLitWindow(166, 68, 62, 74, '#fef08a', '#f59e0b');

            // ประตูซุ้มโค้งทองคำตรงกลาง
            ctx.fillStyle = '#b45309';
            ctx.beginPath();
            ctx.roundRect(104, 118, 48, 114, [24, 24, 0, 0]);
            ctx.fill();
            ctx.fillStyle = '#fde047';
            ctx.beginPath();
            ctx.roundRect(111, 126, 34, 106, [18, 18, 0, 0]);
            ctx.fill();
            emCtx.fillStyle = '#fbbf24';
            emCtx.beginPath();
            emCtx.roundRect(113, 128, 30, 100, [16, 16, 0, 0]);
            emCtx.fill();
        } else if (styleType === 'mansion') {
            // คอนโด/แมนชั่น 2 ชั้นสไตล์ยุโรปโมเดิร์น
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#f8fafc');
            wallGrad.addColorStop(1, '#cbd5e1');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // แถบไฟนีออนคาดกลางตึก & ขอบบน
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 22);
            ctx.fillRect(0, 118, 256, 18);
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 20, 256, 6);
            ctx.fillRect(0, 134, 256, 6);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 4, 256, 10);
            emCtx.fillRect(0, 121, 256, 10);

            // หน้าต่างชั้นบน 3 บาน + ชั้นล่าง 2 บาน + ล็อบบี้กลาง
            const cols = [24, 103, 182];
            cols.forEach(cx => drawLitWindow(cx, 44, 50, 56, '#fef08a', '#f59e0b'));
            drawLitWindow(24, 156, 54, 62, '#bae6fd', '#0284c7');
            drawLitWindow(178, 156, 54, 62, '#bae6fd', '#0284c7');
            drawLitWindow(103, 152, 50, 88, '#fde047', '#d97706');
        } else if (styleType === 'hotel') {
            // โรงแรมแกรนด์ทาวเวอร์ 5 ดาว (กระจกสีน้ำเงินเข้มตัดทองและไฟห้องสูทระยิบระยับ)
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#0f172a');
            wallGrad.addColorStop(0.5, '#1e293b');
            wallGrad.addColorStop(1, '#0f172a');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // เสาคิ้วทองคำแนวตั้งซ้าย-ขวา
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 0, 14, 256);
            ctx.fillRect(242, 0, 14, 256);
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 22);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 2, 256, 16);

            // ตารางห้องพัก VIP 4 ชั้น x 3 คอลัมน์
            const xs = [28, 102, 176];
            const ys = [34, 82, 130, 178];
            ys.forEach((yy, rIdx) => {
                xs.forEach((xx, cIdx) => {
                    if (rIdx === 3 && cIdx === 1) {
                        // โถงทางเข้าโรงแรมหรูสีทองสว่าง
                        drawLitWindow(xx - 4, yy, 60, 72, '#fde047', '#f59e0b');
                    } else {
                        const isWarm = (rIdx + cIdx) % 2 === 0;
                        drawLitWindow(
                            xx,
                            yy,
                            52,
                            34,
                            isWarm ? '#fef08a' : '#7dd3fc',
                            isWarm ? '#f59e0b' : '#0ea5e9'
                        );
                    }
                });
            });
        } else {
            // อาคารระฟ้าแลนด์มาร์ค (Crystal / Twin Tower)
            ctx.fillStyle = '#091124';
            ctx.fillRect(0, 0, 256, 256);
            ctx.fillStyle = '#ffd700';
            ctx.fillRect(0, 0, 12, 256);
            ctx.fillRect(244, 0, 12, 256);
            ctx.fillRect(122, 0, 12, 256);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 0, 256, 18);
            emCtx.fillRect(124, 0, 8, 256);

            for (let r = 0; r < 5; r++) {
                for (let c = 0; c < 4; c++) {
                    const wx = 22 + c * 56;
                    const wy = 28 + r * 44;
                    const goldWin = (r + c) % 2 === 0;
                    drawLitWindow(
                        wx,
                        wy,
                        36,
                        26,
                        goldWin ? '#fde047' : '#a5f3fc',
                        goldWin ? '#f59e0b' : hex
                    );
                }
            }
        }

        const mapTex = new THREE.CanvasTexture(canvas);
        const emTex = new THREE.CanvasTexture(emCanvas);
        mapTex.anisotropy = 4;
        emTex.anisotropy = 4;

        const mat = new THREE.MeshStandardMaterial({
            map: mapTex,
            emissive: 0xffffff,
            emissiveMap: emTex,
            emissiveIntensity: styleType === 'landmark' ? 0.95 : 0.8,
            roughness: 0.24,
            metalness: styleType === 'hotel' || styleType === 'landmark' ? 0.45 : 0.18
        });

        this.cityFacadeMatCache[key] = mat;
        return mat;
    }

    createCityLabelSprite(tollText, badgeText, ownerHexColor, isLandmark = false, multiplier = 1, isSuperLandmark = false) {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 156;
        const ctx = canvas.getContext('2d');

        const isBoosted = multiplier > 1;
        const borderCol = isSuperLandmark ? '#f43f5e' : (isBoosted ? '#ec4899' : (isLandmark ? '#ffd700' : ownerHexColor));

        // เงาเรืองแสงรอบป้ายลอย (Compact Pill ไม่บังหลังคาตึก)
        ctx.save();
        ctx.shadowColor = isSuperLandmark ? '#ff0055' : (isLandmark ? '#fbbf24' : ownerHexColor);
        ctx.shadowBlur = isSuperLandmark ? 26 : 18;
        const bgGrad = ctx.createLinearGradient(24, 14, 488, 120);
        if (isSuperLandmark) {
            bgGrad.addColorStop(0, 'rgba(48, 10, 36, 0.96)');
            bgGrad.addColorStop(0.5, 'rgba(88, 15, 60, 0.96)');
            bgGrad.addColorStop(1, 'rgba(48, 10, 36, 0.96)');
        } else if (isLandmark) {
            bgGrad.addColorStop(0, 'rgba(24, 16, 48, 0.94)');
            bgGrad.addColorStop(0.5, 'rgba(45, 22, 74, 0.94)');
            bgGrad.addColorStop(1, 'rgba(24, 16, 48, 0.94)');
        } else {
            bgGrad.addColorStop(0, 'rgba(8, 15, 32, 0.92)');
            bgGrad.addColorStop(1, 'rgba(15, 28, 54, 0.92)');
        }
        ctx.fillStyle = bgGrad;
        ctx.strokeStyle = borderCol;
        ctx.lineWidth = isSuperLandmark ? 7.5 : 6;
        ctx.beginPath();
        ctx.roundRect(24, 14, 464, 106, 53);
        ctx.fill();
        ctx.stroke();

        // หมุดสามเหลี่ยมชี้ลงยอดตึกด้านล่างป้าย
        ctx.beginPath();
        ctx.moveTo(238, 120);
        ctx.lineTo(256, 144);
        ctx.lineTo(274, 120);
        ctx.closePath();
        ctx.fillStyle = borderCol;
        ctx.fill();
        ctx.restore();

        // เส้นขอบทองด้านในสำหรับแลนด์มาร์ค
        if (isSuperLandmark || isLandmark) {
            ctx.strokeStyle = isSuperLandmark ? 'rgba(255, 110, 199, 0.85)' : 'rgba(253, 224, 71, 0.55)';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.roundRect(33, 23, 446, 88, 44);
            ctx.stroke();
        }

        // เหรียญป้ายระดับเมือง / ตัวคูณด้านซ้าย
        if (badgeText) {
            const pillW = badgeText.length > 7 ? 196 : 168;
            const pillGrad = ctx.createLinearGradient(36, 28, 36 + pillW, 106);
            if (isSuperLandmark) {
                pillGrad.addColorStop(0, '#ff007f');
                pillGrad.addColorStop(1, '#ffd700');
            } else if (isBoosted) {
                pillGrad.addColorStop(0, '#ec4899');
                pillGrad.addColorStop(1, '#f59e0b');
            } else if (isLandmark) {
                pillGrad.addColorStop(0, '#fde047');
                pillGrad.addColorStop(1, '#d97706');
            } else {
                pillGrad.addColorStop(0, ownerHexColor);
                pillGrad.addColorStop(1, '#e2e8f0');
            }
            ctx.fillStyle = pillGrad;
            ctx.beginPath();
            ctx.roundRect(36, 28, pillW, 78, 39);
            ctx.fill();

            ctx.fillStyle = (isSuperLandmark || isBoosted) ? '#ffffff' : '#090d16';
            const badgeFontPx = badgeText.length > 9 ? 24 : (badgeText.length > 6 ? 28 : 34);
            ctx.font = `900 ${badgeFontPx}px Kanit, sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(badgeText, 36 + pillW / 2, 68);

            // ตัวเลขค่าผ่านทางขนาดใหญ่คมชัดทางขวา
            ctx.fillStyle = isSuperLandmark ? '#fde047' : '#fef08a';
            ctx.shadowColor = isSuperLandmark ? 'rgba(255, 0, 128, 0.95)' : 'rgba(245, 158, 11, 0.85)';
            ctx.shadowBlur = 12;
            ctx.font = '900 44px Kanit, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(tollText, 468, 58);
            ctx.shadowBlur = 0;

            ctx.fillStyle = isSuperLandmark ? '#fbcfe8' : (isLandmark ? '#fda4af' : '#93c5fd');
            ctx.font = '700 22px Kanit, sans-serif';
            ctx.fillText(isSuperLandmark ? '👑 ซุปเปอร์แลนด์มาร์ค' : (isLandmark ? '🏛️ แลนด์มาร์ค (ห้ามซื้อต่อ)' : '💰 ค่าผ่านทาง'), 462, 95);
        } else {
            ctx.fillStyle = '#fde047';
            ctx.font = '900 52px Kanit, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(tollText, 256, 68);
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.anisotropy = 4;
        const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
        const sprite = new THREE.Sprite(mat);
        sprite.scale.set(4.35, 1.32, 1);
        sprite.renderOrder = 28;
        return sprite;
    }

    rebuildTileCity3D(tileNum) {
        const t = Number(tileNum);
        if (this.cityMeshes[t]) {
            this.citiesGroup.remove(this.cityMeshes[t]);
            delete this.cityMeshes[t];
        }
        const st = this.cityStates[t];
        const pos = this.tiles[t];
        if (!st || !pos) return;

        const group = new THREE.Group();
        group.position.set(pos.x, pos.y, pos.z);

        const ownerColor = Number(st.color) || 0x00e5ff;
        const ownerHex = '#' + ownerColor.toString(16).padStart(6, '0');
        const isLM = Boolean(st.isLandmark);
        const isSLM = Boolean(st.isSuperLandmark);
        const colorSetBonus = this.hasMonopolyColorSetBonus(t) ? 2 : 1;
        const presetSpecialMult = Number(this.monopolyTilesList?.[t - 1]?.special_multiplier || 0);
        const baseMult = Math.max(1, Number(st.multiplier) || 1, presetSpecialMult || 1);
        const mult = baseMult * colorSetBonus;
        if (typeof this.refreshSingleTileTexture === 'function') {
            this.refreshSingleTileTexture(t);
        }

        const animData = {
            phase: (t * 0.67) % (Math.PI * 2),
            buildProgress: 0,
            rotatingHalo: null,
            rotatingHalo2: null,
            floatingCrest: null,
            crestBaseY: 0,
            beamMesh: null,
            beacons: []
        };

        // 1. พื้นอาณาเขตโปร่งแสง + กรอบนีออน 3D ล้อมรอบช่องจังหวัด + เสาคริสตัล 4 มุม
        const innerSpan = this.tileSize - 0.16;
        const floorPad = new THREE.Mesh(
            new THREE.BoxGeometry(innerSpan, 0.08, innerSpan),
            new THREE.MeshStandardMaterial({
                color: isSLM ? 0xff007f : ownerColor,
                emissive: isSLM ? 0xff007f : ownerColor,
                emissiveIntensity: isSLM ? 0.95 : (isLM ? 0.7 : 0.42),
                transparent: true,
                opacity: isSLM ? 0.45 : (isLM ? 0.34 : 0.2)
            })
        );
        floorPad.position.y = 0.05;
        group.add(floorPad);

        // รางขอบนีออน 4 ด้านสีผู้เล่นสว่างคมชัด (หากเป็นซุปเปอร์แลนด์มาร์คจะมีรางขอบสีชมพูทองนีออนสุดอลังการ)
        const railThick = isSLM ? 0.26 : (isLM ? 0.22 : 0.17);
        const railHeight = isSLM ? 0.32 : (isLM ? 0.26 : 0.19);
        const halfSpan = innerSpan / 2 - railThick / 2;
        const railMat = new THREE.MeshStandardMaterial({
            color: isSLM ? 0xff007f : ownerColor,
            emissive: isSLM ? 0xff007f : ownerColor,
            emissiveIntensity: isSLM ? 1.45 : (isLM ? 1.15 : 0.85),
            metalness: 0.45,
            roughness: 0.18
        });
        const nsGeo = new THREE.BoxGeometry(innerSpan, railHeight, railThick);
        const ewGeo = new THREE.BoxGeometry(railThick, railHeight, innerSpan - railThick * 2);

        const northRail = new THREE.Mesh(nsGeo, railMat);
        northRail.position.set(0, railHeight / 2 + 0.04, -halfSpan);
        const southRail = new THREE.Mesh(nsGeo, railMat);
        southRail.position.set(0, railHeight / 2 + 0.04, halfSpan);
        const westRail = new THREE.Mesh(ewGeo, railMat);
        westRail.position.set(-halfSpan, railHeight / 2 + 0.04, 0);
        const eastRail = new THREE.Mesh(ewGeo, railMat);
        eastRail.position.set(halfSpan, railHeight / 2 + 0.04, 0);
        group.add(northRail, southRail, westRail, eastRail);

        // เสาไฟคริสตัลประดับ 4 มุมช่องจังหวัด
        const cornerCoord = halfSpan - 0.04;
        const postMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            emissive: 0xf59e0b,
            emissiveIntensity: 0.55,
            metalness: 0.85,
            roughness: 0.15
        });
        const gemMat = new THREE.MeshStandardMaterial({
            color: isLM ? 0xffe066 : 0xffffff,
            emissive: isLM ? 0xffb703 : ownerColor,
            emissiveIntensity: 1.1,
            metalness: 0.3,
            roughness: 0.1
        });
        const corners = [
            [-cornerCoord, -cornerCoord],
            [cornerCoord, -cornerCoord],
            [-cornerCoord, cornerCoord],
            [cornerCoord, cornerCoord]
        ];
        corners.forEach(([cx, cz]) => {
            const post = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, isLM ? 0.52 : 0.36, 6), postMat);
            post.position.set(cx, (isLM ? 0.26 : 0.18) + 0.05, cz);
            group.add(post);

            const gem = new THREE.Mesh(new THREE.OctahedronGeometry(isLM ? 0.24 : 0.17), gemMat.clone());
            gem.position.set(cx, (isLM ? 0.68 : 0.48), cz);
            group.add(gem);
            animData.beacons.push(gem);
        });

        // Shared luxury materials
        const goldMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            emissive: 0xf59e0b,
            emissiveIntensity: 0.55,
            metalness: 0.88,
            roughness: 0.14
        });
        const ownerRoofMat = new THREE.MeshStandardMaterial({
            color: ownerColor,
            emissive: ownerColor,
            emissiveIntensity: 0.62,
            metalness: 0.38,
            roughness: 0.2
        });
        const marbleMat = new THREE.MeshStandardMaterial({
            color: 0xf8fafc,
            emissive: 0xe2e8f0,
            emissiveIntensity: 0.18,
            roughness: 0.22,
            metalness: 0.15
        });
        const gardenMat = new THREE.MeshStandardMaterial({
            color: 0x10b981,
            emissive: 0x059669,
            emissiveIntensity: 0.35,
            roughness: 0.45
        });

        let labelHeightY = 4.2;

        if (!isLM) {
            // 2. โซนสถาปัตยกรรมเมือง 1 - 3 เมือง สไตล์กระดาน 3D 3D (วิลล่าหรู -> คอนโด 2 ชั้น -> โรงแรมแกรนด์ทาวเวอร์)
            const count = Math.max(1, Math.min(3, Number(st.level) || 1));

            // ฐานลานพลาซ่ายกระดับด้านบนของช่อง (ไม่ทับตัวเดินและชื่อจังหวัด)
            const terraceW = count === 1 ? 2.55 : (count === 2 ? 4.45 : 5.55);
            const terraceBase = new THREE.Mesh(new THREE.BoxGeometry(terraceW, 0.24, 2.25), marbleMat);
            terraceBase.position.set(0, 0.16, -1.55);
            terraceBase.castShadow = true;
            group.add(terraceBase);

            const terraceLawn = new THREE.Mesh(new THREE.BoxGeometry(terraceW - 0.18, 0.08, 2.05), gardenMat);
            terraceLawn.position.set(0, 0.30, -1.55);
            group.add(terraceLawn);

            const xSlots = count === 1 ? [0] : (count === 2 ? [-1.28, 1.28] : [-1.85, -0.05, 1.80]);

            for (let i = 0; i < count; i++) {
                const bld = new THREE.Group();

                if (i === 0) {
                    // หลังที่ 1: 🏡 วิลล่าหรูหลังคาทรงปั้นหยา + ซุ้มมุกหน้าบ้าน + ยอดทอง
                    const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.22, 1.48), goldMat);
                    plinth.position.y = 0.42;
                    bld.add(plinth);

                    const villaMat = this.getCityFacadeMaterials(ownerColor, 'villa');
                    const body = new THREE.Mesh(new THREE.BoxGeometry(1.38, 1.55, 1.30), villaMat);
                    body.position.y = 1.30;
                    body.castShadow = true;
                    bld.add(body);

                    // กันสาดซุ้มประตูหน้าบ้าน
                    const awning = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.14, 0.36), ownerRoofMat);
                    awning.position.set(0, 1.18, 0.72);
                    bld.add(awning);

                    // บัวทองรองรับหลังคา
                    const eaves = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.12, 1.54), goldMat);
                    eaves.position.y = 2.12;
                    bld.add(eaves);

                    // หลังคาสีผู้เล่นสดใสเด่นชัด
                    const roof = new THREE.Mesh(new THREE.ConeGeometry(1.18, 1.05, 4), ownerRoofMat);
                    roof.rotation.y = Math.PI / 4;
                    roof.position.y = 2.70;
                    roof.castShadow = true;
                    bld.add(roof);

                    // ยอดฉัตรลูกแก้วทองคำบนหลังคา
                    const finial = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), goldMat);
                    finial.position.y = 3.26;
                    bld.add(finial);

                    if (count === 1) {
                        bld.scale.set(1.14, 1.14, 1.14);
                    }
                } else if (i === 1) {
                    // หลังที่ 2: 🏘️ คอนโดบูทีคแมนชั่น 2 ชั้น พร้อมระเบียงทองคำรอบตัวตึก
                    const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.60, 0.24, 1.52), goldMat);
                    plinth.position.y = 0.43;
                    bld.add(plinth);

                    const mansionMat = this.getCityFacadeMaterials(ownerColor, 'mansion');
                    const body = new THREE.Mesh(new THREE.BoxGeometry(1.42, 2.32, 1.34), mansionMat);
                    body.position.y = 1.70;
                    body.castShadow = true;
                    bld.add(body);

                    // ระเบียงทองคำคั่นชั้น 1 และชั้น 2
                    const balcony = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.15, 1.54), goldMat);
                    balcony.position.y = 1.68;
                    bld.add(balcony);

                    // หลังคาแมนซาร์ด 2 ชั้นสีผู้เล่น + ยอดเพชรทอง
                    const roofBase = new THREE.Mesh(new THREE.ConeGeometry(1.22, 0.92, 4), ownerRoofMat);
                    roofBase.rotation.y = Math.PI / 4;
                    roofBase.position.y = 3.30;
                    roofBase.castShadow = true;
                    bld.add(roofBase);

                    const spire = new THREE.Mesh(new THREE.OctahedronGeometry(0.22), goldMat);
                    spire.position.y = 3.88;
                    bld.add(spire);
                } else {
                    // หลังที่ 3: 🏨 โรงแรมแกรนด์ทาวเวอร์ 5 ดาว (ตึกสูงระฟ้า + โดมเพนท์เฮาส์ทองคำ)
                    const podium = new THREE.Mesh(new THREE.BoxGeometry(1.70, 0.30, 1.60), ownerRoofMat);
                    podium.position.y = 0.46;
                    bld.add(podium);

                    const podiumTrim = new THREE.Mesh(new THREE.BoxGeometry(1.76, 0.09, 1.66), goldMat);
                    podiumTrim.position.y = 0.64;
                    bld.add(podiumTrim);

                    const hotelMat = this.getCityFacadeMaterials(ownerColor, 'hotel');
                    const tower = new THREE.Mesh(new THREE.BoxGeometry(1.48, 3.25, 1.38), hotelMat);
                    tower.position.y = 2.28;
                    tower.castShadow = true;
                    bld.add(tower);

                    // มงกุฎนีออนยอดตึกโรงแรม
                    const crownLedge = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.22, 1.56), ownerRoofMat);
                    crownLedge.position.y = 4.00;
                    bld.add(crownLedge);

                    const goldCornice = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.10, 1.62), goldMat);
                    goldCornice.position.y = 4.16;
                    bld.add(goldCornice);

                    // โดมเพนท์เฮาส์ทองคำ + เสาอากาศคริสตัล
                    const dome = new THREE.Mesh(
                        new THREE.SphereGeometry(0.56, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2),
                        goldMat
                    );
                    dome.position.y = 4.20;
                    bld.add(dome);

                    const needle = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.72, 8), goldMat);
                    needle.position.y = 4.96;
                    bld.add(needle);
                }

                bld.position.set(xSlots[i], 0, -1.55);
                group.add(bld);
            }

            // หากสร้างครบ 3 เมือง เพิ่มวงแหวนออร่าสีทองหมุนรอบฐาน เพื่อบอกว่าพร้อมอัปเกรดเป็นแลนด์มาร์ค!
            if (count === 3) {
                const readyHalo = new THREE.Mesh(
                    new THREE.TorusGeometry(2.55, 0.06, 10, 36),
                    new THREE.MeshBasicMaterial({ color: 0xfde047, transparent: true, opacity: 0.85 })
                );
                readyHalo.rotation.x = Math.PI / 2;
                readyHalo.position.set(0, 0.42, -1.45);
                group.add(readyHalo);
                animData.rotatingHalo = readyHalo;
            }

            labelHeightY = count === 1 ? 4.35 : (count === 2 ? 4.75 : 5.75);
        } else {
            // 3. 🏛️ โมเดล 3D แลนด์มาร์คระดับตำนาน 6 สถาปัตยกรรม + เสาแสงสวรรค์ + วงแหวนเวทย์หมุน + มงกุฎเพชรลอยตัว
            const lm = new THREE.Group();
            lm.position.set(0, 0, -1.30);

            // ลำแสงออร่าแนวตั้งส่องสว่างเห็นเด่นทั่วทั้งกระดาน
            const beamGeo = new THREE.CylinderGeometry(isSLM ? 1.45 : 1.25, isSLM ? 2.25 : 1.95, isSLM ? 11.5 : 9.2, 24, 1, true);
            const beamMat = new THREE.MeshBasicMaterial({
                color: isSLM ? 0xff007f : (mult > 1 ? 0xf43f5e : ownerColor),
                transparent: true,
                opacity: isSLM ? 0.28 : 0.18,
                side: THREE.DoubleSide,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const beam = new THREE.Mesh(beamGeo, beamMat);
            beam.position.y = isSLM ? 5.85 : 4.65;
            // lm.add(beam); // ปิดแท่งแสงสีฟ้าครอบแลนด์มาร์ค ให้เห็นสถาปัตยกรรม 3D ชัดเจน
            // animData.beamMesh = beam;

            // แท่นอนุสาวรีย์แกรนด์พลาซ่า 3 ชั้น (หินอ่อน + สีผู้เล่นเรืองแสง + ทองคำ 24K)
            const baseStep1 = new THREE.Mesh(new THREE.BoxGeometry(4.45, 0.34, 2.75), marbleMat);
            baseStep1.position.y = 0.22;
            lm.add(baseStep1);

            const baseStep2 = new THREE.Mesh(new THREE.BoxGeometry(3.85, 0.38, 2.35), ownerRoofMat);
            baseStep2.position.y = 0.56;
            lm.add(baseStep2);

            const baseStep3 = new THREE.Mesh(new THREE.BoxGeometry(3.15, 0.32, 1.95), goldMat);
            baseStep3.position.y = 0.90;
            lm.add(baseStep3);

            // วงแหวนเวทย์ทองคำหมุนรอบแลนด์มาร์ค + วงแหวนพลังงานสีเจ้าของ
            const halo1 = new THREE.Mesh(
                new THREE.TorusGeometry(2.18, 0.085, 12, 42),
                new THREE.MeshBasicMaterial({ color: 0xffd700 })
            );
            halo1.rotation.x = Math.PI / 2;
            halo1.position.y = 0.72;
            lm.add(halo1);
            animData.rotatingHalo = halo1;

            const halo2 = new THREE.Mesh(
                new THREE.TorusGeometry(1.55, 0.065, 10, 36),
                new THREE.MeshBasicMaterial({ color: mult > 1 ? 0xff4d94 : ownerColor })
            );
            halo2.rotation.x = Math.PI / 2;
            halo2.position.y = 2.85;
            lm.add(halo2);
            animData.rotatingHalo2 = halo2;

            const lmFacadeMat = this.getCityFacadeMaterials(ownerColor, 'landmark');
            const crimsonRoofMat = new THREE.MeshStandardMaterial({
                color: 0xdc2626,
                emissive: 0xb91c1c,
                emissiveIntensity: 0.48,
                metalness: 0.4,
                roughness: 0.2
            });

            let crestY = 6.15;
            const archType = t % 6;

            if (archType === 0) {
                // แบบที่ 1: มหาปราสาทศาลาไทยทองคำจตุรมุข (Royal Thai Golden Palace)
                const hall = new THREE.Mesh(new THREE.BoxGeometry(2.45, 1.65, 1.55), this.getCityFacadeMaterials(ownerColor, 'villa'));
                hall.position.y = 1.88;
                lm.add(hall);

                const tier1 = new THREE.Mesh(new THREE.ConeGeometry(2.05, 1.0, 4), crimsonRoofMat);
                tier1.rotation.y = Math.PI / 4;
                tier1.position.y = 3.12;
                lm.add(tier1);

                const tierGold1 = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.16, 1.35), goldMat);
                tierGold1.position.y = 3.55;
                lm.add(tierGold1);

                const tier2 = new THREE.Mesh(new THREE.ConeGeometry(1.45, 0.92, 4), ownerRoofMat);
                tier2.rotation.y = Math.PI / 4;
                tier2.position.y = 4.05;
                lm.add(tier2);

                const spire = new THREE.Mesh(new THREE.ConeGeometry(0.52, 2.05, 12), goldMat);
                spire.position.y = 5.25;
                lm.add(spire);

                // ยอดมณฑปเล็ก 4 มุม
                [[-1.25, -0.68], [1.25, -0.68], [-1.25, 0.68], [1.25, 0.68]].forEach(([mx, mz]) => {
                    const miniSpire = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.95, 8), goldMat);
                    miniSpire.position.set(mx, 1.52, mz);
                    lm.add(miniSpire);
                });
                crestY = 6.55;
            } else if (archType === 1) {
                // แบบที่ 2: มหาเสาอนุสาวรีย์จักรพรรดิยอดเพชรสุริยะ (Imperial Sun Obelisk)
                const pedestal = new THREE.Mesh(new THREE.BoxGeometry(1.85, 1.15, 1.45), lmFacadeMat);
                pedestal.position.y = 1.62;
                lm.add(pedestal);

                const obelisk = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.78, 3.65, 4), marbleMat);
                obelisk.rotation.y = Math.PI / 4;
                obelisk.position.y = 3.95;
                lm.add(obelisk);
                [2.5, 3.6, 4.7].forEach(ry => {
                    const band = new THREE.Mesh(new THREE.BoxGeometry(0.95 - (ry - 2.5) * 0.18, 0.14, 0.95 - (ry - 2.5) * 0.18), goldMat);
                    band.position.y = ry;
                    lm.add(band);
                });

                const pyramidion = new THREE.Mesh(new THREE.ConeGeometry(0.48, 0.85, 4), goldMat);
                pyramidion.rotation.y = Math.PI / 4;
                pyramidion.position.y = 6.05;
                lm.add(pyramidion);
                crestY = 6.75;
            } else if (archType === 2) {
                // แบบที่ 3: ตึกระฟ้าคริสตัลเอ็มไพร์ 101 (Crystal Empire Skyscraper)
                const seg1 = new THREE.Mesh(new THREE.BoxGeometry(2.05, 1.65, 1.55), lmFacadeMat);
                seg1.position.y = 1.88;
                lm.add(seg1);

                const trim1 = new THREE.Mesh(new THREE.BoxGeometry(2.25, 0.18, 1.72), goldMat);
                trim1.position.y = 2.78;
                lm.add(trim1);

                const seg2 = new THREE.Mesh(new THREE.BoxGeometry(1.62, 1.55, 1.28), lmFacadeMat);
                seg2.position.y = 3.62;
                lm.add(seg2);

                const trim2 = new THREE.Mesh(new THREE.BoxGeometry(1.82, 0.16, 1.45), ownerRoofMat);
                trim2.position.y = 4.46;
                lm.add(trim2);

                const seg3 = new THREE.Mesh(new THREE.BoxGeometry(1.12, 1.15, 0.98), lmFacadeMat);
                seg3.position.y = 5.10;
                lm.add(seg3);

                const spire = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.25, 8), goldMat);
                spire.position.y = 6.22;
                lm.add(spire);
                crestY = 7.0;
            } else if (archType === 3) {
                // แบบที่ 4: พระมหาเจดีย์ทองคำรัตนโกสินทร์ 5 ยอด (5-Spire Golden Stupa)
                const terrace = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.62, 0.65, 16), ownerRoofMat);
                terrace.position.y = 1.38;
                lm.add(terrace);

                const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 1.22, 1.95, 20), goldMat);
                bell.position.y = 2.65;
                lm.add(bell);

                const harmika = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.34, 0.82), ownerRoofMat);
                harmika.position.y = 3.72;
                lm.add(harmika);

                const chatraSpire = new THREE.Mesh(new THREE.ConeGeometry(0.48, 2.35, 16), goldMat);
                chatraSpire.position.y = 5.02;
                lm.add(chatraSpire);

                [[-1.25, -0.68], [1.25, -0.68], [-1.25, 0.68], [1.25, 0.68]].forEach(([cx, cz]) => {
                    const subStupa = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.35, 10), goldMat);
                    subStupa.position.set(cx, 1.72, cz);
                    lm.add(subStupa);
                });
                crestY = 6.48;
            } else if (archType === 4) {
                // แบบที่ 5: ตึกแฝดสกายบริดจ์มหานคร (Twin Luxury Towers & Sky-Bridge)
                [-0.95, 0.95].forEach(tx => {
                    const tw = new THREE.Mesh(new THREE.BoxGeometry(1.18, 4.15, 1.28), lmFacadeMat);
                    tw.position.set(tx, 3.12, 0);
                    lm.add(tw);

                    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.76, 0.95, 4), ownerRoofMat);
                    cap.rotation.y = Math.PI / 4;
                    cap.position.set(tx, 5.65, 0);
                    lm.add(cap);

                    const pin = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.65, 8), goldMat);
                    pin.position.set(tx, 6.32, 0);
                    lm.add(pin);
                });

                // สะพานลอยฟ้าเชื่อมตึกแฝด + ลูกแก้วพลังงานตรงกลาง
                const bridge = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.42, 0.78), goldMat);
                bridge.position.set(0, 3.85, 0);
                lm.add(bridge);

                const bridgeCore = new THREE.Mesh(new THREE.SphereGeometry(0.36, 16, 16), ownerRoofMat);
                bridgeCore.position.set(0, 4.35, 0);
                lm.add(bridgeCore);
                crestY = 6.65;
            } else {
                // แบบที่ 6: มหาวิหารโดมเพชรราชันย์ (Royal Diamond Pantheon Dome)
                const hall = new THREE.Mesh(new THREE.BoxGeometry(2.55, 1.85, 1.65), this.getCityFacadeMaterials(ownerColor, 'mansion'));
                hall.position.y = 1.98;
                lm.add(hall);

                // เสาโรมันด้านหน้า 4 ต้น
                [-0.95, -0.32, 0.32, 0.95].forEach(px => {
                    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 1.85, 10), goldMat);
                    col.position.set(px, 1.98, 0.88);
                    lm.add(col);
                });

                const drum = new THREE.Mesh(new THREE.CylinderGeometry(1.18, 1.28, 0.65, 20), ownerRoofMat);
                drum.position.y = 3.18;
                lm.add(drum);

                const dome = new THREE.Mesh(
                    new THREE.SphereGeometry(1.18, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2),
                    goldMat
                );
                dome.position.y = 3.48;
                lm.add(dome);

                const lantern = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.35, 10), goldMat);
                lantern.position.y = 5.25;
                lm.add(lantern);
                crestY = 6.25;
            }

            // เพชรราชันย์ลอยตัวหมุนส่องประกายเหนือยอดแลนด์มาร์ค / ซุปเปอร์แลนด์มาร์ค
            const crestGroup = new THREE.Group();
            const crestScale = isSLM ? 1.45 : 1.25;
            const diamond = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.42 * crestScale),
                new THREE.MeshStandardMaterial({
                    color: isSLM ? 0xff4d94 : (mult > 1 ? 0xff4d94 : 0xfffbeb),
                    emissive: isSLM ? 0xff007f : (mult > 1 ? 0xf43f5e : 0xffd700),
                    emissiveIntensity: isSLM ? 1.6 : 1.3,
                    metalness: 0.65,
                    roughness: 0.08
                })
            );
            const crestRing = new THREE.Mesh(
                new THREE.TorusGeometry(0.62 * crestScale, 0.065, 10, 32),
                new THREE.MeshBasicMaterial({ color: isSLM ? 0xff4d94 : 0xffd700 })
            );
            crestGroup.add(diamond, crestRing);
            if (isSLM) {
                const crestRing2 = new THREE.Mesh(
                    new THREE.TorusGeometry(0.78 * crestScale, 0.045, 10, 32),
                    new THREE.MeshBasicMaterial({ color: 0xffd700 })
                );
                crestRing2.rotation.x = Math.PI / 2.2;
                crestGroup.add(crestRing2);
            }
            crestGroup.position.set(0, crestY + 0.15, 0);
            lm.add(crestGroup);

            // วงแหวนฐานแลนด์มาร์ค / ซุปเปอร์แลนด์มาร์ค ให้เห็นเด่นชัดบนกระดาน
            const lmBaseRing = new THREE.Mesh(
                new THREE.RingGeometry(isSLM ? 2.15 : 2.05, isSLM ? 2.65 : 2.42, 36),
                new THREE.MeshBasicMaterial({
                    color: isSLM ? 0xff007f : 0xffd700,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: isSLM ? 0.92 : 0.78,
                    blending: THREE.AdditiveBlending
                })
            );
            lmBaseRing.rotation.x = -Math.PI / 2;
            lmBaseRing.position.set(0, 0.21, 0);
            lm.add(lmBaseRing);
            if (!animData.rotatingHalo) animData.rotatingHalo = lmBaseRing;

            animData.floatingCrest = crestGroup;
            animData.crestBaseY = crestY + 0.15;
            labelHeightY = crestY + (isSLM ? 1.65 : 1.42);

            group.add(lm);
        }

        // 3.5 ✨ แสงเออร่าเมืองคูณ (Multiplier Aura): แสดงความหนาตามที่ตั้งค่าในหน้า Admin เมื่อสร้างเมืองครบสี (เช่น สีแดงครบคู่ คูณ 2) หรือเมื่อเป็นเมืองคูณพิเศษ
        if (mult > 1) {
            const mtCfg = this.monopolyTilesList?.[t - 1];
            const monoColorStr = mtCfg?.aura_color || mtCfg?.color;
            const auraHexNum = monoColorStr
                ? (parseInt(String(monoColorStr).replace('#', ''), 16) || 0xff0055)
                : ownerColor;
            const boardAuraT = Number(this.monopolyStageSkillConfig?.aura_thickness || 2.2);
            const aThick = Math.max(1.0, Math.min(3.5, Number(mtCfg?.aura_thickness || boardAuraT || 2.2)));

            // วงแหวนแสงเออร่าหนาพิเศษเรืองแสงรอบฐานเมือง
            const innerR = Math.max(1.5, 2.35 - (0.25 * aThick));
            const outerR = 2.75 + (0.28 * aThick);
            const multRing = new THREE.Mesh(
                new THREE.RingGeometry(innerR, outerR, 36),
                new THREE.MeshBasicMaterial({
                    color: auraHexNum,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: 0.95,
                    blending: THREE.AdditiveBlending
                })
            );
            multRing.rotation.x = -Math.PI / 2;
            multRing.position.set(0, 0.24, 0);
            group.add(multRing);
            if (!animData.rotatingHalo) animData.rotatingHalo = multRing;

            // แผ่นพลังงานเออร่าเรืองแสงเต็มพื้นที่ช่อง
            const multDisc = new THREE.Mesh(
                new THREE.CircleGeometry(outerR * 0.92, 32),
                new THREE.MeshBasicMaterial({
                    color: auraHexNum,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: Math.min(0.65, 0.28 * aThick),
                    blending: THREE.AdditiveBlending
                })
            );
            multDisc.rotation.x = -Math.PI / 2;
            multDisc.position.set(0, 0.19, 0);
            group.add(multDisc);

            // ม่านลำแสงเออร่าพุ่งรอบเมืองให้เห็นชัดเจนว่าค่าผ่านทางเมืองนี้กำลังคูณอยู่!
            const crownH = 2.2 + (aThick * 0.65);
            const multCrown = new THREE.Mesh(
                new THREE.CylinderGeometry(outerR * 0.88, outerR * 0.98, crownH, 28, 1, true),
                new THREE.MeshBasicMaterial({
                    color: auraHexNum,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: Math.min(0.58, 0.24 * aThick),
                    depthWrite: false,
                    blending: THREE.AdditiveBlending
                })
            );
            multCrown.position.set(0, crownH / 2 + 0.15, 0);
            group.add(multCrown);
            animData.beamMesh = multCrown;
        }

        // 4. ป้ายลอยดีไซน์เพรียวคมชัดเหนือยอดตึก แสดงค่าผ่านทาง & ตัวคูณ (เช่น คูณ 2, คูณ 4, คูณ 8)
        const tollVal = this.getTileToll(t);
        let badgeStr = mult > 1 ? `🔥x${mult}` : `${st.level}🏠`;
        if (isSLM) {
            badgeStr = mult > 1 ? `👑ซุปเปอร์ x${mult}` : '👑ซุปเปอร์LM';
        } else if (isLM) {
            badgeStr = mult > 1 ? `🏛️LM x${mult}` : '🏛️แลนด์มาร์ค';
        }
        const labelSprite = this.createCityLabelSprite(
            this.formatCompactGold(tollVal),
            badgeStr,
            ownerHex,
            isLM,
            mult,
            isSLM
        );
        labelSprite.position.set(0, labelHeightY, -1.35);
        group.add(labelSprite);

        // เริ่มต้นแอนิเมชันเด้งสร้างเมืองใหม่ (Pop-in Scale)
        group.scale.set(0.05, 0.05, 0.05);
        group.userData.cityAnim = animData;
        group.userData.tileNum = t;
        group.traverse(child => {
            if (child.isMesh) child.userData.tileNum = t;
        });

        this.citiesGroup.add(group);
        this.cityMeshes[t] = group;
    }

    openCityActionPrompt(config) {
        this._keepRollStationUntil = 0;
        this.hideMonopolyCenterRollStation(true);
        const modal = document.getElementById('modal-city-action');
        const titleEl = document.getElementById('city-action-title');
        const subEl = document.getElementById('city-action-sub');
        const iconEl = document.getElementById('city-action-icon');
        const avatarWrapper = document.getElementById('city-action-avatar-wrapper');
        const walletEl = document.getElementById('city-action-wallet');
        const optsEl = document.getElementById('city-action-options');
        const timerEl = document.getElementById('city-action-timer');
        const confirmBtn = document.getElementById('btn-city-action-confirm');
        const skipBtn = document.getElementById('btn-city-action-skip');

        if (!modal || !optsEl) {
            return Promise.resolve(config.defaultChoice ?? null);
        }

        this.closeCityActionPrompt(null);
        this.isWaitingForCityAction = true;
        this.cityActionAutoChoice = config.defaultChoice ?? null;

        // Current active human player avatar if available
        const activePlayer = this.players?.[this.currentPlayerIndex] || this.players?.find(p => !p.is_bot);
        const avatarUrl = activePlayer?.avatar_url || activePlayer?.picture || (typeof window.getActivePlayerAvatarUrl === 'function' ? window.getActivePlayerAvatarUrl() : 'avatars/google_avatar.png');

        if (avatarWrapper) {
            avatarWrapper.innerHTML = `
                <img src="${avatarUrl}" alt="Avatar" style="width:100%; height:100%; object-fit:cover; border-radius:50%;" onerror="this.onerror=null; this.src='avatars/google_avatar.png';">
                <span class="city-action-icon-badge">${config.icon || '🏛️'}</span>
            `;
        } else if (iconEl) {
            iconEl.innerText = config.icon || '🏙️';
        }

        if (titleEl) titleEl.innerHTML = config.title || 'จัดการเมือง';
        if (subEl) subEl.innerHTML = config.subtitle || '';
        if (walletEl) walletEl.innerHTML = config.walletHtml || '';

        return new Promise(resolve => {
            this.activeCityActionResolver = resolve;
            optsEl.innerHTML = '';

            const options = config.options || [];
            let selectedValue = config.defaultChoice;
            if (selectedValue === undefined || selectedValue === null) {
                const firstAvailable = options.find(o => !o.disabled && o.value !== 'SKIP' && o.value !== 0);
                selectedValue = firstAvailable ? firstAvailable.value : (options[0]?.value ?? null);
            }

            const updateConfirmButton = () => {
                if (!confirmBtn) return;
                const curOpt = options.find(o => o.value === selectedValue);
                if (curOpt && !curOpt.disabled) {
                    confirmBtn.disabled = false;
                    const costShort = curOpt.costLabel ? ` (${curOpt.costLabel})` : '';
                    confirmBtn.innerHTML = `<span>✅ ยืนยัน${costShort}</span>`;
                } else {
                    confirmBtn.disabled = false;
                    confirmBtn.innerHTML = `<span>✅ ยืนยัน</span>`;
                }
            };

            const optionButtons = [];
            options.forEach(opt => {
                const btn = document.createElement('button');
                btn.type = 'button';
                const isSelected = (opt.value === selectedValue);
                btn.className = 'city-opt-btn ' + (opt.className || '') + (isSelected ? ' selected' : '');
                btn.disabled = Boolean(opt.disabled);
                btn.innerHTML = `
                    <div class="city-opt-icon">${opt.icon || '🏠'}</div>
                    <div class="city-opt-info">
                        <div class="city-opt-title">${opt.label}</div>
                        ${opt.costLabel ? `<div class="city-opt-cost">${opt.costLabel}</div>` : ''}
                        ${opt.subLabel ? `<div class="city-opt-sub">${opt.subLabel}</div>` : ''}
                    </div>
                `;

                btn.onclick = () => {
                    if (opt.disabled) return;
                    if (selectedValue === opt.value) {
                        // Double click / clicking selected option immediately confirms!
                        this.closeCityActionPrompt(opt.value);
                        return;
                    }
                    selectedValue = opt.value;
                    optionButtons.forEach(b => b.classList.remove('selected'));
                    btn.classList.add('selected');
                    updateConfirmButton();
                };

                optionButtons.push(btn);
                optsEl.appendChild(btn);
            });

            updateConfirmButton();

            if (confirmBtn) {
                confirmBtn.onclick = () => {
                    this.closeCityActionPrompt(selectedValue);
                };
            }

            // Find skip / cancel option if present
            const skipOpt = options.find(o =>
                o.value === 'SKIP' ||
                o.value === 0 ||
                o.value === 'SURRENDER' ||
                (o.className && o.className.includes('skip-btn'))
            );
            if (skipBtn) {
                if (skipOpt) {
                    skipBtn.style.display = 'inline-flex';
                    skipBtn.innerHTML = `<span>${skipOpt.label || 'ข้าม'}</span>`;
                    skipBtn.onclick = () => {
                        this.closeCityActionPrompt(skipOpt.value);
                    };
                } else {
                    skipBtn.style.display = 'none';
                }
            }

            modal.style.display = 'flex';
            let sec = Number(config.timeoutSec) || 20;
            if (timerEl) timerEl.innerText = `${sec}วิ`;

            this.cityActionInterval = setInterval(() => {
                if (this.isAutoMode || this.isGameOver) {
                    this.closeCityActionPrompt(config.defaultChoice ?? null);
                    return;
                }
                sec--;
                if (timerEl) timerEl.innerText = `${Math.max(0, sec)}วิ`;
                if (sec <= 0) {
                    // หากผู้เล่นไม่ตัดสินใจ/จ่ายค่าผ่านทางภายใน 15 วินาที ให้เปลี่ยนเป็นเล่น AUTO ทันที และตัดสินใจอัตโนมัติ
                    this.enableAutoMode(false);
                    if (typeof this.showSkillBanner === 'function') {
                        this.showSkillBanner(`⏳ ไม่จ่าย/เลือกภายใน 15 วิ! ระบบจ่ายอัตโนมัติและเปลี่ยนเป็นโหมด AUTO`);
                    }
                    this.closeCityActionPrompt(config.defaultChoice ?? null);
                }
            }, 1000);
        });
    }

    closeCityActionPrompt(choiceValue = null) {
        if (this.cityActionInterval) {
            clearInterval(this.cityActionInterval);
            this.cityActionInterval = null;
        }
        const modal = document.getElementById('modal-city-action');
        if (modal) modal.style.display = 'none';
        this.isWaitingForCityAction = false;
        if (this.activeCityActionResolver) {
            const fn = this.activeCityActionResolver;
            this.activeCityActionResolver = null;
            fn(choiceValue);
        }
    }

    // -------------------------------------------------------------
    // TILE & CITY INSPECT SYSTEM (กดดูข้อมูลเมือง สิ่งก่อสร้าง ค่าผ่านทาง และค่าซื้อต่อ)
    // -------------------------------------------------------------
    setupTileInspectionClick() {
        if (!this.renderer || !this.renderer.domElement) return;
        const dom = this.renderer.domElement;
        let downX = 0;
        let downY = 0;
        let downTime = 0;
        let lastClickTime = 0;

        const isUiBlockingBoardTap = (clientX, clientY) => {
            if (typeof document === 'undefined' || typeof document.elementFromPoint !== 'function') return false;
            const elAtPoint = document.elementFromPoint(clientX, clientY);
            if (!elAtPoint) return false;
            return Boolean(elAtPoint.closest('button, .btn, a, input, select, textarea, .corner-hud-slot, .bottom-hud, .top-bar, .modal-content, .side-panel-toggle-tab, #board-quick-controls, .board-quick-controls, .side-panel, #left-menu-panel, #right-log-panel, .lobby-welcome-toast'));
        };

        const onDown = (clientX, clientY) => {
            if (isUiBlockingBoardTap(clientX, clientY)) {
                downTime = 0;
                return; // สัมผัสบนองค์ประกอบ UI (HUD, ปุ่มตั้งค่า, เมนู ฯลฯ) ไม่บันทึกเป็นคลิกกระดาน 3D
            }
            downX = clientX;
            downY = clientY;
            downTime = Date.now();
        };

        const onUp = (clientX, clientY) => {
            if (!downTime) return;
            const now = Date.now();
            if (now - lastClickTime < 320) return; // ป้องกันการยิงซ้ำซ้อนระหว่าง Touch และ Pointer
            const dt = now - downTime;
            const dist = Math.hypot(clientX - downX, clientY - downY);
            downTime = 0;

            if (isUiBlockingBoardTap(clientX, clientY)) {
                return; // ปล่อยนิ้วบน UI ไม่ตรวจสอบกระดาน
            }

            // คลิกหรือแตะโดยไม่ลากหมุนกล้อง (ระยะคลาดเคลื่อนนิ้วมือไม่เกิน 36px และเวลาไม่เกิน 800ms เพื่อรองรับ Mobile iOS & Android)
            if (dist <= 36 && dt <= 800) {
                lastClickTime = now;
                this.handleBoardTileClick({
                    clientX: clientX,
                    clientY: clientY,
                    target: dom
                });
            }
        };

        const targetEl = (typeof document !== 'undefined') ? document : dom;
        targetEl.addEventListener('pointerdown', (e) => {
            onDown(e.clientX, e.clientY);
        }, { passive: true, capture: true });

        targetEl.addEventListener('pointerup', (e) => {
            onUp(e.clientX, e.clientY);
        }, { passive: true, capture: true });

        // Touch event handlers เพื่อรับประกันการตอบสนอง 100% บน Safari iOS WKWebView และ Android Chrome
        targetEl.addEventListener('touchstart', (e) => {
            if (e.touches && e.touches.length === 1) {
                onDown(e.touches[0].clientX, e.touches[0].clientY);
            }
        }, { passive: true, capture: true });

        targetEl.addEventListener('touchend', (e) => {
            if (e.changedTouches && e.changedTouches.length === 1) {
                onUp(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
            }
        }, { passive: true, capture: true });
    }

    handleBoardTileClick(e) {
        if (!this.camera || !this.scene || !this.renderer) return;

        const isDirectPickActive = (typeof this._onBoardTilePickCallback === 'function');

        // 1. ตรวจสอบว่าจุดคลิก/แตะอยู่บนองค์ประกอบ UI 2D หรือไม่ (ปุ่มตั้งค่า, HUD, เมนู, กล่องข้อความ ฯลฯ)
        if (typeof document !== 'undefined' && typeof document.elementFromPoint === 'function' && e && e.clientX !== undefined && e.clientY !== undefined) {
            const hitEl = document.elementFromPoint(e.clientX, e.clientY);
            if (hitEl && hitEl.closest('button, .btn, a, input, select, textarea, .corner-hud-slot, .bottom-hud, .top-bar, .modal-content, .side-panel-toggle-tab, #board-quick-controls, .board-quick-controls, .side-panel, #left-menu-panel, #right-log-panel, .lobby-welcome-toast')) {
                return;
            }
        }

        // 2. หากมี Modal ใดๆ กำลังเปิดอยู่ หรือมีคลาส modal-open บน body ให้ละเว้นการคลิกกระดาน 3D เด็ดขาด
        if (typeof document !== 'undefined' && !isDirectPickActive) {
            if (document.body && document.body.classList.contains('modal-open')) return;
            const openBlockingModals = document.querySelectorAll(
                '.modal-overlay.active, #modal-settings, #modal-shop, #modal-gacha-reveal, #modal-city-action, #modal-magic-cube, #modal-match-result, #modal-boards, #modal-lobby, #modal-inventory, #modal-gems'
            );
            for (const m of openBlockingModals) {
                const cs = getComputedStyle(m);
                if (m.style.display !== 'none' && cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity || '1') > 0.05) {
                    return;
                }
            }
        }

        // 3. ยิง Raycaster ตรวจสอบช่องกระดาน 3D ที่ผู้เล่นจิ้ม/คลิก
        const domEl = this.renderer.domElement;
        const rect = domEl.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0 && e && e.clientX !== undefined && e.clientY !== undefined) {
            const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
            const ndcY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
            if (!this._boardRaycaster) this._boardRaycaster = new THREE.Raycaster();
            this._boardRaycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera);

            const rayTargets = [];
            if (this._boardPickGroup) rayTargets.push(this._boardPickGroup);
            if (Array.isArray(this.tileMeshes)) {
                this.tileMeshes.forEach(tm => { if (tm) rayTargets.push(tm); });
            }
            if (this.citiesGroup) rayTargets.push(this.citiesGroup);

            const hits = this._boardRaycaster.intersectObjects(rayTargets, true);
            if (hits && hits.length > 0) {
                let clickedTile = 0;
                let fallbackTile = 0;
                for (const h of hits) {
                    let cur = h.object;
                    let hitTile = 0;
                    while (cur) {
                        if (cur.userData && cur.userData.tileNum) {
                            hitTile = Number(cur.userData.tileNum);
                            break;
                        }
                        cur = cur.parent;
                    }
                    if (hitTile >= 1) {
                        if (!fallbackTile) fallbackTile = hitTile;
                        if (isDirectPickActive && this._boardPickClickableSet && !this._boardPickClickableSet.has(hitTile)) {
                            continue;
                        }
                        clickedTile = hitTile;
                        break;
                    }
                }
                if (!clickedTile) clickedTile = fallbackTile;

                if (clickedTile >= 1) {
                    if (isDirectPickActive) {
                        this._onBoardTilePickCallback(clickedTile);
                        return;
                    }
                    if (this.isMonopolyBoardMode && this.isMatchActive) {
                        this.inspectTileCity(clickedTile);
                        return;
                    }
                }
            }
        }

        if (typeof document !== 'undefined') {
            // คลิกที่พื้นที่ว่างบนกระดาน ให้ปิด popup เล็กๆ แสดงเมืองอัตโนมัติ
            const inspectModal = document.getElementById('modal-city-inspect');
            if (inspectModal && inspectModal.style.display !== 'none') {
                this.closeCityInspect();
            }
        }
    }

    inspectTileCity(tileNum) {
        const t = Number(tileNum);
        if (!t || t < 1 || t > 100) return;

        // 1. ไฮไลท์วงแหวนเรืองแสงสีทอง 3D บนกระดานตรงช่องที่เลือก
        this.showInspectHighlightRing(t);

        const modal = document.getElementById('modal-city-inspect');
        if (!modal) return;

        const numBadge = document.getElementById('city-inspect-num-badge');
        const typeBadge = document.getElementById('city-inspect-type-badge');
        const titleEl = document.getElementById('city-inspect-title');
        const iconEl = document.getElementById('city-inspect-icon');
        const ownerCardEl = document.getElementById('city-inspect-owner-card');
        const tollEl = document.getElementById('city-inspect-toll');
        const multNoteEl = document.getElementById('city-inspect-multiplier-note');
        const buyoutEl = document.getElementById('city-inspect-buyout');
        const buyoutNoteEl = document.getElementById('city-inspect-buyout-note');
        const bStatusEl = document.getElementById('city-inspect-building-status');
        const bVisualsEl = document.getElementById('city-inspect-building-visuals');
        const costsTableEl = document.getElementById('city-inspect-build-costs');
        const alertEl = document.getElementById('city-inspect-special-alert');

        const prov = this.getProvinceName(t);
        const st = this.cityStates[t];
        const isBuildable = this.isBuildableTile(t);

        // หัวข้อและเลขช่อง
        if (numBadge) numBadge.innerText = `ช่อง ${t}`;
        if (titleEl) titleEl.innerText = prov;

        // วิเคราะห์ประเภทช่อง (รองรับทั้งกระดานบันไดงูและกระดานเกมส์เศรษฐี 32 ช่อง)
        let typeName = 'เมืองพาณิชย์';
        let iconChar = '🏙️';
        let specialDescText = '';
        const monoTile = (this.isMonopolyBoardMode && Array.isArray(this.monopolyTilesList))
            ? this.monopolyTilesList[t - 1]
            : null;
        const monoType = monoTile ? String(monoTile.type || '').toUpperCase() : '';

        if (t === 1 || monoType === 'START') {
            const sal = (window.GAME_RULES && window.GAME_RULES.lap_salary_gold !== undefined) ? Number(window.GAME_RULES.lap_salary_gold) : 200000;
            typeName = '🏁 จุดสตาร์ท (START)';
            iconChar = '🏁';
            specialDescText = `เดินผ่านจุดสตาร์ท (ทอยครั้งแรกของเทิร์น) รับเงินเดือน +${sal.toLocaleString()} ทอง`;
        } else if (t === 100) {
            typeName = 'เส้นชัยพิชิตกระดาน (FINISH)';
            iconChar = '🏆';
        } else if (t === this.jailTile || monoType === 'JAIL' || monoType === 'ISLAND') {
            typeName = 'เกาะร้าง / ติดเกาะ (Jail)';
            iconChar = '🏝️';
            specialDescText = 'ติดเกาะร้างสูงสุด 2 ตา ทอยเบิ้ลหรือจ่ายค่าประกันตัวเพื่อออกทันที';
        } else if (monoType === 'WORLD_TRAVEL' || monoType === 'AIRPORT' || monoType === 'TRAVEL') {
            typeName = '✈️ ท่องเที่ยวรอบโลก (World Travel)';
            iconChar = '✈️';
            specialDescText = 'เลือกบินไปยังเมืองหรือช่องใดก็ได้บนกระดานในเทิร์นถัดไป';
        } else if (monoType === 'OLYMPIC' || monoType === 'FESTIVAL') {
            typeName = '🏟️ เทศกาล / โอลิมปิก (Festival)';
            iconChar = '🏟️';
            specialDescText = 'เลือกเมืองของคุณ 1 แห่งเพื่อเพิ่มตัวคูณค่าผ่านทาง (x2 / x4 / x8)';
        } else if ((this.chanceTiles && this.chanceTiles.includes(t)) || monoType === 'CHANCE' || monoType === 'FORTUNE') {
            typeName = 'ช่องการ์ดดวง (Chance)';
            iconChar = '🎁';
            specialDescText = 'เปิดการ์ดดวงสุ่มรับโบนัสทอง, ย้ายตำแหน่ง, หรือเหตุการณ์พิเศษ';
        } else if ((this.taxTiles && this.taxTiles.includes(t)) || monoType === 'TAX') {
            typeName = 'สำนักงานสรรพากร (Tax)';
            iconChar = '🏛️';
            specialDescText = 'เสียภาษี 10% ของมูลค่าทรัพย์สินหรือเงินสดที่มีเข้ากองกลาง';
        } else if ((this.gambleTiles && this.gambleTiles.includes(t)) || monoType === 'GAMBLE' || monoType === 'CASINO') {
            typeName = 'วงล้อเสี่ยงโชค (Lucky Gamble)';
            iconChar = '🎡';
            specialDescText = 'หมุนวงล้อเสี่ยงทายทวีคูณเงินรางวัล';
        } else if (this.destroyTiles && this.destroyTiles.includes(t)) {
            typeName = 'ช่องพายุทำลายเมือง (Destroy)';
            iconChar = '⚡';
            specialDescText = 'สุ่มทำลายสิ่งก่อสร้างหรือลดระดับเมืองบนกระดาน';
        } else if (this.ladders && this.ladders[t]) {
            typeName = 'บันไดไต่ขึ้น';
            iconChar = '🪜';
        } else if (this.snakes && this.snakes[t]) {
            typeName = 'หัวงูดึงร่วง';
            iconChar = '🐍';
        } else if (st && st.isSuperLandmark) {
            typeName = '👑 ซุปเปอร์แลนด์มาร์ค';
            iconChar = '👑';
        } else if (st && st.isLandmark) {
            typeName = '🏛️ แลนด์มาร์คถาวร';
            iconChar = '🏛️';
        }

        if (alertEl) {
            const notes = [];
            if (specialDescText) notes.push(specialDescText);
            if (this.blackHoleTiles && this.blackHoleTiles.includes(t)) notes.push('🕳️ ช่องนี้มีหลุมดำดูดผู้เล่น!');
            if (this.fogTiles && this.fogTiles.includes(t)) notes.push('🌫️ ช่องนี้ปกคลุมด้วยหมอก!');
            if (notes.length > 0) {
                alertEl.style.display = 'block';
                alertEl.innerHTML = notes.join('<br>');
            } else {
                alertEl.style.display = 'none';
            }
        }

        if (typeBadge) typeBadge.innerText = typeName;
        if (iconEl) iconEl.innerText = iconChar;

        // ข้อมูลเจ้าของ
        if (ownerCardEl) {
            if (st && st.ownerId) {
                const owner = this.players.find(p => String(p.id) === String(st.ownerId));
                const avatar = owner?.avatar || 'assets/default_avatar.png';
                const name = owner?.username || owner?.name || 'ผู้เล่น';
                const teamTag = owner?.team && owner.team !== 'NONE'
                    ? `<span style="background:${owner.color || '#3b82f6'}; color:#fff; font-size:9.5px; font-weight:800; padding:1px 5px; border-radius:4px; margin-left:4px;">ทีม ${owner.team}</span>`
                    : '';
                const investGold = this.formatCompactGold(st.investedGold || 0);

                ownerCardEl.innerHTML = `
                    <div style="display:flex; align-items:center; gap:8px; width:100%;">
                        <img src="${avatar}" style="width:34px; height:34px; border-radius:50%; border:2px solid ${owner?.color || '#00e5ff'}; object-fit:cover; box-shadow:0 0 8px rgba(0,229,255,0.4);" onerror="this.src='assets/default_avatar.png'">
                        <div style="flex:1; min-width:0;">
                            <div style="display:flex; align-items:center;">
                                <strong style="font-size:12.5px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${name}</strong>
                                ${teamTag}
                            </div>
                            <div style="font-size:10px; color:#38bdf8; margin-top:1px;">
                                เจ้าของเมือง • ลงทุน ${investGold} ทอง
                            </div>
                        </div>
                        <span style="background:rgba(0,229,255,0.18); border:1px solid #00e5ff; color:#67e8f9; font-size:10px; font-weight:800; padding:2px 6px; border-radius:5px; white-space:nowrap;">
                            มีเจ้าของ
                        </span>
                    </div>
                `;
            } else if (isBuildable) {
                ownerCardEl.innerHTML = `
                    <div style="display:flex; align-items:center; gap:8px; width:100%;">
                        <span style="font-size:20px; flex-shrink:0;">🚩</span>
                        <div style="flex:1; min-width:0;">
                            <div style="font-size:12px; font-weight:700; color:#cbd5e1;">ที่ดินว่าง (ยังไม่มีเจ้าของ)</div>
                            <div style="font-size:10px; color:#94a3b8; line-height:1.25;">สร้างเมืองได้เมื่อตกช่องนี้</div>
                        </div>
                        <span style="background:rgba(16,185,129,0.2); color:#34d399; border:1px solid #10b981; font-size:10px; font-weight:800; padding:2px 6px; border-radius:5px; white-space:nowrap;">
                            ว่าง
                        </span>
                    </div>
                `;
            } else {
                ownerCardEl.innerHTML = `
                    <div style="display:flex; align-items:center; gap:8px; width:100%;">
                        <span style="font-size:20px; flex-shrink:0;">⭐</span>
                        <div style="flex:1; min-width:0;">
                            <div style="font-size:12px; font-weight:700; color:#cbd5e1;">ช่องพิเศษของระบบ</div>
                            <div style="font-size:10px; color:#94a3b8; line-height:1.25;">ช่องนี้ไม่สามารถสร้างเมืองได้ (มีผลเอฟเฟกต์พิเศษ)</div>
                        </div>
                    </div>
                `;
            }
        }

        // ค่าผ่านทาง (Toll Fee)
        if (tollEl) {
            if (st && st.ownerId) {
                const toll = this.getTileToll(t);
                tollEl.innerText = `${toll.toLocaleString()} ทอง`;
                tollEl.title = `ประมาณ ${this.formatCompactGold(toll)} ทอง`;
            } else {
                tollEl.innerText = `0 ทอง`;
                tollEl.title = '';
            }
        }

        if (multNoteEl) {
            if (st && st.ownerId) {
                if (st.multiplier && Number(st.multiplier) > 1) {
                    multNoteEl.innerHTML = `<span style="color:#f43f5e; font-weight:800;">🔥 ติดตัวคูณพิเศษ x${st.multiplier}</span>`;
                } else if (st.isSuperLandmark) {
                    multNoteEl.innerHTML = `<span style="color:#f472b6; font-weight:800;">🏰 ซุปเปอร์แลนด์มาร์ค (x2.45)</span>`;
                } else if (st.isLandmark) {
                    multNoteEl.innerHTML = `<span style="color:#fde047; font-weight:800;">🏛️ แลนด์มาร์ค (x1.45)</span>`;
                } else {
                    multNoteEl.innerText = 'อัตราปกติ (x1)';
                }
            } else {
                multNoteEl.innerText = isBuildable ? 'ไม่มีค่าผ่านทาง (ที่ดินว่าง)' : 'ช่องพิเศษ';
            }
        }

        // ค่าซื้อต่อ (Buyout Cost)
        if (buyoutEl) {
            if (st && st.ownerId) {
                if (st.isLandmark || st.isSuperLandmark) {
                    buyoutEl.innerText = '🚫 ล็อกเมือง';
                    buyoutEl.style.fontSize = '12px';
                    buyoutEl.style.color = '#f43f5e';
                    if (buyoutNoteEl) buyoutNoteEl.innerText = 'ล็อกถาวร ห้ามซื้อต่อ';
                } else {
                    const buyout = this.getTileBuyoutCost(t);
                    buyoutEl.innerText = `${buyout.toLocaleString()} ทอง`;
                    buyoutEl.style.fontSize = '14px';
                    buyoutEl.style.color = '#38bdf8';
                    if (buyoutNoteEl) buyoutNoteEl.innerText = `ซื้อต่อได้ (${this.formatCompactGold(buyout)} ทอง)`;
                }
            } else {
                buyoutEl.innerText = '-';
                buyoutEl.style.fontSize = '14px';
                buyoutEl.style.color = '#94a3b8';
                if (buyoutNoteEl) buyoutNoteEl.innerText = isBuildable ? 'ยังไม่มีเจ้าของให้ซื้อต่อ' : 'ไม่สามารถซื้อต่อได้';
            }
        }

        // สถานะสิ่งก่อสร้าง (Building Status)
        if (bStatusEl && bVisualsEl) {
            if (st && st.ownerId) {
                if (st.isSuperLandmark) {
                    bStatusEl.innerText = '🏰 ซุปเปอร์';
                    bVisualsEl.innerHTML = `
                        <span class="city-inspect-house-tag" style="border-color:#ec4899; color:#f472b6; background:rgba(236,72,153,0.15);">
                            🏰✨ ซุปเปอร์แลนด์มาร์ค (x2.45)
                        </span>
                    `;
                } else if (st.isLandmark) {
                    bStatusEl.innerText = '🏛️ แลนด์มาร์ค';
                    bVisualsEl.innerHTML = `
                        <span class="city-inspect-house-tag" style="border-color:#fbbf24; color:#fde047; background:rgba(245,158,11,0.15);">
                            🏛️ แลนด์มาร์กถาวร (x1.45)
                        </span>
                    `;
                } else {
                    const lvl = Number(st.level) || 1;
                    bStatusEl.innerText = `${lvl} หลัง`;
                    bVisualsEl.innerHTML = Array.from({ length: lvl }).map((_, idx) => `
                        <span class="city-inspect-house-tag">🏠 หลังที่ ${idx + 1}</span>
                    `).join('');
                }
            } else {
                bStatusEl.innerText = isBuildable ? 'ที่ดินว่าง' : 'ช่องพิเศษ';
                bVisualsEl.innerHTML = isBuildable
                    ? `<span class="city-inspect-house-tag">🏕️ ยังไม่มีสิ่งก่อสร้าง (เริ่มสร้างได้เมื่อตกช่องนี้)</span>`
                    : `<span class="city-inspect-house-tag">⚡ ช่องลูกเล่นเกม</span>`;
            }
        }

        // ราคาค่าก่อสร้าง (Build Costs Table)
        if (costsTableEl) {
            if (isBuildable) {
                const costs = this.getTileBuildCosts(t);
                costsTableEl.style.display = 'block';
                costsTableEl.innerHTML = `
                    <div style="font-weight:700; color:#cbd5e1; margin-bottom:3px; font-size:10px;">🏗️ อัตราค่าก่อสร้างช่องนี้:</div>
                    <div class="city-inspect-costs-grid">
                        <div class="city-inspect-cost-item">
                            <span class="c-label">1 หลัง</span>
                            <span class="c-val">${this.formatCompactGold(costs.city1)}</span>
                        </div>
                        <div class="city-inspect-cost-item">
                            <span class="c-label">2 หลัง</span>
                            <span class="c-val">${this.formatCompactGold(costs.city2)}</span>
                        </div>
                        <div class="city-inspect-cost-item">
                            <span class="c-label">3 หลัง</span>
                            <span class="c-val">${this.formatCompactGold(costs.city3)}</span>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:space-between; margin-top:4px; padding-top:4px; border-top:1px solid rgba(255,255,255,0.08); font-size:9.5px;">
                        <span>🏛️ แลนด์มาร์ค: <strong style="color:#fbbf24;">${this.formatCompactGold(costs.landmarkUpgrade)}</strong></span>
                        <span>🏰 ซุปเปอร์: <strong style="color:#f472b6;">${this.formatCompactGold(costs.superLandmarkUpgrade)}</strong></span>
                    </div>
                `;
            } else {
                costsTableEl.style.display = 'none';
            }
        }

        // ทางลัดบันได / งู
        if (alertEl) {
            if (this.ladders && this.ladders[t]) {
                alertEl.style.display = 'block';
                alertEl.style.background = 'rgba(0, 229, 255, 0.15)';
                alertEl.style.border = '1px solid #00e5ff';
                alertEl.style.color = '#7dd3fc';
                alertEl.innerHTML = `🪜 <strong>ทางลัดบันได (ขึ้น):</strong> ตกช่องนี้จะปีนขึ้นไปสู่ <strong>ช่องที่ ${this.ladders[t]}</strong> ทันที!`;
            } else if (this.snakes && this.snakes[t]) {
                alertEl.style.display = 'block';
                alertEl.style.background = 'rgba(239, 68, 68, 0.15)';
                alertEl.style.border = '1px solid #ef4444';
                alertEl.style.color = '#fca5a5';
                alertEl.innerHTML = `🐍 <strong>อันตรายหัวงู (ลง):</strong> ตกช่องนี้จะโดนงูกลืนร่วงลงไปยัง <strong>ช่องที่ ${this.snakes[t]}</strong>!`;
            } else if (specialDescText || (this.blackHoleTiles && this.blackHoleTiles.includes(t)) || (this.fogTiles && this.fogTiles.includes(t))) {
                alertEl.style.display = 'block';
                alertEl.style.background = 'rgba(168, 85, 247, 0.15)';
                alertEl.style.border = '1px solid #a855f7';
                alertEl.style.color = '#e9d5ff';
            } else {
                alertEl.style.display = 'none';
            }
        }

        // แสดงหน้าต่างโมดอล & เล่นเสียงคลิก
        modal.style.display = 'flex';
        try {
            if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
                window.soundEngine.playClick();
            }
        } catch (e) { }
    }

    showInspectHighlightRing(tileNum) {
        this.clearInspectHighlightRing();
        const pos = this.tiles[tileNum];
        if (!pos) return;

        const ringGroup = new THREE.Group();
        ringGroup.name = 'inspectHighlightRing';
        ringGroup.position.set(pos.x, (pos.y || 0) + 0.32, pos.z);

        // 1. วงแหวนสีทองเรืองแสงรอบช่อง (Gold Highlight Ring)
        const ringGeo = new THREE.RingGeometry(1.68, 2.05, 36);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0xffd700,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.95
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = -Math.PI / 2;
        ringGroup.add(ringMesh);

        // 2. แผ่นพื้นเรืองแสงโปร่งใส (Inner Glow Disc)
        const discGeo = new THREE.CircleGeometry(1.65, 32);
        const discMat = new THREE.MeshBasicMaterial({
            color: 0xffe600,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.26
        });
        const discMesh = new THREE.Mesh(discGeo, discMat);
        discMesh.rotation.x = -Math.PI / 2;
        ringGroup.add(discMesh);

        // 3. เสาลำแสงส่องชี้ตำแหน่งแนวตั้ง (Vertical Beacon Beam)
        const beaconGeo = new THREE.CylinderGeometry(1.75, 1.75, 5.5, 32, 1, true);
        const beaconMat = new THREE.MeshBasicMaterial({
            color: 0xffd700,
            transparent: true,
            opacity: 0.22,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending
        });
        const beacon = new THREE.Mesh(beaconGeo, beaconMat);
        beacon.position.y = 2.75;
        // ringGroup.add(beacon); // ปิดแท่งแสง
        ringGroup.userData.beacon = beacon;

        this.effectsGroup.add(ringGroup);
        this.inspectHighlightRing = ringGroup;
    }

    clearInspectHighlightRing() {
        if (this.inspectHighlightRing) {
            this.effectsGroup.remove(this.inspectHighlightRing);
            this.inspectHighlightRing = null;
        }
    }

    closeCityInspect() {
        const modal = document.getElementById('modal-city-inspect');
        if (modal) modal.style.display = 'none';
        this.clearInspectHighlightRing();
        if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
            window.soundEngine.playClick();
        }
    }

    /**
     * สุ่มตัวคูณแลนด์มาร์ค X2 / X4 / X6 / X8 / X12 ตามสกิลลูกเต๋า + สกิลกรอบรูป + สกิลอัญมณีของผู้เล่น
     */
    rollLandmarkMultiplier(player, tileNum) {
        const st = this.cityStates[tileNum];
        if (!st || !st.isLandmark) return 2;

        const prov = this.getProvinceName(tileNum);
        const diceSkill = Number(player.dice_control_rate) || 20;
        const frameSkill = (Number(player.play_skill_rate) || 15) + (Number(player.win_rate_bonus) || 10) * 0.55;
        const gems = this.getPlayerEquippedGems(player);
        const gemEff = this.aggregateGemEffects(gems);

        const pool = gemEff.toll_multiplier_random ? [2, 4, 6, 8, 12] : [2, 4, 6, 8];
        const bonusBias = Math.min(0.45, (diceSkill + frameSkill) / 250);
        const pickIdx = Math.min(pool.length - 1, Math.floor((Math.random() + bonusBias * 0.5) * pool.length));
        const finalMult = Math.max(Number(st.multiplier) || 2, pool[pickIdx]);

        st.multiplier = finalMult;
        this.rebuildTileCity3D(tileNum);
        const newToll = this.getTileToll(tileNum);

        if (gemEff.toll_multiplier_random) {
            this.showSkillBanner(`💎 สกิลอัญมณีตัวคูณแลนด์มาร์คทำงาน! [${prov}] พุ่งเป็นคูณ X${finalMult} (ค่าผ่านทาง ${this.formatCompactGold(newToll)})!`);
        }
        this.logMessage(`⚡ ${player.username} ตกแลนด์มาร์คตัวเอง [${prov}] สกิลเต๋า/กรอบ/อัญมณีสุ่มได้คูณ X${finalMult}! ค่าผ่านทางพุ่งเป็น ${newToll.toLocaleString()} ทอง!`, 'skill');
        return finalMult;
    }

    async showOpponentTollModal(visitor, owner, prov, toll, cityDesc) {
        const modal = document.getElementById('modal-opponent-toll');
        if (!modal) return;
        const titleEl = document.getElementById('opp-toll-title');
        const visitorEl = document.getElementById('opp-toll-visitor');
        const amountEl = document.getElementById('opp-toll-amount');
        const timerEl = document.getElementById('opp-toll-timer');
        const statusEl = document.getElementById('opp-toll-status');

        if (titleEl) titleEl.innerText = `🚨 คู่แข่งตกเมืองของคุณ!`;
        if (visitorEl) visitorEl.innerHTML = `<strong>${visitor?.username || 'คู่แข่ง'}</strong> ตกที่ [${prov}] (${cityDesc})`;
        if (amountEl) amountEl.innerText = `+${Number(toll).toLocaleString()} ทอง (${this.formatCompactGold(toll)})`;
        if (statusEl) {
            statusEl.innerText = `💸 คู่แข่งกำลังชำระค่าผ่านทาง...`;
            statusEl.style.color = '#fbbf24';
        }

        modal.style.display = 'flex';

        let sec = 15;
        if (timerEl) timerEl.innerText = `${sec}s`;

        const timerId = setInterval(() => {
            sec--;
            if (timerEl) timerEl.innerText = `${Math.max(0, sec)}s`;
            if (sec <= 0) {
                clearInterval(timerId);
            }
        }, 1000);

        // รอสักครู่ (~1.6 วินาที) ให้เห็นรายละเอียดค่าผ่านทางอย่างชัดเจน
        await new Promise(r => setTimeout(r, 1600));
        clearInterval(timerId);

        if (statusEl) {
            statusEl.innerText = `✅ ชำระค่าผ่านทางเรียบร้อย! ทองเข้ากระเป๋าคุณ`;
            statusEl.style.color = '#34d399';
        }
        if (window.soundEngine && typeof window.soundEngine.playCoins === 'function') {
            window.soundEngine.playCoins();
        }

        await new Promise(r => setTimeout(r, 800));
        modal.style.display = 'none';
    }

    async handleCityTileLanding(player, options = {}) {
        const {
            allowBuyout = true,
            isPostBounce = false
        } = options;

        const t = player.currentTile;
        if (!this.isBuildableTile(t) || this.isGameOver || player.isBankrupt) return;

        const prov = this.getProvinceName(t);
        const costs = this.getTileBuildCosts(t);
        const st = this.cityStates[t];
        const isAutoOrBot = Boolean(player.is_bot || this.isAutoMode || !this.isLocalPlayer(player));

        // -----------------------------------------------------------
        // CASE 1: ช่องจังหวัดว่าง -> ตาแรกสร้างเมืองได้สูงสุด 3 เมือง (เหมือนรูป 2)
        // -----------------------------------------------------------
        if (!st) {
            // หากเป็นการเด้ง/ส่งต่อมายังช่องนี้ (เช่น เด้งจากสกิล หรือ ปลายบันได/หางงู):
            // "และหากเป็นเมืองที่ไม่ได้สร้างห้ามสร้างเมืองใดๆทั้งสิ้น"
            if (isPostBounce) {
                this.logMessage(`ℹ️ ${player.username} ถูกส่ง/เด้งมาที่ช่อง [${prov}] (ยังไม่มีเมืองสร้าง) — ห้ามสร้างเมืองใดๆ ทั้งสิ้น!`, '');
                return;
            }

            const gold = Number(player.matchGold) || 0;
            if (gold < costs.city1) return;

            let maxAffordable = 1;
            if (gold >= costs.city3) maxAffordable = 3;
            else if (gold >= costs.city2) maxAffordable = 2;

            let chosenCount = 0;
            if (isAutoOrBot) {
                // บอทหรือโหมด AUTO: สร้าง 3 เมืองทันทีถ้าเงินเหลือปลอดภัย หรือลดหลั่นตามงบ
                if (gold >= costs.city3 * 1.15) chosenCount = 3;
                else if (gold >= costs.city2 * 1.15) chosenCount = 2;
                else chosenCount = 1;
            } else {
                chosenCount = await this.openCityActionPrompt({
                    icon: '🏙️',
                    title: `สร้างเมืองที่ "${prov}" (ช่อง ${t})`,
                    subtitle: 'ตาแรกเลือกสร้างได้สูงสุด 3 เมือง! ตกซ้ำครั้งหน้าสร้างแลนด์มาร์คได้ทันที',
                    defaultChoice: maxAffordable,
                    timeoutSec: 20,
                    walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 💰</span>`,
                    options: [
                        {
                            icon: '🏠',
                            label: 'สร้าง 1 เมือง',
                            costLabel: `${this.formatCompactGold(costs.city1)} 💰`,
                            subLabel: 'บ้านพักตากอากาศ',
                            value: 1,
                            disabled: gold < costs.city1
                        },
                        {
                            icon: '🏘️',
                            label: 'สร้าง 2 เมือง',
                            costLabel: `${this.formatCompactGold(costs.city2)} 💰`,
                            subLabel: 'คอมมูนิตี้วิลล่า',
                            value: 2,
                            disabled: gold < costs.city2
                        },
                        {
                            icon: '🏙️',
                            label: 'สร้าง 3 เมือง!',
                            costLabel: `${this.formatCompactGold(costs.city3)} 💰`,
                            subLabel: 'แนะนำ! พร้อมอัปแลนด์มาร์ค',
                            value: 3,
                            className: gold >= costs.city3 ? 'recommended' : '',
                            disabled: gold < costs.city3
                        },
                        {
                            icon: '⏭️',
                            label: 'ยังไม่สร้าง',
                            costLabel: 'ข้ามตานี้',
                            value: 0,
                            className: 'skip-btn'
                        }
                    ]
                });
            }

            const count = Number(chosenCount) || 0;
            if (count >= 1 && count <= 3) {
                const totalBuildCost = costs[`city${count}`];
                if ((Number(player.matchGold) || 0) >= totalBuildCost) {
                    player.matchGold -= totalBuildCost;
                    this.cityStates[t] = {
                        ownerId: player.id,
                        ownerIndex: this.players.indexOf(player),
                        color: player.color,
                        level: count,
                        isLandmark: false,
                        multiplier: 1,
                        investedGold: totalBuildCost
                    };
                    this.rebuildTileCity3D(t);
                    this.checkAndRefreshColorGroupBonus3D(t, player);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    if (window.ThaiAudio && typeof window.ThaiAudio.playBuildCity === 'function') {
                        window.ThaiAudio.playBuildCity();
                    } else if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                        window.ThaiAudio.playIfConfigured('build_city');
                    }
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`🏙️ ${player.username} สร้าง ${count} เมืองที่ [${prov}]! (ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`🏙️ ${player.username} สร้าง ${count} เมืองที่ช่อง ${this.getDisplayTileNumber(t)} (${prov}) จ่าย ${totalBuildCost.toLocaleString()} ทอง (ค่าผ่านทาง ${tollNow.toLocaleString()})`, 'highlight');
                    if (this.checkLineMonopolyVictory(player)) return;

                    // สกิลสร้าง 3 เมือง % ตัวละครกระโดดสปิน 360 องศา แล้วเปลี่ยนเป็นแลนด์มาร์คทันที!
                    if (count === 3) {
                        const gems = this.getPlayerEquippedGems(player);
                        const eff = this.aggregateGemEffects(gems);
                        if (eff.instant_landmark_3city) {
                            const lmChance = eff.landmark_rate || 80;
                            if (Math.random() * 100 < lmChance) {
                                await this.animatePlayerJumpAndSpin(player);
                                const stNow = this.cityStates[t];
                                if (stNow) {
                                    stNow.level = 4;
                                    stNow.isLandmark = true;
                                    stNow.isSuperLandmark = false;
                                    stNow.multiplier = Math.max(2, Number(stNow.multiplier) || 2);
                                    this.rebuildTileCity3D(t);
                                    const lmToll = this.getTileToll(t);
                                    this.showSkillBanner(`✨ สกิลอัศจรรย์ (${lmChance}%)! ${player.username} กระโดดสปิน เสก 3 เมืองกลายเป็น "แลนด์มาร์ค" ทันที! (ค่าผ่านทาง ${this.formatCompactGold(lmToll)})`);
                                    this.logMessage(`✨ สกิล [instant_landmark_3city] ของ ${player.username} ทำงาน! อัปเกรดเป็นแลนด์มาร์คทันที`, 'skill');
                                    if (window.ThaiAudio && typeof window.ThaiAudio.playBuildLandmark === 'function') {
                                        window.ThaiAudio.playBuildLandmark();
                                    }
                                    if (this.checkLineMonopolyVictory(player)) return;
                                    await this.triggerLandmarkSkills(player, t);
                                }
                            }
                        }
                    }
                }
            }
            return;
        }

        const owner = this.players.find(p => String(p.id) === String(st.ownerId));
        const isSelf = String(st.ownerId) === String(player.id);
        const isTeammate = Boolean(
            !isSelf &&
            player.team &&
            player.team !== 'NONE' &&
            owner &&
            player.team === owner.team
        );

        // -----------------------------------------------------------
        // CASE 2: ตกเมืองของตัวเอง -> ครั้งที่ 2 สร้างแลนด์มาร์ค / หากเป็นแลนด์มาร์คแล้ว อัปเป็นซุปเปอร์แลนด์มาร์ค / ถึงสูงสุดแล้วสุ่มตัวคูณ
        // -----------------------------------------------------------
        if (isSelf) {
            if (isPostBounce) {
                this.logMessage(`ℹ️ ${player.username} เด้งมาตกเมืองของตัวเอง [${prov}] ปลอดภัย!`, '');
                return;
            }
            if (!st.isLandmark) {
                // มีเมืองอยู่แล้ว (1-3 หลัง) -> สร้างแลนด์มาร์คได้ทันที!
                const missingCities = Math.max(0, 3 - (Number(st.level) || 1));
                const upgradeCost = costs.landmarkUpgrade + missingCities * costs.unitCost;
                const gold = Number(player.matchGold) || 0;
                if (gold < upgradeCost) {
                    this.logMessage(`ℹ️ ${player.username} ตกเมืองตัวเอง [${prov}] แต่ทองไม่พอสร้างแลนด์มาร์ค (ต้องการ ${this.formatCompactGold(upgradeCost)})`, '');
                    return;
                }

                let doLandmark = false;
                if (isAutoOrBot) {
                    doLandmark = true;
                } else {
                    const choice = await this.openCityActionPrompt({
                        icon: '🏛️',
                        title: `อัปเกรดแลนด์มาร์ค "${prov}"!`,
                        subtitle: 'มีเมืองอยู่แล้ว! สร้างแลนด์มาร์คเพื่อล็อกเมือง (ห้ามใครซื้อต่อเด็ดขาด) และเพิ่มค่าผ่านทางพุ่งทะยาน!',
                        defaultChoice: 'LANDMARK',
                        timeoutSec: 20,
                        walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 💰</span>`,
                        options: [
                            {
                                icon: '🏛️',
                                label: 'สร้างแลนด์มาร์ค!',
                                costLabel: `${this.formatCompactGold(upgradeCost)} 💰`,
                                subLabel: 'ห้ามใครซื้อต่อ + ค่าผ่านทางพุ่ง!',
                                value: 'LANDMARK',
                                className: 'landmark-btn recommended'
                            },
                            {
                                icon: '⏭️',
                                label: 'ยังไม่สร้าง',
                                costLabel: 'เก็บทองไว้ก่อน',
                                value: 'SKIP',
                                className: 'skip-btn'
                            }
                        ]
                    });
                    doLandmark = (choice === 'LANDMARK');
                }

                if (doLandmark && (Number(player.matchGold) || 0) >= upgradeCost) {
                    player.matchGold -= upgradeCost;
                    st.level = 4;
                    st.isLandmark = true;
                    st.isSuperLandmark = false;
                    st.investedGold = (Number(st.investedGold) || 0) + upgradeCost;
                    st.multiplier = Math.max(2, Number(st.multiplier) || 2);
                    this.rebuildTileCity3D(t);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`🏛️ ${player.username} สร้างแลนด์มาร์ค [${prov}] สำเร็จ! (ป้องกันซื้อต่อ • ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`🏛️ ${player.username} อัปเกรด [${prov}] เป็นแลนด์มาร์คสำเร็จ! ค่าผ่านทาง ${tollNow.toLocaleString()} ทอง (ห้ามซื้อต่อ!)`, 'highlight');
                    if (window.ThaiAudio && typeof window.ThaiAudio.playBuildLandmark === 'function') {
                        window.ThaiAudio.playBuildLandmark();
                    } else if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                        window.ThaiAudio.playIfConfigured('build_landmark');
                    }
                    if (this.checkLineMonopolyVictory(player)) return;

                    // สกิลแลนด์มาร์ค: สุ่มตัวคูณ X2-X12, ดึงดูดคู่แข่ง, หรือ เสกหลุมดำ
                    await this.triggerLandmarkSkills(player, t);
                }
            } else if (!st.isSuperLandmark) {
                // เป็นแลนด์มาร์คแล้ว และตกอีกครั้ง -> ให้สร้าง "ซุปเปอร์แลนด์มาร์ค (Super Landmark)"!
                const superCost = costs.superLandmarkUpgrade || Math.round(costs.landmarkUpgrade * 1.75);
                const gold = Number(player.matchGold) || 0;
                let doSuper = false;

                if (gold >= superCost) {
                    if (isAutoOrBot) {
                        doSuper = true;
                    } else {
                        const choice = await this.openCityActionPrompt({
                            icon: '👑',
                            title: `อัปเกรด "ซุปเปอร์แลนด์มาร์ค" [${prov}]!`,
                            subtitle: 'ตกแลนด์มาร์คตัวเองอีกครั้ง! อัปเกรดขั้นสูงสุด (Super Landmark) เพิ่มค่าผ่านทางมหาศาล!',
                            defaultChoice: 'SUPER_LANDMARK',
                            timeoutSec: 20,
                            walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 💰</span>`,
                            options: [
                                {
                                    icon: '👑',
                                    label: 'สร้างซุปเปอร์แลนด์มาร์ค!',
                                    costLabel: `${this.formatCompactGold(superCost)} 💰`,
                                    subLabel: 'ขั้นสูงสุด! ห้ามซื้อต่อ + ค่าผ่านทางคูณหนัก',
                                    value: 'SUPER_LANDMARK',
                                    className: 'landmark-btn recommended'
                                },
                                {
                                    icon: '⚡',
                                    label: 'สุ่มตัวคูณแทน',
                                    costLabel: 'ฟรี (ลุ้น X2-X12)',
                                    value: 'ROLL_ONLY',
                                    className: 'skip-btn'
                                }
                            ]
                        });
                        doSuper = (choice === 'SUPER_LANDMARK');
                    }
                }

                if (doSuper && (Number(player.matchGold) || 0) >= superCost) {
                    player.matchGold -= superCost;
                    st.level = 5;
                    st.isLandmark = true;
                    st.isSuperLandmark = true;
                    st.investedGold = (Number(st.investedGold) || 0) + superCost;
                    st.multiplier = Math.max(4, Number(st.multiplier) || 4);
                    this.rebuildTileCity3D(t);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`👑 ${player.username} สร้าง "ซุปเปอร์แลนด์มาร์ค" [${prov}] ขั้นสูงสุดสำเร็จ! (ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`👑 ${player.username} อัปเกรด [${prov}] เป็นซุปเปอร์แลนด์มาร์ค (ขั้นสูงสุด) ค่าผ่านทาง ${tollNow.toLocaleString()} ทอง (ห้ามซื้อต่อ!)`, 'highlight');
                    if (window.ThaiAudio && typeof window.ThaiAudio.playBuildSuperLandmark === 'function') {
                        window.ThaiAudio.playBuildSuperLandmark();
                    } else if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                        window.ThaiAudio.playIfConfigured('build_super_landmark');
                    }
                    if (this.checkLineMonopolyVictory(player)) return;

                    // สกิลแลนด์มาร์ค
                    await this.triggerLandmarkSkills(player, t);
                } else {
                    // หากไม่สร้างซุปเปอร์แลนด์มาร์ค หรือทองไม่พอ ให้สุ่มตัวคูณ X2-X12
                    this.rollLandmarkMultiplier(player, t);
                    // ตกแลนด์มาร์คตัวเอง -> กระตุ้นสกิลแลนด์มาร์ค
                    await this.triggerLandmarkSkills(player, t);
                }
            } else {
                // แลนด์มาร์กถึงสูงสุดแล้ว (Super Landmark) -> สุ่มคูณตัวคูณ X4 - X12 ต่อเนื่อง!
                this.logMessage(`👑 [${prov}] เป็นซุปเปอร์แลนด์มาร์คขั้นสูงสุดแล้ว (ไม่สามารถสร้างต่อได้)`, '');
                this.rollLandmarkMultiplier(player, t);
                // ตกแลนด์มาร์คตัวเอง -> กระตุ้นสกิลแลนด์มาร์ค
                await this.triggerLandmarkSkills(player, t);
            }
            return;
        }

        if (isTeammate) {
            this.logMessage(`🤝 ${player.username} แวะพักที่เมืองของเพื่อนร่วมทีม (${owner?.username || 'ทีมเดียวกัน'}) ไม่เสียค่าผ่านทาง!`, '');
            return;
        }

        // -----------------------------------------------------------
        // CASE 3: ตกเมืองหรือแลนด์มาร์คของคู่แข่ง -> แสดง Popup ค่าผ่านทาง / กู้เงิน / ล้มละลาย
        // -----------------------------------------------------------
        let toll = this.getTileToll(t);
        const visitorGems = this.getPlayerEquippedGems(player);
        const visitorEffects = this.aggregateGemEffects(visitorGems);
        if (visitorEffects.toll_discount) {
            toll = Math.max(1, Math.round(toll * 0.5));
            this.showSkillBanner(`💸 สกิลส่วนลดค่าผ่านทาง 50% ของ ${player.username} ทำงาน! ลดเหลือ ${this.formatCompactGold(toll)}!`);
            this.logMessage(`💸 สกิลส่วนลดค่าผ่านทาง 50% ของ ${player.username} ทำงาน! ค่าผ่านทางลดเหลือ ${toll.toLocaleString()} ทอง`, 'skill');
        }
        const visitorGold = Number(player.matchGold) || 0;
        const gr = window.GAME_RULES || {};
        const maxLoans = Math.max(0, Number(gr.loan_max_count ?? 3));
        const loanGoldCost = Math.max(0, Number(gr.loan_gold_cost ?? 5000));
        const loanGoldBonusPct = Math.max(0, Number(gr.loan_gold_bonus_percent ?? 25));
        const loanDiaCost = Math.max(0, Number(gr.loan_diamond_cost ?? 20));
        const loanDiaBonusPct = Math.max(0, Number(gr.loan_diamond_bonus_percent ?? 100));

        const loansUsed = Number(player.loanCount) || 0;
        const shortage = Math.max(0, toll - visitorGold);
        const hasEnoughGold = (visitorGold >= toll);
        const canLoan = (loansUsed < maxLoans);

        // คำนวณยอดกู้ฉุกเฉิน: กู้ด้วยทอง (+25% เช่น ตก 2M กู้ได้ 2.5M) / กู้ด้วยเพชร (+100% ได้เยอะ เหลือเยอะ)
        const goldLoanAmount = Math.max(shortage + 100000, Math.round(toll * (1 + loanGoldBonusPct / 100)));
        const diaLoanAmount = Math.max(shortage + 300000, Math.round(toll * (1 + loanDiaBonusPct / 100)));
        const sysGold = Number(window.DEFAULT_USER?.gold || 0);
        const sysDia = Number(window.DEFAULT_USER?.diamond || 0);
        const canAffordGoldLoan = canLoan && (isAutoOrBot || sysGold >= loanGoldCost);
        const canAffordDiaLoan = canLoan && (isAutoOrBot || sysDia >= loanDiaCost);

        const cityDesc = st.isSuperLandmark
            ? `👑 ซุปเปอร์แลนด์มาร์ค (ขั้นสูงสุด • ค่าผ่านทาง X${st.multiplier || 1})`
            : (st.isLandmark ? `🏛️ แลนด์มาร์ค (ห้ามซื้อต่อ • ค่าผ่านทาง X${st.multiplier || 1})` : `🏙️ เมืองระดับ ${st.level || 1} หลัง`);

        // ตรวจสอบว่าผู้มาเยือนตกเมืองของเรา (Local player หรือ Teammate) หรือไม่
        const isOwnerLocal = Boolean(owner && this.isLocalPlayer(owner));
        const isVisitorLocal = Boolean(this.isLocalPlayer(player) && !player.is_bot);

        // หากคู่แข่งตกเมืองเรา: ให้แสดง popup ด้วยว่าต้องจ่ายค่าผ่านทางเท่าไหร่
        if (isOwnerLocal && !isVisitorLocal) {
            await this.showOpponentTollModal(player, owner, prov, toll, cityDesc);
        }

        let tollDecision = null;

        if (isAutoOrBot) {
            // โหมดบอท หรือ AUTO: ตัดสินใจอัตโนมัติ
            if (hasEnoughGold) {
                tollDecision = 'PAY_TOLL';
            } else if (canAffordGoldLoan) {
                tollDecision = 'LOAN_GOLD';
            } else if (canAffordDiaLoan) {
                tollDecision = 'LOAN_DIAMOND';
            } else {
                tollDecision = 'BANKRUPT';
            }
        } else {
            // ผู้เล่นจริง: แสดง Popup รายละเอียดค่าผ่านทาง พร้อมปุ่มเลือกกดจ่าย, กู้เงิน หรือล้มละลาย
            const cityDesc = st.isSuperLandmark
                ? `👑 ซุปเปอร์แลนด์มาร์ค (ขั้นสูงสุด • ค่าผ่านทาง X${st.multiplier || 1})`
                : (st.isLandmark ? `🏛️ แลนด์มาร์ค (ห้ามซื้อต่อ • ค่าผ่านทาง X${st.multiplier || 1})` : `🏙️ เมืองระดับ ${st.level || 1} หลัง`);

            let walletInfoHtml = `
                <div style="display:flex; flex-direction:column; gap:4px; width:100%; background:rgba(15,23,42,0.92); padding:5px 8px; border-radius:9px; border:1px solid rgba(255,255,255,0.1); box-sizing:border-box;">
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:3px;">
                        <span style="font-size:11px;">👑 เจ้าของ: <strong style="color:#38bdf8; font-size:11.5px;">${owner?.username || 'คู่แข่ง'}</strong></span>
                        <span style="font-size:10.5px; color:#fde047; font-weight:700;">${cityDesc}</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:11px;">💸 ค่าผ่านทาง:</span>
                        <strong style="color:#f43f5e; font-size:13px; font-weight:900;">-${toll.toLocaleString()} 💰 (${this.formatCompactGold(toll)})</strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:10.5px;">💰 ทองในกระเป๋า:</span>
                        <strong style="color:#fde047; font-size:11.5px;">${visitorGold.toLocaleString()} 💰</strong>
                    </div>
            `;

            if (hasEnoughGold) {
                const remaining = visitorGold - toll;
                walletInfoHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px dashed rgba(255,255,255,0.15); padding-top:3px;">
                        <span style="font-size:10.5px;">✨ ทองคงเหลือ:</span>
                        <strong style="color:#10b981; font-size:11.5px; font-weight:800;">${remaining.toLocaleString()} 💰</strong>
                    </div>
                </div>`;
            } else {
                walletInfoHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px dashed rgba(244,63,94,0.4); padding-top:3px; color:#f87171;">
                        <span style="font-size:10.5px;">⚠️ ขาดอีก:</span>
                        <strong style="font-size:12px; color:#ff4d4d; font-weight:900;">${shortage.toLocaleString()} 💰 (${this.formatCompactGold(shortage)})</strong>
                    </div>
                </div>`;
            }

            const promptOptions = [];

            if (hasEnoughGold) {
                promptOptions.push({
                    icon: '💸',
                    label: 'จ่ายค่าผ่านทาง',
                    costLabel: `-${this.formatCompactGold(toll)} 💰`,
                    subLabel: 'ชำระค่าผ่านทางและเดินเกมต่อ',
                    value: 'PAY_TOLL',
                    className: 'pay-btn recommended'
                });
                promptOptions.push({
                    icon: '🏳️',
                    label: 'ประกาศล้มละลาย',
                    costLabel: 'ยอมแพ้',
                    subLabel: `โอนทรัพย์สินให้ ${owner?.username || 'คู่แข่ง'} แล้วจบเกม`,
                    value: 'BANKRUPT',
                    className: 'skip-btn'
                });
            } else {
                // เงินไม่พอจ่าย: เลือกกู้ด้วยทองในระบบ, กู้ด้วยเพชรในระบบ (ได้เยอะ เหลือเยอะ) หรือประกาศล้มละลาย
                if (canLoan) {
                    const remainAfterGold = Math.max(0, visitorGold + goldLoanAmount - toll);
                    const remainAfterDia = Math.max(0, visitorGold + diaLoanAmount - toll);
                    promptOptions.push({
                        icon: '🪙',
                        label: `กู้ด้วยทองในระบบ (รับ ${this.formatCompactGold(goldLoanAmount)})`,
                        costLabel: canAffordGoldLoan ? `ใช้ ${loanGoldCost.toLocaleString()} ทองระบบ` : `ทองระบบไม่พอ (มี ${sysGold.toLocaleString()})`,
                        subLabel: `จ่ายค่าผ่านทางแล้วเหลือใช้ต่อ +${this.formatCompactGold(remainAfterGold)} (สิทธิ์ ${loansUsed + 1}/${maxLoans})`,
                        value: 'LOAN_GOLD',
                        disabled: !canAffordGoldLoan,
                        className: canAffordGoldLoan ? 'loan-btn recommended' : 'skip-btn'
                    });
                    promptOptions.push({
                        icon: '💎',
                        label: `กู้ด้วยเพชรในระบบ (รับ ${this.formatCompactGold(diaLoanAmount)} ได้เยอะ!)`,
                        costLabel: canAffordDiaLoan ? `ใช้ ${loanDiaCost.toLocaleString()} เพชร` : `เพชรไม่พอ (มี ${sysDia.toLocaleString()})`,
                        subLabel: `จ่ายค่าผ่านทางแล้วเหลือเยอะ +${this.formatCompactGold(remainAfterDia)} (สิทธิ์ ${loansUsed + 1}/${maxLoans})`,
                        value: 'LOAN_DIAMOND',
                        disabled: !canAffordDiaLoan,
                        className: canAffordDiaLoan ? 'landmark-btn' : 'skip-btn'
                    });
                } else {
                    promptOptions.push({
                        icon: '🚫',
                        label: 'สิทธิ์กู้เงินเต็มแล้ว',
                        costLabel: `ใช้ครบ ${maxLoans} ครั้งแล้ว`,
                        subLabel: 'ไม่สามารถกู้เงินเพิ่มได้',
                        value: 'NONE',
                        disabled: true,
                        className: 'skip-btn'
                    });
                }
                promptOptions.push({
                    icon: '💥',
                    label: 'ประกาศล้มละลาย',
                    costLabel: `มอบทอง ${this.formatCompactGold(visitorGold)} ทั้งหมด`,
                    subLabel: `โอนทองที่เหลือให้ ${owner?.username || 'คู่แข่ง'} แล้วออกจากเกม`,
                    value: 'BANKRUPT',
                    className: 'bankrupt-btn'
                });
            }

            tollDecision = await this.openCityActionPrompt({
                icon: hasEnoughGold ? '💸' : '⚠️',
                title: hasEnoughGold ? `ตกเมือง "${prov}"! จ่ายค่าผ่านทาง` : `ตกเมือง "${prov}"! เงินไม่พอจ่ายค่าผ่านทาง`,
                subtitle: hasEnoughGold
                    ? `เมืองของ <strong>${owner?.username || 'คู่แข่ง'}</strong> • ตรวจสอบค่าใช้จ่ายแล้วกดชำระหรือยอมแพ้`
                    : `ขาดอีก <strong style="color:#ff4d4d;">${this.formatCompactGold(shortage)} ทอง</strong> • เลือกกู้ด้วยทอง/เพชรในระบบ หรือประกาศล้มละลาย`,
                defaultChoice: hasEnoughGold ? 'PAY_TOLL' : (canAffordGoldLoan ? 'LOAN_GOLD' : (canAffordDiaLoan ? 'LOAN_DIAMOND' : 'BANKRUPT')),
                walletHtml: walletInfoHtml,
                options: promptOptions,
                timeoutSec: 15
            });
        }

        // ประมวลผลผลการตัดสินใจค่าผ่านทาง
        if (tollDecision === 'BANKRUPT') {
            // ประกาศล้มละลาย
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + visitorGold;
            }
            player.matchGold = 0;
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();

            this.showSkillBanner(`💥 ${player.username} ประกาศล้มละลายที่ [${prov}]!`);
            this.logMessage(`💥 ${player.username} ตกเมือง [${prov}] ของ ${owner?.username || 'คู่แข่ง'} (ค่าผ่านทาง ${toll.toLocaleString()}) เลือกประกาศล้มละลาย! โอนเงินทั้งหมด ${visitorGold.toLocaleString()} ทองให้ ${owner?.username || 'คู่แข่ง'}`, 'highlight');
            this.handleBankruptcy(player, owner || null, `ล้มละลายจากค่าผ่านทางที่ ${prov}`);
            return;
        }

        if (tollDecision === 'LOAN_AND_PAY' || tollDecision === 'LOAN_GOLD' || tollDecision === 'LOAN_DIAMOND') {
            const useDiamond = (tollDecision === 'LOAN_DIAMOND');
            const chosenLoanAmt = useDiamond ? diaLoanAmount : goldLoanAmount;
            const chosenMethod = useDiamond ? 'diamond' : 'gold';
            const chosenCost = useDiamond ? loanDiaCost : loanGoldCost;

            let loanOk = true;
            if (!player.is_bot && this.isLocalPlayer(player) && !window.isPracticeMatch && chosenCost > 0) {
                try {
                    const tok = (window.apiClient && (typeof window.apiClient.getToken === 'function' ? window.apiClient.getToken() : window.apiClient.token)) || localStorage.getItem('snake_auth_token') || '';
                    const bUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
                    const lRes = await fetch(`${bUrl}api/matchmaking.php?action=emergency_loan`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            ...(tok ? { 'Authorization': 'Bearer ' + tok } : {})
                        },
                        body: JSON.stringify({ method: chosenMethod })
                    }).then(r => r.json());
                    if (lRes && lRes.status === 'success') {
                        if (window.DEFAULT_USER) {
                            if (lRes.gold !== undefined) window.DEFAULT_USER.gold = Number(lRes.gold);
                            if (lRes.diamond !== undefined) window.DEFAULT_USER.diamond = Number(lRes.diamond);
                            if (typeof window.updateUserBar === 'function') window.updateUserBar(window.DEFAULT_USER);
                        }
                    } else {
                        loanOk = false;
                        if (typeof window.showToast === 'function') {
                            window.showToast(`❌ ${(lRes && lRes.message) || 'กู้เงินไม่สำเร็จ'}`);
                        }
                    }
                } catch (e) {
                    loanOk = false;
                }
            } else if (!player.is_bot && this.isLocalPlayer(player) && window.DEFAULT_USER) {
                if (useDiamond) {
                    window.DEFAULT_USER.diamond = Math.max(0, Number(window.DEFAULT_USER.diamond || 0) - chosenCost);
                } else {
                    window.DEFAULT_USER.gold = Math.max(0, Number(window.DEFAULT_USER.gold || 0) - chosenCost);
                }
                if (typeof window.updateUserBar === 'function') window.updateUserBar(window.DEFAULT_USER);
            }

            if (loanOk) {
                player.loanCount = (Number(player.loanCount) || 0) + 1;
                player.matchGold = visitorGold + chosenLoanAmt;
                const methodText = useDiamond ? `💎 เพชร ${chosenCost.toLocaleString()}` : `🪙 ทองระบบ ${chosenCost.toLocaleString()}`;
                this.showSkillBanner(`🏦 ${player.username} กู้ฉุกเฉิน (${methodText}) +${this.formatCompactGold(chosenLoanAmt)} ทอง (${player.loanCount}/${maxLoans})!`);
                this.logMessage(`🏦 ${player.username} ใช้ ${methodText} กู้ฉุกเฉินรับ ${chosenLoanAmt.toLocaleString()} ทอง (ครั้งที่ ${player.loanCount}/${maxLoans}) เพื่อจ่ายค่าผ่านทาง ${toll.toLocaleString()} ทอง!`, 'skill');
            }
        }

        // หักค่าผ่านทางจริงให้เจ้าของเมือง
        const currentGoldAfterLoan = Number(player.matchGold) || 0;
        const actualPaid = Math.min(currentGoldAfterLoan, toll);
        player.matchGold = Math.max(0, currentGoldAfterLoan - actualPaid);
        if (owner && !owner.isBankrupt) {
            owner.matchGold = (Number(owner.matchGold) || 0) + actualPaid;
        }
        this.updateMatchWealthHUD();
        this.updateActiveTurnUI();

        this.showSkillBanner(`🚧 ${player.username} จ่ายค่าผ่านทาง [${prov}] ${this.formatCompactGold(actualPaid)} ให้ ${owner?.username || 'เจ้าของเมือง'}!`);
        this.logMessage(`🚧 ${player.username} ตกช่อง ${t} (${prov}) จ่ายค่าผ่านทาง ${actualPaid.toLocaleString()} ทอง ให้ ${owner?.username || 'เจ้าของเมือง'}!`, 'highlight');

        // หากเงินยังคงไม่พอแม้กู้แล้ว
        if (player.matchGold <= 0 && actualPaid < toll) {
            this.handleBankruptcy(player, owner || null, `ล้มละลายจากค่าผ่านทางที่ ${prov}`);
            return;
        }

        // ตรวจสอบว่าเจ้าของเมืองยืนเฝ้าเมืองอยู่ที่ช่องนี้หรือไม่!
        const standingOwner = this.players.find(p => p.id === owner?.id && !p.isBankrupt && p.currentTile === t);
        if (standingOwner && !isPostBounce) {
            // เจ้าของเมืองยืนอยู่ที่เมืองของตัวเอง: คู่ต่อสู้จ่ายค่าผ่านทางก่อน แล้วจึงโดนเด้งถอยหลังตามระยะสกิล!
            const defSkill = standingOwner.skill || {};
            const bounceTiles = (defSkill.code === 'PULL_BACK_8' || standingOwner.isAwakened || defSkill.power === 8) ? 8 : (defSkill.power || 5);

            this.showSkillBanner(`⚡ สกิลพิทักษ์เมือง! ${standingOwner.username} ซัด ${player.username} เด้งถอยหลัง ${bounceTiles} ช่อง!`);
            this.logMessage(`⚡ สกิลพิทักษ์เมืองทำงาน! ${standingOwner.username} ยืนเฝ้าเมือง [${prov}] หลังจากเก็บค่าผ่านทาง ${actualPaid.toLocaleString()} ทองแล้ว ซัด ${player.username} เด้งกระเด็นถอยหลัง ${bounceTiles} ช่อง!`, 'skill');

            const bouncedTile = Math.max(1, player.currentTile - bounceTiles);
            await this.animatePawnToTile(player, bouncedTile, 750);
            player.currentTile = bouncedTile;
            this.showLandingPin(bouncedTile);

            // ตรวจสอบช่องที่กระเด็นไปตก (เช่น บันได หรืองู)
            if (this.ladders[player.currentTile] || this.snakes[player.currentTile]) {
                await this.checkAndTriggerBoardLinks(player);
            }

            // ที่ช่องปลายทาง: "แล้วบังคับจ่ายค่าผ่านทางอีกครั้งจำนวนมูลค่าผ่านทางเมืองที่ตกและหากเป็นเมืองที่ไม่ได้สร้างห้ามสร้างเมืองใดๆทั้งสิ้น"
            if (this.isBuildableTile(player.currentTile)) {
                await this.handleCityTileLanding(player, { isPostBounce: true, allowBuyout: false });
            }
            return;
        }

        // หาก allowBuyout เป็น false (เช่น อยู่ที่บันได, หัวงู, หรือช่องหลังเด้ง):
        // "แต่หากเป็นของผ่ายตงข้างบังคับจ่ายทันทีชื้อต่อไม่ได้"
        if (!allowBuyout) {
            this.logMessage(`🔒 [${prov}] เป็นเมืองของ ${owner?.username || 'คู่แข่ง'} — บังคับจ่ายค่าผ่านทางทันที (ไม่สามารถซื้อต่อได้)`, 'skill');
            return;
        }

        // หากเป็นแลนด์มาร์ค หรือ ซุปเปอร์แลนด์มาร์ค -> ห้ามซื้อต่อเด็ดขาด!
        if (st.isLandmark || st.isSuperLandmark) {
            const lmTypeStr = st.isSuperLandmark ? '👑 ซุปเปอร์แลนด์มาร์ค' : '🏛️ แลนด์มาร์ค';
            this.logMessage(`🔒 [${prov}] เป็น${lmTypeStr}ของ ${owner?.username || 'คู่แข่ง'} — ไม่สามารถซื้อต่อได้!`, 'skill');
            return;
        }

        // หากยังเป็นเมือง 1-3 หลัง และมีทองเหลือพอซื้อต่อ -> เสนอซื้อต่อเมือง (และอัปเป็นแลนด์มาร์คต่อได้!)
        const buyoutCost = this.getTileBuyoutCost(t);
        if (player.matchGold < buyoutCost) return;

        const missingForLm = Math.max(0, 3 - (Number(st.level) || 1)) * costs.unitCost;
        const buyoutPlusLandmarkCost = buyoutCost + missingForLm + costs.landmarkUpgrade;
        const canBuyAndLandmark = player.matchGold >= buyoutPlusLandmarkCost;

        let buyAction = 'SKIP';
        if (isAutoOrBot) {
            if (canBuyAndLandmark && player.matchGold >= buyoutPlusLandmarkCost * 1.15) {
                buyAction = 'BUY_AND_LANDMARK';
            } else if (player.matchGold >= buyoutCost * 1.2) {
                buyAction = 'BUYOUT';
            }
        } else {
            buyAction = await this.openCityActionPrompt({
                icon: '💼',
                title: `ซื้อต่อเมือง "${prov}" จาก ${owner?.username || 'คู่แข่ง'}?`,
                subtitle: `จ่ายค่าผ่านทางแล้ว ${this.formatCompactGold(toll)} • สามารถเทคโอเวอร์เมืองนี้มาเป็นของเราได้!`,
                defaultChoice: canBuyAndLandmark ? 'BUY_AND_LANDMARK' : 'BUYOUT',
                timeoutSec: 20,
                walletHtml: `<span>💰 ทองคงเหลือหลังจ่ายค่าผ่านทาง: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 💰</span>`,
                options: [
                    {
                        icon: '💼',
                        label: 'ซื้อต่อเมืองนี้',
                        costLabel: `${this.formatCompactGold(buyoutCost)} 💰`,
                        subLabel: `ยึดเมือง ${st.level} หลังมาเป็นของเรา`,
                        value: 'BUYOUT',
                        className: !canBuyAndLandmark ? 'recommended' : ''
                    },
                    {
                        icon: '🏛️',
                        label: 'ซื้อต่อ + สร้างแลนด์มาร์ค!',
                        costLabel: `${this.formatCompactGold(buyoutPlusLandmarkCost)} 💰`,
                        subLabel: 'ยึดแล้วล็อกแลนด์มาร์คทันที!',
                        value: 'BUY_AND_LANDMARK',
                        className: canBuyAndLandmark ? 'landmark-btn recommended' : '',
                        disabled: !canBuyAndLandmark
                    },
                    {
                        icon: '⏭️',
                        label: 'ไม่ซื้อต่อ',
                        costLabel: 'เก็บทองไว้เดินต่อ',
                        value: 'SKIP',
                        className: 'skip-btn'
                    }
                ]
            });
        }

        if (buyAction === 'BUY_AND_LANDMARK' && player.matchGold >= buyoutPlusLandmarkCost) {
            player.matchGold -= buyoutPlusLandmarkCost;
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + buyoutCost;
            }
            st.ownerId = player.id;
            st.ownerIndex = this.players.indexOf(player);
            st.color = player.color;
            st.level = 4;
            st.isLandmark = true;
            st.multiplier = 2;
            st.investedGold = (Number(st.investedGold) || 0) + missingForLm + costs.landmarkUpgrade;
            this.rebuildTileCity3D(t);
            this.checkAndRefreshColorGroupBonus3D(t, player);
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            const newToll = this.getTileToll(t);
            if (window.ThaiAudio && typeof window.ThaiAudio.playBuildLandmark === 'function') {
                window.ThaiAudio.playBuildLandmark();
            } else if (window.ThaiAudio && typeof window.ThaiAudio.playBuyoutCity === 'function') {
                window.ThaiAudio.playBuyoutCity();
            } else if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                window.ThaiAudio.playIfConfigured('build_landmark');
            }
            this.showSkillBanner(`🏛️ ${player.username} เทคโอเวอร์ [${prov}] พร้อมสร้างแลนด์มาร์คทันที! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
            this.logMessage(`🏛️ ${player.username} ซื้อต่อเมือง [${prov}] และอัปเกรดเป็นแลนด์มาร์คทันที!`, 'highlight');
            if (this.checkLineMonopolyVictory(player)) return;
            await this.triggerLandmarkSkills(player, t);
        } else if (buyAction === 'BUYOUT' && player.matchGold >= buyoutCost) {
            player.matchGold -= buyoutCost;
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + buyoutCost;
            }
            st.ownerId = player.id;
            st.ownerIndex = this.players.indexOf(player);
            st.color = player.color;
            this.rebuildTileCity3D(t);
            this.checkAndRefreshColorGroupBonus3D(t, player);
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            if (window.ThaiAudio && typeof window.ThaiAudio.playBuyoutCity === 'function') {
                window.ThaiAudio.playBuyoutCity();
            } else if (window.ThaiAudio && typeof window.ThaiAudio.playIfConfigured === 'function') {
                window.ThaiAudio.playIfConfigured('buyout_city');
            }
            this.showSkillBanner(`💼 ${player.username} ซื้อต่อเมือง [${prov}] สำเร็จ!`);
            this.logMessage(`💼 ${player.username} ซื้อต่อเมือง [${prov}] จาก ${owner?.username || 'คู่แข่ง'} ในราคา ${buyoutCost.toLocaleString()} ทอง!`, 'highlight');
            if (this.checkLineMonopolyVictory(player)) return;
        }
    }

    /**
     * 💥 สกิลลบเมืองคู่แข่ง (ช่อง 26, 36, 90)
     * หากตกช่องนี้ สามารถใช้สกิลเลือกเมืองคู่แข่งที่ต้องการลบได้
     * หากคู่แข่งต้องการรักษาเมืองไว้ ต้องจ่ายเงินปกป้องเมือง!
     */
    async handleDestroySkillTile(player) {
        if (!player || player.isBankrupt || this.isGameOver) return;
        const isAutoOrBot = Boolean(player.is_bot || this.isAutoMode || !this.isLocalPlayer(player));

        // หาเมืองหรือแลนด์มาร์คของคู่แข่งทั้งหมดบนกระดาน (ยกเว้นซุปเปอร์แลนด์มาร์ค ห้ามระเบิด!)
        const opponentCities = [];
        for (const [tKey, st] of Object.entries(this.cityStates)) {
            const tNum = Number(tKey);
            if (!st || String(st.ownerId) === String(player.id)) continue;
            if (st.isSuperLandmark) continue; // 👑 ยกเว้นซุปเปอร์แลนด์มาร์ค ไม่สามารถระเบิดได้!
            const owner = this.players.find(p => String(p.id) === String(st.ownerId));
            if (!owner || owner.isBankrupt) continue;
            if (player.team && player.team !== 'NONE' && owner.team === player.team) continue;

            const prov = this.getProvinceName(tNum);
            const levelStr = st.isLandmark ? '🏛️ แลนด์มาร์ค' : `${st.level}🏠 เมือง`;
            opponentCities.push({
                tileNum: tNum,
                state: st,
                owner,
                prov,
                levelStr
            });
        }

        if (opponentCities.length === 0) {
            this.showSkillBanner(`💣 ${player.username} ตกพื้นที่ระเบิด! แต่ยังไม่มีเมืองหรือแลนด์มาร์คของคู่แข่งที่ระเบิดได้ (ซุปเปอร์แลนด์มาร์คป้องกันระเบิด)`);
            this.logMessage(`💣 ${player.username} ตกพื้นที่ระเบิด แต่ไม่มีเมืองหรือแลนด์มาร์คคู่แข่งให้ทำลาย!`, 'highlight');
            return;
        }

        this.showSkillBanner(`💣 พื้นที่ระเบิด! ${player.username} สามารถเลือกเมืองหรือแลนด์มาร์คคู่แข่งเพื่อระเบิดทิ้งได้!`);
        this.logMessage(`💣 ${player.username} ตกพื้นที่ระเบิด กำลังเปิดเป้าหมายเลือกระเบิดเมืองหรือแลนด์มาร์คคู่แข่ง!`, 'skill');

        let targetTileNum = null;

        opponentCities.sort((a, b) => {
            const valA = (Number(a.state.investedGold) || 0) * (a.state.isLandmark ? 2.5 : 1);
            const valB = (Number(b.state.investedGold) || 0) * (b.state.isLandmark ? 2.5 : 1);
            return valB - valA;
        });

        if (isAutoOrBot || !this.isLocalPlayer(player)) {
            targetTileNum = opponentCities[0]?.tileNum;
        } else {
            const oppSet = new Set(opponentCities.map(c => c.tileNum));
            const chosenBombTile = await this.pickTileDirectlyOnBoard3D({
                title: '💣 พื้นที่ระเบิด! จิ้มเลือกเมืองหรือแลนด์มาร์คคู่แข่งบนกระดาน',
                subText: '✨ จิ้มที่เมืองหรือแลนด์มาร์คของคู่แข่งที่สว่างอยู่บนกระดานเพื่อวางระเบิดทันที! (ยกเว้นซุปเปอร์แลนด์มาร์ค)',
                getTileMode: (t) => oppSet.has(t) ? 'HIGHLIGHT' : 'DISABLED',
                defaultTile: opponentCities[0]?.tileNum,
                timeoutSec: 15
            });
            if (!chosenBombTile) return;
            targetTileNum = Number(chosenBombTile);
        }

        const targetData = opponentCities.find(c => c.tileNum === targetTileNum);
        if (!targetData) return;

        const { tileNum: targetTile, state: targetState, owner: targetOwner, prov: targetProv, levelStr: targetLevelStr } = targetData;
        const invested = Number(targetState.investedGold) || 120000;
        const defendCost = this.roundMatchGold(invested * 0.35);
        const defendDiamondCost = targetState.isLandmark ? 30 : 15;
        const ownerGold = Number(targetOwner.matchGold) || 0;
        const userDiamonds = (!targetOwner.is_bot && window.DEFAULT_USER) ? (Number(window.DEFAULT_USER.diamonds) || 0) : (targetOwner.is_bot ? 50 : 0);

        // แจ้งเตือนคู่แข่งทันที
        this.showSkillBanner(`🚨 แจ้งเตือนภัยระเบิด! ${player.username} วางระเบิดที่ [${targetProv}] ของ ${targetOwner.username}!`);

        let defendMethod = 'SURRENDER'; // 'GOLD' | 'DIAMOND' | 'SURRENDER'

        const isOwnerAuto = Boolean(targetOwner.is_bot || !this.isLocalPlayer(targetOwner) || this.isAutoMode);
        if (isOwnerAuto) {
            if (ownerGold >= defendCost && (targetState.isLandmark || ownerGold >= defendCost * 1.6)) {
                defendMethod = 'GOLD';
            }
        } else if (ownerGold >= defendCost || userDiamonds >= defendDiamondCost) {
            const defOpts = [];
            if (ownerGold >= defendCost) {
                defOpts.push({
                    icon: '🪙',
                    label: 'ใช้ทองรักษาเมือง/แลนด์มาร์คไว้!',
                    costLabel: `-${this.formatCompactGold(defendCost)} ทอง 💰`,
                    subLabel: 'หักทองในกระดานเพื่อกู้ระเบิดและรักษาเมืองไว้',
                    value: 'GOLD',
                    className: 'recommended'
                });
            }
            if (userDiamonds >= defendDiamondCost) {
                defOpts.push({
                    icon: '💎',
                    label: 'ใช้เพชรรักษาเมือง/แลนด์มาร์คไว้!',
                    costLabel: `-${defendDiamondCost} เพชร 💎`,
                    subLabel: 'ใช้เพชรคุ้มครองเมืองและแลนด์มาร์คทันที',
                    value: 'DIAMOND',
                    className: ownerGold < defendCost ? 'recommended' : ''
                });
            }
            defOpts.push({
                icon: '💥',
                label: 'ยอมให้ระเบิดลบเมือง',
                costLabel: 'ไม่จ่าย (เสียเมืองนี้ทันที)',
                value: 'SURRENDER',
                className: 'skip-btn'
            });

            const defendChoice = await this.openCityActionPrompt({
                icon: '🚨',
                title: `แจ้งเตือน! [${targetProv}] กำลังถูกระเบิด!`,
                subtitle: `${player.username} วางระเบิดทำลาย ${targetLevelStr} ของคุณ! เลือกใช้ "ทอง" หรือ "เพชร" เพื่อรักษาไว้ได้ทันที`,
                defaultChoice: ownerGold >= defendCost ? 'GOLD' : (userDiamonds >= defendDiamondCost ? 'DIAMOND' : 'SURRENDER'),
                timeoutSec: 20,
                walletHtml: `<span>💰 ทองในกระดาน: <strong style="color:#fde047;">${ownerGold.toLocaleString()}</strong> | 💎 เพชร: <strong style="color:#38bdf8;">${userDiamonds.toLocaleString()}</strong></span>`,
                options: defOpts
            });
            if (defendChoice === 'GOLD' || defendChoice === 'DIAMOND') {
                defendMethod = defendChoice;
            }
        }

        if (defendMethod === 'GOLD' && ownerGold >= defendCost) {
            targetOwner.matchGold -= defendCost;
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`🛡️ ${targetOwner.username} ใช้ทอง -${this.formatCompactGold(defendCost)} กู้ระเบิดปกป้อง [${targetProv}] สำเร็จ!`);
            this.logMessage(`🛡️ ${targetOwner.username} ใช้ทอง ${defendCost.toLocaleString()} รักษา ${targetLevelStr} [${targetProv}] จากระเบิดสำเร็จ!`, 'highlight');
        } else if (defendMethod === 'DIAMOND' && userDiamonds >= defendDiamondCost) {
            if (!targetOwner.is_bot && window.DEFAULT_USER) {
                window.DEFAULT_USER.diamonds = Math.max(0, (Number(window.DEFAULT_USER.diamonds) || 0) - defendDiamondCost);
                if (typeof window.updateUserBar === 'function') window.updateUserBar(window.DEFAULT_USER);
                if (typeof window.syncUserProgress === 'function') {
                    try { window.syncUserProgress({ diamond_delta: -defendDiamondCost }); } catch (e) { }
                }
            }
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`💎🛡️ ${targetOwner.username} ใช้เพชร -${defendDiamondCost} 💎 ปกป้อง [${targetProv}] จากระเบิดสำเร็จ!`);
            this.logMessage(`💎🛡️ ${targetOwner.username} ใช้เพชร ${defendDiamondCost} 💎 รักษา ${targetLevelStr} [${targetProv}] จากระเบิดสำเร็จ!`, 'highlight');
        } else {
            // ทำลายล้างเมือง ลบออกจากกระดาน 3D ทันที!
            delete this.cityStates[targetTile];
            if (this.cityMeshes[targetTile]) {
                this.citiesGroup.remove(this.cityMeshes[targetTile]);
                delete this.cityMeshes[targetTile];
            }
            this.checkAndRefreshColorGroupBonus3D(targetTile, null);
            this.updateMonopolyVictoryWarningAuras();
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`💥 ตู้ม! เมือง [${targetProv}] ของ ${targetOwner.username} ถูกลบออกจากกระดานแล้ว!`);
            this.logMessage(`💥 สกิลสัมฤทธิ์ผล! ${player.username} ลบ ${targetLevelStr} [${targetProv}] ของ ${targetOwner.username} ออกจากกระดานเรียบร้อย!`, 'highlight');
        }
    }

    handleBankruptcy(bankruptPlayer, creditor = null, reason = '') {
        if (!bankruptPlayer || bankruptPlayer.isBankrupt) return;
        bankruptPlayer.isBankrupt = true;
        bankruptPlayer.matchGold = 0;
        if (bankruptPlayer.mesh) {
            bankruptPlayer.mesh.visible = false;
        }

        // คืนเมืองของผู้ล้มละลายออกจากกระดานให้ว่างสำหรับคนอื่นสร้างใหม่
        for (const key of Object.keys(this.cityStates)) {
            const tNum = Number(key);
            if (this.cityStates[tNum] && String(this.cityStates[tNum].ownerId) === String(bankruptPlayer.id)) {
                delete this.cityStates[tNum];
                if (this.cityMeshes[tNum]) {
                    this.citiesGroup.remove(this.cityMeshes[tNum]);
                    delete this.cityMeshes[tNum];
                }
                this.checkAndRefreshColorGroupBonus3D(tNum, null);
            }
        }
        this.updateMonopolyVictoryWarningAuras();

        this.updateMatchWealthHUD();

        // ตรวจสอบว่าเหลือผู้รอดชีวิตเพียง 1 คน (หรือ 1 ทีมในโหมด 2v2) หรือไม่
        const alivePlayers = this.players.filter(p => !p.isBankrupt);
        if (alivePlayers.length === 1) {
            this.handleVictory(alivePlayers[0], 'BANKRUPTCY');
            return;
        }

        const isTeamGame = alivePlayers.length > 0 && alivePlayers.every(p => p.team && p.team !== 'NONE');
        if (isTeamGame) {
            const aliveTeams = new Set(alivePlayers.map(p => p.team));
            if (aliveTeams.size === 1) {
                this.handleVictory(alivePlayers[0], 'BANKRUPTCY');
                return;
            }
        }
    }

    async handleGambleTile(player) {
        this.showSkillBanner(`🎰 ${player.username} ตกช่องเสี่ยงโชค! ลุ้นรับเพชรและทองคำ`);
        const isAuto = Boolean(this.isAutoMode || player.is_bot);
        if (!player.is_bot && typeof window.openLuckyGambleModal === 'function') {
            this.isWaitingForGamble = true;
            try {
                await window.openLuckyGambleModal(player, isAuto);
            } catch (e) {
                console.warn('Lucky gamble modal error:', e);
            }
            this.isWaitingForGamble = false;
        } else {
            const rewardPool = [
                { label: '💎 50 เพชร', diamond_delta: 50 },
                { label: '🪙 5,000 ทอง', gold_delta: 5000 },
                { label: '🪙 10,000 ทอง', gold_delta: 10000 },
                { label: '💎 20 เพชร', diamond_delta: 20 }
            ];
            const picked = rewardPool[Math.floor(Math.random() * rewardPool.length)];
            this.logMessage(`🎰 ${player.username}${(!player.is_bot && this.isAutoMode) ? ' ⚡[AUTO]' : ''} หมุนวงล้อเสี่ยงโชคได้รับ ${picked.label}!`, 'highlight');
            if (!player.is_bot && !window.isPracticeMatch && typeof window.syncUserProgress === 'function') {
                try { await window.syncUserProgress(picked); } catch (e) { }
            }
        }
    }

    /**
     * เปลี่ยนสกินลูกเต๋า 3D ตาม preset (window.DICE_SKIN_PRESETS)
     */
    applyDiceSkin(skinKey) {
        const presets = window.DICE_SKIN_PRESETS || {};
        const preset = presets[skinKey] || presets['ClassicWoodDice'];
        if (!preset || this.currentDiceSkin === skinKey) return;
        this.currentDiceSkin = skinKey;

        const pipConfigs = {
            1: [[0.5, 0.5]],
            2: [[0.25, 0.25], [0.75, 0.75]],
            3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
            4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
            5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
            6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
        };
        const mats = [1, 6, 2, 5, 3, 4].map(num => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const ctx = canvas.getContext('2d');
            const colors = preset.bgGradient || ['#ffffff', '#e2e8f0'];
            const grad = ctx.createLinearGradient(0, 0, 256, 256);
            colors.forEach((c, i) => grad.addColorStop(colors.length === 1 ? 0 : i / (colors.length - 1), c));
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 256, 256);
            ctx.strokeStyle = preset.borderColor || '#cbd5e1';
            ctx.lineWidth = preset.borderWidth || 12;
            ctx.strokeRect(6, 6, 244, 244);
            ctx.fillStyle = num === 1 ? (preset.pipOneColor || '#ef4444') : (preset.pipColor || '#0f172a');
            pipConfigs[num].forEach(([px, py]) => {
                ctx.beginPath();
                ctx.arc(px * 256, py * 256, num === 1 ? 32 : 22, 0, Math.PI * 2);
                ctx.fill();
            });
            return new THREE.MeshStandardMaterial({
                map: new THREE.CanvasTexture(canvas),
                roughness: preset.roughness ?? 0.15,
                metalness: preset.metalness ?? 0.1,
                emissive: preset.emissive || 0x000000,
                emissiveIntensity: 0.4
            });
        });
        this.diceMaterials = mats;
        if (this.diceMesh1) this.diceMesh1.material = mats;
        if (this.diceMesh2) this.diceMesh2.material = mats;
    }

    applyDiceSkinForPlayer(player) {
        if (!player) return;
        try { this.applyDiceSkin(player.dice_skin || 'ClassicWoodDice'); } catch (e) { console.warn('applyDiceSkin error:', e); }
    }

    saveActiveSession() {
        this.saveGameState();
    }

    restoreSavedSession(saved) {
        try {
            if (saved && typeof saved === 'object') {
                if (saved.boardLayout && typeof this.setBoardLayout === 'function') {
                    this.boardLayout = saved.boardLayout;
                }
                if (saved.tileProvinces) this.tileProvinces = saved.tileProvinces;
                if (saved.boardTheme && this.themes[saved.boardTheme]) this.boardTheme = saved.boardTheme;
                this.buildBoard();
                const json = JSON.stringify(saved);
                localStorage.setItem('snake_active_session', json);
                try { sessionStorage.setItem('snake_active_session_backup', json); } catch (e) { }
            }
        } catch (e) { }
        return this.restoreGameState();
    }

    /**
     * เอฟเฟกต์กระตุ้นเมืองและช่องกระดานนูนขึ้น (Step Pop / Bounce) เมื่อตัวละครวิ่งผ่าน
     */
    triggerTileStepPop(t) {
        const tileNum = Number(t);
        if (!tileNum || tileNum < 1 || tileNum > 100) return;

        // 1. นูนตึกเมือง & แลนด์มาร์ค
        if (this.cityMeshes && this.cityMeshes[tileNum]) {
            const cityGrp = this.cityMeshes[tileNum];
            if (cityGrp.userData && cityGrp.userData.cityAnim) {
                const ca = cityGrp.userData.cityAnim;
                if (ca.basePosY === undefined) ca.basePosY = cityGrp.position.y;
                ca.stepPopProgress = 0;
            }
        }

        // 2. นูนช่องกระดานพื้น
        if (this.tileMeshes && this.tileMeshes[tileNum]) {
            const tm = this.tileMeshes[tileNum];
            if (!tm.userData) tm.userData = {};
            if (tm.userData.origY === undefined) tm.userData.origY = tm.position.y;
            tm.userData.stepPopProgress = 0;
        }

        // เสียงป็อปเมื่อเหยียบผ่าน
        if (window.soundEngine && typeof window.soundEngine.playCityPop === 'function') {
            window.soundEngine.playCityPop();
        }
    }

    /**
     * ตรวจสอบระยะ 5-8 เมืองก่อนถึงเส้นชัย (ช่อง 92-99) เพื่อแจ้งเตือนคู่แข่งและแสดงแสงเออร่าพิเศษ
     */
    checkNearFinishAlerts() {
        if (!this.isMatchActive || this.isGameOver || !this.players) return;
        this.nearFinishAlerted = this.nearFinishAlerted || {};

        for (const p of this.players) {
            if (p.isBankrupt) continue;
            if (p.currentTile >= 92 && p.currentTile < 100) {
                const rem = 100 - p.currentTile;
                const lastAlerted = this.nearFinishAlerted[p.id];
                if (lastAlerted !== p.currentTile) {
                    this.nearFinishAlerted[p.id] = p.currentTile;
                    if (p.is_bot) {
                        this.showSkillBanner(`🚨 สัญญาณเตือนภัย! คู่แข่ง "${p.username}" ใกล้ถึงเส้นชัยแล้ว! (เหลืออีก ${rem} ช่อง)`, 'near-finish');
                        this.logMessage(`🚨 [สัญญาณเตือน] คู่แข่ง ${p.username} อยู่ห่างจากเส้นชัยเพียง ${rem} เมือง! ระวังโดนคว้าชัยชนะ!`, 'highlight');
                    } else {
                        this.showSkillBanner(`⚡ โอกาสคว้าชัย! คุณใกล้ถึงเส้นชัยแล้ว! (เหลืออีก ${rem} ช่อง)`, 'near-finish');
                        this.logMessage(`⚡ ${p.username} กำลังพุ่งทะยานสู่เส้นชัย! เหลืออีกเพียง ${rem} เมือง!`, 'highlight');
                    }
                    if (window.soundEngine && typeof window.soundEngine.playNearFinish === 'function') {
                        window.soundEngine.playNearFinish();
                    }
                    this.updateMatchWealthHUD();
                }
            }
        }
    }

    // =========================================================================
    // 💎 GEM & CUSTOM SKILL ENGINE (โล่คุ้มกัน 1-3 ชั้น, กันเตะ, กันดูดเงิน, ฯลฯ)
    // =========================================================================
    getPlayerEquippedGems(player) {
        if (!player) return [];
        if (player.equippedGems && Array.isArray(player.equippedGems) && player.equippedGems.length > 0) {
            return player.equippedGems;
        }
        if (player.equipped_gems && Array.isArray(player.equipped_gems) && player.equipped_gems.length > 0) {
            return player.equipped_gems;
        }
        if (this.isLocalPlayer(player)) {
            if (typeof window.getEquippedGemsList === 'function') {
                const list = window.getEquippedGemsList();
                if (Array.isArray(list) && list.length > 0) {
                    player.equippedGems = list;
                    player.equipped_gems = list;
                    return list;
                }
            }
            if (window.playerGemsData && window.playerGemsData.equippedSlots) {
                const slots = Array.isArray(window.playerGemsData.equippedSlots)
                    ? window.playerGemsData.equippedSlots.filter(Boolean)
                    : Object.values(window.playerGemsData.equippedSlots).filter(Boolean);
                if (slots.length > 0) {
                    player.equippedGems = slots;
                    player.equipped_gems = slots;
                    return slots;
                }
            }
            if (window.playerGemsData && Array.isArray(window.playerGemsData.ownedGems)) {
                const eq = window.playerGemsData.ownedGems.filter(g => Number(g.is_equipped) === 1);
                if (eq.length > 0) {
                    player.equippedGems = eq;
                    player.equipped_gems = eq;
                    return eq;
                }
            }
            if (Array.isArray(window.latestGemsList)) {
                const eq = window.latestGemsList.filter(g => Boolean(Number(g.is_equipped)));
                if (eq.length > 0) {
                    player.equippedGems = eq;
                    player.equipped_gems = eq;
                    return eq;
                }
            }
            if (Array.isArray(window.DEFAULT_USER?.equipped_gems) && window.DEFAULT_USER.equipped_gems.length > 0) {
                player.equippedGems = window.DEFAULT_USER.equipped_gems;
                player.equipped_gems = window.DEFAULT_USER.equipped_gems;
                return window.DEFAULT_USER.equipped_gems;
            }
        }
        // ผู้เล่นหรือบอทที่ไม่ได้ใส่อัญมณีมา จะไม่แสดงเอฟเฟกต์และไม่ทำงานสกิลอัญมณี
        return [];
    }

    getDefaultGemsForPlayer(player) {
        if (!player) return [];
        if (player._cachedDefaultGems && Array.isArray(player._cachedDefaultGems)) {
            return player._cachedDefaultGems;
        }
        const grade = String(player.char_grade || player.grade || player.character_grade || 'SS+').toUpperCase();
        const gemPool = [
            { id: 101, name: 'อัญมณีพิทักษ์เพนทากอน', shape: 'pentagon', grade: 'SS+', gem_color: '#c084fc', skill_name: 'โล่พิทักษ์ 3 ชั้น', trigger_rate_percent: 85, aura_type: 'pulse', particle_fx: 'spark' },
            { id: 102, name: 'เนบิวลาสตาร์เจม', shape: 'diamond', grade: 'SS+', gem_color: '#38bdf8', skill_name: 'ก้าวกระโดดดับเบิ้ล', trigger_rate_percent: 80, aura_type: 'pulse', particle_fx: 'spark' },
            { id: 103, name: 'อัคนีเพลิงรูบี้', shape: 'hexagon', grade: 'S+', gem_color: '#f43f5e', skill_name: 'ดูดทรัพย์คู่แข่ง', trigger_rate_percent: 75, aura_type: 'pulse', particle_fx: 'spark' }
        ];
        let count = 3;
        if (grade === 'S+') count = 2;
        else if (grade === 'S') count = 1;
        else if (grade === 'A+' || grade === 'A') count = 1;
        player._cachedDefaultGems = gemPool.slice(0, count);
        return player._cachedDefaultGems;
    }

    parseGemEffects(gem) {
        if (!gem) return {};
        let effects = {};
        if (gem.skill_effects_json) {
            try {
                effects = typeof gem.skill_effects_json === 'string' ? JSON.parse(gem.skill_effects_json) : gem.skill_effects_json;
            } catch (e) { }
        }
        if (!effects || typeof effects !== 'object') effects = {};

        const desc = ((gem.skill_description || '') + ' ' + (gem.skill_name || '') + ' ' + (gem.name || '')).toLowerCase();
        const cat = (gem.skill_category || '').toUpperCase();

        if (!effects.pass_kick && (cat === 'PASS_OPPONENT_KICK' || /เตะส่ง|ข้ามมิติ|ก้าวผ่าน|สะบัดหาง|ดีดตัว|ผลักไส|pass.*kick|ผลักคู่แข่ง|เตะคู่แข่ง/i.test(desc))) {
            effects.pass_kick = true;
        }
        if (!effects.pull_opponents_line && !effects.pull_opponents_4 && !effects.pull_opponents_6) {
            if (cat === 'MAGNETIC_PULL' || cat === 'PULL_OPPONENTS' || /ดึงดูด|แม่เหล็ก|ดูดคู่แข่ง|ดูดดาว|ดึงคู่แข่ง|magnetic|pull/i.test(desc)) {
                effects.pull_opponents_line = true;
                effects.pull_opponents_6 = true;
                effects.pull_opponents_4 = true;
            }
        }
        if (!effects.block_city && (cat === 'BLOCK_CITY' || /กั้นทาง|ยกเมือง|ปราการ|กำแพงเมือง/i.test(desc))) {
            effects.block_city = true;
        }
        if (!effects.dice_double && (cat === 'DICE_DOUBLE' || /ทอยเบิ้ล|แต้มเบิ้ล|ดับเบิ้ล/i.test(desc))) {
            effects.dice_double = true;
            const pctMatch = desc.match(/(\d+)\s*%/);
            effects.dice_double_salary_pct = pctMatch ? Math.max(50, Math.min(1000, parseInt(pctMatch[1], 10))) : 200;
        }

        if (!effects.shield_on_roll && (/สร้างโล่|โล่|เกราะ|shield/i.test(desc))) {
            effects.shield_on_roll = true;
            effects.shield_min = 1;
            effects.shield_max = 3;
            const match = desc.match(/(\d+)\s*[-–ถึง]\s*(\d+)\s*ชั้น/);
            if (match) {
                effects.shield_min = parseInt(match[1]) || 1;
                effects.shield_max = parseInt(match[2]) || 3;
            }
        }
        if (!effects.immune_kick && (/ป้องกันการเตะ|กันเตะ|ไม่โดนดึง|ต้านการเตะ/i.test(desc))) {
            effects.immune_kick = true;
        }
        if (!effects.immune_steal && (/ป้องกันการดูดเงิน|กันดูดเงิน|กันขโมย|ป้องกันการขโมย/i.test(desc))) {
            effects.immune_steal = true;
        }
        if (!effects.immune_snake && (/ป้องกันงู|คุ้มกันหัวงู|กันงู/i.test(desc) || cat === 'SHIELD_SNAKE')) {
            effects.immune_snake = true;
        }
        if (!effects.steal_gold && (/ดูดเงิน|ขโมยทอง|ปล้นทอง/i.test(desc) || cat === 'STEAL_GOLD')) {
            effects.steal_gold = true;
        }
        if (!effects.toll_discount && (/ส่วนลดค่าผ่านทาง|ลดค่าผ่านทาง/i.test(desc) || cat === 'TOLL_DISCOUNT')) {
            effects.toll_discount = true;
        }
        if (!effects.pull_opponents_4 && (/4 ช่อง|4ช่อง|ดึง 4/i.test(desc))) {
            effects.pull_opponents_4 = true;
        }
        if (!effects.pull_opponents_6 && (/6 ช่อง|6ช่อง|ดึง 6/i.test(desc))) {
            effects.pull_opponents_6 = true;
        }
        if (!effects.pull_opponents_line && (/ในแถว|ทั้งแถว/i.test(desc))) {
            effects.pull_opponents_line = true;
        }
        if (!effects.black_hole_generator && (/หลุมดำ|black hole|blackhole/i.test(desc))) {
            effects.black_hole_generator = true;
        }
        if (!effects.instant_landmark_3city && (/3 เมือง|3เมือง|กระโดด|เสกแลนด์มาร์ค/i.test(desc))) {
            effects.instant_landmark_3city = true;
        }
        if (!effects.toll_multiplier_random && (/12|x12|คูณ 12|คูณ12|ตัวคูณ|คูณ 8|คูณ 2|คูณ2/i.test(desc))) {
            effects.toll_multiplier_random = true;
        }
        if (!effects.forward_backward_move && (cat === 'FORWARD_BACKWARD_MOVE' || /ทอยหน้า.*หลัง|เดินหน้า.*ถอยหลัง|หน้าหลัง.*เดิน|forward.*backward/i.test(desc))) {
            effects.forward_backward_move = true;
        }
        return effects;
    }

    getGemScaledRate(baseRate, maxRate, level = 1) {
        const lv = Math.max(1, Math.min(30, parseInt(level, 10) || 1));
        const maxR = Math.max(1, Math.min(100, parseFloat(maxRate) || 90));
        const baseR = (baseRate !== undefined && baseRate !== null && !isNaN(parseFloat(baseRate)))
            ? Math.max(1, Math.min(maxR, parseFloat(baseRate)))
            : Math.max(10, Math.round(maxR * 0.45));
        if (lv >= 30) return Math.round(maxR);
        return Math.round(baseR + ((maxR - baseR) * (lv - 1)) / 29);
    }

    aggregateGemEffects(gems) {
        const agg = {
            shield_on_roll: false,
            shield_rate: 90,
            shield_min: 1,
            shield_max: 3,
            immune_kick: false,
            immune_steal: false,
            immune_snake: false,
            steal_gold: false,
            toll_discount: false,
            pull_opponents_4: false,
            pull_opponents_6: false,
            pull_opponents_line: false,
            black_hole_generator: false,
            instant_landmark_3city: false,
            toll_multiplier_random: false,
            pull_rate: 90,
            black_hole_rate: 80,
            instant_landmark_rate: 85,
            pass_kick: false,
            pass_kick_rate: 90,
            block_city: false,
            block_city_rate: 90,
            dice_double: false,
            dice_double_rate: 75,
            forward_backward_move: false,
            forward_backward_rate: 50,
            forward_backward_gem_level: 1
        };
        if (!Array.isArray(gems) || gems.length === 0) return agg;
        gems.forEach(g => {
            const gemLv = Math.max(1, Math.min(30, parseInt(g.level, 10) || 1));
            const grade = String(g.grade || 'S').toUpperCase();
            const maxSlots = (grade === 'ZZ+') ? 3 : ((grade === 'ZZ' || grade === 'SS+') ? 2 : 1);
            let rawEff = this.parseGemEffects(g);
            let chosenName = g.skill_name || g.name;
            let rate = this.getGemScaledRate(rawEff.base_rate, g.trigger_rate_percent || g.rate || 90, gemLv);

            // หากอัญมณีมีหลายสกิล (เช่น SS+/ZZ = 2 สกิล, ZZ+ = 3 สกิล) ให้ระบบสุ่มออก 1 สกิลพร้อม % ตามเลเวล
            if (Array.isArray(rawEff.skills) && rawEff.skills.length > 1) {
                const pool = rawEff.skills.slice(0, maxSlots);
                const pickedSk = pool[Math.floor(Math.random() * pool.length)];
                if (pickedSk) {
                    chosenName = pickedSk.name || chosenName;
                    rate = this.getGemScaledRate(pickedSk.base_rate ?? rawEff.base_rate, pickedSk.max_rate ?? g.trigger_rate_percent ?? 90, gemLv);
                    rawEff = this.parseGemEffects({
                        ...g,
                        skill_category: pickedSk.category || g.skill_category,
                        skill_name: pickedSk.name || g.skill_name,
                        skill_description: pickedSk.description || g.skill_description,
                        skill_effects_json: null
                    });
                }
            }

            const eff = rawEff;
            if (eff.forward_backward_move) {
                agg.forward_backward_move = true;
                agg.forward_backward_rate = Math.max(agg.forward_backward_rate, rate);
                agg.forward_backward_name = chosenName;
                agg.forward_backward_gem_level = gemLv;
            }
            if (eff.shield_on_roll) {
                agg.shield_on_roll = true;
                agg.shield_rate = Math.max(agg.shield_rate, rate);
                agg.shield_name = g.skill_name || g.name;
                if (eff.shield_min) agg.shield_min = eff.shield_min;
                if (eff.shield_max) agg.shield_max = eff.shield_max;
            }
            if (eff.immune_kick) {
                agg.immune_kick = true;
                agg.immune_kick_name = g.skill_name || g.name;
            }
            if (eff.immune_steal) {
                agg.immune_steal = true;
                agg.immune_steal_name = g.skill_name || g.name;
            }
            if (eff.immune_snake) {
                agg.immune_snake = true;
                agg.immune_snake_name = g.skill_name || g.name;
            }
            if (eff.steal_gold) {
                agg.steal_gold = true;
                agg.steal_rate = rate;
                agg.steal_gold_name = g.skill_name || g.name;
            }
            if (eff.toll_discount) {
                agg.toll_discount = true;
            }
            if (eff.pass_kick) {
                agg.pass_kick = true;
                agg.pass_kick_rate = Math.max(agg.pass_kick_rate, rate);
                agg.pass_kick_name = g.skill_name || g.name;
            }
            if (eff.pull_opponents_4) {
                agg.pull_opponents_4 = true;
                agg.pull_rate = Math.max(agg.pull_rate, rate);
                agg.pull_name = g.skill_name || g.name;
            }
            if (eff.pull_opponents_6) {
                agg.pull_opponents_6 = true;
                agg.pull_rate = Math.max(agg.pull_rate, rate);
                agg.pull_name = g.skill_name || g.name;
            }
            if (eff.pull_opponents_line) {
                agg.pull_opponents_line = true;
                agg.pull_rate = Math.max(agg.pull_rate, rate);
                agg.pull_name = g.skill_name || g.name;
            }
            if (eff.block_city) {
                agg.block_city = true;
                agg.block_city_rate = Math.max(agg.block_city_rate, rate);
                agg.block_city_name = g.skill_name || g.name;
            }
            if (eff.dice_double) {
                agg.dice_double = true;
                agg.dice_double_rate = Math.max(agg.dice_double_rate, rate);
                agg.dice_double_name = chosenName || g.skill_name || g.name;
                agg.dice_double_salary_pct = Math.max(agg.dice_double_salary_pct || 0, eff.dice_double_salary_pct || 200);
            }
            if (eff.black_hole_generator) {
                agg.black_hole_generator = true;
                agg.black_hole_rate = Math.max(agg.black_hole_rate, rate);
            }
            if (eff.instant_landmark_3city) {
                agg.instant_landmark_3city = true;
                agg.instant_landmark_rate = Math.max(agg.instant_landmark_rate, rate);
            }
            if (eff.toll_multiplier_random) {
                agg.toll_multiplier_random = true;
            }
        });
        return agg;
    }

    triggerGemDoubleRollSalarySkill(player) {
        if (!player || player.isBankrupt || this.isGameOver) return;
        const gems = this.getPlayerEquippedGems(player);
        if (!Array.isArray(gems) || gems.length === 0) return;

        let bestMatch = null;
        gems.forEach(g => {
            const gemLv = Math.max(1, Math.min(30, parseInt(g.level, 10) || 1));
            const grade = String(g.grade || 'S').toUpperCase();
            const maxSlots = (grade === 'ZZ+') ? 3 : ((grade === 'ZZ' || grade === 'SS+') ? 2 : 1);
            const baseEff = this.parseGemEffects(g);

            const checkSkill = (eff, skName, baseR, maxR) => {
                if (!eff || !eff.dice_double) return;
                const rate = this.getGemScaledRate(baseR, maxR, gemLv);
                const pct = eff.dice_double_salary_pct || 200;
                if (!bestMatch || rate > bestMatch.rate) {
                    bestMatch = { rate, pct, name: skName || g.skill_name || g.name, gem: g };
                }
            };

            if (Array.isArray(baseEff.skills) && baseEff.skills.length > 0) {
                baseEff.skills.slice(0, maxSlots).forEach(sk => {
                    const skEff = this.parseGemEffects({
                        ...g,
                        skill_category: sk.category || g.skill_category,
                        skill_name: sk.name || g.skill_name,
                        skill_description: sk.description || g.skill_description,
                        skill_effects_json: null
                    });
                    checkSkill(skEff, sk.name, sk.base_rate ?? baseEff.base_rate, sk.max_rate ?? g.trigger_rate_percent ?? 90);
                });
            } else {
                checkSkill(baseEff, g.skill_name || g.name, baseEff.base_rate, g.trigger_rate_percent || g.rate || 90);
            }
        });

        if (!bestMatch) return;
        if (Math.random() * 100 >= bestMatch.rate) return;

        const salaryGold = (window.GAME_RULES && window.GAME_RULES.lap_salary_gold !== undefined)
            ? Number(window.GAME_RULES.lap_salary_gold)
            : 200000;
        const bonusGold = Math.max(0, Math.round(salaryGold * (bestMatch.pct / 100)));
        if (bonusGold <= 0) return;

        player.matchGold = (player.matchGold || 0) + bonusGold;
        this.updateMatchWealthHUD();

        const msg = `💎 สกิลอัญมณี [${bestMatch.name}]! ทอยเบิ้ลรับทอง ${bestMatch.pct}% ของเงินผ่านจุดสตาร์ท (+${bonusGold.toLocaleString()} ทอง)`;
        if (typeof this.showFloatingGemSkillBanner === 'function') {
            this.showFloatingGemSkillBanner(player, bestMatch.gem, bestMatch.name, `+${bonusGold.toLocaleString()} ทอง (${bestMatch.pct}%)`);
        } else if (typeof this.showSkillBanner === 'function') {
            this.showSkillBanner(msg);
        }
        this.logMessage(msg, 'highlight');
        if (window.soundEngine && typeof window.soundEngine.playCoins === 'function') {
            window.soundEngine.playCoins();
        } else if (window.soundEngine && typeof window.soundEngine.playCash === 'function') {
            window.soundEngine.playCash();
        }
    }

    triggerGemSkillsOnRoll(player) {
        if (!player) return;
        const gems = this.getPlayerEquippedGems(player);
        if (!gems || gems.length === 0) return;

        const eff = this.aggregateGemEffects(gems);

        // 1. เสกโล่คุ้มกันเมื่อทอยเต๋า (ทอย 1 ครั้งสร้างได้ 1 ขั้น สูงสุดไม่เกิน 2 ขั้น)
        if (eff.shield_on_roll) {
            const currentLayers = Number(player.shieldLayers || 0);
            if (currentLayers < 2) {
                const rate = eff.shield_rate || 85;
                if (Math.random() * 100 < rate) {
                    const added = 1;
                    player.shieldLayers = Math.min(2, currentLayers + added);

                    this.createOrUpdatePawnShieldVisual(player);
                    this.triggerShieldPulseEffect(player);

                    const gemTitle = eff.shield_name || 'อัญมณีพิทักษ์';
                    this.showSkillBanner(`🛡️ สกิล [${gemTitle}] ทำงาน (${rate}%)! เสกโล่คุ้มกัน +${added} ขั้น (รวม ${player.shieldLayers}/2 ขั้น)!`);
                    this.logMessage(`🛡️ สกิลอัญมณีของ ${player.username} ทำงาน (${rate}%)! เสกม่านพลังโล่คุ้มกัน +${added} ขั้น (ปัจจุบันมี ${player.shieldLayers}/2 ขั้น)!`, 'skill');

                    if (window.soundEngine && typeof window.soundEngine.playBuyoutCity === 'function') {
                        window.soundEngine.playBuyoutCity();
                    }
                }
            }
        }
    }

    async checkAndTriggerPassKick(player, stepTile) {
        if (!player || player.isBankrupt || this.isGameOver || !stepTile || stepTile <= 1) return;
        if (!this.canUseAttackSkillsAgainstOpponents(player)) return;
        const gems = this.getPlayerEquippedGems(player);
        if (!gems || gems.length === 0) return;
        const eff = this.aggregateGemEffects(gems);
        if (!eff.pass_kick) return;

        // ค้นหาคู่แข่งที่อยู่ในช่องนี้ (stepTile)
        const opponents = (this.players || []).filter(p =>
            p && p.id !== player.id && !p.isBankrupt && p.currentTile === stepTile
        );
        if (opponents.length === 0) return;

        const rate = eff.pass_kick_rate || 90;
        const rollChance = Math.random() * 100;
        if (rollChance >= rate) {
            console.log(`[PassKick] Rate check: rolled ${rollChance.toFixed(1)}% >= ${rate}% -> Not triggered`);
            return;
        }

        for (const opp of opponents) {
            if (player.team && player.team !== 'NONE' && player.team === opp.team) continue;
            if (this.isStartProtected(opp)) {
                this.showSkillBanner(`🛡️ โล่จุดเริ่มต้นของ ${opp.username} ป้องกันการถูกดีดตัวสำเร็จ!`);
                this.triggerShieldPulseEffect(opp);
                continue;
            }

            const oppGems = this.getPlayerEquippedGems(opp);
            const oppEff = this.aggregateGemEffects(oppGems);

            if (oppEff.immune_kick) {
                this.showSkillBanner(`🛡️ สกิล [${oppEff.immune_kick_name || 'ป้องกันการเตะ'}] ของ ${opp.username} ทำงาน! ป้องกันการถูกเตะได้ 100%!`);
                this.logMessage(`🛡️ ${opp.username} มีสกิลป้องกันการเตะ ป้องกันการถูกดีดตัวของ ${player.username} สำเร็จ!`, 'skill');
                this.triggerShieldPulseEffect(opp);
                continue;
            }
            if (opp.shieldLayers && opp.shieldLayers > 0) {
                opp.shieldLayers--;
                this.createOrUpdatePawnShieldVisual(opp);
                this.showSkillBanner(`🛡️ ม่านพลังโล่ของ ${opp.username} สลายแรงกระแทก! ป้องกันการถูกเตะสำเร็จ! (เหลือโล่ ${opp.shieldLayers} ชั้น)`);
                this.logMessage(`🛡️ โล่ของ ${opp.username} ป้องกันการถูกสะบัดหางดีดตัวสำเร็จ (เหลือโล่ ${opp.shieldLayers} ชั้น)`, 'skill');
                this.triggerShieldPulseEffect(opp);
                continue;
            }

            // ค้นหาแลนด์มาร์คของผู้เล่น
            const myLandmarks = Object.keys(this.cityStates || {})
                .map(Number)
                .filter(t => {
                    const st = this.cityStates[t];
                    return st && String(st.ownerId) === String(player.id) && (st.isLandmark || st.level >= 4);
                });

            let targetLandmarkTile = null;
            if (myLandmarks.length > 0) {
                targetLandmarkTile = myLandmarks[Math.floor(Math.random() * myLandmarks.length)];
            } else {
                // หากยังไม่มีแลนด์มาร์ค ให้หาเมืองของผู้เล่นที่มีค่าผ่านทางสูงสุด
                const myCities = Object.keys(this.cityStates || {})
                    .map(Number)
                    .filter(t => this.cityStates[t] && String(this.cityStates[t].ownerId) === String(player.id));
                if (myCities.length > 0) {
                    myCities.sort((a, b) => this.getTileToll(b) - this.getTileToll(a));
                    targetLandmarkTile = myCities[0];
                } else {
                    targetLandmarkTile = Math.max(1, opp.currentTile - 8);
                }
            }

            const skillTitle = eff.pass_kick_name || 'เตะส่งข้ามมิติลงเมืองแพง';
            const provName = this.getProvinceName(targetLandmarkTile);

            this.showSkillBanner(`🌪️ สกิล [${skillTitle}] (${rate}%)! ${player.username} สะบัดหางดีดตัว ${opp.username} ข้ามมิติไปตก [${provName}] (จ่ายค่าผ่านทาง 2 เท่า)!`);
            this.logMessage(`🌪️ มหาเวทย์ [${skillTitle}] ทำงาน (${rate}%)! ${player.username} ก้าวผ่านช่อง ${stepTile} ดีด ${opp.username} ลอยข้ามมิติไปตก [${provName}] ช่อง ${targetLandmarkTile} และจ่ายค่าผ่านทาง 2 เท่า!`, 'skill');

            if (window.soundEngine && typeof window.soundEngine.playWarp === 'function') {
                window.soundEngine.playWarp();
            } else if (window.soundEngine && typeof window.soundEngine.playDiceLand === 'function') {
                window.soundEngine.playDiceLand();
            }

            await this.animatePawnToTile(opp, targetLandmarkTile, 850);
            opp.currentTile = targetLandmarkTile;
            this.showLandingPin(targetLandmarkTile);

            if (this.isBuildableTile(targetLandmarkTile)) {
                await this.handleCityTileLanding(opp, { isPostBounce: true, allowBuyout: false, tollMultiplier: 2 });
            }
        }
    }

    createOrUpdatePawnShieldVisual(player) {
        if (!player || !player.mesh) return;
        const ud = player.mesh.userData;
        if (!ud) return;

        const startProt = this.isStartProtected(player);
        const count = player.shieldLayers || 0;
        const hasShield = count > 0 || startProt;
        const badgeLabel = count > 0 ? `🛡️ x${count}` : '🛡️ START';
        const auraHex = count >= 2 ? 0xfacc15 : (startProt && count === 0 ? 0x22d3ee : 0x38bdf8);
        const haloHex = count >= 2 ? 0xfde047 : (startProt && count === 0 ? 0x34d399 : 0x38bdf8);

        if (hasShield) {
            if (!ud.shieldGroup) {
                const shieldGroup = new THREE.Group();
                shieldGroup.position.set(0, 1.45, 0);

                // ทรงกลมม่านพลังเรืองแสง
                const shieldGeo = new THREE.SphereGeometry(1.65, 24, 24);
                const shieldMat = new THREE.MeshStandardMaterial({
                    color: 0x38bdf8,
                    emissive: 0x0284c7,
                    emissiveIntensity: 0.75,
                    transparent: true,
                    opacity: 0.55,
                    roughness: 0.15,
                    metalness: 0.85,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                const shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
                shieldGroup.add(shieldMesh);
                ud.shieldMesh = shieldMesh;

                // แสงเออร่าของโล่ห์ชั้นนอก (Shield Outer Aura Glow)
                const auraGeo = new THREE.SphereGeometry(2.05, 24, 24);
                const auraMat = new THREE.MeshBasicMaterial({
                    color: auraHex,
                    transparent: true,
                    opacity: count >= 2 ? 0.28 : 0.22,
                    blending: THREE.AdditiveBlending,
                    depthWrite: false,
                    side: THREE.BackSide
                });
                const auraMesh = new THREE.Mesh(auraGeo, auraMat);
                shieldGroup.add(auraMesh);
                ud.shieldAuraMesh = auraMesh;

                // วงแหวนเออร่าเรืองแสงรอบฐานโล่
                const haloGeo = new THREE.RingGeometry(1.75, 2.2, 32);
                const haloMat = new THREE.MeshBasicMaterial({
                    color: haloHex,
                    transparent: true,
                    opacity: 0.65,
                    blending: THREE.AdditiveBlending,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                const haloMesh = new THREE.Mesh(haloGeo, haloMat);
                haloMesh.rotation.x = Math.PI / 2;
                haloMesh.position.y = -0.95;
                shieldGroup.add(haloMesh);
                ud.shieldHaloMesh = haloMesh;

                // วงแหวนเวทย์มนตร์ 6 เหลี่ยมหมุนรอบ
                const ringGeo = new THREE.RingGeometry(1.35, 1.65, 6);
                const ringMat = new THREE.MeshBasicMaterial({
                    color: 0x7dd3fc,
                    transparent: true,
                    opacity: 0.85,
                    side: THREE.DoubleSide
                });
                const ringMesh = new THREE.Mesh(ringGeo, ringMat);
                ringMesh.rotation.x = Math.PI / 2;
                shieldGroup.add(ringMesh);

                // ป้ายลอยแสดงจำนวนชั้นของโล่ (🛡️ xN)
                const badgeCanvas = document.createElement('canvas');
                badgeCanvas.width = 256;
                badgeCanvas.height = 96;
                const bCtx = badgeCanvas.getContext('2d');
                bCtx.fillStyle = count > 0 ? '#38bdf8' : '#34d399';
                bCtx.font = 'bold 40px sans-serif';
                bCtx.textAlign = 'center';
                bCtx.fillText(badgeLabel, 128, 62);

                const bTex = new THREE.CanvasTexture(badgeCanvas);
                const bSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: bTex, transparent: true, depthTest: false }));
                bSprite.scale.set(2.4, 0.9, 1);
                bSprite.position.set(0, 1.95, 0);
                shieldGroup.add(bSprite);

                ud.shieldBadgeSprite = bSprite;
                ud.shieldBadgeCanvas = badgeCanvas;

                player.mesh.add(shieldGroup);
                ud.shieldGroup = shieldGroup;
            } else {
                ud.shieldGroup.visible = true;
                if (ud.shieldAuraMesh && ud.shieldAuraMesh.material) {
                    ud.shieldAuraMesh.material.color.setHex(auraHex);
                    ud.shieldAuraMesh.material.opacity = count >= 2 ? 0.28 : 0.22;
                }
                if (ud.shieldHaloMesh && ud.shieldHaloMesh.material) {
                    ud.shieldHaloMesh.material.color.setHex(haloHex);
                }
                if (ud.shieldBadgeCanvas) {
                    const bCtx = ud.shieldBadgeCanvas.getContext('2d');
                    bCtx.clearRect(0, 0, 256, 96);
                    bCtx.fillStyle = count > 0 ? '#38bdf8' : '#34d399';
                    bCtx.font = 'bold 40px sans-serif';
                    bCtx.textAlign = 'center';
                    bCtx.fillText(badgeLabel, 128, 62);
                    if (ud.shieldBadgeSprite?.material?.map) {
                        ud.shieldBadgeSprite.material.map.needsUpdate = true;
                    }
                }
            }
        } else {
            if (ud.shieldGroup) {
                ud.shieldGroup.visible = false;
            }
        }
    }

    triggerShieldPulseEffect(player) {
        if (!player || !player.mesh) return;
        const ud = player.mesh.userData;
        if (!ud || !ud.shieldGroup) return;

        ud.shieldGroup.visible = true;
        const origScale = 1.0;
        ud.shieldGroup.scale.set(1.35, 1.35, 1.35);
        if (ud.shieldMesh && ud.shieldMesh.material) {
            ud.shieldMesh.material.opacity = 0.95;
            ud.shieldMesh.material.emissiveIntensity = 1.8;
        }

        setTimeout(() => {
            if (ud.shieldGroup) {
                ud.shieldGroup.scale.set(origScale, origScale, origScale);
                if (ud.shieldMesh && ud.shieldMesh.material) {
                    ud.shieldMesh.material.opacity = 0.55;
                    ud.shieldMesh.material.emissiveIntensity = 0.75;
                }
                if ((!player.shieldLayers || player.shieldLayers <= 0) && !this.isStartProtected(player)) {
                    ud.shieldGroup.visible = false;
                }
            }
        }, 500);
    }

    updatePlayerGems(equippedList) {
        const finalEquipped = Array.isArray(equippedList) ? equippedList : [];
        if (!this.players || this.players.length === 0) {
            if (this.pawnsGroup && this.pawnsGroup.children.length > 0) {
                const pawn = this.pawnsGroup.children[0];
                if (pawn && pawn.userData) {
                    pawn.userData.equippedGems = finalEquipped;
                    this.rebuildSideGems3D(pawn, finalEquipped);
                    this.refreshPawnAvatarTexture(pawn);
                }
            }
            return;
        }
        const localPlayer = this.players.find(p => this.isLocalPlayer(p)) || this.players[0];
        if (localPlayer) {
            localPlayer.equippedGems = finalEquipped;
            localPlayer.equipped_gems = finalEquipped;
            this.rebuildGemOrbit3D(localPlayer);
            if (localPlayer.mesh && localPlayer.mesh.userData) {
                localPlayer.mesh.userData.equippedGems = finalEquipped;
                this.rebuildSideGems3D(localPlayer.mesh, finalEquipped);
                this.refreshPawnAvatarTexture(localPlayer.mesh);
            }
        }
    }

    /**
     * รีเฟรชภาพโปรไฟล์และอัญมณีบนการ์ดตัวหมากของผู้เล่น
     */
    refreshPawnAvatarTexture(pawnGroup) {
        if (!pawnGroup || !pawnGroup.userData) return;
        const ud = pawnGroup.userData;
        this.applyAvatarTextureToPawn(
            pawnGroup,
            ud.avatarUrl || '',
            ud.username || '',
            ud.colorHex || 0x00e5ff,
            Boolean(ud.isBot),
            ud.provider || '',
            ud.character_grade || null,
            ud.aura_type || null,
            ud.equippedGems || null
        );
    }

    /**
     * สร้างและอัปเดตเอฟเฟกต์อัญมณี 3D ข้างกรอบการ์ดตัวหมาก (Side Card Gem Sockets 3D)
     */
    rebuildSideGems3D(pawnGroup, equippedList = null) {
        if (!pawnGroup || !pawnGroup.userData) return;
        const ud = pawnGroup.userData;
        const sideGemsGroup = ud.sideGemsGroup;
        if (!sideGemsGroup) return;

        while (sideGemsGroup.children.length > 0) {
            sideGemsGroup.remove(sideGemsGroup.children[0]);
        }

        const isBot = Boolean(ud.isBot);
        let gems = equippedList;
        if (!gems || !Array.isArray(gems) || gems.length === 0) {
            gems = ud.equippedGems;
        }
        if ((!gems || gems.length === 0) && !isBot) {
            if (typeof window.getEquippedGemsList === 'function') {
                gems = window.getEquippedGemsList();
            }
            if ((!gems || gems.length === 0) && window.playerGemsData?.equippedSlots) {
                gems = Array.isArray(window.playerGemsData.equippedSlots)
                    ? window.playerGemsData.equippedSlots.filter(Boolean)
                    : Object.values(window.playerGemsData.equippedSlots).filter(Boolean);
            }
            if ((!gems || gems.length === 0) && Array.isArray(window.DEFAULT_USER?.equipped_gems)) {
                gems = window.DEFAULT_USER.equipped_gems;
            }
        }
        const cardH = ud.cardH || (isBot ? 4.0 : 4.5);
        const slotYPositions = [cardH * 0.33, 0, -cardH * 0.33];

        const slots = [null, null, null];
        if (Array.isArray(gems)) {
            gems.forEach(g => {
                if (!g) return;
                const s = (Number(g.slot_index) >= 1 && Number(g.slot_index) <= 3) ? (Number(g.slot_index) - 1) : -1;
                if (s >= 0) slots[s] = g;
            });
            let nextIdx = 0;
            gems.forEach(g => {
                if (!g) return;
                if (Number(g.slot_index) >= 1 && Number(g.slot_index) <= 3) return;
                while (nextIdx < 3 && slots[nextIdx]) nextIdx++;
                if (nextIdx < 3) {
                    slots[nextIdx] = g;
                    nextIdx++;
                }
            });
        }

        if (!this._sideSparkleTex) {
            const sc = document.createElement('canvas');
            sc.width = 128;
            sc.height = 128;
            const sctx = sc.getContext('2d');
            sctx.clearRect(0, 0, 128, 128);

            const radGrad = sctx.createRadialGradient(64, 64, 4, 64, 64, 56);
            radGrad.addColorStop(0, 'rgba(255, 255, 255, 1)');
            radGrad.addColorStop(0.35, 'rgba(0, 229, 255, 0.7)');
            radGrad.addColorStop(1, 'transparent');
            sctx.fillStyle = radGrad;
            sctx.beginPath();
            sctx.arc(64, 64, 56, 0, Math.PI * 2);
            sctx.fill();

            sctx.fillStyle = '#ffffff';
            sctx.beginPath();
            sctx.moveTo(64, 6);
            sctx.quadraticCurveTo(64, 64, 122, 64);
            sctx.quadraticCurveTo(64, 64, 64, 122);
            sctx.quadraticCurveTo(64, 64, 6, 64);
            sctx.quadraticCurveTo(64, 64, 64, 6);
            sctx.closePath();
            sctx.fill();

            this._sideSparkleTex = new THREE.CanvasTexture(sc);
        }

        const pColHex = ud.primaryBorderColor ? parseInt(String(ud.primaryBorderColor).replace('#', '0x'), 16) : 0x00e5ff;
        const sColHex = ud.secondaryBorderColor ? parseInt(String(ud.secondaryBorderColor).replace('#', '0x'), 16) : 0xffd700;
        const defaultSlotColors = [pColHex || 0x00e5ff, sColHex || 0xffd700, pColHex || 0x00e5ff];
        for (let idx = 0; idx < 3; idx++) {
            const gem = slots[idx];
            const yPos = slotYPositions[idx];
            let colorHexNum = defaultSlotColors[idx];
            if (gem) {
                let gemColorVal = gem.gem_color || ((gem.grade === 'SS+') ? '#c084fc' : ((gem.grade === 'S+') ? '#00e5ff' : '#ffd700'));
                if (typeof gemColorVal === 'string' && gemColorVal.startsWith('#')) {
                    colorHexNum = parseInt(gemColorVal.replace('#', '0x'), 16);
                } else if (typeof gemColorVal === 'number') {
                    colorHexNum = gemColorVal;
                }
            }

            // 1. วงแหวนเออร่าเรืองแสงรอบช่องข้างการ์ด (Pulsing Side Aura Ring)
            const auraRingGeo = new THREE.RingGeometry(0.14, 0.26, 16);
            const auraRingMat = new THREE.MeshBasicMaterial({
                color: colorHexNum,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.85,
                depthTest: false,
                blending: THREE.AdditiveBlending
            });
            const auraMesh = new THREE.Mesh(auraRingGeo, auraRingMat);
            auraMesh.position.set(0, yPos, 0.02);
            auraMesh.userData = { isSideGlow: true, spinDir: (idx % 2 === 0 ? 1 : -1) };
            sideGemsGroup.add(auraMesh);

            // 2. ป้ายประกายดาววิบวับ 4 แฉก (Twinkling Star Sparkle Sprite ✦)
            const spriteMat = new THREE.SpriteMaterial({
                map: this._sideSparkleTex,
                color: colorHexNum,
                transparent: true,
                opacity: 0.95,
                depthTest: false,
                blending: THREE.AdditiveBlending
            });
            const sparkleSprite = new THREE.Sprite(spriteMat);
            sparkleSprite.scale.set(0.55, 0.55, 1);
            sparkleSprite.position.set(0.04, yPos + 0.04, 0.04);
            sparkleSprite.userData = { isSparkleSprite: true, baseScale: 0.55, phase: idx * 1.8 };
            sideGemsGroup.add(sparkleSprite);
        }
    }

    rebuildGemOrbit3D(player) {
        if (!player || !player.mesh || !player.mesh.userData) return;
        const ud = player.mesh.userData;
        const orbitGroup = ud.gemOrbitGroup;
        if (!orbitGroup) return;

        while (orbitGroup.children.length > 0) {
            orbitGroup.remove(orbitGroup.children[0]);
        }

        const gems = this.getPlayerEquippedGems(player);
        if (!gems || gems.length === 0) return;

        const count = gems.length;
        const radius = 1.35;

        // Aura color & primary aura calculation
        let primaryAura = 'pulse';
        let primaryIntensity = 'high';
        let primaryAuraColor = 0xc084fc;

        gems.forEach((gem, i) => {
            const angle = (i / count) * Math.PI * 2;
            let gemColorVal = gem.gem_color || ((gem.grade === 'SS+') ? '#c084fc' : ((gem.grade === 'S+') ? '#00e5ff' : '#ffd700'));
            if (typeof gemColorVal === 'string' && gemColorVal.startsWith('#')) {
                gemColorVal = parseInt(gemColorVal.replace('#', '0x'), 16);
            }
            const shape = (gem.shape || 'triangle').toLowerCase();
            const auraType = (gem.aura_type || 'pulse').toLowerCase();
            const particleFx = (gem.particle_fx || 'spark').toLowerCase();
            const intensity = (gem.aura_intensity || 'high').toLowerCase();

            if (i === 0) {
                primaryAura = auraType;
                primaryIntensity = intensity;
                primaryAuraColor = gemColorVal;
            }

            // 1. Geometry based on shape
            let geo;
            if (shape === 'square') {
                geo = new THREE.BoxGeometry(0.24, 0.24, 0.24);
            } else if (shape === 'pentagon') {
                geo = new THREE.DodecahedronGeometry(0.20, 0);
            } else {
                geo = new THREE.OctahedronGeometry(0.22, 0);
            }

            const emissiveInt = intensity === 'ultra' ? 1.6 : (intensity === 'high' ? 1.1 : 0.7);

            const mat = new THREE.MeshStandardMaterial({
                color: gemColorVal,
                emissive: gemColorVal,
                emissiveIntensity: emissiveInt,
                roughness: 0.15,
                metalness: 0.85
            });
            const gemMesh = new THREE.Mesh(geo, mat);
            gemMesh.position.set(Math.cos(angle) * radius, 0.2, Math.sin(angle) * radius);
            gemMesh.userData = { isGemMesh: true, baseY: 0.2, gemShape: shape, auraType: auraType };
            orbitGroup.add(gemMesh);

            // 2. Aura halo around the gem
            if (auraType !== 'none') {
                const haloGeo = new THREE.RingGeometry(0.24, 0.38, 16);
                let haloColor = gemColorVal;
                if (auraType === 'fire') haloColor = 0xf59e0b;
                else if (auraType === 'electric') haloColor = 0x38bdf8;
                else if (auraType === 'divine') haloColor = 0xfef08a;
                else if (auraType === 'dark') haloColor = 0xe11d48;

                const haloMat = new THREE.MeshBasicMaterial({
                    color: haloColor,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: intensity === 'ultra' ? 0.85 : 0.6
                });
                const haloMesh = new THREE.Mesh(haloGeo, haloMat);
                haloMesh.position.set(Math.cos(angle) * radius, 0.2, Math.sin(angle) * radius);
                haloMesh.rotation.x = Math.PI / 2;
                haloMesh.userData = { isAuraRing: true, spinDir: (i % 2 === 0 ? 1 : -1) };
                orbitGroup.add(haloMesh);
            }

            // 3. Particle FX satellites
            if (particleFx === 'orbit_ring' || particleFx === 'spark' || particleFx === 'crystal_shard') {
                const partGeo = new THREE.OctahedronGeometry(0.08, 0);
                const partMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
                const partMesh1 = new THREE.Mesh(partGeo, partMat);
                partMesh1.position.set(
                    Math.cos(angle) * radius + Math.cos(angle + 1.2) * 0.35,
                    0.25,
                    Math.sin(angle) * radius + Math.sin(angle + 1.2) * 0.35
                );
                partMesh1.userData = { isGemMesh: true, baseY: 0.25 };
                orbitGroup.add(partMesh1);
            }
        });

        // 4. Character Energy Aura Ring on Ground
        if (primaryAura !== 'none') {
            const groundAuraGeo = new THREE.RingGeometry(1.2, 1.45, 32);
            const groundAuraMat = new THREE.MeshBasicMaterial({
                color: primaryAuraColor,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: primaryIntensity === 'ultra' ? 0.75 : 0.45
            });
            const groundAuraMesh = new THREE.Mesh(groundAuraGeo, groundAuraMat);
            groundAuraMesh.rotation.x = -Math.PI / 2;
            groundAuraMesh.position.set(0, -0.4, 0);
            groundAuraMesh.userData = { isAuraRing: true, spinDir: 1 };
            orbitGroup.add(groundAuraMesh);
        }
    }

    async triggerLandmarkSkills(player, tileNum) {
        if (!player || !tileNum) return;
        const gems = this.getPlayerEquippedGems(player);
        const eff = this.aggregateGemEffects(gems);
        const prov = this.getProvinceName(tileNum);

        // 1. สุ่มตัวคูณค่าผ่านทาง X2 - X12
        if (eff.toll_multiplier_random) {
            this.rollLandmarkMultiplier(player, tileNum);
        }

        // 2. ดึงดูดคู่แข่ง (Magnetic Pull 4 ช่อง, 6 ช่อง, หรือ ในแถว)
        const hasPull = eff.pull_opponents_4 || eff.pull_opponents_6 || eff.pull_opponents_line;
        if (hasPull) {
            const rate = eff.pull_rate || 90;
            const rollVal = Math.random() * 100;
            if (rollVal < rate) {
                const gridCols = (this.boardLayout === 'rectangle') ? (this.customGridCols || 12) : (this.customGridCols || 10);
                const targets = this.players.filter(p => {
                    if (p.id === player.id || p.isBankrupt || p.currentTile === tileNum) return false;
                    if (player.team && player.team !== 'NONE' && player.team === p.team) return false;

                    const dist = Math.abs(p.currentTile - tileNum);
                    if (eff.pull_opponents_4 && dist <= 4) return true;
                    if (eff.pull_opponents_6 && dist <= 6) return true;
                    if (eff.pull_opponents_line) {
                        const myRow = Math.floor((tileNum - 1) / gridCols);
                        const oppRow = Math.floor((p.currentTile - 1) / gridCols);
                        if (myRow === oppRow) return true;
                    }
                    if (dist <= 6) return true;
                    return false;
                });

                if (targets.length > 0) {
                    for (const opp of targets) {
                        const oppGems = this.getPlayerEquippedGems(opp);
                        const oppEff = this.aggregateGemEffects(oppGems);

                        if (oppEff.immune_kick) {
                            this.showSkillBanner(`🛡️ สกิล [${oppEff.immune_kick_name || 'ต้านแรงดึง'}] ของ ${opp.username} ทำงาน! ไม่โดนแม่เหล็กดึงดูด!`);
                            this.logMessage(`🛡️ ${opp.username} มีสกิลป้องกัน ต้านแรงแม่เหล็กดึงดูดของ ${player.username} สำเร็จ!`, 'skill');
                            this.triggerShieldPulseEffect(opp);
                            continue;
                        }

                        if (this.isStartProtected(opp)) {
                            this.showSkillBanner(`🛡️ โล่จุดเริ่มต้นของ ${opp.username} ป้องกันเวทดูดเงินสำเร็จ!`);
                            this.triggerShieldPulseEffect(opp);
                            return;
                        }
                        if (opp.shieldLayers && opp.shieldLayers > 0) {
                            opp.shieldLayers--;
                            this.createOrUpdatePawnShieldVisual(opp);
                            this.showSkillBanner(`🛡️ โล่ของ ${opp.username} สลายแรงดึงดูดแม่เหล็ก! รอดพ้นสำเร็จ (เหลือโล่ ${opp.shieldLayers} ชั้น)!`);
                            this.logMessage(`🛡️ โล่ของ ${opp.username} ต้านแรงดึงดูดแม่เหล็กสำเร็จ (เหลือโล่ ${opp.shieldLayers} ชั้น)`, 'skill');
                            this.triggerShieldPulseEffect(opp);
                            continue;
                        }

                        // แอนิเมชันแม่เหล็กดึงดูด 3D
                        const skillTitle = eff.pull_name || 'ดึงดูดคู่แข่ง';
                        this.showSkillBanner(`🧲 สกิล [${skillTitle}] (${rate}%)! ดึงดูด ${opp.username} มายังแลนด์มาร์ค [${prov}]!`);
                        this.logMessage(`🧲 สกิลแม่เหล็กมหาเวทย์! ${player.username} ดูด ${opp.username} (จากช่อง ${opp.currentTile}) มายังแลนด์มาร์ค [${prov}]!`, 'skill');
                        await this.animateMagneticPull(player, opp, tileNum);
                        opp.currentTile = tileNum;
                        this.showLandingPin(tileNum);

                        // คู่แข่งถูกดึงมาตกแลนด์มาร์คและต้องจ่ายค่าผ่านทาง!
                        await this.handleCityTileLanding(opp);
                    }
                } else {
                    const skillTitle = eff.pull_name || 'ดึงดูดคู่แข่ง';
                    this.showSkillBanner(`🧲 สกิล [${skillTitle}] (${rate}%) ทำงาน! ปล่อยคลื่นแม่เหล็กดึงดูดรอบแลนด์มาร์ค [${prov}]!`);
                    this.logMessage(`🧲 สกิลแม่เหล็กแลนด์มาร์ค [${prov}] ทำงาน (${rate}%)! ปล่อยคลื่นดึงดูดรอบแลนด์มาร์ค (ไม่มีคู่แข่งในระยะ)`, 'skill');
                }
            } else {
                console.log(`[LandmarkPull] Rate check: rolled ${rollVal.toFixed(1)}% >= ${rate}% -> Not triggered`);
            }
        }

        // 3. เสกหลุมดำมิติ (Black Hole Generator)
        if (eff.black_hole_generator) {
            const bhRate = eff.black_hole_rate || 80;
            if (Math.random() * 100 < bhRate) {
                const opponents = this.players.filter(p => p.id !== player.id && !p.isBankrupt && p.currentTile !== tileNum);
                let targetTile = null;
                if (opponents.length > 0) {
                    const opp = opponents[0];
                    targetTile = Math.min(99, opp.currentTile + Math.floor(Math.random() * 3) + 1);
                } else {
                    targetTile = Math.max(2, (tileNum + 5) % 99);
                }

                if (targetTile && targetTile !== tileNum) {
                    this.createBlackHole3DVortex(targetTile, tileNum, player);
                    this.showSkillBanner(`🌀 สกิลหลุมดำทำงาน (${bhRate}%)! เสกหลุมดำที่ช่อง ${targetTile} เชื่อมมายังแลนด์มาร์ค [${prov}]!`);
                    this.logMessage(`🌀 มหาเวทย์หลุมดำ! ${player.username} เปิดหลุมดำมิติที่ช่อง ${targetTile} เชื่อมทะลุมายัง [${prov}]!`, 'skill');
                }
            }
        }
    }

    async animatePlayerJumpAndSpin(player) {
        if (!player || !player.mesh) return;
        const mesh = player.mesh;
        const origY = mesh.position.y;
        const origRotY = mesh.rotation.y;

        if (window.soundEngine && typeof window.soundEngine.playBuildSuperLandmark === 'function') {
            window.soundEngine.playBuildSuperLandmark();
        }

        await new Promise(resolve => {
            const start = performance.now();
            const duration = 850;
            const animStep = (now) => {
                const progress = Math.min(1, (now - start) / duration);
                const jumpHeight = Math.sin(progress * Math.PI) * 2.6;
                mesh.position.y = origY + jumpHeight;
                mesh.rotation.y = origRotY + progress * Math.PI * 4;

                if (progress < 1) {
                    requestAnimationFrame(animStep);
                } else {
                    mesh.position.y = origY;
                    mesh.rotation.y = origRotY;
                    resolve();
                }
            };
            requestAnimationFrame(animStep);
        });
    }

    async animateMagneticPull(attacker, victim, destTile) {
        if (!victim || !victim.mesh || !attacker || !attacker.mesh) return;
        const startPos = victim.mesh.position.clone();
        const destCoords = this.getTileCenterCoordinates(destTile);
        const endPos = new THREE.Vector3(destCoords.x, victim.mesh.position.y, destCoords.z);

        const attackerPos = attacker.mesh.position.clone();
        attackerPos.y += 1.4;
        const victimPos = victim.mesh.position.clone();
        victimPos.y += 1.4;

        const beamDist = attackerPos.distanceTo(victimPos);
        const beamGeo = new THREE.CylinderGeometry(0.12, 0.12, Math.max(0.1, beamDist), 8);
        const beamMat = new THREE.MeshBasicMaterial({
            color: 0x38bdf8,
            transparent: true,
            opacity: 0.9,
            wireframe: false
        });
        const beamMesh = new THREE.Mesh(beamGeo, beamMat);
        beamMesh.position.copy(attackerPos).lerp(victimPos, 0.5);
        beamMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), victimPos.clone().sub(attackerPos).normalize());
        this.scene.add(beamMesh);

        if (window.soundEngine && typeof window.soundEngine.playSnake === 'function') {
            window.soundEngine.playSnake();
        }

        await new Promise(resolve => {
            const start = performance.now();
            const duration = 800;
            const animStep = (now) => {
                const p = Math.min(1, (now - start) / duration);
                const ease = p * p * (3 - 2 * p);

                victim.mesh.position.lerpVectors(startPos, endPos, ease);
                victim.mesh.position.y = startPos.y + Math.sin(p * Math.PI) * 1.8;
                victim.mesh.rotation.y += 0.25;

                const curVictimPos = victim.mesh.position.clone();
                curVictimPos.y += 1.4;
                const curDist = attackerPos.distanceTo(curVictimPos);
                beamMesh.scale.set(1, curDist / Math.max(0.1, beamDist), 1);
                beamMesh.position.copy(attackerPos).lerp(curVictimPos, 0.5);
                beamMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), curVictimPos.clone().sub(attackerPos).normalize());

                if (p < 1) {
                    requestAnimationFrame(animStep);
                } else {
                    victim.mesh.position.copy(endPos);
                    this.scene.remove(beamMesh);
                    beamGeo.dispose();
                    beamMat.dispose();
                    resolve();
                }
            };
            requestAnimationFrame(animStep);
        });
    }

    removeBlackHole(tile) {
        if (!this.activeBlackHoles || !this.activeBlackHoles[tile]) return;
        const bh = this.activeBlackHoles[tile];
        if (bh && bh.mesh) {
            this.scene.remove(bh.mesh);
            bh.mesh.traverse(child => {
                if (child.isMesh) {
                    if (child.geometry) child.geometry.dispose();
                    if (child.material) {
                        if (Array.isArray(child.material)) child.material.forEach(m => m && m.dispose && m.dispose());
                        else if (child.material.dispose) child.material.dispose();
                    }
                }
            });
        }
        delete this.activeBlackHoles[tile];
    }

    createBlackHole3DVortex(targetTile, destTile, owner) {
        this.activeBlackHoles = this.activeBlackHoles || {};

        if (this.activeBlackHoles[targetTile]?.mesh) {
            this.scene.remove(this.activeBlackHoles[targetTile].mesh);
        }

        const coords = this.getTileCenterCoordinates(targetTile);
        const bhGroup = new THREE.Group();
        bhGroup.position.set(coords.x, 0.25, coords.z);

        // Core
        const coreGeo = new THREE.SphereGeometry(0.75, 16, 16);
        const coreMat = new THREE.MeshBasicMaterial({ color: 0x09090b });
        const coreMesh = new THREE.Mesh(coreGeo, coreMat);
        bhGroup.add(coreMesh);

        // Accretion disk
        const diskGeo = new THREE.RingGeometry(0.8, 1.85, 24);
        const diskMat = new THREE.MeshBasicMaterial({
            color: 0xa855f7,
            transparent: true,
            opacity: 0.85,
            side: THREE.DoubleSide
        });
        const diskMesh = new THREE.Mesh(diskGeo, diskMat);
        diskMesh.rotation.x = -Math.PI / 2;
        bhGroup.add(diskMesh);

        // Floating label
        const labelCanvas = document.createElement('canvas');
        labelCanvas.width = 256;
        labelCanvas.height = 80;
        const ctx = labelCanvas.getContext('2d');
        ctx.fillStyle = '#a855f7';
        ctx.font = 'bold 36px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('🌀 หลุมดำ', 128, 52);
        const labelTex = new THREE.CanvasTexture(labelCanvas);
        const labelSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTex, transparent: true, depthTest: false }));
        labelSprite.scale.set(2.2, 0.8, 1);
        labelSprite.position.set(0, 1.6, 0);
        bhGroup.add(labelSprite);

        this.scene.add(bhGroup);

        this.activeBlackHoles[targetTile] = {
            destinationTile: destTile,
            ownerId: owner.id,
            mesh: bhGroup,
            diskMesh: diskMesh,
            createdAt: performance.now()
        };
    }

    async animateBlackHoleSuckAndTeleport(victim, fromTile, toTile) {
        if (!victim || !victim.mesh) return;
        const origScale = victim.mesh.scale.clone();
        const origY = victim.mesh.position.y;
        const destCoords = this.getTileCenterCoordinates(toTile);

        // Phase 1: Suck down into black hole
        await new Promise(resolve => {
            const start = performance.now();
            const duration = 500;
            const animStep = (now) => {
                const p = Math.min(1, (now - start) / duration);
                const s = Math.max(0.05, 1 - p);
                victim.mesh.scale.set(origScale.x * s, origScale.y * s, origScale.z * s);
                victim.mesh.position.y = origY - p * 0.9;
                victim.mesh.rotation.y += 0.4;
                if (p < 1) requestAnimationFrame(animStep);
                else resolve();
            };
            requestAnimationFrame(animStep);
        });

        // Phase 2: Move to destination
        victim.mesh.position.set(destCoords.x, origY - 0.9, destCoords.z);

        // Phase 3: Rise from White Hole & expand
        await new Promise(resolve => {
            const start = performance.now();
            const duration = 500;
            const animStep = (now) => {
                const p = Math.min(1, (now - start) / duration);
                const ease = p * (2 - p);
                const s = Math.min(1, 0.05 + ease * 0.95);
                victim.mesh.scale.set(origScale.x * s, origScale.y * s, origScale.z * s);
                victim.mesh.position.y = (origY - 0.9) + ease * 0.9;
                if (p < 1) requestAnimationFrame(animStep);
                else {
                    victim.mesh.scale.copy(origScale);
                    victim.mesh.position.y = origY;
                    resolve();
                }
            };
            requestAnimationFrame(animStep);
        });
    }

    flagSkillSlotFx(text) {
        try {
            if (!text || !this.players || this.players.length === 0) return;
            const plain = String(text).replace(/<[^>]*>/g, '');
            const isGem = /อัญมณี|💎|🔮|🛡️|🧲|🌪️|🌀|💸/.test(plain);
            const isSkill = plain.includes('สกิล');
            if (!isGem && !isSkill) return;

            let type = 'cardskill';
            if (isGem) type = 'gem1';
            else if (/เต๋า|ลูกเต๋า|🎲/.test(plain)) type = 'dice';

            let player = this.players.find(pl => pl && pl.username && plain.includes(pl.username));
            if (!player) player = this.players[this.currentTurnIndex] || this.players[0];
            const playerIdx = this.players.indexOf(player);

            if (type === 'gem1') {
                const gems = (typeof this.getPlayerEquippedGems === 'function') ? (this.getPlayerEquippedGems(player) || []) : [];
                const g2 = gems[1];
                if (g2 && ((g2.name && plain.includes(g2.name)) || (g2.skill_name && plain.includes(g2.skill_name)))) type = 'gem2';
                else if (!gems[0] && /🧲|💸/.test(plain)) type = 'gem2';
            }

            const dur = 3500;
            this._skillFx = { playerId: player ? player.id : null, playerIdx, type, until: Date.now() + dur };
            if (typeof this.updateMatchWealthHUD === 'function') this.updateMatchWealthHUD();
            if (this._skillFxTimeout) clearTimeout(this._skillFxTimeout);
            this._skillFxTimeout = setTimeout(() => {
                this._skillFx = null;
                if (typeof this.updateMatchWealthHUD === 'function') this.updateMatchWealthHUD();
            }, dur + 50);
        } catch (err) {
            console.warn('flagSkillSlotFx error', err);
        }
    }

    showSkillBanner(text, extraClass = '') {
        this.flagSkillSlotFx(text);
        const banner = document.getElementById('skill-banner');
        if (banner) {
            banner.innerHTML = text;
            banner.className = `skill-banner active ${extraClass}`.trim();
            if (this._skillBannerTimeout) clearTimeout(this._skillBannerTimeout);
            this._skillBannerTimeout = setTimeout(() => {
                banner.className = 'skill-banner';
            }, extraClass ? 4200 : 3200);
        }

        // 💎 หากเป็นสกิลอัญมณี ให้แสดงเอฟเฟกต์ 3D ทอยเด้งหมุนควงกึ่งกลางกระดาน 2 วินาทีแล้วหายไป
        if (text && (text.includes('สกิล') || text.includes('อัญมณี') || text.includes('🛡️') || text.includes('🧲') || text.includes('🌪️') || text.includes('🌀') || text.includes('💸'))) {
            let skillName = 'สกิลอัญมณี';
            const match = text.match(/\[(.*?)\]/);
            if (match && match[1]) {
                skillName = match[1];
            } else {
                const words = text.replace(/<[^>]*>/g, '').split('!');
                if (words[0]) skillName = words[0].trim();
            }
            const activeP = (this.players && this.players[this.currentTurnIndex]) || (this.players && this.players[0]);
            this.showCenterGemActivationEffect(activeP, skillName);
        }
    }

    logMessage(msg, type = '') {
        const feed = document.getElementById('log-feed');
        if (!feed) return;
        const div = document.createElement('div');
        div.className = `log-item ${type}`;
        div.innerText = msg;
        feed.appendChild(div);
        feed.scrollTop = feed.scrollHeight;
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        try {
            const delta = this.clock.getDelta();
            if (this.controls) this.controls.update();

            // 🎲 อัปเดตตำแหน่งปุ่มทอยกลางวงเวียน และตัวเลขมาร์ค 1..12 บนช่องกระดาน (สไตล์ โหมดกระดาน 3D)
            if (this.isMonopolyBoardMode) {
                this.updateMonopolyCenterRollStationPosition();
                this.updateMonopolyTilePathMarkerPositions();
            }

            const time = this.clock.getElapsedTime();
            if (this.pointLight) {
                this.pointLight.position.x = Math.sin(time * 0.7) * 35;
                this.pointLight.position.z = Math.cos(time * 0.7) * 35;
            }

            // แอนิเมชันแผ่นตัวหมากทรงกลมลอยเด่นด้านหน้า + วงแหวนพลังงานหมุน + ขยายเด่นเมื่อถึงตาเดิน
            if (this.players && Array.isArray(this.players)) {
                this.players.forEach((p, idx) => {
                    if (p.mesh && p.mesh.userData && p.mesh.userData.badgeGroup) {
                        const ud = p.mesh.userData;
                        const bg = ud.badgeGroup;
                        const isTurn = Boolean(this.isMatchActive && this.currentTurnIndex === idx && !p.isBankrupt);
                        const isRollingTurn = Boolean(isTurn && this.isRolling);
                        const isHuman = !p.is_bot;

                        const floatBase = ud.baseFloatY || (isHuman ? 2.32 : 2.02);
                        const targetLiftY = isRollingTurn ? 1.05 : (isTurn ? 0.22 : 0);
                        const bobAmp = isRollingTurn ? 0.14 : (isTurn ? 0.20 : 0.12);
                        if (bg.position) {
                            const targetY = floatBase + targetLiftY + Math.sin(time * 3.1 + idx) * bobAmp;
                            bg.position.y += (targetY - bg.position.y) * Math.min(1, delta * 10);
                        }

                        const targetScale = isRollingTurn
                            ? (isHuman ? 1.38 : 1.32)
                            : (isTurn ? (isHuman ? 1.16 : 1.10) : (isHuman ? 1.06 : 0.96));
                        const curScale = bg.scale ? bg.scale.x : 1;
                        const nextScale = curScale + (targetScale - curScale) * Math.min(1, delta * 10);
                        if (bg.scale) bg.scale.set(nextScale, nextScale, nextScale);

                        if (ud.auraRingMesh) {
                            ud.auraRingMesh.rotation.z -= delta * (isTurn ? 1.9 : 1.1);
                        }
                        if (ud.groundAuraMesh) {
                            ud.groundAuraMesh.rotation.z += delta * (isTurn ? 1.8 : 0.9);
                        }

                        // แสงเออร่าเตือนภัยใกล้ถึงเส้นชัย 5-8 ช่อง (ช่อง 92-99)
                        const isNearFinish = Boolean(p.currentTile >= 92 && p.currentTile < 100 && !p.isBankrupt && this.isMatchActive);
                        if (ud.nearFinishAura) {
                            ud.nearFinishAura.visible = isNearFinish;
                            if (isNearFinish && ud.nearFinishAura.material) {
                                ud.nearFinishAura.rotation.z += delta * 3.4;
                                ud.nearFinishAura.material.opacity = 0.78 + Math.sin(time * 6.5) * 0.22;
                                const auraPulse = 1.0 + Math.sin(time * 5.2) * 0.14;
                                ud.nearFinishAura.scale.set(auraPulse, auraPulse, auraPulse);
                            }
                        }

                        if (ud.spotlightBeam && ud.spotlightBeam.material) {
                            ud.spotlightBeam.material.opacity = isNearFinish
                                ? (0.45 + Math.sin(time * 7.5) * 0.22)
                                : (isTurn ? (0.30 + Math.sin(time * 4.2) * 0.08) : (isHuman ? 0.20 : 0.08));
                        }

                        // หมุนโล่คุ้มกัน 3D (Shield Visual Animation)
                        if (ud.shieldGroup && ud.shieldGroup.visible) {
                            ud.shieldGroup.rotation.y += delta * 1.8;
                            ud.shieldGroup.rotation.x = Math.sin(time * 2.0) * 0.12;
                            if (ud.shieldMesh && ud.shieldMesh.material) {
                                ud.shieldMesh.material.opacity = 0.52 + Math.sin(time * 4.5) * 0.18;
                            }
                            if (ud.shieldBadgeSprite && this.camera) {
                                ud.shieldBadgeSprite.lookAt(this.camera.position);
                            }
                        }
                        // หมุนอัญมณีลอยวนรอบตัว & แอนิเมชันเออร่า (Gem Orbit & Aura Animation)
                        if (ud.gemOrbitGroup) {
                            ud.gemOrbitGroup.rotation.y += delta * 1.5;
                            if (ud.gemOrbitGroup.children && ud.gemOrbitGroup.children.length > 0) {
                                ud.gemOrbitGroup.children.forEach((child, ci) => {
                                    if (child.userData && child.userData.isGemMesh) {
                                        child.rotation.x += delta * 2.2;
                                        child.rotation.y += delta * 2.8;
                                        child.position.y = (child.userData.baseY || 0.2) + Math.sin(time * 3.5 + ci) * 0.08;
                                    } else if (child.userData && child.userData.isAuraRing) {
                                        child.rotation.z += delta * (child.userData.spinDir || 1) * 2.0;
                                        if (child.material) {
                                            child.material.opacity = 0.5 + Math.sin(time * 4.0 + ci) * 0.22;
                                        }
                                    }
                                });
                            }
                        }

                        // แอนิเมชันอัญมณี 3D ข้างกรอบการ์ด หมุนเออร่า & กระพริบดาววิบวับ (Side Card Gems Pulse & Sparkle)
                        if (ud.sideGemsGroup && ud.sideGemsGroup.children && ud.sideGemsGroup.children.length > 0) {
                            ud.sideGemsGroup.children.forEach((item, sgi) => {
                                if (item.userData && item.userData.isSideGlow) {
                                    item.rotation.z += delta * (item.userData.spinDir || 1.0) * 2.2;
                                    if (item.material) {
                                        item.material.opacity = 0.55 + Math.sin(time * 5.0 + sgi * 1.5) * 0.35;
                                    }
                                    const pulse = 1.0 + Math.sin(time * 4.2 + sgi * 1.8) * 0.20;
                                    item.scale.set(pulse, pulse, 1);
                                } else if (item.userData && item.userData.isSparkleSprite) {
                                    const sparkle = 0.5 + Math.sin(time * 6.5 + (item.userData.phase || sgi * 2.0)) * 0.5;
                                    const sc = (item.userData.baseScale || 0.55) * (0.8 + sparkle * 0.45);
                                    item.scale.set(sc, sc, 1);
                                    if (item.material) {
                                        item.material.opacity = Math.max(0.25, sparkle);
                                    }
                                }
                            });
                        }

                        if (this.camera && bg) {
                            bg.lookAt(this.camera.position);
                        }
                    }
                });
            }

            // แอนิเมชันพญางู 3D บนกระดาน
            if (this.snakeObjects && this.snakes) {
                for (const headTile of Object.keys(this.snakes)) {
                    const sn = this.snakeObjects[Number(headTile)];
                    if (sn && !sn.isAnimating && sn.headGroup) {
                        const ph = time * 2.8 + (sn.phaseOffset || 0);
                        sn.headGroup.position.x = (sn.headPos ? sn.headPos.x : 0) + Math.sin(ph) * 0.25;
                        sn.headGroup.position.y = (sn.headPos ? sn.headPos.y : 0) + 1.25 + Math.cos(ph * 1.3) * 0.18;
                        if (sn.lowerJawPivot) {
                            sn.lowerJawPivot.rotation.x = 0.18 + Math.sin(ph * 1.6) * 0.1;
                        }
                        if (sn.tongueGroup) {
                            sn.tongueGroup.position.z = Math.sin(ph * 3.5) * 0.22;
                        }
                    }
                }
            }

            // แอนิเมชันเป้าหมายปลายทาง (Destination Beacon) หมุนคริสตัลเพชร 3D + วงแหวนเวทย์พื้น + ป้ายลอยนุ่มนวล
            if (this.destinationBeacon && this.destinationBeacon.visible) {
                if (this.destinationBeaconPad && this.destinationBeaconPad.mesh) {
                    this.destinationBeaconPad.mesh.rotation.z += delta * 0.9;
                }
                if (this.destinationDiamond) {
                    this.destinationDiamond.rotation.y += delta * 2.4;
                    this.destinationDiamond.position.y = 2.65 + Math.sin(time * 3.5) * 0.22;
                    if (this.destDiamondHalo) {
                        this.destDiamondHalo.rotation.z -= delta * 1.8;
                    }
                }
                if (this.destinationBillboard && this.destinationBillboard.sprite) {
                    this.destinationBillboard.sprite.position.y = (this.destBillboardBaseY || 5.6) + Math.sin(time * 3.5) * 0.18;
                }
            }

            // แอนิเมชันจุดสตาร์ท (วงแหวนหมุน + ขอบกะพริบ)
            if (this.startAnimations) {
                const sa = this.startAnimations;
                if (sa.innerRing) sa.innerRing.rotation.z += delta * 0.5;
                if (sa.rim && sa.rim.material) {
                    sa.rim.material.opacity = 0.75 + Math.sin(time * 2.5) * 0.2;
                }
            }

            // แอนิเมชันเส้นชัย (ลำแสงทอง + วงแหวน + เพชรหมุน + เตือนภัยเมื่อมีคนใกล้ถึงเส้นชัย 5-8 ช่อง)
            if (this.goalAnimations) {
                const ga = this.goalAnimations;
                const anyNearFinish = this.players && this.players.some(p => p.currentTile >= 92 && p.currentTile < 100 && !p.isBankrupt && this.isMatchActive);

                if (ga.diamond) {
                    ga.diamond.rotation.y += delta * (anyNearFinish ? 5.2 : 2.2);
                    ga.diamond.position.y = 6.2 + Math.sin(time * (anyNearFinish ? 6.5 : 3.5)) * (anyNearFinish ? 0.42 : 0.25);
                }
                if (ga.pagodaOrb) {
                    ga.pagodaOrb.rotation.y += delta * (anyNearFinish ? 2.5 : 0.8);
                }
                if (ga.auraRing1) ga.auraRing1.rotation.z += delta * (anyNearFinish ? 3.0 : 0.9);
                if (ga.auraRing2) ga.auraRing2.rotation.z -= delta * (anyNearFinish ? 4.2 : 1.4);
                if (ga.beam && ga.beam.material) {
                    if (anyNearFinish) {
                        ga.beam.material.opacity = 0.45 + Math.sin(time * 5.5) * 0.22;
                        const bScale = 1.35 + Math.sin(time * 3.8) * 0.15;
                        ga.beam.scale.set(bScale, 1.0, bScale);
                    } else {
                        ga.beam.material.opacity = 0.20 + Math.sin(time * 2.2) * 0.07;
                        ga.beam.scale.set(1.0, 1.0, 1.0);
                    }
                }
                if (ga.light) {
                    ga.light.intensity = anyNearFinish
                        ? (6.8 + Math.sin(time * 6.5) * 2.2)
                        : (3.0 + Math.sin(time * 2.8) * 0.5);
                    if (anyNearFinish) {
                        ga.light.color.setHex(0xff9900);
                    } else {
                        ga.light.color.setHex(0xffca28);
                    }
                }

                // เอฟเฟกต์ไฟรันเวย์ส่องสว่างตามช่อง 92 ถึง 100 นำทางสู่เส้นชัย (ปลอดภัยแม้เป็น Cylinder หรือ Custom Material)
                if (anyNearFinish && this.tileMeshes) {
                    for (let tNum = 92; tNum <= 100; tNum++) {
                        const tm = this.tileMeshes[tNum];
                        if (tm && tm.material) {
                            const matTarget = Array.isArray(tm.material) ? (tm.material[2] || tm.material[1] || tm.material[0]) : tm.material;
                            if (matTarget && matTarget.emissiveIntensity !== undefined) {
                                const phase = time * 7.5 - (100 - tNum) * 0.75;
                                const wave = Math.max(0, Math.sin(phase));
                                matTarget.emissiveIntensity = 0.25 + wave * 0.65;
                            }
                        }
                    }
                }
            }

            // แอนิเมชันเมือง 3D & แลนด์มาร์ค
            if (this.cityMeshes) {
                const safeDelta = Math.min(delta, 0.08);
                for (const tileKey of Object.keys(this.cityMeshes)) {
                    const cityGrp = this.cityMeshes[tileKey];
                    if (!cityGrp || !cityGrp.userData || !cityGrp.userData.cityAnim) continue;
                    const ca = cityGrp.userData.cityAnim;

                    if (ca.buildProgress < 1) {
                        ca.buildProgress = Math.min(1, ca.buildProgress + safeDelta * 2.8);
                        const p = ca.buildProgress;
                        const bounce = p < 0.72
                            ? 0.05 + (p / 0.72) * 1.07
                            : 1.12 - ((p - 0.72) / 0.28) * 0.12;
                        cityGrp.scale.set(bounce, bounce, bounce);
                    } else if (ca.stepPopProgress !== undefined && ca.stepPopProgress < 1) {
                        ca.stepPopProgress = Math.min(1, ca.stepPopProgress + safeDelta * 4.2);
                        const sp = ca.stepPopProgress;
                        const pop = Math.sin(sp * Math.PI) * Math.exp(-sp * 1.6);
                        const scaleY = 1.0 + pop * 0.55;
                        const scaleXZ = 1.0 + pop * 0.22;
                        cityGrp.scale.set(scaleXZ, scaleY, scaleXZ);
                        cityGrp.position.y = (ca.basePosY || 0) + pop * 0.65;
                        if (sp >= 1) {
                            cityGrp.scale.set(1, 1, 1);
                            cityGrp.position.y = ca.basePosY || 0;
                            delete ca.stepPopProgress;
                        }
                    }

                    if (ca.rotatingHalo) {
                        ca.rotatingHalo.rotation.z += safeDelta * 1.25;
                    }
                    if (ca.rotatingHalo2) {
                        ca.rotatingHalo2.rotation.z -= safeDelta * 1.85;
                    }
                    if (ca.floatingCrest) {
                        ca.floatingCrest.rotation.y += safeDelta * 2.1;
                        ca.floatingCrest.position.y = (ca.crestBaseY || 2.5) + Math.sin(time * 3.2 + (ca.phase || 0)) * 0.22;
                    }
                    if (ca.beamMesh && ca.beamMesh.material) {
                        ca.beamMesh.material.opacity = 0.16 + Math.sin(time * 2.6 + (ca.phase || 0)) * 0.06;
                    }
                    if (ca.beacons && ca.beacons.length) {
                        const rotStep = safeDelta * 1.6;
                        for (let bIdx = 0; bIdx < ca.beacons.length; bIdx++) {
                            ca.beacons[bIdx].rotation.y += rotStep;
                        }
                    }
                }
            }

            // แอนิเมชันช่องกระดานนูนขึ้นเมื่อตัวละครวิ่งผ่าน (Tile Step Pop)
            if (this.tileMeshes) {
                const safeDelta = Math.min(delta, 0.08);
                for (let tNum = 1; tNum <= 100; tNum++) {
                    const tm = this.tileMeshes[tNum];
                    if (tm && tm.userData && tm.userData.stepPopProgress !== undefined && tm.userData.stepPopProgress < 1) {
                        tm.userData.stepPopProgress = Math.min(1, tm.userData.stepPopProgress + safeDelta * 4.5);
                        const sp = tm.userData.stepPopProgress;
                        const pop = Math.sin(sp * Math.PI) * Math.exp(-sp * 1.8);
                        tm.scale.set(1.0 + pop * 0.08, 1.0 + pop * 0.45, 1.0 + pop * 0.08);
                        tm.position.y = (tm.userData.origY || 0) + pop * 0.40;
                        if (sp >= 1) {
                            tm.scale.set(1, 1, 1);
                            tm.position.y = tm.userData.origY || 0;
                            delete tm.userData.stepPopProgress;
                        }
                    }
                }
            }

            // Synchronize & Drive Match Timer
            if (this.isMatchActive && !this.isGameOver) {
                if (!this.matchStartTime) {
                    this.matchStartTime = Date.now();
                }
                const currentElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
                const rem = Math.max(0, (this.matchTimeLimit || 600) - currentElapsed);
                if (rem !== this.matchTimeRemaining) {
                    this.matchTimeRemaining = rem;
                    this.updateMatchTimerHUD();

                    if (rem <= 60 && rem > 30 && !this.warned1Min) {
                        this.warned1Min = true;
                        if (typeof showToast === 'function') {
                            showToast('⏰ เหลือเวลาอีก 1 นาที! ใครมีทองและสิ่งก่อสร้างรวมเยอะสุดจะชนะ!');
                        }
                        this.logMessage('⚠️ [แจ้งเตือนเวลา] เหลือเวลาแข่งขันอีก 1 นาทีสุดท้าย! เร่งสร้างเมืองและทำแต้ม!', 'warning');
                        if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                            window.soundEngine.playAlert();
                        }
                    } else if (rem <= 30 && rem > 0 && !this.warned30Sec) {
                        this.warned30Sec = true;
                        if (typeof showToast === 'function') {
                            showToast('🚨 30 วินาทีสุดท้าย! ระบบจะตัดสินผู้ชนะจากสินทรัพย์และสิ่งก่อสร้างรวม!');
                        }
                        this.logMessage('🚨 [แจ้งเตือนเวลา] 30 วินาทีสุดท้าย! ผู้ที่มีทองและมูลค่าสิ่งก่อสร้างสูงสุดจะคว้าชัยชนะทันที!', 'warning');
                        if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                            window.soundEngine.playAlert();
                        }
                    }

                    if (rem <= 0) {
                        this.handleMatchTimeoutVictory();
                    }
                }
            }

            // แอนิเมชันหลุมดำมิติ 3D
            if (this.activeBlackHoles) {
                for (const key of Object.keys(this.activeBlackHoles)) {
                    const bh = this.activeBlackHoles[key];
                    if (bh && bh.diskMesh) {
                        bh.diskMesh.rotation.z += delta * 3.8;
                    }
                }
            }

            this.updateSpeechBubblesPosition();
        } catch (animErr) {
            // ไม่ให้ข้อผิดพลาดของแอนิเมชันย่อยไปขัดขวางการเรนเดอร์กระดาน
        }

        // แอนิเมชันลูกศรและวงแหวนไฮไลท์ขณะรอจิ้มเลือกช่องบนกระดาน 3D
        if (this._boardPickGroup && this._boardPickGroup.children.length > 0) {
            const pickTime = this.clock ? this.clock.getElapsedTime() : (Date.now() * 0.001);
            this._boardPickGroup.children.forEach((grp, idx) => {
                if (grp.children && grp.children.length >= 3) {
                    const ring = grp.children[0];
                    const arrow = grp.children[2];
                    if (ring) {
                        const sc = 1.0 + Math.sin(pickTime * 6.0 + idx * 0.4) * 0.12;
                        ring.scale.set(sc, sc, sc);
                    }
                    if (arrow) {
                        arrow.position.y = 1.75 + Math.sin(pickTime * 5.5 + idx * 0.4) * 0.35;
                        arrow.rotation.y += 0.06;
                    }
                }
            });
        }

        // แอนิเมชันแสงเออร่าเรืองแสงของเมืองที่กำลังจะชนะ Triple Color Victory (ครบ 3 สี 6 เมือง)
        if (this.monopolyVictoryAuraGroup && this.monopolyVictoryAuraGroup.children.length > 0) {
            const auraTime = this.clock ? this.clock.getElapsedTime() : (Date.now() * 0.001);
            this.monopolyVictoryAuraGroup.children.forEach(item => {
                const ud = item.userData;
                if (ud) {
                    if (ud.ringMesh) {
                        ud.ringMesh.rotation.z += 0.035;
                        const pulse = 1.0 + Math.sin(auraTime * 5.5 + (ud.phase || 0)) * 0.16;
                        ud.ringMesh.scale.set(pulse, pulse, pulse);
                    }
                    if (ud.discMesh && ud.discMesh.material) {
                        ud.discMesh.material.opacity = 0.38 + Math.sin(auraTime * 6.5 + (ud.phase || 0)) * 0.22;
                    }
                    if (ud.beamMesh && ud.beamMesh.material) {
                        ud.beamMesh.material.opacity = 0.28 + Math.sin(auraTime * 4.8 + (ud.phase || 0)) * 0.18;
                    }
                }
            });
        }

        // รับประกันการเรนเดอร์กระดาน 3D เสมอในทุกเฟรม
        if (this.renderer && this.scene && this.camera && !this.isContextLost) {
            try {
                this.renderer.render(this.scene, this.camera);
                if (this._glStats) this._glStats.frames++;
            } catch (renderErr) {
                this.handleRenderError(renderErr);
            }
        }
        this.updateGlDiagOverlay();
    }

    // =====================================================================
    // 🛡️ WebGL Self-Healing: Context Lost Recovery + Render Error Isolation
    // =====================================================================
    attachContextHandlers(glDom) {
        if (!glDom) return;
        glDom.addEventListener('webglcontextlost', (e) => {
            e.preventDefault();
            console.warn('[SnakeGame3D] ⚠️ WebGL Context Lost!');
            this.isContextLost = true;
            if (this._glStats) this._glStats.lost++;
            clearTimeout(this._ctxRecoverTimer);
            // หากเบราว์เซอร์ (iOS WebKit / Android WebView) ไม่คืนคอนเท็กซ์ภายใน 0.25 วิ ให้สร้าง Renderer ใหม่ทันที
            this._ctxRecoverTimer = setTimeout(() => {
                if (this.isContextLost) this.recreateRenderer('context-lost-timeout');
            }, 250);
        }, false);
        glDom.addEventListener('webglcontextrestored', () => {
            console.log('[SnakeGame3D] 🔄 WebGL Context Restored');
            clearTimeout(this._ctxRecoverTimer);
            this.isContextLost = false;
            try { this.updateCameraFit(true); } catch (e) { }
        }, false);
    }

    recreateRenderer(reason = '') {
        if ((this._glStats?.recreated || 0) >= 4) return; // ป้องกันวนลูปสร้างไม่รู้จบ
        console.warn('[SnakeGame3D] ♻️ Recreating WebGL renderer:', reason);
        const old = this.renderer;
        try {
            if (old) {
                if (old.domElement && old.domElement.parentNode) old.domElement.parentNode.removeChild(old.domElement);
                try { old.dispose(); } catch (e) { }
            }
            const bg = (this.scene && this.scene.background && this.scene.background.isColor) ? this.scene.background : new THREE.Color(0x070b12);
            this.renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: 'default' });
            this.renderer.setClearColor(bg, 1.0);
            this.renderer.shadowMap.enabled = false;
            this.renderer.setPixelRatio(1);
            const glDom = this.renderer.domElement;
            glDom.style.touchAction = 'none';
            glDom.style.outline = 'none';
            this.container.appendChild(glDom);
            this.attachContextHandlers(glDom);
            if (this.controls && window.THREE.OrbitControls) {
                try { this.controls.dispose(); } catch (e) { }
                this.controls = new THREE.OrbitControls(this.camera, glDom);
                this.controls.enableDamping = true;
                this.controls.dampingFactor = 0.05;
                this.controls.maxPolarAngle = Math.PI / 2.05;
                this.controls.minDistance = 20;
                this.controls.maxDistance = 200;
            }
            this.graphicsQuality = 'low';
            this.isContextLost = false;
            if (this._glStats) this._glStats.recreated++;
            this.updateCameraFit(true);
        } catch (err) {
            console.error('[SnakeGame3D] Recreate renderer failed:', err);
            if (this._glStats) this._glStats.lastError = 'recreate: ' + (err && err.message);
        }
    }

    handleRenderError(err) {
        const st = this._glStats || (this._glStats = { lost: 0, recreated: 0, renderErrors: 0, culprits: [], lastError: '', frames: 0 });
        st.renderErrors++;
        st.lastError = String((err && err.message) || err).slice(0, 120);
        if (st.renderErrors === 1 || st.renderErrors % 120 === 0) {
            console.error('[SnakeGame3D] 🚨 Render error:', err);
        }
        if (this._isolatingRender || st.renderErrors > 600) return;
        this._isolatingRender = true;
        try {
            const test = () => {
                try { this.renderer.render(this.scene, this.camera); return true; } catch (e) { return false; }
            };
            const isolate = (parent, depth) => {
                for (const child of parent.children.slice()) {
                    if (!child.visible) continue;
                    child.visible = false;
                    const ok = test();
                    child.visible = true;
                    if (ok) {
                        if (depth < 8 && child.children.length) {
                            isolate(child, depth + 1);
                            if (test()) return true;
                        }
                        child.visible = false;
                        st.culprits.push((child.name || child.type || 'obj') + '@' + depth);
                        console.warn('[SnakeGame3D] 🧯 Hid broken 3D object:', child);
                        return true;
                    }
                }
                return false;
            };
            for (let i = 0; i < 4 && !test(); i++) {
                if (!isolate(this.scene, 0)) break;
            }
        } catch (isoErr) { }
        this._isolatingRender = false;
    }

    updateGlDiagOverlay() {
        const st = this._glStats;
        if (!st) return;
        if (!this._diagStart) this._diagStart = performance.now();
        const now = performance.now();
        if (this._diagLast && now - this._diagLast < 500) return;
        this._diagLast = now;
        const forced = /[?&]debug3d=1/.test(window.location.search);
        let el = document.getElementById('gl-diag-overlay');
        if (!forced) {
            if (el) el.style.display = 'none';
            return;
        }
        if (!el) {
            el = document.createElement('div');
            el.id = 'gl-diag-overlay';
            el.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:64px;z-index:2147483600;pointer-events:none;font:10px/1.3 monospace;color:#9ef;background:rgba(0,0,0,0.6);padding:2px 6px;border-radius:4px;max-width:60vw;white-space:pre-wrap;';
            document.body.appendChild(el);
        }
        el.style.display = 'block';
        let glLost = '?';
        try { glLost = this.renderer.getContext().isContextLost() ? 'LOST' : 'ok'; } catch (e) { }
        const c = this.renderer && this.renderer.domElement;
        const info = (this.renderer && this.renderer.info) ? this.renderer.info : null;
        el.textContent = `3D v1.1.04 | gl:${glLost} lost:${st.lost} re:${st.recreated} err:${st.renderErrors} f:${st.frames}` +
            ` | board:${this.boardGroup ? this.boardGroup.children.length : 0} cv:${c ? c.width + 'x' + c.height : '-'}` +
            ` tex:${info ? info.memory.textures : '-'} geo:${info ? info.memory.geometries : '-'}` +
            (st.culprits.length ? `\nhidden:${st.culprits.slice(-3).join(',')}` : '') +
            (st.lastError ? `\n${st.lastError}` : '');
    }
}

window.SnakeGame3D = SnakeGame3D;

// ============================================================
// 🤖 AI CUSTOM 3D BOARDS LOADER & PLAYER SELECTOR
// ============================================================
window.availableAiCustomBoards = [];

window.getBoardsApiEndpoint = function () {
    try {
        if (typeof window !== 'undefined' && window.location) {
            const proto = window.location.protocol;
            const host = window.location.hostname;
            const port = window.location.port;
            if (proto === 'capacitor:' || proto === 'file:' || (host === 'localhost' && port !== '7175')) {
                return 'https://pmix01.thddns.net:7175/home/snake/api/boards.php';
            }
            const path = window.location.pathname;
            const dir = path.substring(0, path.lastIndexOf('/') + 1);
            return (window.location.origin || '') + dir + 'api/boards.php';
        }
    } catch (e) { }
    return 'https://pmix01.thddns.net:7175/home/snake/api/boards.php';
};

window.fetchAndApplyActiveAiBoards = async function () {
    try {
        const endpoint = window.getBoardsApiEndpoint();
        const url = `${endpoint}?action=get_active_boards&_t=${Date.now()}`;
        let res = null;
        try {
            res = await fetch(url).then(r => r.json());
        } catch (netErr) {
            // Fallback for Capacitor iOS/Android offline or local bundle mode
            const cachedRaw = localStorage.getItem('snake_cached_ai_boards_json');
            if (cachedRaw) res = JSON.parse(cachedRaw);
        }
        if (!res || res.status !== 'success') return;
        try {
            localStorage.setItem('snake_cached_ai_boards_json', JSON.stringify(res));
        } catch (e) { }
        window.availableAiCustomBoards = res.boards || [];
        window.renderCustomAiBoardsInModal();

        // สำคัญที่สุด: ห้ามฝืนโหลดกระดาน AI อัตโนมัติบนหน้าหลัก (Home Lobby) เด็ดขาด เพื่อป้องกันปัญหากระดานหายกลายเป็นจอดำ
        // จะสวมกระดาน AI เฉพาะเมื่อมี URL พารามิเตอร์ ?custom_board=ID หรือเมื่อผู้เล่นกดเลือกเล่นด้วยตนเองเท่านั้น
        const urlParams = new URLSearchParams(window.location.search);
        const paramBoardId = urlParams.get('custom_board');

        if (paramBoardId && window.availableAiCustomBoards) {
            const targetBoard = window.availableAiCustomBoards.find(b => String(b.id) === String(paramBoardId));
            if (targetBoard && window.game && typeof window.game.applyCustomBoardConfig === 'function') {
                window.game.applyCustomBoardConfig(targetBoard);
                if (typeof window.confirmBoardSelectionAndPlay === 'function') {
                    setTimeout(() => window.confirmBoardSelectionAndPlay(), 500);
                }
            }
        }
    } catch (err) {
        console.warn('[AI Boards] Could not fetch custom boards:', err);
    }
};

window.renderCustomAiBoardsInModal = function () {
    const sec = document.getElementById('custom-ai-boards-section');
    const grid = document.getElementById('custom-ai-boards-grid');
    if (!sec || !grid) return;
    const list = window.availableAiCustomBoards || [];
    if (!list.length) {
        sec.style.display = 'none';
        return;
    }
    sec.style.display = 'block';
    const shapeNames = {
        rectangle: '▭ สี่เหลี่ยมผืนผ้า',
        square: '🟩 สี่เหลี่ยมจัตุรัส',
        spiral: '🌀 ก้นหอย',
        hexagon: '⬡ หกเหลี่ยม',
        diamond_ring: '❖ วงแหวนเพชร'
    };
    grid.innerHTML = list.map(b => {
        const chCount = (b.special_tiles?.chanceTiles || []).length;
        const borderCol = b.theme_config?.border || '#00e5ff';
        return `
            <div class="board-layout-card" onclick="window.selectCustomAiBoardPlayer(${b.id}, false)" style="border-color:${borderCol}; padding:10px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <span style="font-size:10px; background:${borderCol}; color:#000; padding:2px 7px; border-radius:999px; font-weight:900;">${shapeNames[b.shape_type] || b.shape_type} ${b.grid_cols}x${b.grid_rows}</span>
                    ${b.is_default ? `<span style="font-size:10px; color:#fde047; font-weight:800;">⭐ แนะนำ</span>` : ''}
                </div>
                <div style="font-size:13px; font-weight:800; color:#fff; margin-bottom:4px;">${b.board_name}</div>
                <div style="font-size:11px; color:#cbd5e1; margin-bottom:8px;">
                    🎁 การ์ดดวง ${chCount} ช่อง • ทั้งหมด ${b.total_tiles} ช่อง
                </div>
                <button type="button" class="btn-select-layout" style="width:100%; background:linear-gradient(135deg,#10b981,#059669); color:#fff; border:none;" onclick="event.stopPropagation(); window.selectCustomAiBoardPlayer(${b.id}, true);">
                    🚀 เล่นกระดาน AI นี้ทันที!
                </button>
            </div>
        `;
    }).join('');
};

window.selectCustomAiBoardPlayer = function (boardId, startImmediately = false) {
    const b = (window.availableAiCustomBoards || []).find(x => Number(x.id) === Number(boardId));
    if (!b || !window.game) return;
    try {
        localStorage.setItem('snake_active_custom_board_id', String(b.id));
    } catch (e) { }
    window.game.applyCustomBoardConfig(b);
    if (typeof showToast === 'function') {
        showToast(`🗺️ เลือกกระดาน AI: "${b.board_name}" (${b.shape_type} ${b.grid_cols}x${b.grid_rows}) แล้ว!`);
    }
    if (startImmediately && typeof window.confirmBoardSelectionAndPlay === 'function') {
        window.confirmBoardSelectionAndPlay();
    }
};

window.cancelActiveCustomBoardPlayer = function () {
    try {
        localStorage.removeItem('snake_active_custom_board_id');
    } catch (e) { }
    if (window.game && typeof window.game.cancelCustomBoardConfig === 'function') {
        window.game.cancelCustomBoardConfig();
    }
    if (typeof showToast === 'function') {
        showToast('⏹️ ยกเลิกกระดาน AI และกลับสู่กระดานมาตรฐานเรียบร้อยแล้ว');
    }
};

// Self-healing fallback: ensure Golden 3D Board always mounts on Web, iOS & Android
window.ensureSnakeGameMounted = function () {
    if (!window.game && document.getElementById('canvas-container')) {
        try {
            window.game = new SnakeGame3D('canvas-container');
        } catch (err) {
            console.error('[SnakeGame3D] Fallback init error:', err);
        }
    }
    if (window.game) {
        const wantMonopoly = Boolean(window.game.isMonopolyBoardMode || ((window.selectedHomeGameMode || 'MONOPOLY') === 'MONOPOLY'));
        const minTiles = wantMonopoly ? 32 : 100;
        if (!window.game.boardGroup || window.game.boardGroup.children.length === 0 || !window.game.tiles || window.game.tiles.length < minTiles) {
            try {
                if (wantMonopoly && typeof window.game.buildMonopolyBoard32 === 'function') {
                    window.game.buildMonopolyBoard32(window.ACTIVE_MONOPOLY_BOARD || null);
                } else {
                    window.game.buildBoard();
                }
            } catch (bErr) {
                console.warn('[SnakeGame3D] Self-healing buildBoard warning:', bErr);
            }
        }
        if (typeof window.game.updateCameraFit === 'function') {
            window.game.updateCameraFit(true);
        }
    }
};

if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(window.ensureSnakeGameMounted, 50);
} else {
    window.addEventListener('DOMContentLoaded', window.ensureSnakeGameMounted);
    window.addEventListener('load', window.ensureSnakeGameMounted);
}
setTimeout(window.ensureSnakeGameMounted, 400);