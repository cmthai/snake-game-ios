﻿/**
 * js/monopoly_game.js
 * Monopoly 3D Game Engine (LINE Let's Get Rich Style)
 * Map: "ซากโบราณสถาน & ผนึกศักดิ์สิทธิ์" (Ancient Ruins & Sacred Seal Map)
 * Supports 1v1, 3 Players FFA, 4 Players FFA, and 2v2 Team Match
 * Integrates with Three.js WebGL canvas, 4-corner HUD, 4 Fortune Cards & Pendants
 */
(function() {
    'use strict';

    const MONOPOLY_STATE = {
        active: false,
        matchMode: 'ffa4', // '1v1' | 'ffa3' | 'ffa4' | 'team2v2'
        roomTier: '40M',
        startCapital: 40000000,
        salaryPass: 5000000,
        salaryLand: 10000000,
        turnIndex: 0,
        currentRound: 1,
        maxRounds: 30,
        timeRemainingSec: 1500, // 25:00
        timerInterval: null,
        players: [],
        cityOwnership: {}, // tileIndex -> { ownerIndex, buildings: 1..3, isLandmark: false, toll: 0, landmarkType: '' }
        selectedFortuneCardIndex: null,
        boardMeshGroup: null,
        tilesCoords: []
    };

    // 32 Tiles Definition matching the video from the user
    const ANCIENT_RUINS_TILES = [
        { index: 0, name: 'จุดเริ่มต้น', type: 'START', color: '#10b981', icon: '🚩', base_price: 0 },
        { index: 1, name: 'คริสตัล', type: 'CITY', zone: 'cyan', color: '#06b6d4', base_price: 500000, toll: 300000 },
        { index: 2, name: 'การ์ดดวง', type: 'CHANCE', zone: 'chance', color: '#f59e0b', icon: '🃏' },
        { index: 3, name: 'ประตูวิหารหิน', type: 'CITY', zone: 'cyan', color: '#06b6d4', base_price: 600000, toll: 360000 },
        { index: 4, name: 'ลูกบาศก์', type: 'CITY', zone: 'cyan', color: '#06b6d4', base_price: 750000, toll: 450000 },
        { index: 5, name: 'เทศกาลโบราณ', type: 'FESTIVAL', zone: 'event', color: '#ec4899', icon: '🎪' },
        { index: 6, name: 'วัดโบราณ', type: 'CITY', zone: 'blue', color: '#3b82f6', base_price: 900000, toll: 550000 },
        { index: 7, name: 'รูปปั้นหินแห่งปัญญา', type: 'CITY', zone: 'blue', color: '#3b82f6', base_price: 1100000, toll: 680000 },
        { index: 8, name: 'เกาะร้างโบราณ', type: 'ISLAND', zone: 'corner', color: '#64748b', icon: '🏝️' },
        { index: 9, name: 'ยักษ์ที่หลับใหล', type: 'CITY', zone: 'blue', color: '#3b82f6', base_price: 1300000, toll: 800000 },
        { index: 10, name: 'ดวงตาสู่ดูแล', type: 'CITY', zone: 'purple', color: '#8b5cf6', base_price: 1500000, toll: 950000 },
        { index: 11, name: 'การ์ดดวงโบราณ', type: 'CHANCE', zone: 'chance', color: '#f59e0b', icon: '🃏' },
        { index: 12, name: 'ซากโบราณสถาน', type: 'CITY', zone: 'purple', color: '#8b5cf6', base_price: 1800000, toll: 1150000 },
        { index: 13, name: 'ดาบของยักษ์', type: 'CITY', zone: 'purple', color: '#8b5cf6', base_price: 2100000, toll: 1350000 },
        { index: 14, name: 'ภาษีวิหารโบราณ', type: 'TAX', zone: 'tax', color: '#ef4444', icon: '🏛️' },
        { index: 15, name: 'ถอดสลับจอมเวท', type: 'CITY', zone: 'magenta', color: '#d946ef', base_price: 2400000, toll: 1600000 },
        { index: 16, name: 'ผนึกศักดิ์สิทธิ์', type: 'SEAL_ALTAR', zone: 'corner', color: '#14b8a6', icon: '💎' },
        { index: 17, name: 'รูปปั้นหินแห่งพลัง', type: 'CITY', zone: 'magenta', color: '#d946ef', base_price: 2700000, toll: 1850000 },
        { index: 18, name: 'การ์ดดวงโชคชะตา', type: 'CHANCE', zone: 'chance', color: '#f59e0b', icon: '🃏' },
        { index: 19, name: 'แท่นบูชาลอยได้', type: 'CITY', zone: 'orange', color: '#f97316', base_price: 3100000, toll: 2150000 },
        { index: 20, name: 'ประตูสู่ของคนโบราณ', type: 'CITY', zone: 'orange', color: '#f97316', base_price: 3500000, toll: 2500000 },
        { index: 21, name: 'บริจาคเมือง', type: 'DONATE', zone: 'event', color: '#eab308', icon: '💰' },
        { index: 22, name: 'หนีจากซากโบราณสถาน', type: 'CITY', zone: 'red', color: '#ef4444', base_price: 4000000, toll: 2900000 },
        { index: 23, name: 'มณีพิศวง', type: 'CITY', zone: 'red', color: '#ef4444', base_price: 4500000, toll: 3300000 },
        { index: 24, name: 'สนามบิน / ท่องเที่ยว', type: 'AIRPORT', zone: 'corner', color: '#0ea5e9', icon: '✈️' },
        { index: 25, name: 'จิตวิญญาณผู้พิทักษ์', type: 'CITY', zone: 'gold', color: '#eab308', base_price: 5000000, toll: 3800000 },
        { index: 26, name: 'การ์ดดวงมหัศจรรย์', type: 'CHANCE', zone: 'chance', color: '#f59e0b', icon: '🃏' },
        { index: 27, name: 'ปราสาททองคำโบราณ', type: 'CITY', zone: 'gold', color: '#eab308', base_price: 5500000, toll: 4200000 },
        { index: 28, name: 'หอคอยแห่งกาลเวลา', type: 'CITY', zone: 'gold', color: '#eab308', base_price: 6000000, toll: 4700000 },
        { index: 29, name: 'บ่อน้ำพุศักดิ์สิทธิ์', type: 'FESTIVAL', zone: 'event', color: '#06b6d4', icon: '⛲' },
        { index: 30, name: 'แดนเทวะเนบิวลา', type: 'CITY', zone: 'diamond', color: '#a855f7', base_price: 7000000, toll: 5500000 },
        { index: 31, name: 'ประตูสวรรค์นิรันดร์', type: 'CITY', zone: 'diamond', color: '#a855f7', base_price: 8000000, toll: 6500000 }
    ];

    function fmtMoney(n) {
        const num = Number(n || 0);
        if (num >= 1000000) {
            return (num / 1000000).toFixed(num % 1000000 === 0 ? 0 : 1) + 'M';
        }
        if (num >= 1000) {
            return (num / 1000).toFixed(0) + 'K';
        }
        return num.toLocaleString('en-US');
    }

    // Initialize 4 Players as depicted in the video thumbnail
    function createInitialPlayers(mode = 'ffa4') {
        const myName = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER.username) || 'ผู้เล่น (คุณ)';
        const myAvatar = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER.avatar_url) || 'avatars/avatar_01.svg';

        const p1 = {
            id: 1,
            name: myName,
            avatar: myAvatar,
            characterName: 'เทพเซียนมังกรฟ้า SS+',
            grade: 'SS+',
            team: 'blue',
            money: MONOPOLY_STATE.startCapital,
            position: 0,
            isInIsland: false,
            islandTurns: 0,
            hasAngelCard: true,
            citiesOwned: 0,
            color: '#38bdf8'
        };

        const p2 = {
            id: 2,
            name: 'มิโกะพฤกษา',
            avatar: 'avatars/avatar_02.svg',
            characterName: 'เทพธิดาพฤกษา SS+',
            grade: 'SS+',
            team: (mode === 'team2v2' ? 'red' : 'green'),
            money: MONOPOLY_STATE.startCapital,
            position: 0,
            isInIsland: false,
            islandTurns: 0,
            hasAngelCard: false,
            citiesOwned: 0,
            color: '#4ade80'
        };

        const p3 = {
            id: 3,
            name: 'เจ้าหญิงซากุระ',
            avatar: 'avatars/avatar_03.svg',
            characterName: 'เนบิวลาพิงค์ S+',
            grade: 'S+',
            team: (mode === 'team2v2' ? 'blue' : 'pink'),
            money: MONOPOLY_STATE.startCapital,
            position: 0,
            isInIsland: false,
            islandTurns: 0,
            hasAngelCard: true,
            citiesOwned: 0,
            color: '#ec4899'
        };

        const p4 = {
            id: 4,
            name: 'ลอร์ดดาร์คซอร์ด',
            avatar: 'avatars/avatar_01.svg',
            characterName: 'จอมราชันย์เงา SS+',
            grade: 'SS+',
            team: 'red',
            money: MONOPOLY_STATE.startCapital,
            position: 0,
            isInIsland: false,
            islandTurns: 0,
            hasAngelCard: false,
            citiesOwned: 0,
            color: '#f97316'
        };

        if (mode === '1v1') return [p1, p2];
        if (mode === 'ffa3') return [p1, p2, p3];
        return [p1, p2, p3, p4]; // ffa4 & team2v2
    }

    // Build Monopoly 3D Board Tiles in Three.js
    function buildMonopoly3DBoard(game3d) {
        if (!game3d || !game3d.scene) return;

        // Clear existing board
        while (game3d.boardGroup.children.length > 0) {
            game3d.boardGroup.remove(game3d.boardGroup.children[0]);
        }
        while (game3d.citiesGroup.children.length > 0) {
            game3d.citiesGroup.remove(game3d.citiesGroup.children[0]);
        }

        MONOPOLY_STATE.tilesCoords = [];
        const boardSize = 54.0; // 54x54 units
        const halfSize = boardSize / 2;
        const cornerSize = 7.0;
        const sideTileCount = 7; // 7 tiles between corners = 4 * 7 + 4 = 32 tiles
        const tileStep = (boardSize - cornerSize) / (sideTileCount + 1);

        // Water/Island Base
        const waterGeo = new THREE.CylinderGeometry(42, 45, 1.8, 36);
        const waterMat = new THREE.MeshStandardMaterial({
            color: 0x0369a1,
            metalness: 0.9,
            roughness: 0.1,
            transparent: true,
            opacity: 0.85
        });
        const waterMesh = new THREE.Mesh(waterGeo, waterMat);
        waterMesh.position.y = -1.2;
        game3d.boardGroup.add(waterMesh);

        // Stone Altar Platform in center (like video)
        const centerAltarGeo = new THREE.BoxGeometry(16, 2.5, 16);
        const centerAltarMat = new THREE.MeshStandardMaterial({
            color: 0x1e293b,
            metalness: 0.7,
            roughness: 0.3
        });
        const centerAltar = new THREE.Mesh(centerAltarGeo, centerAltarMat);
        centerAltar.position.set(0, -0.2, 0);
        game3d.boardGroup.add(centerAltar);

        // Calculate 32 perimeter coordinates clockwise
        // Bottom row: 0 (bottom-left) to 8 (top-left) etc.
        // In isometric: 0 (bottom), 8 (left), 16 (top), 24 (right)
        for (let i = 0; i < 32; i++) {
            let x = 0, z = 0;
            const tileInfo = ANCIENT_RUINS_TILES[i];

            if (i >= 0 && i <= 8) {
                // Bottom to Left side
                const t = i / 8;
                x = -halfSize * (1 - t) + (-halfSize) * t * 0 + (i === 0 ? 0 : 0);
                // Diamond coordinates
                x = (i - 4) * 5.8;
                z = halfSize - Math.abs(i - 4) * 1.5;
            }

            // Proper perimeter coordinate math (4 edges of 8 steps)
            const edge = Math.floor(i / 8); // 0: bottom, 1: left, 2: top, 3: right
            const step = i % 8; // 0..7
            const offset = (step - 3.5) * 6.2;

            if (edge === 0) { // Bottom row (facing player)
                x = offset;
                z = halfSize;
            } else if (edge === 1) { // Left row
                x = -halfSize;
                z = -offset;
            } else if (edge === 2) { // Top row
                x = -offset;
                z = -halfSize;
            } else { // Right row
                x = halfSize;
                z = offset;
            }

            // Rotate coordinates 45 deg for true isometric diamond look like clip
            const rad45 = Math.PI / 4;
            const rx = x * Math.cos(rad45) - z * Math.sin(rad45);
            const rz = x * Math.sin(rad45) + z * Math.cos(rad45);

            MONOPOLY_STATE.tilesCoords.push({ x: rx, y: 0.4, z: rz });

            // Create 3D Tile Block
            const isCorner = (i % 8 === 0);
            const tGeo = isCorner ? new THREE.BoxGeometry(6.4, 1.2, 6.4) : new THREE.BoxGeometry(5.2, 1.0, 5.2);
            
            let tColor = 0x1e293b;
            if (tileInfo.zone === 'cyan') tColor = 0x0891b2;
            else if (tileInfo.zone === 'blue') tColor = 0x2563eb;
            else if (tileInfo.zone === 'purple') tColor = 0x7c3aed;
            else if (tileInfo.zone === 'magenta') tColor = 0xc026d3;
            else if (tileInfo.zone === 'orange') tColor = 0xea580c;
            else if (tileInfo.zone === 'red') tColor = 0xdc2626;
            else if (tileInfo.zone === 'gold') tColor = 0xd97706;
            else if (tileInfo.zone === 'diamond') tColor = 0x9333ea;
            else if (tileInfo.type === 'START') tColor = 0x059669;
            else if (tileInfo.type === 'ISLAND') tColor = 0x475569;
            else if (tileInfo.type === 'SEAL_ALTAR') tColor = 0x0d9488;
            else if (tileInfo.type === 'AIRPORT') tColor = 0x0284c7;

            const tMat = new THREE.MeshStandardMaterial({
                color: tColor,
                metalness: 0.6,
                roughness: 0.35
            });
            const tileMesh = new THREE.Mesh(tGeo, tMat);
            tileMesh.position.set(rx, 0.4, rz);
            tileMesh.rotation.y = rad45;
            tileMesh.receiveShadow = true;
            game3d.boardGroup.add(tileMesh);

            // Glowing Border
            const edgeGeo = new THREE.EdgesGeometry(tGeo);
            const edgeMat = new THREE.LineBasicMaterial({
                color: isCorner ? 0xffd700 : 0x38bdf8,
                linewidth: 2
            });
            const edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
            edgeLines.position.set(rx, 0.4, rz);
            edgeLines.rotation.y = rad45;
            game3d.boardGroup.add(edgeLines);

            // Special Corner Ornaments
            if (i === 16) {
                // Sacred Seal Gemstone (Corner 16 - Top)
                const gemGeo = new THREE.OctahedronGeometry(2.4, 0);
                const gemMat = new THREE.MeshStandardMaterial({
                    color: 0x00e5ff,
                    emissive: 0x00a3c4,
                    emissiveIntensity: 0.8,
                    metalness: 0.9,
                    roughness: 0.1
                });
                const gemMesh = new THREE.Mesh(gemGeo, gemMat);
                gemMesh.position.set(rx, 3.8, rz);
                game3d.boardGroup.add(gemMesh);
            } else if (i === 24) {
                // Airport Airplane / Travel Ring (Corner 24 - Right)
                const ringGeo = new THREE.TorusGeometry(2.2, 0.35, 12, 32);
                const ringMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.8 });
                const ringMesh = new THREE.Mesh(ringGeo, ringMat);
                ringMesh.position.set(rx, 2.6, rz);
                ringMesh.rotation.x = Math.PI / 2;
                game3d.boardGroup.add(ringMesh);
            }
        }

        // Camera settings for Ancient Ruins Monopoly View
        game3d.camera.fov = 46;
        game3d.camera.position.set(0, 52, 62);
        game3d.camera.lookAt(0, 0, 0);
        game3d.camera.updateProjectionMatrix();

        if (game3d.controls) {
            game3d.controls.target.set(0, 0, 0);
            game3d.controls.update();
        }
    }

    // Render the 4-Corner HUD Overlay matching the video
    function renderMonopoly4CornerHud() {
        let hud = document.getElementById('monopoly-4corner-hud');
        if (!hud) {
            hud = document.createElement('div');
            hud.id = 'monopoly-4corner-hud';
            hud.className = 'monopoly-4corner-hud';
            document.body.appendChild(hud);
        }

        const p = MONOPOLY_STATE.players;
        const p1 = p[0] || {};
        const p2 = p[1] || {};
        const p3 = p[2] || {};
        const p4 = p[3] || {};

        hud.innerHTML = `
            <!-- Top Center Round & Timer Bar (เหมือนในคลิป: เวลา 25:00 รอบ 30 / 40M) -->
            <div class="mono-center-info-bar">
                <div class="mono-round-timer-pill">
                    <span class="mono-timer-text">เวลา <span id="mono-timer-val">25:00</span></span>
                    <span class="mono-divider">•</span>
                    <span class="mono-round-text">รอบ <span id="mono-round-val">${MONOPOLY_STATE.currentRound}</span>/${MONOPOLY_STATE.maxRounds}</span>
                </div>
                <div class="mono-capital-pill">${fmtMoney(MONOPOLY_STATE.startCapital)}</div>
            </div>

            <!-- Top Left: Player 1 Profile Card -->
            <div class="mono-player-card corner-tl active-turn" id="mono-card-p1">
                <div class="mono-avatar-wrap">
                    <div class="mono-avatar-ring"></div>
                    <img src="${p1.avatar || 'avatars/avatar_01.svg'}" alt="${p1.name}">
                    <span class="mono-grade-tag">${p1.grade || 'SS+'}</span>
                </div>
                <div class="mono-player-info">
                    <div class="mono-player-name">${p1.name} (คุณ)</div>
                    <div class="mono-player-money" id="mono-money-p1">🪙 ${fmtMoney(p1.money)}</div>
                    <div class="mono-player-sub">👑 ${p1.characterName || 'ดาราจักร SS+'}</div>
                </div>
                <div class="mono-turn-arrow">▶</div>
            </div>

            <!-- Top Right: Player 2 Profile Card -->
            <div class="mono-player-card corner-tr" id="mono-card-p2">
                <div class="mono-avatar-wrap">
                    <div class="mono-avatar-ring"></div>
                    <img src="${p2.avatar || 'avatars/avatar_02.svg'}" alt="${p2.name}">
                    <span class="mono-grade-tag">${p2.grade || 'SS+'}</span>
                </div>
                <div class="mono-player-info">
                    <div class="mono-player-name">${p2.name || 'ผู้เล่น 2'}</div>
                    <div class="mono-player-money" id="mono-money-p2">🪙 ${fmtMoney(p2.money)}</div>
                    <div class="mono-player-sub">👑 ${p2.characterName || 'มิโกะพฤกษา SS+'}</div>
                </div>
                <div class="mono-turn-arrow">▶</div>
            </div>

            <!-- Bottom Left: Player 3 Profile Card -->
            ${p3.id ? `
            <div class="mono-player-card corner-bl" id="mono-card-p3">
                <div class="mono-avatar-wrap">
                    <div class="mono-avatar-ring"></div>
                    <img src="${p3.avatar || 'avatars/avatar_03.svg'}" alt="${p3.name}">
                    <span class="mono-grade-tag">${p3.grade || 'S+'}</span>
                </div>
                <div class="mono-player-info">
                    <div class="mono-player-name">${p3.name}</div>
                    <div class="mono-player-money" id="mono-money-p3">🪙 ${fmtMoney(p3.money)}</div>
                    <div class="mono-player-sub">👑 ${p3.characterName || 'ซากุระ S+'}</div>
                </div>
                <div class="mono-turn-arrow">▶</div>
            </div>
            ` : ''}

            <!-- Bottom Right: Player 4 Profile Card -->
            ${p4.id ? `
            <div class="mono-player-card corner-br" id="mono-card-p4">
                <div class="mono-avatar-wrap">
                    <div class="mono-avatar-ring"></div>
                    <img src="${p4.avatar || 'avatars/avatar_01.svg'}" alt="${p4.name}">
                    <span class="mono-grade-tag">${p4.grade || 'SS+'}</span>
                </div>
                <div class="mono-player-info">
                    <div class="mono-player-name">${p4.name}</div>
                    <div class="mono-player-money" id="mono-money-p4">🪙 ${fmtMoney(p4.money)}</div>
                    <div class="mono-player-sub">👑 ${p4.characterName || 'ราชันย์เงา SS+'}</div>
                </div>
                <div class="mono-turn-arrow">▶</div>
            </div>
            ` : ''}

            <!-- Left Controls: 3D Camera & Sound -->
            <div class="mono-left-quick-bar">
                <button type="button" class="mono-btn-circle" onclick="toggleMonopolyCameraView()" title="เปลี่ยนมุมกล้อง 3D">
                    🎥
                </button>
                <button type="button" class="mono-btn-circle" onclick="showMonopolyFortunePopup()" title="ทดสอบการ์ดดวง 4 ใบ">
                    🃏
                </button>
            </div>

            <!-- Bottom Dock: Action Controls (Roll Dice, Auto, Pendants) -->
            <div class="mono-bottom-dock">
                <div class="mono-pendants-bar">
                    <div class="mono-pendant-slot active" title="โล่คุ้มครองนางฟ้า">🛡️</div>
                    <div class="mono-pendant-slot active" title="แม่เหล็กมหาเศรษฐี">🧲</div>
                    <div class="mono-pendant-slot active" title="ตั๋วเครื่องบินช่วยด่วน">🚀</div>
                    <div class="mono-pendant-slot" title="ช่องใส่จี้ 4">+</div>
                </div>
                <div class="mono-dice-action-group">
                    <button type="button" class="btn-mono-roll" id="btn-mono-roll" onclick="executeMonopolyTurnRoll()">
                        <span class="roll-glow"></span>
                        <span class="roll-icon">🎲</span>
                        <span class="roll-text">ทอยเต๋า</span>
                    </button>
                    <button type="button" class="btn-mono-auto" onclick="toggleMonopolyAutoPlay()">
                        ⚡ AUTO
                    </button>
                </div>
            </div>
        `;

        hud.style.display = 'block';
        startMonopolyTimer();
    }

    function startMonopolyTimer() {
        if (MONOPOLY_STATE.timerInterval) clearInterval(MONOPOLY_STATE.timerInterval);
        MONOPOLY_STATE.timerInterval = setInterval(() => {
            if (MONOPOLY_STATE.timeRemainingSec > 0) {
                MONOPOLY_STATE.timeRemainingSec--;
                const m = Math.floor(MONOPOLY_STATE.timeRemainingSec / 60);
                const s = Math.floor(MONOPOLY_STATE.timeRemainingSec % 60);
                const el = document.getElementById('mono-timer-val');
                if (el) el.innerText = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
            }
        }, 1000);
    }

    // Fortune Cards Modal (การ์ดดวง 4 ใบ เหมือนในคลิป)
    window.showMonopolyFortunePopup = function() {
        let modal = document.getElementById('modal-monopoly-fortune-cards');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'modal-monopoly-fortune-cards';
            modal.className = 'modal-overlay mono-fortune-overlay';
            modal.style.cssText = 'display:none; z-index:100500; background:rgba(0,0,0,0.85); backdrop-filter:blur(10px);';
            document.body.appendChild(modal);
        }

        modal.innerHTML = `
            <div class="mono-fortune-box">
                <div class="mono-fortune-header">
                    <div class="mono-fortune-badge">✨ CHANCE & FORTUNE CARD ✨</div>
                    <h2 class="mono-fortune-title">เลือกการ์ดดวงโบราณ (1 ใน 4 ใบ)</h2>
                    <div class="mono-fortune-sub">แตะการ์ดที่คุณต้องการเปิดเพื่อรับพรศักดิ์สิทธิ์หรือเอฟเฟกต์พิเศษ</div>
                </div>

                <!-- 4 Fortune Cards on Table matching video -->
                <div class="mono-fortune-cards-row">
                    <div class="mono-fortune-card-item" onclick="selectMonopolyFortuneCard(0, this)">
                        <div class="mono-card-inner">
                            <div class="mono-card-back">
                                <div class="mono-card-pattern">FORTUNE</div>
                                <div class="mono-check-badge">✔</div>
                            </div>
                        </div>
                    </div>
                    <div class="mono-fortune-card-item" onclick="selectMonopolyFortuneCard(1, this)">
                        <div class="mono-card-inner">
                            <div class="mono-card-back">
                                <div class="mono-card-pattern">FORTUNE</div>
                                <div class="mono-check-badge">✔</div>
                            </div>
                        </div>
                    </div>
                    <div class="mono-fortune-card-item" onclick="selectMonopolyFortuneCard(2, this)">
                        <div class="mono-card-inner">
                            <div class="mono-card-back">
                                <div class="mono-card-pattern">FORTUNE</div>
                                <div class="mono-check-badge">✔</div>
                            </div>
                        </div>
                    </div>
                    <div class="mono-fortune-card-item" onclick="selectMonopolyFortuneCard(3, this)">
                        <div class="mono-card-inner">
                            <div class="mono-card-back">
                                <div class="mono-card-pattern">FORTUNE</div>
                                <div class="mono-check-badge">✔</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="mono-fortune-result-banner" class="mono-fortune-result" style="display:none;"></div>
            </div>
        `;

        modal.style.display = 'flex';
        if (window.soundEngine && typeof window.soundEngine.playCardOpen === 'function') {
            try { window.soundEngine.playCardOpen(); } catch(e) {}
        }
    };

    window.selectMonopolyFortuneCard = function(cardIndex, el) {
        if (el.classList.contains('selected')) return;
        
        // Mark selected card with blue checkmark badge as seen in video!
        document.querySelectorAll('.mono-fortune-card-item').forEach(c => c.classList.remove('selected'));
        el.classList.add('selected');

        if (window.soundEngine && typeof window.soundEngine.playCardOpen === 'function') {
            try { window.soundEngine.playCardOpen(); } catch(e) {}
        }

        const outcomes = [
            { title: '🛡️ การ์ดนางฟ้าคุ้มครอง (Angel Card)', desc: 'ได้รับการยกเว้นค่าผ่านทางและป้องกันการโจมตี 1 ครั้งทันที!' },
            { title: '✈️ ตั๋วบินด่วนสู่สนามบิน (Instant World Travel)', desc: 'บินตรงสู่ช่องสนามบินทันที เพื่อเตรียมบินไปช่องใดก็ได้ในตาถัดไป!' },
            { title: '💰 ทรัพย์สมบัติโบราณ (+10,000,000 ทอง)', desc: 'ได้รับเงินสนับสนุนจากวิหารศักดิ์สิทธิ์ +10M เข้าสู่กระเป๋า!' },
            { title: '🌪️ พายุทรายซากโบราณสถาน', desc: 'ส่งคู่แข่งที่มีเงินมากที่สุดไปติดเกาะร้าง 3 เทิร์น!' }
        ];

        const chosen = outcomes[cardIndex % outcomes.length];
        const resBanner = document.getElementById('mono-fortune-result-banner');
        if (resBanner) {
            resBanner.innerHTML = `
                <div style="font-size:15px; font-weight:800; color:#ffd700; margin-bottom:4px;">${chosen.title}</div>
                <div style="font-size:12px; color:#e2e8f0; margin-bottom:12px;">${chosen.desc}</div>
                <button type="button" class="btn btn-accent" style="padding:6px 18px; font-size:12.5px; font-weight:800;" onclick="closeMonopolyFortunePopup()">
                    รับผลการ์ด & ดำเนินการต่อ
                </button>
            `;
            resBanner.style.display = 'block';
        }
    };

    window.closeMonopolyFortunePopup = function() {
        const modal = document.getElementById('modal-monopoly-fortune-cards');
        if (modal) modal.style.display = 'none';
    };

    // Roll Turn Logic
    window.executeMonopolyTurnRoll = async function() {
        const btn = document.getElementById('btn-mono-roll');
        if (btn) btn.disabled = true;

        const d1 = Math.floor(Math.random() * 6) + 1;
        const d2 = Math.floor(Math.random() * 6) + 1;
        const sum = d1 + d2;
        const isDouble = (d1 === d2);

        // Play dice roll animation & sound
        if (window.gameInstance && typeof window.gameInstance.rollDiceAnimation === 'function') {
            try { await window.gameInstance.rollDiceAnimation(d1, d2); } catch(e) {}
        }

        const p = MONOPOLY_STATE.players[MONOPOLY_STATE.turnIndex];
        if (p) {
            const oldPos = p.position;
            p.position = (p.position + sum) % 32;

            // Salary bonus when passing START
            if (p.position < oldPos) {
                p.money += MONOPOLY_STATE.salaryPass;
                alert(`🚩 ${p.name} เดินผ่านจุดเริ่มต้น! รับเงินเดือน +${fmtMoney(MONOPOLY_STATE.salaryPass)}`);
            }

            // Update Pawn 3D Position
            const targetCoord = MONOPOLY_STATE.tilesCoords[p.position];
            if (targetCoord && window.gameInstance && window.gameInstance.pawnsGroup) {
                // Smooth pawn translation
                const pawn = window.gameInstance.pawnsGroup.children[MONOPOLY_STATE.turnIndex];
                if (pawn) {
                    pawn.position.set(targetCoord.x, targetCoord.y + 0.8, targetCoord.z);
                }
            }

            const landingTile = ANCIENT_RUINS_TILES[p.position];
            if (landingTile) {
                if (landingTile.type === 'CHANCE') {
                    setTimeout(() => window.showMonopolyFortunePopup(), 600);
                } else if (landingTile.type === 'SEAL_ALTAR') {
                    alert(`💎 ${p.name} ตกแท่นบูชาผนึกศักดิ์สิทธิ์! พลังแห่งโบราณสถานเพิ่มค่าผ่านทางเมืองของคุณ X2 เท่า!`);
                } else if (landingTile.type === 'ISLAND') {
                    alert(`🏝️ ${p.name} เดินทางมาติดเกาะร้างโบราณ! พักผ่อน 3 เทิร์น`);
                }
            }

            // Update HUD
            const moneyEl = document.getElementById(`mono-money-p${p.id}`);
            if (moneyEl) moneyEl.innerText = `🪙 ${fmtMoney(p.money)}`;
        }

        // Advance turn
        setTimeout(() => {
            MONOPOLY_STATE.turnIndex = (MONOPOLY_STATE.turnIndex + 1) % MONOPOLY_STATE.players.length;
            if (MONOPOLY_STATE.turnIndex === 0) {
                MONOPOLY_STATE.currentRound = Math.min(MONOPOLY_STATE.maxRounds, MONOPOLY_STATE.currentRound + 1);
                const rEl = document.getElementById('mono-round-val');
                if (rEl) rEl.innerText = MONOPOLY_STATE.currentRound;
            }

            // Highlight active player card
            for (let i = 1; i <= 4; i++) {
                const card = document.getElementById(`mono-card-p${i}`);
                if (card) {
                    card.classList.toggle('active-turn', i - 1 === MONOPOLY_STATE.turnIndex);
                }
            }

            if (btn) btn.disabled = false;
        }, 1200);
    };

    window.toggleMonopolyCameraView = function() {
        if (!window.gameInstance || !window.gameInstance.camera) return;
        const cam = window.gameInstance.camera;
        if (cam.position.y > 60) {
            // Isometric close view
            cam.position.set(0, 48, 56);
        } else {
            // High altitude full view
            cam.position.set(0, 68, 76);
        }
        cam.lookAt(0, 0, 0);
        cam.updateProjectionMatrix();
    };

    // Public API to launch Monopoly 3D Mode
    window.launchMonopoly3DGame = function(options = {}) {
        MONOPOLY_STATE.active = true;
        MONOPOLY_STATE.matchMode = options.matchMode || 'ffa4';
        MONOPOLY_STATE.roomTier = options.roomTier || '40M';
        MONOPOLY_STATE.startCapital = (options.roomTier === '40M' ? 40000000 : (options.roomTier === '10M' ? 10000000 : 2000000));
        MONOPOLY_STATE.players = createInitialPlayers(MONOPOLY_STATE.matchMode);

        // Hide standard snake & ladder HUD if active
        const snakeLog = document.querySelector('.game-log-panel');
        if (snakeLog) snakeLog.style.display = 'none';

        // Rebuild 3D board to Ancient Ruins Map
        if (window.gameInstance) {
            buildMonopoly3DBoard(window.gameInstance);
        }

        renderMonopoly4CornerHud();

        // Close Game Mode Modal
        window.closeGameModeSelectModal();

        alert(`🏰 ยินดีต้อนรับสู่ศึกเกมเศรษฐีเวิลด์ 3D!\nแผนที่: ซากโบราณสถาน & ผนึกศักดิ์สิทธิ์\nโหมด: ${MONOPOLY_STATE.matchMode.toUpperCase()} • เงินทุน ${fmtMoney(MONOPOLY_STATE.startCapital)}`);
    };

    window.exitMonopolyModeToSnake = function() {
        MONOPOLY_STATE.active = false;
        if (MONOPOLY_STATE.timerInterval) clearInterval(MONOPOLY_STATE.timerInterval);
        const hud = document.getElementById('monopoly-4corner-hud');
        if (hud) hud.style.display = 'none';

        if (window.gameInstance) {
            window.gameInstance.setBoardLayout('square');
            window.gameInstance.buildBoard();
        }

        const snakeLog = document.querySelector('.game-log-panel');
        if (snakeLog) snakeLog.style.display = 'block';

        alert('🐍 สลับกลับสู่โหมดบันไดงู 3D คลาสสิกแล้ว');
    };

    let selectedGameMode = 'monopoly';
    let selectedMatchMode = 'ffa4';
    let selectedRoomTier = '40M';

    window.openGameModeSelectModal = function() {
        const modal = document.getElementById('modal-game-mode-select');
        if (modal) modal.style.display = 'flex';
    };

    window.closeGameModeSelectModal = function() {
        const modal = document.getElementById('modal-game-mode-select');
        if (modal) modal.style.display = 'none';
    };

    window.selectGameModeChoice = function(mode) {
        selectedGameMode = mode;
        const snakeCard = document.getElementById('choice-mode-snake');
        const monoCard = document.getElementById('choice-mode-monopoly');
        const settingsBox = document.getElementById('monopoly-mode-settings-box');
        const btnLabel = document.querySelector('#btn-start-game-mode-action .btn-complete-label');

        if (mode === 'snake') {
            if (snakeCard) snakeCard.classList.add('selected');
            if (monoCard) monoCard.classList.remove('selected');
            if (settingsBox) settingsBox.style.display = 'none';
            if (btnLabel) btnLabel.innerText = '✨ เริ่มเล่นโหมดบันไดงู 3D คลาสสิก ✨';
        } else {
            if (snakeCard) snakeCard.classList.remove('selected');
            if (monoCard) monoCard.classList.add('selected');
            if (settingsBox) settingsBox.style.display = 'block';
            if (btnLabel) btnLabel.innerText = '✨ เริ่มศึกเกมเศรษฐีเวิลด์ 3D (ซากโบราณสถาน) ✨';
        }
    };

    window.setMonopolyMatchMode = function(type) {
        selectedMatchMode = type;
        const pills = ['1v1', 'ffa3', 'ffa4', 'team2v2'];
        pills.forEach(p => {
            const el = document.getElementById('pill-match-' + p);
            if (el) el.classList.toggle('active', p === type);
        });
    };

    window.setMonopolyRoomTier = function(tier) {
        selectedRoomTier = tier;
        const tiers = ['2M', '10M', '40M'];
        tiers.forEach(t => {
            const el = document.getElementById('tier-btn-' + t);
            if (el) {
                if (t === tier) {
                    el.style.background = 'rgba(255,215,0,0.2)';
                    el.style.color = '#ffd700';
                    el.style.borderColor = '#ffd700';
                    el.style.fontWeight = '800';
                } else {
                    el.style.background = '#1e293b';
                    el.style.color = '#cbd5e1';
                    el.style.borderColor = '#475569';
                    el.style.fontWeight = 'normal';
                }
            }
        });
    };

    window.confirmStartGameModeAction = function() {
        if (selectedGameMode === 'snake') {
            window.closeGameModeSelectModal();
            if (typeof window.exitMonopolyModeToSnake === 'function') {
                window.exitMonopolyModeToSnake();
            }
        } else {
            window.launchMonopoly3DGame({
                matchMode: selectedMatchMode,
                roomTier: selectedRoomTier
            });
        }
    };

    // Expose Global State
    window.MONOPOLY_STATE = MONOPOLY_STATE;

})();
