/**
 * js/chess_pawn_3d.js
 * Royalty-Free Procedural 3D Chess Pawn & Aura/Effect Builder (Three.js)
 * Shared between Admin Panel Live 3D Preview and In-Game 3D Board (Snake & Ladder + Monopoly)
 */
(function (window) {
    'use strict';

    const DEFAULT_PAWN_ICON_CONFIG = {
        enabled: false,
        global_mode: 'frame', // 'frame' | 'chess_icon'
        apply_to_bots: true,
        apply_to_modes: {
            snake: true,
            monopoly: true
        },
        grades: {
            'DEFAULT': {
                mode: 'inherit',
                piece: 'pawn',
                primary_color: '#38bdf8',
                accent_color: '#ffd700',
                aura_color: '#00e5ff',
                glow_intensity: 0.80,
                effect: 'pulse_aura',
                scale: 1.0
            },
            'A': {
                mode: 'inherit',
                piece: 'pawn',
                primary_color: '#60a5fa',
                accent_color: '#e2e8f0',
                aura_color: '#38bdf8',
                glow_intensity: 0.65,
                effect: 'pulse_aura',
                scale: 0.95
            },
            'A+': {
                mode: 'inherit',
                piece: 'knight',
                primary_color: '#34d399',
                accent_color: '#fde047',
                aura_color: '#10b981',
                glow_intensity: 0.75,
                effect: 'pulse_aura',
                scale: 1.0
            },
            'S': {
                mode: 'inherit',
                piece: 'bishop',
                primary_color: '#a855f7',
                accent_color: '#facc15',
                aura_color: '#c084fc',
                glow_intensity: 0.90,
                effect: 'orbit_ring',
                scale: 1.05
            },
            'S+': {
                mode: 'inherit',
                piece: 'rook',
                primary_color: '#f97316',
                accent_color: '#fef08a',
                aura_color: '#fb923c',
                glow_intensity: 1.0,
                effect: 'orbit_ring',
                scale: 1.10
            },
            'SS+': {
                mode: 'inherit',
                piece: 'queen',
                primary_color: '#ec4899',
                accent_color: '#ffd700',
                aura_color: '#f472b6',
                glow_intensity: 1.15,
                effect: 'sparkle_crown',
                scale: 1.15
            },
            'Z+': {
                mode: 'inherit',
                piece: 'king',
                primary_color: '#ef4444',
                accent_color: '#ffd700',
                aura_color: '#fbbf24',
                glow_intensity: 1.35,
                effect: 'holo_float',
                scale: 1.22
            }
        }
    };

    const PIECE_META = [
        { id: 'king', label: 'ราชา (King)', icon: '👑' },
        { id: 'queen', label: 'ราชินี (Queen)', icon: '👸' },
        { id: 'rook', label: 'ป้อมปราการ (Rook)', icon: '🏰' },
        { id: 'bishop', label: 'บิชอป (Bishop)', icon: '♗' },
        { id: 'knight', label: 'อัศวินม้า (Knight)', icon: '🐴' },
        { id: 'pawn', label: 'เบี้ยคริสตัล (Pawn)', icon: '♟️' },
        { id: 'crystal', label: 'โทเทมเพชร (Crystal)', icon: '💎' }
    ];

    const EFFECT_META = [
        { id: 'none', label: 'ปกติ (ไม่มีเอฟเฟกต์พิเศษ)' },
        { id: 'pulse_aura', label: '✨ ออร่าเต้นเป็นจังหวะ (Pulse Aura)' },
        { id: 'orbit_ring', label: '🌀 วงแหวนพลังงานหมุนรอบ (Orbit Ring)' },
        { id: 'sparkle_crown', label: '🌟 ประกายดาวรอบตัวหมาก (Sparkle Crown)' },
        { id: 'holo_float', label: '🚀 ลอยตัวหมุน + เออร่าเต็มพิกัด (Holo Float)' }
    ];

    function normalizeGradeKey(grade) {
        if (!grade) return 'DEFAULT';
        const g = String(grade).trim().toUpperCase().replace(/\s+/g, '');
        if (g === 'ZZ+' || g === 'ZZ' || g === 'Z' || g === 'Z+') return 'Z+';
        if (g === 'SS+' || g === 'SS') return 'SS+';
        if (g === 'S+') return 'S+';
        if (g === 'S') return 'S';
        if (g === 'A+') return 'A+';
        if (g === 'A') return 'A';
        return 'DEFAULT';
    }

    function mergeConfig(raw) {
        const base = JSON.parse(JSON.stringify(DEFAULT_PAWN_ICON_CONFIG));
        if (!raw || typeof raw !== 'object') return base;
        base.enabled = Boolean(raw.enabled);
        base.global_mode = (raw.global_mode === 'chess_icon') ? 'chess_icon' : 'frame';
        base.apply_to_bots = (raw.apply_to_bots !== undefined) ? Boolean(raw.apply_to_bots) : true;
        if (raw.apply_to_modes && typeof raw.apply_to_modes === 'object') {
            base.apply_to_modes.snake = (raw.apply_to_modes.snake !== undefined) ? Boolean(raw.apply_to_modes.snake) : true;
            base.apply_to_modes.monopoly = (raw.apply_to_modes.monopoly !== undefined) ? Boolean(raw.apply_to_modes.monopoly) : true;
        }
        if (raw.grades && typeof raw.grades === 'object') {
            Object.keys(base.grades).forEach(gk => {
                if (raw.grades[gk] && typeof raw.grades[gk] === 'object') {
                    base.grades[gk] = {
                        ...base.grades[gk],
                        ...raw.grades[gk]
                    };
                }
            });
        }
        return base;
    }

    function resolveForPlayer(configRaw, grade, gameMode = 'monopoly', isBot = false) {
        const cfg = mergeConfig(configRaw);
        if (!cfg.enabled) {
            return { useChessIcon: false, style: cfg.grades.DEFAULT };
        }
        const modeKey = (gameMode === 'snake') ? 'snake' : 'monopoly';
        if (cfg.apply_to_modes && cfg.apply_to_modes[modeKey] === false) {
            return { useChessIcon: false, style: cfg.grades.DEFAULT };
        }
        if (isBot && cfg.apply_to_bots === false) {
            return { useChessIcon: false, style: cfg.grades.DEFAULT };
        }
        const gk = normalizeGradeKey(grade);
        const gStyle = cfg.grades[gk] || cfg.grades.DEFAULT;
        const effectiveMode = (gStyle.mode && gStyle.mode !== 'inherit') ? gStyle.mode : cfg.global_mode;
        return {
            useChessIcon: effectiveMode === 'chess_icon',
            style: gStyle,
            gradeKey: gk
        };
    }

    function buildPieceGroup(THREE, style = {}) {
        if (!THREE) return null;
        const pieceType = style.piece || 'king';
        const primaryHex = style.primary_color || '#38bdf8';
        const accentHex = style.accent_color || '#ffd700';
        const auraHex = style.aura_color || '#00e5ff';
        const glowIntensity = Math.max(0, Math.min(2.5, Number(style.glow_intensity ?? 0.85)));
        const effect = style.effect || 'pulse_aura';
        const scale = Math.max(0.6, Math.min(1.8, Number(style.scale ?? 1.0)));

        const root = new THREE.Group();
        const bodyGroup = new THREE.Group();
        root.add(bodyGroup);

        const primaryCol = new THREE.Color(primaryHex);
        const accentCol = new THREE.Color(accentHex);
        const auraCol = new THREE.Color(auraHex);

        const bodyMat = new THREE.MeshStandardMaterial({
            color: primaryCol,
            metalness: 0.68,
            roughness: 0.22,
            emissive: primaryCol,
            emissiveIntensity: 0.22 * glowIntensity
        });

        const accentMat = new THREE.MeshStandardMaterial({
            color: accentCol,
            metalness: 0.85,
            roughness: 0.16,
            emissive: accentCol,
            emissiveIntensity: 0.35 * glowIntensity
        });

        const gemMat = new THREE.MeshStandardMaterial({
            color: auraCol,
            metalness: 0.35,
            roughness: 0.08,
            emissive: auraCol,
            emissiveIntensity: 0.85 * glowIntensity
        });

        // Shared Lathe Pedestal Helper
        const addLatheProfile = (points, mat, segs = 28) => {
            const vecs = points.map(([r, y]) => new THREE.Vector2(r, y));
            const geo = new THREE.LatheGeometry(vecs, segs);
            const mesh = new THREE.Mesh(geo, mat);
            mesh.castShadow = true;
            bodyGroup.add(mesh);
            return mesh;
        };

        // Base metallic collar ring
        const addBaseRing = (y, r, tube = 0.045) => {
            const ring = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 12, 32), accentMat);
            ring.rotation.x = Math.PI / 2;
            ring.position.y = y;
            bodyGroup.add(ring);
            return ring;
        };

        if (pieceType === 'king') {
            addLatheProfile([
                [0.0, 0.0], [0.78, 0.0], [0.78, 0.14], [0.66, 0.24],
                [0.60, 0.32], [0.46, 0.42], [0.34, 0.90], [0.28, 1.38],
                [0.44, 1.50], [0.36, 1.62], [0.48, 1.98], [0.38, 2.08],
                [0.0, 2.08]
            ], bodyMat);
            addBaseRing(0.16, 0.74, 0.045);
            addBaseRing(1.52, 0.43, 0.04);
            // Crown points
            for (let i = 0; i < 6; i++) {
                const ang = (i / 6) * Math.PI * 2;
                const spike = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 6), accentMat);
                spike.position.set(Math.cos(ang) * 0.38, 2.16, Math.sin(ang) * 0.38);
                bodyGroup.add(spike);
            }
            // Royal Cross + Gem Finial
            const vBar = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.44, 0.11), accentMat);
            vBar.position.y = 2.34;
            const hBar = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.11, 0.11), accentMat);
            hBar.position.y = 2.38;
            const crownGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), gemMat);
            crownGem.position.set(0, 2.38, 0.09);
            bodyGroup.add(vBar, hBar, crownGem);
        } else if (pieceType === 'queen') {
            addLatheProfile([
                [0.0, 0.0], [0.74, 0.0], [0.74, 0.14], [0.62, 0.24],
                [0.44, 0.40], [0.28, 0.95], [0.24, 1.38], [0.40, 1.50],
                [0.30, 1.60], [0.46, 1.96], [0.30, 1.98], [0.0, 1.92]
            ], bodyMat);
            addBaseRing(0.16, 0.70, 0.04);
            addBaseRing(1.50, 0.40, 0.038);
            for (let i = 0; i < 8; i++) {
                const ang = (i / 8) * Math.PI * 2;
                const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), accentMat);
                pearl.position.set(Math.cos(ang) * 0.42, 2.03, Math.sin(ang) * 0.42);
                bodyGroup.add(pearl);
            }
            const orb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 18, 18), gemMat);
            orb.position.y = 2.12;
            bodyGroup.add(orb);
        } else if (pieceType === 'rook') {
            addLatheProfile([
                [0.0, 0.0], [0.76, 0.0], [0.76, 0.16], [0.64, 0.26],
                [0.48, 0.40], [0.42, 1.25], [0.54, 1.42], [0.54, 1.78],
                [0.32, 1.78], [0.32, 1.55], [0.0, 1.55]
            ], bodyMat);
            addBaseRing(0.16, 0.72, 0.045);
            addBaseRing(1.40, 0.54, 0.04);
            for (let i = 0; i < 4; i++) {
                const ang = (i / 4) * Math.PI * 2 + Math.PI / 4;
                const merlon = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.24, 0.22), accentMat);
                merlon.position.set(Math.cos(ang) * 0.42, 1.88, Math.sin(ang) * 0.42);
                merlon.rotation.y = -ang;
                bodyGroup.add(merlon);
            }
            const coreGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.18), gemMat);
            coreGem.position.y = 1.82;
            bodyGroup.add(coreGem);
        } else if (pieceType === 'bishop') {
            addLatheProfile([
                [0.0, 0.0], [0.72, 0.0], [0.72, 0.14], [0.60, 0.24],
                [0.44, 0.40], [0.28, 0.98], [0.26, 1.32], [0.38, 1.42],
                [0.24, 1.50], [0.34, 1.74], [0.26, 1.98], [0.08, 2.14],
                [0.0, 2.16]
            ], bodyMat);
            addBaseRing(0.15, 0.68, 0.04);
            addBaseRing(1.42, 0.38, 0.038);
            const finial = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 16), gemMat);
            finial.position.y = 2.22;
            bodyGroup.add(finial);
        } else if (pieceType === 'knight') {
            addLatheProfile([
                [0.0, 0.0], [0.74, 0.0], [0.74, 0.15], [0.62, 0.26],
                [0.48, 0.42], [0.42, 0.56], [0.0, 0.56]
            ], bodyMat);
            addBaseRing(0.16, 0.70, 0.042);
            // Sculpted Geometric Knight Head & Neck
            const neck = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.85, 0.58), bodyMat);
            neck.position.set(0, 0.94, -0.05);
            neck.rotation.x = 0.22;
            const head = new THREE.Mesh(new THREE.BoxGeometry(0.40, 0.42, 0.76), bodyMat);
            head.position.set(0, 1.50, 0.18);
            head.rotation.x = 0.35;
            const snout = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.28, 0.40), accentMat);
            snout.position.set(0, 1.38, 0.56);
            snout.rotation.x = 0.40;
            const mane = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.92, 0.24), gemMat);
            mane.position.set(0, 1.24, -0.32);
            mane.rotation.x = 0.18;
            const earL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.26, 4), accentMat);
            earL.position.set(-0.14, 1.82, -0.04);
            const earR = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.26, 4), accentMat);
            earR.position.set(0.14, 1.82, -0.04);
            bodyGroup.add(neck, head, snout, mane, earL, earR);
        } else if (pieceType === 'crystal') {
            addLatheProfile([
                [0.0, 0.0], [0.72, 0.0], [0.72, 0.14], [0.58, 0.24],
                [0.46, 0.36], [0.0, 0.36]
            ], bodyMat);
            addBaseRing(0.15, 0.68, 0.04);
            const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.58, 0), gemMat);
            crystal.scale.set(0.85, 1.45, 0.85);
            crystal.position.y = 1.28;
            const cage = new THREE.Mesh(new THREE.TorusGeometry(0.64, 0.035, 10, 32), accentMat);
            cage.position.y = 1.28;
            cage.rotation.x = Math.PI / 3;
            bodyGroup.add(crystal, cage);
        } else {
            // 'pawn'
            addLatheProfile([
                [0.0, 0.0], [0.68, 0.0], [0.68, 0.14], [0.56, 0.24],
                [0.40, 0.40], [0.24, 0.95], [0.20, 1.22], [0.34, 1.32],
                [0.20, 1.40], [0.0, 1.40]
            ], bodyMat);
            addBaseRing(0.15, 0.64, 0.04);
            addBaseRing(1.32, 0.33, 0.035);
            const headSphere = new THREE.Mesh(new THREE.SphereGeometry(0.34, 24, 24), gemMat);
            headSphere.position.y = 1.66;
            bodyGroup.add(headSphere);
        }

        // Ground Aura Ring
        const auraRing = new THREE.Mesh(
            new THREE.RingGeometry(0.82, 1.18, 36),
            new THREE.MeshBasicMaterial({
                color: auraCol,
                transparent: true,
                opacity: 0.55,
                blending: THREE.AdditiveBlending,
                depthWrite: false,
                side: THREE.DoubleSide
            })
        );
        auraRing.rotation.x = -Math.PI / 2;
        auraRing.position.y = 0.03;
        root.add(auraRing);

        let orbitRing = null;
        let orbitRing2 = null;
        let sparklesGroup = null;

        if (effect === 'orbit_ring' || effect === 'sparkle_crown' || effect === 'holo_float') {
            orbitRing = new THREE.Mesh(
                new THREE.TorusGeometry(0.95, 0.032, 10, 40),
                new THREE.MeshBasicMaterial({
                    color: auraCol,
                    transparent: true,
                    opacity: 0.85,
                    blending: THREE.AdditiveBlending
                })
            );
            orbitRing.position.y = 1.05;
            orbitRing.rotation.x = Math.PI / 2.6;
            root.add(orbitRing);
        }

        if (effect === 'holo_float') {
            orbitRing2 = new THREE.Mesh(
                new THREE.TorusGeometry(1.12, 0.024, 10, 40),
                new THREE.MeshBasicMaterial({
                    color: accentCol,
                    transparent: true,
                    opacity: 0.65,
                    blending: THREE.AdditiveBlending
                })
            );
            orbitRing2.position.y = 1.15;
            orbitRing2.rotation.x = -Math.PI / 3.0;
            root.add(orbitRing2);
        }

        if (effect === 'sparkle_crown' || effect === 'holo_float') {
            sparklesGroup = new THREE.Group();
            sparklesGroup.position.y = 1.4;
            for (let i = 0; i < 6; i++) {
                const ang = (i / 6) * Math.PI * 2;
                const sp = new THREE.Mesh(
                    new THREE.OctahedronGeometry(0.075),
                    new THREE.MeshBasicMaterial({ color: (i % 2 === 0) ? auraCol : accentCol })
                );
                sp.position.set(Math.cos(ang) * 0.88, (i % 2 === 0 ? 0.25 : -0.25), Math.sin(ang) * 0.88);
                sparklesGroup.add(sp);
            }
            root.add(sparklesGroup);
        }

        root.scale.setScalar(scale);
        root.userData = {
            isChessPawn3D: true,
            bodyGroup,
            bodyMat,
            gemMat,
            auraRing,
            orbitRing,
            orbitRing2,
            sparklesGroup,
            effect,
            glowIntensity,
            baseScale: scale
        };

        return root;
    }

    function animateGroup(root, timeSec) {
        if (!root || !root.userData || !root.userData.isChessPawn3D) return;
        const ud = root.userData;
        const eff = ud.effect || 'pulse_aura';

        if (ud.auraRing) {
            const pulse = 0.88 + Math.sin(timeSec * 3.2) * 0.14;
            ud.auraRing.scale.set(pulse, pulse, 1);
            ud.auraRing.material.opacity = 0.42 + Math.sin(timeSec * 3.2) * 0.22;
        }
        if (ud.orbitRing) {
            ud.orbitRing.rotation.z = timeSec * 1.8;
            ud.orbitRing.rotation.y = Math.sin(timeSec * 0.9) * 0.35;
        }
        if (ud.orbitRing2) {
            ud.orbitRing2.rotation.z = -timeSec * 1.4;
            ud.orbitRing2.rotation.y = Math.cos(timeSec * 1.1) * 0.4;
        }
        if (ud.sparklesGroup) {
            ud.sparklesGroup.rotation.y = timeSec * 1.6;
            ud.sparklesGroup.position.y = 1.4 + Math.sin(timeSec * 2.5) * 0.15;
        }
        if (eff === 'holo_float' && ud.bodyGroup) {
            ud.bodyGroup.position.y = 0.16 + Math.sin(timeSec * 2.8) * 0.12;
            ud.bodyGroup.rotation.y = timeSec * 0.75;
        } else if (ud.bodyGroup) {
            ud.bodyGroup.position.y = 0;
        }
    }

    function generateAiPresets() {
        const palettes = [
            { title: '👑 Royal Gold Sovereign', piece: 'king', primary_color: '#eab308', accent_color: '#ffffff', aura_color: '#fbbf24', glow_intensity: 1.35, effect: 'holo_float', scale: 1.2 },
            { title: '⚡ Cyber Neon Valkyrie', piece: 'queen', primary_color: '#06b6d4', accent_color: '#f472b6', aura_color: '#22d3ee', glow_intensity: 1.2, effect: 'orbit_ring', scale: 1.15 },
            { title: '🔥 Inferno Dragon Rook', piece: 'rook', primary_color: '#dc2626', accent_color: '#fde047', aura_color: '#f97316', glow_intensity: 1.15, effect: 'sparkle_crown', scale: 1.1 },
            { title: '💎 Astral Crystal Totem', piece: 'crystal', primary_color: '#8b5cf6', accent_color: '#e0f2fe', aura_color: '#c084fc', glow_intensity: 1.25, effect: 'holo_float', scale: 1.15 },
            { title: '🐴 Emerald Cyber Knight', piece: 'knight', primary_color: '#10b981', accent_color: '#fef08a', aura_color: '#34d399', glow_intensity: 0.95, effect: 'orbit_ring', scale: 1.05 },
            { title: '🔮 Mystic Void Bishop', piece: 'bishop', primary_color: '#6366f1', accent_color: '#f43f5e', aura_color: '#a78bfa', glow_intensity: 1.05, effect: 'sparkle_crown', scale: 1.08 },
            { title: '❄️ Frost Diamond Pawn', piece: 'pawn', primary_color: '#38bdf8', accent_color: '#ffffff', aura_color: '#7dd3fc', glow_intensity: 0.85, effect: 'pulse_aura', scale: 1.0 },
            { title: '🌸 Sakura Empress Queen', piece: 'queen', primary_color: '#ec4899', accent_color: '#fde047', aura_color: '#f9a8d4', glow_intensity: 1.1, effect: 'sparkle_crown', scale: 1.12 }
        ];
        // Shuffle slightly so clicking AI Generate feels dynamic
        return palettes.sort(() => Math.random() - 0.5);
    }

    function generateAiFullGradeSet() {
        const themes = [
            {
                name: 'Royal Cyber Pantheon',
                'DEFAULT': { piece: 'pawn', primary_color: '#38bdf8', accent_color: '#e2e8f0', aura_color: '#0ea5e9', glow_intensity: 0.70, effect: 'pulse_aura', scale: 0.95 },
                'A':   { piece: 'pawn', primary_color: '#60a5fa', accent_color: '#f8fafc', aura_color: '#38bdf8', glow_intensity: 0.75, effect: 'pulse_aura', scale: 0.95 },
                'A+':  { piece: 'knight', primary_color: '#10b981', accent_color: '#fde047', aura_color: '#34d399', glow_intensity: 0.85, effect: 'pulse_aura', scale: 1.00 },
                'S':   { piece: 'bishop', primary_color: '#8b5cf6', accent_color: '#facc15', aura_color: '#c084fc', glow_intensity: 0.95, effect: 'orbit_ring', scale: 1.05 },
                'S+':  { piece: 'rook', primary_color: '#f97316', accent_color: '#fef08a', aura_color: '#fb923c', glow_intensity: 1.05, effect: 'orbit_ring', scale: 1.10 },
                'SS+': { piece: 'queen', primary_color: '#ec4899', accent_color: '#ffd700', aura_color: '#f472b6', glow_intensity: 1.20, effect: 'sparkle_crown', scale: 1.15 },
                'Z+':  { piece: 'king', primary_color: '#ef4444', accent_color: '#ffd700', aura_color: '#fbbf24', glow_intensity: 1.40, effect: 'holo_float', scale: 1.22 }
            },
            {
                name: 'Crystal Aurora Legends',
                'DEFAULT': { piece: 'pawn', primary_color: '#22d3ee', accent_color: '#ffffff', aura_color: '#67e8f9', glow_intensity: 0.75, effect: 'pulse_aura', scale: 0.95 },
                'A':   { piece: 'pawn', primary_color: '#38bdf8', accent_color: '#cbd5e1', aura_color: '#0ea5e9', glow_intensity: 0.80, effect: 'pulse_aura', scale: 0.98 },
                'A+':  { piece: 'rook', primary_color: '#06b6d4', accent_color: '#fde047', aura_color: '#22d3ee', glow_intensity: 0.90, effect: 'orbit_ring', scale: 1.02 },
                'S':   { piece: 'knight', primary_color: '#3b82f6', accent_color: '#a5f3fc', aura_color: '#60a5fa', glow_intensity: 1.00, effect: 'orbit_ring', scale: 1.06 },
                'S+':  { piece: 'crystal', primary_color: '#a855f7', accent_color: '#f0abfc', aura_color: '#d8b4fe', glow_intensity: 1.15, effect: 'sparkle_crown', scale: 1.12 },
                'SS+': { piece: 'queen', primary_color: '#f43f5e', accent_color: '#ffd700', aura_color: '#fb7185', glow_intensity: 1.25, effect: 'holo_float', scale: 1.16 },
                'Z+':  { piece: 'king', primary_color: '#eab308', accent_color: '#ffffff', aura_color: '#fde047', glow_intensity: 1.45, effect: 'holo_float', scale: 1.24 }
            }
        ];
        return themes[Math.floor(Math.random() * themes.length)];
    }

    window.ChessPawn3D = {
        DEFAULT_CONFIG: DEFAULT_PAWN_ICON_CONFIG,
        PIECE_META,
        EFFECT_META,
        normalizeGradeKey,
        mergeConfig,
        resolveForPlayer,
        buildPieceGroup,
        animateGroup,
        generateAiPresets,
        generateAiFullGradeSet
    };
})(window);

