// =========================================================================
// 🌟 SEPARATED EVENT GACHA CONTROLLERS (แยกอีเวนต์กรอบรูป & อีเวนต์ลูกเต๋า 3D คนละหน้าคนละเมนู + Popup สุ่มเปิดซองแบบในคลิป)
// =========================================================================
window.parseThaiDate = function (dateStr) {
    if (!dateStr) return null;
    let s = String(dateStr).trim();
    const mdyMatch = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(AM|PM))?)?$/i);
    if (mdyMatch) {
        let [_, m, d, y, h, min, sec, ampm] = mdyMatch;
        let hour = h ? parseInt(h, 10) : 0;
        if (ampm) {
            ampm = ampm.toUpperCase();
            if (ampm === 'PM' && hour < 12) hour += 12;
            if (ampm === 'AM' && hour === 12) hour = 0;
        }
        return new Date(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10), hour, min ? parseInt(min, 10) : 0, sec ? parseInt(sec, 10) : 0);
    }
    let iso = s.replace(' ', 'T');
    if (!iso.includes('+') && !iso.includes('Z')) {
        if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(iso)) {
            iso += ':00+07:00';
        } else if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(iso)) {
            iso += '+07:00';
        } else {
            iso = iso.replace(/-/g, '/');
        }
    }
    const d = new Date(iso);
    return isNaN(d.getTime()) ? null : d;
};

if (!window.isThaiDateExpired) {
    window.isThaiDateExpired = function (dateStr) {
        if (!dateStr) return false;
        const d = window.parseThaiDate(dateStr);
        return d ? (Date.now() > d.getTime()) : false;
    };
}

if (!window.formatEventDateRangeShort) {
    window.formatEventDateRangeShort = function (startStr, endStr) {
        if (!endStr) return '';
        try {
            const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
            const sD = window.parseThaiDate(startStr);
            const eD = window.parseThaiDate(endStr);
            if (!eD) return '';

            const getParts = (d) => {
                const parts = new Intl.DateTimeFormat('en-US', {
                    timeZone: 'Asia/Bangkok',
                    month: 'numeric',
                    day: 'numeric'
                }).formatToParts(d);
                let day = '', m = 1;
                for (const p of parts) {
                    if (p.type === 'day') day = p.value;
                    if (p.type === 'month') m = parseInt(p.value, 10);
                }
                return { day, month: m, monthName: thaiMonths[m - 1] };
            };

            const eP = getParts(eD);
            if (sD) {
                const sP = getParts(sD);
                if (sP.monthName === eP.monthName) {
                    return `${sP.day} - ${eP.day} ${eP.monthName}`;
                }
                return `${sP.day} ${sP.monthName} - ${eP.day} ${eP.monthName}`;
            }
            return `ถึง ${eP.day} ${eP.monthName}`;
        } catch (_) {
            return '';
        }
    };
}

window.formatEventDateLong = function (dateStr) {
    if (!dateStr || dateStr === '-') dateStr = '2026-11-16 14:50:00';
    try {
        const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        const d = (typeof window.parseThaiDate === 'function' ? window.parseThaiDate(dateStr) : null) || new Date(String(dateStr).replace('T', ' ').replace(/-/g, '/'));
        if (!d || isNaN(d.getTime())) return String(dateStr);
        const day = d.getDate();
        const mon = thaiMonths[d.getMonth()];
        const year = d.getFullYear() + 543;
        const hr = String(d.getHours()).padStart(2, '0');
        const min = String(d.getMinutes()).padStart(2, '0');
        return `${day} ${mon} ${year} เวลา ${hr}:${min} น.`;
    } catch (_) {
        return String(dateStr);
    }
};
let currentEventGachaData = null;
let eventGachaTimerInterval = null;
let lastGachaPullMeta = {
    source: 'EVENT',
    category: 'FRAME',
    count: 5,
    currency: 'DIAMOND',
    packTier: 'SPECIAL',
    displayCost: '💎 225'
};
let pendingGachaRevealDrops = [];
let pendingGachaRevealCategory = 'FRAME';
let gachaPackAutoTearTimeout = null;
let gachaCardRevealTimers = [];
let isAllRevealedCardsFlipped = false;

function clearGachaCardRevealTimers() {
    if (Array.isArray(gachaCardRevealTimers) && gachaCardRevealTimers.length > 0) {
        gachaCardRevealTimers.forEach(t => clearTimeout(t));
        gachaCardRevealTimers = [];
    }
}

function triggerSingleCardRevealSound(isRare = false) {
    try {
        if (window.soundEngine && typeof window.soundEngine.duckAllBgm === 'function') {
            window.soundEngine.duckAllBgm(1400);
        }
        const evKey = isRare ? 'card_reveal_rare' : 'card_reveal';
        if (window.ThaiAudio && typeof window.ThaiAudio.playCardReveal === 'function') {
            window.ThaiAudio.playCardReveal(isRare);
        } else if (window.ThaiAudio && typeof window.ThaiAudio.play === 'function' && typeof window.ThaiAudio.isEventPlayable === 'function' && window.ThaiAudio.isEventPlayable(evKey)) {
            window.ThaiAudio.play(evKey);
        } else if (window.soundEngine && typeof window.soundEngine.playCardRevealZap === 'function') {
            window.soundEngine.playCardRevealZap('zap_classic', isRare, 0.95);
        }
    } catch (e) { }
}

window.openFrameEventModal = async function () {
    closeModal('modal-event-dice');
    openModal('modal-event-frame');
    await loadEventGachaData('FRAME');
};

window.openDiceEventModal = async function () {
    closeModal('modal-event-frame');
    openModal('modal-event-dice');
    await loadEventGachaData('DICE');
};

// Backward-compatible alias if any news card or button calls openEventGachaModal
window.openEventGachaModal = async function (preferredType = 'FRAME') {
    if (String(preferredType).toUpperCase() === 'DICE') {
        return window.openDiceEventModal();
    }
    return window.openFrameEventModal();
};

function getDefaultFallbackEventData() {
    return {
        is_live_now: true,
        is_active: 1,
        is_expired: false,
        dice_is_expired: false,
        start_date: '2026-11-16 14:50:00',
        end_date: '2026-11-25 23:59:59',
        dice_start_date: '2026-11-16 14:50:00',
        dice_end_date: '2026-11-25 23:59:59',
        name: 'เทศกาลอีเวนต์พิเศษ',
        cost_diamond: 50,
        remaining_seconds: 86400 * 14,
        user_materials: {},
        reqs: { black: 25, red: 25, orange: 20, blue: 15, gold: 8 },
        dice_reqs: { black: 15, red: 15, orange: 15, blue: 10, gold: 4 },
        target_character: {
            id: 1,
            name: 'ดาราจักรเนบิวลา SS+',
            grade: 'SS+',
            avatar_url: 'avatars/avatar_01.png',
            skill_name: 'ความแม่นยำคุมลูกเต๋าสูงสุด + ส่วนลดค่าผ่านทาง & ป้องกันการถูกซื้อต่อ'
        },
        target_dice: {
            id: 1,
            name: 'ลูกเต๋านีออนมังกรทอง 3D',
            grade: 'SS+',
            dice_control: 85,
            skill_desc: 'ควบคุมแต้มลูกเต๋า +85% • โบนัสทอง & เอฟเฟกต์แสงมังกรทอง 3D'
        }
    };
}

window.loadEventGachaData = async function () {
    let evData = currentEventGachaData || getDefaultFallbackEventData();
    // 🌟 Render immediately with cached/fallback data so dice/frame event pages are NEVER blank!
    try {
        renderSeparatedEventGachaUIs(evData);
    } catch (e) {
        console.warn('Initial render fallback:', e);
    }

    try {
        if (window.apiClient && typeof apiClient.getActiveEventGacha === 'function') {
            const res = await apiClient.getActiveEventGacha();
            if (res && res.status === 'success' && res.data) {
                evData = res.data;
                currentEventGachaData = evData;
                renderSeparatedEventGachaUIs(evData);
            }
        }
    } catch (e) {
        console.warn('Event gacha fetch fallback:', e);
    }
};

function updateSeparatedEventWalletsAndTimers(ev) {
    const userDia = Number((typeof DEFAULT_USER !== 'undefined' ? (DEFAULT_USER.diamond ?? DEFAULT_USER.diamonds) : 0) || 0);
    const userGold = Number((typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER.gold : 0) || 0);

    ['frame-event-user-dia', 'dice-event-user-dia', 'gem-event-user-dia'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerText = userDia.toLocaleString();
    });
    ['frame-event-user-gold', 'dice-event-user-gold', 'gem-event-user-gold'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerText = userGold.toLocaleString();
    });

    if (eventGachaTimerInterval) clearInterval(eventGachaTimerInterval);
    let rem = Number(ev.remaining_seconds || 0);
    const renderTick = () => {
        const txt = rem <= 0
            ? 'เปิดตลอดเวลา'
            : (() => {
                const days = Math.floor(rem / 86400);
                const hrs = Math.floor((rem % 86400) / 3600);
                const mins = Math.floor((rem % 3600) / 60);
                const secs = rem % 60;
                return `${days > 0 ? days + ' วัน ' : ''}${hrs} ชม. ${mins} นาที ${secs} วิ`;
            })();
        const fTimer = document.getElementById('frame-event-countdown');
        const dTimer = document.getElementById('dice-event-countdown');
        if (fTimer) fTimer.innerText = txt;
        if (dTimer) dTimer.innerText = txt;
    };
    renderTick();
    if (rem > 0) {
        eventGachaTimerInterval = setInterval(() => {
            rem = Math.max(0, rem - 1);
            renderTick();
            if (rem <= 0) clearInterval(eventGachaTimerInterval);
        }, 1000);
    }
}

function buildShadowMatsArray(uMats, reqMap, defaultReqs) {
    const specs = [
        { code: 'SHADOW_BLACK_A', name: 'เงาดำ A', grade: 'A', slot: 1, icon: '⬛', color: '#94a3b8', reqKey: 'black', defReq: defaultReqs.black, rate: 90 },
        { code: 'SHADOW_RED_A', name: 'เงาแดง A', grade: 'A', slot: 2, icon: '🟥', color: '#ef4444', reqKey: 'red', defReq: defaultReqs.red, rate: 80 },
        { code: 'SHADOW_ORANGE_A', name: 'เงาส้ม A', grade: 'A', slot: 3, icon: '🟧', color: '#f97316', reqKey: 'orange', defReq: defaultReqs.orange, rate: 70 },
        { code: 'SHADOW_BLUE_APLUS', name: 'เงาฟ้า A+', grade: 'A+', slot: 4, icon: '🟦', color: '#38bdf8', reqKey: 'blue', defReq: defaultReqs.blue, altCode: 'SHADOW_BLUE_A', rate: 50 },
        { code: 'SHADOW_GOLD_S', name: 'เงาทอง S', grade: 'S', slot: 5, icon: '🟨', color: '#ffd700', reqKey: 'gold', defReq: defaultReqs.gold, altCode: 'SHADOW_GOLD_APLUS', rate: 10 }
    ];
    return specs.map(s => {
        const owned = Number(uMats[s.code] || 0) + (s.altCode ? Number(uMats[s.altCode] || 0) : 0);
        const req = parseInt(reqMap[s.reqKey] ?? s.defReq, 10) || s.defReq;
        return { ...s, owned, req, isReady: owned >= req };
    });
}

function renderSeparatedEventGachaUIs(ev) {
    updateSeparatedEventWalletsAndTimers(ev);

    const uMats = ev.user_materials || {};
    const reqs = ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {};
    const diceReqs = ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {};

    const costSingle = Math.max(10, parseInt(ev.cost_diamond || 50, 10));
    const costEvent5 = Math.round(costSingle * 5 * 0.9);
    const costPremium5 = Math.round(costSingle * 5 * 1.45);
    const costPremium10 = Math.round(costSingle * 10 * 1.35);

    // ---------------------------------------------------------
    // 1. Render FRAME EVENT PAGE (#frame-event-body)
    // ---------------------------------------------------------
    const frameBody = document.getElementById('frame-event-body');
    if (frameBody) {
        const frameMats = buildShadowMatsArray(uMats, reqs, { black: 25, red: 25, orange: 20, blue: 15, gold: 8 });
        const isFrameExpired = Boolean(ev.is_expired || (ev.end_date && window.isThaiDateExpired(ev.end_date)));
        const frameDateBadgeText = window.formatEventDateRangeShort ? window.formatEventDateRangeShort(ev?.start_date, ev?.end_date) : '';
        const canExchangeFrame = frameMats.every(m => m.isReady) && !isFrameExpired;
        const missingFrameCount = frameMats.filter(m => !m.isReady).length;
        const char = ev.target_character || { id: 1, name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+' };
        const charGrade = String(char.grade || 'SS+').toUpperCase();
        const myAvatar = (typeof window.getActivePlayerAvatarUrl === 'function')
            ? window.getActivePlayerAvatarUrl()
            : (char.avatar_url || 'avatars/google_avatar.png');
        const auraClass = (typeof window.getFrameAuraClass === 'function') ? window.getFrameAuraClass(charGrade, char.aura_type) : '';
        const intVal = char.aura_intensity !== undefined ? parseInt(char.aura_intensity, 10) : 100;
        const overdriveCss = (typeof window.buildAuraOverdriveStyle === 'function') ? window.buildAuraOverdriveStyle(charGrade, char.aura_type, intVal) : '';
        const customLayersHtml = (typeof window.buildCustomFrameLayersHtml === 'function') ? window.buildCustomFrameLayersHtml(char) : '';
        window._latestFrameEventChar = char;
        const hasFrameInInventory = Boolean(ev.user_has_target_character);

        frameBody.innerHTML = `
            <!-- Left Showcase & Horizontal Shadow Exchange -->
            <div class="event-hero-panel">
                <div>
                    <div class="event-hero-poster">
                        <div class="frame-circle-wrap ${auraClass}" onclick="if(typeof window.openEventTargetLargePreviewModal==='function') window.openEventTargetLargePreviewModal('FRAME', window._latestFrameEventChar)" title="🔍 คลิกดูรูปใหญ่พร้อมรูปไอดีของคุณ" style="position:relative; width:64px; height:64px; margin:8px; border-radius:14px; overflow:visible !important; cursor:pointer; flex-shrink:0; ${overdriveCss}">
                            <img src="${myAvatar}" alt="${char.name || 'Frame'}" class="frame-avatar-img" style="width:100%; height:100%; object-fit:cover; border-radius:12px;" onerror="this.src='avatars/google_avatar.png';">
                            ${customLayersHtml}
                            <span style="position:absolute; bottom:2px; right:2px; background:linear-gradient(135deg,#ffd700,#f59e0b); color:#000; font-size:8px; font-weight:900; padding:1px 4px; border-radius:3px; border:1px solid #fff; z-index:6;">${charGrade}</span>
                            <span style="position:absolute; top:2px; left:2px; background:rgba(0,0,0,0.65); color:#fff; font-size:8.5px; padding:1px 3px; border-radius:4px; z-index:6;">🔍</span>
                        </div>
                        <div style="min-width:0; flex:1;">
                            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                <span style="background:linear-gradient(135deg,#ffd700,#f59e0b); color:#000; font-size:10px; font-weight:900; padding:2px 7px; border-radius:5px;">${char.grade || 'SS+'}</span>
                                <span style="font-size:10px; color:#fde047; font-weight:800;">รางวัลใหญ่ประจำอีเวนต์กรอบรูป</span>
                                ${hasFrameInInventory ? `<span style="background:linear-gradient(135deg,#10b981,#059669); color:#fff; font-size:9.5px; font-weight:900; padding:2px 7px; border-radius:5px; box-shadow:0 0 8px rgba(16,185,129,0.6); display:inline-flex; align-items:center; gap:3px;">🎉 มีในคลังแล้ว</span>` : ''}
                            </div>
                            <div style="font-size:clamp(15px,1.9vw,20px); font-weight:900; color:#fff; margin-top:3px; text-shadow:0 2px 8px rgba(0,0,0,0.8); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${char.name || 'ดาราจักรเนบิวลา SS+'}</div>
                            <div style="font-size:11px; color:#bae6fd; margin-top:3px; line-height:1.35; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">⚡ ${char.skill_name || 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง'}</div>
                        </div>
                    </div>

                    <!-- Horizontal Shadow Progress Strip -->
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; flex-wrap:wrap; gap:4px;">
                        <span style="font-size:11px; font-weight:800; color:#fde68a;">✨ สะสมการ์ดเงาแลกกรอบรูป (แนวนอน):</span>
                        ${isFrameExpired
                            ? `<span style="background:rgba(239,68,68,0.25); border:1px solid rgba(239,68,68,0.6); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">🛑 กิจกรรมหมดเวลา (ไม่สามารถแลกได้)</span>`
                            : (canExchangeFrame
                                ? `<button type="button" class="btn-lgr-exchange-sparkle frame-sparkle" onclick="checkAndShowShadowCompleteModal('FRAME')" title="เงาครบแล้ว! กดแลกรับกรอบรูปทันที">
                                       <span class="btn-sparkle-star">✨</span>
                                       <span class="btn-text">ครบพร้อมแลก! (กดแลกทันที)</span>
                                       <span class="btn-sparkle-tag">FREE</span>
                                   </button>`
                                : `<span style="background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">ขาดอีก ${missingFrameCount} ชนิด</span>`
                            )
                        }
                    </div>
                    <div class="shadow-5card-grid">
                        ${frameMats.map((m, idx) => {
                            const isReady = m.isReady;
                            const isLastSlot = (idx === 4 || m.grade === 'S' || m.grade === 'SS+');
                            const gradeHtml = (typeof window.gradeEmblemHtml === 'function')
                                ? window.gradeEmblemHtml(m.grade || 'A', m.color, m.grade === 'A+' ? 18 : (m.grade === 'A' ? 20 : 18))
                                : `<span style="font-size:18px; font-weight:900; color:${m.color};">${m.grade || 'A'}</span>`;

                            return `
                                <div class="shadow-card-admin-item"
                                     onclick="window.showShadowMaterialInspectModal('${m.code}', 'FRAME')"
                                     title="คลิกดูรายละเอียด: ${m.name} (${m.grade || 'A'}) สะสม ${m.owned}/${m.req}${ev?.end_date ? ` • หมดอายุ ${ev.end_date}` : ''}"
                                     style="${isLastSlot ? 'border-color:#ffd700; box-shadow:0 0 12px rgba(255,215,0,0.5);' : `border-color:${m.color}66;`}">
                                    
                                    <!-- Live Preview Box พร้อมเกรดตรงกลาง สวยเด่น พอดีกับข้างใน -->
                                    <div class="shadow-card-admin-thumb"
                                         style="border:1.5px solid ${m.color}; background:radial-gradient(circle at 50% 50%, ${m.color}44 0%, #050811 85%); box-shadow:0 0 10px ${m.color}55;">
                                        
                                        <!-- Background Frame Emblem Silhouette -->
                                        <div style="position:absolute; width:100%; height:100%; display:flex; align-items:center; justify-content:center; pointer-events:none; opacity:0.35; z-index:1; font-size:20px;">
                                            👑
                                        </div>

                                        <!-- Center Grade Emblem -->
                                        ${gradeHtml}

                                        <!-- Corner Badge -->
                                        <span style="position:absolute; bottom:2px; right:2px; background:${m.color}; color:#000; font-size:7.5px; font-weight:900; padding:0.5px 3.5px; border-radius:3px; border:1px solid #fff; z-index:6; line-height:1.1;">
                                            ${m.grade || 'A'}
                                        </span>

                                        ${isLastSlot ? `<div style="position:absolute; top:2px; right:2px; font-size:10px; filter:drop-shadow(0 0 3px #ffd700); z-index:6;">👑</div>` : ''}
                                    </div>

                                    <!-- Shadow Name -->
                                    <div class="shadow-card-admin-name" style="color:${m.color};">
                                        ${m.name}
                                    </div>

                                    <!-- Event Date Range / Expiration Badge -->
                                    <div class="shadow-card-date-badge ${isFrameExpired ? 'is-expired' : ''}">
                                        ${isFrameExpired ? '🛑 หมดอายุ' : (frameDateBadgeText ? `📅 ${frameDateBadgeText}` : '📅 ประจำอีเวนต์')}
                                    </div>

                                    <!-- Owned / Req Badge (แสดงจำนวน เช่น 50/15 คมชัด สวยงาม) -->
                                    <div class="shadow-card-admin-qty ${isReady ? 'is-ready' : 'is-missing'}">
                                        ${isReady ? '<span style="font-size:9px;">✓</span>' : ''}<span>${m.owned}/${m.req}</span>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    ${typeof window.buildEventSpecialAwakeningBannerHtml === 'function' ? window.buildEventSpecialAwakeningBannerHtml('card', Number(uMats['SPECIAL_CARD'] ?? window.latestMaterialsMap?.['SPECIAL_CARD'] ?? 0)) : ''}
                </div>

                <!-- Exchange Target Frame Card -->
                <div class="event-target-card frame-card ${canExchangeFrame ? 'ready-to-exchange' : 'not-ready'}" style="margin-top:6px; padding:10px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
                        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                            <div style="width:36px; height:36px; border-radius:10px; background:rgba(255,215,0,0.18); border:2px solid #ffd700; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">👑</div>
                            <div style="min-width:0;">
                                <div style="font-size:12px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">👑 ${char.name || 'กรอบรูปตัวละคร SS+'}</div>
                                <div style="font-size:10px; color:#cbd5e1;">${isFrameExpired ? '🛑 กิจกรรมสิ้นสุดแล้ว ไม่สามารถแลกรับได้อีก' : (canExchangeFrame ? 'สะสมเงาครบแล้ว กดแลกรับกรอบรูปได้ทันที!' : (hasFrameInInventory ? '🎉 คุณมีกรอบรูปนี้ในคลังแล้ว (สามารถสะสมแลกเพิ่มได้)' : 'สะสมเงาให้ครบทั้ง 5 สีเพื่อปลดล็อกปุ่มแลก'))}</div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn-lgr-exchange-hero ${canExchangeFrame ? 'is-ready frame-ready' : 'is-disabled'}"
                        onclick="${canExchangeFrame ? `checkAndShowShadowCompleteModal('FRAME')` : ''}"
                        ${canExchangeFrame ? '' : 'disabled'}>
                        <span class="hero-shine-sweep"></span>
                        <span class="hero-btn-content">
                            ${isFrameExpired ? '🛑 กิจกรรมหมดเวลา (ไม่สามารถแลกได้)' : (canExchangeFrame ? '✨ 👑 กดแลกรับกรอบรูป SS+ ทันที! ⚡ ✨' : `🔒 เงายังไม่ครบ (ขาดอีก ${missingFrameCount} ชนิด)`)}
                        </span>
                    </button>
                </div>
            </div>

            <!-- Right 6 Frame Gacha Pack Cards Grid -->
            <div class="event-packs-grid">
                <div class="gacha-pack-shop-card is-special" onclick="rollSeparatedEventGacha('FRAME', 1, 'DIAMOND', 'SPECIAL', '💎 ${costSingle}')">
                    <div class="pack-card-header-bar">แพ็คการ์ดกรอบพิเศษ (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil frame-foil"><span class="mini-foil-icon">👑</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มชิ้นส่วนเงากรอบรูป<br>& ลุ้นกรอบรูป SS+ (+1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costSingle.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('FRAME', 1, 'GOLD', 'NORMAL', '💰 30,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มการ์ดทั่วไป (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🃏</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงากรอบรูป<br>ระดับ A ~ A+ (1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">💰 30,000</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('FRAME', 5, 'GOLD', 'NORMAL', '💰 120,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มการ์ดทั่วไป (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🃏</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงากรอบรูป<br>แบบแพ็คสุดคุ้ม 5 ชิ้น!</div>
                    </div>
                    <div class="pack-card-price-btn">💰 120,000</div>
                </div>

                <div class="gacha-pack-shop-card is-event-hot" onclick="rollSeparatedEventGacha('FRAME', 5, 'DIAMOND', 'SPECIAL', '💎 ${costEvent5}')">
                    <span class="pack-card-event-flag">EVENT</span>
                    <div class="pack-card-header-bar">แพ็คการ์ดกรอบพิเศษ (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil frame-foil"><span class="mini-foil-icon">👑</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">แพ็คการ์ดยอดนิยม!<br>เปิดสุ่มกรอบรูป 5 ชิ้น (ลด 10%)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costEvent5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('FRAME', 5, 'DIAMOND', 'PREMIUM', '💎 ${costPremium5}')">
                    <div class="pack-card-header-bar">ชุดกรอบพรีเมียม (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil frame-foil"><span class="mini-foil-icon">💎</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">เรตอัปเงาการ์ด A+ / S<br>& ลุ้นกรอบรูป SS+ แรร์ 5 ชิ้น</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('FRAME', 10, 'DIAMOND', 'PREMIUM', '💎 ${costPremium10}')">
                    <span class="pack-card-event-flag">HOT</span>
                    <div class="pack-card-header-bar">ชุดกรอบพรีเมียม (+10)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil frame-foil"><span class="mini-foil-icon">🔥</span><span class="mini-foil-qty">10</span></div>
                        <div class="pack-card-desc">แพ็คใหญ่จุใจ 10 ชิ้น<br>โอกาสออกกรอบรูปแรร์สูงสุด!</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium10.toLocaleString()}</div>
                </div>
            </div>
        `;
    }

    // ---------------------------------------------------------
    // 2. Render DICE EVENT PAGE (#dice-event-body)
    // ---------------------------------------------------------
    const diceBody = document.getElementById('dice-event-body');
    if (diceBody) {
        const diceMats = buildShadowMatsArray(uMats, diceReqs, { black: 15, red: 15, orange: 15, blue: 10, gold: 4 });
        const isDiceExpired = Boolean(ev.dice_is_expired || (ev.dice_end_date && window.isThaiDateExpired(ev.dice_end_date)));
        const diceStartDate = ev.dice_start_date || ev.start_date;
        const diceEndDate = ev.dice_end_date || ev.end_date;
        const diceDateBadgeText = window.formatEventDateRangeShort ? window.formatEventDateRangeShort(diceStartDate, diceEndDate) : '';
        const canExchangeDice = diceMats.every(m => m.isReady) && !isDiceExpired;
        const missingDiceCount = diceMats.filter(m => !m.isReady).length;
        const dice = ev.target_dice || { id: 1, name: 'ลูกเต๋านีออนมังกรทอง 3D', grade: 'SS+', dice_control: 85 };
        const diceColor = dice.color_hex || '#00e5ff';
        const diceAuraClass = (typeof window.getFrameAuraClass === 'function') ? window.getFrameAuraClass(dice.grade || 'SS+', dice.aura_type || 'cyan') : '';
        window._latestDiceEventTarget = dice;
        const hasDiceInInventory = Boolean(ev.user_has_target_dice);

        diceBody.innerHTML = `
            <!-- Left Showcase & Horizontal Shadow Exchange -->
            <div class="event-hero-panel">
                <div>
                    <div class="event-hero-poster">
                        <div class="event-hero-emblem ${diceAuraClass}" onclick="if(typeof window.openEventTargetLargePreviewModal==='function') window.openEventTargetLargePreviewModal('DICE', window._latestDiceEventTarget)" title="🔍 คลิกดูรูปใหญ่พร้อมเอฟเฟกต์" style="position:relative; width:60px; height:60px; border-radius:14px; border:2px solid ${diceColor}; background:radial-gradient(circle at 50% 50%, ${diceColor}44 0%, #050811 85%); box-shadow:0 0 18px ${diceColor}88; display:flex; align-items:center; justify-content:center; flex-shrink:0; cursor:pointer;">
                            ${dice.image_url ? `<img src="${dice.image_url}" alt="${dice.name}" style="width:46px; height:46px; object-fit:contain; filter:drop-shadow(0 0 8px ${diceColor});">` : '<span style="font-size:28px;">🎲</span>'}
                            <span style="position:absolute; bottom:2px; right:2px; background:linear-gradient(135deg,#00e5ff,#0284c7); color:#000; font-size:8px; font-weight:900; padding:1px 4px; border-radius:3px; border:1px solid #fff;">${dice.grade || 'SS+'}</span>
                            <span style="position:absolute; top:2px; left:2px; background:rgba(0,0,0,0.65); color:#fff; font-size:8.5px; padding:1px 3px; border-radius:4px;">🔍</span>
                        </div>
                        <div style="min-width:0; flex:1;">
                            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                <span style="background:linear-gradient(135deg,#00e5ff,#0284c7); color:#000; font-size:10px; font-weight:900; padding:2px 7px; border-radius:5px;">${dice.grade || 'SS+'}</span>
                                <span style="font-size:10px; color:#38bdf8; font-weight:800;">รางวัลใหญ่ประจำอีเวนต์ลูกเต๋า 3D</span>
                                ${hasDiceInInventory ? `<span style="background:linear-gradient(135deg,#10b981,#059669); color:#fff; font-size:9.5px; font-weight:900; padding:2px 7px; border-radius:5px; box-shadow:0 0 8px rgba(16,185,129,0.6); display:inline-flex; align-items:center; gap:3px;">🎉 มีในคลังแล้ว</span>` : ''}
                            </div>
                            <div style="font-size:clamp(15px,1.9vw,20px); font-weight:900; color:#fff; margin-top:3px; text-shadow:0 2px 8px rgba(0,0,0,0.8); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${dice.name || 'ลูกเต๋านีออนมังกรทอง 3D'}</div>
                            <div style="font-size:11px; color:#bae6fd; margin-top:3px; line-height:1.35; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">🎲 ควบคุมเต๋าแม่นยำ +${dice.dice_control || 85}% • เอฟเฟกต์ 3D สุดอลังการ</div>
                        </div>
                    </div>

                    <!-- Horizontal Shadow Progress Strip -->
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; flex-wrap:wrap; gap:4px;">
                        <span style="font-size:11px; font-weight:800; color:#7dd3fc;">✨ สะสมชิ้นส่วนเงาแลกลูกเต๋า (แนวนอน):</span>
                        ${isDiceExpired
                            ? `<span style="background:rgba(239,68,68,0.25); border:1px solid rgba(239,68,68,0.6); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">🛑 กิจกรรมหมดเวลา (ไม่สามารถแลกได้)</span>`
                            : (canExchangeDice
                                ? `<button type="button" class="btn-lgr-exchange-sparkle dice-sparkle" onclick="checkAndShowShadowCompleteModal('DICE')" title="เงาครบแล้ว! กดแลกรับลูกเต๋า 3D ทันที">
                                       <span class="btn-sparkle-star">✨</span>
                                       <span class="btn-text">ครบพร้อมแลก! (กดแลกทันที)</span>
                                       <span class="btn-sparkle-tag">FREE</span>
                                   </button>`
                                : `<span style="background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">ขาดอีก ${missingDiceCount} ชนิด</span>`
                            )
                        }
                    </div>
                    <div class="shadow-5card-grid">
                        ${diceMats.map((m, idx) => {
                            const isReady = m.isReady;
                            const isLastSlot = (idx === 4 || m.grade === 'S' || m.grade === 'SS+');
                            const gradeHtml = (typeof window.gradeEmblemHtml === 'function')
                                ? window.gradeEmblemHtml(m.grade || 'A', m.color, m.grade === 'A+' ? 18 : (m.grade === 'A' ? 20 : 18))
                                : `<span style="font-size:18px; font-weight:900; color:${m.color};">${m.grade || 'A'}</span>`;

                            return `
                                <div class="shadow-card-admin-item"
                                     onclick="window.showShadowMaterialInspectModal('${m.code}', 'DICE')"
                                     title="คลิกดูรายละเอียด: ${m.name} (${m.grade || 'A'}) สะสม ${m.owned}/${m.req}${diceEndDate ? ` • หมดอายุ ${diceEndDate}` : ''}"
                                     style="${isLastSlot ? 'border-color:#ffd700; box-shadow:0 0 12px rgba(255,215,0,0.5);' : `border-color:${m.color}66;`}">
                                    
                                    <!-- Live Preview Box พร้อมเกรดตรงกลาง เช่น A, A+ สวยเด่น พอดีกับข้างใน -->
                                    <div class="shadow-card-admin-thumb"
                                         style="border:1.5px solid ${m.color}; background:radial-gradient(circle at 50% 50%, ${m.color}44 0%, #050811 85%); box-shadow:0 0 10px ${m.color}55;">
                                        
                                        <!-- Background 3D Dice Silhouette (matches target dice image or 3D SVG) -->
                                        <div style="position:absolute; width:100%; height:100%; display:flex; align-items:center; justify-content:center; pointer-events:none; opacity:0.56; z-index:2;">
                                            ${(dice && dice.image_url)
                                                ? `<img src="${dice.image_url}" onerror="this.style.display='none';" style="width:36px; height:36px; object-fit:contain; mix-blend-mode:lighten; filter:contrast(1.1) drop-shadow(0 0 6px ${m.color});">`
                                                : `<svg viewBox="0 0 64 64" width="34" height="34" style="filter:drop-shadow(0 0 4px ${m.color});"><polygon points="32,6 56,19 32,32 8,19" fill="#e2e8f0" fill-opacity="0.88" stroke="${m.color}" stroke-width="1.5"/><polygon points="8,19 32,32 32,58 8,45" fill="#94a3b8" fill-opacity="0.85" stroke="${m.color}" stroke-width="1.5"/><polygon points="32,32 56,19 56,45 32,58" fill="#cbd5e1" fill-opacity="0.85" stroke="${m.color}" stroke-width="1.5"/><circle cx="32" cy="19" r="2.8" fill="#1e293b"/><circle cx="16" cy="31" r="2.5" fill="#1e293b"/><circle cx="24" cy="46" r="2.5" fill="#1e293b"/><circle cx="40" cy="34" r="2.5" fill="#1e293b"/><circle cx="48" cy="43" r="2.5" fill="#1e293b"/></svg>`
                                            }
                                        </div>

                                        <!-- Center Grade Emblem -->
                                        ${gradeHtml}

                                        <!-- Corner Badge -->
                                        <span style="position:absolute; bottom:2px; right:2px; background:${m.color}; color:#000; font-size:7.5px; font-weight:900; padding:0.5px 3.5px; border-radius:3px; border:1px solid #fff; z-index:6; line-height:1.1;">
                                            ${m.grade || 'A'}
                                        </span>

                                        ${isLastSlot ? `<div style="position:absolute; top:2px; right:2px; font-size:10px; filter:drop-shadow(0 0 3px #ffd700); z-index:6;">👑</div>` : ''}
                                    </div>

                                    <!-- Shadow Name -->
                                    <div class="shadow-card-admin-name" style="color:${m.color};">
                                        ${m.name}
                                    </div>

                                    <!-- Event Date Range / Expiration Badge -->
                                    <div class="shadow-card-date-badge ${isDiceExpired ? 'is-expired' : ''}">
                                        ${isDiceExpired ? '🛑 หมดอายุ' : (diceDateBadgeText ? `📅 ${diceDateBadgeText}` : '📅 ประจำอีเวนต์')}
                                    </div>

                                    <!-- Owned / Req Badge (แสดงจำนวน เช่น 50/15 คมชัด สวยงาม) -->
                                    <div class="shadow-card-admin-qty ${isReady ? 'is-ready' : 'is-missing'}">
                                        ${isReady ? '<span style="font-size:9px;">✓</span>' : ''}<span>${m.owned}/${m.req}</span>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    ${typeof window.buildEventSpecialAwakeningBannerHtml === 'function' ? window.buildEventSpecialAwakeningBannerHtml('dice', Number(uMats['SPECIAL_DICE_CARD'] ?? window.latestMaterialsMap?.['SPECIAL_DICE_CARD'] ?? 0)) : ''}
                </div>

                <!-- Exchange Target Dice Card -->
                <div class="event-target-card dice-card ${canExchangeDice ? 'ready-to-exchange' : 'not-ready'}" style="margin-top:6px; padding:10px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
                        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                            <div style="width:36px; height:36px; border-radius:10px; background:rgba(0,229,255,0.18); border:2px solid #00e5ff; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">🎲</div>
                            <div style="min-width:0;">
                                <div style="font-size:12px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">🎲 ${dice.name || 'ลูกเต๋า 3D แรร์'}</div>
                                <div style="font-size:10px; color:#cbd5e1;">${isDiceExpired ? '🛑 กิจกรรมสิ้นสุดแล้ว ไม่สามารถแลกรับได้อีก' : (canExchangeDice ? 'สะสมเงาครบแล้ว กดแลกรับลูกเต๋าได้ทันที!' : (hasDiceInInventory ? '🎉 คุณมีลูกเต๋านี้ในคลังแล้ว (สามารถสะสมแลกเพิ่มได้)' : 'สะสมเงาให้ครบทั้ง 5 สีเพื่อปลดล็อกปุ่มแลก'))}</div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn-lgr-exchange-hero ${canExchangeDice ? 'is-ready dice-ready' : 'is-disabled'}"
                        onclick="${canExchangeDice ? `checkAndShowShadowCompleteModal('DICE')` : ''}"
                        ${canExchangeDice ? '' : 'disabled'}>
                        <span class="hero-shine-sweep"></span>
                        <span class="hero-btn-content">
                            ${isDiceExpired ? '🛑 กิจกรรมหมดเวลา (ไม่สามารถแลกได้)' : (canExchangeDice ? '✨ 🎲 กดแลกรับลูกเต๋า 3D ทันที! ⚡ ✨' : `🔒 เงายังไม่ครบ (ขาดอีก ${missingDiceCount} ชนิด)`)}
                        </span>
                    </button>
                </div>
            </div>

            <!-- Right 6 Dice Gacha Pack Cards Grid -->
            <div class="event-packs-grid">
                <div class="gacha-pack-shop-card is-special" onclick="rollSeparatedEventGacha('DICE', 1, 'DIAMOND', 'SPECIAL', '💎 ${costSingle}')">
                    <div class="pack-card-header-bar">แพ็คลูกเต๋าพิเศษ (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มชิ้นส่วนเงาลูกเต๋า<br>& ลุ้นลูกเต๋า 3D (+1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costSingle.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('DICE', 1, 'GOLD', 'NORMAL', '💰 30,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มเต๋าทั่วไป (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงาลูกเต๋า<br>ระดับ A ~ A+ (1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">💰 30,000</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('DICE', 5, 'GOLD', 'NORMAL', '💰 120,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มเต๋าทั่วไป (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงาลูกเต๋า<br>แบบแพ็คสุดคุ้ม 5 ชิ้น!</div>
                    </div>
                    <div class="pack-card-price-btn">💰 120,000</div>
                </div>

                <div class="gacha-pack-shop-card is-event-hot" onclick="rollSeparatedEventGacha('DICE', 5, 'DIAMOND', 'SPECIAL', '💎 ${costEvent5}')">
                    <span class="pack-card-event-flag">EVENT</span>
                    <div class="pack-card-header-bar">แพ็คลูกเต๋าพิเศษ (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">แพ็คลูกเต๋ายอดนิยม!<br>เปิดสุ่มลูกเต๋า 5 ชิ้น (ลด 10%)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costEvent5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('DICE', 5, 'DIAMOND', 'PREMIUM', '💎 ${costPremium5}')">
                    <div class="pack-card-header-bar">ชุดเต๋าพรีเมียม (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">💎</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">เรตอัปเงาเต๋า A+ / S<br>& ลุ้นเต๋า 3D แรร์ 5 ชิ้น</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('DICE', 10, 'DIAMOND', 'PREMIUM', '💎 ${costPremium10}')">
                    <span class="pack-card-event-flag">HOT</span>
                    <div class="pack-card-header-bar">ชุดเต๋าพรีเมียม (+10)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🔥</span><span class="mini-foil-qty">10</span></div>
                        <div class="pack-card-desc">แพ็คใหญ่ลูกเต๋า 10 ชิ้น<br>โอกาสออกลูกเต๋าแรร์สูงสุด!</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium10.toLocaleString()}</div>
                </div>
            </div>
        `;
    }
}

window._gdrCurrentState = { category: 'FRAME', tier: 'SPECIAL' };

window.switchGachaRateTierTab = function (tierKey) {
    window.openGachaDropRateModal(window._gdrCurrentState.category || 'FRAME', tierKey || 'SPECIAL');
};

window.openGachaDropRateModal = function (category = 'FRAME', tierKey = 'SPECIAL') {
    const cat = String(category || 'FRAME').toUpperCase();
    const tier = String(tierKey || 'SPECIAL').toUpperCase();
    window._gdrCurrentState = { category: cat, tier };

    const titleEl = document.getElementById('gdr-modal-title');
    const subEl = document.getElementById('gdr-modal-subtitle');
    const tabsEl = document.getElementById('gdr-tier-tabs');
    const bodyEl = document.getElementById('gdr-table-body');
    const noteEl = document.getElementById('gdr-footer-note');
    if (!bodyEl) return;

    const gradeBadgeColor = (g) => {
        const up = String(g || 'A').toUpperCase();
        if (up.includes('ZZ')) return 'linear-gradient(135deg,#f43f5e,#a855f7)';
        if (up.includes('SS')) return 'linear-gradient(135deg,#ec4899,#f59e0b)';
        if (up === 'S+') return 'linear-gradient(135deg,#f59e0b,#ef4444)';
        if (up === 'S') return 'linear-gradient(135deg,#eab308,#ca8a04)';
        if (up === 'A+') return 'linear-gradient(135deg,#0ea5e9,#2563eb)';
        return 'rgba(100,116,139,0.7)';
    };

    let rows = [];
    let modalTitle = 'อัตราการดรอป';
    let footerNote = '';

    if (cat === 'GEM') {
        const data = window._gemGachaEventData || {};
        const ev = data.event || {};
        const targetItem = data.target_item || {};
        const gemName = targetItem.name || 'อัญมณีเป้าหมายประจำกิจกรรม';
        const gemGrade = targetItem.grade || 'SS+';
        modalTitle = '💎 โอกาสรับรางวัล • อัญมณีพิเศษ';

        const baseTargetRate = Math.max(0.01, parseFloat(ev.target_drop_rate || 1.0));
        const premMult = Math.max(0.1, parseFloat(ev.premium_rate_multiplier ?? 1.5));
        const goldMult = Math.max(0, parseFloat(ev.gold_rate_multiplier ?? 0.5));
        const effectiveTargetRate = tier === 'PREMIUM'
            ? baseTargetRate * premMult
            : (tier === 'NORMAL' ? baseTargetRate * goldMult : baseTargetRate);

        const afterTargetProb = Math.max(0, 1 - (effectiveTargetRate / 100));
        const gemSpecialPct = Math.max(0, Math.min(100, parseFloat(data.special_awakening_drop_pct ?? 5.0)));
        const specialRealPct = afterTargetProb * (gemSpecialPct / 100) * 100;
        const afterSpecialProb = afterTargetProb * Math.max(0, 1 - (gemSpecialPct / 100));

        const slotOrder = ['black', 'red', 'orange', 'blue', 'gold'];
        const defSlots = {
            black: { name: 'เงาดำ A', grade: 'A', icon: '🌑', color: '#64748b', rate: parseFloat(ev.shadow_rate_1 || 90) },
            red: { name: 'เงาแดง A', grade: 'A', icon: '🟥', color: '#ef4444', rate: parseFloat(ev.shadow_rate_2 || 80) },
            orange: { name: 'เงาส้ม A', grade: 'A', icon: '🟧', color: '#ff7b00', rate: parseFloat(ev.shadow_rate_3 || 70) },
            blue: { name: 'เงาฟ้า A+', grade: 'A+', icon: '🔵', color: '#38bdf8', rate: parseFloat(ev.shadow_rate_4 || 50) },
            gold: { name: 'เงาทอง S', grade: 'S', icon: '🟨', color: '#ffd700', rate: parseFloat(ev.shadow_rate_5 || 10) }
        };
        let rawCfg = ev.shadow_config_json;
        if (typeof rawCfg === 'string') {
            try { rawCfg = JSON.parse(rawCfg); } catch (e) { rawCfg = null; }
        }
        const premShadowScale = { black: 0.35, red: 0.45, orange: 0.70, blue: 1.85, gold: 2.50 };
        const shadows = slotOrder.map((k, idx) => {
            const c = Array.isArray(rawCfg) ? rawCfg[idx] : (rawCfg && typeof rawCfg === 'object' ? rawCfg[k] : null);
            const baseW = Math.max(0.1, parseFloat(c?.rate ?? defSlots[k].rate));
            const w = tier === 'PREMIUM' ? baseW * premShadowScale[k] : baseW;
            return {
                name: `${defSlots[k].icon} ${c?.name || defSlots[k].name}`,
                grade: c?.grade || defSlots[k].grade,
                color: c?.color || defSlots[k].color,
                weight: w
            };
        });
        const totalShadowW = shadows.reduce((s, x) => s + x.weight, 0) || 100;

        rows.push({ name: `🏆 ${gemName} (รางวัลใหญ่)`, grade: gemGrade, pct: effectiveTargetRate, color: '#ec4899', isJackpot: true });
        if (gemSpecialPct > 0) {
            rows.push({ name: '✨ การ์ดอัญมณีปลุกพลังพิเศษ S', grade: 'S', pct: specialRealPct, color: '#fbbf24' });
        }
        shadows.slice().reverse().forEach(s => {
            rows.push({
                name: s.name,
                grade: s.grade,
                pct: afterSpecialProb * (s.weight / totalShadowW) * 100,
                color: s.color
            });
        });

        if (tabsEl) {
            tabsEl.innerHTML = [
                { k: 'NORMAL', label: `🪙 แพ็คทอง (${goldMult}x)` },
                { k: 'SPECIAL', label: '💎 แพ็คเพชร (1x)' },
                { k: 'PREMIUM', label: `🔥 แพ็คพรีเมียม (${premMult}x)` }
            ].map(t => `<button type="button" class="gdr-tier-btn ${tier === t.k ? 'active' : ''}" onclick="switchGachaRateTierTab('${t.k}')">${t.label}</button>`).join('');
        }
        footerNote = '💡 อัตราการดรอปคิดต่อการสุ่ม 1 ใบ (รวมทุกรางวัล = 100%) เมื่อสะสมเงาอัญมณีครบ 5 สี สามารถนำไปหลอมเป็นอัญมณีแท้ได้ทันที';
    } else {
        const isDice = cat === 'DICE';
        const ev = currentEventGachaData || getDefaultFallbackEventData();
        modalTitle = isDice ? '🎲 โอกาสรับรางวัล • ลูกเต๋า 3D' : '👑 โอกาสรับรางวัล • กรอบรูปตัวละคร';

        let rBlack = Math.max(0, parseFloat(ev.rate_shadow_black ?? 90));
        let rRed = Math.max(0, parseFloat(ev.rate_shadow_red ?? 80));
        let rOrange = Math.max(0, parseFloat(ev.rate_shadow_orange ?? 70));
        let rBlue = Math.max(0, parseFloat(ev.rate_shadow_blue ?? 50));
        let rGold = Math.max(0, parseFloat(ev.rate_shadow_gold ?? 10));
        const rSpecial = Math.max(0, parseFloat(ev.rate_shadow_special ?? 15));
        let rSPlus = Math.max(0, parseFloat(ev.rate_splus ?? 3));

        if (tier === 'PREMIUM') {
            rBlack *= 0.25; rRed *= 0.35; rOrange *= 0.50; rBlue *= 1.85; rGold *= 2.50; rSPlus *= 2.00;
        } else if (tier === 'NORMAL') {
            rGold *= 0.45; rSPlus *= 0.25;
        }

        const customBySlot = {};
        if (Array.isArray(ev.shadow_config_json)) {
            ev.shadow_config_json.forEach(o => { if (o && o.slot) customBySlot[o.slot] = o; });
        } else if (typeof ev.shadow_config_json === 'string' && ev.shadow_config_json) {
            try {
                const dec = JSON.parse(ev.shadow_config_json);
                if (Array.isArray(dec)) dec.forEach(o => { if (o && o.slot) customBySlot[o.slot] = o; });
            } catch (e) {}
        }

        const slotDefs = [
            { slot: 'gold', name: isDice ? '🎲 เงาลูกเต๋าทอง' : '🟨 เงากรอบรูปทอง', grade: 'S', color: '#ffd700', w: rGold },
            { slot: 'blue', name: isDice ? '🎲 เงาลูกเต๋าฟ้า' : '🟦 เงากรอบรูปฟ้า', grade: 'A+', color: '#38bdf8', w: rBlue },
            { slot: 'orange', name: isDice ? '🎲 เงาลูกเต๋าส้ม' : '🟧 เงากรอบรูปส้ม', grade: 'A', color: '#ff8800', w: rOrange },
            { slot: 'red', name: isDice ? '🎲 เงาลูกเต๋าแดง' : '🟥 เงากรอบรูปแดง', grade: 'A', color: '#ef4444', w: rRed },
            { slot: 'black', name: isDice ? '🎲 เงาลูกเต๋าดำ' : '⬛ เงากรอบรูปดำ', grade: 'A', color: '#64748b', w: rBlack }
        ];

        const specialDropPct = Math.max(0, Math.min(100, parseFloat(ev.special_awakening_rates?.[isDice ? 'dice' : 'card'] ?? 5.0)));
        const restProb = Math.max(0, 1 - (specialDropPct / 100));

        const targetName = isDice
            ? (ev.target_dice?.name ? `🏆 ${ev.target_dice.name} (รางวัลใหญ่)` : '🏆 ลูกเต๋า 3D เป้าหมาย (รางวัลใหญ่)')
            : (ev.target_character?.name ? `🏆 ${ev.target_character.name} (รางวัลใหญ่)` : '🏆 กรอบรูปเป้าหมาย (รางวัลใหญ่)');
        const targetGrade = isDice ? (ev.target_dice?.grade || 'SS+') : (ev.target_character?.grade || 'SS+');
        const targetWeight = isDice
            ? (ev.dice_target_drop_rate !== undefined ? parseFloat(ev.dice_target_drop_rate) : (Math.max(1, rSPlus) * (1 + (Math.max(0, parseFloat(ev.rate_target_boost ?? 35)) / 100))))
            : (ev.target_drop_rate !== undefined ? parseFloat(ev.target_drop_rate) : rSPlus);

        const pool = [];
        if (targetWeight > 0) {
            pool.push({ name: targetName, grade: targetGrade, color: '#ec4899', weight: targetWeight, isJackpot: true });
        }
        if (specialDropPct <= 0 && rSpecial > 0) {
            pool.push({
                name: isDice ? '✨ การ์ดเต๋าปลุกพลังพิเศษ S' : '✨ การ์ดกรอบปลุกพลังพิเศษ S',
                grade: 'S',
                color: isDice ? '#00e5ff' : '#a855f7',
                weight: rSpecial
            });
        }
        slotDefs.forEach(d => {
            const cObj = customBySlot[d.slot] || {};
            const w = cObj.rate !== undefined ? Math.max(0, parseFloat(cObj.rate)) : d.w;
            pool.push({
                name: d.name,
                grade: cObj.grade || d.grade,
                color: cObj.color || d.color,
                weight: w
            });
        });

        const totalPoolW = pool.reduce((s, p) => s + p.weight, 0) || 100;
        if (specialDropPct > 0) {
            rows.push({
                name: isDice ? '✨ การ์ดเต๋าปลุกพลังพิเศษ S' : '✨ การ์ดกรอบปลุกพลังพิเศษ S',
                grade: 'S',
                pct: specialDropPct,
                color: isDice ? '#00e5ff' : '#a855f7'
            });
        }
        pool.forEach(p => {
            rows.push({
                name: p.name,
                grade: p.grade,
                pct: restProb * (p.weight / totalPoolW) * 100,
                color: p.color,
                isJackpot: Boolean(p.isJackpot)
            });
        });

        // เรียงให้รางวัลใหญ่อยู่บนสุดเสมอ
        rows.sort((a, b) => (b.isJackpot ? 1 : 0) - (a.isJackpot ? 1 : 0));

        if (tabsEl) {
            tabsEl.innerHTML = [
                { k: 'NORMAL', label: '🪙 แพ็คปกติ' },
                { k: 'SPECIAL', label: '💎 แพ็คกิจกรรม' },
                { k: 'PREMIUM', label: '🔥 แพ็คพรีเมียม' }
            ].map(t => `<button type="button" class="gdr-tier-btn ${tier === t.k ? 'active' : ''}" onclick="switchGachaRateTierTab('${t.k}')">${t.label}</button>`).join('');
        }
        footerNote = '💡 อัตราการดรอปคิดต่อการสุ่ม 1 ใบ (รวมทุกรางวัล = 100%) เมื่อสะสมการ์ดเงาครบตามกำหนดสามารถนำไปแลกรางวัลใหญ่ได้ทันที';
    }

    if (titleEl) titleEl.textContent = modalTitle;
    if (subEl) subEl.textContent = 'อัตราการดรอปต่อการสุ่ม 1 ใบ (รวมทุกรางวัล 100.00%)';
    if (noteEl) noteEl.textContent = footerNote;

    bodyEl.innerHTML = rows.map(r => {
        const pctStr = r.pct.toFixed(2);
        const barW = Math.max(2, Math.min(100, r.pct)).toFixed(1);
        const rowBg = r.isJackpot ? 'background:rgba(236,72,153,0.10);' : '';
        return `
            <tr style="${rowBg}">
                <td>
                    <div style="font-weight:700; color:${r.isJackpot ? '#fbcfe8' : '#f8fafc'};">${r.name}</div>
                    <div class="gdr-pct-bar-bg"><div class="gdr-pct-bar-fill" style="width:${barW}%; background:${r.color};"></div></div>
                </td>
                <td style="text-align:center;"><span class="gdr-grade-badge" style="background:${gradeBadgeColor(r.grade)};">${r.grade}</span></td>
                <td style="text-align:right; font-weight:800; color:${r.isJackpot ? '#f472b6' : '#38bdf8'}; white-space:nowrap;">${pctStr}%</td>
            </tr>
        `;
    }).join('');

    if (typeof openModal === 'function') {
        openModal('modal-gacha-drop-rates');
    } else {
        const m = document.getElementById('modal-gacha-drop-rates');
        if (m) m.style.display = 'flex';
    }
};

window.openEventRatesInfoPopup = function (category = 'FRAME') {
    window.openGachaDropRateModal(category === 'DICE' ? 'DICE' : 'FRAME', 'SPECIAL');
};


// =========================================================================
// 🌟 GRAND PRIZE JACKPOT CELEBRATION (เมื่อสุ่มได้ตัวการ์ด, เต๋า หรืออัญมณีแท้)
// =========================================================================
window.playGrandPrizeVictorySound = function () {
    try {
        if (window.soundEngine && typeof window.soundEngine.duckAllBgm === 'function') {
            window.soundEngine.duckAllBgm(2200);
        }
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        if (!window._grandPrizeAudioCtx) {
            window._grandPrizeAudioCtx = new AudioCtx();
        }
        const ctx = window._grandPrizeAudioCtx;
        if (ctx.state === 'suspended') {
            ctx.resume();
        }

        const now = ctx.currentTime;
        // Fanfare Arpeggio: C5 (523.25), E5 (659.25), G5 (783.99), C6 (1046.50), E6 (1318.51)
        const notes = [
            { f: 523.25, t: 0.00, d: 0.16 },
            { f: 659.25, t: 0.15, d: 0.16 },
            { f: 783.99, t: 0.30, d: 0.18 },
            { f: 1046.50, t: 0.46, d: 0.28 },
            { f: 1318.51, t: 0.72, d: 0.85 }
        ];

        notes.forEach(n => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(n.f, now + n.t);

            gain.gain.setValueAtTime(0.001, now + n.t);
            gain.gain.exponentialRampToValueAtTime(0.35, now + n.t + 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + n.t + n.d);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + n.t);
            osc.stop(now + n.t + n.d + 0.05);
        });

        // Add Final Chord Harmony (C5 + G5 + C6) for Epic Finish
        const chordStartTime = now + 0.72;
        [523.25, 783.99, 1046.50].forEach(f => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(f, chordStartTime);

            gain.gain.setValueAtTime(0.001, chordStartTime);
            gain.gain.exponentialRampToValueAtTime(0.2, chordStartTime + 0.05);
            gain.gain.exponentialRampToValueAtTime(0.001, chordStartTime + 1.2);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(chordStartTime);
            osc.stop(chordStartTime + 1.25);
        });
    } catch (e) {
        console.warn('playGrandPrizeVictorySound error:', e);
    }

    try {
        if (window.soundEngine && typeof window.soundEngine.playVictory === 'function') {
            window.soundEngine.playVictory();
        } else if (window.ThaiAudio && typeof window.ThaiAudio.playSuccess === 'function') {
            window.ThaiAudio.playSuccess();
        }
    } catch (_) { }
};

let pendingGrandPrizeCard = null;
let pendingGrandPrizeCategory = 'FRAME';

window.showGrandPrizeCelebrationModal = function (card, category = 'FRAME') {
    pendingGrandPrizeCard = card || {};
    pendingGrandPrizeCategory = category;

    const modal = document.getElementById('modal-grand-prize-celebration');
    if (!modal) return;

    const headingEl = document.getElementById('grand-prize-heading');
    const subEl = document.getElementById('grand-prize-sub');
    const itemCardEl = document.getElementById('grand-prize-item-card');

    const isDice = category === 'DICE' || card.type === 'DICE';
    const isGem = category === 'GEM' || card.type === 'GEM_ITEM' || card.type === 'GEM';
    const cardName = card.name || (isDice ? 'ลูกเต๋า 3D แรร์' : (isGem ? 'อัญมณีมหาเวทย์ SS+' : 'กรอบรูปตัวละคร SS+'));
    const grade = card.grade || card.rarity || 'SS+';

    if (headingEl) {
        headingEl.innerHTML = `🎉 ยินดีด้วย! ทำอีเวนต์สำเร็จแล้ว! 🎉`;
    }
    if (subEl) {
        subEl.innerText = isDice
            ? `คุณได้รับลูกเต๋า 3D ประจำกิจกรรม [${cardName}] (เกรด ${grade}) แล้ว!`
            : (isGem
                ? `คุณได้รับอัญมณีแท้ประจำกิจกรรม [${cardName}] (เกรด ${grade}) แล้ว!`
                : `คุณได้รับกรอบรูปประจำกิจกรรม [${cardName}] (เกรด ${grade}) แล้ว!`);
    }

    if (itemCardEl) {
        if (isDice) {
            itemCardEl.innerHTML = `
                <div class="complete-item-preview dice-theme" style="border: 2px solid #00e5ff; box-shadow: 0 0 20px rgba(0,229,255,0.5);">
                    <div class="complete-item-art" style="font-size:36px; display:flex; align-items:center; justify-content:center;">
                        ${card.image_url ? `<img src="${card.image_url}" alt="${cardName}" style="width:64px; height:64px; object-fit:contain;">` : '🎲'}
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge" style="background:#00e5ff; color:#000;">3D DICE • เกรด ${grade}</div>
                        <div class="complete-item-name" style="color:#fff; font-size:16px;">${cardName}</div>
                        <div class="complete-item-desc" style="color:#bae6fd;">🎲 เพิ่มอัตราความแม่นยำทอยเต๋า +${card.dice_control || 85}% • เอฟเฟกต์ลูกเต๋า 3D แสงนีออนสุดอลังการ</div>
                    </div>
                </div>
            `;
        } else if (isGem) {
            const gemShape = card.shape || 'pentagon';
            const gemColor = card.gem_color || '#ff4444';
            const svgPreview = (typeof window.generateGemSvgPreview === 'function')
                ? window.generateGemSvgPreview(gemShape, grade, 44, gemColor)
                : '<div style="font-size:32px;">💎</div>';

            itemCardEl.innerHTML = `
                <div class="complete-item-preview gem-theme" style="border: 2px solid ${gemColor}; box-shadow: 0 0 20px ${gemColor}88;">
                    <div class="complete-item-art" style="width:64px; height:64px; display:flex; align-items:center; justify-content:center;">
                        ${svgPreview}
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge" style="background:${gemColor}; color:#fff;">💎 GEM ITEM • เกรด ${grade}</div>
                        <div class="complete-item-name" style="color:#fff; font-size:16px;">${cardName}</div>
                        <div class="complete-item-desc" style="color:#bae6fd;">⚡ สกิล: ${card.skill_name || card.skill_category || 'สกิลอัญมณีระดับเทพ'} (อัตราติด ${card.trigger_rate_percent || 90}%)</div>
                    </div>
                </div>
            `;
        } else {
            const avatarUrl = (typeof window.getActivePlayerAvatarUrl === 'function')
                ? window.getActivePlayerAvatarUrl()
                : (card.avatar_url || (typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER.avatar_url : '') || 'avatars/google_avatar.png');
            const fObj = (window._latestFrameEventChar && (!card.frame_overlay_url && !card.aura_type))
                ? { ...window._latestFrameEventChar, ...card }
                : card;
            const fAura = (typeof window.getFrameAuraClass === 'function') ? window.getFrameAuraClass(grade, fObj.aura_type) : '';
            const fOver = (typeof window.buildAuraOverdriveStyle === 'function') ? window.buildAuraOverdriveStyle(grade, fObj.aura_type, fObj.aura_intensity || 100) : '';
            const fLayers = (typeof window.buildCustomFrameLayersHtml === 'function') ? window.buildCustomFrameLayersHtml(fObj) : '';
            itemCardEl.innerHTML = `
                <div class="complete-item-preview frame-theme" style="border: 2px solid #ffd700; box-shadow: 0 0 24px rgba(255,215,0,0.6); overflow:visible;">
                    <div class="frame-circle-wrap ${fAura}" style="position:relative; width:74px; height:74px; margin:6px; border-radius:14px; overflow:visible !important; flex-shrink:0; ${fOver}">
                        <img src="${avatarUrl}" alt="${cardName}" style="width:100%; height:100%; object-fit:cover; border-radius:12px;" onerror="this.src='avatars/google_avatar.png';">
                        ${fLayers}
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge">👑 FRAME CHARACTER • เกรด ${grade}</div>
                        <div class="complete-item-name">${cardName}</div>
                        <div class="complete-item-desc">⚡ ${card.skill_name || fObj.skill_name || 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง'}</div>
                    </div>
                </div>
            `;
        }
    }

    modal.style.zIndex = '100999';
    modal.style.display = 'flex';
    window.playGrandPrizeVictorySound();

    if (typeof confetti === 'function') {
        try {
            confetti({ particleCount: 95, spread: 85, origin: { y: 0.55 }, zIndex: 101050 });
            setTimeout(() => {
                confetti({ particleCount: 55, angle: 60, spread: 60, origin: { x: 0.15, y: 0.65 }, zIndex: 101050 });
                confetti({ particleCount: 55, angle: 120, spread: 60, origin: { x: 0.85, y: 0.65 }, zIndex: 101050 });
            }, 260);
        } catch (e) { }
    }
};

window.goToInventoryFromGrandPrize = function () {
    const cat = String(pendingGrandPrizeCategory || 'FRAME').toUpperCase();
    const card = pendingGrandPrizeCard || {};
    window.closeGrandPrizeCelebrationModal();
    if (typeof window.closeGachaVideoPopup === 'function') window.closeGachaVideoPopup();
    if (typeof closeModal === 'function') {
        closeModal('modal-event-frame');
        closeModal('modal-event-dice');
        closeModal('modal-gem-gacha');
    }
    let invTab = 'frames';
    if (cat === 'DICE' || card.type === 'DICE') invTab = 'dice';
    else if (cat === 'GEM' || card.type === 'GEM_ITEM' || card.type === 'GEM') invTab = 'gems';

    if (typeof openModal === 'function') openModal('modal-inventory');
    if (typeof window.loadInventoryData === 'function') {
        window.loadInventoryData().then(() => {
            if (typeof window.switchInventoryTab === 'function') window.switchInventoryTab(invTab);
        }).catch(() => {});
    } else if (typeof window.switchInventoryTab === 'function') {
        window.switchInventoryTab(invTab);
    }
};

window.closeGrandPrizeCelebrationModal = function () {
    const modal = document.getElementById('modal-grand-prize-celebration');
    if (modal) modal.style.display = 'none';
};

window.handleGrandPrizeClaim = function () {
    window.closeGrandPrizeCelebrationModal();
    if (typeof showToast === 'function') {
        showToast('🎉 บันทึกไอเทมรางวัลใหญ่เข้าสู่คลังของคุณเรียบร้อยแล้ว!');
    }
};

// =========================================================================
// 🌟 SHADOW COMPLETE CELEBRATION POPUP & INSTANT EXCHANGE LOGIC
// =========================================================================
let pendingShadowCompleteCategory = 'FRAME';
let pendingShadowCompleteTargetId = 1;
let pendingShadowCompleteGrade = 'SS+';

window.checkAndShowShadowCompleteModal = function (category = 'FRAME') {
    const ev = currentEventGachaData || (typeof getDefaultFallbackEventData === 'function' ? getDefaultFallbackEventData() : {});
    const uMats = ev.user_materials || {};
    const isDice = category === 'DICE';

    const isExpired = isDice
        ? Boolean(ev.dice_is_expired || (ev.dice_end_date && window.isThaiDateExpired(ev.dice_end_date)))
        : Boolean(ev.is_expired || (ev.end_date && window.isThaiDateExpired(ev.end_date)));
    if (isExpired) {
        if (typeof showInGameAlert === 'function') {
            showInGameAlert('ขออภัย! กิจกรรมนี้สิ้นสุดระยะเวลาแล้ว ไม่สามารถแลกรับของรางวัลได้อีก', 'กิจกรรมหมดเวลา', '🛑');
        } else {
            alert('🛑 ขออภัย! กิจกรรมนี้สิ้นสุดระยะเวลาแล้ว ไม่สามารถแลกรับของรางวัลได้อีก');
        }
        return false;
    }

    let canExchange = false;
    let targetItem = null;
    let mats = [];

    if (isDice) {
        const diceReqs = ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {};
        mats = buildShadowMatsArray(uMats, diceReqs, { black: 15, red: 15, orange: 15, blue: 10, gold: 4 });
        canExchange = mats.every(m => m.isReady);
        targetItem = ev.target_dice || { id: 1, name: 'ลูกเต๋านีออนมังกรทอง 3D', grade: 'SS+', dice_control: 85 };
        pendingShadowCompleteCategory = 'DICE';
        pendingShadowCompleteTargetId = targetItem.id || 1;
        pendingShadowCompleteGrade = targetItem.grade || 'SS+';
    } else {
        const reqs = ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {};
        mats = buildShadowMatsArray(uMats, reqs, { black: 25, red: 25, orange: 20, blue: 15, gold: 8 });
        canExchange = mats.every(m => m.isReady);
        targetItem = ev.target_character || { id: 1, name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+' };
        pendingShadowCompleteCategory = 'FRAME';
        pendingShadowCompleteTargetId = targetItem.id || 1;
        pendingShadowCompleteGrade = targetItem.grade || 'SS+';
    }

    if (!canExchange) return false;

    const popup = document.getElementById('modal-shadow-complete-popup');
    if (!popup) return false;

    const headingEl = document.getElementById('shadow-complete-heading');
    const subEl = document.getElementById('shadow-complete-sub');
    const itemCardEl = document.getElementById('shadow-complete-item-card');
    const chipsBarEl = document.getElementById('shadow-complete-chips-bar');
    const btnLabel = document.getElementById('btn-complete-redeem-label');

    if (headingEl) {
        headingEl.innerHTML = isDice
            ? '🎉 สะสมชิ้นส่วนเงาลูกเต๋าครบแล้ว! 🎲'
            : '🎉 สะสมการ์ดเงากรอบรูปครบ 5 สีแล้ว! 👑';
    }
    if (subEl) {
        subEl.innerText = isDice
            ? 'สะสมชิ้นส่วนเงาครบตามเงื่อนไข 100% พร้อมแลกรับลูกเต๋า 3D แรร์ได้ทันที!'
            : 'สะสมการ์ดเงาครบทั้ง 5 ชนิด 100% พร้อมแลกรับกรอบรูปตัวละครระดับ SS+ ทันที!';
    }

    if (itemCardEl) {
        if (isDice) {
            itemCardEl.innerHTML = `
                <div class="complete-item-preview dice-theme">
                    <div class="complete-item-art">
                        ${targetItem.image_url ? `<img src="${targetItem.image_url}" alt="${targetItem.name}" style="width:60px; height:60px; object-fit:contain;">` : '<div class="dice-3d-glyph">🎲</div>'}
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge">3D DICE • เกรด ${targetItem.grade || 'SS+'}</div>
                        <div class="complete-item-name">${targetItem.name || 'ลูกเต๋านีออนมังกรทอง 3D'}</div>
                        <div class="complete-item-desc">🎲 ควบคุมเต๋าแม่นยำ +${targetItem.dice_control || 85}% • เอฟเฟกต์ลูกเต๋า 3D แสงนีออนสุดอลังการ</div>
                    </div>
                </div>
            `;
        } else {
            const avatarUrl = targetItem.avatar_url || (typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER.avatar_url : '') || 'avatars/avatar_01.png';
            itemCardEl.innerHTML = `
                <div class="complete-item-preview frame-theme">
                    <div class="complete-item-art frame-art">
                        <div class="complete-frame-ring-spin"></div>
                        <img src="${avatarUrl}" alt="${targetItem.name}" onerror="this.src='avatars/avatar_01.png';">
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge">👑 กรอบรูปตัวละครระดับ ${targetItem.grade || 'SS+'}</div>
                        <div class="complete-item-name">${targetItem.name || 'ดาราจักรเนบิวลา SS+'}</div>
                        <div class="complete-item-desc">⚡ ${targetItem.skill_name || 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง'}</div>
                    </div>
                </div>
            `;
        }
    }

    if (chipsBarEl) {
        chipsBarEl.innerHTML = mats.map(m => `
            <div class="complete-chip-pill is-ready">
                <span class="chip-icon">${m.icon}</span>
                <span class="chip-name" style="color:${m.color}">${m.name}</span>
                <span class="chip-status">✔ ${m.owned}/${m.req}</span>
            </div>
        `).join('');
    }

    if (btnLabel) {
        btnLabel.innerText = isDice
            ? '✨ กดแลกรับลูกเต๋า 3D ทันที! 🎲'
            : '✨ กดแลกรับกรอบรูป SS+ ทันที! 👑';
    }

    popup.style.display = 'flex';

    if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
        try { window.soundEngine.playWin(); } catch (e) { }
    }

    return true;
};

window.triggerShadowCompleteRedeem = async function () {
    window.closeShadowCompletePopup();
    if (pendingShadowCompleteCategory === 'DICE') {
        await window.exchangeDiceAction(pendingShadowCompleteTargetId || 1);
    } else {
        await window.exchangeSPlusAction(pendingShadowCompleteTargetId || 1, pendingShadowCompleteGrade || 'SS+');
    }
};

window.closeShadowCompletePopup = function () {
    const pop = document.getElementById('modal-shadow-complete-popup');
    if (pop) pop.style.display = 'none';
};

/* ===================================================================
   INSPECT MODAL: แตะที่เงาเพื่อแสดงตัวอย่างรูปแบบและรายละเอียดตรงกลาง
   =================================================================== */
window.showShadowMaterialInspectModal = function (matCode, category = 'FRAME') {
    try {
        if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
            window.soundEngine.playClick();
        }
    } catch (_) { }

    const isDice = category === 'DICE';
    const ev = currentEventGachaData || (typeof getDefaultFallbackEventData === 'function' ? getDefaultFallbackEventData() : {});
    const uMats = ev.user_materials || {};

    const reqs = isDice
        ? (ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {})
        : (ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {});
    const defaultReqs = isDice
        ? { black: 15, red: 15, orange: 15, blue: 10, gold: 4 }
        : { black: 25, red: 25, orange: 20, blue: 15, gold: 8 };

    const isSpecialAwaken = ['SPECIAL_CARD', 'SPECIAL_DICE_CARD', 'SPECIAL_GEM_CARD'].includes(String(matCode || '').toUpperCase());
    const specialCodeUpper = String(matCode || '').toUpperCase();
    const reqAwakenLv30 = (window.GAME_RULES && window.GAME_RULES.special_awakening_config && window.GAME_RULES.special_awakening_config.req_qty_lv30)
        ? Number(window.GAME_RULES.special_awakening_config.req_qty_lv30)
        : 5;
    const specialOwnedQty = Number((window.latestMaterialsMap && window.latestMaterialsMap[specialCodeUpper]) ?? uMats[specialCodeUpper] ?? 0);

    const allMats = buildShadowMatsArray(uMats, reqs, defaultReqs);
    const specialTitleMap = {
        'SPECIAL_CARD': 'การ์ดกรอบปลุกพลังพิเศษ S',
        'SPECIAL_DICE_CARD': 'การ์ดเต๋าปลุกพลังพิเศษ S',
        'SPECIAL_GEM_CARD': 'การ์ดอัญมณีปลุกพลังพิเศษ S'
    };
    const targetMat = isSpecialAwaken
        ? {
            code: specialCodeUpper,
            name: specialTitleMap[specialCodeUpper] || 'การ์ดพิเศษ (Special Awakening)',
            owned: specialOwnedQty,
            req: reqAwakenLv30,
            isReady: specialOwnedQty >= reqAwakenLv30,
            slot: 6,
            rate: 15
        }
        : (allMats.find(m => m.code === matCode || (m.altCode && m.altCode === matCode)) || allMats[0]);

    const shadowMeta = {
        'SHADOW_BLACK_A': {
            grade: 'A',
            gradeBadgeBg: 'linear-gradient(135deg, #475569, #1e293b)',
            nameTh: 'เงาดำ A',
            colorName: 'ดำออบซิเดียน',
            glowColor: '#94a3b8',
            accentColor: '#94a3b8',
            haloBorder: '#94a3b8',
            haloBg: 'radial-gradient(circle, rgba(148,163,184,0.3) 0%, transparent 70%)',
            desc: isDice
                ? 'ชิ้นส่วนเงาดำลูกเต๋า อณูพลังแห่งความมืดมิด เป็น 1 ใน 5 วัตถุดิบหลักในการสังเคราะห์ลูกเต๋า 3D ระดับแรร์'
                : 'การ์ดเงาดำระดับ A พลังแห่งความลึกลับ ใช้สะสมร่วมกับเงาสีอื่นเพื่อปลดล็อกกรอบรูปตัวละครระดับตำนาน'
        },
        'SHADOW_RED_A': {
            grade: 'A',
            gradeBadgeBg: 'linear-gradient(135deg, #ef4444, #991b1b)',
            nameTh: 'เงาแดง A',
            colorName: 'แดงเพลิงรูบี้',
            glowColor: '#ef4444',
            accentColor: '#f87171',
            haloBorder: '#ef4444',
            haloBg: 'radial-gradient(circle, rgba(239,68,68,0.35) 0%, transparent 70%)',
            desc: isDice
                ? 'ชิ้นส่วนเงาแดงลูกเต๋า เปลวเพลิงแห่งการทำลายล้าง ใช้สะสมเพื่ออัปเกรดและสังเคราะห์ลูกเต๋า 3D'
                : 'การ์ดเงาแดงระดับ A เปลวไฟแห่งชัยชนะ ใช้สะสมเป็นวัตถุดิบสำคัญในการแลกรับกรอบรูปตัวละคร'
        },
        'SHADOW_ORANGE_A': {
            grade: 'A',
            gradeBadgeBg: 'linear-gradient(135deg, #f97316, #c2410c)',
            nameTh: 'เงาส้ม A',
            colorName: 'ส้มสุริยัน',
            glowColor: '#f97316',
            accentColor: '#fb923c',
            haloBorder: '#f97316',
            haloBg: 'radial-gradient(circle, rgba(249,115,22,0.35) 0%, transparent 70%)',
            desc: isDice
                ? 'ชิ้นส่วนเงาส้มลูกเต๋า แสงสุริยันร้อนแรง ใช้สะสมเพื่อปลดล็อกลูกเต๋า 3D แรร์'
                : 'การ์ดเงาส้มระดับ A พลังแห่งแสงอาทิตย์ เป็นวัตถุดิบสำคัญในการสะสมแลกรับกรอบรูปตัวละคร'
        },
        'SHADOW_BLUE_APLUS': {
            grade: 'A+',
            gradeBadgeBg: 'linear-gradient(135deg, #0ea5e9, #0369a1)',
            nameTh: 'เงาฟ้า A+',
            colorName: 'ฟ้าสายฟ้าคราม',
            glowColor: '#38bdf8',
            accentColor: '#7dd3fc',
            haloBorder: '#38bdf8',
            haloBg: 'radial-gradient(circle, rgba(56,189,248,0.35) 0%, transparent 70%)',
            desc: isDice
                ? 'ชิ้นส่วนเงาฟ้าลูกเต๋า A+ ธาตุเยือกแข็งและสายฟ้า แรร์พิเศษระดับ A+ ใช้ในการสังเคราะห์ลูกเต๋า 3D'
                : 'การ์ดเงาฟ้าแรร์ระดับ A+ ประกายสายฟ้าเย็นยะเยือก วัตถุดิบเกรด A+ ชิ้นสำคัญในการแลกรับกรอบรูป'
        },
        'SHADOW_GOLD_S': {
            grade: 'S',
            gradeBadgeBg: 'linear-gradient(135deg, #ffd700, #b45309)',
            nameTh: 'เงาทอง S',
            colorName: 'ทองจักรพรรดิ',
            glowColor: '#ffd700',
            accentColor: '#fde047',
            haloBorder: '#ffd700',
            haloBg: 'radial-gradient(circle, rgba(255,215,0,0.4) 0%, transparent 70%)',
            desc: isDice
                ? 'ชิ้นส่วนเงาทองลูกเต๋า [S] ระดับสูงสุด หายากที่สุด! หัวใจสำคัญในการปลดล็อกลูกเต๋า 3D ในตำนาน'
                : 'การ์ดเงาทองระดับตำนาน [S] เปล่งรัศมีจักรพรรดิ หายากที่สุด! หัวใจหลักในการแลกรับกรอบรูปตัวละคร SS+'
        },
        'SPECIAL_CARD': {
            grade: 'S',
            gradeBadgeBg: 'linear-gradient(135deg, #a855f7, #6d28d9)',
            nameTh: 'การ์ดพิเศษ (Special Awakening)',
            colorName: 'ม่วงคริสตัล',
            glowColor: '#c084fc',
            accentColor: '#e9d5ff',
            haloBorder: '#c084fc',
            haloBg: 'radial-gradient(circle, rgba(192,132,252,0.42) 0%, transparent 70%)',
            desc: `การ์ดปลุกพลังพิเศษระดับ S ใช้ร่วมกับเพชรในการปลุกพลังกรอบรูป/การ์ดจาก Lv.29 ➔ Lv.30 MAX (${reqAwakenLv30} ใบ)`
        },
        'SPECIAL_DICE_CARD': {
            grade: 'S',
            gradeBadgeBg: 'linear-gradient(135deg, #a855f7, #6d28d9)',
            nameTh: 'การ์ดเต๋าปลุกพลังพิเศษ S',
            colorName: 'ม่วงคริสตัล',
            glowColor: '#c084fc',
            accentColor: '#e9d5ff',
            haloBorder: '#c084fc',
            haloBg: 'radial-gradient(circle, rgba(192,132,252,0.42) 0%, transparent 70%)',
            desc: `การ์ดปลุกพลังพิเศษระดับ S ใช้ร่วมกับเพชรในการปลุกพลังลูกเต๋า 3D จาก Lv.29 ➔ Lv.30 MAX (${reqAwakenLv30} ใบ)`
        },
        'SPECIAL_GEM_CARD': {
            grade: 'S',
            gradeBadgeBg: 'linear-gradient(135deg, #a855f7, #6d28d9)',
            nameTh: 'การ์ดอัญมณีปลุกพลังพิเศษ S',
            colorName: 'ม่วงคริสตัล',
            glowColor: '#c084fc',
            accentColor: '#e9d5ff',
            haloBorder: '#c084fc',
            haloBg: 'radial-gradient(circle, rgba(192,132,252,0.42) 0%, transparent 70%)',
            desc: `การ์ดปลุกพลังพิเศษระดับ S ใช้ร่วมกับเพชรในการปลุกพลังอัญมณีจาก Lv.29 ➔ Lv.30 MAX (${reqAwakenLv30} ใบ)`
        }
    };

    let matStartDate = isDice ? (ev.dice_start_date || ev.start_date) : ev.start_date;
    let matEndDate = isDice ? (ev.dice_end_date || ev.end_date) : ev.end_date;
    if (!matStartDate || !matEndDate) {
        const catKey = isDice ? 'DICE' : 'FRAME';
        const st = window.latestEventsStatus ? window.latestEventsStatus[catKey] : null;
        if (st) {
            matStartDate = matStartDate || st.start_date;
            matEndDate = matEndDate || st.end_date;
        }
    }
    if (!matStartDate) matStartDate = '2026-11-16 14:50:00';
    if (!matEndDate) matEndDate = '2026-11-25 23:59:59';

    const isLive = Boolean(ev.is_live_now || ev.is_active || (window.latestEventsStatus && window.latestEventsStatus[isDice ? 'DICE' : 'FRAME'] && !window.latestEventsStatus[isDice ? 'DICE' : 'FRAME'].is_expired));
    const isMatExpired = isLive ? false : (isDice
        ? Boolean(ev.dice_is_expired || (ev.dice_end_date && window.isThaiDateExpired(ev.dice_end_date)))
        : Boolean(ev.is_expired || (ev.end_date && window.isThaiDateExpired(ev.end_date))));
    const matDateRangeShort = window.formatEventDateRangeShort ? window.formatEventDateRangeShort(matStartDate, matEndDate) : '';

    const specialCatMap = { 'SPECIAL_CARD': 'card', 'SPECIAL_DICE_CARD': 'dice', 'SPECIAL_GEM_CARD': 'gem' };
    const specialCatKey = specialCatMap[specialCodeUpper] || 'card';
    const specialInfo = (isSpecialAwaken && typeof window.getSpecialAwakeningCardInfo === 'function')
        ? window.getSpecialAwakeningCardInfo(specialCatKey)
        : null;
    if (specialInfo) {
        targetMat.name = specialInfo.title;
        if (specialInfo.startDate) matStartDate = specialInfo.startDate;
        if (specialInfo.endDate) matEndDate = specialInfo.endDate;
    }
    const effectiveExpired = isSpecialAwaken && specialInfo ? Boolean(specialInfo.isExpired) : isMatExpired;

    const meta = shadowMeta[targetMat.code] || shadowMeta['SHADOW_BLACK_A'];
    if (specialInfo) {
        meta.haloBorder = specialInfo.color;
        meta.nameTh = specialInfo.title;
    }
    const owned = targetMat.owned;
    const req = targetMat.req;
    const isReady = targetMat.isReady;
    const progressPct = Math.min(100, Math.round((owned / Math.max(1, req)) * 100));

    const targetItem = isDice
        ? (ev.target_dice || { id: 1, name: 'ลูกเต๋านีออนมังกรทอง 3D', grade: 'SS+', dice_control: 85 })
        : (ev.target_character || { id: 1, name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+', skill_name: 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง' });

    const charAvatar = (!isDice && targetItem.avatar_url) ? targetItem.avatar_url : 'avatars/avatar_01.png';

    const dropSourceText = isDice
        ? 'สุ่มได้จาก: แพ็คลูกเต๋าพิเศษ (+1 / +5 ชิ้น), ชุดลูกเต๋าพรีเมียม (+5 / +10 ชิ้น) และชุดลูกเต๋าทั่วไปในหน้าร้านค้าอีเวนต์'
        : 'สุ่มได้จาก: แพ็คการ์ดกรอบพิเศษ (+1 / +5 ชิ้น), ชุดกรอบพรีเมียม (+5 / +10 ชิ้น) และชุดการ์ดทั่วไปในหน้าร้านค้าอีเวนต์';

    let modal = document.getElementById('modal-shadow-inspect-popup');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modal-shadow-inspect-popup';
        modal.className = 'modal-overlay shadow-inspect-overlay';
        modal.style.cssText = 'display:none; z-index:100700; background:rgba(0,0,0,0.75); backdrop-filter:blur(8px); align-items:center; justify-content:center;';
        modal.onclick = (e) => { if (e.target === modal) window.closeShadowInspectPopup(); };
        modal.innerHTML = '<div class="glass-panel gem-shadow-detail-box" id="shadow-inspect-box" style="position:relative;"></div>';
        document.body.appendChild(modal);
    } else {
        modal.style.background = 'rgba(0,0,0,0.75)';
        modal.style.backdropFilter = 'blur(8px)';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
    }

    const box = document.getElementById('shadow-inspect-box');
    if (!box) return;

    box.className = 'glass-panel gem-shadow-detail-box';
    box.style.borderColor = meta.haloBorder;
    box.style.boxShadow = `0 16px 40px rgba(0,0,0,0.9), 0 0 28px ${meta.haloBorder}88`;

    const dropRate = targetMat.rate || (targetMat.slot === 5 ? 10 : (targetMat.slot === 4 ? 50 : 80));

    box.innerHTML = `
        <button type="button" onclick="window.closeShadowInspectPopup()" style="position:absolute; top:8px; right:8px; background:rgba(255,255,255,0.12); border:none; color:#fff; width:24px; height:24px; border-radius:50%; font-size:12px; cursor:pointer; display:flex; align-items:center; justify-content:center; z-index:10;" aria-label="ปิด">✕</button>
        
        <!-- Live Preview Card (Compact) -->
        ${isSpecialAwaken && typeof window.buildSpecialAwakeningCardHtml === 'function'
            ? `<div style="display:flex; justify-content:center; margin:0 auto 6px auto;">${window.buildSpecialAwakeningCardHtml(specialCatKey, 58)}</div>`
            : `<div style="position:relative; width:136px; max-width:80%; height:48px; margin:0 auto 6px auto; border-radius:9px; border:1.5px solid ${meta.haloBorder}; display:flex; align-items:center; justify-content:center; overflow:hidden; background:radial-gradient(circle at 50% 50%, ${meta.haloBorder}44 0%, #050811 85%); box-shadow:0 0 14px ${meta.haloBorder}66, inset 0 0 10px ${meta.haloBorder}33;">
            <div style="position:absolute; width:100%; height:100%; display:flex; align-items:center; justify-content:center; pointer-events:none; opacity:0.25; z-index:1; font-size:22px;">
                ${isDice ? '🎲' : '👑'}
            </div>
            <div class="grade-emblem" style="--gc:${meta.haloBorder}; font-size:24px; z-index:5; font-family:'Kanit',sans-serif; font-weight:900; line-height:1; letter-spacing:-0.5px;">
                <span class="ge-txt" style="color:#ffffff; text-shadow:0 0 10px ${meta.haloBorder}, 0 2px 4px rgba(0,0,0,0.9); font-weight:900;">${window.gradeEmblemInnerHtml ? window.gradeEmblemInnerHtml(meta.grade) : meta.grade}</span>
            </div>
            <span class="sh-grade-pill" style="position:absolute; bottom:3px; right:3px; background:${meta.haloBorder}; color:#000; font-size:8px; font-weight:900; padding:1px 4px; border-radius:4px; border:1px solid #fff; z-index:6; line-height:1;">
                ${meta.grade}
            </span>
            ${(targetMat.slot === 5 || meta.grade === 'S' || meta.grade === 'SS+') ? `
                <div style="position:absolute; top:2px; right:3px; font-size:10px; filter:drop-shadow(0 0 4px #ffd700); z-index:6;">👑</div>
            ` : ''}
        </div>`}

        <!-- Tag Pill -->
        <div style="display:inline-block; padding:1.5px 10px; border-radius:6px; background:${meta.haloBorder}22; border:1px solid ${meta.haloBorder}; color:${meta.accentColor}; font-size:9.5px; font-weight:900; letter-spacing:0.2px;">
            ${isSpecialAwaken ? `[${meta.grade}] การ์ดปลุกพลังพิเศษ (Lv.29 ➔ Lv.30 MAX)` : `[${meta.grade}] ชิ้นส่วนเงาอันดับ ${targetMat.slot || 1}`}
        </div>

        <!-- Shadow Title -->
        <div style="margin:3px 0 5px 0; color:#fff; font-size:13.5px; font-weight:900; line-height:1.2; text-shadow:0 2px 5px rgba(0,0,0,0.8);">
            ${targetMat.name}
        </div>
        
        <!-- Progress Container -->
        <div style="background:rgba(10,15,30,0.75); border:1px solid rgba(255,255,255,0.12); border-radius:9px; padding:6px 9px; text-align:left;">
            <div style="display:flex; justify-content:space-between; align-items:center; font-size:10px; margin-bottom:4px;">
                <span style="color:#e2e8f0; font-weight:800;">จำนวนที่ครอบครอง:</span>
                <span style="color:#38bdf8; font-weight:900; font-size:11.5px;">${owned} / ${req} ${isSpecialAwaken ? 'ใบ' : 'ชิ้น'}</span>
            </div>
            <div style="width:100%; height:6px; border-radius:3px; background:rgba(255,255,255,0.1); overflow:hidden;">
                <div style="width:${progressPct}%; height:100%; background:linear-gradient(90deg, #38bdf8 0%, #a855f7 100%); border-radius:3px;"></div>
            </div>
            <div style="margin-top:4px; font-size:9.5px; font-weight:800; color:${effectiveExpired ? '#f87171' : (isReady ? '#4ade80' : '#94a3b8')}; line-height:1.25;">
                ${isSpecialAwaken
                    ? (effectiveExpired ? '⏰ การ์ดปลุกพลังรอบนี้หมดอายุแล้ว ไม่สามารถใช้งานได้' : (isReady ? '🎉 สะสมครบแล้ว! พร้อมใช้ปลุกพลัง Lv.29 ➔ Lv.30 MAX' : `⏳ ขาดอีก ${req - owned} ใบ เพื่อใช้ปลุกพลัง Lv.30 MAX`))
                    : (isReady ? `🎉 สะสมครบแล้ว! พร้อมแลกรับ${isDice ? 'ลูกเต๋า 3D แท้' : 'กรอบรูปแท้'}` : `⏳ ขาดอีก ${req - owned} ชิ้น เพื่อแลกรับ [${targetItem.name || (isDice ? 'ลูกเต๋า 3D' : 'กรอบรูป')}]`)}
            </div>
        </div>

        <!-- Event Period & Rules Box -->
        <div style="margin-top:5px; background:rgba(15,23,42,0.8); border:1px solid ${isMatExpired ? '#ef4444' : 'rgba(16,185,129,0.45)'}; border-radius:9px; padding:6px 9px; text-align:left; font-size:9.5px; line-height:1.3;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                <span style="color:#94a3b8; font-weight:800;">📅 ระยะเวลากิจกรรม:</span>
                <span style="color:${isMatExpired ? '#f87171' : '#34d399'}; font-weight:900;">
                    ${isMatExpired ? '🛑 สิ้นสุดแล้ว' : '🔥 กำลังจัดกิจกรรม'}
                </span>
            </div>
            <div style="color:#cbd5e1; font-size:9px;">
                ${window.formatEventDateLong(matStartDate)} – ${window.formatEventDateLong(matEndDate)}
            </div>
        </div>

        <!-- Action Buttons -->
        ${(allMats.every(m => m.isReady) && !isMatExpired) ? `
            <div style="width:100%; display:flex; gap:6px; margin-top:7px;">
                <button type="button" onclick="window.closeShadowInspectPopup()" style="flex:1; padding:6px 8px; border-radius:8px; background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.2); color:#cbd5e1; font-size:11px; font-weight:800; cursor:pointer;">
                    ตกลง
                </button>
                <button type="button" onclick="window.closeShadowInspectPopup(); window.checkAndShowShadowCompleteModal('${category}');" style="flex:1.5; padding:6px 8px; border-radius:8px; background:linear-gradient(135deg, #10b981, #059669); border:1px solid #6ee7b7; color:#fff; font-size:11px; font-weight:900; cursor:pointer; box-shadow:0 0 10px rgba(16,185,129,0.45);">
                    🎉 กดแลกรับทันที!
                </button>
            </div>
        ` : `
            <button type="button" onclick="window.closeShadowInspectPopup()" style="width:100%; margin-top:7px; padding:6px 10px; border-radius:8px; background:linear-gradient(135deg, #a855f7, #7c3aed); color:#fff; font-weight:900; font-size:11.5px; border:none; cursor:pointer; box-shadow:0 0 12px rgba(168,85,247,0.45);">
                ตกลง
            </button>
        `}
    `;

    modal.style.display = 'flex';
};

window.closeShadowInspectPopup = function () {
    const pop = document.getElementById('modal-shadow-inspect-popup');
    if (pop) pop.style.display = 'none';
};

window.exchangeSPlusAction = async function (charId, grade) {
    await window.doCraftFrameTier(grade || 'SS+', charId, 'event');
    await loadEventGachaData();
};

window.exchangeDiceAction = async function (diceId) {
    if (!window.apiClient) return;
    try {
        const res = await apiClient.exchangeDiceFromShadows(diceId);
        if (res && res.status === 'success') {
            showInGameAlert(res.message || 'แลกรับลูกเต๋าสำเร็จ!', 'ยินดีด้วย! 🎉', '🎲');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            if (typeof loadEventGachaData === 'function') await loadEventGachaData();
            if (typeof loadInventoryData === 'function') await loadInventoryData();
        } else {
            showInGameAlert(res.message || 'สะสมเงายังไม่ครบตามที่กำหนด', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการแลกลูกเต๋า', 'ข้อผิดพลาด', '❌');
    }
};

// =========================================================================
// 💎 UNIFIED PURCHASE & CARD PACK CONFIRMATION MODAL (แสดงราคากี่เพชร/ทอง & ยืนยันก่อนเปิดการ์ด/ซื้อทุกหน้า)
// =========================================================================
let _pendingPurchaseConfirmCallback = null;

function ensurePurchaseConfirmModalDOM() {
    let modal = document.getElementById('modal-purchase-confirm');
    if (modal) return modal;

    modal = document.createElement('div');
    modal.id = 'modal-purchase-confirm';
    modal.className = 'modal-overlay';
    modal.style.cssText = 'display:none; z-index:125000; background:rgba(2,6,23,0.86); backdrop-filter:blur(8px); align-items:center; justify-content:center; padding:8px;';
    modal.innerHTML = `
        <div id="purchase-confirm-box" style="
            width:min(88vw, 304px);
            max-width:304px;
            background:linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            border:1.5px solid #38bdf8;
            border-radius:14px;
            box-shadow:0 14px 36px rgba(0,0,0,0.88), 0 0 24px rgba(56,189,248,0.35);
            overflow:hidden;
            color:#f8fafc;
            font-family:inherit;
            box-sizing:border-box;
            animation:modalPopIn 0.2s cubic-bezier(0.16,1,0.3,1);
        ">
            <!-- Header -->
            <div id="purchase-confirm-header" style="
                background:linear-gradient(90deg, #0284c7 0%, #1d4ed8 100%);
                padding:7px 11px;
                display:flex;
                align-items:center;
                justify-content:space-between;
                border-bottom:1.5px solid rgba(255,255,255,0.2);
            ">
                <div style="display:flex; align-items:center; gap:6px; min-width:0;">
                    <span id="purchase-confirm-header-icon" style="font-size:15px; line-height:1;">💎</span>
                    <span id="purchase-confirm-header-title" style="font-size:12px; font-weight:900; color:#fff; letter-spacing:0.2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">ยืนยันการเปิดแพ็คการ์ด</span>
                </div>
                <button type="button" onclick="window.closePurchaseConfirmModal(false)" style="
                    width:22px; height:22px; border-radius:50%; border:1px solid rgba(255,255,255,0.4);
                    background:rgba(15,23,42,0.45); color:#fff; font-size:14px; font-weight:900;
                    cursor:pointer; display:flex; align-items:center; justify-content:center; line-height:1; padding:0; flex-shrink:0;
                ">&times;</button>
            </div>

            <!-- Body -->
            <div style="padding:8px 10px 10px 10px; display:flex; flex-direction:column; gap:7px; box-sizing:border-box;">
                <!-- Item Preview Card -->
                <div style="
                    background:rgba(15,23,42,0.75);
                    border:1px solid rgba(148,163,184,0.28);
                    border-radius:10px;
                    padding:7px 9px;
                    display:flex;
                    align-items:center;
                    gap:9px;
                ">
                    <div id="purchase-confirm-item-icon" style="
                        width:40px; height:40px; border-radius:10px;
                        background:radial-gradient(circle at 30% 30%, rgba(56,189,248,0.35), rgba(15,23,42,0.9));
                        border:1.5px solid #38bdf8;
                        display:flex; align-items:center; justify-content:center;
                        font-size:20px; flex-shrink:0;
                        box-shadow:0 3px 10px rgba(0,0,0,0.4);
                    ">👑</div>
                    <div style="min-width:0; flex:1; text-align:left;">
                        <div id="purchase-confirm-badge" style="
                            display:inline-block; font-size:8.5px; font-weight:900;
                            padding:1px 6px; border-radius:999px;
                            background:rgba(56,189,248,0.2); color:#38bdf8;
                            border:1px solid rgba(56,189,248,0.45); margin-bottom:2px;
                        ">ตรวจสอบราคาก่อนยืนยัน</div>
                        <div id="purchase-confirm-item-name" style="font-size:12px; font-weight:900; color:#fff; line-height:1.2;">แพ็คการ์ดกรอบพิเศษ (+1 ใบ)</div>
                        <div id="purchase-confirm-item-desc" style="font-size:10px; color:#cbd5e1; margin-top:1.5px; line-height:1.25;">สุ่มการ์ดกรอบรูปพิเศษ & การ์ดเงา (+1 ใบ)</div>
                    </div>
                </div>

                <!-- Prominent Price Display Box -->
                <div id="purchase-confirm-price-box" style="
                    background:linear-gradient(135deg, rgba(2,132,199,0.24) 0%, rgba(15,23,42,0.92) 100%);
                    border:1.5px solid #38bdf8;
                    border-radius:10px;
                    padding:7px 10px;
                    text-align:center;
                    box-shadow:inset 0 0 14px rgba(56,189,248,0.15);
                ">
                    <div style="font-size:9.5px; font-weight:800; color:#94a3b8; text-transform:uppercase; letter-spacing:0.4px;">ราคาที่ใช้ในการทำรายการนี้</div>
                    <div id="purchase-confirm-price-big" style="
                        font-size:17px; font-weight:900; color:#38bdf8;
                        margin:2px 0 5px 0;
                        text-shadow:0 2px 8px rgba(56,189,248,0.45);
                        display:flex; align-items:center; justify-content:center; gap:5px; line-height:1.2;
                    ">💎 50 เพชร</div>

                    <div style="
                        display:flex; justify-content:space-between; align-items:center;
                        border-top:1px dashed rgba(148,163,184,0.28);
                        padding-top:5px; font-size:10px; color:#cbd5e1;
                    ">
                        <span>ยอดคงเหลือของคุณ:</span>
                        <b id="purchase-confirm-balance-now" style="color:#fff; font-size:10.5px;">💎 0 เพชร</b>
                    </div>
                    <div style="
                        display:flex; justify-content:space-between; align-items:center;
                        margin-top:2px; font-size:10px; color:#cbd5e1;
                    ">
                        <span>คงเหลือหลังยืนยัน:</span>
                        <b id="purchase-confirm-balance-after" style="color:#4ade80; font-size:10.5px;">💎 0 เพชร</b>
                    </div>
                </div>

                <!-- Buttons -->
                <div id="purchase-confirm-btn-row" style="display:flex; flex-wrap:wrap; gap:7px; margin-top:1px;">
                    <button type="button" onclick="window.closePurchaseConfirmModal(false)" style="
                        flex:1 1 85px; padding:7px 8px; border-radius:8px;
                        border:1px solid #475569;
                        background:linear-gradient(180deg, #334155 0%, #1e293b 100%);
                        color:#e2e8f0; font-size:11px; font-weight:800;
                        cursor:pointer; line-height:1.2;
                    ">❌ ยกเลิก</button>
                    <button type="button" id="purchase-confirm-ok-btn" onclick="window.closePurchaseConfirmModal(true)" style="
                        flex:1.4 1 120px; padding:7px 10px; border-radius:8px;
                        border:1px solid #bae6fd;
                        background:linear-gradient(180deg, #38bdf8 0%, #0284c7 100%);
                        color:#fff; font-size:11.5px; font-weight:900;
                        cursor:pointer; box-shadow:0 4px 12px rgba(2,132,199,0.45); line-height:1.2;
                    ">✅ ยืนยันเปิดการ์ด</button>
                    <button type="button" id="purchase-confirm-extra-btn" onclick="window.closePurchaseConfirmModal('extra')" style="
                        display:none; flex:1 1 100%; padding:8px 10px; border-radius:8px;
                        border:1px solid #fde047;
                        background:linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
                        color:#fff; font-size:11.5px; font-weight:900;
                        cursor:pointer; box-shadow:0 4px 14px rgba(245,158,11,0.45); line-height:1.2;
                    ">⚡ อัปถึง Lv.29 ทันที</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    return modal;
}

window.showPurchaseConfirmModal = function (opts = {}, onConfirm = null) {
    const modal = ensurePurchaseConfirmModalDOM();
    _pendingPurchaseConfirmCallback = onConfirm;

    const currency = String(opts.currency || 'DIAMOND').toUpperCase();
    const price = Math.max(0, Number(opts.price || 0));
    const isGold = currency === 'GOLD';
    const isThb = currency === 'THB';

    const currIcon = isThb ? '฿' : (isGold ? '💰' : '💎');
    const currUnit = isThb ? 'บาท' : (isGold ? 'ทอง' : 'เพชร');
    const priceFormatted = isThb ? price.toFixed(2) : price.toLocaleString();
    const fullPriceText = `${currIcon} ${priceFormatted} ${currUnit}`;

    const userDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? Number(DEFAULT_USER.diamond || 0) : 0;
    const userGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? Number(DEFAULT_USER.gold || 0) : 0;
    const currentBal = isGold ? userGold : userDia;
    const afterBal = currentBal - price;
    const isEnough = isThb ? true : (currentBal >= price);

    const accentColor = isGold ? '#f59e0b' : (isThb ? '#10b981' : '#38bdf8');
    const headerGrad = isGold
        ? 'linear-gradient(90deg, #d97706 0%, #b45309 100%)'
        : (isThb ? 'linear-gradient(90deg, #059669 0%, #047857 100%)' : 'linear-gradient(90deg, #0284c7 0%, #1d4ed8 100%)');

    const box = document.getElementById('purchase-confirm-box');
    const header = document.getElementById('purchase-confirm-header');
    const headerIcon = document.getElementById('purchase-confirm-header-icon');
    const headerTitle = document.getElementById('purchase-confirm-header-title');
    const itemIcon = document.getElementById('purchase-confirm-item-icon');
    const badge = document.getElementById('purchase-confirm-badge');
    const itemName = document.getElementById('purchase-confirm-item-name');
    const itemDesc = document.getElementById('purchase-confirm-item-desc');
    const priceBox = document.getElementById('purchase-confirm-price-box');
    const priceBig = document.getElementById('purchase-confirm-price-big');
    const balNow = document.getElementById('purchase-confirm-balance-now');
    const balAfter = document.getElementById('purchase-confirm-balance-after');
    const okBtn = document.getElementById('purchase-confirm-ok-btn');
    const extraBtn = document.getElementById('purchase-confirm-extra-btn');
    window._pendingPurchaseExtraCallback = (opts.extraBtn && typeof opts.extraBtn.onConfirm === 'function') ? opts.extraBtn.onConfirm : null;

    if (box) box.style.borderColor = accentColor;
    if (header) header.style.background = headerGrad;
    if (headerIcon) headerIcon.innerText = opts.headerIcon || currIcon;
    if (headerTitle) headerTitle.innerText = opts.headerTitle || 'ยืนยันราคาก่อนเปิดการ์ด / สั่งซื้อ';

    if (itemIcon) {
        itemIcon.style.borderColor = accentColor;
        itemIcon.innerHTML = opts.iconHtml || `<span style="font-size:30px;">${opts.icon || '🎴'}</span>`;
    }
    if (badge) {
        badge.style.color = accentColor;
        badge.style.borderColor = accentColor;
        badge.style.background = isGold ? 'rgba(245,158,11,0.18)' : 'rgba(56,189,248,0.18)';
        badge.innerText = opts.badgeText || `ใช้ ${fullPriceText}`;
    }
    if (itemName) itemName.innerText = opts.title || 'แพ็คการ์ดสุ่มไอเทม';
    if (itemDesc) itemDesc.innerText = opts.subtitle || 'กรุณาตรวจสอบราคาและกดยืนยันเพื่อทำรายการ';

    if (priceBox) {
        priceBox.style.borderColor = accentColor;
        priceBox.style.background = isGold
            ? 'linear-gradient(135deg, rgba(217,119,6,0.22) 0%, rgba(15,23,42,0.92) 100%)'
            : 'linear-gradient(135deg, rgba(2,132,199,0.24) 0%, rgba(15,23,42,0.92) 100%)';
    }
    if (priceBig) {
        priceBig.style.color = isGold ? '#fde047' : '#38bdf8';
        priceBig.innerText = `ราคา ${fullPriceText}`;
    }

    if (balNow) {
        balNow.innerText = isThb
            ? `💎 ${userDia.toLocaleString()} เพชร | 💰 ${userGold.toLocaleString()} ทอง`
            : `${currIcon} ${currentBal.toLocaleString()} ${currUnit}`;
    }
    if (balAfter) {
        if (isThb) {
            balAfter.style.color = '#4ade80';
            balAfter.innerText = 'ชำระผ่าน QR พร้อมเพย์ / ช่องทางที่เลือก';
        } else if (isEnough) {
            balAfter.style.color = '#4ade80';
            balAfter.innerText = `${currIcon} ${afterBal.toLocaleString()} ${currUnit}`;
        } else {
            balAfter.style.color = '#f87171';
            balAfter.innerText = `⚠️ ${currUnit}ไม่เพียงพอ (ขาดอีก ${(price - currentBal).toLocaleString()} ${currUnit})`;
        }
    }

    if (okBtn) {
        const actionVerb = opts.confirmLabel || 'ยืนยันเปิดการ์ด';
        okBtn.innerText = `✅ ${actionVerb} (${currIcon} ${priceFormatted})`;
        okBtn.style.background = isGold
            ? 'linear-gradient(180deg, #fbbf24 0%, #d97706 100%)'
            : 'linear-gradient(180deg, #38bdf8 0%, #0284c7 100%)';
        okBtn.style.color = isGold ? '#0f172a' : '#ffffff';
        okBtn.style.borderColor = isGold ? '#fde68a' : '#bae6fd';
    }

    if (extraBtn) {
        if (opts.extraBtn && opts.extraBtn.label) {
            const exPrice = Math.max(0, Number(opts.extraBtn.price || 0));
            const exCanAfford = isThb ? true : (currentBal >= exPrice);
            extraBtn.style.display = 'block';
            extraBtn.innerText = `${opts.extraBtn.label} (${currIcon} ${exPrice.toLocaleString()})`;
            extraBtn.style.opacity = exCanAfford ? '1' : '0.6';
        } else {
            extraBtn.style.display = 'none';
        }
    }

    modal.style.display = 'flex';
};

window.closePurchaseConfirmModal = function (confirmed = false) {
    const modal = document.getElementById('modal-purchase-confirm');
    if (modal) modal.style.display = 'none';
    const cb = _pendingPurchaseConfirmCallback;
    const extraCb = window._pendingPurchaseExtraCallback;
    _pendingPurchaseConfirmCallback = null;
    window._pendingPurchaseExtraCallback = null;
    if (confirmed === 'extra' && typeof extraCb === 'function') {
        extraCb();
    } else if (confirmed && typeof cb === 'function') {
        cb();
    }
};

window.rollSeparatedEventGacha = async function (category = 'FRAME', count = 5, currency = 'DIAMOND', packTier = 'SPECIAL', displayCost = '', skipConfirm = false) {
    if (!window.apiClient) return;

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const costSingle = Number(ev.cost_diamond || 50);
    const currUpper = String(currency || 'DIAMOND').toUpperCase();
    const tierUpper = String(packTier || 'SPECIAL').toUpperCase();
    const isDice = String(category || 'FRAME').toUpperCase() === 'DICE';

    // คำนวณราคาจริง (กี่เพชร / กี่ทอง) เพื่อให้แสดงในป๊อปอัปยืนยันอย่างแม่นยำ 100%
    let numericPrice = 0;
    if (displayCost) {
        const parsed = parseInt(String(displayCost).replace(/[^0-9]/g, ''), 10);
        if (!isNaN(parsed) && parsed > 0) numericPrice = parsed;
    }
    if (!numericPrice) {
        if (currUpper === 'GOLD') {
            numericPrice = count === 5 ? 120000 : (30000 * count);
        } else if (tierUpper === 'PREMIUM') {
            numericPrice = count >= 10 ? Math.round(costSingle * 10 * 1.35) : Math.round(costSingle * 5 * 1.45);
        } else {
            numericPrice = count >= 5 ? Math.round(costSingle * count * 0.9) : (costSingle * count);
        }
    }

    // ชื่อแพ็คและรายละเอียดให้ตรงกับการ์ดที่กด
    let packTitle = '';
    let packDesc = '';
    let packIcon = isDice ? '🎲' : '👑';
    if (isDice) {
        if (currUpper === 'GOLD') {
            packTitle = `ชุดสุ่มเต๋าทั่วไป (+${count} ชิ้น)`;
            packDesc = `สุ่มวัตถุดิบเงาลูกเต๋าระดับ A ~ A+ จำนวน ${count} ชิ้น`;
        } else if (tierUpper === 'PREMIUM') {
            packTitle = `ชุดเต๋าพรีเมียม (+${count} ชิ้น)`;
            packDesc = `เรตอัปเงาเต๋า A+ / S & ลุ้นลูกเต๋า 3D แรร์ จำนวน ${count} ชิ้น`;
            packIcon = count >= 10 ? '🔥' : '💎';
        } else {
            packTitle = `แพ็คลูกเต๋าพิเศษ (+${count} ชิ้น)`;
            packDesc = `สุ่มชิ้นส่วนเงาลูกเต๋า & ลุ้นลูกเต๋า 3D แรร์ จำนวน ${count} ชิ้น`;
        }
    } else {
        if (currUpper === 'GOLD') {
            packTitle = `ชุดการ์ดกรอบทั่วไป (+${count} ใบ)`;
            packDesc = `สุ่มวัตถุดิบการ์ดเงาระดับ A ~ A+ จำนวน ${count} ใบ`;
            packIcon = '🃏';
        } else if (tierUpper === 'PREMIUM') {
            packTitle = `ชุดกรอบพรีเมียม (+${count} ใบ)`;
            packDesc = `เรตอัปเงาฟ้า A+ / ทอง S & ลุ้นกรอบ SS+ จำนวน ${count} ใบ`;
            packIcon = count >= 10 ? '🌟' : '✨';
        } else {
            packTitle = `แพ็คการ์ดกรอบพิเศษ (+${count} ใบ)`;
            packDesc = `สุ่มการ์ดกรอบรูปพิเศษ & การ์ดเงา จำนวน ${count} ใบ`;
        }
    }

    if (!skipConfirm) {
        window.showPurchaseConfirmModal({
            headerIcon: currUpper === 'GOLD' ? '💰' : '💎',
            headerTitle: isDice ? 'ยืนยันราคาเปิดแพ็คลูกเต๋า 3D' : 'ยืนยันราคาเปิดแพ็คการ์ดกรอบรูป',
            icon: packIcon,
            badgeText: `เปิดแพ็ค ${count} ${isDice ? 'ชิ้น' : 'ใบ'}`,
            title: packTitle,
            subtitle: packDesc,
            currency: currUpper,
            price: numericPrice,
            confirmLabel: 'ยืนยันเปิดการ์ด'
        }, () => {
            window.closeGachaVideoPopup();
            window.rollSeparatedEventGacha(category, count, currency, packTier, displayCost, true);
        });
        return;
    }

    lastGachaPullMeta = {
        source: 'EVENT',
        category,
        count,
        currency,
        packTier,
        displayCost: displayCost || (currUpper === 'GOLD' ? `💰 ${numericPrice.toLocaleString()}` : `💎 ${numericPrice.toLocaleString()}`)
    };

    try {
        const res = await apiClient.rollEventGacha(count, category, currency, packTier);
        if (res && res.status === 'success') {
            if (res.user) {
                DEFAULT_USER.diamond = Number(res.user.diamond ?? DEFAULT_USER.diamond ?? 0);
                DEFAULT_USER.gold = Number(res.user.gold ?? DEFAULT_USER.gold ?? 0);
                updateUserBar(DEFAULT_USER);
            } else {
                apiClient.getProfile().then(prof => {
                    if (prof && prof.data) {
                        Object.assign(DEFAULT_USER, prof.data);
                        updateUserBar(DEFAULT_USER);
                    }
                }).catch(() => { });
            }

            if (res.event) {
                currentEventGachaData = res.event;
                renderSeparatedEventGachaUIs(res.event);
            } else {
                loadEventGachaData();
            }

            const actualCostLabel = (res.currency === 'GOLD')
                ? `💰 ${Number(res.cost_spent || res.gold_spent || numericPrice).toLocaleString()}`
                : `💎 ${Number(res.cost_spent || res.diamonds_spent || numericPrice).toLocaleString()}`;
            lastGachaPullMeta.displayCost = actualCostLabel;

            window.openVideoStyleGachaPopup(res.drops || [], category, res.total_cards || count, actualCostLabel);
        } else {
            showInGameAlert((res && res.message) ? res.message : 'ทรัพยากรไม่เพียงพอสำหรับการสุ่ม', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'กรุณาเข้าสู่ระบบหรือตรวจสอบเพชร/ทองก่อนทำการสุ่ม', 'แจ้งเตือนการสุ่ม', '⚠️');
    }
};

window.rollEventGachaAction = function (count = 1) {
    return window.rollSeparatedEventGacha('FRAME', count, 'DIAMOND', 'SPECIAL');
};

// =========================================================================
// 🎴 VIDEO-STYLE 2-STAGE PACK TEAR & HORIZONTAL CARD REVEAL POPUP (00:02 - 00:15)
// =========================================================================
window.openVideoStyleGachaPopup = function (drops, category = 'FRAME', cardCount = 5, againCostLabel = '💎 225', opts = null) {
    const popup = document.getElementById('modal-gacha-pack-popup');
    const stagePack = document.getElementById('gacha-popup-stage-pack');
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const foilBox = document.getElementById('gacha-foil-pack-box');
    const foilInner = document.getElementById('gacha-foil-pack-inner');
    const foilCount = document.getElementById('gacha-foil-pack-count');
    const againCostEl = document.getElementById('gacha-popup-again-cost');
    const againBtnEl = document.getElementById('btn-gacha-popup-again');
    const inspectBar = document.getElementById('gacha-card-inspect-bar');

    if (!popup || !stagePack || !stageCards) return;

    if (againBtnEl) {
        againBtnEl.style.display = (opts && opts.hideAgainBtn) ? 'none' : '';
    }

    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    clearGachaCardRevealTimers();

    pendingGachaRevealDrops = Array.isArray(drops) ? drops : [];
    pendingGachaRevealCategory = (category === 'DICE') ? 'DICE' : ((category === 'GEM') ? 'GEM' : 'FRAME');
    isAllRevealedCardsFlipped = false;

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const isDice = pendingGachaRevealCategory === 'DICE';

    if (foilBox) {
        foilBox.classList.remove('tearing');
        foilBox.classList.toggle('dice-theme', isDice);
    }
    if (foilCount) {
        foilCount.innerText = String(pendingGachaRevealDrops.length || cardCount || 1);
    }
    if (againCostEl) {
        againCostEl.innerText = againCostLabel || lastGachaPullMeta.displayCost || '💎 225';
    }
    if (inspectBar) {
        inspectBar.style.display = 'none';
    }

    if (foilInner) {
        if (opts && opts.packTitle) {
            const pCol = opts.packColor || '#38bdf8';
            const pIcon = opts.packIcon || '⚡';
            const pBadge = opts.packBadge || 'SHOP PURCHASE';
            const pSub = opts.packSubtitle || 'แตะเพื่อเปิดการ์ดที่ซื้อ';
            foilInner.innerHTML = `<div style="font-size:11px; font-weight:900; color:${pCol}; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">${pBadge}</div><div style="font-size:14.5px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">${opts.packTitle}</div><div style="width:82px; height:82px; border-radius:18px; background:radial-gradient(circle, ${pCol}55, #0f172a); border:2.5px solid ${pCol}; display:flex; align-items:center; justify-content:center; font-size:44px; box-shadow:0 0 22px ${pCol}99;">${pIcon}</div><div style="font-size:10.5px; font-weight:800; color:#fde047; margin-top:8px; text-shadow:0 1px 3px #000;">${pSub}</div>`;
        } else if (pendingGachaRevealCategory === 'GEM') {
            foilInner.innerHTML = `<div style="font-size:11px; font-weight:900; color:#e9d5ff; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">GEM EVENT</div><div style="font-size:15px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">แพ็คอัญมณีมหาเวทย์</div><div style="width:82px; height:82px; border-radius:18px; background:radial-gradient(circle, rgba(168,85,247,0.55), #0f172a); border:2.5px solid #c084fc; display:flex; align-items:center; justify-content:center; font-size:44px; box-shadow:0 0 22px rgba(168,85,247,0.8);">💎</div><div style="font-size:10.5px; font-weight:800; color:#fde047; margin-top:8px; text-shadow:0 1px 3px #000;">สุ่มอัญมณี & เงาอัญมณี</div>`;
        } else if (isDice) {
            const dName = ev.target_dice?.name || 'ลูกเต๋า 3D พิเศษ';
            foilInner.innerHTML = `
                <div style="font-size:11px; font-weight:900; color:#bae6fd; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">3D DICE EVENT</div>
                <div style="font-size:15px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">แพ็คลูกเต๋าพิเศษ</div>
                <div style="width:82px; height:82px; border-radius:18px; background:radial-gradient(circle, rgba(0,229,255,0.45), #0f172a); border:2.5px solid #7dd3fc; display:flex; align-items:center; justify-content:center; font-size:44px; box-shadow:0 0 22px rgba(0,229,255,0.7);">🎲</div>
                <div style="font-size:10.5px; font-weight:800; color:#fde047; margin-top:8px; text-shadow:0 1px 3px #000;">${dName}</div>
            `;
        } else {
            const cName = ev.target_character?.name || 'ดาราจักรเนบิวลา SS+';
            const cImg = ev.target_character?.avatar_url || 'avatars/avatar_01.png';
            foilInner.innerHTML = `
                <div style="font-size:11px; font-weight:900; color:#fef08a; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">FRAME EVENT</div>
                <div style="font-size:15px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">แพ็คการ์ดพิเศษ</div>
                <div style="width:84px; height:84px; border-radius:50%; border:3px solid #fde047; overflow:hidden; box-shadow:0 0 22px rgba(255,215,0,0.75); background:#0f172a;">
                    <img src="${cImg}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src='avatars/avatar_01.png';">
                </div>
                <div style="font-size:10.5px; font-weight:800; color:#fef08a; margin-top:8px; text-shadow:0 1px 3px #000;">${cName}</div>
            `;
        }
    }

    stageCards.style.display = 'none';
    stagePack.style.display = 'flex';
    popup.style.display = 'flex';

    if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        try { window.soundEngine.playClick(); } catch (e) { }
    }

    const isFastOpen = typeof window.isGachaFastOpenEnabled === 'function' ? window.isGachaFastOpenEnabled() : true;
    const intervalSec = typeof window.getGachaRevealIntervalSec === 'function' ? window.getGachaRevealIntervalSec() : 0.10;

    // อัปเดตข้อความบนแพ็คการ์ดและปุ่มความเร็วทันที
    const promptEl = document.getElementById('gacha-tap-prompt') || document.querySelector('.gacha-tap-prompt');
    if (promptEl) {
        promptEl.innerHTML = isFastOpen
            ? `⚡ แตะแพ็คเพื่อเปิดด่วนทีละ ${pendingGachaRevealDrops.length || cardCount || 5} ใบ (${intervalSec.toFixed(2)} วิ)`
            : `แตะแพ็คการ์ดเพื่อเปิด`;
    }
    const stage1SpeedLabel = document.getElementById('gacha-stage1-speed-label');
    if (stage1SpeedLabel) {
        stage1SpeedLabel.innerText = `${intervalSec.toFixed(2)} วิ`;
    }
    const quickPillLabel = document.getElementById('gacha-quick-speed-pill-label');
    if (quickPillLabel) {
        quickPillLabel.innerText = `${intervalSec.toFixed(2)} วิ`;
    }

    // หากเปิดโหมด Fast Open และผู้เล่นไม่แตะใน 550ms จะฉีกซองให้อัตโนมัติ (หรือแตะเปิดด่วนทันที)
    const autoTearDelay = isFastOpen ? 550 : 1350;
    gachaPackAutoTearTimeout = setTimeout(() => {
        if (stagePack.style.display !== 'none') {
            window.tearOpenGachaPackNow();
        }
    }, autoTearDelay);
};

window.tearOpenGachaPackNow = function () {
    const stagePack = document.getElementById('gacha-popup-stage-pack');
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const foilBox = document.getElementById('gacha-foil-pack-box');
    const flashEl = document.getElementById('gacha-tear-flash');
    if (!stagePack || !stageCards) return;

    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    if (foilBox && foilBox.classList.contains('tearing')) return;
    if (foilBox) foilBox.classList.add('tearing');

    const isFastOpen = typeof window.isGachaFastOpenEnabled === 'function' ? window.isGachaFastOpenEnabled() : true;
    const tearDuration = isFastOpen ? 80 : 220;

    if (flashEl) {
        flashEl.classList.add('active');
        setTimeout(() => flashEl.classList.remove('active'), isFastOpen ? 160 : 320);
    }
    if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        try { window.soundEngine.playClick(); } catch (e) { }
    }

    setTimeout(() => {
        stagePack.style.display = 'none';
        try {
            renderRevealedCardsStage();
        } catch (err) {
            console.error('renderRevealedCardsStage error:', err);
            window.closeGachaVideoPopup();
            if (typeof showToast === 'function') showToast('⚠️ แสดงผลการสุ่มไม่สำเร็จ แต่ไอเทมถูกเพิ่มในคลังแล้ว');
            return;
        }
        stageCards.style.display = 'flex';
    }, tearDuration);
};

function buildOrnateCardBackEmblemSvg(rarityRaw, cardIsDice, isGrandAura, accentHex) {
    const primaryGold = isGrandAura ? '#fde047' : (rarityRaw === 'S' ? '#fbbf24' : (rarityRaw === 'A+' ? '#38bdf8' : '#fcd34d'));
    const secondaryGlow = isGrandAura ? '#f43f5e' : (cardIsDice ? '#00e5ff' : (accentHex || '#f59e0b'));
    const coreIcon = cardIsDice ? '🎲' : (isGrandAura ? '👑' : (rarityRaw === 'S' ? '🌟' : '⚜️'));

    return `
        <div class="lgr-back-emblem-wrap" style="position:relative; width:64px; height:64px; margin:2px auto; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
            <svg viewBox="0 0 100 100" style="position:absolute; inset:0; width:100%; height:100%; overflow:visible; filter:drop-shadow(0 0 8px ${secondaryGlow});">
                <defs>
                    <radialGradient id="backCoreGrad_${rarityRaw}_${cardIsDice ? 'D' : 'F'}" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.95"/>
                        <stop offset="40%" stop-color="${primaryGold}" stop-opacity="0.85"/>
                        <stop offset="78%" stop-color="${secondaryGlow}" stop-opacity="0.65"/>
                        <stop offset="100%" stop-color="#0f172a" stop-opacity="0"/>
                    </radialGradient>
                </defs>
                <!-- Outer Sacred Sunburst Ring -->
                <circle cx="50" cy="50" r="44" fill="url(#backCoreGrad_${rarityRaw}_${cardIsDice ? 'D' : 'F'})" stroke="${primaryGold}" stroke-width="2" stroke-dasharray="5 3" opacity="0.9"/>
                <!-- Ornate Octagram Star Frame -->
                <polygon points="50,6 61,35 92,35 67,54 76,85 50,67 24,85 33,54 8,35 39,35" fill="none" stroke="${primaryGold}" stroke-width="1.6" opacity="0.65"/>
                <polygon points="50,14 75,25 86,50 75,75 50,86 25,75 14,50 25,25" fill="rgba(15,23,42,0.72)" stroke="${primaryGold}" stroke-width="2.2"/>
                <!-- Inner Filigree Ring -->
                <circle cx="50" cy="50" r="24" fill="radial-gradient(circle, ${secondaryGlow}, #090d16)" stroke="#ffffff" stroke-width="1.2" opacity="0.9"/>
                <!-- Corner Gems -->
                <circle cx="50" cy="10" r="3" fill="${primaryGold}"/>
                <circle cx="50" cy="90" r="3" fill="${primaryGold}"/>
                <circle cx="10" cy="50" r="3" fill="${primaryGold}"/>
                <circle cx="90" cy="50" r="3" fill="${primaryGold}"/>
            </svg>
            <div style="position:relative; z-index:2; font-size:26px; line-height:1; filter:drop-shadow(0 2px 6px rgba(0,0,0,0.9)) drop-shadow(0 0 10px ${primaryGold});">
                ${coreIcon}
            </div>
        </div>
    `;
}

function renderRevealedCardsStage() {
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const ribbonEl = document.getElementById('gacha-popup-ribbon-title');
    const rowEl = document.getElementById('gacha-popup-cards-row');
    const flipLabel = document.getElementById('gacha-popup-flip-label');
    if (!rowEl) return;

    // Enforce responsive container constraints & top/bottom close buttons via JS as well for 100% cache-proof display
    if (stageCards) {
        stageCards.style.maxWidth = 'min(100vw, 1060px)';
        stageCards.style.width = '100%';
        stageCards.style.minWidth = '0';
        stageCards.style.margin = '0 auto';
        stageCards.style.boxSizing = 'border-box';
        stageCards.style.overflow = 'hidden';

        // Ensure top-right close button inside stageCards exists and is accessible
        if (!stageCards.querySelector('.gacha-stage-close-x')) {
            const topClose = document.createElement('button');
            topClose.type = 'button';
            topClose.className = 'gacha-stage-close-x';
            topClose.setAttribute('aria-label', 'ปิด');
            topClose.onclick = () => window.closeGachaVideoPopup();
            topClose.innerHTML = '&times;';
            stageCards.appendChild(topClose);
        }

        const bottomBar = stageCards.querySelector('.gacha-stage-bottom-bar');
        if (bottomBar && !bottomBar.querySelector('.close-pack')) {
            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.className = 'gacha-act-btn close-pack';
            closeBtn.onclick = () => window.closeGachaVideoPopup();
            closeBtn.style.cssText = 'padding:9px 18px; border-radius:12px; font-weight:900; font-size:clamp(12px, 1.4vw, 14.5px); background:linear-gradient(180deg, #ef4444 0%, #b91c1c 100%); border:2px solid #fde047; color:#fff; display:inline-flex; align-items:center; gap:6px; cursor:pointer; touch-action:manipulation; pointer-events:auto;';
            closeBtn.innerHTML = `<span class="gacha-act-icon">✕</span><span>ปิด</span>`;
            bottomBar.appendChild(closeBtn);
        }
    }

    const isDice = pendingGachaRevealCategory === 'DICE';
    const isGem = pendingGachaRevealCategory === 'GEM';
    if (ribbonEl) {
        ribbonEl.innerText = isDice ? 'การ์ดลูกเต๋า 3D' : (isGem ? 'อัญมณีมหาเวทย์ & เงาอัญมณี' : 'การ์ดกรอบรูป');
        ribbonEl.classList.toggle('dice-ribbon', isDice);
    }
    if (flipLabel) {
        flipLabel.innerText = 'ดูด้านหลัง';
    }

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const uMats = ev.user_materials || {};
    const drops = pendingGachaRevealDrops;
    const isCount10 = drops.length > 5;
    rowEl.classList.toggle('count-10', isCount10);
    rowEl.style.width = '100%';
    rowEl.style.maxWidth = isCount10 ? '840px' : '920px';
    rowEl.style.minWidth = '0';
    rowEl.style.boxSizing = 'border-box';

    clearGachaCardRevealTimers();
    window.isGachaRevealFinished = false;

    // ระยะเวลาห่างกันต่อใบ (เช่น 0.10 วิ หรือตามที่ตั้งค่าไว้ในหน้าตั้งค่าเกมส์)
    const intervalSec = (typeof window.getGachaRevealIntervalSec === 'function')
        ? window.getGachaRevealIntervalSec()
        : ((window.ThaiAudio && typeof window.ThaiAudio.getCardRevealIntervalSec === 'function')
            ? window.ThaiAudio.getCardRevealIntervalSec()
            : 0.10);
    const intervalMs = Math.round(intervalSec * 1000);

    const cardRareFlags = [];

    rowEl.innerHTML = drops.map((d, idx) => {
        const rarityRaw = String(d.rarity || 'A').toUpperCase();
        const gradeClass = rarityRaw === 'SS+' ? 'grade-SSPLUS'
            : (rarityRaw === 'S+' ? 'grade-SPLUS'
                : (rarityRaw === 'S' ? 'grade-S'
                    : (rarityRaw === 'A+' ? 'grade-APLUS' : 'grade-A')));

        const cardIsDice = isDice || d.type === 'DICE' || d.category === 'DICE';
        const isJackpot = d.type === 'CHARACTER' || d.type === 'DICE';
        const isSpecialAwakenCard = (d.material_code === 'SPECIAL_CARD' || d.material_code === 'SPECIAL_DICE_CARD' || d.material_code === 'SPECIAL_GEM_CARD');
        const isEventFeatured = isJackpot
            || rarityRaw === 'SS+'
            || rarityRaw === 'S+'
            || isSpecialAwakenCard
            || String(d.name || '').includes('ปลุกพลังพิเศษ');
        const isSubtleSAura = (!isEventFeatured && rarityRaw === 'S');

        cardRareFlags[idx] = Boolean(isEventFeatured || isSubtleSAura);

        const auraSlotClass = isEventFeatured
            ? 'card-aura-ssplus'
            : (isSubtleSAura ? 'card-aura-s' : '');

        const ownedQty = (d.owned_shadow_count !== undefined)
            ? Number(d.owned_shadow_count)
            : (d.material_code && window._gemGachaEventData && window._gemGachaEventData.user_shadows && window._gemGachaEventData.user_shadows[d.material_code] !== undefined)
                ? Number(window._gemGachaEventData.user_shadows[d.material_code])
                : (d.material_code ? Number(uMats[d.material_code] || 0) : 1);
        const accentHex = d.color || (rarityRaw === 'SS+' || rarityRaw === 'S' ? '#ffd700' : (cardIsDice ? '#00e5ff' : '#4ade80'));

        // Front Center Artwork (No transform/filter bleed-through onto back face!)
        let centerArtHtml = '';
        if (isGem || d.category === 'GEM' || d.type === 'GEM_ITEM' || d.type === 'SHADOW_GEM') {
            const sColor = d.color || '#a855f7';
            const sGrade = d.grade || rarityRaw || 'A';
            const sShape = (d.shape || 'pentagon').toLowerCase();
            
            // Helper to build 3D Crystal Gem SVG or fallback
            let gemSvgHtml = '';
            if (typeof window.generateGemSvgPreview === 'function') {
                gemSvgHtml = window.generateGemSvgPreview(sShape, sGrade, 54, sColor);
            } else {
                let pts = "50,10 88,38 74,86 26,86 12,38";
                if (sShape === 'square') pts = "50,10 90,50 50,90 10,50";
                else if (sShape === 'triangle') pts = "50,12 88,80 12,80";
                gemSvgHtml = `<svg viewBox="0 0 100 100" width="54" height="54" style="filter:drop-shadow(0 0 10px ${sColor});">
                    <polygon points="${pts}" fill="${sColor}" stroke="#fff" stroke-width="2" opacity="0.85"/>
                </svg>`;
            }

            if (d.type === 'GEM_ITEM') {
                centerArtHtml = `
                    <div style="position:relative; width:68px; height:68px; border-radius:18px; display:flex; align-items:center; justify-content:center; background:radial-gradient(circle, ${sColor}55 0%, #0f172a 85%); border:2.5px solid ${sColor}; box-shadow:0 0 20px ${sColor}99;">
                        ${gemSvgHtml}
                        <div class="grade-emblem" style="--gc:${sColor}; font-size:26px; z-index:5; position:absolute;">
                            <span class="ge-txt">${sGrade}</span>
                        </div>
                    </div>
                `;
            } else {
                centerArtHtml = `
                    <div style="position:relative; width:66px; height:66px; border-radius:16px; display:flex; align-items:center; justify-content:center; background:radial-gradient(circle at 50% 50%, ${sColor}44 0%, #050811 85%); border:2px solid ${sColor}; box-shadow:0 0 16px ${sColor}88;">
                        <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; opacity:0.65;">
                            ${gemSvgHtml}
                        </div>
                        <div class="grade-emblem" style="--gc:${sColor}; font-size:${sGrade === 'A+' ? '28px' : (sGrade === 'A' ? '30px' : '26px')}; z-index:5; position:absolute;">
                            <span class="ge-txt">${sGrade}</span>
                        </div>
                    </div>
                `;
            }
        } else if (cardIsDice) {
            const diceTint = d.color || accentHex || '#00e5ff';
            if (isJackpot) {
                if (d.image_url) {
                    centerArtHtml = `<img src="${d.image_url}" style="width:66px; height:66px; object-fit:contain; position:relative;" onerror="this.outerHTML='<div style=\\'font-size:46px;position:relative;\\'>🎲</div>';">`;
                } else {
                    centerArtHtml = `
                        <div style="width:64px; height:64px; border-radius:16px; background:radial-gradient(circle at 30% 30%, #fff, ${diceTint} 65%, #0f172a 100%); border:2.5px solid #fff; box-shadow:0 6px 16px rgba(0,0,0,0.55), 0 0 16px ${diceTint}; display:flex; align-items:center; justify-content:center; font-size:34px; position:relative;">
                            🎲
                        </div>
                    `;
                }
            } else {
                // Dice Shadow Material Card (สไตล์รูป 4)
                centerArtHtml = `
                    <div style="position:relative; width:66px; height:66px; border-radius:16px; display:flex; align-items:center; justify-content:center; background:radial-gradient(circle at 50% 50%, ${diceTint}44 0%, #050811 85%); border:2px solid ${diceTint}; box-shadow:0 0 16px ${diceTint}88;">
                        <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; opacity:0.4; font-size:28px;">
                            🎲
                        </div>
                        <div class="grade-emblem" style="--gc:${diceTint}; font-size:${rarityRaw === 'A+' ? '28px' : (rarityRaw === 'A' ? '30px' : '26px')}; z-index:5; position:absolute;">
                            <span class="ge-txt">${rarityRaw}</span>
                        </div>
                    </div>
                `;
            }
        } else if (d.image_url || (d.material_code && d.material_code.startsWith('SHADOW_')) || d.type === 'SHADOW_MATERIAL' || d.material_code === 'SPECIAL_CARD' || d.material_code === 'SPECIAL_DICE_CARD' || d.material_code === 'SPECIAL_GEM_CARD') {
            const frameTint = d.color || accentHex || '#ffd700';
            if (isJackpot) {
                const ringUrl = d.image_url || '';
                const ringIcon = rarityRaw === 'SS+' || rarityRaw === 'S+' ? '👑' : (rarityRaw === 'S' ? '🌟' : '⚜️');
                centerArtHtml = `
                    <div style="width:66px; height:66px; border-radius:50%; position:relative; display:inline-flex; align-items:center; justify-content:center; background:radial-gradient(circle, ${frameTint}44 0%, #1e293b 65%, #090d16 100%); border:2.5px solid ${frameTint}; box-shadow:0 0 16px ${frameTint}aa, inset 0 0 12px ${frameTint}66;">
                        ${ringUrl ? `<img src="${ringUrl}" style="position:absolute; inset:-6%; width:112%; height:112%; object-fit:contain; pointer-events:none;" alt="">` : ''}
                        <span style="font-size:24px; line-height:1; filter:drop-shadow(0 2px 4px rgba(0,0,0,0.85));">${ringIcon}</span>
                    </div>
                `;
            } else {
                // Frame Shadow Material Card (สไตล์รูป 4)
                centerArtHtml = `
                    <div style="position:relative; width:66px; height:66px; border-radius:16px; display:flex; align-items:center; justify-content:center; background:radial-gradient(circle at 50% 50%, ${frameTint}44 0%, #050811 85%); border:2px solid ${frameTint}; box-shadow:0 0 16px ${frameTint}88;">
                        <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; opacity:0.35; font-size:26px;">
                            👑
                        </div>
                        <div class="grade-emblem" style="--gc:${frameTint}; font-size:${rarityRaw === 'A+' ? '28px' : (rarityRaw === 'A' ? '30px' : '26px')}; z-index:5; position:absolute;">
                            <span class="ge-txt">${rarityRaw}</span>
                        </div>
                    </div>
                `;
            }
        } else {
            centerArtHtml = `<div style="font-size:44px; position:relative; text-shadow:0 4px 12px rgba(0,0,0,0.75);">${d.icon || '👑'}</div>`;
        }

        // Aura Visual Layers (S = subtle golden aura | SS+ / Event = spectacular radiant god-ray + plasma + star particles aura)
        let auraOverlayHtml = '';
        if (isEventFeatured) {
            const badgeText = (rarityRaw === 'SS+' || isJackpot) ? `👑 GRAND ${rarityRaw}` : `🌟 EVENT SPECIAL`;
            auraOverlayHtml = `
                <div class="lgr-aura-fx-container ssplus-event-aura" aria-hidden="true">
                    <div class="lgr-aura-godrays"></div>
                    <div class="lgr-aura-plasma-ring"></div>
                    <div class="lgr-aura-sparkles">
                        <span class="sp-1">✦</span>
                        <span class="sp-2">★</span>
                        <span class="sp-3">✨</span>
                        <span class="sp-4">✦</span>
                    </div>
                </div>
                <div class="lgr-card-floating-aura-badge ssplus-badge">${badgeText}</div>
            `;
        } else if (isSubtleSAura) {
            auraOverlayHtml = `
                <div class="lgr-aura-fx-container s-subtle-aura" aria-hidden="true">
                    <div class="lgr-aura-soft-halo"></div>
                    <div class="lgr-aura-sparkles">
                        <span class="sp-1">✦</span>
                        <span class="sp-3">✨</span>
                    </div>
                </div>
                <div class="lgr-card-floating-aura-badge s-badge">✨ RARE S</div>
            `;
        }

        const isShadowCard = Boolean(
            (d.material_code && String(d.material_code).startsWith('SHADOW_')) ||
            String(d.name || '').includes('เงา') ||
            (d.material_code && !isJackpot)
        );

        // คำนวณจำนวนที่ต้องใช้สะสมตามประเภทอีเวนต์ (Frame: 25/25/20/15/8 | Dice: 15/15/15/10/4 | Gem: d.req_count หรือ 15/15/15/10/4)
        let reqQty = 0;
        if (d.req_count) {
            reqQty = Number(d.req_count);
        } else if (d.material_code) {
            const mCode = String(d.material_code).toUpperCase();
            if (mCode.startsWith('SHADOW_GEM_')) {
                const sIdx = parseInt(mCode.replace('SHADOW_GEM_', ''), 10) - 1;
                const gemDefReqs = [15, 15, 15, 10, 4];
                reqQty = gemDefReqs[sIdx] || 10;
            } else {
                const reqMap = cardIsDice
                    ? (ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {})
                    : (ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {});
                const defReqs = cardIsDice
                    ? { black: 15, red: 15, orange: 15, blue: 10, gold: 4 }
                    : { black: 25, red: 25, orange: 20, blue: 15, gold: 8 };

                if (mCode.includes('BLACK')) reqQty = parseInt(reqMap.black ?? defReqs.black, 10) || defReqs.black;
                else if (mCode.includes('RED')) reqQty = parseInt(reqMap.red ?? defReqs.red, 10) || defReqs.red;
                else if (mCode.includes('ORANGE')) reqQty = parseInt(reqMap.orange ?? defReqs.orange, 10) || defReqs.orange;
                else if (mCode.includes('BLUE')) reqQty = parseInt(reqMap.blue ?? defReqs.blue, 10) || defReqs.blue;
                else if (mCode.includes('GOLD')) reqQty = parseInt(reqMap.gold ?? defReqs.gold, 10) || defReqs.gold;
            }
        }

        const isComplete = (reqQty > 0 && ownedQty >= reqQty);

        let cornerBadgeHtml = '';
        if (isShadowCard) {
            if (reqQty > 0) {
                if (isComplete) {
                    cornerBadgeHtml = `<span class="lgr-card-corner-badge is-complete" title="สะสม ${ownedQty}/${reqQty} (ครบตามเงื่อนไขแล้ว)"><span class="badge-lbl">สะสม:</span><b class="badge-num">${ownedQty}/${reqQty}</b><span class="badge-complete-tag">ครบแล้ว</span></span>`;
                } else {
                    cornerBadgeHtml = `<span class="lgr-card-corner-badge" title="สะสม ${ownedQty}/${reqQty}"><span class="badge-lbl">สะสม:</span><b class="badge-num">${ownedQty}/${reqQty}</b></span>`;
                }
            } else if (d.material_code === 'SPECIAL_CARD' || d.material_code === 'SPECIAL_DICE_CARD' || d.material_code === 'SPECIAL_GEM_CARD') {
                cornerBadgeHtml = `<span class="lgr-card-corner-badge" title="การ์ดปลุกพลังพิเศษ ใช้สำหรับอัปเกรดจาก Lv.29 ➔ Lv.30 MAX"><span class="badge-lbl">มีในคลัง:</span><b class="badge-num">${ownedQty.toLocaleString()}</b></span>`;
            } else {
                cornerBadgeHtml = `<span class="lgr-card-corner-badge" title="จำนวนสะสมในคลัง"><span class="badge-lbl">สะสม:</span><b class="badge-num">${ownedQty.toLocaleString()}</b></span>`;
            }
        }

        const shortTopName = String(d.name || '').replace(/^การ์ด/, '').replace(/^เงา/, 'เงา');
        const subTag = (isJackpot || d.type === 'GEM_ITEM')
            ? (cardIsDice ? '🎲 [ลูกเต๋า 3D ประจำกิจกรรม]' : ((isGem || d.type === 'GEM_ITEM') ? '💎 [อัญมณีแท้ประจำกิจกรรม]' : '👑 [กรอบรูปประจำกิจกรรม]'))
            : ((d.material_code === 'SPECIAL_CARD' || d.material_code === 'SPECIAL_DICE_CARD' || d.material_code === 'SPECIAL_GEM_CARD')
                ? '⚡ [การ์ดปลุกพลัง] ใช้อัปเกรด Lv.29 ➔ 30 MAX'
                : (isEventFeatured ? '🌟 [การ์ดจัดกิจกรรมพิเศษ]' : ((isGem || d.category === 'GEM') ? `[เงาอัญมณี] วัตถุดิบแลก ${d.target_gem_name || 'อัญมณีแท้'}` : '[อีเวนต์พิเศษ] วัตถุดิบแลก')));

        const backEmblemHtml = buildOrnateCardBackEmblemSvg(rarityRaw, cardIsDice, isEventFeatured, accentHex);
        const backOwnedBadge = isJackpot || d.type === 'GEM_ITEM'
            ? `<div class="lgr-back-pill jackpot-pill">🎉 อัญมณีแท้พร้อมสวมใส่!</div>`
            : `<div class="lgr-back-pill">📦 สะสมในคลัง: <strong>${ownedQty.toLocaleString()}${reqQty > 0 ? '/' + reqQty : ''}</strong> ชิ้น${isComplete ? ' <span style="color:#10b981; font-weight:800; font-size:11px;">(ครบแล้ว)</span>' : ''}</div>`;
        const backUsageText = (isGem || d.category === 'GEM' || d.type === 'GEM_ITEM' || d.type === 'SHADOW_GEM')
            ? (d.type === 'GEM_ITEM' ? `อัญมณีแท้ [${d.name}] เกรด ${rarityRaw} พร้อมสวมใส่ในช่องอัญมณีทันที!` : `สะสมการ์ดเงาครบ 5 ชนิด เพื่อแลกรับ [${d.target_gem_name || 'อัญมณีประจำกิจกรรม'}] ฟรี!`)
            : (isJackpot
                ? (cardIsDice ? 'ลูกเต๋า 3D แรร์ประจำกิจกรรม เพิ่มความแม่นยำทอยเต๋าสูงสุด' : 'กรอบรูปตัวละครแรร์ประจำกิจกรรม พร้อมออร่าและสกิลพิเศษ')
                : (d.material_code === 'SPECIAL_CARD'
                    ? 'การ์ดปลุกพลังกิจกรรม ใช้ปลุกพลังLv.30 หรือแลกรางวัลพิเศษ'
                    : `สะสมการ์ดเงาครบ 5 สี เพื่อแลก${cardIsDice ? 'ลูกเต๋า 3D SS+' : 'กรอบรูป SS+'} ฟรี!`));

        const slotInlineWidth = isCount10
            ? 'width:100%; max-width:142px; min-width:0;'
            : 'flex:0 1 158px; width:calc((100% - 48px) / 5); max-width:158px; min-width:0;';

        return `
            <div id="gacha-reveal-slot-${idx}" class="gacha-lgr-card-slot card-awaiting-reveal ${auraSlotClass}" style="animation-delay:${(idx * intervalSec).toFixed(2)}s; ${slotInlineWidth}" onclick="inspectOrFlipSingleCard(this, ${idx})">
                ${auraOverlayHtml}
                <div class="gacha-lgr-card-inner">
                    <!-- FRONT FACE (ดูด้านหน้า) -->
                    <div class="gacha-lgr-card-face gacha-lgr-card-front ${gradeClass}">
                        ${(isEventFeatured || isSubtleSAura) ? '<div class="lgr-card-holo-sweep"></div>' : ''}
                        <div class="lgr-card-top-bar">
                            <div class="lgr-card-top-title-wrap">
                                <span class="lgr-card-grade-letter">${rarityRaw}</span>
                                <span class="lgr-card-top-name">${shortTopName}</span>
                            </div>
                            ${cornerBadgeHtml}
                        </div>
                        <div class="lgr-card-art-area">
                            <div class="lgr-card-art-glow"></div>
                            ${centerArtHtml}
                        </div>
                        <div class="lgr-card-bottom-tag ${cardIsDice ? 'dice-tag' : ''}">
                            <div class="lgr-card-tag-sub">${subTag}</div>
                            <div class="lgr-card-tag-main">${d.name || 'การ์ดอีเวนต์'}</div>
                        </div>
                    </div>

                    <!-- BACK FACE (ดูด้านหลัง - ภาพด้านหลังสวยเด่น ไม่มีวงกลมดำทับข้อความ) -->
                    <div class="gacha-lgr-card-face gacha-lgr-card-back ${gradeClass}">
                        <div class="lgr-back-top-header">
                            <div style="display:inline-flex; align-items:center; gap:3px; min-width:0;">
                                <span class="lgr-back-grade-chip">GRADE ${rarityRaw}</span>
                                <span class="lgr-back-type-chip">${cardIsDice ? '🎲 3D DICE' : ((isGem || d.category === 'GEM') ? '💎 GEM' : '👑 FRAME')}</span>
                            </div>
                            ${cornerBadgeHtml}
                        </div>

                        ${backEmblemHtml}

                        <div class="lgr-back-info-panel">
                            <div class="lgr-back-card-title">${d.name || 'การ์ดอีเวนต์พิเศษ'}</div>
                            ${backOwnedBadge}
                            <div class="lgr-back-card-desc">${backUsageText}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    // เปิดการ์ดทีละ 1 ใบ ห่างกันใบละ intervalSec (เช่น 0.10 วิ) พร้อมเล่นเสียง "แซ๊บ!" ต่อใบ
    drops.forEach((d, idx) => {
        const delayMs = idx * intervalMs;
        const tId = setTimeout(() => {
            const slotEl = document.getElementById(`gacha-reveal-slot-${idx}`);
            if (slotEl) {
                slotEl.classList.remove('card-awaiting-reveal');
                slotEl.classList.add('card-revealed-active', 'card-zap-burst');
                setTimeout(() => {
                    if (slotEl) slotEl.classList.remove('card-zap-burst');
                }, 380);
            }
            triggerSingleCardRevealSound(Boolean(cardRareFlags[idx]));
        }, delayMs);
        gachaCardRevealTimers.push(tId);
    });

    const completeCheckTimer = setTimeout(() => {
        window.isGachaRevealFinished = true;
        // ตรวจสอบว่าได้ของรางวัลใหญ่ประจำกิจกรรมโดยตรงหรือไม่ (Jackpot Direct Drop)
        const grandPrizeCard = drops.find(d => Boolean(d.is_grand_prize) || d.type === 'CHARACTER' || d.type === 'DICE' || d.type === 'GEM_ITEM');
        if (grandPrizeCard) {
            window.showGrandPrizeCelebrationModal(grandPrizeCard, pendingGachaRevealCategory);
        } else {
            if (!isGem) {
                window.checkAndShowShadowCompleteModal(isDice ? 'DICE' : 'FRAME');
            }
        }
    }, (drops.length * intervalMs) + 350);
    gachaCardRevealTimers.push(completeCheckTimer);
}

/**
 * ⚡ ฟังก์ชันแตะเปิดการ์ดทั้งหมดทันที (Skip Card Reveal Animation)
 */
window.skipCardRevealAnimationNow = function () {
    if (window.isGachaRevealFinished) return;
    window.isGachaRevealFinished = true;
    clearGachaCardRevealTimers();

    pendingGachaRevealDrops.forEach((d, idx) => {
        const slotEl = document.getElementById(`gacha-reveal-slot-${idx}`);
        if (slotEl) {
            slotEl.classList.remove('card-awaiting-reveal');
            slotEl.classList.add('card-revealed-active');
        }
    });

    if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        try { window.soundEngine.playClick(); } catch (e) { }
    }

    setTimeout(() => {
        const grandPrizeCard = pendingGachaRevealDrops.find(d => Boolean(d.is_grand_prize) || d.type === 'CHARACTER' || d.type === 'DICE' || d.type === 'GEM_ITEM');
        if (grandPrizeCard) {
            window.showGrandPrizeCelebrationModal(grandPrizeCard, pendingGachaRevealCategory);
        } else {
            if (pendingGachaRevealCategory !== 'GEM') {
                window.checkAndShowShadowCompleteModal(pendingGachaRevealCategory === 'DICE' ? 'DICE' : 'FRAME');
            }
        }
    }, 180);
};

window.syncCardFaceVisibility = function (slotEl) {
    if (!slotEl) return;
    const isFlipped = slotEl.classList.contains('is-flipped');
    const frontEl = slotEl.querySelector('.gacha-lgr-card-front');
    const backEl = slotEl.querySelector('.gacha-lgr-card-back');
    if (frontEl) {
        frontEl.style.visibility = isFlipped ? 'hidden' : 'visible';
        frontEl.style.opacity = isFlipped ? '0' : '1';
        frontEl.style.pointerEvents = isFlipped ? 'none' : 'auto';
    }
    if (backEl) {
        backEl.style.visibility = isFlipped ? 'visible' : 'hidden';
        backEl.style.opacity = isFlipped ? '1' : '0';
        backEl.style.pointerEvents = isFlipped ? 'auto' : 'none';
    }
};

window.inspectOrFlipSingleCard = function (slotEl, idx) {
    if (slotEl) {
        slotEl.classList.toggle('is-flipped');
        window.syncCardFaceVisibility(slotEl);
    }
    const inspectBar = document.getElementById('gacha-card-inspect-bar');
    if (inspectBar) {
        inspectBar.style.display = 'none';
        inspectBar.innerHTML = '';
    }
};

window.toggleFlipAllRevealedCards = function () {
    isAllRevealedCardsFlipped = !isAllRevealedCardsFlipped;
    document.querySelectorAll('#gacha-popup-cards-row .gacha-lgr-card-slot').forEach(el => {
        el.classList.toggle('is-flipped', isAllRevealedCardsFlipped);
        window.syncCardFaceVisibility(el);
    });
    const flipLabel = document.getElementById('gacha-popup-flip-label');
    if (flipLabel) {
        flipLabel.innerText = isAllRevealedCardsFlipped ? 'ดูด้านหน้า' : 'ดูด้านหลัง';
    }
};

window.closeGachaVideoPopup = function () {
    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    clearGachaCardRevealTimers();
    const popup = document.getElementById('modal-gacha-pack-popup');
    if (popup) popup.style.display = 'none';
    const sp = document.getElementById('gacha-popup-stage-pack'); if (sp) sp.style.display = 'flex';
    const sc = document.getElementById('gacha-popup-stage-cards'); if (sc) sc.style.display = 'none';
};

window.repeatLastGachaPullAction = function () {
    if (pendingGachaRevealCategory === 'GEM' && window.lastGachaPullMeta && window.lastGachaPullMeta.source === 'GEM' && typeof window.rollGemGacha === 'function') {
        const gm = window.lastGachaPullMeta;
        window.rollGemGacha(gm.count || 1, gm.currency || 'DIAMOND', gm.packTier || 'SPECIAL');
        return;
    }
    if (lastGachaPullMeta.source === 'GEM' && typeof window.rollGemGacha === 'function') {
        window.rollGemGacha(lastGachaPullMeta.count || 1, lastGachaPullMeta.currency || 'DIAMOND', lastGachaPullMeta.packTier || 'SPECIAL');
        return;
    }
    if (lastGachaPullMeta.source === 'SHOP' && typeof window.doGacha === 'function') {
        window.doGacha(lastGachaPullMeta.count || 1);
        return;
    }
    window.rollSeparatedEventGacha(
        lastGachaPullMeta.category || 'FRAME',
        lastGachaPullMeta.count || 5,
        lastGachaPullMeta.currency || 'DIAMOND',
        lastGachaPullMeta.packTier || 'SPECIAL',
        lastGachaPullMeta.displayCost || ''
    );
};

// Upgrade legacy Shop Gacha reveal to also use the Video-Style 2-Stage Pack Popup!
window.showGachaCardsRevealModal = function (drops, packCount, totalCards, spent) {
    const hasDiceOnly = Array.isArray(drops) && drops.length > 0 && drops.every(d => d.type === 'DICE' || d.category === 'DICE');
    lastGachaPullMeta = {
        source: 'SHOP',
        category: hasDiceOnly ? 'DICE' : 'FRAME',
        count: packCount || 1,
        currency: 'DIAMOND',
        packTier: 'SPECIAL',
        displayCost: `💎 ${Number(spent || 100).toLocaleString()}`
    };
    window.openVideoStyleGachaPopup(drops || [], hasDiceOnly ? 'DICE' : 'FRAME', totalCards || (drops ? drops.length : 5), `💎 ${Number(spent || 100).toLocaleString()}`);
};

// =========================================================================
// 🧊 MAGIC CUBE SPINNER CONTROLLER (หมุนลูกบาศก์นำโชค 3D สไตล์ Tycoon 3D)
// =========================================================================
let currentCubesData = { cubes: [], configs: [] };
let selectedCubeForSpin = null;
let magicCubeInterval = null;

window.resetMagicCubesData = function() {
    currentCubesData = { cubes: [], configs: [] };
    selectedCubeForSpin = null;
    if (magicCubeInterval) {
        clearInterval(magicCubeInterval);
        magicCubeInterval = null;
    }
    const badgeCube = document.getElementById('badge-cube-ready');
    if (badgeCube) badgeCube.style.display = 'none';
    const sub = document.getElementById('card-cube-sub');
    if (sub) sub.innerText = 'รับเพชร & ทอง';
    const tray = document.getElementById('user-cubes-slots-row');
    if (tray) tray.innerHTML = '';
    const slotsGrid = document.getElementById('magic-cube-slots-grid');
    if (slotsGrid) slotsGrid.innerHTML = '';
};

/**
 * สร้าง SVG 3D Isometric Magic Cube แบบสมจริง เรืองแสงออร่า โดดเด่นสวยงาม
 * รองรับชนิดลูกบาศก์ที่แตกต่างกันอย่างชัดเจน มีระบบดิ้นได้ (Wobble) และเอฟเฟกต์ออร่าเรืองแสง (Aura)
 */
/**
 * =========================================================================
 * 🧊 TRUE 3D RUBIK MAGIC CUBE (Tycoon 3D & GAN Speedcube 3x3 Style)
 * หมุนแบบ 3D แท้ตามคลิปเกมเศรษฐี 100% พร้อมชิ้นส่วนรูบิค 3x3 ครบ 6 ด้าน
 * =========================================================================
 */
window.getMagicCubeSvgHtml = function (cubeType, isSpinning = false, size = 88, hasAura = false, isWobble = false, extraOpts = {}) {
    const rawType = String(cubeType || 'SILVER').toUpperCase();

    // กำหนดสีออร่าตามประเภทลูกบาศก์
    let auraCol = '#ffd700';
    if (rawType.includes('GOLD') || rawType === 'GOLD') {
        auraCol = '#ffd700';
    } else if (rawType.includes('DIAMOND') || rawType === 'DIAMOND') {
        auraCol = '#00e5ff';
    } else if (rawType.includes('LEGEND') || rawType === 'LEGENDARY') {
        auraCol = '#ec4899';
    } else if (rawType.includes('ANCIENT')) {
        auraCol = '#10b981';
    } else {
        auraCol = '#38bdf8';
    }

    // สำหรับรายการที่สุ่มจากเพชร หรือสุ่มได้เวลาเต็ม MAX (hasAura): หมุนลูกบาศก์และเอฟเฟกต์เร็วกว่าเดิม (~1.75x)
    const isFastSpin = isSpinning && hasAura;
    const rotSpeed = isFastSpin ? '3.5s' : '7.5s';
    const counterSpeed = isFastSpin ? '4.8s' : '10s';
    const pulseSpeed = isFastSpin ? '1.2s' : '1.8s';

    // 🌟 แสงเออร่า / เอฟเฟกต์ (SVG วงแหวนเทค & รัศมีแสง 8 ทิศ + จุดประกาย เหมือนรูปที่ 1)
    const auraHtml = hasAura ? `
        <div class="cube-3d-aura-wrap" style="position:absolute; inset:-24px; pointer-events:none; display:flex; align-items:center; justify-content:center; z-index:0; overflow:visible;">
            <div style="position:absolute; width:${Math.round(size * 1.38)}px; height:${Math.round(size * 1.38)}px; border-radius:50%; background:radial-gradient(circle, ${auraCol}66 0%, ${auraCol}22 45%, transparent 72%); filter:blur(8px); animation:cubeAuraPulse ${pulseSpeed} ease-in-out infinite alternate;"></div>
            <svg viewBox="0 0 160 160" style="position:absolute; width:${Math.round(size * 1.55)}px; height:${Math.round(size * 1.55)}px; animation:cubeAuraRaysRotate ${rotSpeed} linear infinite; pointer-events:none; overflow:visible;">
                <line x1="80" y1="5" x2="80" y2="155" stroke="${auraCol}" stroke-width="2.5" stroke-linecap="round" opacity="0.9" filter="drop-shadow(0 0 6px ${auraCol})" />
                <line x1="5" y1="80" x2="155" y2="80" stroke="${auraCol}" stroke-width="2.5" stroke-linecap="round" opacity="0.9" filter="drop-shadow(0 0 6px ${auraCol})" />
                <line x1="26" y1="26" x2="134" y2="134" stroke="${auraCol}" stroke-width="2" stroke-linecap="round" opacity="0.8" />
                <line x1="134" y1="26" x2="26" y2="134" stroke="${auraCol}" stroke-width="2" stroke-linecap="round" opacity="0.8" />
                <circle cx="80" cy="80" r="58" fill="none" stroke="${auraCol}" stroke-width="2.2" stroke-dasharray="10 8" opacity="0.85" />
                <circle cx="80" cy="80" r="70" fill="none" stroke="${auraCol}" stroke-width="1.3" stroke-dasharray="4 6" opacity="0.6" />
                <circle cx="80" cy="8" r="2.2" fill="#fff" filter="drop-shadow(0 0 4px ${auraCol})" />
                <circle cx="80" cy="152" r="2.2" fill="#fff" filter="drop-shadow(0 0 4px ${auraCol})" />
                <circle cx="8" cy="80" r="2.2" fill="#fff" filter="drop-shadow(0 0 4px ${auraCol})" />
                <circle cx="152" cy="80" r="2.2" fill="#fff" filter="drop-shadow(0 0 4px ${auraCol})" />
                <circle cx="28" cy="28" r="1.8" fill="#fff" />
                <circle cx="132" cy="132" r="1.8" fill="#fff" />
                <circle cx="132" cy="28" r="1.8" fill="#fff" />
                <circle cx="28" cy="132" r="1.8" fill="#fff" />
            </svg>
            <svg viewBox="0 0 160 160" style="position:absolute; width:${Math.round(size * 1.68)}px; height:${Math.round(size * 1.68)}px; animation:cubeAuraRaysRotateCounter ${counterSpeed} linear infinite; pointer-events:none; overflow:visible;">
                <circle cx="80" cy="80" r="75" fill="none" stroke="${auraCol}" stroke-width="1.2" stroke-dasharray="3 9" opacity="0.45" />
            </svg>
        </div>
    ` : '';

    // 🧊 True Three.js WebGL 3D Rubik Speedcube (เฉพาะ 4 ช่องหลัก ไม่สร้าง WebGL สำหรับไอคอนเล็กในถาดเพื่อป้องกัน WebGL Context เต็ม)
    if (!isWobble && size >= 56 && window.THREE && typeof window.mountMagicCube3D === 'function') {
        const canvasId = `mc_canvas_${Math.random().toString(36).substr(2, 9)}`;
        const aType = extraOpts.auraType || 'neon_pulse';
        const pFx = extraOpts.particleFx || 'flare_burst';
        const intVal = extraOpts.intensity || '2x';

        requestAnimationFrame(() => {
            const el = document.getElementById(canvasId);
            if (el && el.offsetParent !== null) {
                window.mountMagicCube3D(el, {
                    cubeType: rawType,
                    isSpinning: isSpinning,
                    hasAura: hasAura,
                    auraType: aType,
                    particleFx: pFx,
                    intensity: intVal,
                    width: size,
                    height: size
                });
            }
        });

        return `
            <div class="cube-3d-scene ${hasAura ? 'has-cube-aura' : ''}" style="width:${size}px; height:${size}px; margin:0 auto; flex-shrink:0; position:relative; display:flex; align-items:center; justify-content:center; overflow:visible;">
                ${auraHtml}
                <canvas id="${canvasId}" class="magic-cube-3d-canvas" data-type="${rawType}" data-spinning="${isSpinning}" data-aura="${hasAura}" data-aura-type="${aType}" data-particle-fx="${pFx}" data-intensity="${intVal}" data-size="${size}" width="${size}" height="${size}" style="width:${size}px; height:${size}px; display:block; margin:0 auto; pointer-events:none; position:relative; z-index:2;"></canvas>
            </div>
        `;
    }

    const cubeDim = Math.max(30, Math.round(size * 0.62));
    const half = Math.round(cubeDim / 2);
    const gap = Math.max(1, Math.round(cubeDim * 0.035));
    const pad = Math.max(1.5, Math.round(cubeDim * 0.045));
    const tileRadius = Math.max(2, Math.round(cubeDim * 0.065));
    const cornerRadius = Math.max(3, Math.round(cubeDim * 0.08));

    let colors = {};
    let seamCol = '#1a1005';
    let emblem = { text: '👑', bg: '#fffbeb', color: '#b45309', border: '#f59e0b' };

    if (rawType.includes('GOLD') || rawType === 'GOLD') {
        // 👑 GOLD CUBE (เหมือนคลิปเกมเศรษฐี 100%): ทองคำเงาวับ 3x3 ครบ 6 ด้าน
        auraCol = '#ffd700';
        seamCol = '#2a1705';
        emblem = { text: '👑', bg: '#fffbeb', color: '#b45309', border: '#f59e0b' };
        colors = {
            top: 'linear-gradient(135deg, #fffbeb 0%, #fef08a 35%, #eab308 100%)',
            front: 'linear-gradient(135deg, #fef08a 0%, #f59e0b 55%, #b45309 100%)',
            right: 'linear-gradient(135deg, #fde047 0%, #d97706 65%, #78350f 100%)',
            back: 'linear-gradient(135deg, #fef9c3 0%, #eab308 55%, #92400e 100%)',
            left: 'linear-gradient(135deg, #fef08a 0%, #ca8a04 55%, #713f12 100%)',
            bottom: 'linear-gradient(135deg, #78350f 0%, #451a03 100%)'
        };
    } else if (rawType.includes('DIAMOND') || rawType === 'DIAMOND') {
        // 💎 DIAMOND CUBE: คริสตัลเพชรนีออนสีฟ้าเทอร์ควอยซ์
        auraCol = '#00e5ff';
        seamCol = '#031f33';
        emblem = { text: '💎', bg: '#f0fdf4', color: '#0284c7', border: '#38bdf8' };
        colors = {
            top: 'linear-gradient(135deg, #ecfeff 0%, #67e8f9 40%, #06b6d4 100%)',
            front: 'linear-gradient(135deg, #a5f3fc 0%, #0284c7 60%, #0c4a6e 100%)',
            right: 'linear-gradient(135deg, #bae6fd 0%, #0284c7 65%, #0369a1 100%)',
            back: 'linear-gradient(135deg, #cffafe 0%, #0891b2 60%, #155e75 100%)',
            left: 'linear-gradient(135deg, #7dd3fc 0%, #0369a1 65%, #082f49 100%)',
            bottom: 'linear-gradient(135deg, #082f49 0%, #021e33 100%)'
        };
    } else if (rawType.includes('LEGEND') || rawType === 'LEGENDARY') {
        // 🌌 LEGENDARY CUBE: คอสมิกเนบิวลาสีม่วงชมพู
        auraCol = '#ec4899';
        seamCol = '#240638';
        emblem = { text: '🌌', bg: '#fdf4ff', color: '#701a75', border: '#d946ef' };
        colors = {
            top: 'linear-gradient(135deg, #fdf4ff 0%, #f472b6 40%, #d946ef 100%)',
            front: 'linear-gradient(135deg, #f5d0fe 0%, #c026d3 60%, #701a75 100%)',
            right: 'linear-gradient(135deg, #e879f9 0%, #9333ea 65%, #581c87 100%)',
            back: 'linear-gradient(135deg, #fae8ff 0%, #a855f7 60%, #4a044e 100%)',
            left: 'linear-gradient(135deg, #d8b4fe 0%, #7e22ce 65%, #3b0764 100%)',
            bottom: 'linear-gradient(135deg, #3b0764 0%, #1e0533 100%)'
        };
    } else if (rawType.includes('ANCIENT')) {
        // 🔮 ANCIENT CUBE: หยกมรกตโบราณ
        auraCol = '#10b981';
        seamCol = '#02241b';
        emblem = { text: '🔮', bg: '#ecfdf5', color: '#065f46', border: '#10b981' };
        colors = {
            top: 'linear-gradient(135deg, #d1fae5 0%, #34d399 40%, #059669 100%)',
            front: 'linear-gradient(135deg, #6ee7b7 0%, #059669 60%, #064e3b 100%)',
            right: 'linear-gradient(135deg, #a7f3d0 0%, #047857 65%, #022c22 100%)',
            back: 'linear-gradient(135deg, #6ee7b7 0%, #10b981 60%, #047857 100%)',
            left: 'linear-gradient(135deg, #34d399 0%, #065f46 65%, #064e3b 100%)',
            bottom: 'linear-gradient(135deg, #064e3b 0%, #022c22 100%)'
        };
    } else {
        // ✦ CLASSIC SPEEDCUBE (เหมือนรูป GAN Rubik 3x3 แท้ 100%):
        // ด้านบน: ฟ้า/น้ำเงิน, ด้านหน้า: ขาวพร้อมตรา GAN, ซ้าย: ส้ม, ขวา: เขียว, หลัง: เหลือง, ล่าง: แดง
        auraCol = '#38bdf8';
        seamCol = '#0b0f19';
        emblem = { text: 'GAN', bg: '#ffffff', color: '#0284c7', border: '#94a3b8' };
        colors = {
            top: 'linear-gradient(135deg, #93c5fd 0%, #2563eb 55%, #1d4ed8 100%)',
            front: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 55%, #e2e8f0 100%)',
            left: 'linear-gradient(135deg, #fdba74 0%, #f97316 55%, #c2410c 100%)',
            right: 'linear-gradient(135deg, #86efac 0%, #16a34a 55%, #14532d 100%)',
            back: 'linear-gradient(135deg, #fef08a 0%, #eab308 55%, #a16207 100%)',
            bottom: 'linear-gradient(135deg, #fca5a5 0%, #dc2626 55%, #991b1b 100%)'
        };
    }

    // สร้าง 9 ช่อง (3x3 Tiles) ของแต่ละหน้า
    const renderFaceTiles = (faceGrad, isFront = false) => {
        let tilesHtml = '';
        for (let i = 0; i < 9; i++) {
            const isCenter = isFront && (i === 4);
            const emblemHtml = isCenter ? `
                <div style="width:${Math.round(cubeDim * 0.26)}px; height:${Math.round(cubeDim * 0.26)}px; border-radius:50%; background:${emblem.bg}; border:1px solid ${emblem.border}; box-shadow:0 1px 3px rgba(0,0,0,0.6); display:flex; align-items:center; justify-content:center; line-height:1;">
                    <span style="font-size:${emblem.text.length > 2 ? Math.round(cubeDim * 0.085) : Math.round(cubeDim * 0.14)}px; font-weight:900; color:${emblem.color}; font-family:'Segoe UI',sans-serif;">${emblem.text}</span>
                </div>
            ` : '';

            tilesHtml += `
                <div class="cube-3d-tile" style="
                    border-radius: ${tileRadius}px;
                    background: ${faceGrad};
                    box-shadow: inset 0 1px 1.5px rgba(255,255,255,0.65), inset 0 -1px 1.5px rgba(0,0,0,0.35), 0 1px 2px rgba(0,0,0,0.4);
                ">
                    ${emblemHtml}
                </div>
            `;
        }
        return tilesHtml;
    };

    const faceBaseStyle = `
        position: absolute;
        width: ${cubeDim}px;
        height: ${cubeDim}px;
        left: 0;
        top: 0;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        grid-template-rows: repeat(3, 1fr);
        gap: ${gap}px;
        background: ${seamCol};
        padding: ${pad}px;
        box-sizing: border-box;
        border-radius: ${cornerRadius}px;
        box-shadow: inset 0 0 ${Math.max(2, Math.round(cubeDim * 0.08))}px rgba(0,0,0,0.85);
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
    `;

    // 6 Faces in True 3D Coordinates
    const facesHtml = `
        <div class="cube-3d-face face-front" style="${faceBaseStyle} transform: rotateY(0deg) translateZ(${half}px);">${renderFaceTiles(colors.front, true)}</div>
        <div class="cube-3d-face face-back" style="${faceBaseStyle} transform: rotateY(180deg) translateZ(${half}px);">${renderFaceTiles(colors.back, false)}</div>
        <div class="cube-3d-face face-right" style="${faceBaseStyle} transform: rotateY(90deg) translateZ(${half}px);">${renderFaceTiles(colors.right, false)}</div>
        <div class="cube-3d-face face-left" style="${faceBaseStyle} transform: rotateY(-90deg) translateZ(${half}px);">${renderFaceTiles(colors.left, false)}</div>
        <div class="cube-3d-face face-top" style="${faceBaseStyle} transform: rotateX(90deg) translateZ(${half}px);">${renderFaceTiles(colors.top, false)}</div>
        <div class="cube-3d-face face-bottom" style="${faceBaseStyle} transform: rotateX(-90deg) translateZ(${half}px);">${renderFaceTiles(colors.bottom, false)}</div>
    `;

    const animClass = isSpinning ? 'is-spinning' : (isWobble ? 'is-wobble' : 'is-idle');

    return `
        <div class="cube-3d-scene ${hasAura ? 'has-cube-aura' : ''}" style="width:${size}px; height:${size}px; margin:0 auto; flex-shrink:0; position:relative; display:flex; align-items:center; justify-content:center; overflow:visible;">
            ${auraHtml}
            <div class="cube-3d-body ${animClass} ${isFastSpin ? 'is-fast-spin' : ''}" style="width:${cubeDim}px; height:${cubeDim}px; z-index:2;">
                ${facesHtml}
            </div>
            <div class="cube-3d-floor-shadow" style="position:absolute; width:${Math.round(cubeDim * 0.95)}px; height:${Math.max(8, Math.round(cubeDim * 0.25))}px; border-radius:50%; background:radial-gradient(ellipse at center, ${hasAura ? auraCol + '77' : 'rgba(0,0,0,0.55)'} 0%, rgba(0,0,0,0) 72%); bottom:2px; left:50%; transform:translateX(-50%); pointer-events:none; z-index:1;"></div>
        </div>
    `;
};

window.openMagicCubeModal = async function () {
    const modal = document.getElementById('modal-magic-cube');
    if (modal) modal.style.zIndex = '100500';
    if (typeof openModal === 'function') openModal('modal-magic-cube');
    await loadMagicCubesData();
};

const _notifiedReadyCubeKeys = new Set();
const _scheduledSpinningCubeKeys = new Map();
const _pendingNotifTimers = new Map();

window.loadMagicCubesData = async function () {
    try {
        if (!window.apiClient) return;
        const res = await apiClient.getUserCubes();
        if (res && res.status === 'success' && res.data) {
            currentCubesData = res.data;
            renderMagicCubeSlots();
            renderUserCubesTray();
            startMagicCubeLiveTimers();

            const allCubes = currentCubesData?.cubes || [];
            // อัปเดต Badge แจ้งเตือนลูกบาศก์ที่พร้อมเปิด หรือลูกบาศก์ที่รอหมุนในเมนูลัด
            const readyCubes = allCubes.filter(c => c.status === 'READY');
            const readyCount = readyCubes.length;
            const idleCount = allCubes.filter(c => {
                const s = c.slot_index;
                return (s === null || s === undefined || s === 0 || s === '0' || s === '') && (!c.status || String(c.status).toUpperCase() === 'IDLE');
            }).length;

            // ตั้งเวลาแจ้งเตือนล่วงหน้าอัตโนมัติสำหรับทุกช่องที่กำลังหมุนอยู่ (SPINNING)
            allCubes.forEach(c => {
                if (c.status === 'SPINNING' && Number(c.remaining_seconds) > 0) {
                    const slotNum = Number(c.slot_index || 1);
                    const prevRem = _scheduledSpinningCubeKeys.get(c.id);
                    // ตั้งเวลาเมื่อเพิ่งโหลดครั้งแรก หรือเวลาเปลี่ยนเกิน 15 วินาที
                    if (prevRem === undefined || Math.abs(prevRem - Number(c.remaining_seconds)) > 15) {
                        _scheduledSpinningCubeKeys.set(c.id, Number(c.remaining_seconds));
                        if (typeof window.schedulePhoneNotification === 'function') {
                            window.schedulePhoneNotification({
                                title: '🔮 ลูกบาศก์นำโชคหมุนครบแล้ว!',
                                body: `${c.cube_name || 'ลูกบาศก์นำโชค'} (ช่อง ${slotNum}) หมุนเสร็จสมบูรณ์แล้ว! แตะเพื่อเปิดรับเพชรและทองรางวัลใหญ่`,
                                id: 7700 + slotNum,
                                scheduleAtMs: Date.now() + (Number(c.remaining_seconds) * 1000),
                                actionType: 'MAGIC_CUBE'
                            });
                        }
                    }
                }
            });

            const badgeCube = document.getElementById('badge-cube-ready');
            if (badgeCube) {
                if (readyCount > 0) {
                    badgeCube.textContent = `🎁 ${readyCount}`;
                    badgeCube.style.background = '#10b981';
                    badgeCube.style.display = 'inline-block';
                } else if (idleCount > 0) {
                    badgeCube.textContent = idleCount > 99 ? '99+' : String(idleCount);
                    badgeCube.style.background = '#ef4444';
                    badgeCube.style.display = 'inline-block';
                } else {
                    badgeCube.style.display = 'none';
                }
            }

            // แจ้งเตือนลูกบาศก์ที่หมุนครบเวลาแล้ว (READY) ทุกช่องที่ยังไม่ได้แจ้งเตือนในรอบนี้
            if (readyCount > 0 && typeof window.notifyCubeFinishReady === 'function') {
                const newlyReady = readyCubes.filter(c => {
                    const key = `${c.id}_${c.slot_index}_READY`;
                    if (_notifiedReadyCubeKeys.has(key)) return false;
                    _notifiedReadyCubeKeys.add(key);
                    return true;
                });
                if (newlyReady.length === 1) {
                    const rc = newlyReady[0];
                    window.notifyCubeFinishReady(rc.slot_index || 1, rc.cube_name || 'ลูกบาศก์นำโชค', rc.id);
                } else if (newlyReady.length > 1) {
                    const summaryNames = newlyReady.map(rc => `${rc.cube_name || 'ลูกบาศก์'} (ช่อง ${rc.slot_index || 1})`).join(', ');
                    window.schedulePhoneNotification({
                        title: `🔮 ลูกบาศก์หมุนครบแล้ว ${newlyReady.length} ช่อง!`,
                        body: `${summaryNames} หมุนเสร็จสมบูรณ์แล้ว! แตะเพื่อเปิดรับเพชรและทองรางวัลใหญ่ทันที`,
                        id: 7799,
                        delayMs: 400,
                        actionType: 'MAGIC_CUBE'
                    });
                }
            }

            if (typeof window.triggerEventStartedNotification === 'function') {
                window.triggerEventStartedNotification('กิจกรรมล่าการ์ดเงาและลูกบาศก์นำโชค');
            }
        }
    } catch (e) {
        console.error('Failed to load magic cubes:', e);
    }
};

function startMagicCubeLiveTimers() {
    if (magicCubeInterval) clearInterval(magicCubeInterval);
    magicCubeInterval = setInterval(() => {
        let hasSpinning = false;
        let newlyFinished = false;
        if (currentCubesData && currentCubesData.cubes) {
            for (const c of currentCubesData.cubes) {
                if (c.status === 'SPINNING') {
                    if (c.remaining_seconds > 0) {
                        c.remaining_seconds--;
                        hasSpinning = true;
                    } else {
                        c.status = 'READY';
                        newlyFinished = true;
                        const key = `${c.id}_${c.slot_index}_READY`;
                        if (!c._notifiedReady && !_notifiedReadyCubeKeys.has(key)) {
                            c._notifiedReady = true;
                            _notifiedReadyCubeKeys.add(key);
                            if (typeof window.notifyCubeFinishReady === 'function') {
                                window.notifyCubeFinishReady(c.slot_index || 1, c.cube_name || 'ลูกบาศก์นำโชค', c.id);
                            }
                        }
                    }
                }
            }
        }
        updateMagicCubeSlotTimers();
        if (newlyFinished) {
            renderMagicCubeSlots();
            const readyCount = (currentCubesData?.cubes || []).filter(c => c.status === 'READY').length;
            const badgeCube = document.getElementById('badge-cube-ready');
            if (badgeCube && readyCount > 0) {
                badgeCube.textContent = `🎁 ${readyCount}`;
                badgeCube.style.background = '#10b981';
                badgeCube.style.display = 'inline-block';
            }
        }
        if (!hasSpinning && (!currentCubesData.cubes.some(c => c.status === 'SPINNING'))) {
            clearInterval(magicCubeInterval);
        }
    }, 1000);
}

// เช็คสถานะลูกบาศก์ในพื้นหลังทุกๆ 45 วินาที เพื่อให้แจ้งเตือนทันทีเมื่อหมุนครบเวลาแม้ไม่ได้เปิดหน้าต่างลูกบาศก์
setInterval(() => {
    const uid = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.id) ? Number(DEFAULT_USER.id) : (window.DEFAULT_USER?.id ? Number(window.DEFAULT_USER.id) : 0);
    if (uid > 0 && typeof window.loadMagicCubesData === 'function') {
        window.loadMagicCubesData().catch(() => {});
    }
}, 45000);

function updateMagicCubeSlotTimers() {
    for (let slot = 1; slot <= 4; slot++) {
        const cube = (currentCubesData?.cubes || []).find(c => Number(c.slot_index) === slot && c.status !== 'CLAIMED');
        const timerEl = document.getElementById(`cube-slot-${slot}-timer`);
        if (timerEl && cube) {
            if (cube.status === 'READY') {
                timerEl.innerHTML = '<span style="color:#10b981; font-weight:800;">🎉 หมุนเสร็จแล้ว! แตะรับรางวัล</span>';
            } else if (cube.status === 'SPINNING') {
                const s = cube.remaining_seconds || 0;
                const hrs = Math.floor(s / 3600);
                const mins = Math.floor((s % 3600) / 60);
                const secs = s % 60;
                const hasAura = Boolean(cube.has_aura) || cube.spin_cost_currency === 'DIAMOND';
                timerEl.innerHTML = `<span style="color:${hasAura ? '#fef08a' : '#ffd700'}; font-weight:800;">${hasAura ? '✨ ' : '⏳ '}${hrs > 0 ? hrs + ' ชม. ' : ''}${mins} น. ${secs} วิ</span>`;
            }
        }
    }
}

// ฟังก์ชันดึงค่าคอนฟิกออร่าของลูกบาศก์ที่แอดมินกำหนดจากระบบหลังบ้าน
window.getCubeAuraSettings = function(cubeType = 'SILVER') {
    const rawType = String(cubeType || 'SILVER').toUpperCase();
    const cubeCfg = (currentCubesData?.configs || []).find(cf => String(cf.cube_type).toUpperCase() === rawType) || {};
    return {
        auraType: cubeCfg.aura_type || 'neon_pulse',
        particleFx: cubeCfg.particle_fx || 'flare_burst',
        intensity: cubeCfg.intensity || '2x'
    };
};

// 📱 Phone Notifications System (แจ้งเตือนทางข้อความหน้าจอโทรศัพท์ / Lock Screen เหมือนรูป 2 + แบนเนอร์แจ้งเตือนสไตล์ iOS)
(function initServiceWorkerForNotifications() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('sw.js').then(reg => {
                console.log('[SW] ServiceWorker registered for lockscreen notifications:', reg.scope);
                if ('Notification' in window && Notification.permission === 'granted' && typeof window.registerWebPushSubscription === 'function') {
                    window.registerWebPushSubscription().catch(() => {});
                }
            }).catch(err => {
                console.warn('[SW] ServiceWorker registration notice:', err.message);
            });
        });
    }

    // ขอสิทธิ์แจ้งเตือนอัตโนมัติเมื่อผู้เล่นแตะหน้าจอครั้งแรก (iOS / Android / Browser ต้องใช้ User Gesture)
    let _autoRequestedPerm = false;
    const autoRequestOnFirstTap = () => {
        if (_autoRequestedPerm) return;
        _autoRequestedPerm = true;
        if (window.webkit?.messageHandlers?.snakeNativeNotify) {
            try { window.webkit.messageHandlers.snakeNativeNotify.postMessage({ action: 'requestPermission' }); } catch (e) {}
        }
        if ('Notification' in window && Notification.permission === 'default') {
            window.requestNotificationPermission().catch(() => {});
        }
    };
    document.addEventListener('touchend', autoRequestOnFirstTap, { once: true, passive: true });
    document.addEventListener('click', autoRequestOnFirstTap, { once: true, passive: true });
})();

/**
 * แสดงแบนเนอร์แจ้งเตือนสไตล์ iOS Lock Screen / Notification Center (เหมือนรูป 2)
 * เด้งลงมาจากด้านบนหน้าจอพร้อมเสียงแจ้งเตือน และแตะเพื่อเปิดหน้านั้นได้ทันที
 */
window.showPhoneStyleNotificationBanner = function ({ title, body, icon = '🔮', actionType = '', onClick = null }) {
    if (typeof document === 'undefined' || !document.body) return;

    let container = document.getElementById('ios-phone-notif-stack');
    if (!container) {
        container = document.createElement('div');
        container.id = 'ios-phone-notif-stack';
        container.style.cssText = 'position:fixed; top:max(10px, env(safe-area-inset-top, 10px)); left:50%; transform:translateX(-50%); z-index:2147483640; width:min(92vw, 350px); display:flex; flex-direction:column; gap:7px; pointer-events:none;';
        document.body.appendChild(container);
    }

    // จำกัดไม่ให้ซ้อนเกิน 3 อัน
    while (container.children.length >= 3) {
        container.removeChild(container.firstChild);
    }

    const card = document.createElement('div');
    card.style.cssText = `
        pointer-events: auto;
        cursor: pointer;
        background: rgba(22, 30, 46, 0.94);
        backdrop-filter: blur(18px);
        -webkit-backdrop-filter: blur(18px);
        border: 1px solid rgba(255, 255, 255, 0.22);
        border-radius: 18px;
        padding: 10px 13px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.72), 0 0 18px rgba(56, 189, 248, 0.28);
        display: flex;
        align-items: center;
        gap: 10px;
        color: #ffffff;
        font-family: 'Kanit', -apple-system, BlinkMacSystemFont, sans-serif;
        transform: translateY(-24px) scale(0.95);
        opacity: 0;
        transition: transform 0.28s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.28s ease;
    `;

    card.innerHTML = `
        <div style="position:relative; width:38px; height:38px; border-radius:10px; background:linear-gradient(135deg, #0284c7, #1e3a8a); border:1px solid rgba(125,211,252,0.5); display:flex; align-items:center; justify-content:center; flex-shrink:0; box-shadow:0 3px 10px rgba(0,0,0,0.45); overflow:hidden;">
            <img src="apple-touch-icon.png" alt="" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <span style="display:none; font-size:20px; align-items:center; justify-content:center;">${icon}</span>
            <span style="position:absolute; top:-2px; right:-2px; background:#ef4444; color:#fff; font-size:8.5px; font-weight:900; width:14px; height:14px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:1px solid #fff;">1</span>
        </div>
        <div style="flex:1; min-width:0; text-align:left;">
            <div style="display:flex; justify-content:space-between; align-items:baseline; gap:6px; margin-bottom:1px;">
                <span style="font-size:12px; font-weight:800; color:#ffffff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${title || '🎲 เกมส์บันไดงู 3D'}</span>
                <span style="font-size:9.5px; color:#94a3b8; flex-shrink:0;">ตอนนี้</span>
            </div>
            <div style="font-size:11px; color:#e2e8f0; line-height:1.3; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">
                ${body || ''}
            </div>
        </div>
    `;

    const dismissCard = () => {
        card.style.transform = 'translateY(-18px) scale(0.95)';
        card.style.opacity = '0';
        setTimeout(() => {
            if (card.parentNode) card.parentNode.removeChild(card);
        }, 260);
    };

    card.onclick = () => {
        dismissCard();
        if (typeof onClick === 'function') {
            onClick();
        } else if (actionType === 'MAGIC_CUBE' && typeof window.openMagicCubeModal === 'function') {
            window.openMagicCubeModal();
        } else if (actionType === 'MAIL' && typeof window.openModal === 'function') {
            window.openModal('modal-mail');
            if (typeof window.loadMailData === 'function') window.loadMailData();
        } else if (actionType === 'EVENT' && typeof window.openFrameEventModal === 'function') {
            window.openFrameEventModal();
        }
    };

    container.appendChild(card);
    requestAnimationFrame(() => {
        card.style.transform = 'translateY(0) scale(1)';
        card.style.opacity = '1';
    });

    setTimeout(dismissCard, 6500);
};

window._urlBase64ToUint8Array = function(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
};

window.registerWebPushSubscription = async function() {
    try {
        if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
            return false;
        }
        if (Notification.permission !== 'granted') {
            return false;
        }
        const reg = await navigator.serviceWorker.ready;
        if (!reg || !reg.pushManager) return false;

        const baseUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
        const keyRes = await fetch(baseUrl + 'api/web_push.php?action=vapid_public_key');
        const keyJson = await keyRes.json();
        if (!keyJson || keyJson.status !== 'success' || !keyJson.public_key) {
            return false;
        }

        const appServerKey = window._urlBase64ToUint8Array(keyJson.public_key);
        let subscription = await reg.pushManager.getSubscription();
        if (!subscription) {
            subscription = await reg.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: appServerKey
            });
        }
        if (!subscription) return false;

        const headers = { 'Content-Type': 'application/json' };
        const token = (window.apiClient && typeof window.apiClient.getToken === 'function') ? window.apiClient.getToken() : '';
        if (token) {
            headers['Authorization'] = 'Bearer ' + token;
        }

        const subRes = await fetch(baseUrl + 'api/web_push.php?action=subscribe', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ subscription: subscription.toJSON() })
        });
        const subJson = await subRes.json();
        if (subJson && subJson.status === 'success') {
            console.log('[WebPush] Subscribed device successfully');
            return true;
        }
        return false;
    } catch (e) {
        console.warn('[WebPush] Subscribe notice:', e.message || e);
        return false;
    }
};

window.requestNotificationPermission = async function() {
    if (window.webkit?.messageHandlers?.snakeNativeNotify) {
        try {
            window.webkit.messageHandlers.snakeNativeNotify.postMessage({ action: 'requestPermission' });
        } catch (e) {}
    }
    if (window.Capacitor?.Plugins?.LocalNotifications) {
        try {
            const res = await window.Capacitor.Plugins.LocalNotifications.requestPermissions();
            return res?.display === 'granted';
        } catch(e) {}
    }
    if ('Notification' in window) {
        try {
            const perm = await Notification.requestPermission();
            if (perm === 'granted' && typeof window.registerWebPushSubscription === 'function') {
                window.registerWebPushSubscription().catch(() => {});
            }
            return perm === 'granted';
        } catch(e) {}
    }
    return false;
};

window.enablePhoneNotificationsPrompt = async function() {
    const granted = await window.requestNotificationPermission();
    localStorage.setItem('snake_phone_notifications_enabled', 'true');
    if (granted || (typeof Notification !== 'undefined' && Notification.permission === 'granted') || window.webkit?.messageHandlers?.snakeNativeNotify) {
        if (typeof window.showToast === 'function') {
            window.showToast('🔔 เปิดการแจ้งเตือนหน้าจอมือถือสำเร็จ!');
        }
    }
    // ยิงแจ้งเตือนตัวอย่างให้ผู้เล่นเห็นผลทันที
    window.schedulePhoneNotification({
        title: '🎲 เปิดระบบแจ้งเตือนสำเร็จ!',
        body: 'ระบบจะแจ้งเตือนเมื่อลูกบาศก์นำโชคหมุนครบเวลา มีจดหมายใหม่ หรือมีกิจกรรมพิเศษ',
        id: 8888,
        delayMs: 400
    });
    const btn = document.getElementById('btn-toggle-phone-notifications');
    if (btn) {
        btn.style.background = 'linear-gradient(135deg,#16a34a,#15803d)';
        btn.innerHTML = '<span>✅</span> เปิดใช้งานแล้ว';
    }
};

window.schedulePhoneNotification = async function({ title, body, id = 7000, delayMs = 0, scheduleAtMs = 0, actionType = '', onClick = null }) {
    const targetTimeMs = scheduleAtMs > 0 ? scheduleAtMs : (Date.now() + Math.max(200, delayMs));
    const delayFromNow = Math.max(0, targetTimeMs - Date.now());
    const notifKey = String(id || 7000);

    if (_pendingNotifTimers.has(notifKey)) {
        clearTimeout(_pendingNotifTimers.get(notifKey));
        _pendingNotifTimers.delete(notifKey);
    }

    // 1. iOS Native UNUserNotificationCenter Bridge (แจ้งเตือนขึ้นหน้าจอล็อก iPhone แบบรูป 2 แม้พับแอป/ล็อกจอ)
    if (window.webkit?.messageHandlers?.snakeNativeNotify) {
        try {
            window.webkit.messageHandlers.snakeNativeNotify.postMessage({
                action: 'schedule',
                id: Number(id) || 7000,
                title: String(title),
                body: String(body),
                delayMs: delayFromNow
            });
        } catch (err) {
            console.warn('[PushNotif] iOS native bridge error:', err);
        }
    }

    // 2. Capacitor Native Local Notifications (iOS / Android Lockscreen & Status Bar)
    if (window.Capacitor?.Plugins?.LocalNotifications) {
        try {
            await window.Capacitor.Plugins.LocalNotifications.schedule({
                notifications: [{
                    id: Number(id) || Math.floor(Math.random() * 90000) + 10000,
                    title: String(title),
                    body: String(body),
                    schedule: { at: new Date(targetTimeMs) },
                    sound: 'default'
                }]
            });
        } catch(err) {
            console.warn('[PushNotif] Capacitor schedule error:', err);
        }
    }

    // 3. ส่งคำสั่งตั้งเวลาแจ้งเตือนไปยัง Service Worker (รองรับตอนพับหน้าจอเบราว์เซอร์ / PWA)
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        try {
            navigator.serviceWorker.controller.postMessage({
                type: 'SCHEDULE_NOTIFICATION',
                id: notifKey,
                title: String(title),
                body: String(body),
                icon: 'apple-touch-icon.png',
                badge: 'favicon.png',
                tag: 'game-notif-' + notifKey,
                delayMs: delayFromNow,
                actionType: actionType
            });
        } catch (e) {}
    }

    // 4. แสดงผลเมื่อถึงเวลา (ทั้ง OS Notification + แบนเนอร์สไตล์ iOS ด้านบนหน้าจอ + เสียงแจ้งเตือน)
    const fireNow = () => {
        _pendingNotifTimers.delete(notifKey);

        // แสดงแบนเนอร์สไตล์ iOS ด้านบนหน้าจอเสมอเพื่อให้ผู้เล่นเห็นแจ้งเตือน 100%
        if (typeof window.showPhoneStyleNotificationBanner === 'function') {
            window.showPhoneStyleNotificationBanner({
                title: title,
                body: body,
                actionType: actionType,
                onClick: onClick
            });
        }

        // ยิง OS / Browser Notification หากได้รับสิทธิ์
        if ('Notification' in window && Notification.permission === 'granted') {
            if ('serviceWorker' in navigator && navigator.serviceWorker.ready) {
                navigator.serviceWorker.ready.then(reg => {
                    reg.showNotification(title, {
                        body: body,
                        icon: 'apple-touch-icon.png',
                        badge: 'favicon.png',
                        vibrate: [300, 100, 300, 100, 400],
                        tag: 'game-notif-' + notifKey,
                        renotify: true,
                        requireInteraction: false,
                        data: { url: './', actionType: actionType }
                    });
                }).catch(() => {
                    try { new Notification(title, { body: body, icon: 'apple-touch-icon.png' }); } catch(e) {}
                });
            } else {
                try { new Notification(title, { body: body, icon: 'apple-touch-icon.png' }); } catch(e) {}
            }
        }

        // สั่นเครื่อง (Vibration)
        if (navigator.vibrate) {
            try { navigator.vibrate([300, 100, 300, 100, 400]); } catch(e) {}
        }
        // เล่นเสียงแจ้งเตือน
        if (window.soundEngine && typeof window.soundEngine.playNotification === 'function') {
            try { window.soundEngine.playNotification(); } catch(e) {}
        }
    };

    if (delayFromNow <= 1200) {
        fireNow();
    } else if (delayFromNow < 86400000) {
        const t = setTimeout(fireNow, delayFromNow);
        _pendingNotifTimers.set(notifKey, t);
    }
};

// แจ้งเตือนเมื่อลูกบาศก์หมุนเสร็จ
window.notifyCubeFinishReady = function(slot, cubeName = 'ลูกบาศก์นำโชค', cubeId = 0) {
    const dedupKey = `last_cube_notif_${slot}_${cubeId || ''}`;
    const lastNotif = sessionStorage.getItem(dedupKey);
    if (lastNotif && Date.now() - Number(lastNotif) < 20000) return;
    sessionStorage.setItem(dedupKey, String(Date.now()));

    window.schedulePhoneNotification({
        title: '🔮 ลูกบาศก์นำโชคหมุนครบแล้ว!',
        body: `${cubeName} ในช่อง ${slot} หมุนเสร็จสมบูรณ์แล้ว! แตะที่นี่เพื่อเปิดรับเพชรและทองรางวัลใหญ่`,
        id: 7700 + Number(slot),
        delayMs: 300,
        actionType: 'MAGIC_CUBE'
    });
};

// แจ้งเตือนจดหมายและของรางวัลใกล้หมดอายุ
window.checkAndNotifyExpiringMails = function(expiringCount) {
    if (!expiringCount || expiringCount <= 0) return;
    window.schedulePhoneNotification({
        title: '📬 กล่องจดหมาย: มีของรางวัลรอรับ!',
        body: `คุณมี ${expiringCount} ของรางวัลในกล่องจดหมายที่ใกล้หมดอายุใน 24 ชม.! แตะเพื่อรับทันที`,
        id: 7801,
        delayMs: 1200,
        actionType: 'MAIL'
    });
};

// แจ้งเตือนกิจกรรมเริ่มแล้ว
window.triggerEventStartedNotification = function(eventName = 'กิจกรรมล่าการ์ดเงาและลูกบาศก์นำโชค') {
    const today = new Date().toDateString();
    if (sessionStorage.getItem('event_notif_' + today)) return;
    sessionStorage.setItem('event_notif_' + today, '1');

    window.schedulePhoneNotification({
        title: '🎉 กิจกรรมพิเศษเปิดให้ร่วมสนุกแล้ว!',
        body: `${eventName} เริ่มต้นแล้ว เข้ามาหมุนลูกบาศก์และสุ่มรางวัลใหญ่ได้เลย`,
        id: 7901,
        delayMs: 2200,
        actionType: 'EVENT'
    });
};

window.renderMagicCubeSlots = function () {
    const grid = document.getElementById('magic-cube-slots-grid');
    if (!grid) return;

    let html = '';
    for (let slot = 1; slot <= 4; slot++) {
        const cube = (currentCubesData?.cubes || []).find(c => Number(c.slot_index) === slot && c.status !== 'CLAIMED');
        const auraCfg = window.getCubeAuraSettings(cube ? cube.cube_type : 'SILVER');

        if (!cube) {
            html += `
                <div class="cube-slot-card empty-slot" onclick="equipFirstAvailableCubeToSpecificSlot(${slot})" style="border: 1.5px dashed rgba(56, 189, 248, 0.4); text-align: center; padding: 4px 6px; border-radius: 10px; background: rgba(15, 23, 42, 0.5); min-height: clamp(118px, 20vh, 138px); display:flex; flex-direction:column; justify-content:space-between; align-items:center; cursor:pointer; transition:transform 0.15s ease, border-color 0.15s ease;" title="แตะเพื่อใส่ลูกบาศก์ลงในช่อง ${slot}" onmouseover="this.style.borderColor='#38bdf8'; this.style.background='rgba(56,189,248,0.08)'" onmouseout="this.style.borderColor='rgba(56,189,248,0.4)'; this.style.background='rgba(15,23,42,0.5)'">
                    <div style="display:flex; justify-content:space-between; align-items:center; width:100%; position:relative; z-index:2;">
                        <span style="font-size: 9px; color: #64748b; font-weight: 800; text-transform:uppercase;">ช่อง ${slot}</span>
                    </div>
                    <div style="margin: 2px 0;">
                        ${window.getMagicCubeSvgHtml('SILVER', false, 44, false, false, auraCfg)}
                    </div>
                    <div style="font-size: 8.5px; color: #38bdf8; font-weight: 800; margin-bottom: 3px;">+ แตะเพื่อใส่ลูกบาศก์</div>
                </div>
            `;
        } else {
            const isSpinning = cube.status === 'SPINNING';
            const isReady = cube.status === 'READY';
            const hasAura = (isSpinning || isReady) && (Boolean(cube.has_aura) || cube.spin_cost_currency === 'DIAMOND');
            const color = (cube.color_hex || '#00e5ff');

            html += `
                <div class="cube-slot-card ${hasAura ? 'has-aura-spin' : ''} ${isSpinning ? 'is-spinning-active' : ''}" style="border: 2px solid ${color}; text-align: center; padding: 4px 6px; border-radius: 10px; background: radial-gradient(circle at center, rgba(30, 41, 59, 0.95) 0%, rgba(10, 15, 29, 0.98) 100%); box-shadow: 0 4px 18px ${color}33, inset 0 0 12px ${color}1a; position: relative; min-height: clamp(118px, 20vh, 138px); display:flex; flex-direction:column; justify-content:space-between; cursor:pointer;" onclick="${isReady ? `claimCubeRewardAction(${cube.id})` : (!isSpinning ? `showCubeSpinConfirmModal(${cube.id})` : `speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})`)}">
                    

                    <div style="display:flex; justify-content:space-between; align-items:center; width:100%; position:relative; z-index:2;">
                        <span style="font-size: 9px; color: ${color}; font-weight: 800; text-transform:uppercase; letter-spacing:0.3px;">ช่อง ${slot}</span>
                        <div style="display:flex; align-items:center; gap:4px;">
                            ${!isSpinning && !isReady ? `<button type="button" onclick="event.stopPropagation(); removeCubeFromSlotAction(${cube.id})" style="background:rgba(239,68,68,0.25); border:1px solid #ef4444; color:#fca5a5; font-size:9px; cursor:pointer; font-weight:900; padding:1px 5px; border-radius:4px; line-height:1;" title="นำออก">✕</button>` : ''}
                        </div>
                    </div>

                    <!-- Glowing 3D Magic Cube (จัดระยะห่างไม่ให้วงออร่าทับชื่อลูกบาศก์ด้านล่าง) -->
                    <div style="margin: 4px auto 7px auto; display:flex; align-items:center; justify-content:center; position:relative; z-index:2;">
                        ${window.getMagicCubeSvgHtml(cube.cube_type || 'SILVER', isSpinning, hasAura ? 54 : 52, hasAura, false, auraCfg)}
                    </div>

                    <div style="font-size: 10px; font-weight: 800; color: #fff; margin-top: 2px; text-shadow:0 0 8px ${color}; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; position:relative; z-index:3;">${cube.cube_name || cube.cube_type}</div>

                    <div id="cube-slot-${slot}-timer" style="font-size: 8.5px; min-height: 12px; margin: 1px 0; position:relative; z-index:2;">
                        ${isReady ? '<span style="color:#10b981; font-weight:900;">🎉 แตะรับรางวัล!</span>' :
                    (isSpinning ? `<span style="color:${hasAura ? '#fef08a' : '#ffd700'}; font-weight:800;">${hasAura ? '✨ หมุนออร่า MAX' : 'กำลังหมุน...'}</span>` :
                        '<span style="color:#38bdf8; font-weight:700;">แตะหมุน</span>')}
                    </div>

                    <div style="margin-top: 1px; width:100%; position:relative; z-index:2;">
                        ${isReady ? `
                            <button type="button" onclick="event.stopPropagation(); claimCubeRewardAction(${cube.id})" class="btn" style="width:100%; padding: 3px 6px; font-size: 9.5px; font-weight: 900; background: linear-gradient(135deg, #10b981, #059669); color: #fff; border:1px solid #34d399; border-radius: 6px; cursor:pointer; box-shadow:0 2px 8px rgba(16,185,129,0.5);">
                                🎁 รับ
                            </button>
                        ` : (isSpinning ? `
                            <button type="button" onclick="event.stopPropagation(); speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})" class="btn" style="width:100%; padding: 3px 6px; font-size: 9px; font-weight: 800; background: linear-gradient(135deg, #06b6d4, #0284c7); color: #fff; border:1px solid #38bdf8; border-radius: 6px; cursor:pointer; box-shadow:0 2px 8px rgba(6,182,212,0.4);">
                                ⚡ 💎${cube.instant_open_diamond || 10}
                            </button>
                        ` : `
                            <button type="button" onclick="event.stopPropagation(); showCubeSpinConfirmModal(${cube.id})" class="btn" style="width:100%; padding: 3px 6px; font-size: 9.5px; font-weight: 900; background: linear-gradient(135deg, #f59e0b, #d97706); color: #000; border:1.5px solid #fde047; border-radius: 6px; cursor:pointer; box-shadow:0 2px 8px rgba(245,158,11,0.5);">
                                🌀 หมุน
                            </button>
                        `)}
                    </div>
                </div>
            `;
        }
    }
    grid.innerHTML = html;
    if (typeof window.initOrUpdateMagicCube3DCanvases === 'function') {
        window.initOrUpdateMagicCube3DCanvases();
    }
};

function renderUserCubesTray() {
    const tray = document.getElementById('user-cubes-slots-row');
    const countEl = document.getElementById('user-cube-count');
    if (!tray) return;

    const unequipped = (currentCubesData?.cubes || []).filter(c => {
        const s = c.slot_index;
        const isSlotEmpty = s === null || s === undefined || s === 0 || s === '0' || s === '';
        const isIdle = !c.status || String(c.status).toUpperCase() === 'IDLE';
        return isSlotEmpty && isIdle;
    });
    if (countEl) countEl.innerText = unequipped.length;

    if (unequipped.length === 0) {
        tray.innerHTML = `
            <div style="color:#64748b; font-size:9px; padding:6px; text-align:center; width:100%;">
                ยังไม่มีลูกบาศก์ในกระเป๋า ชนะห้อง 2M / 5M / 10M เพื่อรับฟรี!
            </div>
        `;
        return;
    }

    tray.innerHTML = unequipped.map(c => {
        const cType = (c.cube_type || 'SILVER').toUpperCase();
        const fallbackName = cType === 'LEGENDARY' ? 'ลูกบาศก์ในตำนาน' : (cType === 'DIAMOND' ? 'ลูกบาศก์เพชร' : (cType === 'GOLD' ? 'ลูกบาศก์ทอง' : 'ลูกบาศก์เงิน'));
        const fallbackColor = cType === 'LEGENDARY' ? '#a855f7' : (cType === 'DIAMOND' ? '#00e5ff' : (cType === 'GOLD' ? '#f59e0b' : '#94a3b8'));
        const cName = c.cube_name || fallbackName;
        const cColor = c.color_hex || fallbackColor;

        return `
            <div class="cube-inventory-card" onclick="equipCubeToFirstEmptySlot(${c.id})" style="background: rgba(30, 41, 59, 0.9); border: 1.5px solid ${cColor}; border-radius: 8px; padding: 3px 5px; text-align: center; cursor: pointer; min-width: 62px; max-width: 72px; flex-shrink: 0; box-shadow: 0 0 10px ${cColor}33; display:flex; flex-direction:column; align-items:center; justify-content:space-between;" title="แตะเพื่อใส่">
                <div style="width: 40px; height: 40px; display:flex; align-items:center; justify-content:center; margin: 1px 0;">
                    ${window.getMagicCubeSvgHtml(cType, false, 40, false, true)}
                </div>
                <div style="font-size: 8.5px; font-weight: 800; color: #fff; margin-top: 1px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:64px;">${cName}</div>
                <div style="font-size: 8px; font-weight: 800; color: #38bdf8; margin-top: 1px; background: rgba(56,189,248,0.2); border: 1px solid rgba(56,189,248,0.4); border-radius:4px; padding:1px 6px;">+ ใส่</div>
            </div>
        `;
    }).join('');

    if (typeof window.initOrUpdateMagicCube3DCanvases === 'function') {
        window.initOrUpdateMagicCube3DCanvases();
    }
}

window.equipCubeToFirstEmptySlot = async function (userCubeId) {
    const occupiedSlots = (currentCubesData?.cubes || [])
        .filter(c => c.slot_index !== null && c.slot_index !== undefined && c.slot_index !== '' && c.status !== 'CLAIMED')
        .map(c => Number(c.slot_index));
    let targetSlot = 1;
    while (occupiedSlots.includes(targetSlot) && targetSlot <= 4) {
        targetSlot++;
    }
    if (targetSlot > 4) {
        if (typeof showToast === 'function') showToast('แท่นหมุนเต็มแล้วทั้ง 4 ช่อง! กรุณานำออกหรือรอหมุนเสร็จ');
        return;
    }

    await window.equipCubeToSpecificSlot(userCubeId, targetSlot);
};

window.equipCubeToSpecificSlot = async function (userCubeId, targetSlot) {
    targetSlot = Number(targetSlot) || 1;
    try {
        const res = await apiClient.equipCubeToSlot(userCubeId, targetSlot);
        if (res && res.status === 'success') {
            if (typeof showToast === 'function') showToast(`ใส่ลูกบาศก์ลงช่องที่ ${targetSlot} เรียบร้อยแล้ว`);
            await loadMagicCubesData();
        } else {
            if (typeof showToast === 'function') showToast(res.message || 'ไม่สามารถใส่ลูกบาศก์ได้');
        }
    } catch (e) {
        if (typeof showToast === 'function') showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.equipFirstAvailableCubeToSpecificSlot = async function (targetSlot) {
    const unequipped = (currentCubesData?.cubes || []).filter(c => {
        const s = c.slot_index;
        const isSlotEmpty = s === null || s === undefined || s === 0 || s === '0' || s === '';
        const isIdle = !c.status || String(c.status).toUpperCase() === 'IDLE';
        return isSlotEmpty && isIdle;
    });

    if (unequipped.length === 0) {
        if (typeof showToast === 'function') showToast('ไม่มีลูกบาศก์ว่างในกระเป๋า');
        return;
    }

    await window.equipCubeToSpecificSlot(unequipped[0].id, targetSlot);
};

window.removeCubeFromSlotAction = async function (userCubeId) {
    try {
        const res = await apiClient.removeCubeFromSlot(userCubeId);
        if (res && res.status === 'success') {
            if (typeof showToast === 'function') showToast('นำลูกบาศก์ออกจากช่องแล้ว');
            await loadMagicCubesData();
        } else {
            if (typeof showToast === 'function') showToast(res.message || 'ไม่สามารถนำออกได้');
        }
    } catch (e) {
        if (typeof showToast === 'function') showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.showCubeSpinConfirmModal = function (userCubeId) {
    userCubeId = Number(userCubeId);
    if (!currentCubesData || !currentCubesData.cubes) return;
    const cube = currentCubesData.cubes.find(c => Number(c.id) === userCubeId);
    if (!cube) {
        console.warn('[MagicCube] Cube not found for ID:', userCubeId);
        return;
    }
    selectedCubeForSpin = cube;

    const prevEl = document.getElementById('spin-confirm-cube-preview');
    const diaCostEl = document.getElementById('spin-cost-dia-val');
    const goldCostEl = document.getElementById('spin-cost-gold-val');
    const userDiaEl = document.getElementById('spin-user-dia-val');
    const userGoldEl = document.getElementById('spin-user-gold-val');

    if (prevEl) {
        prevEl.innerHTML = `
            <div style="display:inline-block; margin: 0 auto; position:relative; transform: scale(0.84);">
                ${window.getMagicCubeSvgHtml(cube.cube_type || 'SILVER', false, 44, true, true)}
            </div>
            <h4 style="color: #fff; margin: 1px 0 0 0; font-size: 11.5px; font-weight:900; text-shadow:0 0 8px ${cube.color_hex || '#38bdf8'}; letter-spacing:0.2px; line-height:1.2;">${cube.cube_name || cube.cube_type}</h4>
            <div style="font-size: 8.5px; color: #94a3b8; margin-bottom: 1px;">ระยะเวลา: <strong style="color:#fde047; font-weight:800;">${cube.min_hours || 1} - ${cube.max_hours || 4} ชม.</strong></div>
        `;
    }

    const diaCost = cube.spin_cost_diamond || (cube.cube_type === 'SILVER' ? 10 : (cube.cube_type === 'GOLD' ? 25 : 50));
    const goldCost = cube.spin_cost_gold || (cube.cube_type === 'SILVER' ? 5000 : (cube.cube_type === 'GOLD' ? 15000 : 35000));

    if (diaCostEl) diaCostEl.innerText = `${diaCost} เพชร`;
    if (goldCostEl) goldCostEl.innerText = `${Number(goldCost).toLocaleString()} ทอง`;

    const u = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? DEFAULT_USER : (window.DEFAULT_USER || {});
    const myDia = Number(u.diamond ?? u.diamonds ?? 0);
    const myGold = Number(u.gold ?? 0);

    if (userDiaEl) userDiaEl.innerText = myDia.toLocaleString();
    if (userGoldEl) userGoldEl.innerText = myGold.toLocaleString();

    const confirmModal = document.getElementById('modal-cube-spin-confirm');
    if (confirmModal) {
        confirmModal.style.zIndex = '100900';
    }
    if (typeof openModal === 'function') {
        openModal('modal-cube-spin-confirm');
    }
};

window.confirmStartSpinAction = async function (currency) {
    if (!selectedCubeForSpin) return;
    const cubeToSpin = selectedCubeForSpin;
    if (typeof closeModal === 'function') {
        closeModal('modal-cube-spin-confirm');
    }

    try {
        if (typeof showToast === 'function') showToast('🌀 กำลังเริ่มหมุนลูกบาศก์...');
        const res = await apiClient.startSpinCube(cubeToSpin.id, currency, cubeToSpin.slot_index || 0);
        if (res && res.status === 'success') {
            const hasAura = Boolean(res.has_aura);
            const msg = res.message || (hasAura
                ? '🎉 เริ่มหมุนลูกบาศก์แบบเต็มเวลา MAX พร้อมรับออร่าเรืองแสง!'
                : '🎉 เริ่มหมุนลูกบาศก์นำโชคเรียบร้อยแล้ว!');
            if (typeof showToast === 'function') showToast(msg);
            if (window.soundEngine && typeof window.soundEngine.playSuccess === 'function') {
                window.soundEngine.playSuccess();
            }

            // 📱 ตั้งเวลาแจ้งเตือนที่หน้าจอมือถือเมื่อหมุนเสร็จ (Phone Screen Notification)
            const spinDurSec = Number(res.remaining_seconds || (cubeToSpin.min_hours ? cubeToSpin.min_hours * 3600 : 3600));
            if (typeof window.schedulePhoneNotification === 'function') {
                window.schedulePhoneNotification({
                    title: '🔮 ลูกบาศก์นำโชคหมุนเสร็จแล้ว!',
                    body: `${cubeToSpin.cube_name || 'ลูกบาศก์นำโชค'} ในช่อง ${cubeToSpin.slot_index || 1} หมุนเสร็จสมบูรณ์แล้ว! เข้ามากดรับเพชรและทองรางวัลใหญ่กันเถอะ`,
                    id: 7700 + Number(cubeToSpin.slot_index || 1),
                    scheduleAtMs: Date.now() + (spinDurSec * 1000)
                });
            }
            if (apiClient && typeof apiClient.getProfile === 'function') {
                const prof = await apiClient.getProfile();
                if (prof && prof.data) {
                    const u = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? DEFAULT_USER : (window.DEFAULT_USER || {});
                    Object.assign(u, prof.data);
                    if (typeof updateUserBar === 'function') updateUserBar(u);
                }
            }
            await loadMagicCubesData();
        } else {
            const msg = (res && res.message) ? res.message : 'ทรัพยากรไม่เพียงพอ';
            if (typeof showInGameAlert === 'function') {
                showInGameAlert(msg, 'แจ้งเตือน', '⚠️');
            } else if (typeof showToast === 'function') {
                showToast(msg);
            }
        }
    } catch (e) {
        const err = e.message || 'เกิดข้อผิดพลาดในการเริ่มหมุน';
        if (typeof showInGameAlert === 'function') {
            showInGameAlert(err, 'ข้อผิดพลาด', '❌');
        } else if (typeof showToast === 'function') {
            showToast(err);
        }
    }
};

let pendingCubeRewardData = null;

window.speedupCubeAction = async function (userCubeId, costDiamond) {
    showInGameConfirm(`ต้องการใช้ 💎 ${costDiamond} เพชร เพื่อเปิดลูกบาศก์นี้ทันทีใช่หรือไม่?`, async () => {
        try {
            const res = await apiClient.speedupCube(userCubeId);
            if (res && (res.status === 'success' || res.claimed || res.reward)) {
                // เปิดหน้าต่างสุ่มรางวัลเปิดลูกบาศก์เหมือนสุ่มการ์ดทันที
                window.openCubeGachaRevealModal(res);

                if (res.user) {
                    DEFAULT_USER.diamond = Number(res.user.diamond ?? DEFAULT_USER.diamond);
                    DEFAULT_USER.gold = Number(res.user.gold ?? DEFAULT_USER.gold);
                    updateUserBar(DEFAULT_USER);
                } else if (apiClient && typeof apiClient.getProfile === 'function') {
                    const prof = await apiClient.getProfile().catch(() => null);
                    if (prof && prof.data) {
                        Object.assign(DEFAULT_USER, prof.data);
                        updateUserBar(DEFAULT_USER);
                    }
                }
                await loadMagicCubesData();
            } else {
                showInGameAlert((res && res.message) ? res.message : 'เพชรไม่เพียงพอสำหรับการเปิดทันที', 'แจ้งเตือน', '⚠️');
            }
        } catch (e) {
            showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการเปิดลูกบาศก์', 'ข้อผิดพลาด', '❌');
        }
    });
};

window.claimCubeRewardAction = async function (userCubeId) {
    try {
        const res = await apiClient.claimCubeReward(userCubeId);
        if (res && res.status === 'success') {
            window.openCubeGachaRevealModal(res);
            await loadMagicCubesData();
        } else {
            showInGameAlert((res && res.message) ? res.message : 'ไม่สามารถรับรางวัลได้', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการรับรางวัล', 'ข้อผิดพลาด', '❌');
    }
};

window.openCubeGachaRevealModal = function (rewardData) {
    if (!rewardData) return;
    pendingCubeRewardData = rewardData;

    const modal = document.getElementById('modal-cube-reward');
    if (!modal) return;

    const stageBurst = document.getElementById('cube-reveal-stage-burst');
    const stageCards = document.getElementById('cube-reveal-stage-cards');
    const svgWrap = document.getElementById('cube-burst-svg-wrap');
    const burstTitle = document.getElementById('cube-burst-title');
    const burstSub = document.getElementById('cube-burst-sub');
    const cardsRow = document.getElementById('cube-reward-cards-row');
    const cardsTitle = document.getElementById('cube-cards-title');

    const cubeType = rewardData.cube_type || 'SILVER';
    const cubeName = rewardData.cube_name || 'ลูกบาศก์นำโชค';
    const colorHex = rewardData.color_hex || '#00e5ff';

    // 1. Stage 1: Floating 3D Cube with Glow
    if (stageBurst) stageBurst.style.display = 'flex';
    if (stageCards) stageCards.style.display = 'none';

    if (burstTitle) burstTitle.innerText = `กำลังเปิด ${cubeName}...`;
    if (burstSub) burstSub.innerText = 'ลุ้นรับรางวัลทอง, เพชร และไอเทมระดับแรร์!';

    if (svgWrap) {
        svgWrap.style.transform = 'scale(1.0)';
        svgWrap.style.filter = 'none';
        svgWrap.innerHTML = window.getMagicCubeSvgHtml(cubeType, true, 72, true, true);
    }

    modal.style.display = 'flex';

    if (window.soundEngine && typeof window.soundEngine.playDiceRoll === 'function') {
        try { window.soundEngine.playDiceRoll(); } catch (e) { }
    }

    // 2. After 0.9s, burst open with sound
    setTimeout(() => {
        if (svgWrap) {
            svgWrap.style.transform = 'scale(1.26) rotate(10deg)';
            svgWrap.style.filter = 'drop-shadow(0 0 24px #fff) brightness(1.6)';
        }
        if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
            try { window.soundEngine.playWin(); } catch (e) { }
        }
    }, 850);

    // 3. Stage 2: Reveal Cards Row (เหมือนสุ่มการ์ด)
    setTimeout(() => {
        if (stageBurst) stageBurst.style.display = 'none';
        if (stageCards) stageCards.style.display = 'block';

        if (cardsTitle) {
            cardsTitle.innerHTML = `🎉 เปิด <strong>${cubeName}</strong> สำเร็จ! ได้รับรางวัล:`;
        }

        let list = Array.isArray(rewardData.rewards_list) ? rewardData.rewards_list : [];
        if (list.length === 0) {
            if (rewardData.reward_gold > 0) {
                list.push({
                    type: 'GOLD',
                    amount: rewardData.reward_gold,
                    title: `+${Number(rewardData.reward_gold).toLocaleString()} ทอง`,
                    subtitle: 'เหรียญทองเข้าคลัง',
                    grade: rewardData.reward_gold >= 500000 ? 'SS+' : (rewardData.reward_gold >= 100000 ? 'S' : 'A+'),
                    icon: '💰',
                    color: '#f59e0b'
                });
            }
            if (rewardData.reward_diamond > 0) {
                list.push({
                    type: 'DIAMOND',
                    amount: rewardData.reward_diamond,
                    title: `+${Number(rewardData.reward_diamond).toLocaleString()} เพชร`,
                    subtitle: 'เพชรล้ำค่าเข้าคลัง',
                    grade: rewardData.reward_diamond >= 500 ? 'SS+' : (rewardData.reward_diamond >= 100 ? 'S' : 'A+'),
                    icon: '💎',
                    color: '#00e5ff'
                });
            }
            if (rewardData.reward && rewardData.reward.type !== 'GOLD' && rewardData.reward.type !== 'DIAMOND') {
                list.unshift({
                    type: rewardData.reward.type,
                    amount: 1,
                    title: rewardData.reward.label || 'ไอเทมพิเศษ',
                    subtitle: 'ไอเทมพิเศษส่งเข้าคลัง',
                    grade: 'SS+',
                    icon: rewardData.reward.type === 'FRAME' ? '👑' : (rewardData.reward.type === 'DICE' ? '🎲' : '🧊'),
                    color: '#ec4899'
                });
            }
        }

        if (cardsRow) {
            cardsRow.innerHTML = list.map((item, idx) => {
                const borderCol = item.color || '#38bdf8';
                const grade = item.grade || 'S';
                let gradeBg = 'rgba(56,189,248,0.2)';
                let gradeTextCol = '#38bdf8';
                if (grade === 'SS+') {
                    gradeBg = 'linear-gradient(135deg, #ec4899, #f43f5e)';
                    gradeTextCol = '#fff';
                } else if (grade === 'S') {
                    gradeBg = 'linear-gradient(135deg, #f59e0b, #d97706)';
                    gradeTextCol = '#000';
                }

                // ตรวจสอบและคำนวณระดับออร่าเมื่อเป็นของรางวัลเพชร (มากน้อยขึ้นอยู่กับจำนวนเพชร)
                const isDiamond = (item.type === 'DIAMOND');
                let diaAmount = 0;
                let diaTier = 0;
                let diaAuraClass = '';
                let diaAuraHtml = '';
                let diaBadgeHtml = '';

                if (isDiamond) {
                    diaAmount = Number(item.amount) || 0;
                    if (!diaAmount && typeof item.title === 'string') {
                        const m = item.title.replace(/,/g, '').match(/\d+/);
                        if (m) diaAmount = parseInt(m[0], 10);
                    }

                    // จัดลำดับเทียร์ออร่าเพชรตามจำนวนที่ได้รับ
                    if (diaAmount >= 700) {
                        diaTier = 4; // ระดับเทพเจ้าสุริยะ (1,000+ เพชร SS+)
                        diaAuraClass = 'dia-aura-tier-4';
                        diaBadgeHtml = '<div class="dia-aura-badge dia-aura-badge-t4">🌟 AURA GODLY ✨</div>';
                        diaAuraHtml = `
                            <div class="dia-godly-rays-backdrop"></div>
                            <div class="dia-card-shimmer-sweep"></div>
                            <div class="dia-sparkle-container">
                                <span class="dia-sparkle-star dsp-1">✨</span>
                                <span class="dia-sparkle-star dsp-2">💎</span>
                                <span class="dia-sparkle-star dsp-3">🌟</span>
                                <span class="dia-sparkle-star dsp-4">✨</span>
                                <span class="dia-sparkle-star dsp-5">✦</span>
                                <span class="dia-sparkle-star dsp-6">💎</span>
                                <span class="dia-sparkle-star dsp-7">✨</span>
                                <span class="dia-sparkle-star dsp-8">★</span>
                            </div>
                        `;
                    } else if (diaAmount >= 300) {
                        diaTier = 3; // ระดับทรงพลังมหาศาล (300-699 เพชร)
                        diaAuraClass = 'dia-aura-tier-3';
                        diaBadgeHtml = '<div class="dia-aura-badge dia-aura-badge-t3">⚡ AURA EPIC ✨</div>';
                        diaAuraHtml = `
                            <div class="dia-card-shimmer-sweep"></div>
                            <div class="dia-sparkle-container">
                                <span class="dia-sparkle-star dsp-1">✨</span>
                                <span class="dia-sparkle-star dsp-2">✦</span>
                                <span class="dia-sparkle-star dsp-3">💎</span>
                                <span class="dia-sparkle-star dsp-4">✨</span>
                                <span class="dia-sparkle-star dsp-5">✧</span>
                                <span class="dia-sparkle-star dsp-6">🌟</span>
                            </div>
                        `;
                    } else if (diaAmount >= 100) {
                        diaTier = 2; // ระดับประกายฟ้าชัดเจน (100-299 เพชร)
                        diaAuraClass = 'dia-aura-tier-2';
                        diaBadgeHtml = '<div class="dia-aura-badge dia-aura-badge-t2">✨ AURA</div>';
                        diaAuraHtml = `
                            <div class="dia-sparkle-container">
                                <span class="dia-sparkle-star dsp-1">✨</span>
                                <span class="dia-sparkle-star dsp-2">✦</span>
                                <span class="dia-sparkle-star dsp-3">✨</span>
                                <span class="dia-sparkle-star dsp-4">✧</span>
                            </div>
                        `;
                    } else {
                        diaTier = 1; // ระดับออร่าฟ้าอ่อนประกาย (<100 เพชร)
                        diaAuraClass = 'dia-aura-tier-1';
                        diaAuraHtml = `
                            <div class="dia-sparkle-container">
                                <span class="dia-sparkle-star dsp-1">✨</span>
                                <span class="dia-sparkle-star dsp-4">✨</span>
                            </div>
                        `;
                    }
                }

                return `
                    <div class="cube-reward-card-item ${diaAuraClass}" style="
                        flex: 1 1 0;
                        width: 118px;
                        max-width: 132px;
                        min-width: 102px;
                        background: linear-gradient(160deg, rgba(30,43,68,0.92) 0%, rgba(15,23,40,0.98) 100%);
                        border: none;
                        border-radius: 14px;
                        padding: 9px 8px 8px 8px;
                        box-shadow: 0 10px 24px rgba(0,0,0,0.7), 0 0 16px ${borderCol}35, inset 0 1px 0 rgba(255,255,255,0.18);
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        position: relative;
                        box-sizing: border-box;
                        animation: modalPopIn 0.35s cubic-bezier(0.16,1,0.3,1);
                        animation-delay: ${idx * 0.12}s;
                        animation-fill-mode: both;
                        overflow: visible;
                    ">
                        ${diaAuraHtml}
                        <div style="position: absolute; top: 5px; left: 6px; font-size: 8.5px; font-weight: 900; padding: 1px 5px; border-radius: 4px; background: ${gradeBg}; color: ${gradeTextCol}; z-index: 5; line-height: 1.2;">
                            ${grade}
                        </div>
                        ${diaBadgeHtml}
                        <div class="${isDiamond ? 'dia-icon-glow' : ''}" style="font-size: 26px; line-height: 1; margin: 14px 0 5px 0; filter: drop-shadow(0 3px 8px rgba(0,0,0,0.6)); position: relative; z-index: 3;">
                            ${item.icon || '🎁'}
                        </div>
                        <div style="font-size: 11.5px; font-weight: 900; color: #fff; line-height: 1.2; margin-bottom: 2px; text-shadow:0 2px 6px rgba(0,0,0,0.8); position: relative; z-index: 3; white-space: nowrap; max-width: 100%; overflow: hidden; text-overflow: ellipsis;">
                            ${item.title || ''}
                        </div>
                        <div style="font-size: 9px; color: ${borderCol}; font-weight: 800; line-height: 1.2; position: relative; z-index: 3; white-space: nowrap; max-width: 100%; overflow: hidden; text-overflow: ellipsis;">
                            ${item.subtitle || ''}
                        </div>
                    </div>
                `;
            }).join('');
        }
    }, 1150);
};

window.closeCubeRewardModal = function () {
    const modal = document.getElementById('modal-cube-reward');
    if (modal) modal.style.display = 'none';
};

window.confirmClaimCubeReward = function () {
    const data = pendingCubeRewardData;
    window.closeCubeRewardModal();

    if (window.soundEngine && typeof window.soundEngine.playSuccess === 'function') {
        try { window.soundEngine.playSuccess(); } catch (e) { }
    }

    if (data) {
        if (data.user) {
            const oldGold = Number(DEFAULT_USER.gold || 0);
            const newGold = Number(data.user.gold ?? oldGold);
            const oldDia = Number(DEFAULT_USER.diamond || 0);
            const newDia = Number(data.user.diamond ?? oldDia);

            DEFAULT_USER.gold = newGold;
            DEFAULT_USER.diamond = newDia;
            updateUserBar(DEFAULT_USER);

            if (typeof window.animateCurrencyCounter === 'function') {
                if (newGold > oldGold) window.animateCurrencyCounter('user-gold', oldGold, newGold, 1200);
                if (newDia > oldDia) window.animateCurrencyCounter('user-diamonds', oldDia, newDia, 1200);
            }
        } else if (apiClient && typeof apiClient.getProfile === 'function') {
            apiClient.getProfile().then(prof => {
                if (prof && prof.data) {
                    Object.assign(DEFAULT_USER, prof.data);
                    updateUserBar(DEFAULT_USER);
                }
            }).catch(() => { });
        }
    }

    if (typeof loadMagicCubesData === 'function') {
        loadMagicCubesData();
    }
};

window.showCubeRewardModal = function (rewardData) {
    window.openCubeGachaRevealModal(rewardData);
};
/**
 * Animate number count up smoothly in top bar with glowing golden pulse effect
 */
window.animateCurrencyCounter = function (elementId, startVal, endVal, duration = 1000) {
    const el = document.getElementById(elementId);
    if (!el || startVal === endVal) return;
    const startTime = performance.now();
    el.style.transition = 'transform 0.2s ease, text-shadow 0.2s ease';
    el.style.transform = 'scale(1.25)';
    el.style.textShadow = '0 0 14px rgba(255, 215, 0, 0.9)';
    el.style.color = '#ffd700';

    function step(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOutQuad = 1 - (1 - progress) * (1 - progress);
        const currentVal = Math.round(startVal + (endVal - startVal) * easeOutQuad);
        el.innerText = currentVal.toLocaleString();
        if (progress < 1) {
            requestAnimationFrame(step);
        } else {
            el.innerText = endVal.toLocaleString();
            setTimeout(() => {
                el.style.transform = '';
                el.style.textShadow = '';
                el.style.color = '';
            }, 300);
        }
    }
    requestAnimationFrame(step);
};

// =========================================================================
// ระบบกล่องข้อความ (Speech Bubble แบบรูปที่ 2), อิโมจิเพียวๆ, อัปเดตอิโมจิล่าสุด และระบบ @ แท็กชื่อผู้เล่น
// =========================================================================

const DEFAULT_RECENT_EMOJIS = ['😍', '😃', '😫', '😖', '😣', '😄', '🌾', '🔥'];

/**
 * ดึงรายการอิโมจิที่ใช้ล่าสุดจาก localStorage
 */
window.getRecentEmojis = function () {
    try {
        const saved = JSON.parse(localStorage.getItem('snake_recent_emojis') || 'null');
        if (Array.isArray(saved) && saved.length > 0) {
            return saved.slice(0, 8);
        }
    } catch (e) { }
    return [...DEFAULT_RECENT_EMOJIS];
};

/**
 * บันทึกอิโมจิที่เพิ่งกดใช้ขึ้นเป็นอันดับแรกในหมวด "ใช้ล่าสุด" และอัปเดต UI ทันที
 */
window.recordRecentEmoji = function (emoji) {
    if (!emoji) return;
    const clean = String(emoji).trim();
    if (!clean) return;

    let list = window.getRecentEmojis().filter(item => item !== clean);
    list.unshift(clean);
    list = list.slice(0, 8);

    try {
        localStorage.setItem('snake_recent_emojis', JSON.stringify(list));
    } catch (e) { }

    window.renderRecentEmojisUI();
};

/**
 * อัปเดตปุ่มอิโมจิในหมวด "ใช้ล่าสุด" ทั้งบนกระดานหลักและในห้องบ้าน 3D
 */
window.renderRecentEmojisUI = function () {
    const list = window.getRecentEmojis();

    const boardGrid = document.getElementById('emoji-recent-grid');
    if (boardGrid) {
        boardGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendPlayerEmoji('${em}')">${em}</button>`
        ).join('');
    }

    const clanGrid = document.getElementById('clan-emoji-recent-grid');
    if (clanGrid) {
        clanGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendClanRoomEmoji('${em}')">${em}</button>`
        ).join('');
    }
};

// เรียกอัปเดตหมวด "ใช้ล่าสุด" ทันทีเมื่อโหลดหน้าเว็บ
setTimeout(() => {
    if (typeof window.renderRecentEmojisUI === 'function') {
        window.renderRecentEmojisUI();
    }
}, 200);

/**
 * ดึงรายชื่อผู้เล่นที่สามารถ @ คุยด้วยได้ (จากผู้เล่นบนกระดาน 3D และสมาชิกในห้องบ้าน 3D)
 */
window.getMentionablePlayers = function () {
    const map = new Map();
    const gameInstance = window.game || window.snakeGame3D;

    // 1. ผู้เล่นบนกระดาน 3D
    if (gameInstance && Array.isArray(gameInstance.players)) {
        gameInstance.players.forEach((p, idx) => {
            if (!p || !p.username) return;
            const cleanName = String(p.username).replace(/^🤖\s*/, '').trim();
            map.set(cleanName, {
                name: cleanName,
                rawName: p.username,
                avatar: p.picture || p.pictureUrl || p.avatar_url || 'avatars/google_avatar.png',
                playerIndex: idx,
                isBot: Boolean(p.is_bot)
            });
        });
    }

    // 2. สมาชิกในห้องบ้าน 3D (ถ้ามี)
    if (typeof currentClanData === 'object' && currentClanData && Array.isArray(currentClanData.members)) {
        currentClanData.members.forEach((m) => {
            if (!m || !m.username) return;
            const cleanName = String(m.username).trim();
            if (!map.has(cleanName)) {
                map.set(cleanName, {
                    name: cleanName,
                    rawName: m.username,
                    avatar: m.avatar_url || 'avatars/google_avatar.png',
                    playerIndex: 0,
                    isBot: false
                });
            }
        });
    }

    return Array.from(map.values());
};

/**
 * แสดงรายการผู้เล่นเมื่อพิมพ์ @ หรือกดปุ่ม @
 */
window.handleChatInputMention = function (inputEl, dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl || !dropdown) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    if (atIndex === -1) {
        dropdown.style.display = 'none';
        return;
    }

    const query = val.substring(atIndex + 1).toLowerCase();
    // หากพิมพ์เว้นวรรคหลังชื่อไปแล้ว ให้ซ่อนเมนู
    if (query.includes(' ')) {
        dropdown.style.display = 'none';
        return;
    }

    const candidates = window.getMentionablePlayers().filter(p =>
        !query || p.name.toLowerCase().includes(query) || p.rawName.toLowerCase().includes(query)
    );

    if (candidates.length === 0) {
        dropdown.style.display = 'none';
        return;
    }

    dropdown.innerHTML = candidates.map(c => {
        const safeName = c.name.replace(/'/g, "\\'");
        return `
            <div class="mention-item" onclick="insertMentionTag('${inputEl.id}', '${dropdownId}', '${safeName}')">
                <img src="${c.avatar}" onerror="this.src='avatars/google_avatar.png'">
                <span>@${c.name}</span>
            </div>
        `;
    }).join('');
    dropdown.style.display = 'block';
};

/**
 * เมื่อกดปุ่ม @ ให้เติมเครื่องหมาย @ ลงในช่องแชทและเปิดรายชื่อคนให้เลือกทันที
 */
window.triggerMentionList = function (inputId, dropdownId) {
    const inputEl = document.getElementById(inputId);
    if (!inputEl) return;

    if (!inputEl.value.endsWith('@')) {
        inputEl.value = (inputEl.value ? inputEl.value.trimEnd() + ' ' : '') + '@';
    }
    inputEl.focus();
    window.handleChatInputMention(inputEl, dropdownId);
};

/**
 * เมื่อคลิกเลือกชื่อคนที่ต้องการ @ จากรายการ
 */
window.insertMentionTag = function (inputId, dropdownId, targetName) {
    const inputEl = document.getElementById(inputId);
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    const cleanTag = targetName.replace(/\s+/g, '_');

    if (atIndex !== -1) {
        inputEl.value = val.substring(0, atIndex) + `@${cleanTag} `;
    } else {
        inputEl.value = `@${cleanTag} ` + val;
    }

    if (dropdown) dropdown.style.display = 'none';
    inputEl.focus();
};

let mentionPillTimer = null;

window.dismissMentionPill = function () {
    const pill = document.getElementById('mention-notification-pill');
    if (pill) pill.classList.remove('show');
    if (mentionPillTimer) {
        clearTimeout(mentionPillTimer);
        mentionPillTimer = null;
    }
};

/**
 * แจ้งเตือนเมื่อมีคน @ หา: "ชื่อ..พูดถึงคุณ"
 */
window.notifyUserMentioned = function (speakerName = 'ผู้เล่น', messageText = '', avatarUrl = '') {
    const rawSpeaker = String(speakerName || 'ผู้เล่น').trim();
    const rawMsg = String(messageText || '').trim();

    // 1. แสดงกล่องแจ้งเตือน Mention Notification Pill ลอยเด่นกึ่งกลางด้านบน
    const pill = document.getElementById('mention-notification-pill');
    const authorEl = document.getElementById('mention-pill-author');
    const textEl = document.getElementById('mention-pill-text');
    const avatarEl = document.getElementById('mention-pill-avatar');

    if (authorEl) authorEl.innerText = rawSpeaker;
    if (textEl) textEl.innerText = rawMsg || 'พูดถึงคุณ';
    if (avatarEl && avatarUrl) avatarEl.src = avatarUrl;

    if (pill) {
        pill.classList.remove('show');
        void pill.offsetWidth; // Force CSS reflow
        pill.classList.add('show');

        if (mentionPillTimer) clearTimeout(mentionPillTimer);
        mentionPillTimer = setTimeout(() => {
            pill.classList.remove('show');
        }, 5000);
    }

    // 2. ส่งเสียงแจ้งเตือนแบบ Chime
    if (window.soundEngine && typeof window.soundEngine.playNotification === 'function') {
        window.soundEngine.playNotification();
    } else if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        window.soundEngine.playClick();
    }

    // 3. แสดงข้อความ Toast เสริมความชัดเจน
    if (typeof window.showToast === 'function') {
        window.showToast(`🔔 ${rawSpeaker} พูดถึงคุณ`, 4500);
    }

    // 4. บันทึกลง Game Log
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        gameInstance.logMessage(`🔔 ${rawSpeaker} พูดถึงคุณ: "${rawMsg}"`, 'highlight');
    }
};

/**
 * ตรวจสอบว่าข้อความแชทมีการ @ หาตัวผู้เล่นคนปัจจุบันหรือไม่
 */
window.checkIfMessageMentionsMe = function (text) {
    if (!text) return false;
    const str = String(text);
    const myName = (window.DEFAULT_USER && window.DEFAULT_USER.username) || '';
    const myGameName = (window.game && window.game.players && window.game.players[0] && window.game.players[0].username) || '';

    if (str.includes('@คุณ')) return true;
    if (myName && str.includes(`@${myName}`)) return true;
    if (myGameName && str.includes(`@${myGameName}`)) return true;

    const lower = str.toLowerCase();
    if (myName && lower.includes(`@${myName.toLowerCase()}`)) return true;
    if (myGameName && lower.includes(`@${myGameName.toLowerCase()}`)) return true;

    return false;
};

/**
 * ฟังก์ชันกลางสำหรับเรียกแสดงกล่องข้อความ (Speech Bubble) หรืออิโมจิบนหัวตัวละคร 3D
 * @param {string} message ข้อความหรืออิโมจิที่ต้องการให้แสดง
 * @param {number} playerIndex ลำดับตัวละครบนกระดาน (ค่าเริ่มต้น 0 = ตัวละครของผู้เล่นหลัก)
 * @param {number} durationMs ระยะเวลาแสดงผลก่อนค่อยๆ จางหายไป (3000 - 5000 ms, ค่าเริ่มต้น 4000 ms)
 */
window.showSpeechBubble = function (message, playerIndex = 0, durationMs = 4000) {
    const text = String(message || '').trim();
    if (!text) return;

    // เชื่อมต่อกับอินสแตนซ์กระดาน 3D (window.game หรือ window.snakeGame3D)
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.showSpeechBubble === 'function') {
        gameInstance.showSpeechBubble(playerIndex, text, durationMs);
    }

    // หากคนพูดเป็นผู้เล่นอื่น (playerIndex !== 0) และข้อความมี @ หาเรา ให้แจ้งเตือนทันที!
    if (playerIndex !== 0 && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
        let speakerName = 'ผู้เล่น';
        let speakerAvatar = 'avatars/google_avatar.png';
        if (gameInstance && Array.isArray(gameInstance.players) && gameInstance.players[playerIndex]) {
            const p = gameInstance.players[playerIndex];
            speakerName = p.username || p.displayName || 'ผู้เล่น';
            speakerAvatar = p.avatar_url || p.picture || 'avatars/google_avatar.png';
        }
        if (typeof window.notifyUserMentioned === 'function') {
            window.notifyUserMentioned(speakerName, text, speakerAvatar);
        }
    }
};

/**
 * เปิด/ปิด หน้าต่างเลือกอิโมจิและส่งข้อความด่วน
 */
window.toggleEmojiChatPopover = function (forceClose = false) {
    const popover = document.getElementById('emoji-chat-popover');
    if (!popover) return;

    if (forceClose === true) {
        popover.style.display = 'none';
        const dd = document.getElementById('board-mention-dropdown');
        if (dd) dd.style.display = 'none';
        return;
    }

    const isVisible = popover.style.display !== 'none' && popover.style.display !== '';
    popover.style.display = isVisible ? 'none' : 'block';

    if (!isVisible) {
        window.renderRecentEmojisUI();
        const input = document.getElementById('input-speech-message');
        if (input) {
            setTimeout(() => input.focus(), 60);
        }
    }
};

/**
 * เมื่อผู้เล่นคลิกเลือกอิโมจิจากถาดอิโมจิ ให้แสดงเป็นตัวอิโมจิบนหัวรูปภาพทันที และอัปเดตหมวด "ใช้ล่าสุด"
 */
window.sendPlayerEmoji = function (emoji) {
    if (!emoji) return;

    // 1. บันทึกและอัปเดตอิโมจิล่าสุดขึ้นอันดับ 1 ในหมวด "ใช้ล่าสุด"
    window.recordRecentEmoji(emoji);

    // 2. แสดงอิโมจิเพียวๆ บนหัวรูปภาพตัวหมากของผู้เล่น (index 0) นาน 4 วินาที
    window.showSpeechBubble(emoji, 0, 4000);

    // 3. บันทึกลง Game Log ด้านขวาด้วย
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: ${emoji}`, 'highlight');
    }

    window.toggleEmojiChatPopover(true);
};

/**
 * เมื่อผู้เล่นพิมพ์ข้อความแชท (รองรับ @ชื่อผู้เล่น) และกดส่ง หรือกดปุ่ม Enter
 */
window.sendPlayerChatMessage = function () {
    const input = document.getElementById('input-speech-message');
    if (!input) return;

    const msg = input.value.trim();
    if (!msg) return;

    // 1. แสดงข้อความในกล่องข้อความทรงวงรีสีขาวขอบดำ (แบบรูปที่ 2) บนหัวรูปภาพตัวละครของผู้เล่น
    window.showSpeechBubble(msg, 0, 4500);

    const gameInstance = window.game || window.snakeGame3D;

    // 2. บันทึกลง Game Log ด้านขวา (ปิดระบบบอทตอบกลับข้อความอัตโนมัติ 100%)
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: "${msg}"`, 'highlight');
    }

    input.value = '';
    const dd = document.getElementById('board-mention-dropdown');
    if (dd) dd.style.display = 'none';
    window.toggleEmojiChatPopover(true);
};

// ปิดถาดเลือกอิโมจิเมื่อคลิกพื้นที่ว่างข้างนอก
document.addEventListener('click', function (e) {
    const popover = document.getElementById('emoji-chat-popover');
    const triggerBtn = document.getElementById('btn-toggle-emoji');
    if (popover && popover.style.display !== 'none') {
        if (!popover.contains(e.target) && (!triggerBtn || !triggerBtn.contains(e.target))) {
            popover.style.display = 'none';
        }
    }

    const clanEmojiPop = document.getElementById('clan-room-emoji-popover');
    const clanEmojiBtn = document.getElementById('btn-clan-room-emoji');
    if (clanEmojiPop && clanEmojiPop.style.display !== 'none') {
        if (!clanEmojiPop.contains(e.target) && (!clanEmojiBtn || !clanEmojiBtn.contains(e.target))) {
            clanEmojiPop.style.display = 'none';
        }
    }
});



// ==========================================================================
// 3D BOARD CATALOG, RULES & SPECIAL TILES (ROOM & MATCHMAKING FLOW)
// ==========================================================================
const BOARD_CATALOG = {
    classic: {
        id: 'classic',
        name: 'นีออนไซเบอร์ 3D (Cyber Neon)',
        shortName: 'นีออนไซเบอร์ 3D',
        badge: 'CYBER NEON',
        themeColor: '#00e5ff',
        auraDesc: 'ธีมไซไฟล้ำยุค เรืองแสงนีออนฟ้า-ชมพู คมชัดทุกสายตา',
        features: ['• แสงนีออนคมชัดสูง', '• สังเกตตำแหน่งง่าย'],
        story: 'สังเวียนการแข่งขันใจกลางมหานครไซเบอร์พังก์ ล้อมรอบด้วยสถาปัตยกรรมดิจิทัลแห่งโลกอนาคต เส้นทางเชื่อมต่อด้วยบันไดลำแสงไฮเทค และพญางูเลเซอร์เรืองแสงสีชมพู ทุกย่างก้าวเต็มไปด้วยความเร็วและพลังงานนีออน',
        specialBonus: '⚡ ทัศนวิสัยคมชัดสูงพิเศษ แสงนีออนสะท้อนพื้นผิวบอร์ด 3D สังเกตตำแหน่งบันไดและงูได้ง่ายที่สุด',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="cyberBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#070b14"/><stop offset="50%" stop-color="#0c2340"/><stop offset="100%" stop-color="#034168"/></linearGradient><filter id="cyberGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#cyberBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#111c30" stroke="#00e5ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#00e5ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00e5ff" stroke-width="3.5" filter="url(#cyberGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00e5ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00e5ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00e5ff" stroke-width="2"/><path d="M 36 -36 Q 0 -12 24 24 T -12 36" fill="none" stroke="#ff0055" stroke-width="3.5" filter="url(#cyberGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#ff0055"/></g><text x="120" y="108" text-anchor="middle" fill="#00e5ff" font-size="11" font-weight="800" letter-spacing="1">CYBER NEON 3D</text></svg>`
    },
    ancient: {
        id: 'ancient',
        name: 'วิหารทองคำพญานาค (Golden Temple)',
        shortName: 'วิหารทองคำพญานาค',
        badge: 'GOLDEN NAGA',
        themeColor: '#ffd700',
        auraDesc: 'ศาลทองคำโบราณ มนต์ขลังพญานาคราชบันไดทอง',
        features: ['• มนต์โชคพญานาคราช', '• บันไดทองคำสุดเร้าใจ'],
        story: 'มหาปราสาททองคำลอยฟ้าโบราณที่สถิตของพญานาคราชผู้พิทักษ์ บันไดทองคำส่องแสงประกายมนต์ขลัง และงูเขียวมรกตเกล็ดนาคราช ทุกย่างก้าวจะได้รับพรแห่งโชคลาภในการทอยเต๋า',
        specialBonus: '👑 มนต์มหาโชคพญานาคราช เสริมบารมีแก่ผู้เล่นที่ก้าวขึ้นบันไดทองคำสู่เส้นชัย',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="ancientBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1f1406"/><stop offset="50%" stop-color="#422d0d"/><stop offset="100%" stop-color="#694a16"/></linearGradient><filter id="goldGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#ancientBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#33240e" stroke="#ffd700" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ffd700" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffd700" stroke-width="3.5" filter="url(#goldGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffd700" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffd700" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffd700" stroke-width="2"/><path d="M 36 -36 Q 10 -5 20 20 T -20 24" fill="none" stroke="#00e676" stroke-width="3.5" filter="url(#goldGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#00e676"/></g><text x="120" y="108" text-anchor="middle" fill="#ffd700" font-size="11" font-weight="800" letter-spacing="1">GOLDEN NAGA 3D</text></svg>`
    },
    lava: {
        id: 'lava',
        name: 'ภูเขาไฟลาวาเดือด (Lava Volcano)',
        shortName: 'ภูเขาไฟลาวาเดือด',
        badge: 'LAVA VOLCANO',
        themeColor: '#ff5722',
        auraDesc: 'ธารหินหลอมละลายร้อนแรง การแข่งขันสุดดุเดือดท้าทาย',
        features: ['• บรรยากาศลาวาไฟแดง', '• เลือดร้อนสุดมันส์'],
        story: 'ดินแดนปากปล่องภูเขาไฟใต้พิภพที่ปะทุด้วยลาวาเดือดพล่าน บันไดเหล็กหลอมเพลิงและพญางูดำอัคคี บรรยากาศร้อนระอุบีบคั้นการตัดสินใจ ผู้กล้าเท่านั้นที่จะพิชิตสู่ยอดเขา',
        specialBonus: '🔥 บรรยากาศเกมเร้าใจ ปลุกสัญชาตญาณความกระหายชัยชนะ การชิงตำแหน่งและหลบหลีกงูเพลิงสุดระทึก',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="lavaBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#240808"/><stop offset="50%" stop-color="#471111"/><stop offset="100%" stop-color="#751b14"/></linearGradient><filter id="lavaGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#lavaBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#2b0d0d" stroke="#ff5722" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ff3d00" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffab00" stroke-width="3" filter="url(#lavaGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffab00" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffab00" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffab00" stroke-width="2"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#212121" stroke-width="4.5"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#ff3d00" stroke-width="1.8" filter="url(#lavaGlow)"/><circle cx="36" cy="-36" r="4" fill="#ff1744"/></g><text x="120" y="108" text-anchor="middle" fill="#ff5722" font-size="11" font-weight="800" letter-spacing="1">LAVA VOLCANO 3D</text></svg>`
    },
    ice: {
        id: 'ice',
        name: 'แดนน้ำแข็งคริสตัล (Crystal Ice)',
        shortName: 'แดนน้ำแข็งคริสตัล',
        badge: 'CRYSTAL ICE',
        themeColor: '#38bdf8',
        auraDesc: 'มหาธารน้ำแข็งคริสตัลขั้วโลก แสงออโรร่าประกายแก้ว',
        features: ['• บรรยากาศน้ำแข็งสีฟ้า', '• เย็นชื่นใจทุกย่างก้าว'],
        story: 'ยอดเขาน้ำแข็งนิรันดร์ที่ปกคลุมด้วยผลึกคริสตัลใสประกายระยิบระยับ แสงออโรร่าสีฟ้าน้ำทะเลร่ายรำบนท้องฟ้า บันไดผลึกแก้วใสและงูหมอกมนตราสีม่วง เงียบสงบแต่เยือกเย็นและเฉียบคม',
        specialBonus: '❄️ แสงสะท้อนประกายแก้ว สบายตา สมาธิตั้งมั่น วางกลยุทธ์การเดินได้อย่างเยือกเย็น',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="iceBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#051524"/><stop offset="50%" stop-color="#0f3554"/><stop offset="100%" stop-color="#1e5987"/></linearGradient><filter id="iceGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#iceBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#0f2a3d" stroke="#80d8ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#80d8ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00b0ff" stroke-width="3" filter="url(#iceGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00b0ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00b0ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00b0ff" stroke-width="2"/><path d="M 36 -36 Q 10 -5 22 22 T -18 30" fill="none" stroke="#a855f7" stroke-width="3.5" filter="url(#iceGlow)"/><circle cx="36" cy="-36" r="4" fill="#a855f7"/></g><text x="120" y="108" text-anchor="middle" fill="#80d8ff" font-size="11" font-weight="800" letter-spacing="1">CRYSTAL ICE 3D</text></svg>`
    }
};

const ROOM_TIER_CONFIG = {
    '2M': {
        tier: '2M',
        room_tier: '2M',
        title: 'ห้อง 2M (ยอดนิยม)',
        fee: 2000,
        entry_fee_gold: 2000,
        start_match_gold: 2000000,
        winDia: 200,
        winGold: 100000,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '⚡ รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 2,000 💰 • ทองเริ่มต้นในกระดาน: 2,000,000 💰 | ชนะรับ: 200 💎 + 100,000 💰'
    },
    '5M': {
        tier: '5M',
        room_tier: '5M',
        title: 'ห้อง 5M (ระดับเซียน)',
        fee: 5000,
        entry_fee_gold: 5000,
        start_match_gold: 5000000,
        winDia: 500,
        winGold: 300000,
        tax_amount: 120000,
        tax_percent: 22,
        city_base_cost: 300000,
        landmark_cost: 800000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🔥 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 5,000 💰 • ทองเริ่มต้นในกระดาน: 5,000,000 💰 | ชนะรับ: 500 💎 + 300,000 💰'
    },
    '10M': {
        tier: '10M',
        room_tier: '10M',
        title: 'ห้อง 10M (มหาเศรษฐี)',
        fee: 10000,
        entry_fee_gold: 10000,
        start_match_gold: 10000000,
        winDia: 1200,
        winGold: 800000,
        tax_amount: 250000,
        tax_percent: 25,
        city_base_cost: 600000,
        landmark_cost: 1600000,
        toll_percent: 90,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '👑 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 10,000 💰 • ทองเริ่มต้นในกระดาน: 10,000,000 💰 | ชนะรับ: 1,200 💎 + 800,000 💰'
    },
    'PRACTICE': {
        tier: 'PRACTICE',
        room_tier: 'PRACTICE',
        title: 'โหมดทดลองเล่น',
        fee: 0,
        entry_fee_gold: 0,
        start_match_gold: 2000000,
        winDia: 0,
        winGold: 0,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🎯 ฝึกซ้อมฟรี',
        desc: 'เล่นฟรีไม่เสียค่าเข้า • ทองเริ่มต้นในกระดาน: 2,000,000 💰'
    }
};

window.getActiveRoomEconomyConfig = function (tier = null) {
    const key = String(tier || window.currentActiveRoomTier || (window.isPracticeMatch ? 'PRACTICE' : currentLobbyTier) || '2M').toUpperCase();
    return ROOM_TIER_CONFIG[key] || ROOM_TIER_CONFIG['2M'];
};

window.loadRoomConfigs = async function () {
    try {
        if (!window.apiClient || typeof window.apiClient.getRoomConfigs !== 'function') return;
        const res = await window.apiClient.getRoomConfigs();
        if (!res || res.status !== 'success' || !res.rooms) return;

        Object.entries(res.rooms).forEach(([tierKey, r]) => {
            const t = String(tierKey).toUpperCase();
            if (!ROOM_TIER_CONFIG[t]) ROOM_TIER_CONFIG[t] = { tier: t, room_tier: t, defaultMode: '2P' };
            const cfg = ROOM_TIER_CONFIG[t];
            cfg.title = r.room_title || cfg.title || `ห้อง ${t}`;
            cfg.fee = Number(r.entry_fee_gold ?? cfg.fee ?? 2000);
            cfg.entry_fee_gold = cfg.fee;
            cfg.start_match_gold = Number(r.start_match_gold ?? cfg.start_match_gold ?? 2000000);
            cfg.winDia = Number(r.reward_diamond ?? cfg.winDia ?? 0);
            cfg.winGold = Number(r.reward_gold ?? cfg.winGold ?? 0);
            cfg.tax_amount = Number(r.tax_amount ?? cfg.tax_amount ?? 50000);
            cfg.tax_percent = Number(r.tax_percent ?? cfg.tax_percent ?? 20);
            cfg.city_base_cost = Number(r.city_base_cost ?? cfg.city_base_cost ?? 120000);
            cfg.landmark_cost = Number(r.landmark_cost ?? cfg.landmark_cost ?? 320000);
            cfg.toll_percent = Number(r.toll_percent ?? cfg.toll_percent ?? 85);
            cfg.buyout_percent = Number(r.buyout_percent ?? cfg.buyout_percent ?? 160);
            cfg.odd_even_diamond_cost = Number(r.odd_even_diamond_cost ?? cfg.odd_even_diamond_cost ?? 5);
            cfg.desc = `ค่าผ่านทางเข้าเล่น: ${cfg.fee.toLocaleString()} ทอง • ทองเริ่มต้นในกระดาน: ${cfg.start_match_gold.toLocaleString()} ทอง | ชนะรับ: ${cfg.winDia.toLocaleString()} 💎 + ${cfg.winGold.toLocaleString()} ทอง`;

            // อัปเดตการ์ดห้องในหน้า Lobby แบบสดๆ
            const elTitle = document.getElementById(`room-title-${t}`);
            const elFee = document.getElementById(`room-fee-${t}`);
            const elStart = document.getElementById(`room-startgold-${t}`);
            const elDia = document.getElementById(`room-dia-${t}`);
            const elGold = document.getElementById(`room-gold-${t}`);
            if (elTitle) elTitle.innerText = cfg.title;
            if (elFee) elFee.innerText = cfg.fee.toLocaleString();
            if (elStart) elStart.innerText = cfg.start_match_gold.toLocaleString();
            if (elDia) elDia.innerText = `💎 ${cfg.winDia.toLocaleString()} เพชร`;
            if (elGold) elGold.innerText = `💰 ${cfg.winGold.toLocaleString()} ทอง`;
        });
    } catch (e) {
        console.warn('loadRoomConfigs warning:', e);
    }
};

let currentLobbyTier = '2M';
let currentLobbyMode = '2P';
let currentLobbyBoard = localStorage.getItem('snake_board_theme') || 'ancient';
let activeInfoBoardId = 'ancient';

window.selectLobbyLayout = function (layoutType) {
    currentSelectedBoardLayout = layoutType;
    try {
        localStorage.setItem('snake_board_layout', layoutType);
    } catch (e) { }
    if (layoutType !== 'all') {
        if (window.game && typeof window.game.setBoardLayout === 'function') {
            window.game.setBoardLayout(layoutType);
        }
    }
    window.updateLobbyLayoutUIState();
    window.renderLobbyBoardsGrid();
    if (typeof showToast === 'function') {
        const names = { all: 'ทั้งหมด (27 กระดาน)', square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'วงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม', diamond_ring: 'วงแหวนเพชร' };
        showToast('🗺️ แสดงผังกระดาน 3D: ' + (names[layoutType] || layoutType));
    }
};

window.updateLobbyLayoutUIState = function () {
    const layout = currentSelectedBoardLayout || 'all';
    ['all', 'square', 'spiral', 'hexagon', 'diamond_ring'].forEach(l => {
        const btn = document.getElementById('lobby-layout-btn-' + l);
        if (btn) {
            if (l === layout) btn.classList.add('active');
            else btn.classList.remove('active');
        }
    });
    const display = document.getElementById('lobby-active-layout-display');
    if (display) {
        const labels = {
            all: '✨ ทั้งหมด (All 27 Boards)',
            square: '🟩 สี่เหลี่ยมดั้งเดิม (Classic Square)',
            spiral: '🌀 ทรงกลมก้นหอย (Spiral Galaxy)',
            hexagon: '⬡ ทรงหกเหลี่ยมรังผึ้ง (Hexagon Hive)',
            diamond_ring: '❖ วงแหวนเพชร (Diamond Ring)'
        };
        display.textContent = labels[layout] || labels.all;
    }
};

window.selectLobbyRoom = function (tier = '2M') {
    currentLobbyTier = tier;
    window.goToBoardStep();
};

window.goToBoardStep = function () {
    // Switch views in modal: Show Step 2 (Boards)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'block';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '🗺️ ขั้นตอนที่ 2/3: เลือกกระดาน 3D & แผนที่';

    // Update Room Banner
    const isPractice = (currentLobbyTier === 'PRACTICE');
    const isFriendRoom = (currentLobbyTier === 'FRIEND_ROOM');
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const pill = document.getElementById('lobby-active-room-pill');
    const desc = document.getElementById('lobby-active-room-desc');
    if (pill) {
        pill.innerText = isPractice ? '🎯 โหมดทดลองเล่นเดี่ยว (1 ต่อ 1)' : (isFriendRoom ? '🔑 เล่นกับเพื่อน (รหัสเชิญ AI)' : cfg.title);
    }
    if (desc) {
        desc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : (isFriendRoom ? 'เลือกกระดาน 3D แล้วไปหน้ารอเล่นเพื่อรับรหัสเชิญ AI หรือใส่รหัสจากเพื่อน' : cfg.desc);
    }

    const btnNext = document.querySelector('#lobby-view-boards .btn-start-match');
    const btnNextText = document.querySelector('#lobby-view-boards .btn-start-match span');
    if (btnNextText) {
        btnNextText.innerText = isPractice
            ? 'ถัดไป: เลือกลำดับเล่น & สิทธิ์เริ่มก่อน ➔'
            : (isFriendRoom ? 'ถัดไป: ไปหน้ารอเล่นกับเพื่อน (รหัสเชิญ AI) ➔' : 'ถัดไป: เลือกคู่แข่ง & โหมดแข่งขัน ➔');
    }

    // Update Layout selector pills (In Monopoly mode, show Monopoly boards header; in Snake mode, show 3D shapes)
    const isMonopolyMode = (String(window.selectedHomeGameMode || '').toUpperCase() === 'MONOPOLY')
        || (window.game && window.game.isMonopolyBoardMode);
    if (btnNext) {
        btnNext.style.display = isMonopolyMode ? 'none' : 'inline-flex';
    }
    const layoutCard = document.querySelector('#lobby-view-boards .lobby-section-card');
    if (layoutCard) {
        const pillsRow = layoutCard.querySelector('.lobby-layout-pills-row');
        const layoutDisp = document.getElementById('lobby-active-layout-display');
        if (isMonopolyMode) {
            if (pillsRow) pillsRow.style.display = 'none';
            if (layoutDisp) {
                const monCount = Array.isArray(window.MONOPOLY_BOARDS_LIST) ? window.MONOPOLY_BOARDS_LIST.length : 0;
                layoutDisp.textContent = monCount > 0
                    ? `🏦 กระดานเกมส์เศรษฐีทั้งหมด (${monCount} กระดาน • 9 ช่อง/แถว • 32 ช่อง)`
                    : '🏦 กระดานเกมส์เศรษฐีทั้งหมด (9 ช่อง/แถว • 32 ช่อง)';
            }
        } else {
            if (pillsRow) pillsRow.style.display = 'flex';
            window.updateLobbyLayoutUIState();
        }
    } else {
        window.updateLobbyLayoutUIState();
    }

    // Render Board Grid & Selected Monopoly Board Banner
    window.renderLobbyBoardsGrid();
    if (typeof window.renderLobbySelectedMonopolyBoard === 'function') {
        window.renderLobbySelectedMonopolyBoard();
    }

    if (isMonopolyMode && (!Array.isArray(window.MONOPOLY_BOARDS_LIST) || window.MONOPOLY_BOARDS_LIST.length === 0)) {
        try {
            const url = (typeof window.getSnakeApiEndpoint === 'function')
                ? window.getSnakeApiEndpoint('api/monopoly_board_service.php?action=get_boards')
                : 'api/monopoly_board_service.php?action=get_boards';
            fetch(url).then(r => r.json()).then(res => {
                if (res && res.status === 'success' && Array.isArray(res.boards) && res.boards.length > 0) {
                    window.MONOPOLY_BOARDS_LIST = res.boards;
                    if (!window.ACTIVE_MONOPOLY_BOARD) {
                        window.ACTIVE_MONOPOLY_BOARD = res.boards.find(b => b.is_default) || res.boards[0];
                    }
                    if (typeof window.renderHomeMonopolyBoardSelect === 'function') {
                        window.renderHomeMonopolyBoardSelect();
                    }
                    const layoutDisp = document.getElementById('lobby-active-layout-display');
                    if (layoutDisp) {
                        layoutDisp.textContent = `🏦 กระดานเกมส์เศรษฐีทั้งหมด (${res.boards.length} กระดาน • 9 ช่อง/แถว • 32 ช่อง)`;
                    }
                    window.renderLobbyBoardsGrid();
                    if (typeof window.renderLobbySelectedMonopolyBoard === 'function') {
                        window.renderLobbySelectedMonopolyBoard();
                    }
                }
            }).catch(() => { });
        } catch (e) { }
    }

    // Fetch AI boards if not loaded yet (Snake mode)
    if (!isMonopolyMode && !(window.availableAiCustomBoards || []).length && typeof window.fetchAndApplyActiveAiBoards === 'function') {
        window.fetchAndApplyActiveAiBoards().then(() => {
            window.renderLobbyBoardsGrid();
        }).catch(() => { });
    }
};

window.renderLobbySelectedMonopolyBoard = function () {
    const box = document.getElementById('lobby-selected-monopoly-board-box');
    if (!box) return;

    const isMonopoly = (String(window.selectedHomeGameMode || '').toUpperCase() === 'MONOPOLY')
        || (window.game && window.game.isMonopolyBoardMode);

    if (!isMonopoly) {
        box.style.display = 'none';
        return;
    }

    let boardObj = window.ACTIVE_MONOPOLY_BOARD || null;
    const sel = document.getElementById('select-home-monopoly-board');
    if (sel && sel.value && Array.isArray(window.MONOPOLY_BOARDS_LIST)) {
        const matched = window.MONOPOLY_BOARDS_LIST.find(b => String(b.id) === String(sel.value));
        if (matched) boardObj = matched;
    }

    let boardName = boardObj?.name || '';
    if (!boardName && sel && sel.selectedIndex >= 0 && sel.options[sel.selectedIndex]) {
        boardName = sel.options[sel.selectedIndex].text || '';
    }
    if (!boardName) {
        boardName = 'มหานครสยาม & จังหวัดไทย (กระดานหลัก)';
    }

    const nameEl = document.getElementById('lobby-selected-monopoly-name');
    const metaEl = document.getElementById('lobby-selected-monopoly-meta');
    if (nameEl) nameEl.textContent = boardName;
    if (metaEl) {
        const tileCount = Array.isArray(boardObj?.tiles) && boardObj.tiles.length > 0 ? boardObj.tiles.length : 32;
        metaEl.textContent = `9 ช่อง/แถว • ${tileCount} ช่อง`;
    }

    box.style.display = 'flex';
};

window.backToRoomSelect = function () {
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'block';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '⚔️ ห้องแข่งขัน & เลือกกระดาน 3D';
};

window.goToLobbyModeSelect = function () {
    // Switch views: Show Step 3 (Opponents / Players count & Match mode)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'block';

    const isPractice = (currentLobbyTier === 'PRACTICE');
    const isFriendRoom = (currentLobbyTier === 'FRIEND_ROOM');
    const compBlock = document.getElementById('lobby-competitive-modes-block');
    const pracBlock = document.getElementById('lobby-practice-turn-block');
    const friendBlock = document.getElementById('lobby-friend-waiting-block');
    const footerStartBtn = document.getElementById('lobby-footer-start-match-btn');

    if (footerStartBtn) {
        footerStartBtn.style.display = isPractice ? 'inline-flex' : 'none';
    }

    if (title) {
        title.innerText = isPractice
            ? '🎲 ขั้นตอนที่ 3/3: เลือกสิทธิ์การเล่นก่อน-หลัง (โหมดทดลองเล่น)'
            : (isFriendRoom
                ? '🔑 ขั้นตอนที่ 3/3: หน้ารอเล่นกับเพื่อน (รหัสเชิญ AI & เข้าร่วมห้อง)'
                : '👥 ขั้นตอนที่ 3/3: เลือกคู่แข่ง & รูปแบบแข่งขัน');
    }

    if (compBlock) compBlock.style.display = (!isPractice && !isFriendRoom) ? 'block' : 'none';
    if (pracBlock) pracBlock.style.display = isPractice ? 'block' : 'none';
    if (friendBlock) friendBlock.style.display = isFriendRoom ? 'block' : 'none';

    // Update Summary Banner in Step 3
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const board = BOARD_CATALOG[currentLobbyBoard] || BOARD_CATALOG.classic;
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    const layoutNames = { square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'ทรงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม' };
    const modeRoomPill = document.getElementById('mode-summary-room-pill');
    const modeBoardPill = document.getElementById('mode-summary-board-pill');
    const modeSummaryDesc = document.getElementById('mode-summary-desc');

    if (modeRoomPill) {
        modeRoomPill.innerText = isPractice ? '🎯 โหมดทดลองเล่น (1v1)' : (isFriendRoom ? '🔑 เล่นกับเพื่อน' : `🏆 ${cfg.title}`);
    }
    if (modeBoardPill) {
        modeBoardPill.innerText = `🗺️ แผนที่: ${board.name} (${layoutNames[layout] || layout})`;
    }
    if (modeSummaryDesc) {
        modeSummaryDesc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : `ค่าเข้า: ${(cfg.fee || 2000).toLocaleString()} 💰 • ชนะรับ: ${(cfg.winDia || 200).toLocaleString()} 💎 + ${(cfg.winGold || 100000).toLocaleString()} 💰`;
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        if (isPractice) {
            btnText.innerText = '🚀 เริ่มทดลองเล่นทันที';
        } else {
            const modeLabel = (currentLobbyMode === '2P') ? '1 ต่อ 1' : ((currentLobbyMode === '3P') ? 'เดี่ยว 3' : ((currentLobbyMode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
            btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
        }
    }

    if (isPractice) {
        if (typeof window.updateTurnOrderUIState === 'function') {
            window.updateTurnOrderUIState();
        }
    } else if (isFriendRoom) {
        if (typeof window.initFriendWaitingRoomStep === 'function') {
            window.initFriendWaitingRoomStep();
        }
    } else {
        window.setLobbyGameMode(currentLobbyMode || '2P');
    }
};

window.backToBoardSelect = function () {
    window.goToBoardStep();
};

window.handleLobbyModeCardClick = function (mode) {
    if (currentLobbyMode === mode) {
        if (mode === 'TEAM') {
            const teamPanel = document.getElementById('lobby-team-setup-panel');
            if (teamPanel) {
                teamPanel.style.display = 'block';
                teamPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
            if (window.teamPlaySubMode === 'INVITE' && !window.invitedTeamPartner) {
                if (typeof showToast === 'function') showToast('👥 กรุณาเชิญเพื่อนที่กำลังออนไลน์เข้าร่วมทีมก่อนเริ่มเกมส์');
                return;
            }
        }
        window.confirmLobbyMatch();
    } else {
        window.setLobbyGameMode(mode);
    }
};

window.setLobbyGameMode = function (mode = '2P') {
    currentLobbyMode = mode;
    ['2P', '3P', '4P', 'TEAM'].forEach(m => {
        const card = document.getElementById('mode-card-' + m);
        const actionSlot = document.getElementById('mode-action-' + m);
        if (card) {
            if (m === mode) {
                card.classList.add('active', 'selected');
                if (actionSlot) {
                    if (m === 'TEAM') {
                        actionSlot.innerHTML = `
                            <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:center; width:100%;">
                                <button type="button" class="btn-mode-start glow-btn" style="flex:1; min-width:110px; font-size:11.5px; padding:6px 8px;" onclick="if(typeof window.selectTeamPlaySubMode==='function') window.selectTeamPlaySubMode('RANDOM'); window.startTeamRandomMatch(); event.stopPropagation();">🎲 สุ่มค้นหาเพื่อน</button>
                                <button type="button" class="btn-mode-select" style="flex:1; min-width:110px; font-size:11.5px; padding:6px 8px; background:linear-gradient(135deg,#7e22ce,#a855f7); color:#fff; border-color:#c084fc;" onclick="if(typeof window.selectTeamPlaySubMode==='function') window.selectTeamPlaySubMode('INVITE'); event.stopPropagation();">👥 เชิญเพื่อนออนไลน์</button>
                            </div>
                        `;
                    } else {
                        actionSlot.innerHTML = `<button type="button" class="btn-mode-start glow-btn" onclick="confirmLobbyMatch(); event.stopPropagation();">🚀 เริ่มแข่งขัน</button>`;
                    }
                }
            } else {
                card.classList.remove('active', 'selected');
                if (actionSlot) {
                    actionSlot.innerHTML = `<button type="button" class="btn-mode-select" onclick="setLobbyGameMode('${m}'); event.stopPropagation();">แตะเพื่อเลือก</button>`;
                }
            }
        }
    });

    const teamPanel = document.getElementById('lobby-team-setup-panel');
    if (teamPanel) {
        if (mode === 'TEAM') {
            teamPanel.style.display = 'block';
            if (typeof window.initTeamLobbySetupPanel === 'function') {
                window.initTeamLobbySetupPanel();
            }
            setTimeout(() => {
                try { teamPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
            }, 80);
        } else {
            teamPanel.style.display = 'none';
            window.invitedTeamPartner = null;
        }
    }

    const hint = document.getElementById('lobby-mode-hint');
    if (hint) {
        if (mode === '2P') hint.innerText = '👤 ดวลเดี่ยวตัวต่อตัว 2 คน (1 ต่อ 1)';
        else if (mode === '3P') hint.innerText = '🥉 ประลอง 3 ผู้เล่น ตะลุมบอน 3 ทิศทาง (เดี่ยว 3)';
        else if (mode === '4P') hint.innerText = '👑 ตะลุมบอน 4 ผู้เล่น อิสระทุกคน (เดี่ยว 4 คน)';
        else if (mode === 'TEAM') hint.innerText = '🛡️ แท็กทีม 2v2: เลือกสุ่มค้นหาเพื่อน หรือเชิญเพื่อนออนไลน์ (ในบ้าน / นอกบ้าน)';
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        const modeLabel = (mode === '2P') ? '1 ต่อ 1' : ((mode === '3P') ? 'เดี่ยว 3' : ((mode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
        btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
    }
};

window.scrollLobbyBoards = function (direction) {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    const scrollAmount = 296 * direction;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
};

function attachLobbyBoardsDragScroll(container) {
    if (!container || container._hasDragAttached) return;
    container._hasDragAttached = true;

    let isDown = false;
    let startX = 0;
    let scrollLeft = 0;

    container.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return;
        isDown = true;
        container._isDragging = false;
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
    });

    container.addEventListener('mouseleave', () => {
        isDown = false;
    });

    container.addEventListener('mouseup', () => {
        setTimeout(() => { container._isDragging = false; }, 50);
        isDown = false;
    });

    container.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 1.5;
        if (Math.abs(walk) > 6) {
            container._isDragging = true;
        }
        container.scrollLeft = scrollLeft - walk;
    });

    container.addEventListener('wheel', (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            container.scrollLeft += e.deltaY;
        }
    }, { passive: false });
}

window.selectLobbyBoard = function (boardId, autoAdvanceToStep3 = true) {
    currentLobbyBoard = boardId;
    // Check if this is an AI custom board (numeric ID)
    if (!isNaN(Number(boardId)) && Number(boardId) > 0) {
        // AI Board - use selectCustomAiBoardPlayer
        if (typeof window.selectCustomAiBoardPlayer === 'function') {
            window.selectCustomAiBoardPlayer(Number(boardId), false);
        }
    } else {
        // Built-in board - cancel any active custom board
        if (window.game && typeof window.game.cancelCustomBoardConfig === 'function') {
            window.game.cancelCustomBoardConfig();
        }
        try { localStorage.removeItem('snake_active_custom_board_id'); } catch (e) { }
        if (window.game && typeof window.game.setBoardTheme === 'function') {
            window.game.setBoardTheme(boardId);
        }
    }
    window.renderLobbyBoardsGrid();
    if (autoAdvanceToStep3 && typeof window.goToLobbyModeSelect === 'function') {
        window.goToLobbyModeSelect();
    }
};

// Generate SVG preview for AI custom boards based on shape_type & theme_config
// 🎨 Generate High-Fidelity 3D Isometric Board Preview (รูปตัวอย่างกระดาน 3D สมจริงตามรูป 2)
window.generateAiBoardSvg = function (board) {
    var tc = board.theme_config || {};
    var borderColor = tc.border || '#00e5ff';
    var bgColor = tc.bgColor || '#091528';
    var tileEven = tc.tileEven || '#14253d';
    var tileOdd = tc.tileOdd || '#1b3252';
    var ladderColor = tc.ladder || '#ffd700';
    var snakeColor = tc.snake || '#ef4444';
    var shape = board.shape_type || 'rectangle';
    var uid = 'b_' + (board.id || Math.random().toString(36).substr(2, 6));
    var boardName = (board.board_name || 'AI 3D Board').substring(0, 24);

    var innerContent = '';

    if (shape === 'spiral') {
        var spiralTiles = '';
        var rings = 4;
        for (var ri = 0; ri < rings; ri++) {
            var rx = 85 - ri * 18;
            var ry = 44 - ri * 9.5;
            var strokeW = 12 - ri * 1.5;
            var col = (ri % 2 === 0) ? tileEven : tileOdd;
            spiralTiles += '<ellipse cx="140" cy="70" rx="' + rx + '" ry="' + ry + '" fill="none" stroke="' + col + '" stroke-width="' + strokeW + '" stroke-dasharray="' + (14 + ri * 4) + ' 4"/>';
            spiralTiles += '<ellipse cx="140" cy="70" rx="' + rx + '" ry="' + ry + '" fill="none" stroke="' + borderColor + '66" stroke-width="0.8"/>';
        }
        innerContent = '<ellipse cx="140" cy="76" rx="98" ry="52" fill="#08101d" stroke="' + borderColor + '88" stroke-width="1.2"/>'
            + '<ellipse cx="140" cy="70" rx="98" ry="52" fill="' + bgColor + '" stroke="' + borderColor + '" stroke-width="2.4" filter="url(#glow_' + uid + ')"/>'
            + spiralTiles
            + '<ellipse cx="140" cy="70" rx="14" ry="7.5" fill="' + borderColor + '" opacity="0.85" filter="url(#glow_' + uid + ')"/>'
            + '<ellipse cx="140" cy="70" rx="7" ry="3.8" fill="#fff"/>'
            + '<g opacity="0.95" filter="url(#glow_' + uid + ')">'
            + '<line x1="90" y1="84" x2="128" y2="72" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<line x1="94" y1="87" x2="132" y2="75" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<line x1="98" y1="83" x2="102" y2="86" stroke="' + ladderColor + '" stroke-width="1.8"/>'
            + '<line x1="112" y1="78" x2="116" y2="81" stroke="' + ladderColor + '" stroke-width="1.8"/>'
            + '<path d="M 175 62 Q 155 78 135 68" fill="none" stroke="' + snakeColor + '" stroke-width="3.6" stroke-linecap="round"/>'
            + '<circle cx="175" cy="62" r="3.8" fill="' + snakeColor + '"/>'
            + '</g>';
    } else if (shape === 'hexagon') {
        var hexTiles = '';
        var hexPoints = [
            [140, 48], [118, 60], [162, 60], [96, 72], [140, 72], [184, 72],
            [118, 84], [162, 84], [140, 96]
        ];
        hexPoints.forEach(function (pt, idx) {
            var hx = pt[0], hy = pt[1];
            var col = (idx % 2 === 0) ? tileEven : tileOdd;
            var isCenter = (idx === 4);
            var fCol = isCenter ? (ladderColor + '44') : col;
            var strCol = isCenter ? ladderColor : (borderColor + '77');
            hexTiles += '<polygon points="' + hx + ',' + (hy - 12) + ' ' + (hx + 16) + ',' + (hy - 6) + ' ' + (hx + 16) + ',' + (hy + 6) + ' ' + hx + ',' + (hy + 12) + ' ' + (hx - 16) + ',' + (hy + 6) + ' ' + (hx - 16) + ',' + (hy - 6) + '" fill="' + fCol + '" stroke="' + strCol + '" stroke-width="1.2"/>';
        });
        innerContent = '<polygon points="140,24 235,52 235,88 140,116 45,88 45,52" fill="#08101d" stroke="' + borderColor + '88" stroke-width="1.2"/>'
            + '<polygon points="140,20 235,48 235,82 140,110 45,82 45,48" fill="' + bgColor + '" stroke="' + borderColor + '" stroke-width="2.4" filter="url(#glow_' + uid + ')"/>'
            + hexTiles
            + '<g opacity="0.95" filter="url(#glow_' + uid + ')">'
            + '<line x1="90" y1="84" x2="135" y2="58" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<line x1="95" y1="87" x2="140" y2="61" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<path d="M 180 62 Q 155 78 120 72" fill="none" stroke="' + snakeColor + '" stroke-width="3.6" stroke-linecap="round"/>'
            + '<circle cx="180" cy="62" r="3.8" fill="' + snakeColor + '"/>'
            + '</g>';
    } else if (shape === 'diamond_ring') {
        innerContent = '<ellipse cx="140" cy="76" rx="98" ry="48" fill="#08101d" stroke="' + borderColor + '88" stroke-width="1.2"/>'
            + '<ellipse cx="140" cy="70" rx="98" ry="48" fill="' + tileOdd + '" stroke="' + borderColor + '" stroke-width="2.4" filter="url(#glow_' + uid + ')"/>'
            + '<ellipse cx="140" cy="70" rx="82" ry="38" fill="none" stroke="' + tileEven + '" stroke-width="16" stroke-dasharray="14 3"/>'
            + '<ellipse cx="140" cy="70" rx="42" ry="19" fill="#020617" stroke="' + borderColor + '" stroke-width="1.8"/>'
            + '<ellipse cx="140" cy="70" rx="30" ry="13" fill="' + borderColor + '" opacity="0.25" filter="url(#glow_' + uid + ')"/>'
            + '<g opacity="0.95" filter="url(#glow_' + uid + ')">'
            + '<line x1="85" y1="82" x2="115" y2="56" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<line x1="90" y1="85" x2="120" y2="59" stroke="' + ladderColor + '" stroke-width="2.6"/>'
            + '<path d="M 185 64 Q 165 82 145 76" fill="none" stroke="' + snakeColor + '" stroke-width="3.6" stroke-linecap="round"/>'
            + '<circle cx="185" cy="64" r="3.8" fill="' + snakeColor + '"/>'
            + '</g>';
    } else {
        // 🟩 สี่เหลี่ยม / ผืนผ้า 3D แบบภาพถ่ายจริง (Isometric 3D Board matching รูป 2)
        var tilesGrid = '';
        var cols = 6;
        var rows = 6;
        for (var r = 0; r < rows; r++) {
            for (var c = 0; c < cols; c++) {
                var u0 = c / cols, u1 = (c + 0.90) / cols;
                var v0 = r / rows, v1 = (r + 0.90) / rows;

                var x0 = 140 + (u0 * 88) - (v0 * 88);
                var y0 = 26 + (u0 * 43) + (v0 * 43);

                var x1 = 140 + (u1 * 88) - (v0 * 88);
                var y1 = 26 + (u1 * 43) + (v0 * 43);

                var x2 = 140 + (u1 * 88) - (v1 * 88);
                var y2 = 26 + (u1 * 43) + (v1 * 43);

                var x3 = 140 + (u0 * 88) - (v1 * 88);
                var y3 = 26 + (u0 * 43) + (v1 * 43);

                var isAlt = (r + c) % 2 === 0;
                var isSpecial = (r === 0 && c === cols - 1) || (r === 2 && c === 2) || (r === rows - 1 && c === 1);
                var tileFill = isSpecial ? (ladderColor + '44') : (isAlt ? tileEven : tileOdd);
                var strokeCol = isSpecial ? ladderColor : (borderColor + '55');

                tilesGrid += '<polygon points="' + x0.toFixed(1) + ',' + y0.toFixed(1) + ' ' + x1.toFixed(1) + ',' + y1.toFixed(1) + ' ' + x2.toFixed(1) + ',' + y2.toFixed(1) + ' ' + x3.toFixed(1) + ',' + y3.toFixed(1) + '" fill="' + tileFill + '" stroke="' + strokeCol + '" stroke-width="0.8"/>';
            }
        }

        innerContent = '<polygon points="42,70 140,118 140,126 42,78" fill="#0a121e" stroke="' + borderColor + '88" stroke-width="0.8"/>'
            + '<polygon points="140,118 238,70 238,78 140,126" fill="#060c14" stroke="' + borderColor + '88" stroke-width="0.8"/>'
            + '<polygon points="140,22 238,70 140,118 42,70" fill="' + bgColor + '" stroke="' + borderColor + '" stroke-width="2.2" filter="url(#glow_' + uid + ')"/>'
            + '<polygon points="140,25 234,69 140,115 46,69" fill="none" stroke="' + borderColor + '66" stroke-width="1.0"/>'
            + tilesGrid
            + '<g opacity="0.95" filter="url(#glow_' + uid + ')">'
            + '<line x1="102" y1="92" x2="158" y2="48" stroke="' + ladderColor + '" stroke-width="2.4"/>'
            + '<line x1="109" y1="95" x2="165" y2="51" stroke="' + ladderColor + '" stroke-width="2.4"/>'
            + '<line x1="106" y1="91" x2="112" y2="94" stroke="' + ladderColor + '" stroke-width="1.6"/>'
            + '<line x1="118" y1="81" x2="124" y2="84" stroke="' + ladderColor + '" stroke-width="1.6"/>'
            + '<line x1="130" y1="71" x2="136" y2="74" stroke="' + ladderColor + '" stroke-width="1.6"/>'
            + '<line x1="142" y1="61" x2="148" y2="64" stroke="' + ladderColor + '" stroke-width="1.6"/>'
            + '<line x1="154" y1="51" x2="160" y2="54" stroke="' + ladderColor + '" stroke-width="1.6"/>'
            + '</g>'
            + '<g opacity="0.95" filter="url(#glow_' + uid + ')">'
            + '<path d="M 182 54 Q 155 76 138 68 T 92 82" fill="none" stroke="' + snakeColor + '" stroke-width="3.6" stroke-linecap="round"/>'
            + '<path d="M 182 54 Q 155 76 138 68 T 92 82" fill="none" stroke="#fff" stroke-width="1.2" opacity="0.6" stroke-linecap="round"/>'
            + '<circle cx="182" cy="54" r="4.2" fill="' + snakeColor + '"/>'
            + '<circle cx="182" cy="54" r="2.2" fill="#ffeb3b"/>'
            + '<circle cx="182" cy="54" r="1.1" fill="#000"/>'
            + '</g>'
            + '<ellipse cx="58" cy="74" rx="8" ry="4.5" fill="#00e5ff" opacity="0.85" filter="url(#glow_' + uid + ')"/>'
            + '<ellipse cx="58" cy="74" rx="4" ry="2.2" fill="#fff"/>';
    }

    return '<svg viewBox="0 0 280 140" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:12px;">'
        + '<defs>'
        + '<linearGradient id="bg_' + uid + '" x1="0" y1="0" x2="0" y2="1">'
        + '<stop offset="0%" stop-color="#040812"/>'
        + '<stop offset="60%" stop-color="' + bgColor + '"/>'
        + '<stop offset="100%" stop-color="#020408"/>'
        + '</linearGradient>'
        + '<filter id="glow_' + uid + '">'
        + '<feGaussianBlur stdDeviation="2.5" result="b"/>'
        + '<feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>'
        + '</filter>'
        + '</defs>'
        + '<rect width="280" height="140" fill="url(#bg_' + uid + ')"/>'
        + '<ellipse cx="140" cy="85" rx="95" ry="45" fill="' + borderColor + '" opacity="0.16" filter="url(#glow_' + uid + ')"/>'
        + innerContent
        + '<rect x="40" y="122" width="200" height="15" rx="7.5" fill="rgba(2,6,23,0.88)" stroke="' + borderColor + '88" stroke-width="1"/>'
        + '<text x="140" y="133" text-anchor="middle" fill="' + borderColor + '" font-size="9" font-weight="900" letter-spacing="0.5" font-family="Prompt, sans-serif">' + boardName + '</text>'
        + '</svg>';
};

window.generateMonopolyBoardSvg = function (board) {
    const bgCol = board?.board_bg_color || '#0b2220';
    const centerCol = board?.center_bg_color || '#115e59';
    const borderCol = board?.border_color || '#10b981';
    const tiles = Array.isArray(board?.tiles) && board.tiles.length > 0 ? board.tiles : [];

    // 9x9 Grid coordinate helper (counter-clockwise 1..32, matching Admin Panel)
    const getCoord = (idx1) => {
        const idx = idx1 - 1;
        if (idx <= 8) return { row: 8, col: 8 - idx };
        if (idx <= 16) return { row: 8 - (idx - 8), col: 0 };
        if (idx <= 24) return { row: 0, col: idx - 16 };
        return { row: idx - 24, col: 8 };
    };

    const typeIcons = {
        START: '🚩', ISLAND: '🏝️', OLYMPIC: '🏅', WORLD_TRAVEL: '✈️',
        EXPRESSWAY: '🛣️', GAMBLE: '🎰', DESTROY: '💣', GOD_TILE: '👼',
        CHANCE: '🎁', TAX: '💸', CITY: ''
    };

    const W = 270;
    const H = 162;
    const padX = 28;
    const padY = 6;
    const boardW = W - padX * 2;
    const boardH = H - padY * 2;
    const cellW = boardW / 9;
    const cellH = boardH / 9;

    let cellsSvg = '';
    for (let i = 0; i < 32; i++) {
        const t = tiles[i] || {};
        const pos = getCoord(i + 1);
        const x = padX + pos.col * cellW;
        const y = padY + pos.row * cellH;
        const tCol = t.color || (i === 0 ? '#ef4444' : i === 8 ? '#f59e0b' : i === 16 ? '#38bdf8' : i === 24 ? '#a855f7' : '#34d399');
        const icon = typeIcons[t.type] || '';

        cellsSvg += `<rect x="${(x + 0.8).toFixed(1)}" y="${(y + 0.8).toFixed(1)}" width="${(cellW - 1.6).toFixed(1)}" height="${(cellH - 1.6).toFixed(1)}" rx="2" fill="#0f172a" stroke="${tCol}" stroke-width="0.9"/>`;
        cellsSvg += `<rect x="${(x + 1.2).toFixed(1)}" y="${(y + 1.2).toFixed(1)}" width="${(cellW - 2.4).toFixed(1)}" height="3.2" rx="1" fill="${tCol}"/>`;
        if (icon) {
            cellsSvg += `<text x="${(x + cellW / 2).toFixed(1)}" y="${(y + cellH * 0.78).toFixed(1)}" text-anchor="middle" font-size="6.5">${icon}</text>`;
        }
    }

    const cx = padX + cellW + 2;
    const cy = padY + cellH + 2;
    const cw = cellW * 7 - 4;
    const ch = cellH * 7 - 4;

    return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:8px; background:#060c18;">
        <rect x="${padX - 2}" y="${padY - 2}" width="${boardW + 4}" height="${boardH + 4}" rx="6" fill="${bgCol}" stroke="${borderCol}" stroke-width="2"/>
        <rect x="${cx.toFixed(1)}" y="${cy.toFixed(1)}" width="${cw.toFixed(1)}" height="${ch.toFixed(1)}" rx="5" fill="${centerCol}" stroke="rgba(255,255,255,0.28)" stroke-width="1" stroke-dasharray="3 2"/>
        ${cellsSvg}
        <text x="${W / 2}" y="${H / 2 - 4}" text-anchor="middle" fill="#ffffff" font-size="11" font-weight="900">🏦 เกมเศรษฐี</text>
        <text x="${W / 2}" y="${H / 2 + 9}" text-anchor="middle" fill="#fde047" font-size="7.5" font-weight="800">แถวละ 9 ช่อง • รวม 32 ช่องรอบกรอบ</text>
    </svg>`;
};

window.renderLobbyBoardsGrid = function () {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    container.innerHTML = '';
    container.style.display = 'flex';
    container.style.visibility = 'visible';
    container.style.opacity = '1';
    container.scrollTop = 0;

    // In Monopoly Mode: render all Monopoly boards with 9x9 (32-tile) preview matching Admin Panel
    const isMonopolyMode = (String(window.selectedHomeGameMode || '').toUpperCase() === 'MONOPOLY')
        || (window.game && window.game.isMonopolyBoardMode);

    if (isMonopolyMode) {
        let monBoards = Array.isArray(window.MONOPOLY_BOARDS_LIST) && window.MONOPOLY_BOARDS_LIST.length > 0
            ? window.MONOPOLY_BOARDS_LIST
            : (window.ACTIVE_MONOPOLY_BOARD ? [window.ACTIVE_MONOPOLY_BOARD] : []);

        if (monBoards.length === 0) {
            container.innerHTML = '<div style="padding:24px; text-align:center; width:100%; color:#94a3b8; font-size:12px;">⏳ กำลังโหลดรายการกระดานเกมส์เศรษฐี...</div>';
            return;
        }

        const selEl = document.getElementById('select-home-monopoly-board');
        const activeId = window.ACTIVE_MONOPOLY_BOARD?.id || (selEl ? selEl.value : monBoards[0].id);

        monBoards.forEach(mBoard => {
            const isSelected = String(mBoard.id) === String(activeId);
            const accent = mBoard.border_color || '#10b981';
            const card = document.createElement('div');
            card.className = 'board-preview-card ' + (isSelected ? 'selected' : '');
            card.style.setProperty('--accent-board', accent);
            card.style.setProperty('--glow-board', accent + '66');
            card.style.cursor = 'pointer';

            const previewSvg = window.generateMonopolyBoardSvg(mBoard);
            const tileCount = Array.isArray(mBoard.tiles) && mBoard.tiles.length > 0 ? mBoard.tiles.length : 32;

            const nextBtnLabel = (currentLobbyTier === 'PRACTICE')
                ? 'ถัดไป: เลือกลำดับเล่น ➔'
                : ((currentLobbyTier === 'FRIEND_ROOM') ? 'ถัดไป: รอเล่นกับเพื่อน ➔' : 'ถัดไป: เลือกคู่แข่ง & โหมดแข่งขัน ➔');

            card.innerHTML = `
                <div class="board-visual-preview" style="height: 102px !important; min-height: 102px !important; max-height: 102px !important;">
                    ${mBoard.is_default ? `<span class="board-badge-tag" style="background:${accent}; color:#020617; font-weight:900;">⭐ กระดานหลัก</span>` : ''}
                    ${previewSvg}
                </div>
                <div>
                    <div class="board-card-name" style="font-size:12px;">${mBoard.name || 'กระดานเกมส์เศรษฐี'}</div>
                    <div class="board-card-desc" style="font-size:10px; color:#94a3b8;">🏦 9 ช่อง/แถว • ${tileCount} ช่องรอบกรอบ</div>
                </div>
                <div class="board-card-actions">
                    ${isSelected
                        ? `<button type="button" onclick="event.stopPropagation(); window.goToLobbyModeSelect();"
                                style="width:100%; padding:6px 8px; border-radius:8px; border:none; background:linear-gradient(135deg, #00e5ff, #0284c7); color:#020617; font-size:11px; font-weight:900; cursor:pointer; box-shadow:0 3px 12px rgba(0,229,255,0.45);">
                                ${nextBtnLabel}
                           </button>`
                        : `<div class="board-check-indicator">คลิกเลือกกระดานนี้ ➔</div>`
                    }
                </div>
            `;

            card.onclick = () => {
                if (container._isDragging) return;
                if (isSelected) {
                    window.goToLobbyModeSelect();
                    return;
                }
                if (typeof window.selectHomeMonopolyBoard === 'function') {
                    window.selectHomeMonopolyBoard(mBoard.id);
                }
                const homeSel = document.getElementById('select-home-monopoly-board');
                if (homeSel) homeSel.value = String(mBoard.id);
                window.renderLobbyBoardsGrid();
            };

            container.appendChild(card);
        });

        attachLobbyBoardsDragScroll(container);
        const activeCard = container.querySelector('.board-preview-card.selected');
        if (activeCard) {
            setTimeout(() => {
                activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }, 60);
        }
        return;
    }

    const currentFilter = (typeof currentSelectedBoardLayout !== 'undefined' && currentSelectedBoardLayout) ? currentSelectedBoardLayout : 'all';
    const aiBoards = Array.isArray(window.availableAiCustomBoards) && window.availableAiCustomBoards.length > 0
        ? window.availableAiCustomBoards
        : (Array.isArray(window.STATIC_AI_CUSTOM_BOARDS) ? window.STATIC_AI_CUSTOM_BOARDS : []);

    // Filter built-in boards
    const builtInList = Object.values(BOARD_CATALOG).filter(board => {
        if (currentFilter === 'all') return true;
        if (currentFilter === 'square') return true;
        return false;
    });

    // Filter AI custom boards
    const filteredAiBoards = aiBoards.filter(b => {
        if (currentFilter === 'all') return true;
        if (currentFilter === 'square') return (b.shape_type === 'square' || b.shape_type === 'rectangle');
        return b.shape_type === currentFilter;
    });

    // Update tab counts
    try {
        const countAll = Object.keys(BOARD_CATALOG).length + aiBoards.length;
        const countSquare = Object.keys(BOARD_CATALOG).length + aiBoards.filter(b => b.shape_type === 'square' || b.shape_type === 'rectangle').length;
        const countSpiral = aiBoards.filter(b => b.shape_type === 'spiral').length;
        const countHexagon = aiBoards.filter(b => b.shape_type === 'hexagon').length;
        const countDiamond = aiBoards.filter(b => b.shape_type === 'diamond_ring').length;

        const elAll = document.getElementById('count-tab-all');
        const elSq = document.getElementById('count-tab-square');
        const elSp = document.getElementById('count-tab-spiral');
        const elHex = document.getElementById('count-tab-hexagon');
        const elDia = document.getElementById('count-tab-diamond_ring');

        if (elAll) elAll.innerText = countAll;
        if (elSq) elSq.innerText = countSquare;
        if (elSp) elSp.innerText = countSpiral;
        if (elHex) elHex.innerText = countHexagon;
        if (elDia) elDia.innerText = countDiamond;
    } catch (e) { }

    // 1. Render Built-in boards
    builtInList.forEach(board => {
        try {
            const isSelected = (currentLobbyBoard === board.id);
            const card = document.createElement('div');
            card.className = 'board-preview-card ' + (isSelected ? 'selected' : '');
            card.style.setProperty('--accent-board', board.themeColor || '#00e5ff');
            card.style.setProperty('--glow-board', (board.themeColor || '#00e5ff') + '66');
            card.style.cursor = 'pointer';

            const previewSvg = (typeof window.generateAiBoardSvg === 'function')
                ? window.generateAiBoardSvg({
                    id: board.id,
                    board_name: board.name,
                    shape_type: 'square',
                    theme_config: {
                        border: board.themeColor,
                        bgColor: board.id === 'lava' ? '#240808' : (board.id === 'ancient' ? '#2b1b04' : (board.id === 'ice' ? '#081c30' : '#071828')),
                        tileEven: board.id === 'lava' ? '#3d1212' : (board.id === 'ancient' ? '#3d2808' : (board.id === 'ice' ? '#0e2b47' : '#0d2238')),
                        tileOdd: board.id === 'lava' ? '#240808' : (board.id === 'ancient' ? '#261803' : (board.id === 'ice' ? '#081c30' : '#061624')),
                        ladder: board.id === 'lava' ? '#ff9800' : (board.id === 'ancient' ? '#ffd700' : (board.id === 'ice' ? '#80d8ff' : '#00e5ff')),
                        snake: board.id === 'lava' ? '#ff1744' : (board.id === 'ancient' ? '#00e676' : (board.id === 'ice' ? '#a855f7' : '#ff0055'))
                    }
                })
                : (board.svg || '');

            const tierObj = (typeof ROOM_TIER_CONFIG !== 'undefined' && ROOM_TIER_CONFIG[currentLobbyTier]) ? ROOM_TIER_CONFIG[currentLobbyTier] : null;
            const tierTitle = (currentLobbyTier === 'PRACTICE') ? '🎯 ทดลองเล่น' : (tierObj?.title || 'ห้องแข่งขัน');
            const tierMeta = (currentLobbyTier === 'PRACTICE')
                ? 'เล่นฟรี'
                : ('ค่าเข้า ' + (Number(tierObj?.fee || tierObj?.entry_fee_gold || 2000)).toLocaleString() + ' 💰 | ชนะ +' + (tierObj?.winDia || 50) + ' 💎');

            card.innerHTML = `
                <div class="board-visual-preview" style="height: 102px !important; min-height: 102px !important; max-height: 102px !important;">
                    <span class="board-badge-tag" style="background:${board.themeColor}; color:#020617; font-weight:900;">${board.badge}</span>
                    ${previewSvg}
                </div>
                <div>
                    <div class="board-card-name">${board.name}</div>
                    <div class="board-card-desc">${board.auraDesc}</div>
                    <div style="margin-top:6px; padding:3px 8px; background:rgba(0,229,255,0.08); border:1px solid rgba(0,229,255,0.25); border-radius:6px; font-size:10px; color:#38bdf8; display:flex; align-items:center; justify-content:space-between; gap:4px; flex-wrap:wrap;">
                        <span style="font-weight:700;">${tierTitle}</span>
                        <span style="color:#f8fafc; font-size:9.5px;">${tierMeta}</span>
                    </div>
                </div>
                <div class="board-card-actions">
                    <button type="button" class="btn-board-info-trigger" onclick="openBoardInfoModal('${board.id}', event)">
                        <span>ℹ️</span> คำอธิบาย &amp; ช่องพิเศษ
                    </button>
                    <div class="board-check-indicator">
                        ${isSelected ? '✓ เลือก & ไปต่อ ➔' : 'คลิกเลือก ➔'}
                    </div>
                </div>
            `;

            card.onclick = (e) => {
                if (e.target.closest('.btn-board-info-trigger')) return;
                if (container._isDragging) return;
                window.selectLobbyBoard(board.id, true);
            };

            container.appendChild(card);
        } catch (err) {
            console.warn('Built-in board card render error:', err);
        }
    });

    // 2. Render Filtered AI custom boards
    if (filteredAiBoards.length > 0) {
        if (builtInList.length > 0) {
            const sep = document.createElement('div');
            sep.style.cssText = 'min-width:2px; width:2px; background:linear-gradient(to bottom,transparent,#fde047,transparent); margin:0 8px; border-radius:4px; flex-shrink:0;';
            container.appendChild(sep);
        }

        const shapeIcons = { rectangle: '▭', square: '🟩', spiral: '🌀', hexagon: '⬡', diamond_ring: '❖' };

        filteredAiBoards.forEach(aiBoard => {
            try {
                const isSelected = (String(currentLobbyBoard) === String(aiBoard.id));
                const tc = aiBoard.theme_config || {};
                const borderCol = tc.border || '#00e5ff';
                const chCount = (aiBoard.special_tiles?.chanceTiles || []).length;
                const shapeIcon = shapeIcons[aiBoard.shape_type] || '🗺️';

                const card = document.createElement('div');
                card.className = 'board-preview-card ' + (isSelected ? 'selected' : '');
                card.style.setProperty('--accent-board', borderCol);
                card.style.setProperty('--glow-board', borderCol + '66');
                card.style.cursor = 'pointer';

                const svgPreview = (typeof window.generateAiBoardSvg === 'function') ? window.generateAiBoardSvg(aiBoard) : '';
                const tierObj = (typeof ROOM_TIER_CONFIG !== 'undefined' && ROOM_TIER_CONFIG[currentLobbyTier]) ? ROOM_TIER_CONFIG[currentLobbyTier] : null;
                const tierTitle = (currentLobbyTier === 'PRACTICE') ? '🎯 ทดลองเล่น' : (tierObj?.title || 'ห้องแข่งขัน');
                const tierMeta = (currentLobbyTier === 'PRACTICE')
                    ? 'เล่นฟรี'
                    : ('ค่าเข้า ' + (Number(tierObj?.fee || tierObj?.entry_fee_gold || 2000)).toLocaleString() + ' 💰 | ชนะ +' + (tierObj?.winDia || 50) + ' 💎');

                card.innerHTML = '<div class="board-visual-preview" style="height: 102px !important; min-height: 102px !important; max-height: 102px !important;">'
                    + '<span class="board-badge-tag" style="background:' + borderCol + '; color:#020617; font-size:9.5px; font-weight:900;">' + shapeIcon + ' AI 3D</span>'
                    + svgPreview
                    + '</div>'
                    + '<div>'
                    + '<div class="board-card-name" style="font-size:12.5px;">' + (aiBoard.board_name || 'AI Board') + '</div>'
                    + '<div class="board-card-desc" style="font-size:10px; color:#94a3b8;">' + shapeIcon + ' ' + (aiBoard.shape_type || '') + ' ' + (aiBoard.grid_cols || '') + 'x' + (aiBoard.grid_rows || '') + ' • ' + (aiBoard.total_tiles || 0) + ' ช่อง</div>'
                    + '<div style="margin-top:6px; padding:3px 8px; background:rgba(0,229,255,0.08); border:1px solid rgba(0,229,255,0.25); border-radius:6px; font-size:10px; color:#38bdf8; display:flex; align-items:center; justify-content:space-between; gap:4px; flex-wrap:wrap;">'
                    + '<span style="font-weight:700;">' + tierTitle + '</span>'
                    + '<span style="color:#f8fafc; font-size:9.5px;">' + tierMeta + '</span>'
                    + '</div>'
                    + '<div style="margin-top:5px; display:flex; flex-direction:column; gap:1px;">'
                    + '<span style="font-size:10px; color:#94a3b8;">🎁 การ์ดดวง ' + chCount + ' ช่อง • บันได ' + (aiBoard.ladders ? Object.keys(aiBoard.ladders).length : 0) + ' • งู ' + (aiBoard.snakes ? Object.keys(aiBoard.snakes).length : 0) + '</span>'
                    + (aiBoard.is_default ? '<span style="font-size:10px; color:#fde047; font-weight:800;">⭐ แนะนำโดยระบบ</span>' : '')
                    + '</div></div>'
                    + '<div class="board-card-actions">'
                    + '<div class="board-check-indicator">'
                    + (isSelected ? '✓ เลือก & ไปต่อ ➔' : 'คลิกเลือก ➔')
                    + '</div></div>';

                card.onclick = () => {
                    if (container._isDragging) return;
                    window.selectLobbyBoard(aiBoard.id, true);
                };

                container.appendChild(card);
            } catch (err) {
                console.warn('AI board card render error:', err);
            }
        });
    }

    attachLobbyBoardsDragScroll(container);

    const activeCard = container.querySelector('.board-preview-card.selected');
    if (activeCard) {
        setTimeout(() => {
            activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }, 60);
    }
};

window.confirmLobbyMatch = function () {
    if (currentLobbyMode === 'TEAM' && window.teamPlaySubMode === 'INVITE' && !window.invitedTeamPartner) {
        if (typeof showToast === 'function') {
            showToast('⏳ กรุณาเชิญเพื่อนที่กำลังออนไลน์เข้าร่วมทีมให้ครบ 2/2 ก่อนกดเริ่มเกมส์!');
        }
        const teamPanel = document.getElementById('lobby-team-setup-panel');
        if (teamPanel) {
            teamPanel.style.display = 'block';
            try { teamPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
        }
        return;
    }

    const isAiBoard = (!isNaN(Number(currentLobbyBoard)) && Number(currentLobbyBoard) > 0);
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    try {
        localStorage.setItem('snake_board_layout', layout);
    } catch (e) { }
    if (!isAiBoard) {
        if (window.game && typeof window.game.setBoardLayout === 'function') {
            window.game.setBoardLayout(layout);
        }
        if (window.game && typeof window.game.setBoardTheme === 'function') {
            window.game.setBoardTheme(currentLobbyBoard);
        }
    } else {
        // AI board already applied via selectLobbyBoard -> selectCustomAiBoardPlayer
        if (typeof window.selectCustomAiBoardPlayer === 'function') {
            window.selectCustomAiBoardPlayer(Number(currentLobbyBoard), false);
        }
    }

    if (currentLobbyTier === 'PRACTICE') {
        closeModal('modal-lobby');
        if (typeof window.startExplicitPracticeMatch === 'function') {
            window.startExplicitPracticeMatch();
        }
    } else {
        window.startQuickMatch(currentLobbyTier, currentLobbyMode, currentLobbyBoard);
    }
};

window.openBoardInfoModal = function (boardId = 'classic', event = null) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
    openModal('modal-board-info');
};

function renderBoardInfoModal() {
    const board = BOARD_CATALOG[activeInfoBoardId] || BOARD_CATALOG.classic;
    const nav = document.getElementById('board-info-tabs-nav');
    const body = document.getElementById('board-info-modal-body');

    // Render nav tabs
    if (nav) {
        nav.innerHTML = Object.values(BOARD_CATALOG).map(b => `
            <button class="board-info-tab-btn ${b.id === activeInfoBoardId ? 'active' : ''}" onclick="switchInfoBoardTab('${b.id}')">
                <span>${b.id === 'classic' ? '🌌' : (b.id === 'ancient' ? '🛕' : (b.id === 'lava' ? '🌋' : '❄️'))}</span>
                ${b.shortName}
            </button>
        `).join('');
    }

    if (body) {
        body.innerHTML = `
            <!-- Hero Banner -->
            <div class="board-info-hero" style="background:${board.themeColor}15; border-color:${board.themeColor}55;">
                <div class="board-info-hero-header">
                    <span class="board-info-hero-icon">${board.id === 'classic' ? '🌌' : (board.id === 'ancient' ? '🛕' : (board.id === 'lava' ? '🌋' : '❄️'))}</span>
                    <div>
                        <div style="font-size:11px; font-weight:800; color:${board.themeColor}; text-transform:uppercase; letter-spacing:1px;">แผนที่ / กระดาน 3D</div>
                        <div class="board-info-hero-title">${board.name}</div>
                    </div>
                </div>
                <div class="board-info-hero-story">
                    ${board.story}
                </div>
                <div style="margin-top:10px; font-size:12px; color:${board.themeColor}; font-weight:700;">
                    ${board.specialBonus}
                </div>
            </div>

            <!-- How to play & Win conditions -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🎯</span> กติกาและวิธีเล่น (How to Play & Winning Rules)
                </div>
                <div class="rules-grid">
                    <div class="rule-item">
                        <div class="rule-item-title">🎲 การทอยลูกเต๋า 2 ลูก</div>
                        <div class="rule-item-desc">ทอยลูกเต๋าคู่ ผลรวมแต้ม (2-12) คือจำนวนช่องที่ตัวหมากเดินไปข้างหน้า</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">⚡ ดับเบิ้ลโบนัส (Double)</div>
                        <div class="rule-item-desc">ทอยได้เลขคู่หน้าเหมือนกัน ได้สิทธิ์ทอยต่อทันที! (หากดับเบิ้ล 3 ครั้งติด โดนส่งไปคุกทันที)</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">🏆 เงื่อนไขคว้าชัยชนะ</div>
                        <div class="rule-item-desc">ผู้เล่นที่เดินถึงหรือทะลุ <strong>ช่อง 100</strong> คนแรก คว้าแชมป์ทันที และรับทอง+เพชรของห้อง</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">👥 รูปแบบผู้เล่น</div>
                        <div class="rule-item-desc">เลือกได้ทั้ง <strong>1 ต่อ 1 (2 คน)</strong>, <strong>เดี่ยว 3 (3 คน)</strong>, <strong>เดี่ยว 4 (4 คน)</strong> หรือ <strong>ทีม 2v2</strong> (ใครในทีมถึง 100 ชนะยกทีม)</div>
                    </div>
                </div>
            </div>

            <!-- Special Tiles -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🌟</span> รายการช่องพิเศษทั้งหมดบนกระดานนี้ (Special Tiles)
                </div>
                <div class="special-tiles-grid">
                    <!-- Start -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🚩 จุดเริ่มต้น (Start)</span>
                            <span class="tile-badge-number">ช่อง 1</span>
                        </div>
                        <div class="tile-card-desc">จุดออกสตาร์ท ทุกผู้เล่นเริ่มเดินทางพร้อมกันที่วงกลมสตาร์ทนี้</div>
                    </div>

                    <!-- Goal -->
                    <div class="special-tile-card" style="border-color:rgba(255, 215, 0, 0.4); background:rgba(255, 215, 0, 0.08);">
                        <div class="tile-card-header">
                            <span class="tile-card-title" style="color:#ffd700;">🏆 เส้นชัยสูงสุด (Goal)</span>
                            <span class="tile-badge-number" style="background:#ffd70033; color:#ffd700; border-color:#ffd700;">ช่อง 100</span>
                        </div>
                        <div class="tile-card-desc">ช่องแห่งชัยชนะ เข้าถึงช่องนี้ชนะการแข่งขันทันที รับรางวัลเต็มแม็กซ์</div>
                    </div>

                    <!-- Chance -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎁 ช่องโอกาส (Chance)</span>
                            <span class="tile-badge-number">11, 26, 45, 76</span>
                        </div>
                        <div class="tile-card-desc">สุ่มเปิดการ์ดดวงชะตา: โบนัสทอง 10k-50k, สปีดบูสต์ก้าวหน้า, วาร์ปขึ้นบันได, สลับที่คู่แข่ง</div>
                    </div>

                    <!-- Gamble -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎲 ช่องเสี่ยงโชค (Lucky Gamble)</span>
                            <span class="tile-badge-number">15, 36, 68, 88</span>
                        </div>
                        <div class="tile-card-desc">มินิเกมเสี่ยงดวงลูกเต๋า ลุ้นรับโบนัสทวีคูณทองและเพชรตามดวง</div>
                    </div>

                    <!-- Tax -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">💸 ช่องภาษีเมือง (City Tax)</span>
                            <span class="tile-badge-number">20, 52, 82</span>
                        </div>
                        <div class="tile-card-desc">จ่ายค่าบำรุงเมือง 5,000 ทอง เข้ากองกลางเพื่อพัฒนาอาณาจักร</div>
                    </div>

                    <!-- Jail -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">⛓️ เกาะร้าง / ติดคุก (Jail)</span>
                            <span class="tile-badge-number">ช่อง 10</span>
                        </div>
                        <div class="tile-card-desc">ถูกกักขัง 2 เทิร์น เว้นแต่จะทอยได้แต้มดับเบิ้ล หรือจ่ายเพชรประกันตัว</div>
                    </div>
                </div>

                <!-- Ladders & Snakes breakdown -->
                <div class="ladders-snakes-table">
                    <div class="ladder-list-box">
                        <div class="list-box-title" style="color:#38bdf8;">
                            <span>🪜</span> ช่องบันไดนำโชค (8 แห่ง) - พุ่งทะยานขึ้น
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-ladder">ช่อง 4 ➔ 14</span>
                            <span class="tile-chip chip-ladder">ช่อง 9 ➔ 31</span>
                            <span class="tile-chip chip-ladder">ช่อง 22 ➔ 38</span>
                            <span class="tile-chip chip-ladder" style="border-color:#ffd700; color:#ffd700;">ช่อง 28 ➔ 84 🚀</span>
                            <span class="tile-chip chip-ladder">ช่อง 40 ➔ 59</span>
                            <span class="tile-chip chip-ladder">ช่อง 51 ➔ 67</span>
                            <span class="tile-chip chip-ladder">ช่อง 63 ➔ 81</span>
                            <span class="tile-chip chip-ladder">ช่อง 71 ➔ 91</span>
                        </div>
                    </div>

                    <div class="snake-list-box">
                        <div class="list-box-title" style="color:#fb7185;">
                            <span>🐍</span> ช่องงูพิษอันตราย (8 แห่ง) - สไลด์ตกฮวบ
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-snake">ช่อง 17 ➔ 7</span>
                            <span class="tile-chip chip-snake">ช่อง 54 ➔ 34</span>
                            <span class="tile-chip chip-snake">ช่อง 62 ➔ 19</span>
                            <span class="tile-chip chip-snake">ช่อง 64 ➔ 60</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 87 ➔ 24 💀</span>
                            <span class="tile-chip chip-snake">ช่อง 93 ➔ 73</span>
                            <span class="tile-chip chip-snake">ช่อง 95 ➔ 75</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 99 ➔ 78 ⚠️</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Buttons -->
            <div class="board-info-actions">
                <button class="btn-back-step" onclick="closeModal('modal-board-info')">ปิดหน้าต่าง</button>
                <button class="btn-start-match" onclick="applyAndChooseBoard('${board.id}')" style="background:${board.themeColor}; color:#020617;">
                    ✓ เลือกกระดานนี้เลย
                </button>
            </div>
        `;
    }
}

window.switchInfoBoardTab = function (boardId) {
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
};

window.applyAndChooseBoard = function (boardId) {
    if (typeof window.selectBoardThemeAction === 'function') {
        window.selectBoardThemeAction(boardId);
    }
    if (typeof window.closeModal === 'function') {
        window.closeModal('modal-board-info');
    }
};

/* Side Panels Toggle (พับเก็บ / ขยาย เมนูลัดและข่าวสาร เพื่อดูหน้าจอ 3D เต็มตา) */
(function () {
    // Sync side panels: delegates to robust window.bindSidePanelButton / window.initSidePanelsDefaultShown
    if (typeof window.bindSidePanelButton === 'function') {
        ['left', 'right'].forEach(window.bindSidePanelButton);
    } else if (typeof window.initSidePanelsDefaultShown === 'function') {
        window.initSidePanelsDefaultShown();
    }
})();

/* ===================================================================
   Rewarded Video Ad - Free Daily Diamonds (30 เพชร ฟรี 0/1)
   Compatible with @capacitor-community/admob & Web Simulator
   =================================================================== */
window.adRewardState = {
    enabled: true,
    reward_diamonds: 30,
    claimed_today: 0,
    max_per_day: 1,
    can_claim: true,
    ad_unit_id: 'ca-app-pub-3940256099942544/1712485313'
};

window.renderRewardAdCard = async function () {
    const wrap = document.getElementById('reward-ad-card-topup-wrapper');
    if (!wrap) return;

    // Fetch live status from backend
    try {
        const token = localStorage.getItem('snake_auth_token') || sessionStorage.getItem('snake_auth_token') || '';
        const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
        const resp = await fetch('api/claim_ad_reward.php?action=status', { headers });
        if (resp.ok) {
            const data = await resp.json();
            if (data && data.success) {
                window.adRewardState = { ...window.adRewardState, ...data };
            }
        }
    } catch (e) {
        console.warn('Ad reward status offline check:', e);
    }

    const state = window.adRewardState;
    const isClaimed = (state.claimed_today >= 1);
    const diaAmount = state.reward_diamonds || 30;

    wrap.innerHTML = `
        <div style="
            width: 100%;
            max-width: 320px;
            margin: 0 auto 12px auto;
            background: radial-gradient(circle at 50% 25%, #f97316 0%, #c2410c 60%, #7c2d12 100%);
            border: 2px solid #fbbf24;
            box-shadow: 0 0 25px rgba(245, 158, 11, 0.45), inset 0 0 15px rgba(254, 240, 138, 0.25);
            border-radius: 14px;
            padding: 14px 16px 12px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            overflow: hidden;
            box-sizing: border-box;
        ">
            <!-- Top badge -->
            <div style="position:absolute; top:8px; left:8px; background:linear-gradient(135deg, #fbbf24, #d97706); color:#000; font-size:9.5px; font-weight:900; padding:2px 8px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.4);">
                🔥 รางวัลพิเศษประจำวัน
            </div>

            <!-- Diamond Amount Title -->
            <div style="font-size:20px; font-weight:900; color:#ffffff; text-shadow:0 2px 6px rgba(0,0,0,0.8), 0 0 14px rgba(255,255,255,0.5); margin-top:14px; letter-spacing:0.5px;">
                ${diaAmount} เพชร
            </div>

            <!-- Shiny 3D Diamond Graphic Cluster -->
            <div style="margin: 10px 0 12px 0; position:relative; display:flex; justify-content:center; align-items:center;">
                <div style="position:absolute; width:110px; height:110px; border-radius:50%; background:radial-gradient(circle, rgba(56, 189, 248, 0.6) 0%, rgba(56, 189, 248, 0) 70%); filter:blur(10px);"></div>
                <svg width="125" height="85" viewBox="0 0 140 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="position:relative; z-index:2; filter:drop-shadow(0 6px 14px rgba(0,0,0,0.55));">
                    <!-- Main Diamond -->
                    <polygon points="70,12 105,38 70,88 35,38" fill="#38bdf8" fill-opacity="0.95" />
                    <polygon points="70,12 88,38 70,88" fill="#0284c7" fill-opacity="0.85" />
                    <polygon points="70,12 52,38 70,88" fill="#bae6fd" fill-opacity="0.95" />
                    <polygon points="52,38 70,12 88,38" fill="#f0f9ff" />
                    <polygon points="35,38 52,38 70,88" fill="#0369a1" />
                    <polygon points="105,38 88,38 70,88" fill="#0284c7" />
                    <!-- Left Small Diamond -->
                    <polygon points="20,45 42,42 35,70 12,65" fill="#38bdf8" fill-opacity="0.85" />
                    <polygon points="20,45 35,70 12,65" fill="#0284c7" />
                    <!-- Right Small Diamond -->
                    <polygon points="120,45 98,42 105,70 128,65" fill="#38bdf8" fill-opacity="0.85" />
                    <polygon points="120,45 105,70 128,65" fill="#0284c7" />
                    <!-- Sparkles -->
                    <circle cx="95" cy="22" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 5px #ffffff)" />
                    <circle cx="45" cy="55" r="2.5" fill="#ffffff" />
                    <circle cx="70" cy="80" r="3" fill="#ffffff" />
                </svg>
            </div>

            <!-- Claim Button (0/1 or 1/1) -->
            <button type="button" id="btn-claim-ad-reward" onclick="handleAdRewardClick()" ${isClaimed ? 'disabled' : ''} style="
                width: 100%;
                padding: 10px 14px;
                background: ${isClaimed ? 'linear-gradient(180deg, #475569 0%, #334155 100%)' : 'linear-gradient(180deg, #b45309 0%, #78350f 100%)'};
                border: 1.5px solid ${isClaimed ? '#64748b' : '#fbbf24'};
                border-radius: 10px;
                color: ${isClaimed ? '#94a3b8' : '#ffffff'};
                font-size: 14px;
                font-weight: 800;
                cursor: ${isClaimed ? 'not-allowed' : 'pointer'};
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                box-shadow: ${isClaimed ? 'none' : '0 4px 14px rgba(0,0,0,0.4), 0 0 12px rgba(251, 191, 36, 0.4)'};
                transition: all 0.2s ease;
            ">
                <span style="display:inline-flex; align-items:center; justify-content:center; width:22px; height:22px; border-radius:50%; background:rgba(0,0,0,0.35); border:1px solid ${isClaimed ? '#94a3b8' : '#fff'}; font-size:10px;">
                    ${isClaimed ? '✓' : '▶'} AD
                </span>
                <span id="ad-reward-btn-label">${isClaimed ? 'ฟรี (1/1) - รับแล้ว' : 'ฟรี (0/1)'}</span>
            </button>
        </div>
    `;
};

window.handleAdRewardClick = async function () {
    if (window.adRewardState.claimed_today >= 1) {
        showToast('คุณได้รับเพชรฟรีจากโฆษณาของวันนี้ไปแล้ว (รีเซ็ตวันใหม่ 00:00 น.)');
        return;
    }

    const btn = document.getElementById('btn-claim-ad-reward');
    if (btn) btn.disabled = true;

    // Check Capacitor AdMob plugin
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob) {
        try {
            const { AdMob } = window.Capacitor.Plugins;
            const rewardId = window.adRewardState.ad_unit_id || 'ca-app-pub-3940256099942544/1712485313';
            showToast('กำลังโหลดโฆษณารางวัล AdMob...');
            await AdMob.prepareRewardVideoAd({ adId: rewardId });
            const rewardResult = await AdMob.showRewardVideoAd();
            console.log('AdMob reward result:', rewardResult);
            await window.sendClaimAdRewardRequest();
            return;
        } catch (err) {
            console.warn('AdMob native failed or cancelled, using simulator fallback:', err);
        }
    }

    // Web / fallback simulation
    window.openSimulatedAdRewardModal();
};

window.openSimulatedAdRewardModal = function () {
    const modal = document.getElementById('modal-simulated-reward-ad');
    if (!modal) {
        window.sendClaimAdRewardRequest();
        return;
    }

    modal.style.display = 'flex';
    let timeLeft = 5;
    const secEl = document.getElementById('ad-countdown-seconds');
    const barEl = document.getElementById('ad-countdown-bar');
    const statusEl = document.getElementById('ad-reward-status-pill');

    if (secEl) secEl.innerText = timeLeft;
    if (barEl) barEl.style.width = '0%';
    if (statusEl) {
        statusEl.innerText = '⏳ กำลังเล่น...';
        statusEl.style.borderColor = '#fbbf24';
        statusEl.style.color = '#fbbf24';
    }

    const timer = setInterval(() => {
        timeLeft--;
        if (secEl) secEl.innerText = Math.max(0, timeLeft);
        if (barEl) barEl.style.width = `${((5 - timeLeft) / 5) * 100}%`;

        if (timeLeft <= 0) {
            clearInterval(timer);
            if (statusEl) {
                statusEl.innerText = '✅ สำเร็จ!';
                statusEl.style.borderColor = '#10b981';
                statusEl.style.color = '#10b981';
            }
            setTimeout(() => {
                modal.style.display = 'none';
                window.sendClaimAdRewardRequest();
            }, 600);
        }
    }, 1000);
};

window.sendClaimAdRewardRequest = async function () {
    try {
        const token = localStorage.getItem('snake_auth_token') || sessionStorage.getItem('snake_auth_token') || '';
        const headers = {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        };
        const resp = await fetch('api/claim_ad_reward.php?action=claim', {
            method: 'POST',
            headers,
            body: JSON.stringify({ action: 'claim' })
        });
        const res = await resp.json();

        if (res && res.success) {
            window.adRewardState.claimed_today = 1;
            window.adRewardState.can_claim = false;
            if (res.new_diamonds !== undefined && typeof DEFAULT_USER !== 'undefined') {
                DEFAULT_USER.diamonds = res.new_diamonds;
                updateUserBar(DEFAULT_USER);
            }
            showToast(res.message || '🎉 ได้รับ 30 เพชรฟรีสำเร็จ!');
            window.renderRewardAdCard();
        } else {
            showToast((res && res.message) ? res.message : 'ไม่สามารถรับรางวัลได้ในขณะนี้');
            window.renderRewardAdCard();
        }
    } catch (e) {
        console.error('sendClaimAdRewardRequest error:', e);
        showToast('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
        window.renderRewardAdCard();
    }
};

// =========================================================================
// 🎪 SIDEBAR EVENT CARDS DYNAMIC STATUS SYNC (ซิงก์สถานะอีเวนต์ & แสดง [หมดเวลา])
// =========================================================================
window.syncSidebarEventsSummary = function (eventsSummary) {
    if (!eventsSummary || !Array.isArray(eventsSummary.events)) return;

    eventsSummary.events.forEach(ev => {
        const type = String(ev.type || '').toUpperCase();
        const isLive = Boolean(ev.is_live);
        const name = ev.name || '';

        if (type === 'FRAME') {
            const sub = document.getElementById('card-event-frame-sub');
            const badge = document.getElementById('badge-event-frame');
            if (badge) {
                badge.innerText = isLive ? 'EVENT' : 'หมดเวลา';
                badge.style.background = isLive ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : '#ef4444';
            }
            if (sub) {
                if (!isLive) {
                    sub.innerHTML = '<span style="color:#ef4444; font-weight:800;">[หมดเวลา]</span>';
                } else {
                    sub.innerHTML = '<span style="color:#fbbf24; font-weight:700;">สุ่มกรอบ SS+</span>';
                }
            }
        } else if (type === 'DICE') {
            const sub = document.getElementById('card-event-dice-sub');
            const badge = document.getElementById('badge-event-dice');
            if (badge) {
                badge.innerText = isLive ? 'EVENT' : 'หมดเวลา';
                badge.style.background = isLive ? 'linear-gradient(135deg,#0284c7,#0369a1)' : '#ef4444';
            }
            if (sub) {
                if (!isLive) {
                    sub.innerHTML = '<span style="color:#ef4444; font-weight:800;">[หมดเวลา]</span>';
                } else {
                    sub.innerHTML = '<span style="color:#00e5ff; font-weight:700;">สุ่มเต๋า 3D</span>';
                }
            }
        } else if (type === 'GEM') {
            const sub = document.getElementById('card-event-gem-sub');
            const badge = document.getElementById('badge-event-gem');
            if (badge) {
                badge.innerText = isLive ? 'EVENT' : 'หมดเวลา';
                badge.style.background = isLive ? 'linear-gradient(135deg,#8b5cf6,#6d28d9)' : '#ef4444';
            }
            if (sub) {
                if (!isLive) {
                    sub.innerHTML = '<span style="color:#ef4444; font-weight:800;">[หมดเวลา]</span>';
                } else {
                    sub.innerHTML = '<span style="color:#e9d5ff; font-weight:700;">สุ่มอัญมณี SS+</span>';
                }
            }
        }
    });
};

// ออโต้ซิงก์สถานะอีเวนต์ทันทีเมื่อโหลดหน้าเว็บเสร็จ
(function () {
    const doSync = () => {
        fetch('api/app_config.php?t=' + Date.now(), { cache: 'no-store' })
            .then(r => r.json())
            .then(res => {
                if (res && res.events_summary && typeof window.syncSidebarEventsSummary === 'function') {
                    window.syncSidebarEventsSummary(res.events_summary);
                }
            })
            .catch(() => {});
    };
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', doSync);
    } else {
        setTimeout(doSync, 100);
    }
})();
