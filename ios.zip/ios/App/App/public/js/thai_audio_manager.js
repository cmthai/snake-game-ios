/**
 * Snake & Ladder 3D - Thai Audio Manager Module (ระบบเสียงประกอบ & เสียงพากย์ภาษาไทย)
 * Fully Optimized for Desktop, iOS Safari/WKWebView, and Android WebView:
 * - Dual-Engine Playback: Web Audio API (Buffer Pooling, 0ms Latency, Autoplay-Immune) + Prewarmed HTML5 Audio Fallback
 * - Global iOS/Android Gesture Unlock: Resumes AudioContext & unlocks HTML5 Audio pipeline on first interaction
 * - Safe URI Encoding: Prevents Unicode / Thai character load failures on iOS WebKit and Android
 * - Guaranteed TTS Fallback: Uses Web Speech API (speechSynthesis) if audio files fail or are restricted
 */
(function (window) {
    'use strict';

    const DEFAULT_AUDIO_CONFIG = {
        enabled: true,
        voiceEnabled: true,
        sfxEnabled: true,
        masterVolume: 0.85,
        voiceVolume: 1.0,
        sfxVolume: 0.85,
        basePath: 'assets/audio/th/',
        updatedAt: 1,
        events: {
            'malei': {
                name: 'เสียงพากย์เริ่มเกม ("มาเลยๆ")',
                type: 'voice',
                files: ['0-_ah.mp3'],
                text: 'มาเลยๆ',
                description: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "มาเลยๆ" เมื่อเริ่มการแข่งขัน',
                volume: 1.0,
                enabled: true
            },
            'yeay': {
                name: 'เสียงได้เริ่มคนแรก ("เย้! ได้ทอยเป็นคนแรก")',
                type: 'voice',
                files: ['0-_yo.mp3'],
                text: 'เย้ ได้ทอยเป็นคนแรก',
                description: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "เย้! ได้ทอยเป็นคนแรก"',
                volume: 1.0,
                enabled: true
            },
            'turn_order_1': {
                name: 'เสียงได้ทอยเป็นคนแรก ("เย้! ได้ทอยเป็นคนแรก")',
                type: 'voice',
                files: ['0-_yo.mp3', 'yeay.mp3'],
                text: 'เย้ ได้ทอยเป็นคนแรก',
                description: 'เสียงเด็กผู้หญิงดีใจเมื่อได้ทอยเป็นคนแรก (มือ 1)',
                volume: 1.0,
                enabled: true
            },
            'turn_order_2': {
                name: 'เสียงได้ทอยเป็นที่สอง ("ได้ทอยเป็นคนที่สอง")',
                type: 'voice',
                files: ['3-______________________________2.mp3'],
                text: 'ได้ทอยเป็นคนที่สอง',
                description: 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สอง (มือ 2)',
                volume: 1.0,
                enabled: true
            },
            'turn_order_3': {
                name: 'เสียงได้ทอยเป็นที่สาม ("ได้ทอยเป็นคนที่สาม")',
                type: 'voice',
                files: ['4-______________________________3.mp3'],
                text: 'ได้ทอยเป็นคนที่สาม',
                description: 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สาม (มือ 3)',
                volume: 1.0,
                enabled: true
            },
            'turn_order_4': {
                name: 'เสียงได้ทอยเป็นที่สี่ ("ได้ทอยเป็นคนที่สี่")',
                type: 'voice',
                files: ['5-______________________________4.mp3'],
                text: 'ได้ทอยเป็นคนที่สี่',
                description: 'เสียงเด็กผู้หญิงพูดเมื่อได้ทอยเป็นคนที่สี่ (มือ 4)',
                volume: 1.0,
                enabled: true
            },
            'your_turn': {
                name: 'เสียงเริ่มทอย ("ถึงตาคุณแล้ว ทอยเต๋าเลย!")',
                type: 'voice',
                files: ['3-.mp3'],
                text: 'ถึงตาคุณแล้ว ทอยเต๋าเลย',
                description: 'เสียงเด็กผู้หญิงเตือนเมื่อถึงรอบตาของเราทอยลูกเต๋า',
                volume: 1.0,
                enabled: true
            },
            'dice_roll': {
                name: 'เสียงทอยลูกเต๋า (Dice Roll)',
                type: 'sfx',
                files: ['6a9c4ae3075b1_RkLaxis5.mp3'],
                description: 'เอฟเฟกต์ลูกเต๋าหมุนกระทบพื้นกระดาน (Dice Roll SFX)',
                volume: 0.9,
                enabled: true
            },
            'step': {
                name: 'เสียงเดินนับช่อง (Step SFX)',
                type: 'sfx',
                files: ['freesound_gamestudio-button-394464.mp3'],
                description: 'เสียงก้าวเดินสั้นๆ ตามจำนวนแต้มลูกเต๋าในแต่ละช่อง',
                volume: 0.85,
                enabled: true
            },
            'double': {
                name: 'เสียงทอยได้แต้มดับเบิลทั่วไป ("ดับเบิล!")',
                type: 'voice',
                files: ['double.mp3'],
                text: 'ดับเบิล',
                description: 'เด็กผู้หญิงพูดภาษาไทยชัดเจนว่า "ดับเบิล!"',
                volume: 1.0,
                enabled: true
            },
            'double_2': {
                name: 'เสียงแต้มดับเบิล 2 ("ดับเบิลสอง")',
                type: 'voice',
                files: ['5-.mp3'],
                text: 'ดับเบิลสอง',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลสอง"',
                volume: 1.0,
                enabled: true
            },
            'double_4': {
                name: 'เสียงแต้มดับเบิล 4 ("ดับเบิลสี่")',
                type: 'voice',
                files: ['4-.mp3'],
                text: 'ดับเบิลสี่',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลสี่"',
                volume: 1.0,
                enabled: true
            },
            'double_6': {
                name: 'เสียงแต้มดับเบิล 6 ("ดับเบิลหก")',
                type: 'voice',
                files: ['3-ดับเบิลหก.mp3'],
                text: 'ดับเบิลหก',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลหก"',
                volume: 1.0,
                enabled: true
            },
            'double_8': {
                name: 'เสียงแต้มดับเบิล 8 ("ดับเบิลแปด")',
                type: 'voice',
                files: ['2-.mp3'],
                text: 'ดับเบิลแปด',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลแปด"',
                volume: 1.0,
                enabled: true
            },
            'double_10': {
                name: 'เสียงแต้มดับเบิล 10 ("ดับเบิลสิบ")',
                type: 'voice',
                files: ['1-ดับเบิลสิบ.mp3'],
                text: 'ดับเบิลสิบ',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลสิบ"',
                volume: 1.0,
                enabled: true
            },
            'double_12': {
                name: 'เสียงแต้มดับเบิล 12 ("ดับเบิลสิบสอง")',
                type: 'voice',
                files: ['0-ดับเบิ้ลสิบสอง.mp3'],
                text: 'ดับเบิลสิบสอง',
                description: 'เสียงเด็กผู้หญิงพูด "ดับเบิลสิบสอง"',
                volume: 1.0,
                enabled: true
            },
            'dice_2': { name: 'เสียงแต้มลูกเต๋า 2 ("สอง")', type: 'voice', files: ['5-.mp3'], text: 'สอง', description: 'เสียงแต้ม 2', volume: 1.0, enabled: true },
            'dice_3': { name: 'เสียงแต้มลูกเต๋า 3 ("สาม")', type: 'voice', files: ['9-สาม.mp3'], text: 'สาม', description: 'เสียงแต้ม 3', volume: 1.0, enabled: true },
            'dice_4': { name: 'เสียงแต้มลูกเต๋า 4 ("สี่")', type: 'voice', files: ['8-สี่.mp3'], text: 'สี่', description: 'เสียงแต้ม 4', volume: 1.0, enabled: true },
            'dice_5': { name: 'เสียงแต้มลูกเต๋า 5 ("ห้า")', type: 'voice', files: ['7-ห้า.mp3'], text: 'ห้า', description: 'เสียงแต้ม 5', volume: 1.0, enabled: true },
            'dice_6': { name: 'เสียงแต้มลูกเต๋า 6 ("หก")', type: 'voice', files: ['6-หก.mp3'], text: 'หก', description: 'เสียงแต้ม 6', volume: 1.0, enabled: true },
            'dice_7': { name: 'เสียงแต้มลูกเต๋า 7 ("เจ็ด")', type: 'voice', files: ['5-เจ็ด.mp3'], text: 'เจ็ด', description: 'เสียงแต้ม 7', volume: 1.0, enabled: true },
            'dice_8': { name: 'เสียงแต้มลูกเต๋า 8 ("แปด")', type: 'voice', files: ['4-แปด.mp3'], text: 'แปด', description: 'เสียงแต้ม 8', volume: 1.0, enabled: true },
            'dice_9': { name: 'เสียงแต้มลูกเต๋า 9 ("เก้า")', type: 'voice', files: ['3-เก้า.mp3'], text: 'เก้า', description: 'เสียงแต้ม 9', volume: 1.0, enabled: true },
            'dice_10': { name: 'เสียงแต้มลูกเต๋า 10 ("สิบ")', type: 'voice', files: ['2-สิบ.mp3'], text: 'สิบ', description: 'เสียงแต้ม 10', volume: 1.0, enabled: true },
            'dice_11': { name: 'เสียงแต้มลูกเต๋า 11 ("สิบเอ็ด")', type: 'voice', files: ['1-สิบเอ็ด.mp3'], text: 'สิบเอ็ด', description: 'เสียงแต้ม 11', volume: 1.0, enabled: true },
            'dice_12': { name: 'เสียงแต้มลูกเต๋า 12 ("สิบสอง")', type: 'voice', files: ['0-.mp3'], text: 'สิบสอง', description: 'เสียงแต้ม 12', volume: 1.0, enabled: true },
            'card_reveal': {
                name: 'เสียงเปิดการ์ด / สุ่มเต๋าที่ละใบ ("แซ่บ")',
                type: 'sfx',
                files: ['oxidvideos-taking-playing-card-522520.mp3'],
                description: 'เอฟเฟกต์เสียงเปิดการ์ดทีละใบ',
                volume: 0.95,
                enabled: true
            },
            'card_reveal_rare': {
                name: 'เสียงเปิดได้การ์ดแรร์ S / SS+ / กิจกรรม ("แซ่บ-ออร่า")',
                type: 'sfx',
                files: ['mixkit-video-game-treasure-2066.wav'],
                description: 'เอฟเฟกต์เสียงการ์ดแรร์',
                volume: 1.0,
                enabled: true
            },
            'island_trap': {
                name: 'เสียงติดเกาะร้าง ("ติดเกาะร้างซะแล้ว")',
                type: 'voice',
                files: ['mix_03s__audio-joiner_com.mp3'],
                text: 'ติดเกาะร้างซะแล้ว',
                description: 'เด็กผู้หญิงพูด "ติดเกาะร้างซะแล้ว"',
                volume: 1.0,
                enabled: true
            },
            'buyout_city': {
                name: 'เสียงเมื่อมีคนซื้อเมืองต่อ ("ซื้อเมืองต่อแล้วนะ!")',
                type: 'voice',
                files: ['buyout_city_110924.mp3'],
                text: 'ซื้อเมืองต่อแล้วนะ',
                description: 'เสียงเทคโอเวอร์เมือง',
                volume: 1.0,
                enabled: true
            },
            'build_landmark': {
                name: 'เสียงสร้างแลนด์มาร์คสำเร็จ ("แลนด์มาร์คของฉัน!")',
                type: 'voice',
                files: ['build_landmark_111226.mp3'],
                text: 'แลนด์มาร์คของฉัน',
                description: 'เสียงสร้างแลนด์มาร์ค',
                volume: 1.0,
                enabled: true
            },
            'build_super_landmark': {
                name: 'เสียงสร้างแลนด์มาร์ค Super ("ซุปเปอร์แลนด์มาร์ค!")',
                type: 'voice',
                files: ['build_super_landmark_112227.mp3'],
                text: 'ซุปเปอร์แลนด์มาร์ค',
                description: 'เสียงสร้างซุปเปอร์แลนด์มาร์ค',
                volume: 1.0,
                enabled: true
            },
            'build_city': {
                name: 'เสียงสร้างเมือง ("สร้างเมืองละกัน")',
                type: 'voice',
                files: ['mhm_สร้างเมืองละกัน.mp3'],
                text: 'สร้างเมืองละกัน',
                description: 'เสียงสร้างเมือง',
                volume: 1.0,
                enabled: true
            },
            'victory': {
                name: 'เสียงชนะเกมส์ ("เย้ ชนะแล้ว!")',
                type: 'voice',
                files: ['2-_wah.mp3'],
                text: 'เย้ ชนะแล้ว',
                description: 'เสียงเมื่อชนะการแข่งขัน',
                volume: 1.0,
                enabled: true
            },
            'game_over_lose': {
                name: 'เสียงแพ้เกมส์ ("แพ้ซะแล้ว")',
                type: 'voice',
                files: ['game_over_lose_110620.mp3'],
                text: 'แพ้ซะแล้ว',
                description: 'เสียงเมื่อแพ้การแข่งขัน',
                volume: 1.0,
                enabled: true
            },
            'snake_bite': {
                name: 'เสียงตกงู ร่วงลง ("ว้าย! ตกช่องงู ร่วงลงเลย")',
                type: 'voice',
                files: ['1-.mp3'],
                text: 'ตกช่องงู',
                description: 'เสียงตกช่องงู',
                volume: 1.0,
                enabled: true
            },
            'ladder_climb': {
                name: 'เสียงตกบันได เลื่อนขึ้น ("เย้! ขึ้นบันไดลัด")',
                type: 'voice',
                files: ['yo.mp3'],
                text: 'ขึ้นบันไดลัด',
                description: 'เสียงขึ้นบันได',
                volume: 1.0,
                enabled: true
            },
            'bankrupt': {
                name: 'เสียงล้มละลาย ("แงๆ หมดตัวเลย")',
                type: 'voice',
                files: ['oh.mp3'],
                text: 'แงๆ หมดตัวเลย',
                description: 'เสียงล้มละลาย',
                volume: 1.0,
                enabled: true
            }
        }
    };

    class ThaiAudioManager {
        constructor() {
            this.config = JSON.parse(JSON.stringify(DEFAULT_AUDIO_CONFIG));
            this.audioPool = {};
            this.poolIndices = {};
            this.currentVoiceAudio = null;
            this.currentVoiceSource = null;
            this.lastVoicePlayTime = 0;
            this.lastVoiceEventKey = '';
            this.lastYourTurnTime = 0;
            this.bgmConfig = null;
            this.audioContext = null;
            this.bufferCache = {};
            this.decodingPromises = {};
            this.isUnlocked = false;
            this.loadLocalPreferences();
        }

        loadLocalPreferences() {
            try {
                const saved = localStorage.getItem('snake_thai_audio_user_prefs');
                if (saved) {
                    const parsed = JSON.parse(saved);
                    if (typeof parsed.masterVolume === 'number') this.config.masterVolume = parsed.masterVolume;
                    if (typeof parsed.voiceVolume === 'number') this.config.voiceVolume = parsed.voiceVolume;
                    if (typeof parsed.sfxVolume === 'number') this.config.sfxVolume = parsed.sfxVolume;
                    if (typeof parsed.enabled === 'boolean') this.config.enabled = parsed.enabled;
                    if (typeof parsed.voiceEnabled === 'boolean') this.config.voiceEnabled = parsed.voiceEnabled;
                    if (typeof parsed.sfxEnabled === 'boolean') this.config.sfxEnabled = parsed.sfxEnabled;
                }
            } catch (e) { }
        }

        saveLocalPreferences() {
            try {
                const prefs = {
                    masterVolume: this.config.masterVolume,
                    voiceVolume: this.config.voiceVolume,
                    sfxVolume: this.config.sfxVolume,
                    enabled: this.config.enabled,
                    voiceEnabled: this.config.voiceEnabled,
                    sfxEnabled: this.config.sfxEnabled
                };
                localStorage.setItem('snake_thai_audio_user_prefs', JSON.stringify(prefs));
            } catch (e) { }
        }

        getAudioContext() {
            if (window.soundEngine && window.soundEngine.ctx) {
                return window.soundEngine.ctx;
            }
            if (!this.audioContext) {
                try {
                    const AudioCtx = window.AudioContext || window.webkitAudioContext;
                    if (AudioCtx) {
                        this.audioContext = new AudioCtx({ latencyHint: 'interactive' });
                    }
                } catch (e) { }
            }
            return this.audioContext;
        }

        unlock() {
            const ctx = this.getAudioContext();
            if (ctx && ctx.state === 'suspended') {
                ctx.resume().catch(() => {});
            }

            if (!this.isUnlocked) {
                this.isUnlocked = true;

                // iOS WebKit HTML5 Audio pipeline warmup with inaudible sound
                try {
                    const dummy = new Audio();
                    dummy.setAttribute('playsinline', 'true');
                    dummy.setAttribute('webkit-playsinline', 'true');
                    dummy.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
                    dummy.volume = 0.01;
                    const p = dummy.play();
                    if (p !== undefined) {
                        p.then(() => {
                            dummy.pause();
                        }).catch(() => {});
                    }
                } catch (e) {}

                // Preload critical in-game SFX and voice lines into WebAudio buffers
                this.preloadCriticalSounds();
            }
        }

        preloadCriticalSounds() {
            const priorityFiles = [
                '0-_yo.mp3',
                'yeay.mp3',
                '3-______________________________2.mp3',
                '4-______________________________3.mp3',
                '5-______________________________4.mp3',
                '3-.mp3',
                'malei.mp3',
                'build_city_110924.mp3',
                'build_landmark_111226.mp3',
                'build_super_landmark_112227.mp3',
                'buyout_city_110924.mp3',
                'walk.mp3',
                'dice.mp3',
                'double.mp3'
            ];
            priorityFiles.forEach(file => {
                const url = this.resolveAudioUrl(file);
                this.loadAudioBuffer(url).catch(() => {});
            });
        }

        async loadAudioBuffer(url) {
            if (this.bufferCache[url]) {
                return this.bufferCache[url];
            }
            if (this.decodingPromises[url]) {
                return this.decodingPromises[url];
            }
            const ctx = this.getAudioContext();
            if (!ctx) return null;

            this.decodingPromises[url] = (async () => {
                try {
                    const resp = await fetch(url);
                    if (!resp.ok) return null;
                    const arrayBuffer = await resp.arrayBuffer();
                    const audioBuffer = await new Promise((resolve, reject) => {
                        ctx.decodeAudioData(arrayBuffer, resolve, reject);
                    });
                    this.bufferCache[url] = audioBuffer;
                    return audioBuffer;
                } catch (e) {
                    console.debug('[ThaiAudio] WebAudio buffer decode failed:', url, e);
                    return null;
                } finally {
                    delete this.decodingPromises[url];
                }
            })();

            return this.decodingPromises[url];
        }

        playWebAudio(buffer, volume = 1.0) {
            const ctx = this.getAudioContext();
            if (!ctx) return null;
            if (ctx.state === 'suspended') {
                ctx.resume().catch(() => {});
            }
            try {
                const source = ctx.createBufferSource();
                source.buffer = buffer;
                const gain = ctx.createGain();
                gain.gain.setValueAtTime(volume, ctx.currentTime);
                source.connect(gain);

                if (window.soundEngine && window.soundEngine.masterGain) {
                    gain.connect(window.soundEngine.masterGain);
                } else {
                    gain.connect(ctx.destination);
                }

                source.start(0);
                return source;
            } catch (e) {
                console.debug('[ThaiAudio] WebAudio play error:', e);
                return null;
            }
        }

        init() {
            this.fetchServerConfig();

            const unlockHandler = () => {
                this.unlock();
            };
            ['pointerdown', 'touchstart', 'touchend', 'click', 'keydown'].forEach(evt => {
                window.addEventListener(evt, unlockHandler, { passive: true });
            });

            console.log('[ThaiAudio] Initialized Thai Voice & SFX Manager with iOS/Android Dual-Engine Support');
        }

        async fetchServerConfig() {
            try {
                const res = await fetch('api/audio_settings.php?action=get_config&t=' + Date.now());
                if (res.ok) {
                    const data = await res.json();
                    if (data && data.status === 'success') {
                        if (data.events && typeof data.events === 'object') {
                            const prevVer = this.config.updatedAt;
                            // ผสานการตั้งค่าจากแอดมินเป็นหลัก 100% โดยไม่แทรกไฟล์ที่ระบบสุ่มสร้างเอง
                            Object.keys(DEFAULT_AUDIO_CONFIG.events).forEach(k => {
                                if (data.events[k]) {
                                    if (!data.events[k].text && DEFAULT_AUDIO_CONFIG.events[k].text) {
                                        data.events[k].text = DEFAULT_AUDIO_CONFIG.events[k].text;
                                    }
                                    if ((!data.events[k].files || !data.events[k].files.length) && DEFAULT_AUDIO_CONFIG.events[k].files.length) {
                                        data.events[k].files = DEFAULT_AUDIO_CONFIG.events[k].files;
                                    }
                                } else {
                                    data.events[k] = DEFAULT_AUDIO_CONFIG.events[k];
                                }
                            });
                            this.config.events = data.events;
                            if (data.basePath) this.config.basePath = data.basePath;
                            this.config.updatedAt = data.updatedAt || Date.now();
                            if (prevVer !== this.config.updatedAt) {
                                this.audioPool = {};
                                this.poolIndices = {};
                            }
                        }
                        if (data.bgm_config && typeof data.bgm_config === 'object') {
                            this.bgmConfig = data.bgm_config;
                            if (window.soundEngine && typeof window.soundEngine.updateBgmSettings === 'function') {
                                window.soundEngine.updateBgmSettings(data.bgm_config);
                            }
                        }
                    }
                }
            } catch (e) { }
        }

        resolveAudioUrl(filename) {
            const basePath = this.config.basePath || 'assets/audio/th/';
            const ver = this.config.updatedAt || 1;
            let fullPath = filename;
            if (!filename.startsWith('http://') && !filename.startsWith('https://') && !filename.startsWith('/')) {
                fullPath = basePath + filename;
            }
            const encoded = encodeURI(fullPath);
            return encoded.includes('?') ? encoded : (encoded + '?v=' + ver);
        }

        preloadAll() {
            this.preloadCriticalSounds();
        }

        isEventPlayable(eventKey) {
            const ev = this.config.events && this.config.events[eventKey];
            return Boolean(ev && ev.enabled !== false && Array.isArray(ev.files) && ev.files.length > 0);
        }

        play(eventKey, options = {}) {
            if (!this.config.enabled) return;

            const ev = this.config.events && this.config.events[eventKey];
            if (!ev || ev.enabled === false) return;

            if (ev.type === 'voice' && !this.config.voiceEnabled) return;
            if (ev.type === 'sfx' && !this.config.sfxEnabled) return;

            const files = Array.isArray(ev.files) ? ev.files : [];
            if (!files.length && !options.file) {
                if (ev.type === 'voice' && ev.text) {
                    this.speakThaiText(ev.text);
                }
                return;
            }

            let targetFile = files[0] || options.file;
            if (files.length > 1) {
                targetFile = files[Math.floor(Math.random() * files.length)];
            }
            if (options.file && (files.includes(options.file) || !files.length)) {
                targetFile = options.file;
            }

            const categoryVol = (ev.type === 'voice') ? this.config.voiceVolume : this.config.sfxVolume;
            const eventVol = (ev.volume !== undefined && !isNaN(Number(ev.volume))) ? Number(ev.volume) : 1.0;
            const optVol = (options.volume !== undefined) ? Number(options.volume) : 1.0;
            const finalVol = Math.max(0, Math.min(1, this.config.masterVolume * categoryVol * eventVol * optVol));

            // หากเป็นเสียงพากย์ (voice) ให้หยุดเสียงพากย์เดิมที่กำลังเล่นอยู่ทันที เพื่อไม่ให้มีเสียงพูดซ้อนกัน
            if (ev.type === 'voice') {
                this.lastVoicePlayTime = Date.now();
                this.lastVoiceEventKey = eventKey;
                if (this.currentVoiceSource) {
                    try { this.currentVoiceSource.stop(); } catch (e) { }
                    this.currentVoiceSource = null;
                }
                if (this.currentVoiceAudio) {
                    try {
                        this.currentVoiceAudio.pause();
                        this.currentVoiceAudio.currentTime = 0;
                    } catch (e) { }
                    this.currentVoiceAudio = null;
                }

                // Audio Ducking: ค่อยๆ หรี่เสียงเพลงประกอบ BGM ชั่วคราวเพื่อให้เสียงพากย์ชัดเจน 100%
                if (window.soundEngine && typeof window.soundEngine.duckAllBgm === 'function') {
                    window.soundEngine.duckAllBgm(2400);
                }
            } else if (ev.type === 'sfx' && (eventKey.includes('dice') || eventKey.includes('trap') || eventKey.includes('city') || eventKey.includes('landmark') || eventKey.includes('card') || eventKey.includes('reveal') || eventKey.includes('gacha'))) {
                if (window.soundEngine && typeof window.soundEngine.duckAllBgm === 'function') {
                    window.soundEngine.duckAllBgm(1500);
                }
            }

            const fullUrl = this.resolveAudioUrl(targetFile);

            // Tier 1: Try Web Audio Buffer (Immediate, 0 latency, immune to iOS/Android autoplay policy)
            const cachedBuffer = this.bufferCache[fullUrl];
            if (cachedBuffer) {
                const srcNode = this.playWebAudio(cachedBuffer, finalVol);
                if (srcNode) {
                    if (ev.type === 'voice') {
                        this.currentVoiceSource = srcNode;
                    }
                    return;
                }
            }

            // Start buffer loading for subsequent plays
            this.loadAudioBuffer(fullUrl).catch(() => {});

            // Tier 2: HTML5 Audio Element Pooling (Pre-warmed with playsinline)
            const soundId = eventKey + '_' + targetFile + '_' + (this.config.updatedAt || 1);
            let pool = this.audioPool[soundId];
            if (!pool) {
                pool = [];
                this.audioPool[soundId] = pool;
                this.poolIndices[soundId] = 0;
            }

            const maxPool = (ev.type === 'sfx') ? 2 : 1;
            let audioElem = pool.find(a => a && (a.paused || a.ended));
            if (!audioElem) {
                if (pool.length < maxPool) {
                    audioElem = new Audio(fullUrl);
                    audioElem.setAttribute('playsinline', 'true');
                    audioElem.setAttribute('webkit-playsinline', 'true');
                    audioElem.preload = 'auto';
                    pool.push(audioElem);
                } else {
                    const idx = (this.poolIndices[soundId] || 0) % pool.length;
                    audioElem = pool[idx];
                    this.poolIndices[soundId] = (idx + 1) % pool.length;
                }
            }

            if (ev.type === 'voice') {
                this.currentVoiceAudio = audioElem;
            }

            try {
                audioElem.volume = finalVol;
                audioElem.currentTime = 0;
                const playPromise = audioElem.play();
                if (playPromise !== undefined) {
                    playPromise.catch(err => {
                        console.debug('[ThaiAudio] HTML5 Playback blocked for ' + soundId + ':', err.message);
                        // Tier 3: If blocked by Autoplay Policy on iOS/Android, fall back to TTS for voice
                        if (ev.type === 'voice' && ev.text) {
                            this.speakThaiText(ev.text);
                        } else if (ev.type === 'sfx' && window.soundEngine) {
                            if (eventKey === 'step' && typeof window.soundEngine.playStep === 'function') window.soundEngine.playStep();
                            else if (eventKey === 'dice_roll' && typeof window.soundEngine.playDiceRoll === 'function') window.soundEngine.playDiceRoll();
                        }
                    });
                }
            } catch (err) {
                if (ev.type === 'voice' && ev.text) {
                    this.speakThaiText(ev.text);
                }
            }
        }

        playIfConfigured(eventKey, options = {}) {
            if (this.isEventPlayable(eventKey)) {
                this.play(eventKey, options);
            }
        }

        playGameStart(isFirstPlayer = true) {
            this.fetchServerConfig();

            const hasMalei = this.isEventPlayable('malei');
            const hasYeay = this.isEventPlayable('yeay');

            if (isFirstPlayer && hasMalei && hasYeay) {
                this.play(Math.random() < 0.5 ? 'malei' : 'yeay');
            } else if (isFirstPlayer && hasYeay) {
                this.play('yeay');
            } else if (hasMalei) {
                this.play('malei');
            } else if (hasYeay) {
                this.play('yeay');
            } else if (this.isEventPlayable('game_start')) {
                this.play('game_start');
            }
        }

        playTurnOrder(orderNum = 1) {
            const n = Math.max(1, Math.min(4, parseInt(orderNum) || 1));
            const orderKey = 'turn_order_' + n;

            // ปลดล็อค AudioContext ทันทีเผื่ออุปกรณ์มือถือเพิ่งเข้าสู่หน้ากระดาน
            this.unlock();

            if (this.isEventPlayable(orderKey)) {
                this.play(orderKey);
            } else if (n === 1) {
                if (this.isEventPlayable('turn_order_1')) {
                    this.play('turn_order_1');
                } else if (this.isEventPlayable('yeay')) {
                    this.play('yeay');
                } else {
                    this.play('turn_order_1', { file: '0-_yo.mp3' });
                }
            } else if (n === 2) {
                this.play('turn_order_2', { file: '3-______________________________2.mp3' });
            } else if (n === 3) {
                this.play('turn_order_3', { file: '4-______________________________3.mp3' });
            } else if (n === 4) {
                this.play('turn_order_4', { file: '5-______________________________4.mp3' });
            }
        }

        playYourTurn(isConsecutiveDouble = false) {
            // หากเป็นการทอยดับเบิลครั้งที่ 2 หรือครั้งที่ 3 ไม่ต้องมีเสียงแจ้งเตือนถึงตาคุณแล้ว
            if (isConsecutiveDouble) return;
            const now = Date.now();
            if (now - this.lastYourTurnTime < 4000) return;
            this.lastYourTurnTime = now;
            if (this.isEventPlayable('your_turn')) {
                this.play('your_turn');
            }
        }

        playStep(stepIndex = 1) {
            this.playIfConfigured('step');
        }

        playDouble(total = null) {
            if (total !== null && Number.isInteger(total)) {
                const specificDoubleKey = 'double_' + total;
                if (this.isEventPlayable(specificDoubleKey)) {
                    this.play(specificDoubleKey);
                    return;
                }
            }
            if (this.isEventPlayable('double')) {
                this.play('double');
            }
        }

        // เสียงขานแต้มลูกเต๋า (3, 4, 5 ถึง 11 และ 2, 12) หรือดับเบิ้ล
        playDiceOutcome(total, isDouble = false, d1 = null, d2 = null) {
            const naturalDouble = (isDouble === true) || (d1 !== null && d2 !== null && d1 === d2) || (total === 2) || (total === 12);

            if (naturalDouble) {
                const specificDoubleKey = 'double_' + total;
                if (this.isEventPlayable(specificDoubleKey)) {
                    this.play(specificDoubleKey);
                    return;
                }
                const specificDiceKey = 'dice_' + total;
                if (this.isEventPlayable(specificDiceKey)) {
                    this.play(specificDiceKey);
                    return;
                }
                if (this.isEventPlayable('double')) {
                    this.play('double');
                    return;
                }
                return;
            }

            const diceKey = 'dice_' + total;
            if (this.isEventPlayable(diceKey)) {
                this.play(diceKey);
            }
        }

        speakThaiText(text) {
            // ปิดเสียงหุ่นยนต์สังเคราะห์ Web Speech API ตามคำสั่งผู้ใช้ ให้ใช้เฉพาะไฟล์เสียงจริงที่แอดมินตั้งค่าเท่านั้น
            return;
        }

        playIslandTrap() {
            if (this.isEventPlayable('island_trap')) {
                this.play('island_trap');
            }
        }

        playBuildCity() {
            if (this.isEventPlayable('build_city')) {
                this.play('build_city');
            } else {
                this.play('build_city', { file: 'build_city_110924.mp3' });
            }
        }

        playBuildLandmark() {
            if (this.isEventPlayable('build_landmark')) {
                this.play('build_landmark');
            } else {
                this.play('build_landmark', { file: 'build_landmark_111226.mp3' });
            }
        }

        playBuildSuperLandmark() {
            if (this.isEventPlayable('build_super_landmark')) {
                this.play('build_super_landmark');
            } else {
                this.play('build_super_landmark', { file: 'build_super_landmark_112227.mp3' });
            }
        }

        playBuyoutCity() {
            if (this.isEventPlayable('buyout_city')) {
                this.play('buyout_city');
            } else {
                this.play('buyout_city', { file: 'buyout_city_110924.mp3' });
            }
        }

        playVictory() {
            if (this.isEventPlayable('victory')) {
                this.play('victory');
            } else {
                this.speakThaiText('เย้ ชนะแล้ว');
            }
        }

        playGameOverLose() {
            if (this.isEventPlayable('game_over_lose')) {
                this.play('game_over_lose');
            } else {
                this.speakThaiText('แพ้ซะแล้ว');
            }
        }

        setMasterVolume(val) {
            this.config.masterVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        setVoiceVolume(val) {
            this.config.voiceVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        setSfxVolume(val) {
            this.config.sfxVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        toggleMaster(enable) {
            this.config.enabled = (enable !== undefined) ? !enable : !this.config.enabled;
            this.saveLocalPreferences();
            return this.config.enabled;
        }

        toggleVoice(enable) {
            this.config.voiceEnabled = (enable !== undefined) ? !enable : !this.config.voiceEnabled;
            this.saveLocalPreferences();
            return this.config.voiceEnabled;
        }

        toggleSfx(enable) {
            this.config.sfxEnabled = (enable !== undefined) ? !enable : !this.config.sfxEnabled;
            this.saveLocalPreferences();
            return this.config.sfxEnabled;
        }
    }

    window.ThaiAudio = new ThaiAudioManager();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => window.ThaiAudio.init());
    } else {
        window.ThaiAudio.init();
    }
})(window);
