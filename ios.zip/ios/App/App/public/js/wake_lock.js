/**
 * wake_lock.js - Keep Screen Awake Engine for Snake & Ladder 3D Game
 * Prevents screen from dimming, sleeping, or locking while the game is open.
 * Supports:
 *  1. Modern W3C Screen Wake Lock API (Chrome, Edge, Safari 16.4+, Android WebView)
 *  2. Capacitor Native Bridge & KeepAwake Plugin
 *  3. Seamless Hidden Video Loop Fallback for older iOS WebKit & Safari
 */

(function () {
    let wakeLockSentinel = null;
    let fallbackVideoEl = null;

    // 1. Request Native W3C Screen Wake Lock
    async function requestWakeLock() {
        if ('wakeLock' in navigator && typeof navigator.wakeLock.request === 'function') {
            try {
                wakeLockSentinel = await navigator.wakeLock.request('screen');
                console.log('💡 [WakeLock] Screen Wake Lock activated - หน้าจอจะเปิดตลอดจนกว่าจะปิดเกม');

                wakeLockSentinel.addEventListener('release', () => {
                    console.log('💤 [WakeLock] Screen Wake Lock was released');
                    wakeLockSentinel = null;
                });
            } catch (err) {
                console.warn('⚠️ [WakeLock] Request failed or requires user gesture:', err.message);
            }
        }

        // 2. Capacitor Native KeepAwake (if available)
        try {
            if (window.Capacitor && window.Capacitor.Plugins) {
                if (window.Capacitor.Plugins.KeepAwake) {
                    window.Capacitor.Plugins.KeepAwake.keepAwake();
                    console.log('📱 [WakeLock] Capacitor KeepAwake plugin activated');
                }
            }
        } catch (e) {
            // Ignore if not in Capacitor
        }

        // 3. Fallback Video Loop for WebKit / older browsers
        activateVideoFallback();
    }

    // Fallback: Invisible seamless 1x1 video loop for Safari / iOS WebKit
    function activateVideoFallback() {
        if (wakeLockSentinel) return; // Not needed if native wakeLock is active
        if (fallbackVideoEl) {
            if (fallbackVideoEl.paused) {
                fallbackVideoEl.play().catch(() => {});
            }
            return;
        }

        try {
            fallbackVideoEl = document.createElement('video');
            fallbackVideoEl.setAttribute('playsinline', '');
            fallbackVideoEl.setAttribute('webkit-playsinline', '');
            fallbackVideoEl.setAttribute('muted', '');
            fallbackVideoEl.setAttribute('loop', '');
            fallbackVideoEl.muted = true;
            fallbackVideoEl.playsInline = true;
            fallbackVideoEl.style.position = 'fixed';
            fallbackVideoEl.style.top = '-9999px';
            fallbackVideoEl.style.left = '-9999px';
            fallbackVideoEl.style.width = '1px';
            fallbackVideoEl.style.height = '1px';
            fallbackVideoEl.style.opacity = '0.01';
            fallbackVideoEl.style.pointerEvents = 'none';
            fallbackVideoEl.style.zIndex = '-1';

            // Prefer live 1x1 canvas stream (always valid on iOS WebKit/Safari without corrupt MP4 issues)
            let usedStream = false;
            try {
                const cvs = document.createElement('canvas');
                cvs.width = 2;
                cvs.height = 2;
                const ctx2d = cvs.getContext('2d');
                if (ctx2d) {
                    ctx2d.fillStyle = '#000000';
                    ctx2d.fillRect(0, 0, 2, 2);
                }
                const streamFn = cvs.captureStream || cvs.mozCaptureStream || cvs.webkitCaptureStream;
                if (typeof streamFn === 'function') {
                    const stream = streamFn.call(cvs, 1);
                    if (stream) {
                        fallbackVideoEl.srcObject = stream;
                        usedStream = true;
                    }
                }
            } catch (streamErr) {}

            if (!usedStream) {
                fallbackVideoEl.src = 'data:video/mp4;base64,AAAAHGZ0eXBtcDQyAAAAAG1wNDJpc29tYXZjMQAAAAhmcmVlAAAAM21kYXQAAAGZABAH//+1AAEAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAKAABAAABAAAAAAAAAAAAAAA';
            }
            document.body.appendChild(fallbackVideoEl);

            const playPromise = fallbackVideoEl.play();
            if (playPromise !== undefined) {
                playPromise.catch(() => {
                    // Autoplay with video might require user gesture, will retry on click
                });
            }
        } catch (e) {
            // Video fallback silent catch
        }
    }

    // Periodic guard: keep wake lock alive while page is visible
    setInterval(() => {
        if (document.visibilityState === 'visible') {
            if (!wakeLockSentinel) {
                requestWakeLock();
            } else if (fallbackVideoEl && fallbackVideoEl.paused) {
                fallbackVideoEl.play().catch(() => {});
            }
        }
    }, 20000);

    window.addEventListener('pageshow', () => {
        requestWakeLock();
    });

    // Re-acquire wake lock when app/tab returns to visible
    document.addEventListener('visibilitychange', async () => {
        if (document.visibilityState === 'visible') {
            await requestWakeLock();
        } else {
            if (wakeLockSentinel) {
                try {
                    await wakeLockSentinel.release();
                } catch(e) {}
                wakeLockSentinel = null;
            }
        }
    });

    window.addEventListener('focus', () => {
        requestWakeLock();
    });

    // Acquire or re-acquire on first touch / click (satisfies browser policy)
    const gestureEvents = ['click', 'touchstart', 'pointerdown', 'keydown'];
    function onFirstGesture() {
        requestWakeLock();
        if (fallbackVideoEl && fallbackVideoEl.paused) {
            fallbackVideoEl.play().catch(() => {});
        }
    }
    gestureEvents.forEach(evt => {
        window.addEventListener(evt, onFirstGesture, { passive: true });
    });

    // Auto-init on DOMContentLoaded & load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', requestWakeLock);
    } else {
        requestWakeLock();
    }

    window.addEventListener('load', requestWakeLock);

    // Export to window for manual control if needed
    window.keepScreenAwakeEngine = {
        request: requestWakeLock,
        release: async () => {
            if (wakeLockSentinel) {
                await wakeLockSentinel.release();
                wakeLockSentinel = null;
            }
            if (fallbackVideoEl) {
                fallbackVideoEl.pause();
                fallbackVideoEl.remove();
                fallbackVideoEl = null;
            }
        }
    };
})();

