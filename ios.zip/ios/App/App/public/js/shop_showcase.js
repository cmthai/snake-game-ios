/**
 * js/shop_showcase.js
 * Full-Screen Landscape Showcase Shop (Let's Get Rich / Video Style)
 * Supports Dynamic Admin Menus, Sub-Tabs, Tall Vertical Cards (Diamonds, Gold, Frames, 3D Dice, Pick Up, & Custom Bundles)
 */
(function () {
    'use strict';

    const DEFAULT_TOPUP_PACKAGES = [
        { id: 8, name: 'แพ็กเกจเพชรเริ่มต้น (500 เพชร)', type: 'DIAMOND', reward_diamond: 500000, reward_gold: 50000000, price_thb: 1.00, is_active: 1 },
        { id: 1, name: 'แพ็กเกจเพชรเริ่มต้น', type: 'DIAMOND', reward_diamond: 500, reward_gold: 0, price_thb: 30.00, is_active: 1 },
        { id: 3, name: 'แพ็กเกจทองมหาเศรษฐี', type: 'GOLD', reward_diamond: 0, reward_gold: 1000000, price_thb: 59.00, is_active: 1 },
        { id: 2, name: 'แพ็กเกจเพชรสุดคุ้ม', type: 'DIAMOND', reward_diamond: 1200, reward_gold: 50000, price_thb: 69.00, is_active: 1 },
        { id: 4, name: 'แพ็กเกจพรีเมียม VIP', type: 'COMBO', reward_diamond: 3000, reward_gold: 2500000, price_thb: 159.00, is_active: 1 }
    ];

    const SHOP_STATE = {
        catalog: {
            topup_packages: DEFAULT_TOPUP_PACKAGES,
            characters: [],
            dice: [],
            shop_menus: [],
            shop_custom_items: [],
            payment_settings: {
                promptpay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', bank: 'พร้อมเพย์กลาง (PromptPay)' },
                shopeepay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', qr_url: '', is_active: 1 }
            }
        },
        inventory: null,
        menus: [],
        customItems: [],
        activeMenuSlug: 'featured',
        activeSubtabIndex: 0,
        previewAvatarMode: 'samples', // 'samples' or 'my_photo'
        cardPortraitOverrides: {}, // charId -> portraitUrl
        loading: false
    };

    const AURA_COLORS = {
        gold: '#ffd700',
        orange: '#f97316',
        crimson: '#ef4444',
        purple: '#a855f7',
        cyan: '#00e5ff',
        yellow: '#facc15',
        rainbow: '#ec4899',
        emerald: '#10b981',
        white: '#f8fafc',
        none: '#64748b'
    };

    function esc(str) {
        return String(str ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function fmtNum(n) {
        const num = Number(n || 0);
        return isFinite(num) ? num.toLocaleString('en-US') : '0';
    }

    function injectShopShowcaseStyles() {
        if (document.getElementById('lgr-shop-showcase-styles')) return;
        const style = document.createElement('style');
        style.id = 'lgr-shop-showcase-styles';
        style.textContent = `
            /* Prominent Shop Button in Header & Left Menu */
            #btn-open-shop.btn-shop-video {
                position: relative;
                display: inline-flex !important;
                align-items: center;
                gap: 6px;
                width: auto !important;
                padding: 6px 14px !important;
                border-radius: 999px !important;
                background: linear-gradient(180deg, #ffe548 0%, #f59e0b 100%) !important;
                color: #0f172a !important;
                font-weight: 900 !important;
                font-size: 13px !important;
                border: 2px solid #ffffff !important;
                box-shadow: 0 4px 14px rgba(245, 158, 11, 0.55), inset 0 2px 0 rgba(255,255,255,0.65) !important;
                cursor: pointer;
                transition: transform 0.16s ease, box-shadow 0.16s ease;
                white-space: nowrap;
            }
            #btn-open-shop.btn-shop-video:hover {
                transform: translateY(-2px) scale(1.04);
                box-shadow: 0 6px 20px rgba(250, 204, 21, 0.75) !important;
            }
            #btn-open-shop.btn-shop-video .shop-hot-pill {
                position: absolute;
                top: -7px;
                right: -6px;
                background: linear-gradient(135deg, #ef4444, #dc2626);
                color: #fff;
                font-size: 9px;
                font-weight: 900;
                padding: 1px 5px;
                border-radius: 999px;
                border: 1.5px solid #fff;
                line-height: 1.2;
                box-shadow: 0 2px 6px rgba(239,68,68,0.6);
            }
            .big-feature-card.card-shop {
                position: relative;
                background: linear-gradient(145deg, rgba(37,99,235,0.42) 0%, rgba(30,58,138,0.72) 100%) !important;
                border: 1.5px solid #facc15 !important;
                box-shadow: 0 0 18px rgba(250, 204, 21, 0.28) !important;
            }
            .big-feature-card.card-shop .shop-card-ribbon {
                position: absolute;
                top: 5px;
                right: 5px;
                background: linear-gradient(180deg, #ffe033, #f59e0b);
                color: #0f172a;
                font-size: 9px;
                font-weight: 900;
                padding: 1px 6px;
                border-radius: 999px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.4);
            }

            /* Full-Screen Video-Style Shop Modal */
            #modal-shop .lgr-shop-shell {
                width: 98vw !important;
                max-width: 1320px !important;
                height: 96vh !important;
                height: 96dvh !important;
                max-height: 98dvh !important;
                padding: 0 !important;
                border-radius: 18px !important;
                overflow: hidden !important;
                display: flex !important;
                flex-direction: column !important;
                background: linear-gradient(180deg, #eef6ff 0%, #dbeafe 100%) !important;
                border: 2.5px solid #60a5fa !important;
                box-shadow: 0 22px 65px rgba(0, 0, 0, 0.82), 0 0 35px rgba(37, 99, 235, 0.45) !important;
                color: #0f172a;
            }

            /* Top White/Sky Header Bar */
            .lgr-shop-topbar {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
                padding: 6px 14px;
                background: linear-gradient(180deg, #ffffff 0%, #f1f5f9 100%);
                border-bottom: 2px solid #cbd5e1;
                flex-shrink: 0;
                z-index: 5;
            }
            .lgr-shop-back-btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                background: transparent;
                border: none;
                cursor: pointer;
                padding: 4px 8px;
                border-radius: 10px;
                transition: background 0.15s;
            }
            .lgr-shop-back-btn:hover {
                background: rgba(37, 99, 235, 0.08);
            }
            .lgr-shop-back-arrow {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 30px;
                height: 30px;
                border-radius: 9px;
                background: linear-gradient(180deg, #3b82f6, #1d4ed8);
                color: #fff;
                font-size: 16px;
                font-weight: 900;
                box-shadow: 0 2px 6px rgba(29, 78, 216, 0.35);
            }
            .lgr-shop-title-text {
                font-size: 20px;
                font-weight: 900;
                color: #1e293b;
                letter-spacing: -0.3px;
            }

            .lgr-shop-wallets {
                display: flex;
                align-items: center;
                gap: 8px;
                flex-wrap: wrap;
            }
            .lgr-wallet-chip {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                background: #1e293b;
                color: #fff;
                padding: 4px 10px 4px 8px;
                border-radius: 999px;
                font-size: 13px;
                font-weight: 800;
                border: 1.5px solid #334155;
                cursor: pointer;
                box-shadow: inset 0 1px 2px rgba(0,0,0,0.4);
            }
            .lgr-wallet-chip .plus-badge {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 18px;
                height: 18px;
                border-radius: 50%;
                background: linear-gradient(180deg, #4ade80, #16a34a);
                color: #fff;
                font-size: 13px;
                font-weight: 900;
                line-height: 1;
            }
            .lgr-top-inv-btn {
                background: linear-gradient(180deg, #38bdf8, #0284c7);
                color: #fff;
                border: 1.5px solid #bae6fd;
                border-radius: 10px;
                padding: 5px 12px;
                font-size: 12.5px;
                font-weight: 800;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(2, 132, 199, 0.3);
            }
            .lgr-top-close-btn,
            .modal-content .lgr-top-close-btn {
                width: 32px !important;
                height: 32px !important;
                min-width: 32px !important;
                min-height: 32px !important;
                max-width: 32px !important;
                max-height: 32px !important;
                border-radius: 50% !important;
                border: 2px solid #ffffff !important;
                background: linear-gradient(135deg, #ef4444 0%, #dc2626 50%, #991b1b 100%) !important;
                color: #ffffff !important;
                font-family: Arial, sans-serif !important;
                font-size: 19px !important;
                font-weight: 900 !important;
                line-height: 1 !important;
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                padding: 0 !important;
                margin: 0 !important;
                box-shadow: 0 3px 10px rgba(0, 0, 0, 0.4), 0 0 10px rgba(239, 68, 68, 0.6) !important;
                cursor: pointer !important;
                transition: transform 0.15s ease, filter 0.15s ease !important;
                flex-shrink: 0 !important;
                box-sizing: border-box !important;
            }
            .lgr-top-close-btn:hover {
                transform: scale(1.12) !important;
                filter: brightness(1.15) !important;
            }

            /* Split Body */
            .lgr-shop-body {
                display: flex;
                flex: 1;
                min-height: 0;
                padding: 10px;
                gap: 10px;
                background: linear-gradient(180deg, #e0f2fe 0%, #dbeafe 100%);
            }

            /* Left Royal-Blue Starry Sidebar (Matches Video!) */
            .lgr-shop-sidebar {
                width: 215px;
                flex-shrink: 0;
                background:
                    radial-gradient(circle at 20% 88%, rgba(255,255,255,0.14) 0%, transparent 32%),
                    radial-gradient(circle at 82% 76%, rgba(147,197,253,0.18) 0%, transparent 28%),
                    linear-gradient(180deg, #2b6cb0 0%, #2563eb 22%, #1d4ed8 65%, #1e3a8a 100%);
                border-radius: 16px;
                padding: 10px 8px;
                display: flex;
                flex-direction: column;
                gap: 5px;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch;
                box-shadow: inset 0 1px 0 rgba(255,255,255,0.35), 0 8px 20px rgba(30, 58, 138, 0.35);
                position: relative;
            }
            .lgr-shop-sidebar::after {
                content: '✦  ★  ✦';
                margin-top: auto;
                padding-top: 10px;
                text-align: center;
                font-size: 13px;
                letter-spacing: 6px;
                color: rgba(255, 255, 255, 0.28);
                pointer-events: none;
            }
            .lgr-menu-btn {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 6px;
                width: 100%;
                padding: 10px 13px;
                border-radius: 999px;
                border: none;
                background: transparent;
                color: rgba(255, 255, 255, 0.94);
                font-size: 14px;
                font-weight: 800;
                text-align: left;
                cursor: pointer;
                transition: all 0.16s ease;
                flex-shrink: 0;
            }
            .lgr-menu-btn:hover {
                background: rgba(255, 255, 255, 0.14);
            }
            .lgr-menu-btn.active {
                background: linear-gradient(180deg, #fff35c 0%, #facc15 100%);
                color: #1e293b;
                font-weight: 900;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.28), inset 0 2px 0 rgba(255, 255, 255, 0.8);
                transform: scale(1.02);
            }
            .lgr-menu-btn-left {
                display: flex;
                align-items: center;
                gap: 7px;
                min-width: 0;
                overflow: hidden;
            }
            .lgr-menu-check {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 18px;
                height: 18px;
                border-radius: 50%;
                background: #1e293b;
                color: #fde047;
                font-size: 11px;
                font-weight: 900;
                flex-shrink: 0;
            }
            .lgr-menu-title {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .lgr-menu-badge {
                font-size: 9.5px;
                font-weight: 900;
                padding: 2px 6px;
                border-radius: 999px;
                background: linear-gradient(135deg, #ef4444, #db2777);
                color: #fff;
                flex-shrink: 0;
                box-shadow: 0 2px 5px rgba(0,0,0,0.25);
            }
            .lgr-menu-btn.active .lgr-menu-badge {
                background: #1e293b;
                color: #fde047;
            }

            /* Right Main Stage */
            .lgr-shop-stage {
                flex: 1;
                min-width: 0;
                display: flex;
                flex-direction: column;
                background: rgba(255, 255, 255, 0.86);
                border-radius: 16px;
                border: 1.5px solid #bfdbfe;
                box-shadow: 0 6px 20px rgba(15, 23, 42, 0.08);
                overflow: hidden;
                position: relative;
            }

            /* Top Sub-Tabs Bar (White Strip + Yellow Active Pill like Video!) */
            .lgr-subtabs-bar {
                display: flex;
                align-items: center;
                gap: 6px;
                padding: 5px 12px;
                background: #ffffff;
                border-bottom: 2px solid #e2e8f0;
                overflow-x: auto;
                flex-shrink: 0;
                -webkit-overflow-scrolling: touch;
            }
            .lgr-subtab-btn {
                padding: 6px 18px;
                border-radius: 9px;
                border: 1px solid transparent;
                background: #f1f5f9;
                color: #475569;
                font-size: 13px;
                font-weight: 800;
                cursor: pointer;
                white-space: nowrap;
                transition: all 0.15s;
            }
            .lgr-subtab-btn:hover {
                background: #e2e8f0;
                color: #0f172a;
            }
            .lgr-subtab-btn.active {
                background: linear-gradient(180deg, #ffe84d 0%, #facc15 100%);
                color: #0f172a;
                border-color: #eab308;
                box-shadow: 0 2px 8px rgba(234, 179, 8, 0.35);
            }

            /* Tall Vertical 3-Card Showcase Viewport */
            .lgr-stage-body {
                flex: 1;
                min-height: 0;
                position: relative;
                display: flex;
                flex-direction: column;
                justify-content: flex-start !important;
                align-items: stretch;
                padding: 4px 10px 2px 10px;
                overflow-y: auto;
                overflow-x: hidden;
                -webkit-overflow-scrolling: touch;
            }
            .lgr-cards-track {
                flex: 1;
                min-height: 0;
                display: flex;
                align-items: stretch;
                gap: 12px;
                overflow-x: auto;
                overflow-y: hidden;
                padding: 2px 4px 6px 4px;
                scroll-behavior: smooth;
                -webkit-overflow-scrolling: touch;
            }
            .lgr-cards-track::-webkit-scrollbar {
                height: 7px;
            }
            .lgr-cards-track::-webkit-scrollbar-track {
                background: rgba(148, 163, 184, 0.2);
                border-radius: 999px;
            }
            .lgr-cards-track::-webkit-scrollbar-thumb {
                background: rgba(37, 99, 235, 0.45);
                border-radius: 999px;
            }

            /* Individual Tall Showcase Card (Optimized so 4th card peeks into view & no vertical cut-off) */
            .lgr-tall-card {
                flex: 0 0 calc((100% - 32px) / 3.35);
                min-width: 190px;
                max-width: 255px;
                height: 100%;
                min-height: 0;
                max-height: 100%;
                box-sizing: border-box;
                border-radius: 14px;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                overflow: hidden;
                position: relative;
                flex-shrink: 0;
                box-shadow: 0 8px 20px rgba(15, 23, 42, 0.14);
                border: 2px solid #93c5fd;
                transition: transform 0.18s ease, box-shadow 0.18s ease;
                background: linear-gradient(180deg, #dbeafe 0%, #eff6ff 65%, #dbeafe 100%);
            }
            .lgr-tall-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 12px 26px rgba(37, 99, 235, 0.24);
            }

            /* Card Color Themes Matching Video */
            .lgr-tall-card.theme-pink {
                border-color: #f472b6;
                background: linear-gradient(180deg, #fce7f3 0%, #fdf2f8 62%, #fbcfe8 100%);
            }
            .lgr-tall-card.theme-pink .lgr-card-top { background: linear-gradient(180deg, #ec4899, #db2777); }
            .lgr-tall-card.theme-pink .lgr-card-buy-bar { background: linear-gradient(180deg, #db2777, #9d174d); }
            .lgr-tall-card.theme-pink .lgr-card-action-bar { background: rgba(157, 23, 77, 0.4); border-top-color: rgba(244, 114, 182, 0.4); }

            .lgr-tall-card.theme-purple {
                border-color: #c084fc;
                background: linear-gradient(180deg, #f3e8ff 0%, #faf5ff 62%, #e9d5ff 100%);
            }
            .lgr-tall-card.theme-purple .lgr-card-top { background: linear-gradient(180deg, #9333ea, #7e22ce); }
            .lgr-tall-card.theme-purple .lgr-card-buy-bar { background: linear-gradient(180deg, #7e22ce, #581c87); }
            .lgr-tall-card.theme-purple .lgr-card-action-bar { background: rgba(88, 28, 135, 0.4); border-top-color: rgba(192, 132, 252, 0.4); }

            .lgr-tall-card.theme-blue {
                border-color: #60a5fa;
                background: linear-gradient(180deg, #dbeafe 0%, #f0f9ff 62%, #bfdbfe 100%);
            }
            .lgr-tall-card.theme-blue .lgr-card-top { background: linear-gradient(180deg, #3b82f6, #1d4ed8); }
            .lgr-tall-card.theme-blue .lgr-card-buy-bar { background: linear-gradient(180deg, #1d4ed8, #1e3a8a); }
            .lgr-tall-card.theme-blue .lgr-card-action-bar { background: rgba(30, 58, 138, 0.4); border-top-color: rgba(96, 165, 250, 0.4); }

            .lgr-tall-card.theme-gold {
                border-color: #fbbf24;
                background: linear-gradient(180deg, #fef3c7 0%, #fffbeb 62%, #fde68a 100%);
            }
            .lgr-tall-card.theme-gold .lgr-card-top { background: linear-gradient(180deg, #d97706, #b45309); }
            .lgr-tall-card.theme-gold .lgr-card-buy-bar { background: linear-gradient(180deg, #b45309, #78350f); }
            .lgr-tall-card.theme-gold .lgr-card-action-bar { background: rgba(120, 53, 15, 0.4); border-top-color: rgba(251, 191, 36, 0.4); }

            .lgr-tall-card.theme-green {
                border-color: #34d399;
                background: linear-gradient(180deg, #d1fae5 0%, #ecfdf5 62%, #a7f3d0 100%);
            }
            .lgr-tall-card.theme-green .lgr-card-top { background: linear-gradient(180deg, #10b981, #047857); }
            .lgr-tall-card.theme-green .lgr-card-buy-bar { background: linear-gradient(180deg, #047857, #064e3b); }
            .lgr-tall-card.theme-green .lgr-card-action-bar { background: rgba(6, 78, 59, 0.4); border-top-color: rgba(52, 211, 153, 0.4); }

            .lgr-tall-card.theme-crimson {
                border-color: #f87171;
                background: linear-gradient(180deg, #fee2e2 0%, #fef2f2 62%, #fecaca 100%);
            }
            .lgr-tall-card.theme-crimson .lgr-card-top { background: linear-gradient(180deg, #ef4444, #b91c1c); }
            .lgr-tall-card.theme-crimson .lgr-card-buy-bar { background: linear-gradient(180deg, #b91c1c, #7f1d1d); }
            .lgr-tall-card.theme-crimson .lgr-card-action-bar { background: rgba(127, 29, 29, 0.4); border-top-color: rgba(248, 113, 113, 0.4); }

            .lgr-tall-card.theme-dark-ad {
                border-color: #475569;
                background: linear-gradient(180deg, #334155 0%, #1e293b 65%, #0f172a 100%);
                color: #fff;
            }
            .lgr-tall-card.theme-dark-ad .lgr-card-top { background: linear-gradient(180deg, #475569, #334155); }
            .lgr-tall-card.theme-dark-ad .lgr-card-buy-bar { background: linear-gradient(180deg, #dc2626, #991b1b); }
            .lgr-tall-card.theme-dark-ad .lgr-card-action-bar { background: rgba(15, 23, 42, 0.85); border-top-color: rgba(100, 116, 139, 0.4); }

            .lgr-card-ribbon {
                position: absolute;
                top: 8px;
                right: 8px;
                z-index: 3;
                background: linear-gradient(180deg, #ffe84d, #f59e0b);
                color: #0f172a;
                font-size: 10.5px;
                font-weight: 900;
                padding: 2px 8px;
                border-radius: 999px;
                border: 1.5px solid #fff;
                box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            }

            .lgr-card-top {
                padding: 4px 6px 2px 6px;
                text-align: center;
                color: #ffffff;
                flex-shrink: 0 !important;
                position: relative;
                z-index: 2;
            }
            .lgr-card-title {
                font-size: 12.5px;
                font-weight: 900;
                line-height: 1.2;
                text-shadow: 0 1px 3px rgba(0,0,0,0.35);
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .lgr-card-limit {
                font-size: 9.5px;
                font-weight: 700;
                color: rgba(255, 255, 255, 0.88);
                margin-top: 1px;
            }

            .lgr-card-grade-strip {
                margin: 2px auto 0 auto;
                display: inline-block;
                padding: 1px 8px;
                border-radius: 999px;
                background: rgba(15, 23, 42, 0.78);
                color: #fde047;
                font-size: 9.5px;
                font-weight: 900;
                border: 1px solid rgba(255,255,255,0.4);
            }

            .lgr-card-visual {
                flex: 1 1 auto;
                min-height: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 2px 4px;
                position: relative;
                gap: 2px;
                overflow: hidden;
            }

            .lgr-reward-pills {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 3px;
                margin-top: 1px;
            }
            .lgr-reward-pill {
                font-size: 9px;
                font-weight: 800;
                padding: 1.5px 6px;
                border-radius: 999px;
                background: rgba(15, 23, 42, 0.88);
                color: #fff;
                box-shadow: 0 1px 4px rgba(0,0,0,0.22);
                border: 1px solid rgba(255, 255, 255, 0.18);
                white-space: nowrap;
                line-height: 1.2;
            }

            /* ============================================================
               Interactive Frame 3D Pop-Out & Embossed Aura Effects
               ============================================================ */
            @keyframes lgrFramePopOut3D {
                0% {
                    transform: perspective(600px) translateZ(0px) scale(1) translateY(0);
                    filter: drop-shadow(0 4px 8px rgba(0,0,0,0.5)) drop-shadow(0 0 10px var(--aura-hex, #ffd700));
                }
                30% {
                    transform: perspective(600px) translateZ(90px) scale(1.42) translateY(-14px);
                    filter: drop-shadow(0 28px 42px rgba(0,0,0,0.95)) drop-shadow(0 0 55px var(--aura-hex, #ffd700)) brightness(1.35);
                }
                60% {
                    transform: perspective(600px) translateZ(65px) scale(1.3) translateY(-7px);
                    filter: drop-shadow(0 20px 32px rgba(0,0,0,0.85)) drop-shadow(0 0 40px var(--aura-hex, #ffd700)) brightness(1.2);
                }
                85% {
                    transform: perspective(600px) translateZ(28px) scale(1.12) translateY(-2px);
                    filter: drop-shadow(0 10px 18px rgba(0,0,0,0.65)) drop-shadow(0 0 22px var(--aura-hex, #ffd700));
                }
                100% {
                    transform: perspective(600px) translateZ(0px) scale(1) translateY(0);
                    filter: drop-shadow(0 4px 10px rgba(0,0,0,0.5)) drop-shadow(0 0 14px var(--aura-hex, #ffd700));
                }
            }
            @keyframes lgrRingSpinPop {
                0% { transform: rotate(0deg) scale(1); }
                40% { transform: rotate(180deg) scale(1.2); }
                75% { transform: rotate(315deg) scale(1.08); }
                100% { transform: rotate(360deg) scale(1); }
            }
            @keyframes lgrShockwaveBurst {
                0% { transform: scale(0.65); opacity: 1; border-width: 4px; box-shadow: 0 0 35px var(--aura-hex, #ffd700); }
                50% { opacity: 0.95; }
                100% { transform: scale(2.8); opacity: 0; border-width: 1px; box-shadow: 0 0 70px var(--aura-hex, #ffd700); }
            }
            @keyframes lgrDicePopOutRoll {
                0% {
                    transform: perspective(600px) translateZ(0px) scale(1) rotate(0deg);
                    filter: drop-shadow(0 4px 8px rgba(0,0,0,0.5));
                }
                30% {
                    transform: perspective(600px) translateZ(70px) scale(1.42) translateY(-14px) rotate(-45deg);
                    filter: drop-shadow(0 24px 38px rgba(0,0,0,0.85)) drop-shadow(0 0 45px var(--dice-aura, #38bdf8)) brightness(1.28);
                }
                60% {
                    transform: perspective(600px) translateZ(50px) scale(1.28) translateY(-6px) rotate(270deg);
                    filter: drop-shadow(0 18px 28px rgba(0,0,0,0.75)) drop-shadow(0 0 30px var(--dice-aura, #38bdf8)) brightness(1.15);
                }
                85% {
                    transform: perspective(600px) translateZ(20px) scale(1.12) translateY(-1px) rotate(480deg);
                }
                100% {
                    transform: perspective(600px) translateZ(0px) scale(1) translateY(0) rotate(540deg);
                    filter: drop-shadow(0 4px 10px rgba(0,0,0,0.5));
                }
            }
            @keyframes lgrFloatBadge {
                0% { opacity: 0; transform: translate(-50%, 6px) scale(0.8); }
                25% { opacity: 1; transform: translate(-50%, -4px) scale(1.05); }
                75% { opacity: 1; transform: translate(-50%, -10px) scale(1); }
                100% { opacity: 0; transform: translate(-50%, -20px) scale(0.9); }
            }

            .lgr-tall-card:has(.aura-active),
            .lgr-tall-card:has(.dice-rolling),
            .lgr-tall-card.popout-active,
            .lgr-pickup-hero.popout-active,
            .lgr-stage-body.popout-active {
                overflow: visible !important;
                z-index: 100 !important;
            }

            .lgr-interactive-frame {
                position: relative;
                width: 74px;
                height: 74px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                user-select: none;
                transform-style: preserve-3d;
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), filter 0.25s ease;
            }
            .lgr-interactive-frame:hover {
                transform: perspective(600px) translateZ(15px) scale(1.08);
            }
            .lgr-interactive-frame.aura-active {
                animation: lgrFramePopOut3D 1s cubic-bezier(0.2, 0.85, 0.35, 1.2) forwards;
                z-index: 99 !important;
            }

            .lgr-frame-avatar-circle {
                position: absolute;
                width: 62px;
                height: 62px;
                border-radius: 50%;
                border: 3px solid var(--aura-hex, #ffd700);
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-color: #0f172a;
                box-shadow: 
                    0 8px 18px rgba(0,0,0,0.65),
                    0 0 20px var(--aura-hex, #ffd700),
                    inset 0 3px 5px rgba(255,255,255,0.7),
                    inset 0 -4px 8px rgba(0,0,0,0.6);
                transition: box-shadow 0.25s ease, transform 0.25s ease;
            }
            .lgr-frame-ring-img {
                position: absolute;
                width: 76px;
                height: 76px;
                object-fit: contain;
                pointer-events: none;
                filter: drop-shadow(0 0 10px var(--aura-hex, #ffd700));
                transition: transform 0.25s ease, filter 0.25s ease;
            }
            .lgr-interactive-frame.aura-active .lgr-frame-avatar-circle {
                box-shadow: 
                    0 22px 45px rgba(0,0,0,0.95),
                    0 0 65px var(--aura-hex, #ffd700),
                    0 0 110px var(--aura-hex, #ffd700),
                    inset 0 5px 10px rgba(255,255,255,1),
                    inset 0 -8px 14px rgba(0,0,0,0.85);
            }
            .lgr-interactive-frame.aura-active .lgr-frame-ring-img {
                animation: lgrRingSpinPop 1s cubic-bezier(0.2, 0.8, 0.4, 1);
                filter: drop-shadow(0 0 25px var(--aura-hex, #ffd700)) brightness(1.4);
            }
            .lgr-aura-shockwave {
                position: absolute;
                inset: -10px;
                border-radius: 50%;
                border: 3px solid var(--aura-hex, #ffd700);
                opacity: 0;
                pointer-events: none;
                box-shadow: 0 0 20px var(--aura-hex, #ffd700);
            }
            .lgr-interactive-frame.aura-active .lgr-aura-shockwave {
                animation: lgrShockwaveBurst 0.95s cubic-bezier(0.1, 0.7, 0.3, 1) forwards;
            }

            .lgr-interactive-dice {
                position: relative;
                width: 74px;
                height: 74px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                user-select: none;
                transform-style: preserve-3d;
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
            }
            .lgr-interactive-dice:hover {
                transform: perspective(600px) translateZ(15px) scale(1.1);
            }
            .lgr-interactive-dice.dice-rolling {
                animation: lgrDicePopOutRoll 0.95s cubic-bezier(0.2, 0.85, 0.35, 1.2) forwards;
                z-index: 99 !important;
            }

            .lgr-dice-aura-glow {
                position: absolute;
                inset: -6px;
                border-radius: 50%;
                background: radial-gradient(circle, var(--dice-aura, #38bdf8) 40%, transparent 74%);
                opacity: 0.5;
                transition: opacity 0.25s, transform 0.25s;
                pointer-events: none;
            }
            .lgr-dice-cube-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: transform 0.15s;
            }
            .lgr-interactive-dice.dice-rolling .lgr-dice-aura-glow {
                opacity: 1;
                transform: scale(1.5);
                background: radial-gradient(circle, var(--dice-aura, #38bdf8) 58%, transparent 85%);
                box-shadow: 0 0 45px var(--dice-aura, #38bdf8);
            }

            .lgr-floating-toast {
                position: absolute;
                top: -12px;
                left: 50%;
                transform: translate(-50%, 0);
                background: linear-gradient(135deg, #0f172a, #1e293b);
                border: 1.5px solid var(--float-border, #facc15);
                color: #ffffff;
                font-size: 11px;
                font-weight: 900;
                padding: 3px 10px;
                border-radius: 999px;
                white-space: nowrap;
                box-shadow: 0 4px 14px rgba(0,0,0,0.55);
                z-index: 15;
                pointer-events: none;
                animation: lgrFloatBadge 1.25s ease-out forwards;
            }

            .lgr-avatar-mode-pill {
                background: linear-gradient(180deg, #38bdf8 0%, #0284c7 100%);
                color: #ffffff;
                border: 1.5px solid #bae6fd;
                border-radius: 999px;
                padding: 3px 12px;
                font-size: 11.5px;
                font-weight: 800;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(2, 132, 199, 0.35);
                transition: transform 0.15s, filter 0.15s;
                white-space: nowrap;
            }
            .lgr-avatar-mode-pill:hover {
                transform: scale(1.04);
                filter: brightness(1.1);
            }

            /* Legacy fallback */
            .lgr-card-buy-bar {
                width: 100%;
                border: none;
                padding: 10px 10px;
                color: #ffffff;
                font-size: 15px;
                font-weight: 900;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                letter-spacing: 0.2px;
                transition: filter 0.15s;
            }
            .lgr-card-buy-bar:hover:not(:disabled) {
                filter: brightness(1.12);
            }
            .lgr-card-buy-bar:disabled {
                opacity: 0.55;
                cursor: not-allowed;
            }

            /* Modern Standout Action Bar & Small Price Pill */
            .lgr-card-action-bar {
                width: 100%;
                padding: 4px 6px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 5px;
                box-sizing: border-box;
                border-top: 1.5px solid rgba(255, 255, 255, 0.35);
                background: rgba(15, 23, 42, 0.85) !important;
                backdrop-filter: blur(4px);
                position: relative;
                z-index: 5;
                flex-shrink: 0 !important;
                margin-top: auto !important;
            }
            .lgr-card-action-bar.dual {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 4px;
                padding: 4px 5px;
            }
            .lgr-card-action-bar.single {
                display: flex;
            }

            /* Small, sleek price badge */
            .lgr-card-price-pill {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                background: rgba(15, 23, 42, 0.95);
                padding: 2px 6px;
                border-radius: 7px;
                border: 1px solid rgba(255, 255, 255, 0.28);
                box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.55);
                min-width: 46px;
                flex-shrink: 0 !important;
            }
            .lgr-card-price-pill .lgr-price-sub {
                font-size: 8px;
                font-weight: 800;
                color: #94a3b8;
                text-transform: uppercase;
                letter-spacing: 0.3px;
                line-height: 1;
                margin-bottom: 1px;
            }
            .lgr-card-price-pill .lgr-price-amount {
                font-size: 11.5px;
                font-weight: 900;
                color: #f8fafc;
                line-height: 1.15;
                white-space: nowrap;
                letter-spacing: 0.2px;
            }

            /* Prominent Eye-Catching Standout Buy Button */
            .lgr-btn-buy-prominent {
                flex: 1;
                min-width: 0;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 4px;
                padding: 6px 8px;
                border-radius: 8px;
                border: 1.5px solid #ffffff;
                background: linear-gradient(180deg, #ffe548 0%, #f59e0b 52%, #d97706 100%);
                color: #0f172a;
                font-weight: 900;
                font-size: 12px;
                cursor: pointer;
                box-shadow: 0 3px 10px rgba(245, 158, 11, 0.6), inset 0 1.5px 0 rgba(255, 255, 255, 0.85);
                text-shadow: 0 1px 0 rgba(255, 255, 255, 0.6);
                transition: transform 0.15s ease, box-shadow 0.15s ease, filter 0.15s ease;
                white-space: nowrap;
                flex-shrink: 0 !important;
            }
            .lgr-btn-buy-prominent:hover:not(:disabled) {
                transform: translateY(-2px) scale(1.03);
                box-shadow: 0 6px 20px rgba(245, 158, 11, 0.88), inset 0 2px 0 #ffffff;
                filter: brightness(1.12);
            }
            .lgr-btn-buy-prominent:active:not(:disabled) {
                transform: translateY(1px) scale(0.98);
            }
            .lgr-btn-buy-prominent:disabled {
                background: #475569;
                border-color: #64748b;
                color: #cbd5e1;
                box-shadow: none;
                cursor: not-allowed;
                opacity: 0.65;
            }
            .lgr-btn-buy-prominent.btn-free {
                background: linear-gradient(180deg, #22c55e 0%, #16a34a 55%, #15803d 100%);
                color: #ffffff;
                box-shadow: 0 4px 14px rgba(34, 197, 94, 0.6), inset 0 2px 0 rgba(255, 255, 255, 0.65);
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
                font-size: 12.5px;
                padding: 7px 10px;
            }
            .lgr-btn-buy-prominent.btn-dia {
                background: linear-gradient(180deg, #38bdf8 0%, #0284c7 55%, #0369a1 100%);
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(2, 132, 199, 0.55), inset 0 2px 0 rgba(255, 255, 255, 0.65);
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
                padding: 4px 4px;
                font-size: 11px;
                flex-direction: column;
                gap: 1px;
            }
            .lgr-btn-buy-prominent.btn-gold {
                background: linear-gradient(180deg, #fbbf24 0%, #d97706 55%, #b45309 100%);
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(217, 119, 6, 0.55), inset 0 2px 0 rgba(255, 255, 255, 0.65);
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
                padding: 4px 4px;
                font-size: 11px;
                flex-direction: column;
                gap: 1px;
            }
            .lgr-btn-buy-prominent.btn-gold {
                background: linear-gradient(180deg, #f59e0b 0%, #d97706 55%, #b45309 100%);
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(217, 119, 6, 0.55), inset 0 2px 0 rgba(255, 255, 255, 0.65);
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
                padding: 6px 5px;
                font-size: 13px;
                flex-direction: column;
                gap: 2px;
            }
            .lgr-btn-owned {
                width: 100%;
                padding: 9px 8px;
                border-radius: 10px;
                border: 2px solid #86efac;
                background: linear-gradient(180deg, #22c55e, #15803d);
                color: #fff;
                font-size: 13px;
                font-weight: 900;
                cursor: pointer;
                box-shadow: 0 3px 10px rgba(22, 163, 74, 0.4), inset 0 1px 0 rgba(255,255,255,0.4);
            }
            .lgr-badge-mini {
                font-size: 11px;
                font-weight: 800;
                background: rgba(0, 0, 0, 0.28);
                padding: 1px 6px;
                border-radius: 999px;
            }

            /* Payment Method Selection & Checkout Modal */
            .lgr-pay-overlay {
                position: fixed;
                inset: 0;
                z-index: 100000;
                background: rgba(3, 7, 18, 0.85);
                backdrop-filter: blur(6px);
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 16px;
                box-sizing: border-box;
                animation: lgrPayFadeIn 0.2s ease-out;
            }
            @keyframes lgrPayFadeIn {
                from { opacity: 0; transform: scale(0.96); }
                to { opacity: 1; transform: scale(1); }
            }
            .lgr-pay-box {
                width: 490px;
                max-width: 96vw;
                max-height: 92vh;
                overflow-y: auto;
                background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
                border: 2px solid #38bdf8;
                border-radius: 20px;
                box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8), 0 0 35px rgba(56, 189, 248, 0.35);
                display: flex;
                flex-direction: column;
                color: #ffffff;
                box-sizing: border-box;
            }
            .lgr-pay-header {
                padding: 14px 18px;
                background: linear-gradient(90deg, #0284c7 0%, #1e40af 100%);
                border-bottom: 2px solid #38bdf8;
                border-radius: 18px 18px 0 0;
                display: flex;
                align-items: center;
                justify-content: space-between;
                flex-shrink: 0;
            }
            .lgr-pay-title-group {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .lgr-pay-header-icon {
                font-size: 20px;
            }
            .lgr-pay-header-title {
                font-size: 17px;
                font-weight: 900;
                color: #ffffff;
                letter-spacing: 0.3px;
                text-shadow: 0 2px 4px rgba(0,0,0,0.4);
            }
            .lgr-pay-close-btn {
                background: rgba(255, 255, 255, 0.15);
                border: 1px solid rgba(255, 255, 255, 0.3);
                color: #ffffff;
                width: 32px;
                height: 32px;
                border-radius: 50%;
                font-size: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: background 0.15s;
                line-height: 1;
            }
            .lgr-pay-close-btn:hover {
                background: #ef4444;
                border-color: #f87171;
            }
            .lgr-pay-body {
                padding: 16px 18px;
                display: flex;
                flex-direction: column;
                gap: 14px;
                box-sizing: border-box;
            }
            .lgr-pay-product-brief {
                background: rgba(255, 255, 255, 0.06);
                border: 1.5px solid rgba(56, 189, 248, 0.3);
                border-radius: 14px;
                padding: 12px 14px;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .lgr-pay-product-icon {
                width: 64px;
                height: 64px;
                border-radius: 12px;
                background: rgba(15, 23, 42, 0.8);
                border: 1.5px solid #38bdf8;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .lgr-pay-product-info {
                flex: 1;
                min-width: 0;
            }
            .lgr-pay-product-title {
                font-size: 15px;
                font-weight: 900;
                color: #fde047;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .lgr-pay-product-rewards {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                margin-top: 5px;
            }
            .lgr-pay-reward-tag {
                font-size: 11.5px;
                font-weight: 800;
                padding: 2px 8px;
                border-radius: 999px;
                background: rgba(30, 58, 138, 0.8);
                color: #38bdf8;
                border: 1px solid rgba(56, 189, 248, 0.4);
            }
            .lgr-pay-reward-tag.gold {
                background: rgba(120, 53, 15, 0.8);
                color: #fde047;
                border-color: rgba(251, 191, 36, 0.4);
            }
            .lgr-pay-product-price {
                text-align: right;
                flex-shrink: 0;
            }
            .lgr-pay-price-label {
                font-size: 11px;
                color: #94a3b8;
                font-weight: 700;
            }
            .lgr-pay-price-val {
                font-size: 18px;
                font-weight: 900;
                color: #38bdf8;
            }
            .lgr-pay-methods-list {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .lgr-pay-method-item {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                padding: 10px 14px;
                border-radius: 12px;
                background: rgba(255, 255, 255, 0.04);
                border: 1.5px solid rgba(255, 255, 255, 0.12);
                cursor: pointer;
                transition: all 0.15s ease;
            }
            .lgr-pay-method-item:hover {
                background: rgba(56, 189, 248, 0.1);
                border-color: rgba(56, 189, 248, 0.5);
            }
            .lgr-pay-method-item.active {
                background: rgba(2, 132, 199, 0.22);
                border-color: #38bdf8;
                box-shadow: 0 0 12px rgba(56, 189, 248, 0.35);
            }
            .lgr-pay-method-left {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .lgr-pay-method-icon {
                font-size: 24px;
                width: 32px;
                text-align: center;
            }
            .lgr-pay-method-text {
                display: flex;
                flex-direction: column;
            }
            .lgr-pay-method-title {
                font-size: 13.5px;
                font-weight: 800;
                color: #f8fafc;
            }
            .lgr-pay-method-desc {
                font-size: 11px;
                color: #94a3b8;
            }
            .lgr-pay-method-tag {
                font-size: 10px;
                font-weight: 900;
                background: linear-gradient(135deg, #ef4444, #dc2626);
                color: #fff;
                padding: 2px 7px;
                border-radius: 999px;
            }
            .lgr-pay-confirm-btn {
                width: 100%;
                background: linear-gradient(180deg, #ffe548 0%, #f59e0b 55%, #d97706 100%);
                color: #0f172a;
                font-weight: 900;
                font-size: 16px;
                padding: 12px;
                border-radius: 12px;
                border: 2px solid #ffffff;
                cursor: pointer;
                box-shadow: 0 4px 16px rgba(245, 158, 11, 0.65), inset 0 2px 0 #fff;
                transition: transform 0.15s, filter 0.15s;
            }
            .lgr-pay-confirm-btn:hover {
                transform: translateY(-2px);
                filter: brightness(1.1);
            }
            .lgr-pay-processing-box {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                padding: 10px 6px;
                gap: 14px;
            }
            .lgr-promptpay-slip {
                background: #ffffff;
                color: #0f172a;
                border-radius: 14px;
                overflow: hidden;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4);
                width: 240px;
                display: flex;
                flex-direction: column;
                border: 2px solid #003b71;
            }
            .lgr-pp-header {
                background: #003b71;
                color: #ffffff;
                padding: 8px 10px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .lgr-pp-qr-container {
                padding: 10px;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #fff;
            }
            .lgr-pp-qr-svg {
                width: 140px;
                height: 140px;
            }
            .lgr-pp-details {
                background: #f8fafc;
                border-top: 1px dashed #cbd5e1;
                padding: 8px;
                text-align: center;
            }
            .lgr-pay-status-pill {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                background: rgba(245, 158, 11, 0.2);
                border: 1.5px solid #f59e0b;
                color: #fde047;
                font-size: 12.5px;
                font-weight: 800;
                padding: 5px 14px;
                border-radius: 999px;
            }
            .lgr-pay-progress-track {
                width: 100%;
                height: 10px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 999px;
                overflow: hidden;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .lgr-pay-progress-fill {
                height: 100%;
                width: 0%;
                background: linear-gradient(90deg, #38bdf8, #22c55e);
                border-radius: 999px;
                transition: width 0.1s linear;
            }
            .lgr-pay-success-box {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                padding: 12px 6px;
                gap: 14px;
                animation: lgrPayPopIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            }
            @keyframes lgrPayPopIn {
                from { transform: scale(0.85); opacity: 0; }
                to { transform: scale(1); opacity: 1; }
            }
            .lgr-success-badge-circle {
                width: 68px;
                height: 68px;
                border-radius: 50%;
                background: linear-gradient(135deg, #22c55e, #15803d);
                border: 3px solid #86efac;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 34px;
                color: #fff;
                box-shadow: 0 0 25px rgba(34, 197, 94, 0.6);
            }
            .lgr-reward-received-container {
                width: 100%;
                background: linear-gradient(180deg, rgba(30,58,138,0.5) 0%, rgba(15,23,42,0.85) 100%);
                border: 2px solid #38bdf8;
                border-radius: 14px;
                padding: 14px;
                box-sizing: border-box;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .lgr-reward-received-row {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 16px;
                font-weight: 900;
            }
            .lgr-reward-received-row.dia {
                color: #38bdf8;
                border-color: #38bdf8;
                box-shadow: 0 0 15px rgba(56, 189, 248, 0.35);
            }
            .lgr-reward-received-row.gold {
                color: #fde047;
                border-color: #facc15;
                box-shadow: 0 0 15px rgba(250, 204, 21, 0.35);
            }
            .lgr-reward-balance-summary {
                display: flex;
                justify-content: space-around;
                width: 100%;
                background: rgba(0, 0, 0, 0.35);
                border-radius: 10px;
                padding: 8px 12px;
                font-size: 12.5px;
                color: #cbd5e1;
            }

            /* Scroll Arrow Buttons */
            .lgr-scroll-arrow {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                z-index: 6;
                width: 34px;
                height: 54px;
                border-radius: 10px;
                border: 1.5px solid rgba(255,255,255,0.8);
                background: rgba(30, 58, 138, 0.78);
                color: #fff;
                font-size: 18px;
                font-weight: 900;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            }
            .lgr-scroll-arrow.left { left: 4px; }
            .lgr-scroll-arrow.right { right: 4px; }

            /* Bottom Utility Bar (Yellow Pill Buttons like Video!) */
            .lgr-stage-footer {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
                padding: 5px 12px;
                background: rgba(241, 245, 249, 0.95);
                border-top: 1px solid #cbd5e1;
                flex-shrink: 0;
                flex-wrap: wrap;
            }
            .lgr-yellow-pill-btn {
                background: linear-gradient(180deg, #ffe84d 0%, #facc15 100%);
                color: #0f172a;
                border: 1.5px solid #eab308;
                border-radius: 999px;
                padding: 5px 15px;
                font-size: 12px;
                font-weight: 900;
                cursor: pointer;
                box-shadow: 0 2px 6px rgba(234, 179, 8, 0.35);
            }
            .lgr-yellow-pill-btn.secondary {
                background: linear-gradient(180deg, #ffffff 0%, #e2e8f0 100%);
                border-color: #94a3b8;
                color: #1e293b;
            }

            /* PICK UP Hero Banner (Clean, Compact, No Top/Bottom Overflow) */
            .lgr-pickup-hero {
                width: 100%;
                box-sizing: border-box;
                border-radius: 16px;
                padding: 12px 18px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                background: radial-gradient(circle at 30% 45%, #312e81 0%, #1e1b4b 55%, #090d16 100%);
                border: 2px solid #fbbf24;
                color: #fff;
                position: relative;
                margin: 0;
                flex-shrink: 0;
                box-shadow: 0 8px 24px rgba(15, 23, 42, 0.4);
            }

            /* Compact Mobile Landscape Responsiveness */
            @media (max-height: 520px) {
                #modal-shop .lgr-shop-shell { height: 98vh !important; height: 98dvh !important; max-height: 98dvh !important; border-radius: 12px !important; }
                .lgr-shop-topbar { padding: 4px 10px; }
                .lgr-subtabs-bar { padding: 3px 8px; }
                .lgr-stage-footer { padding: 3px 10px; font-size: 10px; }
                .lgr-stage-body { padding: 2px 6px 1px 6px; }
                .lgr-cards-track { gap: 8px; padding: 2px 2px 4px 2px; }
                .lgr-card-top { padding: 2px 4px 1px 4px; }
                .lgr-card-title { font-size: 11px; }
                .lgr-card-limit { font-size: 8px; }
                .lgr-reward-pill { font-size: 8px; padding: 1px 4px; }
                .lgr-card-action-bar { padding: 3px 4px; }
                .lgr-btn-buy-prominent { padding: 4px 6px; font-size: 11px; }
                .lgr-card-price-pill { padding: 1px 4px; min-width: 40px; }
                .lgr-card-price-pill .lgr-price-amount { font-size: 10px; }
            }

            /* Mobile Landscape Compact Responsiveness */
            @media (max-width: 920px) {
                .lgr-shop-sidebar { width: 165px; padding: 7px 6px; }
                .lgr-menu-btn { padding: 8px 10px; font-size: 12.5px; }
                .lgr-tall-card { min-width: 182px; }
                .lgr-card-title { font-size: 13px; }
                .lgr-card-buy-bar { padding: 8px 8px; font-size: 14px; }
                .lgr-shop-topbar { padding: 5px 10px; }
                .lgr-shop-title-text { font-size: 16px; }
            }
            @media (max-width: 640px) and (orientation: portrait) {
                .lgr-shop-body { flex-direction: column; }
                .lgr-shop-sidebar {
                    width: 100%;
                    flex-direction: row;
                    overflow-x: auto;
                    overflow-y: hidden;
                    padding: 6px;
                }
                .lgr-shop-sidebar::after { display: none; }
                .lgr-menu-btn { width: auto; }
                .lgr-tall-card { flex: 0 0 76%; min-width: 210px; }
            }

            /* Realistic 3D Gold Bars Visual & Sparkling Animations (ทองแท่ง 3D วิบวับ) */
            .lgr-gold-bars-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                user-select: none;
            }
            .gold-sparkle-star {
                animation: goldSparkleTwinkle 1.8s ease-in-out infinite alternate;
                pointer-events: none;
            }
            @keyframes goldSparkleTwinkle {
                0% { transform: scale(0.15) rotate(0deg); opacity: 0.1; }
                50% { transform: scale(1.25) rotate(45deg); opacity: 1; filter: drop-shadow(0 0 6px #ffffff) drop-shadow(0 0 10px #fde047); }
                100% { transform: scale(0.25) rotate(90deg); opacity: 0.2; }
            }
            @keyframes goldAuraPulsate {
                0% { transform: scale(0.94); opacity: 0.55; }
                50% { transform: scale(1.08); opacity: 0.95; }
                100% { transform: scale(0.94); opacity: 0.55; }
            }
            @keyframes goldSheenSweep {
                0% { transform: translateX(-100%) rotate(35deg); opacity: 0; }
                25% { opacity: 0.9; }
                50% { transform: translateX(100%) rotate(35deg); opacity: 0; }
                100% { transform: translateX(100%) rotate(35deg); opacity: 0; }
            }

            /* Brilliant 3D Diamond Aura & Sparkle Animations (เพชรประกาย 3D & เออร่า) */
            .lgr-diamond-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                user-select: none;
                flex-shrink: 0;
            }
            .dia-sparkle-star {
                animation: diamondSparkleTwinkle 1.8s ease-in-out infinite alternate;
                pointer-events: none;
            }
            @keyframes diamondAuraPulse {
                0% { transform: scale(0.90); opacity: 0.55; }
                50% { transform: scale(1.14); opacity: 0.95; filter: drop-shadow(0 0 10px rgba(56, 189, 248, 0.9)); }
                100% { transform: scale(0.90); opacity: 0.55; }
            }
            @keyframes diamondSparkleTwinkle {
                0% { transform: scale(0.1) rotate(0deg); opacity: 0; }
                50% { transform: scale(1.25) rotate(45deg); opacity: 1; filter: drop-shadow(0 0 5px #ffffff) drop-shadow(0 0 9px #38bdf8); }
                100% { transform: scale(0.2) rotate(90deg); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }

    function ensureShopModalStructure() {
        injectShopShowcaseStyles();

        // Upgrade Header & Left Menu Shop Buttons visually
        const topBtn = document.getElementById('btn-open-shop');
        if (topBtn && !topBtn.classList.contains('btn-shop-video')) {
            topBtn.classList.add('btn-shop-video');
            topBtn.innerHTML = '<span>🏪</span><span>ร้านค้า</span><span class="shop-hot-pill">HOT</span>';
            topBtn.onclick = () => window.openShopShowcaseModal('featured');
        }

        const diaPill = document.querySelector('.currency-pill.diamond');
        if (diaPill) {
            diaPill.onclick = () => window.openShopShowcaseModal('diamond');
        }
        const goldPill = document.querySelector('.currency-pill.gold');
        if (goldPill) {
            goldPill.onclick = () => window.openShopShowcaseModal('gold');
        }
        const leftShopCard = document.querySelector('.big-feature-card.card-shop');
        if (leftShopCard && !leftShopCard.dataset.lgrUpgraded) {
            leftShopCard.dataset.lgrUpgraded = '1';
            leftShopCard.onclick = () => window.openShopShowcaseModal('featured');
            leftShopCard.innerHTML = `
                <span class="shop-card-ribbon">HOT</span>
                <div class="card-icon">🏪</div>
                <div class="card-title">ร้านค้า</div>
                <div class="card-sub" style="color:#fde047; font-weight:800;">เพชร • ทอง • กรอบ • เต๋า</div>
            `;
        }

        const modal = document.getElementById('modal-shop');
        if (!modal) return;
        if (modal.dataset.lgrMounted === '1' && modal.querySelector('.lgr-shop-shell')) return;
        modal.dataset.lgrMounted = '1';
        if (!modal.querySelector('.lgr-shop-shell')) {
        modal.innerHTML = `
            <div class="modal-content lgr-shop-shell">
                <!-- Top Header Bar -->
                <div class="lgr-shop-topbar">
                    <button type="button" class="lgr-shop-back-btn" onclick="closeModal('modal-shop')">
                        <span class="lgr-shop-back-arrow">❮</span>
                        <span class="lgr-shop-title-text">ร้านค้า</span>
                    </button>

                    <div class="lgr-shop-wallets">
                        <div class="lgr-wallet-chip" onclick="window.selectShopMenu('gold')" title="ไปยังร้านค้าทอง">
                            <span>🪙</span>
                            <span id="lgr-shop-gold-val">0</span>
                            <span class="plus-badge">+</span>
                        </div>
                        <div class="lgr-wallet-chip" onclick="window.selectShopMenu('diamond')" title="ไปยังร้านค้าเพชร">
                            <span>💎</span>
                            <span id="lgr-shop-dia-val">0</span>
                            <span class="plus-badge">+</span>
                        </div>
                        <button type="button" class="lgr-top-inv-btn" onclick="closeModal('modal-shop'); if (typeof openInventoryModal === 'function') openInventoryModal();">
                            🎒 คลังไอเทม
                        </button>
                        <button type="button" class="lgr-top-close-btn" onclick="closeModal('modal-shop')" title="ปิดหน้าร้านค้า">✕</button>
                    </div>
                </div>

                <!-- Main Split Content -->
                <div class="lgr-shop-body">
                    <!-- Left Blue Starry Sidebar -->
                    <aside class="lgr-shop-sidebar" id="lgr-shop-sidebar-list"></aside>

                    <!-- Right Showcase Stage -->
                    <section class="lgr-shop-stage">
                        <div class="lgr-subtabs-bar" id="lgr-shop-subtabs-bar"></div>
                        <div class="lgr-stage-body" id="lgr-shop-stage-body">
                            <button type="button" class="lgr-scroll-arrow left" id="lgr-scroll-left" onclick="window.scrollShopCards(-1)" style="display:none;">❮</button>
                            <div class="lgr-cards-track" id="lgr-shop-cards-track"></div>
                            <button type="button" class="lgr-scroll-arrow right" id="lgr-scroll-right" onclick="window.scrollShopCards(1)" style="display:none;">❯</button>
                        </div>
                        <div class="lgr-stage-footer">
                            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                <button type="button" class="lgr-yellow-pill-btn" onclick="window.showShopRatesInfoPopup()">
                                    📊 ตรวจสอบอัตรา / รายละเอียดร้านค้า
                                </button>
                                <button type="button" class="lgr-yellow-pill-btn secondary" onclick="window.selectShopMenu('frames', 2)">
                                    ⚡ อัปเกรดการ์ด Lv.30
                                </button>
                            </div>
                            <div style="font-size:11.5px; color:#475569; font-weight:700;" id="lgr-shop-footer-hint">
                                💡 ปัดซ้าย-ขวา เพื่อเลือกดูสินค้าทั้งหมดในหมวดนี้
                            </div>
                        </div>
                    </section>
                </div>

                <!-- Hidden legacy containers for backward compatibility with older scripts -->
                <div style="display:none;">
                    <span id="gacha-event-title"></span>
                    <span id="gacha-event-period"></span>
                    <span id="gacha-cost-label"></span>
                    <span id="gacha-cards-per-pack-label"></span>
                    <div id="gacha-rates-bar"></div>
                    <div id="shop-crafting-box"></div>
                    <div id="packages-container"></div>
                    <div id="inventory-cards-list"></div>
                </div>
            </div>
        `;
        }
    }

    function syncWalletHeaderNumbers() {
        const u = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? DEFAULT_USER : {};
        const barDia = document.getElementById('bar-diamond')?.innerText;
        const barGold = document.getElementById('bar-gold')?.innerText;
        const diaEl = document.getElementById('lgr-shop-dia-val');
        const goldEl = document.getElementById('lgr-shop-gold-val');
        if (diaEl) diaEl.innerText = u.diamond !== undefined ? fmtNum(u.diamond) : (barDia || '0');
        if (goldEl) goldEl.innerText = u.gold !== undefined ? fmtNum(u.gold) : (barGold || '0');
    }

    function getDefaultMenusFallback() {
        return [
            { menu_slug: 'featured', title: 'ร้านค้าแนะนำ', icon: '🔥', menu_type: 'FEATURED', subtabs: ['ร้านค้าจำกัด', 'โปรโมชั่นสุดคุ้ม', 'แพ็กเกจ 1+1'], badge_text: 'HOT' },
            { menu_slug: 'diamond', title: 'ร้านค้าเพชร', icon: '💎', menu_type: 'DIAMOND', subtabs: ['เพชรทั้งหมด', 'รับเพชรฟรี'], badge_text: '' },
            { menu_slug: 'gold', title: 'ร้านค้าทอง', icon: '🪙', menu_type: 'GOLD', subtabs: ['แลกทองด้วยเพชร', 'แพ็กเกจทอง'], badge_text: '' },
            { menu_slug: 'frames', title: 'การ์ดกรอบ', icon: '👑', menu_type: 'FRAME', subtabs: ['การ์ดกรอบทั้งหมด', 'ระดับ SS+ / S+', 'อัปเกรด Lv.30'], badge_text: 'SS+' },
            { menu_slug: 'dice', title: 'ลูกเต๋า', icon: '🎲', menu_type: 'DICE', subtabs: ['ลูกเต๋าทั้งหมด', 'ลูกเต๋าระดับแรร์'], badge_text: '3D' },
            { menu_slug: 'pickup_frame', title: 'PICK UP การ์ดกรอบ', icon: '✨', menu_type: 'PICKUP_FRAME', subtabs: ['สุ่มแพ็คการ์ดกรอบ', 'แลกเงาการ์ด'], badge_text: 'PICK UP' },
            { menu_slug: 'pickup_dice', title: 'PICK UP ลูกเต๋า', icon: '🎯', menu_type: 'PICKUP_DICE', subtabs: ['สุ่มลูกเต๋า 3D'], badge_text: 'PICK UP' }
        ];
    }

    function isOwnedItem(itemType, id) {
        const inv = SHOP_STATE.inventory?.inventory || [];
        return inv.some(row => {
            if (itemType === 'CHARACTER') return Number(row.character_id || row.char_id) === Number(id);
            if (itemType === 'DICE') return Number(row.dice_id) === Number(id);
            return false;
        });
    }

    function getOwnedInventoryId(itemType, id) {
        const inv = SHOP_STATE.inventory?.inventory || [];
        const found = inv.find(row => {
            if (itemType === 'CHARACTER') return Number(row.character_id || row.char_id) === Number(id);
            if (itemType === 'DICE') return Number(row.dice_id) === Number(id);
            return false;
        });
        return found ? Number(found.id) : 0;
    }

    function buildDiamondSvgVisual(amount, options = {}) {
        const amt = Number(amount || 0);
        const isMini = Boolean(options.mini);
        const uid = 'dia_' + Math.random().toString(36).substr(2, 7);

        // Tiers: 1: < 500 (เพชรน้อย), 2: 500 - 9,999 (เพชรปานกลาง), 3: >= 10,000 (เพชรเยอะมหาศาล)
        const tier = amt >= 10000 ? 3 : (amt >= 500 ? 2 : 1);

        const svgW = isMini ? (options.size || 36) : (tier === 3 ? 60 : (tier === 2 ? 56 : 52));
        const svgH = Math.round(svgW * 0.74);
        const auraSize = isMini ? 36 : (tier === 3 ? 56 : (tier === 2 ? 50 : 44));
        const auraOpacity = tier === 3 ? '0.85' : (tier === 2 ? '0.70' : '0.55');

        let sparkles = [];
        if (isMini) {
            sparkles = [
                { x: 18, y: 14, s: 0.85, d: '0s' },
                { x: 58, y: 12, s: 0.95, d: '0.7s' }
            ];
        } else if (tier === 3) {
            sparkles = [
                { x: 16, y: 12, s: 1.15, d: '0s' },
                { x: 60, y: 10, s: 1.3, d: '0.4s' },
                { x: 68, y: 32, s: 0.95, d: '0.9s' },
                { x: 38, y: 48, s: 1.1, d: '1.3s' },
                { x: 26, y: 32, s: 0.9, d: '1.7s' }
            ];
        } else if (tier === 2) {
            sparkles = [
                { x: 18, y: 14, s: 1.0, d: '0s' },
                { x: 58, y: 12, s: 1.15, d: '0.6s' },
                { x: 38, y: 46, s: 0.9, d: '1.2s' }
            ];
        } else {
            sparkles = [
                { x: 20, y: 14, s: 0.9, d: '0.1s' },
                { x: 56, y: 14, s: 0.9, d: '0.9s' }
            ];
        }

        const sparklesHtml = sparkles.map(sp => `
            <g class="dia-sparkle-star" style="transform-origin: ${sp.x}px ${sp.y}px; animation-delay: ${sp.d};">
                <path d="M 0,-8 Q 0,0 8,0 Q 0,0 0,8 Q 0,0 -8,0 Q 0,0 0,-8 Z" fill="#ffffff" transform="translate(${sp.x}, ${sp.y}) scale(${sp.s})" filter="drop-shadow(0 0 3px #38bdf8)" />
                <circle cx="${sp.x}" cy="${sp.y}" r="2" fill="#e0f2fe" />
            </g>
        `).join('');

        return `
            <div class="lgr-diamond-wrap" style="width:${svgW + 4}px; height:${svgH}px; position:relative; display:flex; align-items:center; justify-content:center;">
                <!-- Ambient Breathing Diamond Aura -->
                <div style="position:absolute; width:${auraSize}px; height:${auraSize}px; border-radius:50%; background:radial-gradient(circle, rgba(56,189,248,${auraOpacity}) 0%, rgba(14,165,233,${parseFloat(auraOpacity)*0.4}) 45%, rgba(2,132,199,0) 75%); filter:blur(7px); animation:diamondAuraPulse 2.4s ease-in-out infinite; pointer-events:none;"></div>

                <!-- 3D Brilliant Diamond Facets SVG -->
                <svg width="${svgW}" height="${svgH}" viewBox="0 0 76 60" style="overflow:visible; filter:drop-shadow(0 4px 12px rgba(14,165,233,0.55));">
                    <defs>
                        <linearGradient id="${uid}_table" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#ffffff" />
                            <stop offset="35%" stop-color="#e0f2fe" />
                            <stop offset="100%" stop-color="#7dd3fc" />
                        </linearGradient>
                        <linearGradient id="${uid}_crownL" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#bae6fd" />
                            <stop offset="100%" stop-color="#0284c7" />
                        </linearGradient>
                        <linearGradient id="${uid}_crownR" x1="100%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stop-color="#e0f2fe" />
                            <stop offset="100%" stop-color="#0369a1" />
                        </linearGradient>
                        <linearGradient id="${uid}_pavilionMid" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stop-color="#38bdf8" />
                            <stop offset="60%" stop-color="#0284c7" />
                            <stop offset="100%" stop-color="#075985" />
                        </linearGradient>
                        <linearGradient id="${uid}_pavilionL" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#0284c7" />
                            <stop offset="100%" stop-color="#0369a1" />
                        </linearGradient>
                        <linearGradient id="${uid}_pavilionR" x1="100%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stop-color="#7dd3fc" />
                            <stop offset="100%" stop-color="#0284c7" />
                        </linearGradient>
                    </defs>

                    <!-- Pavilion (Lower Body Facets) -->
                    <polygon points="6,20 38,54 22,20" fill="url(#${uid}_pavilionL)" stroke="#38bdf8" stroke-width="0.75" />
                    <polygon points="22,20 38,54 54,20" fill="url(#${uid}_pavilionMid)" stroke="#7dd3fc" stroke-width="0.75" />
                    <polygon points="54,20 38,54 70,20" fill="url(#${uid}_pavilionR)" stroke="#38bdf8" stroke-width="0.75" />

                    <!-- Crown Side Facets -->
                    <polygon points="6,20 20,6 22,20" fill="url(#${uid}_crownL)" stroke="#bae6fd" stroke-width="0.75" />
                    <polygon points="54,20 56,6 70,20" fill="url(#${uid}_crownR)" stroke="#bae6fd" stroke-width="0.75" />

                    <!-- Crown Center Facets -->
                    <polygon points="20,6 38,20 56,6" fill="#e0f2fe" opacity="0.95" stroke="#ffffff" stroke-width="0.75" />
                    <polygon points="20,6 22,20 38,20" fill="#7dd3fc" opacity="0.85" stroke="#bae6fd" stroke-width="0.6" />
                    <polygon points="56,6 54,20 38,20" fill="#38bdf8" opacity="0.85" stroke="#bae6fd" stroke-width="0.6" />

                    <!-- Top Table (Flat reflective top facet) -->
                    <polygon points="20,6 56,6 50,11 26,11" fill="url(#${uid}_table)" stroke="#ffffff" stroke-width="0.9" />

                    <!-- Specular Highlight Bevel Lines -->
                    <line x1="20" y1="6" x2="56" y2="6" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round" />
                    <line x1="20" y1="6" x2="6" y2="20" stroke="#ffffff" stroke-width="1.0" stroke-linecap="round" />
                    <line x1="6" y1="20" x2="38" y2="54" stroke="rgba(255,255,255,0.7)" stroke-width="0.8" />
                    <line x1="20" y1="6" x2="38" y2="20" stroke="rgba(255,255,255,0.85)" stroke-width="0.8" />

                    <!-- Sparkles Layer -->
                    ${sparklesHtml}
                </svg>
            </div>
        `;
    }

    function buildGoldBarsVisual(amount, options = {}) {
        const amt = Number(amount || 0);
        const isMini = Boolean(options.mini);
        const width = options.width || (isMini ? (options.size || 44) : 84);
        const height = options.height || (isMini ? Math.round(width * 0.84) : 70);
        const uid = 'gb_' + Math.random().toString(36).substr(2, 7);

        // Tiers: 1: <1M (ทองน้อย), 2: 1M-4.99M (ทองปานกลาง), 3: 5M-9.99M (ทองเยอะ), 4: >=10M (ทองเยอะมาก)
        let tier = 1;
        if (amt >= 10000000) tier = 4;
        else if (amt >= 5000000) tier = 3;
        else if (amt >= 1000000) tier = 2;

        const defs = `
            <defs>
                <linearGradient id="${uid}_top" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#fffced" />
                    <stop offset="14%" stop-color="#fef08a" />
                    <stop offset="42%" stop-color="#f59e0b" />
                    <stop offset="72%" stop-color="#fbbf24" />
                    <stop offset="100%" stop-color="#d97706" />
                </linearGradient>
                <linearGradient id="${uid}_front" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#f59e0b" />
                    <stop offset="28%" stop-color="#d97706" />
                    <stop offset="100%" stop-color="#78350f" />
                </linearGradient>
                <linearGradient id="${uid}_side" x1="0%" y1="0%" x2="100%" y2="50%">
                    <stop offset="0%" stop-color="#b45309" />
                    <stop offset="60%" stop-color="#92400e" />
                    <stop offset="100%" stop-color="#451a03" />
                </linearGradient>
                <radialGradient id="${uid}_aura" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stop-color="#fde047" stop-opacity="0.85" />
                    <stop offset="45%" stop-color="#f59e0b" stop-opacity="0.45" />
                    <stop offset="85%" stop-color="#b45309" stop-opacity="0.1" />
                    <stop offset="100%" stop-color="#78350f" stop-opacity="0" />
                </radialGradient>
                <g id="${uid}_sparkle">
                    <path d="M 0,-11 Q 0,0 11,0 Q 0,0 0,11 Q 0,0 -11,0 Q 0,0 0,-11 Z" fill="#ffffff" filter="drop-shadow(0 0 4px #fff)" />
                    <circle cx="0" cy="0" r="2.8" fill="#fef08a" />
                </g>
            </defs>
        `;

        function renderBar(cx, cy, scale = 1, angle = 0, stamp = 'GOLD') {
            return `
                <g transform="translate(${cx}, ${cy}) rotate(${angle}) scale(${scale})">
                    <ellipse cx="0" cy="22" rx="36" ry="12" fill="rgba(0,0,0,0.5)" filter="blur(3px)" />
                    <polygon points="26,-13 34,0 16,22 8,9" fill="url(#${uid}_side)" stroke="#78350f" stroke-width="0.5" />
                    <polygon points="-26,4 8,9 16,22 -18,17" fill="url(#${uid}_front)" stroke="#78350f" stroke-width="0.5" />
                    <polygon points="-19,-18 26,-13 8,9 -26,4" fill="url(#${uid}_top)" stroke="#ffffff" stroke-width="0.75" />
                    <polygon points="-17,-15 23,-11 6,7 -23,3" fill="none" stroke="rgba(180,83,9,0.55)" stroke-width="0.7" />
                    <ellipse cx="11" cy="-4" rx="4.5" ry="3.2" fill="none" stroke="#b45309" stroke-width="0.7" stroke-dasharray="1.2,1" />
                    <circle cx="11" cy="-4" r="1.3" fill="#b45309" opacity="0.8" />
                    <text x="-6" y="-3" fill="#78350f" font-family="'Impact', 'Arial Black', sans-serif" font-size="7" font-weight="900" letter-spacing="0.8" transform="rotate(-6, -6, -3)">${stamp}</text>
                    <text x="-6" y="3" fill="#92400e" font-family="monospace" font-size="3.6" font-weight="700">999.9</text>
                    <line x1="-19" y1="-18" x2="26" y2="-13" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round" opacity="0.95" />
                    <line x1="-19" y1="-18" x2="-26" y2="4" stroke="#ffffff" stroke-width="0.9" stroke-linecap="round" opacity="0.85" />
                </g>
            `;
        }

        function renderCrossBar(cx, cy, scale = 1, angle = -35, stamp = 'GOLD') {
            return `
                <g transform="translate(${cx}, ${cy}) rotate(${angle}) scale(${scale})">
                    <ellipse cx="0" cy="20" rx="34" ry="11" fill="rgba(0,0,0,0.45)" filter="blur(3px)" />
                    <polygon points="-26,-13 -34,0 -16,22 -8,9" fill="url(#${uid}_side)" stroke="#78350f" stroke-width="0.5" />
                    <polygon points="26,4 -8,9 -16,22 18,17" fill="url(#${uid}_front)" stroke="#78350f" stroke-width="0.5" />
                    <polygon points="19,-18 -26,-13 -8,9 26,4" fill="url(#${uid}_top)" stroke="#ffffff" stroke-width="0.75" />
                    <polygon points="17,-15 -23,-11 -6,7 23,3" fill="none" stroke="rgba(180,83,9,0.55)" stroke-width="0.7" />
                    <text x="-12" y="-2" fill="#78350f" font-family="'Impact', 'Arial Black', sans-serif" font-size="6.8" font-weight="900" letter-spacing="0.8" transform="rotate(6, -12, -2)">${stamp}</text>
                    <text x="-10" y="3.5" fill="#92400e" font-family="monospace" font-size="3.4" font-weight="700">999.9</text>
                    <line x1="19" y1="-18" x2="-26" y2="-13" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round" opacity="0.95" />
                </g>
            `;
        }

        let barsContent = '';
        let sparklePositions = [];
        let auraRadius = 45;
        let auraOpacity = 0.6;
        let animSpeed = '1.8s';

        if (isMini) {
            // Compact mini version for payment modal / rows
            barsContent = `
                ${renderCrossBar(54, 56, 1.1, -30, 'GOLD')}
                ${renderBar(48, 44, 1.2, 20, 'GOLD')}
            `;
            sparklePositions = [
                { x: 30, y: 24, s: 0.9, delay: '0s' },
                { x: 74, y: 32, s: 1.1, delay: '0.6s' }
            ];
            auraRadius = 40;
            auraOpacity = 0.55;
        } else if (tier === 1) {
            // Tier 1 (< 1M, e.g. 500,000): 2 Gold Bars cross-stacked exactly like Image 2!
            barsContent = `
                ${renderCrossBar(54, 58, 1.15, -30, 'GOLD')}
                ${renderBar(46, 44, 1.25, 20, 'GOLD')}
            `;
            sparklePositions = [
                { x: 26, y: 24, s: 0.9, delay: '0s' },
                { x: 78, y: 32, s: 1.15, delay: '0.6s' },
                { x: 48, y: 68, s: 0.85, delay: '1.2s' }
            ];
            auraRadius = 46;
            auraOpacity = 0.55;
            animSpeed = '2.0s';
        } else if (tier === 2) {
            // Tier 2 (1M - 4.99M, e.g. 1.5M, 2.5M): 4 Gold Bars stacked with vivid sparkles
            barsContent = `
                ${renderCrossBar(38, 65, 1.1, -28, 'GOLD')}
                ${renderCrossBar(68, 65, 1.1, -28, 'GOLD')}
                ${renderBar(42, 45, 1.18, 18, 'GOLD')}
                ${renderBar(62, 38, 1.22, 22, 'GOLD')}
            `;
            sparklePositions = [
                { x: 20, y: 35, s: 0.85, delay: '0s' },
                { x: 74, y: 16, s: 1.25, delay: '0.4s' },
                { x: 88, y: 46, s: 0.95, delay: '0.8s' },
                { x: 44, y: 66, s: 1.05, delay: '1.3s' },
                { x: 26, y: 72, s: 0.8, delay: '1.7s' }
            ];
            auraRadius = 55;
            auraOpacity = 0.75;
            animSpeed = '1.7s';
        } else if (tier === 3) {
            // Tier 3 (5M - 9.99M, e.g. 5M): 7 Gold Bars Pyramid Stack
            barsContent = `
                ${renderCrossBar(28, 70, 0.95, -25, 'GOLD')}
                ${renderCrossBar(54, 70, 0.95, -25, 'GOLD')}
                ${renderCrossBar(78, 70, 0.95, -25, 'GOLD')}
                ${renderBar(38, 50, 1.05, 18, 'GOLD')}
                ${renderBar(66, 48, 1.05, 18, 'GOLD')}
                ${renderCrossBar(44, 32, 1.12, -28, 'GOLD')}
                ${renderBar(58, 25, 1.18, 22, 'GOLD')}
            `;
            sparklePositions = [
                { x: 16, y: 40, s: 0.85, delay: '0.1s' },
                { x: 42, y: 10, s: 1.35, delay: '0.5s' },
                { x: 74, y: 14, s: 1.15, delay: '0.9s' },
                { x: 94, y: 40, s: 1.05, delay: '1.3s' },
                { x: 84, y: 72, s: 0.9, delay: '1.7s' },
                { x: 24, y: 74, s: 0.9, delay: '0.3s' },
                { x: 55, y: 55, s: 1.2, delay: '1.1s' }
            ];
            auraRadius = 65;
            auraOpacity = 0.85;
            animSpeed = '1.5s';
        } else {
            // Tier 4 (>= 10,000,000, e.g. 10M, 50M): Imperial Treasury 10 Gold Bars Stack
            barsContent = `
                ${renderCrossBar(20, 74, 0.9, -25, 'GOLD')}
                ${renderCrossBar(44, 74, 0.9, -25, 'GOLD')}
                ${renderCrossBar(66, 74, 0.9, -25, 'GOLD')}
                ${renderCrossBar(88, 74, 0.9, -25, 'GOLD')}
                ${renderBar(30, 56, 1.0, 18, 'GOLD')}
                ${renderBar(54, 56, 1.0, 18, 'GOLD')}
                ${renderBar(76, 56, 1.0, 18, 'GOLD')}
                ${renderCrossBar(38, 38, 1.08, -25, 'GOLD')}
                ${renderCrossBar(68, 38, 1.08, -25, 'GOLD')}
                ${renderBar(52, 20, 1.25, 20, 'GOLD')}
            `;
            sparklePositions = [
                { x: 10, y: 44, s: 0.95, delay: '0s' },
                { x: 28, y: 16, s: 1.25, delay: '0.3s' },
                { x: 52, y: 4,  s: 1.6, delay: '0.7s' },
                { x: 76, y: 12, s: 1.2, delay: '1.0s' },
                { x: 98, y: 36, s: 1.3, delay: '1.4s' },
                { x: 88, y: 72, s: 0.95, delay: '0.5s' },
                { x: 14, y: 75, s: 0.9, delay: '1.2s' },
                { x: 48, y: 44, s: 1.35, delay: '1.8s' },
                { x: 68, y: 56, s: 1.05, delay: '0.2s' }
            ];
            auraRadius = 75;
            auraOpacity = 0.95;
            animSpeed = '1.3s';
        }

        const sparklesSvg = sparklePositions.map((sp) => `
            <g class="gold-sparkle-star" style="transform-origin: ${sp.x}px ${sp.y}px; animation-duration: ${animSpeed}; animation-delay: ${sp.delay};">
                <use href="#${uid}_sparkle" transform="translate(${sp.x}, ${sp.y}) scale(${sp.s})" />
            </g>
        `).join('');

        return `
            <div class="lgr-gold-bars-wrap" style="width:${width}px; height:${height}px;">
                <div style="position:absolute; width:${auraRadius * 2}px; height:${auraRadius * 2}px; border-radius:50%; background:radial-gradient(circle, rgba(251,191,36,${auraOpacity}) 0%, rgba(245,158,11,${auraOpacity * 0.45}) 40%, rgba(217,119,6,0) 75%); filter:blur(10px); animation:goldAuraPulsate 3s ease-in-out infinite; pointer-events:none;"></div>
                <svg viewBox="0 0 110 96" width="${width}" height="${height}" style="overflow:visible; filter:drop-shadow(0 6px 14px rgba(0,0,0,0.4));">
                    ${defs}
                    <ellipse cx="55" cy="52" rx="${auraRadius * 0.7}" ry="${auraRadius * 0.45}" fill="url(#${uid}_aura)" opacity="${auraOpacity}" />
                    ${barsContent}
                    ${sparklesSvg}
                </svg>
            </div>
        `;
    }

    const buildGoldChestVisual = buildGoldBarsVisual;

    function getCharacterPreviewAvatar() {
        if (typeof window.getActivePlayerAvatarUrl === 'function') {
            return window.getActivePlayerAvatarUrl();
        }
        if (typeof DEFAULT_USER !== 'undefined') {
            const u = DEFAULT_USER;
            const pic = u.avatar_url || u.pictureUrl || u.picture;
            if (pic && typeof pic === 'string' && pic.trim() && !pic.endsWith('/')) {
                return pic.trim();
            }
        }
        const bar = document.getElementById('bar-avatar');
        if (bar && bar.src && !bar.src.endsWith('/') && !bar.src.includes('undefined')) {
            return bar.src;
        }
        return 'avatars/avatar_01.svg';
    }

    function buildFrameRingVisual(charObj) {
        const auraColor = AURA_COLORS[charObj.aura_type || 'gold'] || charObj.color_hex || '#ffd700';
        const previewUrl = getCharacterPreviewAvatar();
        const hasRing = Boolean(charObj.avatar_url);
        const charId = Number(charObj.id || 0);
        const grade = String(charObj.grade || 'A').toUpperCase();

        return `
            <div class="lgr-interactive-frame" style="--aura-hex: ${auraColor};" onclick="window.triggerFrameCardAuraEffect(this, '${charId}', '${esc(charObj.aura_type || 'gold')}', '${esc(charObj.name)}', '${esc(grade)}')" title="คลิกเพื่อดูเอฟเฟกต์ 3D นูนลอย & แสงเออร่า">
                <div class="lgr-aura-shockwave"></div>
                <div class="lgr-frame-avatar-circle" style="background-image: url('${esc(previewUrl)}');"></div>
                ${hasRing ? `<img src="${esc(charObj.avatar_url)}" alt="" class="lgr-frame-ring-img">` : ''}
            </div>
        `;
    }

    function buildDice3DVisual(diceObj) {
        const bodyHex = diceObj.color_hex || '#1d4ed8';
        const pipHex = diceObj.pip_color_hex || '#ffffff';
        const auraHex = AURA_COLORS[diceObj.aura_type || 'cyan'] || '#38bdf8';
        const diceId = Number(diceObj.id || 0);
        const ctrl = Number(diceObj.dice_control_rate || 50);

        let innerDice = '';
        if (diceObj.image_url) {
            innerDice = `<img src="${esc(diceObj.image_url)}" alt="${esc(diceObj.name)}" style="width:70px; height:70px; object-fit:contain; filter:drop-shadow(0 6px 14px ${auraHex});">`;
        } else {
            innerDice = `
                <div style="width:56px; height:56px; border-radius:14px; background:linear-gradient(135deg, ${bodyHex}, #0f172a); border:2.5px solid ${pipHex}; box-shadow:0 8px 18px rgba(0,0,0,0.4), 0 0 16px ${auraHex}; display:grid; grid-template-columns:repeat(3,1fr); grid-template-rows:repeat(3,1fr); padding:7px; transform:rotate(-10deg);">
                    <span style="width:8px;height:8px;border-radius:50%;background:${pipHex};box-shadow:0 0 5px ${pipHex};"></span><span></span><span style="width:8px;height:8px;border-radius:50%;background:${pipHex};justify-self:end;"></span>
                    <span></span><span style="width:10px;height:10px;border-radius:50%;background:${pipHex};place-self:center;box-shadow:0 0 7px ${pipHex};"></span><span></span>
                    <span style="width:8px;height:8px;border-radius:50%;background:${pipHex};align-self:end;"></span><span></span><span style="width:8px;height:8px;border-radius:50%;background:${pipHex};place-self:end;"></span>
                </div>
            `;
        }

        return `
            <div class="lgr-interactive-dice" style="--dice-aura: ${auraHex};" onclick="window.triggerDiceRollEffect(this, '${diceId}', '${esc(diceObj.aura_type || 'cyan')}', '${esc(diceObj.name)}', ${ctrl})" title="คลิกเพื่อทอยลูกเต๋า 3D & แสดงแสงเออร่า">
                <div class="lgr-dice-aura-glow"></div>
                <div class="lgr-dice-cube-wrap">
                    ${innerDice}
                </div>
            </div>
        `;
    }

    function buildCustomItemCardHtml(it) {
        const theme = ['pink', 'purple', 'blue', 'gold', 'green', 'crimson'].includes(it.card_theme) ? it.card_theme : 'blue';
        const limit = parseInt(it.purchase_limit || 0, 10);
        const bought = parseInt(it.user_buy_count || 0, 10);
        const soldOut = limit > 0 && bought >= limit;
        const limitLabel = limit > 0 ? `จำกัดการซื้อ (${bought}/${limit})` : (it.subtitle || 'ไม่จำกัดจำนวนซื้อ');

        const curr = String(it.currency || 'DIAMOND').toUpperCase();
        const priceNum = Number(it.price || 0);
        const priceLabel = curr === 'THB'
            ? `฿ ${priceNum.toFixed(2)}`
            : (curr === 'GOLD' ? `🪙 ${fmtNum(priceNum)}` : `💎 ${fmtNum(priceNum)}`);

        let visualHtml = '';
        if (Number(it.ref_character_id) > 0) {
            visualHtml = buildFrameRingVisual({
                avatar_url: it.char_avatar_url,
                aura_type: it.char_aura_type || 'gold',
                color_hex: it.char_color_hex || '#ffd700'
            });
        } else if (Number(it.ref_dice_id) > 0) {
            visualHtml = buildDice3DVisual({
                name: it.dice_name || it.title,
                image_url: it.dice_image_url,
                color_hex: it.dice_color_hex || '#2563eb',
                pip_color_hex: it.dice_pip_color_hex || '#ffffff',
                aura_type: it.dice_aura_type || 'cyan'
            });
        } else if (it.item_kind === 'GOLD' || (Number(it.reward_gold) > 0 && Number(it.reward_diamond) === 0)) {
            visualHtml = buildGoldBarsVisual(Number(it.reward_gold || 1000000));
        } else if (it.image_url) {
            visualHtml = `<img src="${esc(it.image_url)}" alt="${esc(it.title)}" style="max-width:110px; max-height:96px; object-fit:contain; filter:drop-shadow(0 6px 12px rgba(0,0,0,0.25));">`;
        } else if (Number(it.reward_diamond) > 0 && Number(it.reward_gold) === 0) {
            visualHtml = buildDiamondSvgVisual(Number(it.reward_diamond));
        } else {
            visualHtml = buildGoldBarsVisual(Number(it.reward_gold || 1000000));
        }

        const pills = [];
        if (Number(it.reward_diamond) > 0) pills.push(`<span class="lgr-reward-pill">💎 +${fmtNum(it.reward_diamond)}</span>`);
        if (Number(it.reward_gold) > 0) pills.push(`<span class="lgr-reward-pill">🪙 +${fmtNum(it.reward_gold)}</span>`);
        if (it.char_name) pills.push(`<span class="lgr-reward-pill">👑 ${esc(it.char_name)}</span>`);
        if (it.dice_name) pills.push(`<span class="lgr-reward-pill">🎲 ${esc(it.dice_name)}</span>`);

        return `
            <div class="lgr-tall-card theme-${theme}">
                ${it.badge_text ? `<span class="lgr-card-ribbon">${esc(it.badge_text)}</span>` : ''}
                <div class="lgr-card-top">
                    <div class="lgr-card-title" title="${esc(it.title)}">${esc(it.title)}</div>
                    <div class="lgr-card-limit">${esc(limitLabel)}</div>
                </div>
                <div class="lgr-card-visual">
                    ${visualHtml}
                    ${it.subtitle && limit > 0 ? `<div style="font-size:11px; color:#334155; font-weight:700; text-align:center;">${esc(it.subtitle)}</div>` : ''}
                    ${pills.length ? `<div class="lgr-reward-pills">${pills.join('')}</div>` : ''}
                </div>
                <div class="lgr-card-action-bar">
                    <div class="lgr-card-price-pill">
                        <span class="lgr-price-sub">ราคา</span>
                        <span class="lgr-price-amount">${priceLabel}</span>
                    </div>
                    <button type="button" class="lgr-btn-buy-prominent" ${soldOut ? 'disabled' : ''} onclick="window.requestCustomItemPurchase(${Number(it.id)})">
                        ${soldOut ? 'ซื้อครบแล้ว' : '🛒 ซื้อเลย'}
                    </button>
                </div>
            </div>
        `;
    }

    function renderSidebarMenus() {
        const box = document.getElementById('lgr-shop-sidebar-list');
        if (!box) return;
        box.innerHTML = SHOP_STATE.menus.map(m => {
            const isActive = m.menu_slug === SHOP_STATE.activeMenuSlug;
            return `
                <button type="button" class="lgr-menu-btn ${isActive ? 'active' : ''}" onclick="window.selectShopMenu('${esc(m.menu_slug)}', 0)">
                    <span class="lgr-menu-btn-left">
                        ${isActive ? '<span class="lgr-menu-check">✔</span>' : `<span>${esc(m.icon || '🏪')}</span>`}
                        <span class="lgr-menu-title">${esc(m.title)}</span>
                    </span>
                    ${m.badge_text ? `<span class="lgr-menu-badge">${esc(m.badge_text)}</span>` : ''}
                </button>
            `;
        }).join('');
    }

    function getActiveMenuObj() {
        return SHOP_STATE.menus.find(m => m.menu_slug === SHOP_STATE.activeMenuSlug) || SHOP_STATE.menus[0];
    }

    function renderSubtabs(menuObj) {
        const bar = document.getElementById('lgr-shop-subtabs-bar');
        if (!bar || !menuObj) return;
        const subs = (Array.isArray(menuObj.subtabs) && menuObj.subtabs.length > 0)
            ? menuObj.subtabs
            : [menuObj.title];
        if (SHOP_STATE.activeSubtabIndex >= subs.length) SHOP_STATE.activeSubtabIndex = 0;

        bar.innerHTML = subs.map((sName, idx) => `
            <button type="button" class="lgr-subtab-btn ${idx === SHOP_STATE.activeSubtabIndex ? 'active' : ''}" onclick="window.selectShopSubtab(${idx})">
                ${esc(sName)}
            </button>
        `).join('');
    }

    function updateScrollArrowsVisibility() {
        const track = document.getElementById('lgr-shop-cards-track');
        const btnL = document.getElementById('lgr-scroll-left');
        const btnR = document.getElementById('lgr-scroll-right');
        if (!track || !btnL || !btnR) return;
        const hasOverflow = track.scrollWidth > track.clientWidth + 20;
        btnL.style.display = hasOverflow ? 'flex' : 'none';
        btnR.style.display = hasOverflow ? 'flex' : 'none';
    }

    function renderStageContent() {
        const menuObj = getActiveMenuObj();
        const stageBody = document.getElementById('lgr-shop-stage-body');
        if (!menuObj || !stageBody) return;

        renderSubtabs(menuObj);
        const type = String(menuObj.menu_type || 'CUSTOM').toUpperCase();
        const subtabs = (Array.isArray(menuObj.subtabs) && menuObj.subtabs.length) ? menuObj.subtabs : [menuObj.title];
        const activeSubName = subtabs[SHOP_STATE.activeSubtabIndex] || '';

        // Restore standard track container first
        stageBody.innerHTML = `
            <button type="button" class="lgr-scroll-arrow left" id="lgr-scroll-left" onclick="window.scrollShopCards(-1)" style="display:none;">❮</button>
            <div class="lgr-cards-track" id="lgr-shop-cards-track"></div>
            <button type="button" class="lgr-scroll-arrow right" id="lgr-scroll-right" onclick="window.scrollShopCards(1)" style="display:none;">❯</button>
        `;
        const track = document.getElementById('lgr-shop-cards-track');

        // 1) PICK UP FRAME HERO VIEW (Matches Video 00:06-00:08)
        if (type === 'PICKUP_FRAME') {
            const ev = SHOP_STATE.catalog?.gacha_event || {};
            const tc = ev.target_character || { name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+', aura_type: 'gold', win_rate_bonus: 85, roll_rate: 90 };
            const cost1 = parseInt(ev.cost_diamond || 100, 10);
            const mats = SHOP_STATE.inventory?.materials || {};

            const reqBlack = ev.req_shadow_black || 15;
            const reqRed = ev.req_shadow_red || 15;
            const reqOrange = ev.req_shadow_orange || 15;
            const reqBlue = ev.req_shadow_blue || 10;
            const reqGold = ev.req_shadow_gold || 4;

            const curBlack = mats.SHADOW_BLACK_A || 0;
            const curRed = mats.SHADOW_RED_A || 0;
            const curOrange = mats.SHADOW_ORANGE_A || 0;
            const curBlue = mats.SHADOW_BLUE_APLUS || mats.SHADOW_BLUE_A || 0;
            const curGold = mats.SHADOW_GOLD_S || mats.SHADOW_GOLD_APLUS || 0;

            const canExchange = (curBlack >= reqBlack && curRed >= reqRed && curOrange >= reqOrange && curBlue >= reqBlue && curGold >= reqGold);

            // Subtab 1: แลกเงาการ์ด
            if (SHOP_STATE.activeSubtabIndex === 1 || activeSubName.includes('แลกเงา')) {
                stageBody.innerHTML = `
                    <div class="lgr-pickup-hero" style="background:radial-gradient(circle at 30% 45%, #1e1b4b 0%, #0f172a 70%, #020617 100%); padding:10px 14px;">
                        <div style="flex:1; min-width:200px;">
                            <div style="display:inline-block; background:linear-gradient(135deg,#fde047,#f59e0b); color:#0f172a; font-size:10px; font-weight:900; padding:1.5px 8px; border-radius:999px; margin-bottom:2px;">
                                👑 ระบบแลกเงาการ์ด • กรอบรูป ${esc(tc.grade || 'SS+')}
                            </div>
                            <h3 style="font-size:14.5px; font-weight:900; color:#fde047; margin:0 0 2px 0; line-height:1.2;">แลกรับ ${esc(tc.name)} ถาวร</h3>
                            <p style="font-size:10.5px; color:#cbd5e1; margin:0 0 5px 0; line-height:1.25;">สะสมการ์ดเงาให้ครบทั้ง 5 สี เพื่อกดแลกรับกรอบรูปสุดแรร์เข้าคลังทันที!</p>
                            <div style="display:flex; gap:4px; flex-wrap:wrap; margin-bottom:6px;">
                                <div style="background:rgba(255,255,255,0.08); border:1px solid #64748b; border-radius:6px; padding:2px 6px; font-size:10px;">⬛ เงาดำ: <b style="color:${curBlack >= reqBlack ? '#4ade80' : '#fff'};">${fmtNum(curBlack)}</b>/${reqBlack}</div>
                                <div style="background:rgba(239,68,68,0.14); border:1px solid #ef4444; border-radius:6px; padding:2px 6px; font-size:10px;">🟥 เงาแดง: <b style="color:${curRed >= reqRed ? '#4ade80' : '#fff'};">${fmtNum(curRed)}</b>/${reqRed}</div>
                                <div style="background:rgba(249,115,22,0.14); border:1px solid #f97316; border-radius:6px; padding:2px 6px; font-size:10px;">🟧 เงาส้ม: <b style="color:${curOrange >= reqOrange ? '#4ade80' : '#fff'};">${fmtNum(curOrange)}</b>/${reqOrange}</div>
                                <div style="background:rgba(56,189,248,0.14); border:1px solid #38bdf8; border-radius:6px; padding:2px 6px; font-size:10px;">🟦 เงาฟ้า: <b style="color:${curBlue >= reqBlue ? '#4ade80' : '#fff'};">${fmtNum(curBlue)}</b>/${reqBlue}</div>
                                <div style="background:rgba(250,204,21,0.16); border:1px solid #facc15; border-radius:6px; padding:2px 6px; font-size:10px;">🟨 เงาทอง: <b style="color:${curGold >= reqGold ? '#4ade80' : '#fff'};">${fmtNum(curGold)}</b>/${reqGold}</div>
                            </div>
                            <button type="button" class="lgr-yellow-pill-btn" onclick="closeModal('modal-shop'); if (typeof openFrameEventModal === 'function') openFrameEventModal();" style="padding:4px 12px; font-size:11px;">
                                👑 เปิดหน้าแลกการ์ดเงาเต็มจอ
                            </button>
                        </div>
                        <div style="display:flex; flex-direction:column; align-items:center; gap:5px; min-width:170px;">
                            ${buildFrameRingVisual(tc)}
                            <div style="font-size:12px; font-weight:800; color:#fde047; text-align:center;">${esc(tc.name)}</div>
                            <button type="button" onclick="${canExchange ? `if(typeof exchangeSPlusAction==='function'){ exchangeSPlusAction(${tc.id || 1}, '${tc.grade || 'SS+'}'); setTimeout(()=>window.refreshShopShowcase(),600); }` : `closeModal('modal-shop'); if(typeof openFrameEventModal==='function') openFrameEventModal();`}"
                                style="width:100%; background:${canExchange ? 'linear-gradient(180deg,#4ade80,#16a34a)' : 'linear-gradient(180deg,#94a3b8,#64748b)'}; color:#fff; border:1.5px solid #fff; border-radius:8px; padding:6px 10px; font-size:12px; font-weight:900; cursor:pointer; box-shadow:0 3px 8px rgba(0,0,0,0.35);">
                                ${canExchange ? '🎉 กดแลกรับกรอบรูปทันที!' : '🔒 สะสมเงาให้ครบเพื่อแลก'}
                            </button>
                        </div>
                    </div>
                `;
                return;
            }

            // Subtab 0: สุ่มแพ็คการ์ดกรอบ
            stageBody.innerHTML = `
                <div class="lgr-pickup-hero" style="padding:10px 14px;">
                    <div style="flex:1; min-width:200px;">
                        <div style="display:inline-block; background:linear-gradient(135deg,#fde047,#f59e0b); color:#0f172a; font-size:10px; font-weight:900; padding:1.5px 8px; border-radius:999px; margin-bottom:2px;">
                            ✨ PICK UP EVENT • กรอบรูประดับ ${esc(tc.grade || 'SS+')}
                        </div>
                        <h3 style="font-size:14.5px; font-weight:900; color:#fde047; margin:0 0 2px 0; line-height:1.2;">${esc(ev.event_name || tc.name)}</h3>
                        <p style="font-size:10.5px; color:#cbd5e1; margin:0 0 5px 0; line-height:1.25;">สะสมการ์ดเงาครบ 5 สี หรือลุ้นแจ็คพอตออกกรอบ ${esc(tc.name)} ทันที!</p>
                        <div style="display:flex; gap:4px; flex-wrap:wrap; margin-bottom:6px;">
                            <div style="background:rgba(255,255,255,0.08); border:1px solid #64748b; border-radius:6px; padding:2px 6px; font-size:10px;">⬛ เงาดำ: <b style="color:${curBlack >= reqBlack ? '#4ade80' : '#fff'};">${fmtNum(curBlack)}</b>/${reqBlack}</div>
                            <div style="background:rgba(239,68,68,0.14); border:1px solid #ef4444; border-radius:6px; padding:2px 6px; font-size:10px;">🟥 เงาแดง: <b style="color:${curRed >= reqRed ? '#4ade80' : '#fff'};">${fmtNum(curRed)}</b>/${reqRed}</div>
                            <div style="background:rgba(249,115,22,0.14); border:1px solid #f97316; border-radius:6px; padding:2px 6px; font-size:10px;">🟧 เงาส้ม: <b style="color:${curOrange >= reqOrange ? '#4ade80' : '#fff'};">${fmtNum(curOrange)}</b>/${reqOrange}</div>
                            <div style="background:rgba(56,189,248,0.14); border:1px solid #38bdf8; border-radius:6px; padding:2px 6px; font-size:10px;">🟦 เงาฟ้า: <b style="color:${curBlue >= reqBlue ? '#4ade80' : '#fff'};">${fmtNum(curBlue)}</b>/${reqBlue}</div>
                            <div style="background:rgba(250,204,21,0.16); border:1px solid #facc15; border-radius:6px; padding:2px 6px; font-size:10px;">🟨 เงาทอง: <b style="color:${curGold >= reqGold ? '#4ade80' : '#fff'};">${fmtNum(curGold)}</b>/${reqGold}</div>
                        </div>
                        <button type="button" class="lgr-yellow-pill-btn" onclick="window.selectShopSubtab(1)" style="padding:4px 12px; font-size:11px;">
                            👑 สลับไปหน้าแลกการ์ดเงา & ตรวจสอบเงา
                        </button>
                    </div>
                    <div style="display:flex; flex-direction:column; align-items:center; gap:5px; min-width:170px;">
                        ${buildFrameRingVisual(tc)}
                        <div style="font-size:12px; font-weight:800; color:#fde047; text-align:center;">${esc(tc.name)}</div>
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:6px; width:100%;">
                            <button type="button" onclick="if (typeof doGacha === 'function') doGacha(1, false, ${cost1});" style="background:linear-gradient(180deg,#38bdf8,#0284c7); color:#fff; border:1.5px solid #bae6fd; border-radius:8px; padding:5px 4px; font-size:11px; font-weight:900; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:1px; box-shadow:0 3px 8px rgba(2,132,199,0.35);">
                                <span>สุ่ม 1 แพ็ค</span><span style="font-size:10px; color:#fde047;">💎 ${fmtNum(cost1)}</span>
                            </button>
                            <button type="button" onclick="if (typeof doGacha === 'function') doGacha(10, false, ${cost1});" style="background:linear-gradient(180deg,#ffe84d,#f59e0b); color:#0f172a; border:1.5px solid #fff; border-radius:8px; padding:5px 4px; font-size:11px; font-weight:900; cursor:pointer; display:flex; flex-direction:column; align-items:center; gap:1px; box-shadow:0 3px 8px rgba(245,158,11,0.45);">
                                <span>สุ่ม 10 แพ็ค</span><span style="font-size:10px; font-weight:900;">💎 ${fmtNum(cost1 * 10)}</span>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            return;
        }

        // 2) PICK UP DICE HERO VIEW
        if (type === 'PICKUP_DICE') {
            const dev = SHOP_STATE.catalog?.dice_gacha_event || {};
            const td = dev.target_dice || (SHOP_STATE.catalog?.dice || [])[0] || { name: 'ลูกเต๋าเทพอมตะ 3D', grade: 'SS+', aura_type: 'cyan' };
            const dCost = parseInt(dev.cost_diamond || 100, 10);
            stageBody.innerHTML = `
                <div class="lgr-pickup-hero" style="background:radial-gradient(circle at 30% 45%, #0c4a6e 0%, #0f172a 60%, #020617 100%); border-color:#38bdf8; padding:10px 14px;">
                    <div style="flex:1; min-width:200px;">
                        <div style="display:inline-block; background:linear-gradient(135deg,#38bdf8,#0284c7); color:#fff; font-size:10px; font-weight:900; padding:1.5px 8px; border-radius:999px; margin-bottom:2px;">
                            🎯 PICK UP 3D DICE • เกรด ${esc(td.grade || 'SS+')}
                        </div>
                        <h3 style="font-size:14.5px; font-weight:900; color:#7dd3fc; margin:0 0 2px 0; line-height:1.2;">${esc(dev.event_name || td.name)}</h3>
                        <p style="font-size:10.5px; color:#cbd5e1; margin:0 0 5px 0; line-height:1.25;">ลุ้นรับลูกเต๋า 3D แรร์เรตอัป พร้อมสะสมการ์ดเงาแลกรับลูกเต๋าทันที!</p>
                        <button type="button" class="lgr-yellow-pill-btn" onclick="closeModal('modal-shop'); if (typeof openDiceEventModal === 'function') openDiceEventModal();" style="padding:4px 12px; font-size:11px;">
                            🎲 เปิดหน้าสุ่มลูกเต๋า PICK UP เต็มจอ
                        </button>
                    </div>
                    <div style="display:flex; flex-direction:column; align-items:center; gap:5px; min-width:170px;">
                        ${buildDice3DVisual(td)}
                        <div style="font-size:12px; font-weight:900; color:#fff; text-align:center;">${esc(td.name)}</div>
                        <button type="button" onclick="closeModal('modal-shop'); if (typeof openDiceEventModal === 'function') openDiceEventModal();" style="width:100%; background:linear-gradient(180deg,#ffe84d,#f59e0b); color:#0f172a; border:1.5px solid #fff; border-radius:8px; padding:6px 10px; font-size:12px; font-weight:900; cursor:pointer; box-shadow:0 3px 8px rgba(245,158,11,0.45);">
                            🎲 สุ่มลูกเต๋า (💎 ${fmtNum(dCost)})
                        </button>
                    </div>
                </div>
            `;
            return;
        }

        // 3) CARD UPGRADE SUBTAB INSIDE FRAMES
        if (type === 'FRAME' && (SHOP_STATE.activeSubtabIndex === 2 || activeSubName.includes('อัปเกรด'))) {
            const invItems = (SHOP_STATE.inventory?.inventory || []).filter(x => x.char_name || x.dice_name);
            stageBody.innerHTML = `
                <div style="flex:1; overflow-y:auto; padding:6px;">
                    <div style="background:#0f172a; color:#fff; border-radius:12px; padding:12px 16px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                        <div>
                            <div style="font-size:15px; font-weight:900; color:#fde047;">⚡ อัปเกรดการ์ดกรอบ & ปลุกพลังเลเวล 30 (Awakening)</div>
                            <div style="font-size:11.5px; color:#94a3b8;">Lv.1-10: 100💎 | Lv.11-20: 150💎 | Lv.21-29: 200💎 | Lv.30: การ์ดพิเศษ + 500💎</div>
                        </div>
                    </div>
                    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(260px, 1fr)); gap:10px;">
                        ${invItems.length ? invItems.map(it => {
                const isMax = Number(it.level || 1) >= 30;
                return `
                                <div style="background:#1e293b; color:#fff; border:1.5px solid ${it.is_awakened ? '#ffd700' : '#334155'}; border-radius:12px; padding:12px; display:flex; justify-content:space-between; align-items:center; gap:10px;">
                                    <div>
                                        <div style="font-size:13.5px; font-weight:800;">${esc(it.char_name || it.dice_name)} <span style="color:#38bdf8;">[Lv.${it.level || 1}/30]</span></div>
                                        <div style="font-size:11px; color:#94a3b8;">${esc(it.skill_name || 'พลังพิเศษประจำตัว')}</div>
                                    </div>
                                    ${!isMax
                        ? `<button type="button" class="lgr-yellow-pill-btn" onclick="if(typeof upgradeItem==='function'){ upgradeItem(${Number(it.id)}, false, '${esc(it.char_name || it.dice_name)}', ${Number(it.level || 1)}); }">อัปเกรด</button>`
                        : `<span style="color:#fde047; font-weight:900; font-size:12px;">MAX ✨</span>`}
                                </div>
                            `;
            }).join('') : '<div style="padding:24px; text-align:center; color:#475569; font-weight:700;">ยังไม่มีการ์ดในคลังของคุณ</div>'}
                    </div>
                </div>
            `;
            return;
        }

        // Gather custom items assigned to this menuSlug (filtered by subtab if matching)
        const menuCustomItems = SHOP_STATE.customItems.filter(it => {
            if (it.menu_slug !== menuObj.menu_slug) return false;
            if (!activeSubName || SHOP_STATE.activeSubtabIndex === 0) return true;
            return !it.subtab_name || it.subtab_name === activeSubName;
        });

        const cardsHtml = [];

        // 4) DIAMOND SHOP (Matches Video Frame 00:11: Free Ad Card + Diamond Packages!)
        if (type === 'DIAMOND') {
            // Free Daily Ad Card (Card #1 like Video 00:11!)
            cardsHtml.push(`
                <div class="lgr-tall-card theme-dark-ad">
                    <span class="lgr-card-ribbon">FREE</span>
                    <div class="lgr-card-top">
                        <div class="lgr-card-title">รับเพชรฟรีรายวัน</div>
                        <div class="lgr-card-limit">จำกัดรายวัน (30 💎 ฟรี)</div>
                    </div>
                    <div class="lgr-card-visual">
                        ${buildDiamondSvgVisual(30)}
                        <div class="lgr-reward-pills">
                            <span class="lgr-reward-pill" style="background:#dc2626;">▶ โบนัสเพชรฟรี +30 💎</span>
                        </div>
                    </div>
                    <div class="lgr-card-action-bar">
                        <div class="lgr-card-price-pill">
                            <span class="lgr-price-sub">ราคา</span>
                            <span class="lgr-price-amount" style="color:#4ade80;">ฟรี (0 ฿)</span>
                        </div>
                        <button type="button" class="lgr-btn-buy-prominent btn-free" onclick="window.claimShopFreeDiamondAction()">
                            ▶ รับฟรีทันที
                        </button>
                    </div>
                </div>
            `);

            if (!SHOP_STATE.activeSubtabIndex || Number(SHOP_STATE.activeSubtabIndex) === 0) {
                const rawPkgs = (Array.isArray(SHOP_STATE.catalog?.topup_packages) && SHOP_STATE.catalog.topup_packages.length > 0)
                    ? SHOP_STATE.catalog.topup_packages
                    : DEFAULT_TOPUP_PACKAGES;
                const pkgs = rawPkgs.filter(p => Number(p.reward_diamond) > 0);
                pkgs.forEach(p => {
                    const dia = Number(p.reward_diamond || 0);
                    const gold = Number(p.reward_gold || 0);
                    const theme = dia >= 10000 ? 'purple' : 'blue';
                    cardsHtml.push(`
                        <div class="lgr-tall-card theme-${theme}">
                            ${gold > 0 ? '<span class="lgr-card-ribbon">+แถมทอง</span>' : ''}
                            <div class="lgr-card-top">
                                <div class="lgr-card-title">${esc(p.name || ('เพชร ' + fmtNum(dia)))}</div>
                                <div class="lgr-card-limit">ได้รับ 💎 ${fmtNum(dia)} เพชร</div>
                            </div>
                            <div class="lgr-card-visual">
                                ${buildDiamondSvgVisual(dia)}
                                <div class="lgr-reward-pills">
                                    <span class="lgr-reward-pill">💎 +${fmtNum(dia)}</span>
                                    ${gold > 0 ? `<span class="lgr-reward-pill" style="color:#fde047;">🪙 +${fmtNum(gold)}</span>` : ''}
                                </div>
                            </div>
                            <div class="lgr-card-action-bar">
                                <div class="lgr-card-price-pill">
                                    <span class="lgr-price-sub">ราคา</span>
                                    <span class="lgr-price-amount">฿ ${Number(p.price_thb || 0).toFixed(2)}</span>
                                </div>
                                <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestTopupPackagePurchase(${Number(p.id)})">
                                    🛒 ซื้อเลย
                                </button>
                            </div>
                        </div>
                    `);
                });
                menuCustomItems.forEach(it => cardsHtml.push(buildCustomItemCardHtml(it)));
            }
        }
        // 5) GOLD SHOP
        else if (type === 'GOLD') {
            if (!SHOP_STATE.activeSubtabIndex || Number(SHOP_STATE.activeSubtabIndex) === 0) {
                menuCustomItems.forEach(it => cardsHtml.push(buildCustomItemCardHtml(it)));
            }
            const rawGoldPkgs = (Array.isArray(SHOP_STATE.catalog?.topup_packages) && SHOP_STATE.catalog.topup_packages.length > 0)
                ? SHOP_STATE.catalog.topup_packages
                : DEFAULT_TOPUP_PACKAGES;
            const goldPkgs = rawGoldPkgs.filter(p =>
                Number(SHOP_STATE.activeSubtabIndex) === 1 ? Number(p.reward_gold) > 0 : (String(p.type).toUpperCase() === 'GOLD' || Number(p.reward_gold) > 0)
            );
            goldPkgs.forEach(p => {
                const gold = Number(p.reward_gold || 0);
                const dia = Number(p.reward_diamond || 0);
                cardsHtml.push(`
                    <div class="lgr-tall-card theme-gold">
                        <span class="lgr-card-ribbon">คุ้มค่า</span>
                        <div class="lgr-card-top">
                            <div class="lgr-card-title">${esc(p.name)}</div>
                            <div class="lgr-card-limit">แพ็กเกจทองมหาเศรษฐี</div>
                        </div>
                        <div class="lgr-card-visual">
                            ${buildGoldBarsVisual(gold)}
                            <div class="lgr-reward-pills">
                                <span class="lgr-reward-pill" style="color:#fde047;">🪙 +${fmtNum(gold)}</span>
                                ${dia > 0 ? `<span class="lgr-reward-pill">💎 +${fmtNum(dia)}</span>` : ''}
                            </div>
                        </div>
                        <div class="lgr-card-action-bar">
                            <div class="lgr-card-price-pill">
                                <span class="lgr-price-sub">ราคา</span>
                                <span class="lgr-price-amount">฿ ${Number(p.price_thb || 0).toFixed(2)}</span>
                            </div>
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestTopupPackagePurchase(${Number(p.id)})">
                                🛒 ซื้อเลย
                            </button>
                        </div>
                    </div>
                `);
            });
        }
        // 6) PROFILE FRAME CARDS SHOP (การ์ดกรอบ)
        else if (type === 'FRAME') {
            let chars = [...(SHOP_STATE.catalog?.characters || [])];
            if (SHOP_STATE.activeSubtabIndex === 1) {
                chars = chars.filter(c => ['SS+', 'S+'].includes(String(c.grade).toUpperCase()));
            }
            // Sort highest grade first
            const gOrder = { 'SS+': 1, 'S+': 2, 'S': 3, 'A+': 4, 'A': 5, 'B': 6 };
            chars.sort((a, b) => (gOrder[a.grade] || 9) - (gOrder[b.grade] || 9));

            chars.forEach(c => {
                const owned = isOwnedItem('CHARACTER', c.id);
                const invId = getOwnedInventoryId('CHARACTER', c.id);
                const pDia = Number(c.price_diamond || 0);
                const pGold = Number(c.price_gold || 0);
                const grade = String(c.grade || 'A').toUpperCase();
                const theme = grade === 'SS+' ? 'gold' : (grade === 'S+' ? 'purple' : (grade === 'S' ? 'blue' : 'green'));

                let actionBtnHtml = '';
                if (owned) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar single">
                            <button type="button" class="lgr-btn-owned" onclick="window.equipOwnedFromShop('CHARACTER', ${invId})">✔ เป็นเจ้าของแล้ว (สวมใส่)</button>
                        </div>`;
                } else if (pDia > 0 && pGold > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar dual">
                            <button type="button" class="lgr-btn-buy-prominent btn-dia" onclick="window.requestCatalogPurchase('CHARACTER', ${Number(c.id)}, 'DIAMOND')">
                                <span class="lgr-badge-mini">💎 ${fmtNum(pDia)}</span>
                                <span>ซื้อเลย</span>
                            </button>
                            <button type="button" class="lgr-btn-buy-prominent btn-gold" onclick="window.requestCatalogPurchase('CHARACTER', ${Number(c.id)}, 'GOLD')">
                                <span class="lgr-badge-mini">🪙 ${fmtNum(pGold)}</span>
                                <span>ซื้อเลย</span>
                            </button>
                        </div>
                    `;
                } else if (pDia > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar">
                            <div class="lgr-card-price-pill">
                                <span class="lgr-price-sub">ราคา</span>
                                <span class="lgr-price-amount">💎 ${fmtNum(pDia)}</span>
                            </div>
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestCatalogPurchase('CHARACTER', ${Number(c.id)}, 'DIAMOND')">
                                🛒 ซื้อเลย
                            </button>
                        </div>`;
                } else if (pGold > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar">
                            <div class="lgr-card-price-pill">
                                <span class="lgr-price-sub">ราคา</span>
                                <span class="lgr-price-amount">🪙 ${fmtNum(pGold)}</span>
                            </div>
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestCatalogPurchase('CHARACTER', ${Number(c.id)}, 'GOLD')">
                                🛒 ซื้อเลย
                            </button>
                        </div>`;
                } else {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar single">
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.selectShopMenu('pickup_frame', 0)">✨ สุ่มรับใน PICK UP</button>
                        </div>`;
                }

                cardsHtml.push(`
                    <div class="lgr-tall-card theme-${theme}">
                        <span class="lgr-card-ribbon">${esc(grade)}</span>
                        <div class="lgr-card-top">
                            <div class="lgr-card-title" title="${esc(c.name)}">${esc(c.name)}</div>
                            <span class="lgr-card-grade-strip">การ์ดกรอบ ${esc(grade)}</span>
                        </div>
                        <div class="lgr-card-visual">
                            ${buildFrameRingVisual(c)}
                            <div class="lgr-reward-pills">
                                <span class="lgr-reward-pill">🏆 ชนะ +${Number(c.win_rate_bonus || 0)}%</span>
                                <span class="lgr-reward-pill">🎲 คุมเต๋า ${Number(c.roll_rate || 0)}%</span>
                            </div>
                        </div>
                        ${actionBtnHtml}
                    </div>
                `);
            });
            menuCustomItems.forEach(it => cardsHtml.push(buildCustomItemCardHtml(it)));
        }
        // 7) 3D DICE SHOP (ลูกเต๋า — Exact Look of Video Frames 00:09-00:10!)
        else if (type === 'DICE') {
            let diceList = [...(SHOP_STATE.catalog?.dice || [])];
            if (SHOP_STATE.activeSubtabIndex === 1) {
                diceList = diceList.filter(d => !['NORMAL', 'COMMON'].includes(String(d.grade).toUpperCase()));
            }
            diceList.reverse().forEach(d => {
                const owned = isOwnedItem('DICE', d.id);
                const invId = getOwnedInventoryId('DICE', d.id);
                const pDia = Number(d.price_diamond || 0);
                const pGold = Number(d.price_gold || 0);
                const grade = String(d.grade || 'S').toUpperCase();
                const theme = (grade.includes('SS') || grade === 'LEGENDARY') ? 'gold' : (grade === 'EPIC' ? 'purple' : 'blue');

                let actionBtnHtml = '';
                if (owned) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar single">
                            <button type="button" class="lgr-btn-owned" onclick="window.equipOwnedFromShop('DICE', ${invId})">✔ เป็นเจ้าของแล้ว (สวมใส่)</button>
                        </div>`;
                } else if (pGold > 0 && pDia > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar dual">
                            <button type="button" class="lgr-btn-buy-prominent btn-dia" onclick="window.requestCatalogPurchase('DICE', ${Number(d.id)}, 'DIAMOND')">
                                <span class="lgr-badge-mini">💎 ${fmtNum(pDia)}</span>
                                <span>ซื้อเลย</span>
                            </button>
                            <button type="button" class="lgr-btn-buy-prominent btn-gold" onclick="window.requestCatalogPurchase('DICE', ${Number(d.id)}, 'GOLD')">
                                <span class="lgr-badge-mini">🪙 ${fmtNum(pGold)}</span>
                                <span>ซื้อเลย</span>
                            </button>
                        </div>
                    `;
                } else if (pGold > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar">
                            <div class="lgr-card-price-pill">
                                <span class="lgr-price-sub">ราคา</span>
                                <span class="lgr-price-amount">🪙 ${fmtNum(pGold)}</span>
                            </div>
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestCatalogPurchase('DICE', ${Number(d.id)}, 'GOLD')">
                                🛒 ซื้อเลย
                            </button>
                        </div>`;
                } else if (pDia > 0) {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar">
                            <div class="lgr-card-price-pill">
                                <span class="lgr-price-sub">ราคา</span>
                                <span class="lgr-price-amount">💎 ${fmtNum(pDia)}</span>
                            </div>
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.requestCatalogPurchase('DICE', ${Number(d.id)}, 'DIAMOND')">
                                🛒 ซื้อเลย
                            </button>
                        </div>`;
                } else {
                    actionBtnHtml = `
                        <div class="lgr-card-action-bar single">
                            <button type="button" class="lgr-btn-buy-prominent" onclick="window.selectShopMenu('pickup_dice', 0)">🎯 สุ่มรับใน PICK UP</button>
                        </div>`;
                }

                cardsHtml.push(`
                    <div class="lgr-tall-card theme-${theme}">
                        <div class="lgr-card-top">
                            <div class="lgr-card-title" title="${esc(d.name)}">${esc(d.name)}</div>
                            <span class="lgr-card-grade-strip">${esc(grade)}</span>
                        </div>
                        <div class="lgr-card-visual">
                            ${buildDice3DVisual(d)}
                            <div class="lgr-reward-pills">
                                <span class="lgr-reward-pill">🎯 แม่นยำ ${Number(d.dice_control_rate || 50)}%</span>
                            </div>
                        </div>
                        ${actionBtnHtml}
                    </div>
                `);
            });
            menuCustomItems.forEach(it => cardsHtml.push(buildCustomItemCardHtml(it)));
        }
        // 8) FEATURED OR ADMIN CUSTOM MENU
        else {
            const subFiltered = SHOP_STATE.customItems.filter(it => {
                if (it.menu_slug !== menuObj.menu_slug) return false;
                if (!activeSubName) return true;
                // Show items matching subtab, or if none match and index===0 show all in menu
                return !it.subtab_name || it.subtab_name === activeSubName;
            });
            const listToUse = subFiltered.length > 0
                ? subFiltered
                : SHOP_STATE.customItems.filter(it => it.menu_slug === menuObj.menu_slug);

            listToUse.forEach(it => cardsHtml.push(buildCustomItemCardHtml(it)));
        }

        if (cardsHtml.length === 0) {
            track.innerHTML = `
                <div style="flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#475569; padding:30px; text-align:center;">
                    <div style="font-size:42px; margin-bottom:8px;">🏪</div>
                    <div style="font-size:15px; font-weight:800;">ยังไม่มีสินค้าในหมวดย่อยนี้</div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">ผู้ดูแลระบบสามารถเพิ่มการ์ดสินค้าใหม่ได้ที่เมนู "จัดการเมนูร้านค้า & สินค้า" ในหน้า Admin</div>
                </div>
            `;
        } else {
            track.innerHTML = cardsHtml.join('');
        }

        setTimeout(updateScrollArrowsVisibility, 60);
    }

    async function refreshUserProfileBar() {
        try {
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                if (typeof DEFAULT_USER !== 'undefined') Object.assign(DEFAULT_USER, prof.data);
                if (typeof updateUserBar === 'function') updateUserBar(DEFAULT_USER);
            }
        } catch (e) { }
        syncWalletHeaderNumbers();
    }

    // Public Actions
    window.openShopShowcaseModal = async function (initialSlug = 'featured', subtabIdx = 0) {
        ensureShopModalStructure();
        if (initialSlug) {
            // Map legacy tab names smoothly
            const mapLegacy = { topup: 'diamond', gacha: 'pickup_frame', upgrade: 'frames' };
            SHOP_STATE.activeMenuSlug = mapLegacy[initialSlug] || initialSlug;
            SHOP_STATE.activeSubtabIndex = initialSlug === 'upgrade' ? 2 : (subtabIdx || 0);
        }
        if (typeof openModal === 'function') openModal('modal-shop');
        document.body.classList.add('modal-open');
        var btnL = document.getElementById('btn-toggle-side-left');
        var btnR = document.getElementById('btn-toggle-side-right');
        if (btnL) btnL.classList.add('modal-hidden');
        if (btnR) btnR.classList.add('modal-hidden');
        await window.refreshShopShowcase();
    };

    window.refreshShopShowcase = async function () {
        ensureShopModalStructure();
        syncWalletHeaderNumbers();

        try {
            const [catRes, invRes] = await Promise.all([
                apiClient.getCatalog().catch(() => null),
                apiClient.getInventory().catch(() => null)
            ]);
            if (catRes && catRes.catalog) {
                SHOP_STATE.catalog = catRes.catalog;
                if (!Array.isArray(SHOP_STATE.catalog.topup_packages) || SHOP_STATE.catalog.topup_packages.length === 0) {
                    SHOP_STATE.catalog.topup_packages = DEFAULT_TOPUP_PACKAGES;
                }
                SHOP_STATE.menus = (Array.isArray(catRes.catalog.shop_menus) && catRes.catalog.shop_menus.length > 0)
                    ? catRes.catalog.shop_menus
                    : getDefaultMenusFallback();
                SHOP_STATE.customItems = Array.isArray(catRes.catalog.shop_custom_items)
                    ? catRes.catalog.shop_custom_items
                    : [];
                if (catRes.catalog.gacha_event && typeof window.syncGachaShadowAndTierCache === 'function') {
                    window.syncGachaShadowAndTierCache(catRes.catalog.gacha_event);
                }
            } else {
                if (!SHOP_STATE.catalog) {
                    SHOP_STATE.catalog = {
                        topup_packages: DEFAULT_TOPUP_PACKAGES,
                        characters: [],
                        dice: [],
                        shop_menus: getDefaultMenusFallback(),
                        shop_custom_items: [],
                        payment_settings: {
                            promptpay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', bank: 'พร้อมเพย์กลาง (PromptPay)' },
                            shopeepay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', qr_url: '', is_active: 1 }
                        }
                    };
                }
                if (!SHOP_STATE.menus.length) SHOP_STATE.menus = getDefaultMenusFallback();
            }
            if (invRes) {
                SHOP_STATE.inventory = invRes;
            }
        } catch (err) {
            console.warn('[ShopShowcase] fallback load:', err);
            if (!SHOP_STATE.catalog) {
                SHOP_STATE.catalog = {
                    topup_packages: DEFAULT_TOPUP_PACKAGES,
                    characters: [],
                    dice: [],
                    shop_menus: getDefaultMenusFallback(),
                    shop_custom_items: [],
                    payment_settings: {
                        promptpay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', bank: 'พร้อมเพย์กลาง (PromptPay)' },
                        shopeepay: { id: '0804513789', name: 'พวงเพ็ญ อินจันทร์', qr_url: '', is_active: 1 }
                    }
                };
            }
            if (!SHOP_STATE.menus.length) SHOP_STATE.menus = getDefaultMenusFallback();
        }

        if (!SHOP_STATE.menus.some(m => m.menu_slug === SHOP_STATE.activeMenuSlug)) {
            SHOP_STATE.activeMenuSlug = SHOP_STATE.menus[0]?.menu_slug || 'featured';
        }

        syncWalletHeaderNumbers();
        renderSidebarMenus();
        renderStageContent();
    };

    window.selectShopMenu = function (slug, subtabIdx = 0) {
        SHOP_STATE.activeMenuSlug = slug;
        SHOP_STATE.activeSubtabIndex = subtabIdx || 0;
        renderSidebarMenus();
        renderStageContent();
    };

    window.selectShopSubtab = function (idx) {
        SHOP_STATE.activeSubtabIndex = idx;
        renderStageContent();
    };

    window.scrollShopCards = function (dir) {
        const track = document.getElementById('lgr-shop-cards-track');
        if (!track) return;
        track.scrollBy({ left: dir * 280, behavior: 'smooth' });
    };

    // =========================================================================
    // Payment Modal & Checkout System with Progress & Real-time Balance Update
    // =========================================================================
    const PAYMENT_STATE = {
        activeItem: null,
        selectedMethod: 'promptpay',
        isProcessing: false,
        txRef: null,
        orderNo: null,
        orderId: null,
        countdownSecs: 60,
        countdownTimer: null,
        pollingTimer: null
    };

    function clearPaymentTimers() {
        if (PAYMENT_STATE.countdownTimer) {
            clearInterval(PAYMENT_STATE.countdownTimer);
            PAYMENT_STATE.countdownTimer = null;
        }
        if (PAYMENT_STATE.pollingTimer) {
            clearInterval(PAYMENT_STATE.pollingTimer);
            PAYMENT_STATE.pollingTimer = null;
        }
    }

    function playFemaleChildVoiceCelebration(amountThb, rewardDiamond, rewardGold) {
        const amtStr = Number(amountThb || 0).toLocaleString('th-TH', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
        const diaStr = Number(rewardDiamond || 0).toLocaleString('th-TH');
        const speechText = `ระบบได้รับเงินจำนวน ${amtStr} บาท และส่งเพชรจำนวน ${diaStr} เพชรให้เรียบร้อยแล้วค่ะ! เย้!`;

        // 1. Play enthusiasm cheer sound effect
        try {
            const cheerAudio = new Audio('assets/audio/th/yeay.mp3');
            cheerAudio.volume = 0.95;
            cheerAudio.play().catch(() => {});
        } catch (e) {}

        // 2. Play Thai girl voice synthesis
        if ('speechSynthesis' in window) {
            try {
                window.speechSynthesis.cancel();
                const utter = new SpeechSynthesisUtterance(speechText);
                utter.lang = 'th-TH';
                utter.pitch = 1.35; // Energetic young girl tone
                utter.rate = 1.02;  // Cheerful cadence
                utter.volume = 1.0;

                const voices = window.speechSynthesis.getVoices() || [];
                const thVoice = voices.find(v => v.lang && (v.lang.toLowerCase().startsWith('th') || v.lang.toLowerCase().includes('th-th')));
                if (thVoice) {
                    utter.voice = thVoice;
                }
                window.speechSynthesis.speak(utter);
            } catch (err) {
                console.warn('SpeechSynthesis error:', err);
            }
        }
    }

    const PAYMENT_METHODS_THB = [
        { id: 'promptpay', name: 'พร้อมเพย์ / PromptPay QR', icon: '📱', desc: 'สแกนจ่ายได้ทุกแอปธนาคาร รวดเร็ว ไม่มีค่าธรรมเนียม', tag: 'แนะนำ' },
        { id: 'truemoney', name: 'ทรูมันนี่ วอลเล็ท (TrueMoney)', icon: '👛', desc: 'ชำระผ่านแอปพลิเคชัน TrueMoney Wallet', tag: '' },
        { id: 'banking', name: 'Mobile Banking (แอปธนาคาร)', icon: '🏦', desc: 'KBANK K PLUS, SCB EASY, Krungthai, BBL', tag: '' },
        { id: 'card', name: 'บัตรเครดิต / บัตรเดบิต', icon: '💳', desc: 'Visa, Mastercard, JCB (ปลอดภัย 100%)', tag: '' }
    ];

    function generatePromptPayPayload(target, amount = null) {
        target = String(target || '').replace(/[^0-9]/g, '');
        if (!target) return '';
        let targetType = '01'; // 01 for mobile, 02 for national ID
        let formattedTarget = '';
        if (target.length >= 13) {
            targetType = '02';
            formattedTarget = target.substring(0, 13);
        } else {
            formattedTarget = '0066' + target.replace(/^0/, '');
        }
        const tag29 = '0016A000000677010111' + targetType + String(formattedTarget.length).padStart(2, '0') + formattedTarget;
        let payload = [
            '000201',
            amount ? '010212' : '010211',
            '29' + String(tag29.length).padStart(2, '0') + tag29,
            '5802TH',
            '5303764'
        ];
        if (amount) {
            const amtStr = Number(amount).toFixed(2);
            payload.push('54' + String(amtStr.length).padStart(2, '0') + amtStr);
        }
        const raw = payload.join('') + '6304';
        let crc = 0xFFFF;
        for (let i = 0; i < raw.length; i++) {
            crc ^= raw.charCodeAt(i) << 8;
            for (let j = 0; j < 8; j++) {
                crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
            }
        }
        const crcHex = (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
        return raw + crcHex;
    }

    function generatePromptPayQRSvg(refId, amount, ppInfo = {}) {
        const amtStr = '฿ ' + Number(amount || 0).toFixed(2);
        const ppId = ppInfo.id || SHOP_STATE.catalog?.payment_settings?.promptpay?.id || '0804513789';
        const ppName = ppInfo.name || SHOP_STATE.catalog?.payment_settings?.promptpay?.name || 'พวงเพ็ญ อินจันทร์';
        const ppBank = ppInfo.bank || SHOP_STATE.catalog?.payment_settings?.promptpay?.bank || 'พร้อมเพย์กลาง (PromptPay)';

        let qrContent = '';
        const cleanId = String(ppId).replace(/[^0-9]/g, '');
        if (cleanId.length >= 9) {
            const emvPayload = generatePromptPayPayload(cleanId, amount);
            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(emvPayload)}&margin=4`;
            qrContent = `
                <div style="position:relative; width:140px; height:140px; display:flex; align-items:center; justify-content:center; background:#fff; border-radius:8px; padding:4px; box-sizing:border-box;">
                    <img src="${qrUrl}" alt="PromptPay QR" style="width:132px; height:132px; object-fit:contain; border-radius:4px;">
                    <div style="position:absolute; width:26px; height:26px; background:#003b71; border:2px solid #fff; border-radius:6px; display:flex; align-items:center; justify-content:center; box-shadow:0 2px 6px rgba(0,0,0,0.3);">
                        <svg viewBox="0 0 24 24" style="width:16px; height:16px; fill:#fff;">
                            <path d="M12 3 L4 11 L7 11 L7 20 L17 20 L17 11 L20 11 Z"/>
                        </svg>
                    </div>
                </div>
            `;
        } else {
            qrContent = `
                <div style="width:140px; height:140px; background:#f1f5f9; display:flex; flex-direction:column; align-items:center; justify-content:center; border-radius:8px; color:#64748b; font-size:11px; text-align:center; padding:10px; box-sizing:border-box;">
                    <span style="font-size:24px;">⚠️</span>
                    <span>ยังไม่ได้ตั้งค่าพร้อมเพย์</span>
                </div>
            `;
        }

        return `
            <div class="lgr-promptpay-slip">
                <div class="lgr-pp-header">
                    <div style="display:flex; align-items:center; gap:6px;">
                        <span style="background:#fff; color:#003b71; font-weight:900; font-size:11px; padding:2px 6px; border-radius:4px;">THAI QR</span>
                        <span style="font-size:13px; font-weight:900; letter-spacing:0.5px;">พร้อมเพย์ PromptPay</span>
                    </div>
                    <span style="font-size:11px; opacity:0.9;">สแกนเพื่อจ่าย</span>
                </div>
                <div class="lgr-pp-qr-container">
                    ${qrContent}
                </div>
                <div class="lgr-pp-details">
                    <div style="font-size:12.5px; font-weight:800; color:#0f172a; line-height:1.2;">ชื่อบัญชี: ${esc(ppName)}</div>
                    <div style="font-size:11px; color:#475569; margin-top:2px;">พร้อมเพย์: <span style="font-weight:700; color:#003b71;">${esc(ppId || '0804513789')}</span></div>
                    <div style="font-size:10px; color:#64748b; margin-top:1px;">Ref: REF-${esc(refId)}</div>
                    <div style="font-size:17px; font-weight:900; color:#003b71; margin-top:3px;">${amtStr}</div>
                </div>
            </div>
        `;
    }
    window.generatePromptPayPayload = generatePromptPayPayload;
    window.generatePromptPayQRSvg = generatePromptPayQRSvg;

    function animateShopCounters(diaDelta, goldDelta) {
        const diaEl = document.getElementById('lgr-shop-dia-val');
        const barDia = document.getElementById('bar-diamond');
        const goldEl = document.getElementById('lgr-shop-gold-val');
        const barGold = document.getElementById('bar-gold');

        if (diaDelta > 0) {
            [diaEl, barDia].forEach(el => {
                if (!el) return;
                el.style.transition = 'transform 0.25s ease, color 0.25s ease';
                el.style.transform = 'scale(1.35)';
                el.style.color = '#38bdf8';
                setTimeout(() => {
                    if (el) { el.style.transform = ''; el.style.color = ''; }
                }, 700);
            });
        }
        if (goldDelta > 0) {
            [goldEl, barGold].forEach(el => {
                if (!el) return;
                el.style.transition = 'transform 0.25s ease, color 0.25s ease';
                el.style.transform = 'scale(1.35)';
                el.style.color = '#fde047';
                setTimeout(() => {
                    if (el) { el.style.transform = ''; el.style.color = ''; }
                }, 700);
            });
        }
    }

    function ensurePaymentModalOverlay() {
        let overlay = document.getElementById('lgr-payment-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'lgr-payment-overlay';
            overlay.className = 'lgr-pay-overlay';
            overlay.style.display = 'none';
            overlay.innerHTML = `
                <div class="lgr-pay-box" id="lgr-pay-box">
                    <div class="lgr-pay-header">
                        <div class="lgr-pay-title-group">
                            <span class="lgr-pay-header-icon">💳</span>
                            <span class="lgr-pay-header-title" id="lgr-pay-title">เลือกวิธีชำระเงิน</span>
                        </div>
                        <button type="button" class="lgr-pay-close-btn" onclick="window.closeShopPaymentModal()" title="ปิด">&times;</button>
                    </div>
                    <div class="lgr-pay-body" id="lgr-pay-modal-content"></div>
                </div>
            `;
            document.body.appendChild(overlay);
        }
        return overlay;
    }

    window.openShopPaymentModal = function (itemData) {
        if (!itemData) return;
        PAYMENT_STATE.activeItem = itemData;
        PAYMENT_STATE.isProcessing = false;
        PAYMENT_STATE.txRef = Math.floor(100000 + Math.random() * 900000);

        const curr = String(itemData.currency || 'THB').toUpperCase();
        if (curr === 'THB') {
            PAYMENT_STATE.selectedMethod = 'promptpay';
        } else if (curr === 'DIAMOND') {
            PAYMENT_STATE.selectedMethod = 'diamond';
        } else if (curr === 'GOLD') {
            PAYMENT_STATE.selectedMethod = 'gold';
        }

        const overlay = ensurePaymentModalOverlay();
        document.getElementById('lgr-pay-title').innerText = curr === 'DIAMOND'
            ? '💎 ยืนยันราคาก่อนซื้อสินค้า (ใช้เพชร)'
            : (curr === 'GOLD' ? '🪙 ยืนยันราคาก่อนซื้อสินค้า (ใช้ทอง)' : '💳 ยืนยันราคา & เลือกวิธีชำระเงิน');
        renderPaymentSelectView();
        overlay.style.display = 'flex';
    };

    window.closeShopPaymentModal = function (force = false) {
        if (PAYMENT_STATE.isProcessing && !force) return;
        clearPaymentTimers();
        PAYMENT_STATE.isProcessing = false;
        const overlay = document.getElementById('lgr-payment-overlay');
        if (overlay) overlay.style.display = 'none';
        PAYMENT_STATE.activeItem = null;
    };

    window.selectShopPaymentMethod = function (methodId) {
        if (PAYMENT_STATE.isProcessing) return;
        PAYMENT_STATE.selectedMethod = methodId;
        renderPaymentSelectView();
    };

    function renderPaymentSelectView() {
        const content = document.getElementById('lgr-pay-modal-content');
        const it = PAYMENT_STATE.activeItem;
        if (!content || !it) return;

        const curr = String(it.currency || 'THB').toUpperCase();
        const priceNum = Number(it.price || 0);
        const priceLabel = curr === 'THB'
            ? `฿ ${priceNum.toFixed(2)}`
            : (curr === 'GOLD' ? `🪙 ${fmtNum(priceNum)} ทอง` : `💎 ${fmtNum(priceNum)} เพชร`);

        // Visual icon
        let iconHtml = '🎁';
        if (it.imageUrl) {
            iconHtml = `<img src="${esc(it.imageUrl)}" style="max-width:54px; max-height:54px; object-fit:contain;">`;
        } else if (it.rewardDiamond > 0 && it.rewardGold === 0) {
            iconHtml = buildDiamondSvgVisual(it.rewardDiamond, { mini: true, size: 50 });
        } else if (it.rewardGold > 0) {
            iconHtml = buildGoldBarsVisual(it.rewardGold, { mini: true, size: 54 });
        } else if (it.catalogType === 'DICE' || it.diceName) {
            iconHtml = '🎲';
        } else if (it.catalogType === 'CHARACTER' || it.charName) {
            iconHtml = '👑';
        }

        const rewardPills = [];
        if (Number(it.rewardDiamond) > 0) rewardPills.push(`<span class="lgr-pay-reward-tag">💎 +${fmtNum(it.rewardDiamond)} เพชร</span>`);
        if (Number(it.rewardGold) > 0) rewardPills.push(`<span class="lgr-pay-reward-tag gold">🪙 +${fmtNum(it.rewardGold)} ทอง</span>`);
        if (it.charName) rewardPills.push(`<span class="lgr-pay-reward-tag">👑 ${esc(it.charName)}</span>`);
        if (it.diceName) rewardPills.push(`<span class="lgr-pay-reward-tag">🎲 ${esc(it.diceName)}</span>`);
        if (it.itemName && !rewardPills.length) rewardPills.push(`<span class="lgr-pay-reward-tag">✨ ${esc(it.itemName)}</span>`);

        let methodsHtml = '';
        if (curr === 'THB') {
            methodsHtml = `
                <div style="font-size:13px; font-weight:800; color:#cbd5e1; margin-top:4px;">เลือกช่องทางชำระเงิน (เงินบาท):</div>
                <div class="lgr-pay-methods-list">
                    ${PAYMENT_METHODS_THB.map(m => {
                const isActive = m.id === PAYMENT_STATE.selectedMethod;
                return `
                            <div class="lgr-pay-method-item ${isActive ? 'active' : ''}" onclick="window.selectShopPaymentMethod('${m.id}')">
                                <div class="lgr-pay-method-left">
                                    <span class="lgr-pay-method-icon">${m.icon}</span>
                                    <div class="lgr-pay-method-text">
                                        <div class="lgr-pay-method-title">${m.name}</div>
                                        <div class="lgr-pay-method-desc">${m.desc}</div>
                                    </div>
                                </div>
                                ${m.tag ? `<span class="lgr-pay-method-tag">${m.tag}</span>` : ''}
                            </div>
                        `;
            }).join('')}
                </div>
            `;
        } else if (curr === 'DIAMOND') {
            const userDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.diamond) ? Number(DEFAULT_USER.diamond) : 0;
            const isEnough = userDia >= priceNum;
            const remainDia = userDia - priceNum;
            methodsHtml = `
                <div style="background:linear-gradient(135deg, rgba(2,132,199,0.22), rgba(15,23,42,0.9)); border:2px solid #38bdf8; border-radius:12px; padding:10px 14px; text-align:center; margin-top:2px;">
                    <div style="font-size:11.5px; font-weight:800; color:#94a3b8;">ราคาสินค้าที่ต้องใช้</div>
                    <div style="font-size:22px; font-weight:900; color:#38bdf8; margin:3px 0 6px 0;">💎 ${fmtNum(priceNum)} เพชร</div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#cbd5e1; border-top:1px dashed rgba(148,163,184,0.3); padding-top:6px;">
                        <span>เพชรคงเหลือปัจจุบัน:</span>
                        <b style="color:#fff;">💎 ${fmtNum(userDia)} เพชร</b>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#cbd5e1; margin-top:3px;">
                        <span>เพชรคงเหลือหลังยืนยันซื้อ:</span>
                        <b style="color:${isEnough ? '#4ade80' : '#ef4444'};">${isEnough ? `💎 ${fmtNum(remainDia)} เพชร` : `⚠️ เพชรไม่พอ (ขาดอีก ${fmtNum(priceNum - userDia)} เพชร)`}</b>
                    </div>
                </div>
            `;
        } else if (curr === 'GOLD') {
            const userGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.gold) ? Number(DEFAULT_USER.gold) : 0;
            const isEnough = userGold >= priceNum;
            const remainGold = userGold - priceNum;
            methodsHtml = `
                <div style="background:linear-gradient(135deg, rgba(217,119,6,0.22), rgba(15,23,42,0.9)); border:2px solid #f59e0b; border-radius:12px; padding:10px 14px; text-align:center; margin-top:2px;">
                    <div style="font-size:11.5px; font-weight:800; color:#94a3b8;">ราคาสินค้าที่ต้องใช้</div>
                    <div style="font-size:22px; font-weight:900; color:#fde047; margin:3px 0 6px 0;">🪙 ${fmtNum(priceNum)} ทอง</div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#cbd5e1; border-top:1px dashed rgba(148,163,184,0.3); padding-top:6px;">
                        <span>ทองคงเหลือปัจจุบัน:</span>
                        <b style="color:#fff;">🪙 ${fmtNum(userGold)} ทอง</b>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#cbd5e1; margin-top:3px;">
                        <span>ทองคงเหลือหลังยืนยันซื้อ:</span>
                        <b style="color:${isEnough ? '#4ade80' : '#ef4444'};">${isEnough ? `🪙 ${fmtNum(remainGold)} ทอง` : `⚠️ ทองไม่พอ (ขาดอีก ${fmtNum(priceNum - userGold)} ทอง)`}</b>
                    </div>
                </div>
            `;
        }

        content.innerHTML = `
            <div class="lgr-pay-product-brief">
                <div class="lgr-pay-product-icon" style="font-size:28px;">
                    ${iconHtml}
                </div>
                <div class="lgr-pay-product-info">
                    <div class="lgr-pay-product-title">${esc(it.title)}</div>
                    ${it.subtitle ? `<div style="font-size:11.5px; color:#94a3b8;">${esc(it.subtitle)}</div>` : ''}
                    <div class="lgr-pay-product-rewards">
                        ${rewardPills.join('')}
                    </div>
                </div>
                <div class="lgr-pay-product-price">
                    <div class="lgr-pay-price-label">ราคา</div>
                    <div class="lgr-pay-price-val">${priceLabel}</div>
                </div>
            </div>

            ${methodsHtml}

            <div style="display:grid; grid-template-columns:1fr 1.6fr; gap:10px; margin-top:6px;">
                <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal()" style="background:#334155; color:#e2e8f0; border:1.5px solid #64748b; box-shadow:none;">
                    ❌ ยกเลิก
                </button>
                <button type="button" class="lgr-pay-confirm-btn" onclick="window.confirmShopPayment()">
                    ✅ ยืนยันซื้อ (${priceLabel})
                </button>
            </div>
        `;
    }

    async function startPromptPayFlow(it) {
        PAYMENT_STATE.isProcessing = true;
        clearPaymentTimers();
        const content = document.getElementById('lgr-pay-modal-content');
        if (!content) return;
        document.getElementById('lgr-pay-title').innerText = 'สแกน QR Code พร้อมเพย์ (PromptPay)';

        content.innerHTML = `
            <div class="lgr-pay-processing-box" style="padding: 24px 12px;">
                <div style="font-size:42px; animation:spin 1.5s linear infinite;">🔄</div>
                <div style="font-size:15px; font-weight:800; color:#38bdf8;">กำลังสร้างใบสั่งซื้อ PromptPay QR Code...</div>
                <div style="font-size:12px; color:#94a3b8;">เชื่อมต่อไปยังเซิร์ฟเวอร์ กรุณารอสักครู่</div>
            </div>
        `;

        try {
            const orderRes = await apiClient.createPaymentOrder(it.id, 'promptpay');
            if (!orderRes || orderRes.status !== 'success') {
                throw new Error(orderRes?.message || 'ไม่สามารถสร้างใบสั่งซื้อได้');
            }

            const orderNo = orderRes.order_no;
            const amountThb = Number(orderRes.amount_thb || it.price || 0);
            const rewardDia = Number(orderRes.reward_diamond || it.rewardDiamond || 0);
            const rewardGold = Number(orderRes.reward_gold || it.rewardGold || 0);
            PAYMENT_STATE.orderNo = orderNo;
            PAYMENT_STATE.orderId = orderRes.order_id;
            PAYMENT_STATE.countdownSecs = Number(orderRes.expires_in || 180);
            PAYMENT_STATE.totalCountdownSecs = PAYMENT_STATE.countdownSecs;

            const ppInfo = {
                id: orderRes.promptpay_id || SHOP_STATE.catalog?.payment_settings?.promptpay?.id || '0804513789',
                name: orderRes.promptpay_name || SHOP_STATE.catalog?.payment_settings?.promptpay?.name || 'พวงเพ็ญ ขันจันทร์',
                bank: orderRes.promptpay_bank || SHOP_STATE.catalog?.payment_settings?.promptpay?.bank || 'พร้อมเพย์กลาง (PromptPay)'
            };
            PAYMENT_STATE.ppInfo = ppInfo;

            // Render PromptPay QR View with countdown
            renderPromptPayQRView(it, orderNo, amountThb, rewardDia, rewardGold, ppInfo);

            // Start Countdown Timer
            PAYMENT_STATE.countdownTimer = setInterval(() => {
                PAYMENT_STATE.countdownSecs--;
                const countEl = document.getElementById('lgr-pp-countdown');
                const fillEl = document.getElementById('lgr-pp-timer-fill');
                if (countEl) countEl.innerText = Math.max(0, PAYMENT_STATE.countdownSecs);
                if (fillEl) {
                    const totalSecs = PAYMENT_STATE.totalCountdownSecs || 180;
                    const pct = Math.max(0, (PAYMENT_STATE.countdownSecs / totalSecs) * 100);
                    fillEl.style.width = pct + '%';
                }

                if (PAYMENT_STATE.countdownSecs <= 0) {
                    clearPaymentTimers();
                    renderPromptPayExpiredView(orderNo);
                }
            }, 1000);

            // Start 2s Real-Time Polling
            PAYMENT_STATE.pollingTimer = setInterval(async () => {
                if (!PAYMENT_STATE.orderNo) return;
                try {
                    const pollRes = await apiClient.checkPaymentStatus(PAYMENT_STATE.orderNo);
                    if (pollRes && pollRes.payment_status === 'paid') {
                        clearPaymentTimers();
                        handlePaymentCompleted(it, pollRes);
                    } else if (pollRes && pollRes.payment_status === 'expired') {
                        clearPaymentTimers();
                        renderPromptPayExpiredView(PAYMENT_STATE.orderNo);
                    }
                } catch (pollErr) {
                    console.warn('Payment polling error:', pollErr);
                }
            }, 2000);

        } catch (err) {
            clearPaymentTimers();
            PAYMENT_STATE.isProcessing = false;
            content.innerHTML = `
                <div class="lgr-pay-processing-box">
                    <div style="font-size:44px;">❌</div>
                    <div style="font-size:16px; font-weight:900; color:#ef4444;">เกิดข้อผิดพลาด</div>
                    <div style="font-size:12.5px; color:#cbd5e1;">${esc(err.message || 'ไม่สามารถสร้างบิลพร้อมเพย์ได้')}</div>
                    <button type="button" class="lgr-pay-confirm-btn" onclick="renderPaymentSelectView()" style="margin-top:10px;">
                        ย้อนกลับไปเลือกวิธีชำระเงิน
                    </button>
                </div>
            `;
        }
    }

    function renderPromptPayQRView(it, orderNo, amountThb, rewardDia, rewardGold, ppInfo = {}) {
        const content = document.getElementById('lgr-pay-modal-content');
        if (!content) return;
        document.getElementById('lgr-pay-title').innerText = 'สแกน QR พร้อมเพย์เพื่อชำระเงิน';

        const amtStr = '฿ ' + Number(amountThb || 0).toFixed(2);
        const qrSlipHtml = generatePromptPayQRSvg(orderNo, amountThb, ppInfo);

        content.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:10px; align-items:center;">
                <!-- Countdown Timer Pill -->
                <div class="lgr-countdown-pill" style="width:100%; box-sizing:border-box;">
                    <span>⏱️ กรุณาสแกนจ่ายภายใน:</span>
                    <span class="lgr-countdown-number" id="lgr-pp-countdown">${PAYMENT_STATE.countdownSecs || 180}</span>
                    <span>วินาที</span>
                </div>
                <div class="lgr-countdown-bar-track" style="margin-top:-4px;">
                    <div class="lgr-countdown-bar-fill" id="lgr-pp-timer-fill" style="width:100%;"></div>
                </div>

                <!-- Landscape container for QR Slip and details -->
                <div class="lgr-pp-landscape-wrap" style="width:100%; display:flex; justify-content:center; align-items:center; gap:14px;">
                    ${qrSlipHtml}

                    <div style="display:flex; flex-direction:column; gap:8px; text-align:left; max-width:240px;">
                        <div style="background:rgba(255,255,255,0.06); padding:8px 10px; border-radius:10px; border:1px solid rgba(56,189,248,0.25);">
                            <div style="font-size:11px; color:#94a3b8;">แพ็กเกจที่เลือก:</div>
                            <div style="font-size:13px; font-weight:800; color:#38bdf8;">${esc(it.title)}</div>
                            <div style="font-size:12px; font-weight:800; color:#4ade80; margin-top:2px;">💎 +${fmtNum(rewardDia)} เพชร</div>
                        </div>

                        <div style="display:flex; align-items:center; gap:6px; font-size:11px; color:#e2e8f0; background:rgba(34,197,94,0.15); padding:6px 10px; border-radius:8px; border:1px solid rgba(34,197,94,0.3);">
                            <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#22c55e; box-shadow:0 0 8px #22c55e; animation:pulse 1.5s infinite;"></span>
                            <span>รอตรวจยอดเงินเรียลไทม์ (ทุก 2 วิ)...</span>
                        </div>

                        <!-- Instant Confirmation Button for Real User -->
                        <button type="button" id="btn-confirm-pp-paid" onclick="window.confirmPromptPayPaid('${esc(orderNo)}')" style="background:linear-gradient(135deg, #10b981, #059669); border:1.5px solid #34d399; color:#fff; font-size:12.5px; font-weight:800; padding:10px 10px; border-radius:8px; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; box-shadow:0 4px 14px rgba(16,185,129,0.5); width:100%;">
                            <span style="font-size:15px;">✅</span>
                            <span>โอนเงินแล้ว (คลิกรับเพชรทันที)</span>
                        </button>
                        <div style="font-size:10px; color:#94a3b8; line-height:1.3; text-align:center;">
                            เมื่อสแกนโอนเงินในแอปธนาคารสำเร็จแล้ว กดปุ่มสีเขียวด้านบนเพื่อตัดยอดรับเพชรทันทีค่ะ
                        </div>
                    </div>
                </div>

                <div style="display:flex; gap:10px; width:100%; margin-top:4px;">
                    <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal(true)" style="background:#475569; color:#cbd5e1; font-size:12px; padding:9px;">
                        ❌ ยกเลิกการทำรายการ
                    </button>
                </div>
            </div>
        `;
    }

    function renderPromptPayExpiredView(orderNo) {
        const content = document.getElementById('lgr-pay-modal-content');
        if (!content) return;
        document.getElementById('lgr-pay-title').innerText = 'หมดเวลาทำรายการ';
        PAYMENT_STATE.isProcessing = false;

        content.innerHTML = `
            <div class="lgr-pay-processing-box" style="padding: 20px 10px;">
                <div style="font-size:46px;">⏱️</div>
                <div style="font-size:17px; font-weight:900; color:#f59e0b;">หมดเวลาการชำระเงิน</div>
                <div style="font-size:12.5px; color:#cbd5e1; max-width:320px; line-height:1.4;">
                    หากท่านได้สแกนโอนเงินผ่านแอปธนาคารเรียบร้อยแล้ว สามารถกดปุ่มยืนยันด้านล่างเพื่อตัดยอดรับเพชรได้ทันทีค่ะ
                </div>

                <div style="display:flex; flex-direction:column; gap:8px; width:100%; margin-top:12px; max-width:300px;">
                    <button type="button" class="lgr-pay-confirm-btn" onclick="window.confirmPromptPayPaid('${esc(orderNo)}')" style="background:linear-gradient(135deg,#10b981,#059669); border:1.5px solid #34d399; color:#fff; font-size:13px; font-weight:800; padding:10px;">
                        ✅ ฉันโอนเงินไปแล้ว (ยืนยันรับเพชรทันที)
                    </button>
                    <div style="display:flex; gap:8px; width:100%;">
                        <button type="button" class="lgr-pay-confirm-btn" onclick="renderPaymentSelectView()" style="background:linear-gradient(180deg,#38bdf8,#0284c7); flex:1; font-size:12px;">
                            🔄 ทำรายการใหม่
                        </button>
                        <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal(true)" style="background:#475569; color:#fff; flex:1; font-size:12px;">
                            ปิดหน้าต่าง
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    function handlePaymentCompleted(it, res) {
        clearPaymentTimers();
        PAYMENT_STATE.isProcessing = false;

        const addDia = Number(res.reward_diamond ?? it.rewardDiamond ?? 0);
        const addGold = Number(res.reward_gold ?? it.rewardGold ?? 0);
        const amtThb = Number(res.amount_thb ?? it.price ?? 0);

        // Update user balance in local state and UI immediately
        if (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) {
            if (res.new_diamond !== undefined) {
                DEFAULT_USER.diamond = Number(res.new_diamond);
            } else if (addDia > 0) {
                DEFAULT_USER.diamond = (Number(DEFAULT_USER.diamond) || 0) + addDia;
            }

            if (res.new_gold !== undefined) {
                DEFAULT_USER.gold = Number(res.new_gold);
            } else if (addGold > 0) {
                DEFAULT_USER.gold = (Number(DEFAULT_USER.gold) || 0) + addGold;
            }

            if (typeof updateUserBar === 'function') updateUserBar(DEFAULT_USER);
        }

        // Sync Header Numbers & Animate Counters
        animateShopCounters(addDia, addGold);
        syncWalletHeaderNumbers();

        // Render Success Celebration Modal
        renderPaymentSuccessCelebration(amtThb, addDia, addGold, res);

        // Play Thai Female Child Voice:
        playFemaleChildVoiceCelebration(amtThb, addDia, addGold);

        // Refresh user profile and inventory in background
        refreshUserProfileBar();
        window.refreshShopShowcase();
    }

    function renderPaymentSuccessCelebration(amtThb, addDia, addGold, res) {
        document.getElementById('lgr-pay-title').innerText = '🎉 ชำระเงินสำเร็จแล้วค่ะ!';
        const content = document.getElementById('lgr-pay-modal-content');
        if (!content) return;

        const curDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.diamond) ? Number(DEFAULT_USER.diamond) : 0;
        const curGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.gold) ? Number(DEFAULT_USER.gold) : 0;
        const voiceText = `ระบบได้รับเงินจำนวน ${amtThb.toFixed(2)} บาท และส่งเพชรจำนวน ${addDia.toLocaleString()} เพชรให้เรียบร้อยแล้วค่ะ! เย้!`;

        content.innerHTML = `
            <div class="lgr-pay-celebrate-box">
                <div class="lgr-pay-celebrate-check">✔</div>
                <div style="font-size:18px; font-weight:900; color:#4ade80; text-shadow:0 0 10px rgba(74,222,128,0.5);">
                    ได้รับยอดชำระเงินเรียบร้อยแล้ว!
                </div>

                <!-- Speech Bubble Box -->
                <div class="lgr-pay-celebrate-voice-bubble">
                    <span style="font-size:18px;">👧💬</span>
                    <div style="margin-top:2px;">"${voiceText}"</div>
                </div>

                <div class="lgr-reward-received-container" style="width:100%;">
                    <div style="font-size:12px; font-weight:800; color:#94a3b8; text-transform:uppercase;">รายการที่ส่งมอบเข้าบัญชี:</div>
                    <div class="lgr-reward-received-row dia" style="display:flex; align-items:center; gap:10px;">
                        ${buildDiamondSvgVisual(addDia, { mini: true, size: 44 })}
                        <span>ได้รับเพชร: <b style="color:#38bdf8;">+${fmtNum(addDia)}</b> เพชร</span>
                    </div>
                    ${addGold > 0 ? `
                        <div class="lgr-reward-received-row gold" style="display:flex; align-items:center; gap:10px;">
                            ${buildGoldBarsVisual(addGold, { mini: true, size: 44 })}
                            <span>ได้รับทอง: <b style="color:#fde047;">+${fmtNum(addGold)}</b> ทอง</span>
                        </div>
                    ` : ''}
                </div>

                <div class="lgr-reward-balance-summary" style="width:100%;">
                    <div>💎 เพชรคงเหลือใหม่: <b style="color:#38bdf8;">${fmtNum(curDia)}</b></div>
                    <div>🪙 ยอดชำระ: <b style="color:#4ade80;">฿ ${amtThb.toFixed(2)}</b></div>
                </div>

                <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal(true); window.refreshShopShowcase();" style="background:linear-gradient(180deg,#22c55e,#15803d); color:#fff; box-shadow:0 4px 16px rgba(34,197,94,0.6); margin-top:4px;">
                    ✨ ตกลง / สนุกกับเกมต่อ
                </button>
            </div>
        `;
    }

    window.confirmPromptPayPaid = async function(orderNo) {
        const btn = document.getElementById('btn-confirm-pp-paid');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span>⏳ กำลังตรวจสอบและตัดยอดเงิน...</span>';
        }
        if (typeof showToast === 'function') showToast('⚡ กำลังตรวจสอบยอดเงินและส่งมอบเพชร...');

        try {
            const res = await apiClient.checkPaymentStatus(orderNo, 'confirm_paid');
            if (res && (res.payment_status === 'paid' || res.status === 'success')) {
                clearPaymentTimers();
                const it = PAYMENT_STATE.activeItem || {
                    title: res.package_name || 'แพ็กเกจเพชร',
                    rewardDiamond: res.reward_diamond || 0,
                    rewardGold: res.reward_gold || 0,
                    price: res.amount_thb || 0
                };
                handlePaymentCompleted(it, res);
            } else {
                alert('ยังไม่พบยอดเงินหรือสถานะยังไม่สมบูรณ์: ' + (res?.message || ''));
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<span>✅ โอนเงินแล้ว (คลิกรับเพชรทันที)</span>';
                }
            }
        } catch (e) {
            console.error('Confirm payment error:', e);
            alert('เกิดข้อผิดพลาดในการตรวจสอบ: ' + e.message);
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<span>✅ โอนเงินแล้ว (คลิกรับเพชรทันที)</span>';
            }
        }
    };

    window.testSimulatePayment = async function(orderNo) {
        try {
            if (typeof showToast === 'function') showToast('⚡ กำลังจำลองสแกนจ่ายเงินผ่านธนาคาร...');
            await window.confirmPromptPayPaid(orderNo);
        } catch (e) {
            console.warn('Simulation error:', e);
        }
    };

    window.confirmShopPayment = async function () {
        const it = PAYMENT_STATE.activeItem;
        if (!it || PAYMENT_STATE.isProcessing) return;

        const curr = String(it.currency || 'THB').toUpperCase();
        if (curr === 'THB' && PAYMENT_STATE.selectedMethod === 'promptpay') {
            await startPromptPayFlow(it);
            return;
        }

        PAYMENT_STATE.isProcessing = true;
        document.getElementById('lgr-pay-title').innerText = 'รอดำเนินการชำระเงิน';
        const content = document.getElementById('lgr-pay-modal-content');
        const priceNum = Number(it.price || 0);

        // Check local balances for diamond/gold
        if (curr === 'DIAMOND') {
            const userDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.diamond) ? Number(DEFAULT_USER.diamond) : 0;
            if (userDia < priceNum) {
                PAYMENT_STATE.isProcessing = false;
                if (typeof showToast === 'function') showToast('❌ เพชรของคุณไม่เพียงพอ กรุณาเติมเพชรก่อน');
                return;
            }
        } else if (curr === 'GOLD') {
            const userGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.gold) ? Number(DEFAULT_USER.gold) : 0;
            if (userGold < priceNum) {
                PAYMENT_STATE.isProcessing = false;
                if (typeof showToast === 'function') showToast('❌ ทองของคุณไม่เพียงพอ');
                return;
            }
        }

        // Render "รอดำเนินการ" View with realistic PromptPay/ShopeePay QR and animated progress bar
        let visualArea = '';
        if (curr === 'THB' && PAYMENT_STATE.selectedMethod === 'promptpay') {
            visualArea = generatePromptPayQRSvg(PAYMENT_STATE.txRef, priceNum, PAYMENT_STATE.ppInfo || SHOP_STATE.catalog?.payment_settings?.promptpay || {});
        } else if (curr === 'THB' && PAYMENT_STATE.selectedMethod === 'shopeepay') {
            visualArea = generateShopeePaySlipHtml(PAYMENT_STATE.txRef, priceNum, PAYMENT_STATE.shopeeInfo || SHOP_STATE.catalog?.payment_settings?.shopeepay || {});
        } else {
            visualArea = `
                <div style="font-size:52px; animation:spin 2s linear infinite;">🔄</div>
            `;
        }

        content.innerHTML = `
            <div class="lgr-pay-processing-box">
                <div class="lgr-pay-status-pill">
                    <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#facc15; box-shadow:0 0 8px #facc15;"></span>
                    <span>รอดำเนินการ (กำลังตรวจสอบยอดชำระเงินอัตโนมัติ)</span>
                </div>

                ${visualArea}

                <div style="width:100%; display:flex; flex-direction:column; gap:6px;">
                    <div style="display:flex; justify-content:space-between; font-size:12px; color:#cbd5e1; font-weight:700;">
                        <span id="lgr-pay-status-msg">กำลังเชื่อมต่อและยืนยันยอดเงินจากธนาคาร...</span>
                        <span id="lgr-pay-pct">20%</span>
                    </div>
                    <div class="lgr-pay-progress-track">
                        <div class="lgr-pay-progress-fill" id="lgr-pay-progress-bar" style="width: 20%;"></div>
                    </div>
                </div>

                <div style="font-size:11.5px; color:#94a3b8; line-height:1.4;">
                    ระบบกำลังตรวจสอบและยืนยันยอดเงินอัตโนมัติ กรุณารอสักครู่ (ไม่เกิน 2 วินาที)...
                </div>
            </div>
        `;

        // Progress bar smooth animation
        const progBar = document.getElementById('lgr-pay-progress-bar');
        const pctEl = document.getElementById('lgr-pay-pct');
        const statusMsgEl = document.getElementById('lgr-pay-status-msg');

        let pct = 20;
        const progressTimer = setInterval(() => {
            pct = Math.min(pct + 18, 92);
            if (progBar) progBar.style.width = pct + '%';
            if (pctEl) pctEl.innerText = pct + '%';
            if (pct > 60 && statusMsgEl) statusMsgEl.innerText = 'ได้รับยอดชำระแล้ว กำลังส่งมอบสินค้าเข้าสู่บัญชี...';
        }, 220);

        // Execute API call concurrently
        let apiPromise;
        if (it.type === 'TOPUP') {
            apiPromise = apiClient.topupPurchase(it.id);
        } else if (it.type === 'CUSTOM') {
            apiPromise = apiClient.buyShopCustomItem(it.id);
        } else if (it.type === 'CATALOG') {
            apiPromise = apiClient.buyItem(it.catalogType, it.id, it.currency);
        } else {
            apiPromise = Promise.resolve({ status: 'success', message: 'ซื้อสำเร็จ' });
        }

        // Wait for both minimum delay (for realistic verification feeling) and API call
        const delayPromise = new Promise(resolve => setTimeout(resolve, 1400));

        try {
            const [res] = await Promise.all([apiPromise, delayPromise]);
            clearInterval(progressTimer);
            if (progBar) progBar.style.width = '100%';
            if (pctEl) pctEl.innerText = '100%';

            // Determine received goods
            const addDia = Number(res.added_diamond ?? it.rewardDiamond ?? 0);
            const addGold = Number(res.added_gold ?? it.rewardGold ?? 0);

            // Update user balance in local state and UI immediately (เอาจำนวนสินค้าเข้า)
            if (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) {
                if (res.new_diamond !== undefined) {
                    DEFAULT_USER.diamond = Number(res.new_diamond);
                } else if (addDia > 0) {
                    DEFAULT_USER.diamond = (Number(DEFAULT_USER.diamond) || 0) + addDia;
                } else if (res.deducted_field === 'diamond' && res.deducted_amount) {
                    DEFAULT_USER.diamond = Math.max(0, (Number(DEFAULT_USER.diamond) || 0) - Number(res.deducted_amount));
                }

                if (res.new_gold !== undefined) {
                    DEFAULT_USER.gold = Number(res.new_gold);
                } else if (addGold > 0) {
                    DEFAULT_USER.gold = (Number(DEFAULT_USER.gold) || 0) + addGold;
                } else if (res.deducted_field === 'gold' && res.deducted_amount) {
                    DEFAULT_USER.gold = Math.max(0, (Number(DEFAULT_USER.gold) || 0) - Number(res.deducted_amount));
                }

                if (typeof updateUserBar === 'function') updateUserBar(DEFAULT_USER);
            }

            // Sync Header Numbers & Animate Counters
            animateShopCounters(addDia, addGold);
            syncWalletHeaderNumbers();

            // Play celebratory audio
            if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
                try { window.soundEngine.playWin(); } catch (e) { }
            }

            // Show Success State with prominent goods display (หากชำระเสร็จ ให้แสดงจำนวนสินค้าที่ชื้อ)
            setTimeout(() => {
                renderPaymentSuccessView(it, res, addDia, addGold);
            }, 300);

            // Refresh user profile and inventory in background
            refreshUserProfileBar();
            window.refreshShopShowcase();

        } catch (err) {
            clearInterval(progressTimer);
            PAYMENT_STATE.isProcessing = false;
            content.innerHTML = `
                <div class="lgr-pay-processing-box">
                    <div style="font-size:48px;">❌</div>
                    <div style="font-size:16px; font-weight:900; color:#ef4444;">การชำระเงินไม่สำเร็จ</div>
                    <div style="font-size:13px; color:#cbd5e1;">${esc(err.message || 'ไม่สามารถทำรายการได้ในขณะนี้ กรุณาลองใหม่อีกครั้ง')}</div>
                    <div style="display:flex; gap:10px; width:100%; margin-top:8px;">
                        <button type="button" class="lgr-pay-confirm-btn" onclick="window.confirmShopPayment()" style="background:linear-gradient(180deg,#38bdf8,#0284c7);">
                            🔄 ลองใหม่อีกครั้ง
                        </button>
                        <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal()" style="background:#475569; color:#fff;">
                            ปิดหน้าต่าง
                        </button>
                    </div>
                </div>
            `;
        }
    };

    function renderPaymentSuccessView(it, res, addDia, addGold) {
        document.getElementById('lgr-pay-title').innerText = 'ชำระเงินสำเร็จ!';
        const content = document.getElementById('lgr-pay-modal-content');
        if (!content) return;

        const curDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.diamond) ? Number(DEFAULT_USER.diamond) : 0;
        const curGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.gold) ? Number(DEFAULT_USER.gold) : 0;

        const rewardsListHtml = [];
        if (addDia > 0) {
            rewardsListHtml.push(`
                <div class="lgr-reward-received-row dia" style="display:flex; align-items:center; gap:10px;">
                    ${buildDiamondSvgVisual(addDia, { mini: true, size: 44 })}
                    <span>ได้รับเพชร: <b>+${fmtNum(addDia)}</b> เพชร</span>
                </div>
            `);
        }
        if (addGold > 0) {
            rewardsListHtml.push(`
                <div class="lgr-reward-received-row gold" style="display:flex; align-items:center; gap:10px;">
                    ${buildGoldBarsVisual(addGold, { mini: true, size: 48 })}
                    <span>ได้รับทอง: <b>+${fmtNum(addGold)}</b> ทอง</span>
                </div>
            `);
        }
        if (it.charName) {
            rewardsListHtml.push(`
                <div class="lgr-reward-received-row" style="color:#fde047; border-color:#fde047;">
                    <span style="font-size:24px;">👑</span>
                    <span>ได้รับกรอบ: <b>${esc(it.charName)}</b> (พร้อมสวมใส่)</span>
                </div>
            `);
        }
        if (it.diceName) {
            rewardsListHtml.push(`
                <div class="lgr-reward-received-row" style="color:#38bdf8; border-color:#38bdf8;">
                    <span style="font-size:24px;">🎲</span>
                    <span>ได้รับลูกเต๋า: <b>${esc(it.diceName)}</b> 3D</span>
                </div>
            `);
        }
        if (!rewardsListHtml.length) {
            rewardsListHtml.push(`
                <div class="lgr-reward-received-row dia">
                    <span style="font-size:24px;">🎁</span>
                    <span>ได้รับ: <b>${esc(it.title)}</b></span>
                </div>
            `);
        }

        content.innerHTML = `
            <div class="lgr-pay-success-box">
                <div class="lgr-success-badge-circle">✔</div>
                <div style="font-size:18px; font-weight:900; color:#4ade80;">ชำระเงินเสร็จสิ้น!</div>
                <div style="font-size:12.5px; color:#cbd5e1;">สินค้าได้ถูกโอนเข้าสู่บัญชีของคุณเรียบร้อยแล้ว</div>

                <div class="lgr-reward-received-container">
                    <div style="font-size:12.5px; font-weight:800; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px;">รายการสินค้าที่ได้รับ:</div>
                    ${rewardsListHtml.join('')}
                </div>

                <div class="lgr-reward-balance-summary">
                    <div>💎 เพชรคงเหลือใหม่: <b style="color:#38bdf8;">${fmtNum(curDia)}</b></div>
                    <div>🪙 ทองคงเหลือใหม่: <b style="color:#fde047;">${fmtNum(curGold)}</b></div>
                </div>

                <button type="button" class="lgr-pay-confirm-btn" onclick="window.closeShopPaymentModal(); window.refreshShopShowcase();" style="background:linear-gradient(180deg,#22c55e,#15803d); color:#fff; box-shadow:0 4px 16px rgba(34,197,94,0.6);">
                    ✨ ตกลง / รับสินค้าเข้าเกม
                </button>
            </div>
        `;

        PAYMENT_STATE.isProcessing = false;
    }

    // =========================================================================
    // Interactive Frame Aura & 3D Dice Roll Effects & Preview Switcher
    // =========================================================================
    function showFloatingCardToast(parentEl, text, color) {
        if (!parentEl) return;
        const old = parentEl.querySelector('.lgr-floating-toast');
        if (old) old.remove();

        const toast = document.createElement('div');
        toast.className = 'lgr-floating-toast';
        toast.style.setProperty('--float-border', color || '#facc15');
        toast.innerText = text;
        parentEl.appendChild(toast);
        setTimeout(() => { if (toast && toast.parentNode) toast.remove(); }, 1250);
    }

    window.triggerFrameCardAuraEffect = function (el, charId, auraType, charName, grade) {
        if (!el) return;
        const auraColor = AURA_COLORS[auraType || 'gold'] || '#ffd700';

        // 0. Audio Ducking: ลดระดับเสียงเพลงเปิดเกมส์ลงชั่วคราว
        if (typeof window.duckLobbyAmbientSound === 'function') {
            window.duckLobbyAmbientSound(1600, 0.05);
        }

        // 1. Play crystal notification sound
        if (window.soundEngine && typeof window.soundEngine.playNotification === 'function') {
            try { window.soundEngine.playNotification(); } catch (e) { }
        } else if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
            try { window.soundEngine.playClick(); } catch (e) { }
        }

        // 2. Keep player's own avatar photo (รูปไอดีตัวเอง ไม่เปลี่ยนเป็นรูปคนอื่นเด็ดขาด)
        const myAvatar = getCharacterPreviewAvatar();
        const avCircle = el.querySelector('.lgr-frame-avatar-circle');
        if (avCircle) {
            avCircle.style.backgroundImage = `url('${myAvatar}')`;
        }

        // 3. Mark parent card to unclip overflow in 3D
        const parentCard = el.closest('.lgr-tall-card, .lgr-pickup-hero, .lgr-stage-body');
        if (parentCard) {
            parentCard.classList.add('popout-active');
            setTimeout(() => parentCard.classList.remove('popout-active'), 1100);
        }

        // 4. Trigger 3D Pop-Out & Embossed Aura Animation (นูนลอยออกมาด้านนอกกรอบ)
        el.classList.remove('aura-active');
        void el.offsetWidth;
        el.classList.add('aura-active');

        // 5. Show Floating Aura Toast
        const toastText = `✨ กรอบรูป ${charName} [${grade}]`;
        showFloatingCardToast(el, toastText, auraColor);

        setTimeout(() => {
            el.classList.remove('aura-active');
        }, 1100);
    };

    window.triggerDiceRollEffect = function (el, diceId, auraType, diceName, controlRate) {
        if (!el) return;
        const auraColor = AURA_COLORS[auraType || 'cyan'] || '#38bdf8';

        // 0. Audio Ducking: ลดระดับเสียงเพลงเปิดเกมส์ลงชั่วคราว
        if (typeof window.duckLobbyAmbientSound === 'function') {
            window.duckLobbyAmbientSound(2000, 0.04);
        }

        // 1. Play authentic dice rattle sound
        if (window.soundEngine && typeof window.soundEngine.playDiceRoll === 'function') {
            try { window.soundEngine.playDiceRoll(); } catch (e) { }
        }

        // 2. Mark parent card to unclip overflow in 3D
        const parentCard = el.closest('.lgr-tall-card, .lgr-pickup-hero, .lgr-stage-body');
        if (parentCard) {
            parentCard.classList.add('popout-active');
            setTimeout(() => parentCard.classList.remove('popout-active'), 1150);
        }

        // 3. Trigger 3D dice roll animation & expanding aura light
        el.classList.remove('dice-rolling');
        void el.offsetWidth;
        el.classList.add('dice-rolling');

        // 4. Roll a random number (1-6)
        const rollNum = Math.floor(Math.random() * 6) + 1;

        // 5. After 600ms land thud sound and show result badge
        setTimeout(() => {
            if (window.soundEngine && typeof window.soundEngine.playDiceLand === 'function') {
                try { window.soundEngine.playDiceLand(); } catch (e) { }
            }
            showFloatingCardToast(el, `🎯 ทอยได้ [${rollNum}]! ✨ แสงเออร่า ${diceName}`, auraColor);
        }, 620);

        setTimeout(() => {
            el.classList.remove('dice-rolling');
        }, 1150);
    };

    window.toggleShopAvatarPreviewMode = function () {
        renderStageContent();
    };

    // Convenience Handlers for Cards
    window.requestTopupPackagePurchase = function (pkgId) {
        const pkgs = SHOP_STATE.catalog?.topup_packages || [];
        const p = pkgs.find(x => Number(x.id) === Number(pkgId));
        if (!p) {
            window.openShopPaymentModal({
                type: 'TOPUP',
                id: Number(pkgId),
                title: 'แพ็กเกจเติมเงิน',
                subtitle: 'เติมเงินเข้าสู่บัญชีเกม',
                currency: 'THB',
                price: 0,
                rewardDiamond: 0,
                rewardGold: 0
            });
            return;
        }
        const dia = Number(p.reward_diamond || 0);
        const gold = Number(p.reward_gold || 0);
        window.openShopPaymentModal({
            type: 'TOPUP',
            id: Number(p.id),
            title: p.name || (dia > 0 ? `แพ็กเกจเพชร ${fmtNum(dia)}` : `แพ็กเกจทอง ${fmtNum(gold)}`),
            subtitle: dia > 0 && gold > 0 ? `ได้รับ +${fmtNum(dia)} เพชร และ +${fmtNum(gold)} ทอง` : (dia > 0 ? `ได้รับ +${fmtNum(dia)} เพชร` : `ได้รับ +${fmtNum(gold)} ทอง`),
            currency: 'THB',
            price: Number(p.price_thb || 0),
            rewardDiamond: dia,
            rewardGold: gold
        });
    };

    window.requestCustomItemPurchase = function (shopItemId) {
        const it = SHOP_STATE.customItems.find(x => Number(x.id) === Number(shopItemId));
        if (!it) {
            window.openShopPaymentModal({
                type: 'CUSTOM',
                id: Number(shopItemId),
                title: 'ไอเทมพิเศษ',
                subtitle: '',
                currency: 'DIAMOND',
                price: 0,
                rewardDiamond: 0,
                rewardGold: 0
            });
            return;
        }
        window.openShopPaymentModal({
            type: 'CUSTOM',
            id: Number(it.id),
            title: it.title,
            subtitle: it.subtitle || '',
            currency: String(it.currency || 'DIAMOND').toUpperCase(),
            price: Number(it.price || 0),
            rewardDiamond: Number(it.reward_diamond || 0),
            rewardGold: Number(it.reward_gold || 0),
            charName: it.char_name || '',
            diceName: it.dice_name || '',
            imageUrl: it.image_url || ''
        });
    };

    window.requestCatalogPurchase = function (catalogType, itemId, currency) {
        let name = '';
        let price = 0;
        if (catalogType === 'CHARACTER') {
            const c = (SHOP_STATE.catalog?.characters || []).find(x => Number(x.id) === Number(itemId));
            if (c) {
                name = c.name;
                price = currency === 'DIAMOND' ? Number(c.price_diamond || 0) : Number(c.price_gold || 0);
            }
        } else if (catalogType === 'DICE') {
            const d = (SHOP_STATE.catalog?.dice || []).find(x => Number(x.id) === Number(itemId));
            if (d) {
                name = d.name;
                price = currency === 'DIAMOND' ? Number(d.price_diamond || 0) : Number(d.price_gold || 0);
            }
        }
        window.openShopPaymentModal({
            type: 'CATALOG',
            catalogType: catalogType,
            id: Number(itemId),
            title: (catalogType === 'CHARACTER' ? 'การ์ดกรอบ: ' : 'ลูกเต๋า 3D: ') + (name || itemId),
            subtitle: `ซื้อไอเทมถาวรเข้าสู่คลังสัมภาระ`,
            currency: currency,
            price: price,
            rewardDiamond: 0,
            rewardGold: 0,
            itemName: name
        });
    };

    // Public Legacy compatibility hooks
    window.buyCatalogShopItem = async function (itemType, itemId, currency, name, price) {
        window.requestCatalogPurchase(itemType, itemId, currency);
    };

    window.buyCustomShopItemAction = async function (shopItemId) {
        window.requestCustomItemPurchase(shopItemId);
    };

    window.buyTopupPackageInShop = async function (pkgId, dia, gold) {
        window.requestTopupPackagePurchase(pkgId);
    };

    window.equipOwnedFromShop = async function (itemType, inventoryId) {
        if (!inventoryId) return;
        try {
            const res = await apiClient.equipItem(itemType, inventoryId);
            if (typeof showToast === 'function') showToast('✨ ' + (res.message || 'สวมใส่เรียบร้อยแล้ว!'));
            await refreshUserProfileBar();
        } catch (err) {
            if (typeof showToast === 'function') showToast('❌ ' + (err.message || 'ไม่สามารถสวมใส่ได้'));
        }
    };

    window.claimShopFreeDiamondAction = async function () {
        if (typeof window.watchAdForFreeDiamonds === 'function') {
            await window.watchAdForFreeDiamonds();
            await refreshUserProfileBar();
            return;
        }
        try {
            const res = await apiClient.request('api/claim_ad_reward.php', { method: 'POST', body: '{}' });
            if (typeof showToast === 'function') showToast('🎉 ' + (res.message || 'รับเพชรฟรีสำเร็จ!'));
            await refreshUserProfileBar();
        } catch (err) {
            if (typeof showToast === 'function') showToast(err.message || 'คุณรับโบนัสเพชรฟรีของวันนี้ไปแล้ว');
        }
    };

    window.showShopRatesInfoPopup = function () {
        const ev = SHOP_STATE.catalog?.gacha_event || {};
        const msg = [
            '🏪 ข้อมูลร้านค้า & อัตราสุ่มไอเทม:',
            '• ร้านค้าเพชร & ทอง: ได้รับเข้ากระเป๋าทันทีหลังซื้อสำเร็จ',
            '• การ์ดกรอบ & ลูกเต๋า: ซื้อแล้วเก็บเข้าคลังไอเทมถาวร สามารถกดสวมใส่ได้ทันที',
            `• PICK UP การ์ดกรอบ: แจ็คพอตกรอบแรร์ ${ev.rate_splus ?? 3}% | การ์ดเงาทอง ${ev.rate_shadow_gold ?? 10}% | การ์ดเงาฟ้า ${ev.rate_shadow_blue ?? 50}%`
        ].join('\n');
        if (typeof showInGameAlert === 'function') {
            showInGameAlert(msg, '📊 รายละเอียด & อัตราร้านค้า', '🏪');
        } else {
            alert(msg);
        }
    };

    // Seamless compatibility with existing loadShopData() & switchShopTab() calls across index.html / ui.js
    const installHooks = () => {
        ensureShopModalStructure();
        window.loadShopData = window.refreshShopShowcase;
        window.switchShopTab = function (tabKey) {
            const map = { topup: 'diamond', gacha: 'pickup_frame', upgrade: 'frames' };
            window.selectShopMenu(map[tabKey] || tabKey, tabKey === 'upgrade' ? 2 : 0);
        };
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', installHooks);
    } else {
        installHooks();
    }
    window.addEventListener('load', installHooks);
    window.addEventListener('resize', updateScrollArrowsVisibility);
})();

