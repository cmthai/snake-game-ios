/**
 * clan_directory.js - 25 Clan Families System & Lively 3D Room Bot Automation
 * Features:
 *  - 25 Predefined Thai Clan Families (Clans) with complete branding & badges
 *  - 20-30 Unique members per family (~625 realistic members) with real photos
 *  - Live Game Statuses: Playing 4P, 1v1, 2v2, Online in House, Online in Lobby, Offline
 *  - All-Families Directory UI Tab in Clan Modal
 *  - Detailed Family Member Inspector (ใครกำลังเล่นบ้าง, สมาชิกทุกคน)
 *  - Automated lively 3D room members: 8-10 people inside, 5 people walking around,
 *    and sending chat/emojis to simulate vibrant multiplayer life!
 */

(function() {
    'use strict';

    // 25 Predefined Thai Clan Families
    const PREDEFINED_CLAN_FAMILIES = [
        { id: 1, name: 'ครอบครัว พญานาคราช 3D', tag: 'NAGA', badge: 'badge_naga.png', level: 5, score: 245000, slogan: 'รวมพลผู้เล่นสายเวทมนตร์และบันไดงู ยึดครองทุกกระดาน 3D', leader: 'เซียนเต๋าสายฟ้า', targetCount: 28 },
        { id: 2, name: 'ครอบครัว มังกรทองคำ', tag: 'DRG', badge: 'badge_dragon.png', level: 6, score: 298000, slogan: 'สังกัดยอดฝีมือระดับตำนาน ทอยลูกเต๋าแม่นยำดั่งใจนึก', leader: 'มังกรหยกสามมิติ', targetCount: 29 },
        { id: 3, name: 'ครอบครัว นีออนไซเบอร์', tag: 'CYBER', badge: 'badge_cyber.png', level: 4, score: 182000, slogan: 'แสงสีนีออนสุดล้ำ ผู้บุกเบิกเทคนิคสร้างแลนด์มาร์คยุคใหม่', leader: 'น้องแพรวา ไซเบอร์', targetCount: 26 },
        { id: 4, name: 'ครอบครัว แก๊งแมวเหมียวพารวย', tag: 'CAT', badge: 'badge_cat.png', level: 5, score: 215000, slogan: 'ทาสแมวรวมตัว! เหมียวนำโชคทอยติดเบิ้ล 3 ตาติดกวาดเหรียญ', leader: 'น้องมินต์ ทาสแมว', targetCount: 30 },
        { id: 5, name: 'ครอบครัว แก๊งตูบสี่ขานำโชค', tag: 'DOG', badge: 'badge_dog.png', level: 4, score: 164000, slogan: 'เพื่อนซี้สี่ขารักความสนุก สดใส พลังบวกเต็มเปี่ยมทุกตา', leader: 'กัปตันชิบะ', targetCount: 27 },
        { id: 6, name: 'ครอบครัว ฟินิกซ์เพลิงอมตะ', tag: 'PHNX', badge: 'badge_phoenix.png', level: 6, score: 310000, slogan: 'นกไฟไม่มีวันตาย พลิกสถานการณ์ล้มละลายสู่ชัยชนะสูงสุด', leader: 'อัศวินเพลิง', targetCount: 28 },
        { id: 7, name: 'ครอบครัว มหานครพันล้าน', tag: 'RICH', badge: 'badge_rich.png', level: 7, score: 380000, slogan: 'กลุ่มนักลงทุนอสังหาฯ กว้านซื้อเมือง 3 เท่า ยึดเกาะทุกสาย', leader: 'บอส วีรวัฒน์', targetCount: 30 },
        { id: 8, name: 'ครอบครัว อินทรีเวหา', tag: 'EAGLE', badge: 'badge_eagle.png', level: 4, score: 175000, slogan: 'สายตาเฉียบคม โฉบยึดหัวมุมและเส้นชัยอย่างว่องไว', leader: 'อินทรีทอง', targetCount: 25 },
        { id: 9, name: 'ครอบครัว พยัคฆ์ทมิฬคำราม', tag: 'TIGER', badge: 'badge_tiger.png', level: 5, score: 230000, slogan: 'เสือร้ายแห่งกระดานงู ลุยเดี่ยวไม่เกรงกลัวใครในห้อง 5M', leader: 'เสือใหญ่แดนสยาม', targetCount: 26 },
        { id: 10, name: 'ครอบครัว เทพสายฟ้าธันเดอร์', tag: 'THOR', badge: 'badge_thunder.png', level: 5, score: 252000, slogan: 'พลังไฟฟ้าฟาด ลบเมืองคู่แข่งให้ราบคาบทุกการเดิน', leader: 'ธันเดอร์โบลต์', targetCount: 27 },
        { id: 11, name: 'ครอบครัว จิ้งจอกหิมะสีเงิน', tag: 'FOX', badge: 'badge_fox.png', level: 4, score: 158000, slogan: 'ฉลาดปราดเปรียว หลบงูพิษทุกช่อง เดินหมากอย่างแยบยล', leader: 'สโนว์ฟ็อกซ์', targetCount: 24 },
        { id: 12, name: 'ครอบครัว สิงห์เจ้าสมุทร', tag: 'OCEAN', badge: 'badge_ocean.png', level: 5, score: 220000, slogan: 'คลื่นยักษ์สีคราม กวาดค่าผ่านทางเข้ากระเป๋ามหาศาล', leader: 'โพไซดอนไทย', targetCount: 26 },
        { id: 13, name: 'ครอบครัว ซามูไรเงาสีชาด', tag: 'SHADOW', badge: 'badge_shadow.png', level: 4, score: 195000, slogan: 'ย่างก้าวเงียบกริบ พุ่งทะยานสู่ช่อง 100 แบบไม่ทันตั้งตัว', leader: 'เคนชิน ซามูไร', targetCount: 25 },
        { id: 14, name: 'ครอบครัว อัศวินโต๊ะกลม', tag: 'KNIGHT', badge: 'badge_knight.png', level: 5, score: 240000, slogan: 'พลังแห่งความสามัคคี สายแข่งทีม 2v2 ชนะรวดไม่เคยแพ้', leader: 'เซอร์แลนเซล็อต', targetCount: 28 },
        { id: 15, name: 'ครอบครัว ราชาลูกเต๋า 3D', tag: 'DICE', badge: 'badge_dice.png', level: 6, score: 285000, slogan: 'ศาสตร์แห่งเต๋า ทอยตรงแต้มดั่งสั่งได้ 2.. 7.. 12 เสมอ', leader: 'เจ้าพ่อลูกเต๋า', targetCount: 27 },
        { id: 16, name: 'ครอบครัว วาฬสีน้ำเงินยักษ์', tag: 'WHALE', badge: 'badge_whale.png', level: 7, score: 410000, slogan: 'กระเป๋าหนักระดับมหาเศรษฐี เดินเล่นห้อง 10M ชิลๆ', leader: 'กัปตันบิ๊กวาฬ', targetCount: 29 },
        { id: 17, name: 'ครอบครัว วูล์ฟแพ็กหมาป่า', tag: 'WOLF', badge: 'badge_wolf.png', level: 4, score: 170000, slogan: 'ล่าแต้มเป็นฝูง ไต่อันดับ Clan Ranking ติดท็อป 10 ประจำสัปดาห์', leader: 'อัลฟ่าวูล์ฟ', targetCount: 25 },
        { id: 18, name: 'ครอบครัว ยูนิคอร์นสายรุ้ง', tag: 'RAIN', badge: 'badge_unicorn.png', level: 5, score: 205000, slogan: 'สายหวานสดใส ดึงดูดโชคลาภตกช่องการ์ดดวงทองคำตลอด', leader: 'น้องพิม พาสเทล', targetCount: 28 },
        { id: 19, name: 'ครอบครัว ปราการหินผาไททัน', tag: 'TITAN', badge: 'badge_titan.png', level: 5, score: 235000, slogan: 'ป้อมปราการแข็งแกร่ง สร้างแลนด์มาร์คหนาแน่น ไม่มีวันล้มละลาย', leader: 'ไททัน ศักดิ์ดา', targetCount: 26 },
        { id: 20, name: 'ครอบครัว สตาร์การ์เดี้ยน', tag: 'STAR', badge: 'badge_star.png', level: 4, score: 188000, slogan: 'แสงแห่งดวงดาว นำทางก้าวข้ามทุกอุปสรรคและบันไดงู', leader: 'สตาร์การ์ด', targetCount: 26 },
        { id: 21, name: 'ครอบครัว กาแล็กซี่ทัวร์', tag: 'GLX', badge: 'badge_galaxy.png', level: 5, score: 218000, slogan: 'ท่องไปในอวกาศ ค้นพบเทคนิคเดินหมากสุดพิสดารไร้ขีดจำกัด', leader: 'ผู้กองกาแล็กซี่', targetCount: 27 },
        { id: 22, name: 'ครอบครัว มนตราพฤกษา', tag: 'LEAF', badge: 'badge_leaf.png', level: 4, score: 162000, slogan: 'ร่มเย็นดั่งธรรมชาติ สบายใจทุกครั้งที่เล่น สนุกไร้กังวล', leader: 'พฤกษา นารี', targetCount: 25 },
        { id: 23, name: 'ครอบครัว สยามแชมเปี้ยน', tag: 'SIAM', badge: 'badge_siam.png', level: 6, score: 320000, slogan: 'รวมดาวเด่นยอดฝีมือทั่วฟ้าเมืองไทย สถิติชนะสูงสุด 85%', leader: 'ยอดนักสู้สยาม', targetCount: 29 },
        { id: 24, name: 'ครอบครัว ดราก้อนไนท์', tag: 'DKNIGHT', badge: 'badge_dknight.png', level: 5, score: 250000, slogan: 'อัศวินมังกรเกราะเงิน เชี่ยวชาญการชิงพื้นที่ทองคำบนกระดาน', leader: 'อัศวินมังกร', targetCount: 26 },
        { id: 25, name: 'ครอบครัว มหาเศรษฐีเมืองหลวง', tag: 'VIP', badge: 'badge_vip.png', level: 7, score: 395000, slogan: 'สังคมผู้เล่นระดับ VIP ซื้อบ้าน จัดเลี้ยง ชนะแมตช์เป็นประจำ', leader: 'ท่านประธานชานนท์', targetCount: 30 }
    ];

    // คลังรายชื่อสมาชิกหลากหลายวัฒนธรรม (คนไทยแบบบ้านๆ, ภาษาจีน, ภาษาเกาหลี, สากล)
    // เพื่อให้ชื่อไม่ซ้ำกันเด็ดขาด (Unique per clan) ตามที่ผู้ใช้ต้องการ
    const THAI_ORDINARY_NAMES = [
        'ลุงสมหมาย', 'ป้าเพ็ญศรี', 'น้าต้อย', 'ช่างชาญ', 'พี่ยุทธ', 'หมอมุกดา', 'จ่าต๋อย', 'ป๊อกแป๊ก',
        'ต้อม แปดริ้ว', 'ส้มโอ สายหวาน', 'แบงค์ สวนผึ้ง', 'ครูน้อย', 'ตุ่น ปากน้ำ', 'น้าอ้วน ชวนชิม',
        'เฮียตี๋ เยาวราช', 'เจ๊หงส์', 'พี่หมู สายบุญ', 'โก้ เมืองนนท์', 'น้าดำ ดอนเมือง', 'ช่างศักดิ์',
        'ลุงบุญรอด', 'พี่เอก บางบอน', 'ป้าสมร', 'น้องก้อย', 'น้าพงษ์', 'ต้อย บางพลี', 'บอย สวนส้ม',
        'จิ๊บ เมืองกาญจน์', 'ยุ้ย สายชิล', 'เมย์ อัมพวา', 'นัท มีนบุรี', 'โน้ต พัทยา', 'โดม เมืองชล',
        'โบ๊ท ปทุม', 'ปาล์ม มหาชัย', 'กุ้ง ท่าพระ', 'บอล บางใหญ่', 'แอน พระรามสอง', 'ตาล นครชัยศรี',
        'ปิ๊ก สมุทรสาคร', 'โจ พระประแดง', 'ตั๊ก บางแค', 'หนึ่ง สวนผัก', 'เต้ ลาดพร้าว', 'ออย ดอนหวาย',
        'ปิง บางเลน', 'นุช สามโคก', 'เก่ง ไทรน้อย', 'เบิ้ม บางบัวทอง', 'ลุงสมาน', 'ป้าสำราญ', 'น้าเดช',
        'พี่เปี๊ยก', 'ช่างหนุ่ม', 'ลุงทวน', 'น้าสายัณห์', 'ป้าทองดี', 'พี่แฉล้ม', 'ครูสมปอง', 'จ่าประจักษ์',
        'น้าแสวง', 'ลุงอินทร์', 'ป้าสายบัว', 'พี่สมพร', 'น้องมะลิ', 'ลุงทองคำ', 'น้าบัวลอย', 'ป้าจันทร์หอม',
        'ลุงสว่าง', 'น้าเชิด', 'ป้าละมุน', 'พี่สุชาติ', 'น้าบุญมี', 'ช่างสมหมาย', 'ป้าลำดวน', 'ลุงมั่น'
    ];

    const CHINESE_NAMES = [
        '陈伟 (Chen Wei)', '张敏 (Zhang Min)', '王强 (Wang Qiang)', '李娜 (Li Na)', '刘杰 (Liu Jie)',
        '赵磊 (Zhao Lei)', '孙丽 (Sun Li)', '周洋 (Zhou Yang)', '吴刚 (Wu Gang)', '郑秀 (Zheng Xiu)',
        'อาเหวิน', 'อาเฉิน', 'หลี่หมิง', 'เสี่ยวหลิน', 'จางเหว่ย', 'เหมยลี่', 'ต้าหมิง', 'อาฟู่',
        'เจ๊หลิน', 'เถ้าแก่เฉิน', 'ซินหยี่', 'เหาหราน', 'อี้เฟย', 'จื่อหาน', 'หานตง', 'เจี้ยนเฉิง',
        'เสี่ยวเฉิน', 'อาเคี้ยง', 'อาเหลียง', 'จางหมิ่น', 'หลี่เหวิน', 'หวังหยาง', 'หลิวเต๋อ', 'กัวจิ้ง'
    ];

    const KOREAN_NAMES = [
        '민준 (Minjun)', '서연 (Seoyeon)', '지훈 (Jihoon)', '유진 (Yujin)', '하준 (Hajun)',
        '도윤 (Doyun)', '시우 (Siwoo)', '은우 (Eunwoo)', '수아 (Sua)', '지아 (Jia)',
        'มินโฮ', 'ยูจิน', 'ซูอา', 'จีฮุน', 'ซองฮุน', 'ฮยอนอู', 'มินซอ', 'แทฮยอน', 'จินซอง',
        'ดาฮยอน', 'จองอู', 'เยอึน', 'แฮวอน', 'ชีอู', 'ยูนา', 'อึนจี', 'ซังมิน', 'ซึงโฮ', 'แทมิน',
        'ดงฮยอน', 'แจฮยอน', 'อินฮยอก', 'ซูจิน', 'มินกยู', 'ฮเยจิน', 'โบรัม', 'เยจี'
    ];

    const INTERNATIONAL_NAMES = [
        'Alex_99', 'Tommy_K', 'Sarah_B', 'Kevin.W', 'Mike_T', 'Chris_L', 'Emma.R', 'Jason_K',
        'Luna.S', 'David_M', 'Ryan.P', 'Peter.Z', 'Sam_Walker', 'Harry.C', 'Eric_B', 'Andy_L',
        'Lucas.D', 'Daniel.K', 'Leo_Gamer', 'Oliver_T', 'Max_Power', 'Felix_99', 'Anna_Sky'
    ];

    // รายการสถานะการเล่นเกมสด (Live Match Statuses)
    const PLAYING_STATUSES = [
        '🟢 กำลังแข่งขัน เดี่ยว 4 (ห้อง 5M)',
        '🟢 กำลังแข่งขัน 1 ต่อ 1 (ห้อง 2M)',
        '🟢 กำลังแข่งขัน ทีม 2v2 (ห้อง 10M)',
        '🟢 กำลังแข่งขัน เดี่ยว 3 (ห้อง 5M)',
        '🟢 กำลังแข่งขัน 1 ต่อ 1 (ห้อง 10M)',
        '🟢 กำลังแข่งขัน เดี่ยว 4 (ห้อง 2M)'
    ];

    const ONLINE_HOUSE_STATUSES = [
        '🟢 นั่งพักผ่อนในบ้าน 3D',
        '🟢 กำลังคุยแชทในห้องบ้าน 3D',
        '🟢 ออนไลน์หน้าเลือกกระดาน',
        '🟢 ออนไลน์ในล็อบบี้'
    ];

    const OFFLINE_STATUSES = [
        '⚪ ออฟไลน์ (เมื่อ 6 นาทีก่อน)',
        '⚪ ออฟไลน์ (เมื่อ 14 นาทีก่อน)',
        '⚪ ออฟไลน์ (เมื่อ 28 นาทีก่อน)',
        '⚪ ออฟไลน์ (เมื่อ 45 นาทีก่อน)',
        '⚪ ออฟไลน์ (เมื่อ 1 ชม. ที่แล้ว)',
        '⚪ ออฟไลน์ (เมื่อ 2 ชม. ที่แล้ว)',
        '⚪ ออฟไลน์ (เมื่อ 5 ชม. ที่แล้ว)'
    ];

    // Chat phrases & emojis for alive 3D room atmosphere
    const BOT_CHAT_MESSAGES = [
        'สวัสดีจ้าทุกคน! 👋 วันนี้ใครว่างมาตี้ 2v2 กัน',
        'เมื่อกี้ลงห้อง 5M มา ชนะตาเดียวได้ 5 ล้านเลย! 🎉',
        'ทอยเต๋าติดดับเบิ้ล 3 ตาติด โคตรเฮง 🎲✨',
        'ใครเปิดกล่องคิวบ์แล้วได้การ์ด S+ บ้างไหม? 💎',
        'แลนด์มาร์คหนาแน่นมากวันนี้ สู้ๆ น้าา 🔥',
        '555+ โดนงูกินจากช่อง 99 ลงมา 78 เกือบแพ้ 😂',
        'น้องแมวส้มมาเชียร์ด้วย น่าร้ากกก 🐱💖',
        'ยินดีต้อนรับสมาชิกใหม่เข้าบ้านครับผม 🏰',
        'วันนี้แต้มบ้านพุ่งมาก อันดับ Clan Ranking ขึ้นท็อปแล้ว 🏆',
        'ขอตัวไปทอยเต๋าห้อง 2M แป๊บนะจ๊ะ ⚡',
        'ทาสแมวรายงานตัววว เหมียวๆ 🐾',
        'ทอยเบิ้ล 12 ด่วนๆ เลย! 🎲🚀'
    ];

    const BOT_EMOJI_POOL = ['😍', '😃', '🔥', '🎲', '🎉', '🐱', '🐶', '⚡', '🏆', '💎', '👏', '😂', '✨', '🥳'];

    // In-memory generated 25 families & members cache
    let cachedFamilies = null;

    /**
     * ดึงชื่อที่ไม่ซ้ำกันเด็ดขาด (Unique Name Picker) ผสมผสานไทย จีน เกาหลี สากล
     */
    function pickUniqueMemberName(clanId, memberIndex, usedSet) {
        // จัดหมวดหมู่ตามลำดับเพื่อความหลากหลาย: ไทย 60%, จีน 15%, เกาหลี 15%, สากล 10%
        const categoryPick = memberIndex % 10;
        let pool;
        if (categoryPick <= 5) {
            pool = THAI_ORDINARY_NAMES;
        } else if (categoryPick <= 7) {
            pool = CHINESE_NAMES;
        } else if (categoryPick <= 8) {
            pool = KOREAN_NAMES;
        } else {
            pool = INTERNATIONAL_NAMES;
        }

        // วนหาชื่อที่ยังไม่เคยใช้ในครอบครัวนี้
        for (let i = 0; i < pool.length; i++) {
            const idx = (clanId * 17 + memberIndex * 7 + i) % pool.length;
            const candidate = pool[idx];
            if (!usedSet.has(candidate)) {
                usedSet.add(candidate);
                return candidate;
            }
        }

        // กรณีสุ่มซ้ำจนหมด ให้ประกอบชื่อเฉพาะไม่ซ้ำ
        const fallback = `${pool[(memberIndex) % pool.length]}_${clanId}${memberIndex}`;
        usedSet.add(fallback);
        return fallback;
    }

    /**
     * ดึงรูปโปรไฟล์แบบบ้านๆ/ต้นไม้/สัตว์เลี้ยง/ธรรมชาติ ไม่ซ้ำกันในครอบครัว
     */
    function pickMemberAvatar(clanId, memberIndex) {
        if (window.REALISTIC_AVATARS && window.REALISTIC_AVATARS.length > 0) {
            const avatarList = window.REALISTIC_AVATARS;
            // กระจาย Index ให้ทั่วทั้ง 68 รูปที่มีทั้งต้นไม้ คนบ้านๆ สัตว์เลี้ยง กาแฟ
            const idx = (clanId * 19 + memberIndex * 3) % avatarList.length;
            return avatarList[idx].url;
        }
        return 'avatars/bots/tree_forest.jpg';
    }

    /**
     * สร้างข้อมูล 25 ครอบครัวพร้อมสมาชิกครอบครัวละ 20-30 คน
     * กำหนดสถานะออนไลน์ 0 - 15 คนต่อครอบครัวตามที่ผู้ใช้กำหนด
     * และตั้งเวลาจับสถานะเกมเกิน 10 นาทีเพื่อเปลี่ยนสถานะอัตโนมัติ
     */
    function generateAllFamiliesData() {
        if (cachedFamilies) return cachedFamilies;

        let globalMemberId = 1000;
        const now = Date.now();

        cachedFamilies = PREDEFINED_CLAN_FAMILIES.map(clan => {
            const count = clan.targetCount || Math.floor(Math.random() * 6) + 24; // 24-29 คน
            const members = [];
            const usedNamesInClan = new Set();
            usedNamesInClan.add(clan.leader);

            // ผู้ใช้กำหนด: ให้แสดงสถานะออนไลน์สัก 0-15 คนต่อครอบครัว
            const onlineCount = Math.min(count, Math.floor(Math.random() * 14) + 2); // 2 ถึง 15 คน
            // กำหนดคนกำลังแข่งขันในเกม (ไม่เกินจำนวนคนออนไลน์)
            const playingCount = Math.min(onlineCount, Math.floor(Math.random() * Math.min(onlineCount, 8)) + 1);

            // 1. Leader (หัวหน้าบ้าน)
            const leaderAvatar = pickMemberAvatar(clan.id, 0);
            const isLeaderPlaying = (playingCount > 0);
            const leaderMatchStart = now - Math.floor(Math.random() * 8 * 60 * 1000); // เล่นมาแล้ว 0-8 นาที

            members.push({
                id: globalMemberId++,
                username: clan.leader,
                avatar_url: leaderAvatar,
                picture: leaderAvatar,
                clan_role: 'leader',
                role_label: '👑 หัวหน้าบ้าน',
                level: Math.floor(Math.random() * 8) + 22, // Lv. 22-30
                status: {
                    type: isLeaderPlaying ? 'playing' : 'house',
                    label: isLeaderPlaying ? PLAYING_STATUSES[clan.id % PLAYING_STATUSES.length] : '🟢 นั่งพักผ่อนในบ้าน 3D',
                    isPlaying: isLeaderPlaying,
                    isOnline: true
                },
                status_started_at: leaderMatchStart,
                is_online: true,
                is_leader: true,
                gold: Math.floor(Math.random() * 15000000) + 10000000,
                diamond: Math.floor(Math.random() * 3000) + 2000
            });

            // 2. สมาชิกคนอื่นๆ ทั้งหมด (รองหัวหน้า, สมาชิกอาวุโส, สมาชิกทั่วไป)
            for (let i = 1; i < count; i++) {
                const uniqueName = pickUniqueMemberName(clan.id, i, usedNamesInClan);
                const avatar = pickMemberAvatar(clan.id, i);

                let role = 'member';
                let roleLabel = '👤 สมาชิก';
                let level = Math.floor(Math.random() * 14) + 2;

                if (i === 1 || i === 2) {
                    role = 'co_leader';
                    roleLabel = '🥈 รองหัวหน้า';
                    level = Math.floor(Math.random() * 7) + 18;
                } else if (i === 3 || i === 4) {
                    role = 'elder';
                    roleLabel = '🥉 สมาชิกอาวุโส';
                    level = Math.floor(Math.random() * 6) + 14;
                }

                // ควบคุมให้ออนไลน์รวมกันเท่ากับ onlineCount (0 - 15 คนเท่านั้น)
                const isOnline = (i < onlineCount);
                let statusObj;
                let statusStartedAt = now;

                if (isOnline) {
                    if (i < playingCount) {
                        // กำลังแข่งขันในเกม (ตั้งเวลาเริ่มเล่นเพื่อหมุนเวียนเมื่อเกิน 10 นาที)
                        const playedMinutesAgo = Math.floor(Math.random() * 9); // เล่นมาแล้ว 0-9 นาที
                        statusStartedAt = now - (playedMinutesAgo * 60 * 1000);
                        const label = PLAYING_STATUSES[(clan.id + i) % PLAYING_STATUSES.length];
                        statusObj = { type: 'playing', label, isPlaying: true, isOnline: true };
                    } else {
                        // ออนไลน์ในบ้านหรือล็อบบี้
                        const label = ONLINE_HOUSE_STATUSES[(clan.id + i) % ONLINE_HOUSE_STATUSES.length];
                        statusObj = { type: 'house', label, isPlaying: false, isOnline: true };
                    }
                } else {
                    // ออฟไลน์
                    const label = OFFLINE_STATUSES[(clan.id + i) % OFFLINE_STATUSES.length];
                    statusObj = { type: 'offline', label, isPlaying: false, isOnline: false };
                }

                members.push({
                    id: globalMemberId++,
                    username: uniqueName,
                    avatar_url: avatar,
                    picture: avatar,
                    clan_role: role,
                    role_label: roleLabel,
                    level: level,
                    status: statusObj,
                    status_started_at: statusStartedAt,
                    is_online: isOnline,
                    is_leader: false,
                    gold: Math.floor(Math.random() * 6000000) + 100000,
                    diamond: Math.floor(Math.random() * 800) + 50
                });
            }

            const actualOnline = members.filter(m => m.is_online).length;
            const actualPlaying = members.filter(m => m.status && m.status.isPlaying).length;

            return {
                ...clan,
                is_bot: true,
                members_count: members.length,
                online_count: actualOnline,
                playing_count: actualPlaying,
                members: members
            };
        });

        return cachedFamilies;
    }

    /**
     * ระบบหมุนเวียนสถานะเล่นเกมอัตโนมัติ (หากเกิน 10 นาที เปลี่ยนสถานะไปเรื่อยๆ)
     * ตามเงื่อนไขการแข่งในเกมที่จำกัดเวลาไม่เกิน 10 นาที
     */
    window.rotateClanLiveStatuses = function() {
        if (!cachedFamilies) return;
        const now = Date.now();
        const TEN_MINUTES_MS = 10 * 60 * 1000;
        let hasChanges = false;

        cachedFamilies.forEach(clan => {
            clan.members.forEach(m => {
                if (!m.is_online) return;

                const elapsed = now - (m.status_started_at || 0);

                if (m.status && m.status.isPlaying) {
                    // หากเล่นเกมเกิน 10 นาที ให้จบเกมและเปลี่ยนสถานะ
                    if (elapsed >= TEN_MINUTES_MS) {
                        hasChanges = true;
                        m.status_started_at = now;
                        // จบเกม -> มานั่งพักผ่อนในบ้าน หรือ ออนไลน์ในล็อบบี้
                        const postGameOptions = [
                            '🟢 เพิ่งชนะที่ 1 ในห้อง 5M 🏆',
                            '🟢 จบเกมแล้ว นั่งพักผ่อนในบ้าน 3D',
                            '🟢 ทอยติดอันดับ 2 รับเหรียญรางวัล',
                            '🟢 ออนไลน์หน้าเลือกกระดาน'
                        ];
                        const newLabel = postGameOptions[Math.floor(Math.random() * postGameOptions.length)];
                        m.status = {
                            type: 'house',
                            label: newLabel,
                            isPlaying: false,
                            isOnline: true
                        };
                    }
                } else if (m.status && (m.status.type === 'house' || m.status.type === 'lobby')) {
                    // คนที่พักผ่อนหรืออยู่ล็อบบี้ หากผ่านไปสักพัก สุ่มเริ่มเกมใหม่
                    if (elapsed >= (4 * 60 * 1000) && Math.random() < 0.40) {
                        hasChanges = true;
                        m.status_started_at = now;
                        const newPlayLabel = PLAYING_STATUSES[Math.floor(Math.random() * PLAYING_STATUSES.length)];
                        m.status = {
                            type: 'playing',
                            label: newPlayLabel,
                            isPlaying: true,
                            isOnline: true
                        };
                    }
                }
            });

            // อัปเดตยอดรวมสถานะของครอบครัว
            clan.online_count = clan.members.filter(m => m.is_online).length;
            clan.playing_count = clan.members.filter(m => m.status && m.status.isPlaying).length;
        });

        // หากหน้าต่างตรวจสอบสมาชิกกำลังเปิดอยู่ ให้รีเฟรชหน้าจอแบบเรียลไทม์
        const inspectModal = document.getElementById('modal-inspect-clan-roster');
        if (hasChanges && inspectModal && inspectModal.style.display !== 'none' && window.currentInspectedClanId) {
            window.inspectClanFamilyMembers(window.currentInspectedClanId, true);
        }
    };

    // หมุนเวียนตรวจสอบสถานะเกมทุกๆ 45 วินาที
    setInterval(() => {
        try {
            window.rotateClanLiveStatuses();
        } catch(e) {}
    }, 45000);

    window.getAllClanFamilies = generateAllFamiliesData;

    /**
     * ดึงข้อมูลครอบครัวเฉพาะตาม ID
     */
    window.getClanFamilyById = function(clanId) {
        const all = generateAllFamiliesData();
        return all.find(c => c.id === Number(clanId)) || all[0];
    };

    /**
     * แจ้งเตือนเมื่อพยายามสมัครหรือคลิกบ้านระบบ AI / บอท
     */
    window.showBotClanClosedAlert = function(clanName) {
        const title = 'ปิดรับสมัครสมาชิกบ้าน';
        const msg = `⛔ ขออภัย ครอบครัว '${clanName || 'นี้'}' เป็นบ้านระบบ (AI/บอท) ปิดรับสมัครสมาชิกบ้าน\n\n📌 ผู้เล่นใหม่ไม่สามารถเข้าร่วมบ้านบอทได้\n✨ สามารถเข้าร่วมได้เฉพาะบ้านที่ไม่ใช่บอท (บ้านผู้เล่นจริง) ที่ขึ้นสถานะ [🟢 บ้านว่าง เข้าได้] เท่านั้น หรือกดสร้างบ้านใหม่ของคุณเองได้เลย!`;
        if (typeof showInGameAlert === 'function') {
            showInGameAlert(msg, title, '⛔');
        } else if (typeof showToast === 'function') {
            showToast(`⛔ ครอบครัว '${clanName || ''}' ปิดรับสมัครสมาชิกบ้าน (บ้านระบบ AI)`, 'warning');
        } else {
            alert(msg);
        }
    };

    /**
     * เรนเดอร์แท็บ "ครอบครัวทั้งหมด (25 ครอบครัว)" ใน Modal Clan
     */
    window.renderAllClanFamiliesTab = function() {
        const container = document.getElementById('clan-all-families-list');
        if (!container) return;

        const families = generateAllFamiliesData();
        const totalMembers = families.reduce((acc, f) => acc + f.members_count, 0);
        const totalPlaying = families.reduce((acc, f) => acc + f.playing_count, 0);
        const totalOnline = families.reduce((acc, f) => acc + f.online_count, 0);

        // Header statistics
        const statsEl = document.getElementById('clan-all-families-stats');
        if (statsEl) {
            statsEl.innerHTML = `
                <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap; font-size:12px; color:#cbd5e1;">
                    <span>🏰 ครอบครัวทั้งหมด: <strong style="color:#00e5ff;">25 ครอบครัว</strong></span>
                    <span>👥 สมาชิกรวม: <strong style="color:#34d399;">${totalMembers} คน</strong></span>
                    <span>🟢 กำลังแข่งขัน: <strong style="color:#ffd700;">${totalPlaying} คน</strong></span>
                    <span>🟢 ออนไลน์สด: <strong style="color:#38bdf8;">${totalOnline} คน</strong></span>
                </div>
            `;
        }

        container.innerHTML = '';
        families.forEach((fam, idx) => {
            const card = document.createElement('div');
            card.className = 'clan-family-card';
            card.style.cssText = `
                background: radial-gradient(circle at top left, rgba(30, 41, 59, 0.85), rgba(15, 23, 42, 0.95));
                border: 1.5px solid rgba(129, 140, 248, 0.35);
                border-radius: 10px;
                padding: 8px 10px;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                gap: 6px;
                box-shadow: 0 4px 14px rgba(0,0,0,0.45);
                transition: all 0.25s ease;
            `;

            // ผู้ใช้กำหนด: เอาแถบรูปวงกลมสมาชิกและปุ่มดูสมาชิกออก
            // ให้แสดงสถานะการรับสมัครแทน: บอทให้แสดงว่า "ปิดรับสมัครสมาชิกบ้าน" คนใหม่เข้าร่วมไม่ได้
            // หากเป็นบ้านผู้เล่นจริง ให้แสดงว่า "บ้านว่าง เข้าได้" พร้อมปุ่มสมัครเข้าร่วม
            const isBot = fam.is_bot !== false;
            const bottomActionHtml = isBot
                ? `<div style="display: flex; align-items: center; justify-content: space-between; margin-top: 4px; padding-top: 4px; border-top: 1px solid rgba(255,255,255,0.06);">
                    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 10px; font-weight: 700; color: #ef4444; background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); padding: 3px 8px; border-radius: 6px;">
                        ⛔ ปิดรับสมัคร
                    </span>
                    <button type="button" class="btn" onclick="showBotClanClosedAlert('${fam.name}')"
                        style="padding: 3px 10px; font-size: 10px; background: rgba(239,68,68,0.18); border: 1px solid #ef4444; color: #fca5a5; font-weight: 800; border-radius: 6px; cursor: not-allowed; transition: all 0.2s ease;" title="ครอบครัวนี้เป็นบ้านระบบ (AI/บอท) ปิดรับสมัครสมาชิกบ้าน">
                        🔒 ปิดรับ
                    </button>
                </div>`
                : `<div style="display: flex; align-items: center; justify-content: space-between; margin-top: 4px; padding-top: 4px; border-top: 1px solid rgba(255,255,255,0.06);">
                    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 10px; font-weight: 700; color: #34d399; background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.4); padding: 3px 8px; border-radius: 6px;">
                        🟢 บ้านว่าง
                    </span>
                    <button type="button" class="btn btn-primary" onclick="joinClanAction(${fam.id}, '${fam.name}')"
                        style="padding: 3px 12px; font-size: 10.5px; background: linear-gradient(135deg, #10b981, #059669); color: #fff; font-weight: 800; border-radius: 6px; cursor: pointer; border: none; box-shadow: 0 0 10px rgba(16,185,129,0.35);">
                        ✨ สมัคร
                    </button>
                </div>`;

            card.innerHTML = `
                <div>
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="font-size: 16px;">🏰</span>
                            <strong style="color: #fff; font-size: 13px;">${fam.name}</strong>
                            <span class="badge" style="background: #6366f1; color: #fff; font-size: 9.5px; padding: 1px 4px;">[${fam.tag}]</span>
                        </div>
                        <span style="color: #ffd700; font-weight: 800; font-size: 10.5px;">Lv.${fam.level} ⭐</span>
                    </div>

                    <p style="font-size: 10px; color: #94a3b8; margin: 0 0 5px 0; line-height: 1.25; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${fam.slogan}</p>

                    <div style="display: flex; align-items: center; justify-content: space-between; font-size: 9.5px; color: #cbd5e1; background: rgba(0,0,0,0.25); padding: 4px 6px; border-radius: 6px;">
                        <div>👑 <strong style="color: #ffd700;">${fam.leader}</strong></div>
                        <div>👥 <strong style="color: #34d399;">${fam.members_count}/30</strong></div>
                        <div>🟢 <strong style="color: #00e5ff;">${fam.playing_count} เล่น</strong></div>
                    </div>
                </div>

                ${bottomActionHtml}
            `;
            container.appendChild(card);
        });
    };

    /**
     * ค้นหาครอบครัวตามชื่อหรือแท็ก
     */
    window.filterAllFamiliesDirectory = function(keyword = '') {
        const q = String(keyword || '').trim().toLowerCase();
        const container = document.getElementById('clan-all-families-grid');
        if (!container) return;
        const cards = container.querySelectorAll('.clan-family-card');
        cards.forEach(card => {
            const text = (card.textContent || '').toLowerCase();
            card.style.display = (!q || text.includes(q)) ? 'flex' : 'none';
        });
    };

    /**
     * เปิดหน้าต่างตรวจสอบสมาชิกในครอบครัว (Family Members Inspector)
     * แสดงว่ามีใครบ้าง และใครกำลังเล่นเกมอยู่บ้าง
     */
    window.inspectClanFamilyMembers = function(clanId, isAutoRefresh = false) {
        window.currentInspectedClanId = clanId;
        const fam = window.getClanFamilyById(clanId);
        if (!fam) return;

        const modal = document.getElementById('modal-inspect-clan-roster');
        if (!modal) return;

        const nameEl = document.getElementById('inspect-clan-name') || document.getElementById('inspect-clan-title');
        const tagEl = document.getElementById('inspect-clan-tag');
        const metaEl = document.getElementById('inspect-clan-meta');
        const memberCountEl = document.getElementById('inspect-clan-member-count');
        const onlineCountEl = document.getElementById('inspect-clan-online-count');
        const listEl = document.getElementById('inspect-clan-members-grid');

        if (nameEl) nameEl.innerText = fam.name;
        if (tagEl) tagEl.innerText = `[${fam.tag}]`;
        if (metaEl) metaEl.innerText = `เลเวล ${fam.level} ⭐ • หัวหน้า: ${fam.leader} • คะแนนรวม ${fam.score ? fam.score.toLocaleString() : '520,000'} แต้ม • ${fam.slogan}`;
        if (memberCountEl) memberCountEl.innerText = `👥 สมาชิกทั้งหมด (${fam.members_count}/30 คน)`;
        if (onlineCountEl) onlineCountEl.innerText = `กำลังแข่งขัน ${fam.playing_count} คน • ออนไลน์สด ${fam.online_count} คน`;

        if (listEl) {
            listEl.innerHTML = '';
            fam.members.forEach((m, idx) => {
                const card = document.createElement('div');
                card.style.cssText = `
                    background: rgba(15, 23, 42, 0.85);
                    border: 1px solid rgba(255, 255, 255, 0.08);
                    border-radius: 12px;
                    padding: 10px 12px;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.35);
                `;

                const isPlaying = m.status && m.status.isPlaying;
                const statusColor = isPlaying ? '#10b981' : (m.is_online ? '#38bdf8' : '#94a3b8');
                const statusBg = isPlaying ? 'rgba(16, 185, 129, 0.15)' : (m.is_online ? 'rgba(56, 189, 248, 0.12)' : 'rgba(148, 163, 184, 0.15)');

                card.innerHTML = `
                    <div style="position: relative; flex-shrink: 0;">
                        <img src="${m.avatar_url}" 
                             style="width: 46px; height: 46px; border-radius: 50%; object-fit: cover; border: 2px solid ${isPlaying ? '#10b981' : (m.is_online ? '#00e5ff' : '#475569')}; background: #0f172a; box-shadow: 0 0 10px rgba(0,229,255,0.25);"
                             onerror="this.src='avatars/google_avatar.png';">
                        <span style="position: absolute; bottom: 0; right: 0; width: 12px; height: 12px; border-radius: 50%; background: ${m.is_online ? '#10b981' : '#64748b'}; border: 2px solid #0f172a;"></span>
                    </div>

                    <div style="flex: 1; min-width: 0;">
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px;">
                            <strong style="color: #fff; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${m.username}</strong>
                            <span style="font-size: 11px; color: #ffd700; font-weight: 700;">Lv.${m.level} ⭐</span>
                        </div>

                        <div style="display: flex; align-items: center; gap: 6px; margin-top: 4px;">
                            <span class="badge" style="background: rgba(99, 102, 241, 0.2); border: 1px solid rgba(129, 140, 248, 0.4); color: #c084fc; font-size: 10px; padding: 2px 6px; border-radius: 4px; white-space: nowrap;">${m.role_label}</span>
                            <span style="font-size: 10.5px; color: ${statusColor}; background: ${statusBg}; padding: 2px 6px; border-radius: 6px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                ${m.status ? m.status.label : (m.is_online ? '🟢 ออนไลน์' : '⚪ ออฟไลน์')}
                            </span>
                        </div>
                    </div>
                `;
                listEl.appendChild(card);
            });
        }

        modal.style.display = 'flex';
    };

    /**
     * ระบบสุ่มให้ตัวละครในห้อง 3D ส่งแชทและอิโมจิคุยกันเองอย่างมีชีวิตชีวา
     */
    let livelyRoomChatTimer = null;
    let livelyRoomWalkTimer = null;

    window.startLivelyRoomAutomation = function(clanHouseInstance) {
        if (!clanHouseInstance) return;

        if (livelyRoomChatTimer) clearInterval(livelyRoomChatTimer);
        if (livelyRoomWalkTimer) clearInterval(livelyRoomWalkTimer);

        // 1. ส่งข้อความและอิโมจิคึกคักทุกๆ 4 - 7 วินาที
        livelyRoomChatTimer = setInterval(() => {
            if (!clanHouseInstance.otherPawns || clanHouseInstance.otherPawns.length === 0) return;
            const overlay = document.getElementById('clan-room-chat-overlay');
            if (!overlay || overlay.offsetParent === null) return; // ทำงานเฉพาะตอนเปิดหน้าห้อง 3D

            const randomPawn = clanHouseInstance.otherPawns[Math.floor(Math.random() * clanHouseInstance.otherPawns.length)];
            if (!randomPawn || !randomPawn.userData) return;

            const speakerName = randomPawn.userData.displayName || 'สมาชิกในบ้าน';
            const speakerAvatar = randomPawn.userData.avatarUrl || 'avatars/google_avatar.png';

            // สลับส่งข้อความ หรือ อิโมจิ
            const isEmoji = Math.random() < 0.45;
            const message = isEmoji 
                ? BOT_EMOJI_POOL[Math.floor(Math.random() * BOT_EMOJI_POOL.length)]
                : BOT_CHAT_MESSAGES[Math.floor(Math.random() * BOT_CHAT_MESSAGES.length)];

            // แสดงบอลลูนข้อความบนหัวตัวละคร 3D
            if (typeof clanHouseInstance.showSpeechBubbleOnPawn === 'function') {
                clanHouseInstance.showSpeechBubbleOnPawn(randomPawn, message, 3800);
            }

            // เพิ่มเข้ากล่องแชทด้านขวา
            appendLivelyChatToFeed(speakerName, speakerAvatar, message, isEmoji);

        }, 5500);

        // 2. สั่งให้สมาชิก 5 คนเดินเปลี่ยนจุดไปมารอบห้องอย่างเป็นธรรมชาติ
        livelyRoomWalkTimer = setInterval(() => {
            if (!clanHouseInstance.otherPawns || clanHouseInstance.otherPawns.length === 0) return;
            const walkingPawns = clanHouseInstance.otherPawns.filter(p => p.userData && p.userData.isWalker);
            walkingPawns.forEach(pawn => {
                if (Math.random() < 0.65) {
                    const randomSpot = clanHouseInstance.getRandomWalkableSpot ? clanHouseInstance.getRandomWalkableSpot() : null;
                    if (randomSpot && typeof clanHouseInstance.startPawnWalk === 'function') {
                        clanHouseInstance.startPawnWalk(pawn, randomSpot.x, randomSpot.z);
                    }
                }
            });
        }, 6000);
    };

    window.stopLivelyRoomAutomation = function() {
        if (livelyRoomChatTimer) { clearInterval(livelyRoomChatTimer); livelyRoomChatTimer = null; }
        if (livelyRoomWalkTimer) { clearInterval(livelyRoomWalkTimer); livelyRoomWalkTimer = null; }
    };

    function appendLivelyChatToFeed(name, avatar, text, isEmoji) {
        const feed = document.getElementById('clan-room-chat-feed');
        if (!feed) return;

        const timeStr = new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
        const item = document.createElement('div');
        item.className = 'clan-chat-msg';
        item.style.cssText = `
            display: flex; gap: 8px; margin-bottom: 8px; align-items: flex-start;
            animation: fadeInMsg 0.3s ease;
        `;

        item.innerHTML = `
            <img src="${avatar}" style="width: 26px; height: 26px; border-radius: 50%; object-fit: cover; border: 1px solid #00e5ff; background: #0f172a;" onerror="this.src='avatars/google_avatar.png';">
            <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; color: #38bdf8; font-weight: 700;">
                    <span>${name}</span>
                    <span style="color: #64748b; font-weight: normal; font-size: 9.5px;">${timeStr}</span>
                </div>
                <div style="font-size: ${isEmoji ? '20px' : '11.5px'}; color: #fff; margin-top: 2px; word-break: break-word;">
                    ${text}
                </div>
            </div>
        `;

        feed.appendChild(item);
        feed.scrollTop = feed.scrollHeight;
    }

})();
