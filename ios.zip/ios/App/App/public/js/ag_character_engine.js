/**
 * ag_character_engine.js - Antigravity 3D Character & Space Runtime Engine
 * -----------------------------------------------------------------------
 * ระบบแปลงและสร้างโมเดลตัวละคร 3D สำหรับ Antigravity (ag.space.createCharacter)
 * พร้อมระบบเล่นแอนิเมชันตอนปล่อยสกิลเนื้อเรื่องละคร (ag.ui.showDialogue)
 * และเอฟเฟกต์วงแหวนแสงเรืองรอง (Pink Emission Glow) ที่ใบดาบ
 *
 * รองรับการแสดงผล 3 แบบ:
 * 1. ภาพแสดง (2D Card Showcase / Holographic Cut-In)
 * 2. ตอนปกติ (3D Idle Stance / Hovering Sword with subtle glow on Board)
 * 3. ตอนทอยเต๋า (3D Skill Action: Dash, Sword Slash, Pink Emission Glow Flare, Dialogue & 3D Dice Roll)
 */

(function () {
    'use strict';

    window.ag = window.ag || {};
    window.ag.space = window.ag.space || {};
    window.ag.ui = window.ag.ui || {};

    // -----------------------------------------------------------------
    // Audio Synthesizer for Dialogue & Blade Slash (No external files needed)
    // -----------------------------------------------------------------
    function playSfx(type = 'dialogue') {
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            const ctx = window._agAudioCtx || (window._agAudioCtx = new AudioCtx());
            if (ctx.state === 'suspended') {
                ctx.resume().catch(() => {});
            }

            const now = ctx.currentTime;
            if (type === 'dialogue') {
                // Gentle magic chime
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(587.33, now); // D5
                osc.frequency.exponentialRampToValueAtTime(880, now + 0.18); // A5
                gain.gain.setValueAtTime(0.14, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now);
                osc.stop(now + 0.35);
            } else if (type === 'slash') {
                // Whoosh + high energy blade slash
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(750, now);
                osc.frequency.exponentialRampToValueAtTime(220, now + 0.25);
                gain.gain.setValueAtTime(0.2, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now);
                osc.stop(now + 0.3);
            } else if (type === 'dice') {
                // Dice tumble click
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(320, now);
                osc.frequency.exponentialRampToValueAtTime(140, now + 0.12);
                gain.gain.setValueAtTime(0.25, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now);
                osc.stop(now + 0.14);
            }
        } catch (e) {
            // Audio policy ignore
        }
    }

    // -----------------------------------------------------------------
    // 1. ag.ui.showDialogue (กล่องบทสนทนาเนื้อเรื่องละคร / สกิลตัวละคร)
    // -----------------------------------------------------------------
    let _activeDialogueTimer = null;
    let _activeDialogueElem = null;

    ag.ui.showDialogue = function (options = {}) {
        const speaker = options.speaker || '✨ ตัวละคร';
        const text = options.text || 'ดาบแห่งโชคชะตาจงเบิกทาง! ทอยเต๋าติดดับเบิ้ล 100%!';
        const avatar = options.avatar || options.avatarUrl || 'avatars/avatar_01.png';
        const duration = options.duration || 3800;
        const theme = options.theme || 'pink_anime'; // pink_anime, gold_legend, cyber_blue

        playSfx('dialogue');

        // Remove old dialogue if present
        if (_activeDialogueElem) {
            try { _activeDialogueElem.remove(); } catch (e) {}
            _activeDialogueElem = null;
        }
        if (_activeDialogueTimer) {
            clearTimeout(_activeDialogueTimer);
            _activeDialogueTimer = null;
        }

        const container = document.createElement('div');
        container.className = 'ag-story-dialogue-container';
        container.style.cssText = `
            position: fixed;
            bottom: clamp(48px, 9vh, 60px);
            left: 50%;
            transform: translateX(-50%) translateY(15px);
            z-index: 999999;
            width: fit-content;
            max-width: min(88vw, 380px);
            min-width: 240px;
            background: linear-gradient(135deg, rgba(15, 12, 35, 0.94), rgba(24, 15, 45, 0.96));
            border: 1.5px solid #ff2a85;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.75), 0 0 16px rgba(255, 42, 133, 0.4);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 5px 10px;
            color: #ffffff;
            font-family: 'Kanit', sans-serif;
            opacity: 0;
            transition: opacity 0.25s ease, transform 0.25s cubic-bezier(0.18, 0.89, 0.32, 1.28);
            pointer-events: auto;
            cursor: pointer;
            overflow: hidden;
            box-sizing: border-box;
        `;

        // Glowing border accents
        const glowLine = document.createElement('div');
        glowLine.style.cssText = `
            position: absolute;
            top: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, #ff2a85, #ffd700, #ff2a85);
            box-shadow: 0 0 8px #ff2a85;
        `;
        container.appendChild(glowLine);

        // Avatar column
        const avatarWrapper = document.createElement('div');
        avatarWrapper.style.cssText = `
            position: relative;
            flex-shrink: 0;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 2px solid #ff2a85;
            box-shadow: 0 0 10px rgba(255, 42, 133, 0.6);
            background: #110d24;
            overflow: hidden;
        `;
        const avatarImg = document.createElement('img');
        avatarImg.src = avatar;
        avatarImg.alt = speaker;
        avatarImg.style.cssText = `width: 100%; height: 100%; object-fit: cover;`;
        avatarWrapper.appendChild(avatarImg);
        container.appendChild(avatarWrapper);

        // Content column
        const contentCol = document.createElement('div');
        contentCol.style.cssText = `flex: 1; min-width: 0;`;

        // Speaker title badge
        const speakerBadge = document.createElement('div');
        speakerBadge.style.cssText = `
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 11px;
            font-weight: 800;
            color: #ffd700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            background: rgba(255, 215, 0, 0.12);
            border: 1px solid rgba(255, 215, 0, 0.35);
            padding: 1px 7px;
            border-radius: 12px;
            margin-bottom: 2px;
            box-shadow: 0 0 6px rgba(255, 215, 0, 0.2);
            line-height: 1.2;
        `;
        speakerBadge.innerHTML = `<span>⚔️</span> ${speaker} <span style="color:#ff2a85; font-size:9.5px; font-weight:700;">[ปล่อยสกิล]</span>`;
        contentCol.appendChild(speakerBadge);

        // Dialogue text with typewriter effect
        const textElem = document.createElement('div');
        textElem.style.cssText = `
            font-size: 11.5px;
            line-height: 1.3;
            color: #ffffff;
            text-shadow: 0 1px 4px rgba(0,0,0,0.8), 0 0 8px rgba(255, 42, 133, 0.3);
            font-weight: 500;
            min-height: 15px;
            word-break: break-word;
        `;
        contentCol.appendChild(textElem);
        container.appendChild(contentCol);

        // Close / Dismiss button
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '&times;';
        closeBtn.title = 'ปิด';
        closeBtn.style.cssText = `
            background: none;
            border: none;
            color: rgba(255,255,255,0.6);
            font-size: 16px;
            cursor: pointer;
            padding: 0 2px;
            line-height: 1;
            align-self: flex-start;
            margin-left: 2px;
        `;
        const dismissDialogue = (e) => {
            if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
            container.style.opacity = '0';
            container.style.transform = 'translateX(-50%) translateY(15px)';
            setTimeout(() => { try { container.remove(); } catch (err) {} }, 280);
        };
        closeBtn.onclick = dismissDialogue;
        container.onclick = dismissDialogue;
        container.appendChild(closeBtn);

        document.body.appendChild(container);
        _activeDialogueElem = container;

        // Smooth in
        requestAnimationFrame(() => {
            container.style.opacity = '1';
            container.style.transform = 'translateX(-50%) translateY(0)';
        });

        // Typewriter animation
        let charIndex = 0;
        const speed = Math.max(12, Math.floor(900 / Math.max(1, text.length)));
        const typeInterval = setInterval(() => {
            if (charIndex <= text.length) {
                textElem.textContent = text.slice(0, charIndex);
                charIndex++;
            } else {
                clearInterval(typeInterval);
            }
        }, speed);

        // Auto dismiss
        _activeDialogueTimer = setTimeout(() => {
            clearInterval(typeInterval);
            container.style.opacity = '0';
            container.style.transform = 'translateX(-50%) translateY(20px)';
            setTimeout(() => {
                try { container.remove(); } catch (e) {}
                if (_activeDialogueElem === container) _activeDialogueElem = null;
            }, 300);
        }, duration);

        return container;
    };

    // -----------------------------------------------------------------
    // 2. Texture Generator: Avatar Circle on 3D Disc
    // -----------------------------------------------------------------
    function createAvatarDiscTexture(imageUrl, rimColor = 0xff2a85, name = '', grade = 'SS+') {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');

        // Background circle
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(256, 256, 245, 0, Math.PI * 2);
        ctx.fill();

        // Outer glow rim
        ctx.strokeStyle = typeof rimColor === 'string' ? rimColor : '#' + Number(rimColor).toString(16).padStart(6, '0');
        ctx.lineWidth = 16;
        ctx.shadowColor = ctx.strokeStyle;
        ctx.shadowBlur = 24;
        ctx.stroke();

        // Image loader
        const texture = new THREE.CanvasTexture(canvas);
        texture.needsUpdate = true;

        if (imageUrl) {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                ctx.save();
                ctx.beginPath();
                ctx.arc(256, 256, 225, 0, Math.PI * 2);
                ctx.clip();
                ctx.drawImage(img, 31, 31, 450, 450);
                ctx.restore();

                // Grade badge
                ctx.shadowBlur = 10;
                ctx.fillStyle = '#ff2a85';
                ctx.beginPath();
                ctx.roundRect(176, 420, 160, 48, 12);
                ctx.fill();
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 28px Kanit, sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(grade, 256, 444);

                texture.needsUpdate = true;
            };
            img.onerror = () => {
                // Fallback default avatar art
                ctx.fillStyle = '#38bdf8';
                ctx.font = 'bold 120px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('⚔️', 256, 240);
                texture.needsUpdate = true;
            };
            img.src = imageUrl;
        }

        return texture;
    }

    // -----------------------------------------------------------------
    // 3. Texture Generator: Magic Ground Runic Aura Ring
    // -----------------------------------------------------------------
    function createGroundRunicRingTexture(colorHex = '#ff2a85') {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');

        const cx = 256;
        const cy = 256;

        // Concentric glow rings
        ctx.strokeStyle = colorHex;
        ctx.lineWidth = 6;
        ctx.shadowColor = colorHex;
        ctx.shadowBlur = 16;

        ctx.beginPath();
        ctx.arc(cx, cy, 230, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(cx, cy, 185, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, 130, 0, Math.PI * 2);
        ctx.stroke();

        // 8 Runic rays
        for (let i = 0; i < 8; i++) {
            const rad = (i * Math.PI) / 4;
            const x1 = cx + Math.cos(rad) * 135;
            const y1 = cy + Math.sin(rad) * 135;
            const x2 = cx + Math.cos(rad) * 225;
            const y2 = cy + Math.sin(rad) * 225;
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
        }

        // Star runes inside
        ctx.fillStyle = colorHex;
        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const runes = ['✦', '◆', '★', '❖', '✦', '◆', '★', '❖'];
        for (let i = 0; i < 8; i++) {
            const rad = (i * Math.PI) / 4 + Math.PI / 8;
            const rx = cx + Math.cos(rad) * 208;
            const ry = cy + Math.sin(rad) * 208;
            ctx.fillText(runes[i], rx, ry);
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.needsUpdate = true;
        return tex;
    }

    // -----------------------------------------------------------------
    // 3.5. ag.space.load3DModel (Universal 3D Model Loader: GLB, GLTF, FBX, OBJ, BLEND)
    // -----------------------------------------------------------------
    ag.space.load3DModel = function (source, options = {}) {
        return new Promise((resolve, reject) => {
            if (!window.THREE) {
                return reject(new Error('Three.js is not loaded'));
            }

            const targetHeight = options.targetHeight || 2.2;
            const centerBottom = options.centerBottom !== false;
            let format = (options.format || '').toLowerCase();

            let url = source;
            if (typeof source === 'object' && (source instanceof File || source instanceof Blob)) {
                if (source.name) {
                    format = format || (source.name.split('.').pop() || '').toLowerCase();
                }
                url = URL.createObjectURL(source);
            } else if (typeof source === 'string') {
                if (!format) {
                    const clean = source.split('?')[0].split('#')[0];
                    format = (clean.split('.').pop() || '').toLowerCase();
                }
            }

            function normalizeModel(modelGroup) {
                const box = new THREE.Box3().setFromObject(modelGroup);
                const size = box.getSize(new THREE.Vector3());
                const center = box.getCenter(new THREE.Vector3());

                // Center in X and Z
                modelGroup.position.x -= center.x;
                modelGroup.position.z -= center.z;

                // Ground align Y
                if (centerBottom) {
                    modelGroup.position.y -= box.min.y;
                } else {
                    modelGroup.position.y -= center.y;
                }

                // Auto scale
                const maxDim = Math.max(size.y, Math.max(size.x, size.z));
                if (maxDim > 0.0001) {
                    const scale = targetHeight / (size.y > 0.05 ? size.y : maxDim);
                    modelGroup.scale.multiplyScalar(scale);
                }

                modelGroup.traverse(child => {
                    if (child.isMesh) {
                        child.castShadow = true;
                        child.receiveShadow = true;
                        if (child.material) {
                            if (Array.isArray(child.material)) {
                                child.material.forEach(m => {
                                    m.side = THREE.DoubleSide;
                                    m.needsUpdate = true;
                                });
                            } else {
                                child.material.side = THREE.DoubleSide;
                                child.material.needsUpdate = true;
                            }
                        }
                    }
                });

                return { group: modelGroup, bbox: box, size: size };
            }

            // A. Blender (.blend) Project Node
            if (format === 'blend') {
                const blendGroup = new THREE.Group();
                blendGroup.name = 'BlenderProject3DNode';

                // Stylized Blender icon cube with orange & blue
                const bMat = new THREE.MeshStandardMaterial({
                    color: 0xEA7600, // Blender iconic orange
                    emissive: 0x225B8D, // Blender iconic blue
                    emissiveIntensity: 0.35,
                    metalness: 0.8,
                    roughness: 0.2
                });
                const bMesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 1.2), bMat);
                bMesh.position.y = 0.6;
                blendGroup.add(bMesh);

                // Wireframe glowing cage around blender cube
                const wireGeo = new THREE.WireframeGeometry(new THREE.BoxGeometry(1.3, 1.3, 1.3));
                const wireMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 });
                const wireLine = new THREE.LineSegments(wireGeo, wireMat);
                wireLine.position.y = 0.6;
                blendGroup.add(wireLine);

                // Floating "BLENDER .BLEND" 3D badge disc
                const badgeCanvas = document.createElement('canvas');
                badgeCanvas.width = 256; badgeCanvas.height = 128;
                const bCtx = badgeCanvas.getContext('2d');
                bCtx.fillStyle = '#ea7600';
                bCtx.fillRect(0, 0, 256, 128);
                bCtx.fillStyle = '#ffffff';
                bCtx.font = 'bold 30px Kanit, sans-serif';
                bCtx.textAlign = 'center';
                bCtx.fillText('BLENDER 3D', 128, 55);
                bCtx.font = '22px Kanit, sans-serif';
                bCtx.fillText('.BLEND PROJECT', 128, 95);
                const badgeTex = new THREE.CanvasTexture(badgeCanvas);
                const badgeMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: badgeTex, side: THREE.DoubleSide }));
                badgeMesh.position.set(0, 1.6, 0);
                blendGroup.add(badgeMesh);

                normalizeModel(blendGroup);
                return resolve({
                    group: blendGroup,
                    format: 'blend',
                    animations: [],
                    mixer: null,
                    isBlend: true
                });
            }

            // B. GLTF / GLB Loader
            if (format === 'glb' || format === 'gltf') {
                if (!THREE.GLTFLoader) {
                    return reject(new Error('THREE.GLTFLoader is not available. Please load GLTFLoader.js.'));
                }
                const loader = new THREE.GLTFLoader();
                loader.load(url, gltf => {
                    const scene = gltf.scene || gltf.scenes[0];
                    const wrapper = new THREE.Group();
                    wrapper.name = 'GLTFModelRoot';
                    wrapper.add(scene);

                    normalizeModel(wrapper);

                    let mixer = null;
                    if (gltf.animations && gltf.animations.length > 0) {
                        mixer = new THREE.AnimationMixer(scene);
                        const action = mixer.clipAction(gltf.animations[0]);
                        action.play();
                    }

                    resolve({
                        group: wrapper,
                        rawScene: scene,
                        format: format,
                        animations: gltf.animations || [],
                        mixer: mixer,
                        isBlend: false
                    });
                }, undefined, err => {
                    reject(new Error(`Failed to load ${format.toUpperCase()} model: ` + (err.message || err)));
                });
                return;
            }

            // C. OBJ Loader
            if (format === 'obj') {
                if (!THREE.OBJLoader) {
                    return reject(new Error('THREE.OBJLoader is not available. Please load OBJLoader.js.'));
                }
                const loader = new THREE.OBJLoader();
                loader.load(url, obj => {
                    const wrapper = new THREE.Group();
                    wrapper.name = 'OBJModelRoot';
                    wrapper.add(obj);

                    normalizeModel(wrapper);

                    resolve({
                        group: wrapper,
                        rawScene: obj,
                        format: 'obj',
                        animations: [],
                        mixer: null,
                        isBlend: false
                    });
                }, undefined, err => {
                    reject(new Error('Failed to load OBJ model: ' + (err.message || err)));
                });
                return;
            }

            // D. FBX Loader
            if (format === 'fbx') {
                if (!THREE.FBXLoader) {
                    return reject(new Error('THREE.FBXLoader is not available. Please load FBXLoader.js & fflate.'));
                }
                const loader = new THREE.FBXLoader();
                loader.load(url, fbx => {
                    const wrapper = new THREE.Group();
                    wrapper.name = 'FBXModelRoot';
                    wrapper.add(fbx);

                    normalizeModel(wrapper);

                    let mixer = null;
                    if (fbx.animations && fbx.animations.length > 0) {
                        mixer = new THREE.AnimationMixer(fbx);
                        const action = mixer.clipAction(fbx.animations[0]);
                        action.play();
                    }

                    resolve({
                        group: wrapper,
                        rawScene: fbx,
                        format: 'fbx',
                        animations: fbx.animations || [],
                        mixer: mixer,
                        isBlend: false
                    });
                }, undefined, err => {
                    reject(new Error('Failed to load FBX model: ' + (err.message || err)));
                });
                return;
            }

            reject(new Error(`Unsupported 3D model format: ${format}. Supported: GLB, GLTF, FBX, OBJ, BLEND`));
        });
    };

    // -----------------------------------------------------------------
    // 3.6. ag.space.createDice3D (Universal 3D Dice Creator)
    // -----------------------------------------------------------------
    ag.space.createDice3D = function (config = {}) {
        const group = new THREE.Group();
        group.name = 'ag_dice_3d';
        const size = config.size || 0.8;
        const color = config.color || 0x00e5ff;
        const pipColor = config.pipColor || 0xffffff;
        const modelUrl = config.modelUrl || config.model_3d_url || '';
        const modelFormat = config.modelFormat || config.model_format || '';

        if (modelUrl) {
            ag.space.load3DModel(modelUrl, { format: modelFormat, targetHeight: size, centerBottom: false }).then(res => {
                group.add(res.group);
            }).catch(() => {
                buildDefaultCube();
            });
        } else {
            buildDefaultCube();
        }

        function buildDefaultCube() {
            const geo = new THREE.BoxGeometry(size, size, size);
            const mat = new THREE.MeshStandardMaterial({
                color: new THREE.Color(color),
                emissive: new THREE.Color(color),
                emissiveIntensity: 0.25,
                metalness: 0.7,
                roughness: 0.2
            });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.castShadow = true;
            group.add(mesh);
        }

        return group;
    };

    // -----------------------------------------------------------------
    // 4. ag.space.createCharacter (Antigravity 3D Character Creator)
    // -----------------------------------------------------------------
    ag.space.createCharacter = function (config = {}) {
        if (!window.THREE) {
            console.error('ag.space.createCharacter requires Three.js');
            return null;
        }

        const id = config.id || ('char_' + Math.floor(Math.random() * 10000));
        const name = config.name || 'ซากุระ เบลดมาสเตอร์';
        const grade = config.grade || 'SS+';
        const avatarUrl = config.avatarUrl || config.imageUrl || 'avatars/avatar_01.png';
        const colors = config.colors || {};
        const primaryColor = colors.primary || '#ff2a85';
        const secondaryColor = colors.secondary || '#1e1b4b';
        const bladeGlowColor = colors.bladeGlow || '#ff2a85';
        const auraRingColor = colors.auraRing || '#f472b6';

        const weaponConfig = config.weapon || {
            type: 'blade',
            name: 'ดาบประกายชมพูผ่ามิติ',
            glowColor: bladeGlowColor,
            emissionIntensity: 2.8,
            ringEffect: true
        };

        const dialogueConfig = config.dialogue || {
            skillText: '✨ เพลงดาบประกายชมพูผ่ามิติ! ทอยเต๋าติดดับเบิ้ล 100%!',
            speaker: name
        };

        const animConfig = Object.assign({
            idleStyle: 'idle_bounce',
            rollStyle: 'roll_spin_jump',
            jumpHeight: 1.0,
            speed: 1.0,
            headMotion: 'none',
            armMotion: 'none',
            legMotion: 'none',
            eyeBlink: 'none',
            mouthMotion: 'none'
        }, config.animation || {});

        const auraConfig = Object.assign({
            style: 'heavenly_beam',
            color: colors.auraRing || bladeGlowColor || '#ff2a85',
            intensity: 1.8,
            displayMode: 'always'
        }, config.aura || {});

        var currentMode = 'idle'; // 'showcase', 'idle', 'roll_dice'
        var actionAnimStartTime = 0;
        var isActionActive = false;

        const rootGroup = new THREE.Group();
        rootGroup.name = `ag_character_${id}`;

        // -------------------------------------------------------------
        // Universal Character Anchor Group (Procedural Motion Engine)
        // Controls jumping, bouncing, spinning, and swaying for ALL models
        // -------------------------------------------------------------
        const characterAnchorGroup = new THREE.Group();
        characterAnchorGroup.name = 'characterAnchorGroup';
        characterAnchorGroup.position.set(0, 0.35, 0); // Position on top of pedestal
        rootGroup.add(characterAnchorGroup);

        // -------------------------------------------------------------
        // Custom 3D Model Mesh Slot (GLB, GLTF, FBX, OBJ, BLEND)
        // -------------------------------------------------------------
        let activeModelGroup = null;
        let activeMixer = null;
        const customModelSlot = new THREE.Group();
        customModelSlot.name = 'custom3DModelSlot';
        customModelSlot.position.set(0, 0, 0);
        characterAnchorGroup.add(customModelSlot);

        // -------------------------------------------------------------
        // Articulation & Body/Facial Animation Detector
        // Detects: Head, Arms (L/R), Legs (L/R), Eyes (Blink), Mouth (Talk)
        // -------------------------------------------------------------
        const detectedParts = {
            hasBones: false,
            hasMorphs: false,
            headBones: [],
            armLeftBones: [],
            armRightBones: [],
            legLeftBones: [],
            legRightBones: [],
            eyeMeshes: [],
            mouthMeshes: [],
            morphBlinks: [],
            morphMouths: [],
            baseRotations: new Map(),
            baseScales: new Map()
        };

        function scanModelArticulation(targetGroup) {
            detectedParts.headBones = [];
            detectedParts.armLeftBones = [];
            detectedParts.armRightBones = [];
            detectedParts.legLeftBones = [];
            detectedParts.legRightBones = [];
            detectedParts.eyeMeshes = [];
            detectedParts.mouthMeshes = [];
            detectedParts.morphBlinks = [];
            detectedParts.morphMouths = [];
            detectedParts.baseRotations.clear();
            detectedParts.baseScales.clear();
            detectedParts.hasBones = false;
            detectedParts.hasMorphs = false;

            if (!targetGroup) return;

            targetGroup.traverse(child => {
                // Morph targets (BlendShapes for Eyes & Mouth)
                if (child.isMesh && child.morphTargetDictionary && child.morphTargetInfluences) {
                    detectedParts.hasMorphs = true;
                    for (const [key, idx] of Object.entries(child.morphTargetDictionary)) {
                        const lower = key.toLowerCase();
                        if (lower.includes('blink') || lower.includes('eye_close') || lower.includes('close_eye') || lower.includes('wink')) {
                            detectedParts.morphBlinks.push({ mesh: child, index: idx });
                        }
                        if (lower.includes('mouth') || lower.includes('talk') || lower.includes('smile') || lower.includes('jaw') || lower.includes('open') || lower.includes('viseme') || lower.includes('v_aa') || lower.includes('v_ih') || lower.includes('v_oh')) {
                            detectedParts.morphMouths.push({ mesh: child, index: idx });
                        }
                    }
                }

                const name = (child.name || '').toLowerCase();
                const isBone = child.isBone || (child.type && child.type.includes('Bone'));

                if (isBone || child.isMesh || child.isGroup) {
                    // Head / Neck
                    if (name.match(/head|neck|skull|kubi|atama/i) && !name.match(/headset|overhead|arrow|wing/i)) {
                        detectedParts.headBones.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                    }
                    // Left Arm / Hand
                    else if (name.match(/(arm|shoulder|hand|elbow|wrist|forearm|bicep).*l|l.*(arm|hand|shoulder)|left.*(arm|hand)|(arm|hand).*left/i)) {
                        detectedParts.armLeftBones.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                    }
                    // Right Arm / Hand
                    else if (name.match(/(arm|shoulder|hand|elbow|wrist|forearm|bicep).*r|r.*(arm|hand|shoulder)|right.*(arm|hand)|(arm|hand).*right/i)) {
                        detectedParts.armRightBones.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                    }
                    // Left Leg / Foot
                    else if (name.match(/(leg|thigh|calf|knee|shin|foot|toe|ankle).*l|l.*(leg|foot|thigh)|left.*(leg|foot)|(leg|foot).*left/i)) {
                        detectedParts.legLeftBones.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                    }
                    // Right Leg / Foot
                    else if (name.match(/(leg|thigh|calf|knee|shin|foot|toe|ankle).*r|r.*(leg|foot|thigh)|right.*(leg|foot)|(leg|foot).*right/i)) {
                        detectedParts.legRightBones.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                    }
                    // Eyes
                    else if (name.match(/eye|pupil|iris|eyelid|mayu/i)) {
                        detectedParts.eyeMeshes.push(child);
                        detectedParts.baseScales.set(child, child.scale.clone());
                    }
                    // Mouth / Jaw
                    else if (name.match(/mouth|jaw|lip|tongue|kuchi/i)) {
                        detectedParts.mouthMeshes.push(child);
                        detectedParts.baseRotations.set(child, child.rotation.clone());
                        detectedParts.baseScales.set(child, child.scale.clone());
                    }
                }
            });

            if (detectedParts.headBones.length || detectedParts.armLeftBones.length || detectedParts.legLeftBones.length) {
                detectedParts.hasBones = true;
            }
        }

        function attachCustom3DModel(group, mixer) {
            while (customModelSlot.children.length > 0) {
                customModelSlot.remove(customModelSlot.children[0]);
            }
            if (activeMixer && activeMixer.stopAllAction) {
                try { activeMixer.stopAllAction(); } catch (e) {}
            }
            activeModelGroup = group;
            activeMixer = mixer || null;
            if (group) {
                customModelSlot.add(group);
                scanModelArticulation(group);
                heroGroup.visible = false;
            } else {
                heroGroup.visible = true;
                scanModelArticulation(null);
            }
        }

        // -------------------------------------------------------------
        // A. Ground Magic Pedestal & Runic Aura Circle
        // -------------------------------------------------------------
        const pedestalGroup = new THREE.Group();
        pedestalGroup.name = 'pedestalGroup';

        const groundTex = createGroundRunicRingTexture(auraRingColor);
        const groundRingMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(3.6, 3.6),
            new THREE.MeshBasicMaterial({
                map: groundTex,
                transparent: true,
                opacity: 0.95,
                depthWrite: false,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            })
        );
        groundRingMesh.rotation.x = -Math.PI / 2;
        groundRingMesh.position.y = 0.05;
        pedestalGroup.add(groundRingMesh);

        // 3D Hexagonal Pedestal Base
        const baseCyl = new THREE.Mesh(
            new THREE.CylinderGeometry(0.9, 1.1, 0.3, 16),
            new THREE.MeshStandardMaterial({
                color: new THREE.Color(secondaryColor),
                emissive: new THREE.Color(primaryColor),
                emissiveIntensity: 0.35,
                metalness: 0.8,
                roughness: 0.2
            })
        );
        baseCyl.position.y = 0.15;
        pedestalGroup.add(baseCyl);

        // Gold Upper Collar
        const collarMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(0.75, 0.9, 0.12, 16),
            new THREE.MeshStandardMaterial({
                color: 0xffd700,
                emissive: 0xf59e0b,
                emissiveIntensity: 0.5,
                metalness: 0.95,
                roughness: 0.1
            })
        );
        collarMesh.position.y = 0.32;
        pedestalGroup.add(collarMesh);

        // -------------------------------------------------------------
        // Aura VFX Subsystem (6 Rich Selectable Aura Presets)
        // -------------------------------------------------------------
        const auraGroup = new THREE.Group();
        auraGroup.name = 'auraGroup';
        pedestalGroup.add(auraGroup);

        // 1. Heavenly Beam (เสาแสงสปอตไลท์สวรรค์)
        const beamMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(0.75, 1.35, 4.2, 24, 1, true),
            new THREE.MeshBasicMaterial({
                color: new THREE.Color(auraConfig.color || bladeGlowColor),
                transparent: true,
                opacity: 0.22,
                depthWrite: false,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            })
        );
        beamMesh.position.y = 2.1;
        auraGroup.add(beamMesh);

        const beamCoreMesh = new THREE.Mesh(
            new THREE.CylinderGeometry(0.35, 0.65, 4.0, 16, 1, true),
            new THREE.MeshBasicMaterial({
                color: 0xffffff,
                transparent: true,
                opacity: 0.28,
                depthWrite: false,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            })
        );
        beamCoreMesh.position.y = 2.1;
        beamMesh.add(beamCoreMesh);

        // 2. Runic Circle (วงแหวนเวทมนตร์อักขระรูน 2 ชั้นหมุนสวนทาง)
        const runicCircleGroup = new THREE.Group();
        runicCircleGroup.name = 'runicCircleGroup';
        const innerRunicMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(2.3, 2.3),
            new THREE.MeshBasicMaterial({
                map: groundTex,
                transparent: true,
                opacity: 0.85,
                depthWrite: false,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            })
        );
        innerRunicMesh.rotation.x = -Math.PI / 2;
        innerRunicMesh.position.y = 0.08;
        runicCircleGroup.add(innerRunicMesh);
        auraGroup.add(runicCircleGroup);

        // 3. Blazing Fire Aura (เปลวเพลิงลุกโชน + ละอองไฟ)
        const blazingFireGroup = new THREE.Group();
        blazingFireGroup.name = 'blazingFireGroup';
        const fireCone = new THREE.Mesh(
            new THREE.ConeGeometry(1.4, 2.8, 16, 1, true),
            new THREE.MeshBasicMaterial({
                color: new THREE.Color(auraConfig.color || bladeGlowColor),
                transparent: true,
                opacity: 0.25,
                depthWrite: false,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            })
        );
        fireCone.position.y = 1.4;
        fireCone.rotation.x = Math.PI; // upside down flare
        blazingFireGroup.add(fireCone);

        // Spark embers
        const emberParticles = [];
        for (let i = 0; i < 14; i++) {
            const ember = new THREE.Mesh(
                new THREE.BoxGeometry(0.06, 0.06, 0.06),
                new THREE.MeshBasicMaterial({
                    color: 0xffffff,
                    transparent: true,
                    opacity: 0.85,
                    blending: THREE.AdditiveBlending
                })
            );
            ember.userData = {
                angle: (i / 14) * Math.PI * 2,
                radius: 0.5 + Math.random() * 0.7,
                speedY: 1.2 + Math.random() * 1.5,
                phase: Math.random() * Math.PI * 2
            };
            blazingFireGroup.add(ember);
            emberParticles.push(ember);
        }
        auraGroup.add(blazingFireGroup);

        // 4. Electric Lightning Spark Aura (พายุสายฟ้าอสนีบาต)
        const lightningGroup = new THREE.Group();
        lightningGroup.name = 'lightningGroup';
        const lightningRings = [];
        for (let i = 0; i < 3; i++) {
            const lRing = new THREE.Mesh(
                new THREE.TorusGeometry(0.95 + i * 0.25, 0.025, 6, 24),
                new THREE.MeshBasicMaterial({
                    color: 0xffffff,
                    transparent: true,
                    opacity: 0.9,
                    blending: THREE.AdditiveBlending
                })
            );
            lRing.rotation.x = (i * Math.PI) / 3;
            lRing.rotation.y = (i * Math.PI) / 4;
            lRing.position.y = 1.2 + i * 0.3;
            lightningGroup.add(lRing);
            lightningRings.push(lRing);
        }
        auraGroup.add(lightningGroup);

        // 5. Cosmic Starlight (ละอองดวงดาวประกายคอสมิกหมุนวน)
        const starlightGroup = new THREE.Group();
        starlightGroup.name = 'starlightGroup';
        const stars = [];
        for (let i = 0; i < 10; i++) {
            const star = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.09, 0),
                new THREE.MeshBasicMaterial({
                    color: 0xffffff,
                    transparent: true,
                    opacity: 0.95,
                    blending: THREE.AdditiveBlending
                })
            );
            star.userData = {
                baseY: 0.6 + (i * 0.22),
                radius: 0.85 + (i % 3) * 0.25,
                orbitSpeed: 1.0 + (i % 2 === 0 ? 0.6 : -0.6),
                angleOffset: (i / 10) * Math.PI * 2
            };
            starlightGroup.add(star);
            stars.push(star);
        }
        auraGroup.add(starlightGroup);

        // 6. Pulse Shockwave Rings (วงแหวนคลื่นพลังกระแทกกระจาย)
        const shockwaveGroup = new THREE.Group();
        shockwaveGroup.name = 'shockwaveGroup';
        const shockwaves = [];
        for (let i = 0; i < 3; i++) {
            const swMesh = new THREE.Mesh(
                new THREE.RingGeometry(0.3, 0.42, 32),
                new THREE.MeshBasicMaterial({
                    color: new THREE.Color(auraConfig.color || bladeGlowColor),
                    transparent: true,
                    opacity: 0.7,
                    depthWrite: false,
                    blending: THREE.AdditiveBlending,
                    side: THREE.DoubleSide
                })
            );
            swMesh.rotation.x = -Math.PI / 2;
            swMesh.position.y = 0.06;
            swMesh.userData = { phase: i * 0.33 };
            shockwaveGroup.add(swMesh);
            shockwaves.push(swMesh);
        }
        auraGroup.add(shockwaveGroup);

        // Global Dynamic Aura PointLight
        const auraPointLight = new THREE.PointLight(new THREE.Color(auraConfig.color || bladeGlowColor), auraConfig.intensity || 1.8, 6.0);
        auraPointLight.position.set(0, 1.4, 0);
        auraGroup.add(auraPointLight);

        function applyAuraVisuals() {
            const isVisible = (auraConfig.displayMode !== 'none') && 
                              (auraConfig.displayMode === 'always' || isActionActive);
            auraGroup.visible = isVisible;
            if (!isVisible) return;

            const col = new THREE.Color(auraConfig.color || '#ff2a85');
            const intensity = Number(auraConfig.intensity || 1.8) * (isActionActive ? 1.7 : 1.0);

            if (auraPointLight) {
                auraPointLight.color.copy(col);
                auraPointLight.intensity = intensity;
            }
            if (beamMesh) {
                beamMesh.visible = (auraConfig.style === 'heavenly_beam');
                beamMesh.material.color.copy(col);
            }
            if (runicCircleGroup) {
                runicCircleGroup.visible = (auraConfig.style === 'runic_circle');
            }
            if (blazingFireGroup) {
                blazingFireGroup.visible = (auraConfig.style === 'blazing_fire');
                fireCone.material.color.copy(col);
            }
            if (lightningGroup) {
                lightningGroup.visible = (auraConfig.style === 'electric_lightning');
            }
            if (starlightGroup) {
                starlightGroup.visible = (auraConfig.style === 'cosmic_starlight');
            }
            if (shockwaveGroup) {
                shockwaveGroup.visible = (auraConfig.style === 'pulse_shockwave');
                shockwaves.forEach(sw => sw.material.color.copy(col));
            }
        }
        applyAuraVisuals();

        rootGroup.add(pedestalGroup);

        // -------------------------------------------------------------
        // B. Hero Body Group (Stylized Cyber / Anime Warrior Mesh)
        // -------------------------------------------------------------
        const heroGroup = new THREE.Group();
        heroGroup.name = 'heroGroup';
        heroGroup.position.y = 0.4;

        // Torso / Breastplate
        const torsoMat = new THREE.MeshStandardMaterial({
            color: new THREE.Color(secondaryColor),
            emissive: new THREE.Color(primaryColor),
            emissiveIntensity: 0.2,
            metalness: 0.65,
            roughness: 0.3
        });
        const torsoGeo = new THREE.CylinderGeometry(0.42, 0.30, 0.85, 8);
        const torsoMesh = new THREE.Mesh(torsoGeo, torsoMat);
        torsoMesh.position.y = 1.1;
        heroGroup.add(torsoMesh);

        // Gem Core on Chest (Pink Glow)
        const gemMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            emissive: new THREE.Color(bladeGlowColor),
            emissiveIntensity: 1.8,
            metalness: 0.2,
            roughness: 0.1
        });
        const gemMesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), gemMat);
        gemMesh.position.set(0, 1.22, 0.36);
        heroGroup.add(gemMesh);

        // Shoulder Pauldrons (Left & Right)
        const pauldronGeo = new THREE.ConeGeometry(0.24, 0.45, 6);
        const pauldronMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            metalness: 0.85,
            roughness: 0.15
        });
        const pLeft = new THREE.Mesh(pauldronGeo, pauldronMat);
        pLeft.rotation.z = Math.PI / 3;
        pLeft.position.set(-0.55, 1.35, 0);
        heroGroup.add(pLeft);

        const pRight = new THREE.Mesh(pauldronGeo, pauldronMat);
        pRight.rotation.z = -Math.PI / 3;
        pRight.position.set(0.55, 1.35, 0);
        heroGroup.add(pRight);

        // Flowing Cape (Back)
        const capeMat = new THREE.MeshStandardMaterial({
            color: new THREE.Color(primaryColor),
            side: THREE.DoubleSide,
            roughness: 0.5
        });
        const capeGeo = new THREE.PlaneGeometry(0.72, 1.15, 4, 4);
        const capeMesh = new THREE.Mesh(capeGeo, capeMat);
        capeMesh.position.set(0, 0.95, -0.28);
        capeMesh.rotation.x = 0.18;
        heroGroup.add(capeMesh);

        // Head Disc / Face Hologram
        const headBadgeGroup = new THREE.Group();
        headBadgeGroup.position.set(0, 1.88, 0);

        const avatarDiscTex = createAvatarDiscTexture(avatarUrl, bladeGlowColor, name, grade);
        const headDiscMesh = new THREE.Mesh(
            new THREE.CircleGeometry(0.65, 32),
            new THREE.MeshBasicMaterial({
                map: avatarDiscTex,
                side: THREE.DoubleSide,
                transparent: true
            })
        );
        headBadgeGroup.add(headDiscMesh);

        // Floating Crown / Warrior Crest
        const crestMesh = new THREE.Mesh(
            new THREE.TorusGeometry(0.68, 0.045, 8, 32),
            new THREE.MeshStandardMaterial({
                color: 0xffd700,
                emissive: 0xf59e0b,
                emissiveIntensity: 0.7,
                metalness: 0.9,
                roughness: 0.1
            })
        );
        headBadgeGroup.add(crestMesh);

        heroGroup.add(headBadgeGroup);

        // -------------------------------------------------------------
        // C. The Sword with Pink Blade Emission Glow & Glowing Ring
        // -------------------------------------------------------------
        const swordGroup = new THREE.Group();
        swordGroup.name = 'swordGroup';
        // Placed floating at the right side of the character in idle
        swordGroup.position.set(0.75, 1.15, 0.25);
        swordGroup.rotation.z = -0.25;

        // 1. Blade Hilt / Handle
        const hiltGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.45, 8);
        const hiltMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
        const hiltMesh = new THREE.Mesh(hiltGeo, hiltMat);
        hiltMesh.position.y = -0.22;
        swordGroup.add(hiltMesh);

        // 2. Tsuba / Sword Guard (Golden)
        const guardGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.05, 8);
        const guardMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.15 });
        const guardMesh = new THREE.Mesh(guardGeo, guardMat);
        swordGroup.add(guardMesh);

        // 3. The Pink Glowing Blade Mesh (ใบดาบเรืองแสงสีชมพู)
        const bladeGeo = new THREE.BoxGeometry(0.08, 1.45, 0.03);
        const bladeMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            emissive: new THREE.Color(bladeGlowColor), // Pink Emission Glow
            emissiveIntensity: weaponConfig.emissionIntensity || 2.8,
            metalness: 0.92,
            roughness: 0.08
        });
        const bladeMesh = new THREE.Mesh(bladeGeo, bladeMat);
        bladeMesh.position.y = 0.75;
        swordGroup.add(bladeMesh);

        // Blade Point / Tip
        const tipGeo = new THREE.ConeGeometry(0.056, 0.28, 4);
        const tipMesh = new THREE.Mesh(tipGeo, bladeMat);
        tipMesh.position.y = 1.58;
        swordGroup.add(tipMesh);

        // 4. Pink Aura Glow Ring (วงแหวนแสงเรืองรองหมุนรอบใบดาบ)
        const bladeRingGeo = new THREE.TorusGeometry(0.32, 0.04, 12, 32);
        const bladeRingMat = new THREE.MeshStandardMaterial({
            color: new THREE.Color(bladeGlowColor),
            emissive: new THREE.Color(bladeGlowColor),
            emissiveIntensity: 3.5,
            metalness: 0.5,
            roughness: 0.1
        });
        const bladeRingMesh = new THREE.Mesh(bladeRingGeo, bladeRingMat);
        bladeRingMesh.rotation.x = Math.PI / 2;
        bladeRingMesh.position.y = 0.55;
        swordGroup.add(bladeRingMesh);

        // 5. Point Light on Blade Tip (Illuminates the character in pink)
        const bladeLight = new THREE.PointLight(new THREE.Color(bladeGlowColor), 1.8, 4.5);
        bladeLight.position.y = 1.0;
        swordGroup.add(bladeLight);

        heroGroup.add(swordGroup);
        characterAnchorGroup.add(heroGroup);

        // -------------------------------------------------------------
        // D. Floating Name & Role Label Sprite (ป้ายชื่อผู้เล่น)
        // -------------------------------------------------------------
        const nameCanvas = document.createElement('canvas');
        nameCanvas.width = 400;
        nameCanvas.height = 110;
        const nctx = nameCanvas.getContext('2d');
        nctx.fillStyle = 'rgba(15, 12, 35, 0.88)';
        nctx.roundRect(10, 10, 380, 90, 18);
        nctx.fill();
        nctx.strokeStyle = primaryColor;
        nctx.lineWidth = 3.5;
        nctx.stroke();

        nctx.fillStyle = '#ffd700';
        nctx.font = 'bold 30px Kanit, sans-serif';
        nctx.textAlign = 'center';
        nctx.fillText(`👑 [${grade}] ${name}`, 200, 52);

        nctx.fillStyle = '#f472b6';
        nctx.font = '22px Kanit, sans-serif';
        nctx.fillText('⚔️ สกิล: ' + (weaponConfig.name || 'ดาบประกายชมพู'), 200, 84);

        const nameTex = new THREE.CanvasTexture(nameCanvas);
        const nameSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: nameTex, transparent: true }));
        nameSprite.position.set(0, 3.3, 0);
        nameSprite.scale.set(3.4, 0.95, 1);
        rootGroup.add(nameSprite);

        // -------------------------------------------------------------
        // E. State & Universal Motion Controller
        // -------------------------------------------------------------
        const charObj = {
            id,
            name,
            grade,
            rootGroup,
            characterAnchorGroup,
            heroGroup,
            swordGroup,
            bladeMesh,
            bladeMat,
            bladeRingMesh,
            bladeLight,
            groundRingMesh,
            capeMesh,
            config,
            customModelSlot,
            auraGroup,
            attachCustom3DModel,

            setAnimationConfig(newAnim) {
                Object.assign(animConfig, newAnim || {});
            },
            getAnimationConfig() {
                return Object.assign({}, animConfig);
            },
            setAuraConfig(newAura) {
                Object.assign(auraConfig, newAura || {});
                applyAuraVisuals();
            },
            getAuraConfig() {
                return Object.assign({}, auraConfig);
            },

            load3DModel(url, format) {
                return ag.space.load3DModel(url, { format: format, targetHeight: 2.2 }).then(res => {
                    attachCustom3DModel(res.group, res.mixer);
                    return res;
                });
            },
            removeCustom3DModel() {
                attachCustom3DModel(null, null);
            },

            // Set current display mode
            setMode(mode) {
                currentMode = mode;
                if (characterAnchorGroup) {
                    characterAnchorGroup.visible = (mode !== 'showcase');
                }
                applyAuraVisuals();

                if (mode === 'roll_dice') {
                    this.playDiceRollAnimation();
                } else if (mode === 'showcase') {
                    swordGroup.position.set(0.65, 1.25, 0.4);
                    swordGroup.rotation.set(0.2, 0, -0.4);
                    bladeMat.emissiveIntensity = 2.8;
                } else {
                    swordGroup.position.set(0.75, 1.15, 0.25);
                    swordGroup.rotation.set(0, 0, -0.25);
                    bladeMat.emissiveIntensity = 2.4;
                }
            },

            // Play the dice rolling & skill action animation with story dialogue
            playDiceRollAnimation(callback) {
                isActionActive = true;
                actionAnimStartTime = performance.now();
                applyAuraVisuals();
                playSfx('slash');

                // Trigger Story Dialogue popup
                ag.ui.showDialogue({
                    speaker: `🌸 ${name}`,
                    text: dialogueConfig.skillText || '✨ เพลงดาบประกายชมพูผ่ามิติ! ทอยเต๋าติดดับเบิ้ล 100%!',
                    avatar: avatarUrl,
                    duration: 3800
                });

                // Spawn floating 3D dice burst in action mode if in studio
                if (typeof config.onDiceRollTrigger === 'function') {
                    config.onDiceRollTrigger();
                }

                setTimeout(() => {
                    playSfx('dice');
                }, 450);

                setTimeout(() => {
                    isActionActive = false;
                    applyAuraVisuals();
                    if (typeof callback === 'function') callback();
                }, 1600);
            },

            // Per-frame animation updater
            update(delta = 0.016, elapsedSec = 0) {
                const animSpeed = Math.max(0.2, Number(animConfig.speed) || 1.0);
                const H = Math.max(0.1, Number(animConfig.jumpHeight) || 1.0);
                const t = elapsedSec * animSpeed;

                // 0. Update skeletal / 3D model animations
                if (activeMixer) {
                    try { activeMixer.update(delta); } catch (e) {}
                }

                // ---------------------------------------------------------
                // 1. Procedural Character Motion (Both 3D Model & Hero Mesh)
                // ---------------------------------------------------------
                if (!isActionActive) {
                    // IDLE / NORMAL MOVEMENTS
                    const idleStyle = animConfig.idleStyle || 'idle_bounce';

                    if (idleStyle === 'idle_walk_circle') {
                        // 🚶 เดินวนรอบฐาน 360° (Walk in Circle / Orbit Patrol)
                        const walkSpeed = 1.35 * animSpeed;
                        const walkAngle = (t * walkSpeed) % (Math.PI * 2);
                        const radius = 0.65;
                        characterAnchorGroup.position.x = Math.sin(walkAngle) * radius;
                        characterAnchorGroup.position.z = Math.cos(walkAngle) * radius;
                        characterAnchorGroup.rotation.y = walkAngle + (Math.PI / 2);
                        const stepCycle = walkAngle * 3.6;
                        const stepBounce = Math.abs(Math.sin(stepCycle)) * 0.09 * H;
                        characterAnchorGroup.position.y = 0.35 + stepBounce;
                        characterAnchorGroup.rotation.z = Math.sin(stepCycle) * 0.06;
                        characterAnchorGroup.rotation.x = 0.04;
                        characterAnchorGroup.scale.set(1, 1, 1);
                    } else if (idleStyle === 'idle_walk_patrol') {
                        // 🏃 เดินก้าวไปมาหน้าหลัง (Walk Back & Forth)
                        const patrolSpeed = 0.9 * animSpeed;
                        const cycle = (t * patrolSpeed) % 4.0;
                        let pZ = 0;
                        let rotY = 0;
                        if (cycle < 1.7) {
                            pZ = -0.6 + (cycle / 1.7) * 1.2;
                            rotY = 0;
                        } else if (cycle < 2.0) {
                            pZ = 0.6;
                            rotY = ((cycle - 1.7) / 0.3) * Math.PI;
                        } else if (cycle < 3.7) {
                            pZ = 0.6 - ((cycle - 2.0) / 1.7) * 1.2;
                            rotY = Math.PI;
                        } else {
                            pZ = -0.6;
                            rotY = Math.PI + ((cycle - 3.7) / 0.3) * Math.PI;
                        }
                        characterAnchorGroup.position.x = 0;
                        characterAnchorGroup.position.z = pZ;
                        characterAnchorGroup.rotation.y = rotY;
                        const stepBounce = Math.abs(Math.sin(cycle * 7.0)) * 0.08 * H;
                        characterAnchorGroup.position.y = 0.35 + stepBounce;
                        characterAnchorGroup.rotation.z = Math.sin(cycle * 7.0) * 0.05;
                        characterAnchorGroup.rotation.x = 0.04;
                        characterAnchorGroup.scale.set(1, 1, 1);
                    } else if (idleStyle === 'idle_dance_step') {
                        // 💃 สลับขาก้าวเต้นดุ๊กดิ๊ก (Step & Dance)
                        characterAnchorGroup.position.y = 0.35 + Math.abs(Math.sin(t * 3.6)) * 0.12 * H;
                        characterAnchorGroup.position.x = Math.sin(t * 1.8) * 0.22;
                        characterAnchorGroup.position.z = 0;
                        characterAnchorGroup.rotation.y = Math.sin(t * 1.8) * 0.35;
                        characterAnchorGroup.rotation.z = Math.sin(t * 3.6) * 0.12;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.scale.set(1, 1, 1);
                    } else if (idleStyle === 'idle_bounce') {
                        // กระโดดดึ๋งๆ ต่อเนื่อง (Bouncy Hop with Squash & Stretch)
                        const jumpCycle = (t * 3.4) % (Math.PI * 2);
                        const rawBounce = Math.abs(Math.sin(jumpCycle));
                        const bounceY = Math.pow(rawBounce, 1.4) * 0.45 * H;
                        characterAnchorGroup.position.y = 0.35 + bounceY;
                        characterAnchorGroup.position.x = 0;
                        characterAnchorGroup.position.z = 0;

                        if (bounceY < 0.04) {
                            // Squash on ground
                            characterAnchorGroup.scale.set(1.1, 0.9, 1.1);
                        } else {
                            // Stretch in air
                            const str = 1.0 + rawBounce * 0.08;
                            characterAnchorGroup.scale.set(1.0 / Math.sqrt(str), str, 1.0 / Math.sqrt(str));
                        }
                        characterAnchorGroup.rotation.y = Math.sin(t * 1.5) * 0.14;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.rotation.z = 0;
                    } else if (idleStyle === 'idle_float') {
                        // ลอยตัวกลางอากาศนุ่มนวล (Float / Levitate)
                        characterAnchorGroup.position.x = 0;
                        characterAnchorGroup.position.y = 0.45 + Math.sin(t * 2.2) * 0.16 * H;
                        characterAnchorGroup.rotation.y = Math.sin(t * 1.2) * 0.18;
                        characterAnchorGroup.rotation.z = Math.sin(t * 1.6) * 0.06;
                        characterAnchorGroup.rotation.x = Math.sin(t * 1.8) * 0.04;
                        characterAnchorGroup.scale.set(1, 1, 1);
                        characterAnchorGroup.position.z = 0;
                    } else if (idleStyle === 'idle_sway') {
                        // โยกตัวซ้ายขวาตามจังหวะ (Sway Dance)
                        characterAnchorGroup.position.x = 0;
                        characterAnchorGroup.position.y = 0.35 + Math.abs(Math.cos(t * 2.8)) * 0.09 * H;
                        characterAnchorGroup.rotation.z = Math.sin(t * 2.8) * 0.15;
                        characterAnchorGroup.rotation.y = Math.sin(t * 1.4) * 0.22;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.scale.set(1, 1, 1);
                        characterAnchorGroup.position.z = 0;
                    } else if (idleStyle === 'idle_spin') {
                        // หมุนตัวโชว์ 360 องศารอบทิศ (360 Orbit Spin)
                        characterAnchorGroup.position.x = 0;
                        characterAnchorGroup.position.y = 0.38 + Math.sin(t * 2.0) * 0.08 * H;
                        characterAnchorGroup.rotation.y += 0.025 * animSpeed;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.rotation.z = 0;
                        characterAnchorGroup.scale.set(1, 1, 1);
                        characterAnchorGroup.position.z = 0;
                    } else if (idleStyle === 'idle_double_hop') {
                        // กระโดด 2 จังหวะ (Double Hop)
                        characterAnchorGroup.position.x = 0;
                        const cycle = (t * 2.6) % 4.0;
                        let hopY = 0;
                        if (cycle < 0.7) {
                            hopY = Math.sin((cycle / 0.7) * Math.PI) * 0.35 * H;
                        } else if (cycle >= 0.9 && cycle < 1.6) {
                            hopY = Math.sin(((cycle - 0.9) / 0.7) * Math.PI) * 0.52 * H;
                        }
                        characterAnchorGroup.position.y = 0.35 + hopY;
                        characterAnchorGroup.rotation.y = Math.sin(t * 1.4) * 0.1;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.rotation.z = 0;
                        characterAnchorGroup.scale.set(1, 1, 1);
                        characterAnchorGroup.position.z = 0;
                    } else {
                        // ยืนหายใจนิ่งๆ (Breathe Idle)
                        characterAnchorGroup.position.x = 0;
                        const breath = Math.sin(t * 2.2) * 0.04 * H;
                        characterAnchorGroup.position.y = 0.35 + breath;
                        characterAnchorGroup.rotation.y = 0;
                        characterAnchorGroup.rotation.x = 0;
                        characterAnchorGroup.rotation.z = 0;
                        characterAnchorGroup.scale.set(1 + breath * 0.15, 1 + breath * 0.25, 1 + breath * 0.15);
                        characterAnchorGroup.position.z = 0;
                    }

                    // Floating sword in idle
                    swordGroup.position.y = 1.15 + Math.sin(t * 2.8 + 1) * 0.06;
                    swordGroup.rotation.z = -0.25 + Math.sin(t * 1.8) * 0.05;
                    bladeMat.emissiveIntensity = 2.2 + Math.sin(t * 4.0) * 0.6;
                    bladeLight.intensity = 1.6 + Math.sin(t * 4.0) * 0.4;
                }

                // -------------------------------------------------------------
                // 1.5. Body & Facial Articulation Engine (แขน, ขา, หัว, ตา, ปาก)
                // -------------------------------------------------------------
                const headMotion = animConfig.headMotion || 'none';
                const armMotion = animConfig.armMotion || 'none';
                const legMotion = animConfig.legMotion || 'none';
                const eyeBlink = animConfig.eyeBlink || 'none';
                const mouthMotion = animConfig.mouthMotion || 'none';

                // 1.5.A Head Motion
                if (headMotion !== 'none') {
                    let dX = 0, dY = 0, dZ = 0;
                    if (headMotion === 'head_nod') {
                        dX = Math.sin(t * 3.4 * animSpeed) * 0.18;
                    } else if (headMotion === 'head_shake') {
                        dY = Math.sin(t * 2.8 * animSpeed) * 0.25;
                    } else if (headMotion === 'head_tilt') {
                        dZ = Math.sin(t * 2.2 * animSpeed) * 0.18;
                        dY = Math.cos(t * 1.5 * animSpeed) * 0.08;
                    } else if (headMotion === 'head_look_around') {
                        const phase = (t * 0.8 * animSpeed) % (Math.PI * 2);
                        dY = Math.sin(phase) * 0.42;
                        dX = Math.sin(phase * 2) * 0.08;
                    }

                    if (detectedParts.headBones.length > 0) {
                        detectedParts.headBones.forEach(b => {
                            const base = detectedParts.baseRotations.get(b);
                            if (base) {
                                b.rotation.x = base.x + dX;
                                b.rotation.y = base.y + dY;
                                b.rotation.z = base.z + dZ;
                            }
                        });
                    } else if (customModelSlot) {
                        customModelSlot.rotation.x = dX * 0.65;
                        customModelSlot.rotation.y = dY * 0.65;
                        customModelSlot.rotation.z = dZ * 0.65;
                    }
                } else if (detectedParts.headBones.length > 0) {
                    detectedParts.headBones.forEach(b => {
                        const base = detectedParts.baseRotations.get(b);
                        if (base) b.rotation.copy(base);
                    });
                } else if (customModelSlot) {
                    customModelSlot.rotation.set(0, 0, 0);
                }

                // 1.5.B Arm Motion
                if (armMotion !== 'none') {
                    let aLAngle = 0, aRAngle = 0, aRotZ_L = 0, aRotZ_R = 0;
                    let aAxis = 'x';

                    if (armMotion === 'arm_swing') {
                        const swing = Math.sin(t * 3.5 * animSpeed) * 0.45;
                        aLAngle = swing;
                        aRAngle = -swing;
                    } else if (armMotion === 'arm_wave') {
                        aAxis = 'z';
                        aRAngle = 1.1 + Math.sin(t * 7.0 * animSpeed) * 0.35;
                        aLAngle = Math.sin(t * 2.0 * animSpeed) * 0.08;
                    } else if (armMotion === 'arm_cheer') {
                        aAxis = 'z';
                        aLAngle = -1.2 + Math.sin(t * 4.5 * animSpeed) * 0.22;
                        aRAngle = 1.2 - Math.sin(t * 4.5 * animSpeed) * 0.22;
                    } else if (armMotion === 'arm_dance') {
                        aLAngle = Math.sin(t * 3.0 * animSpeed) * 0.32;
                        aRAngle = Math.cos(t * 3.0 * animSpeed) * 0.32;
                        aRotZ_L = -0.4 + Math.sin(t * 2.5 * animSpeed) * 0.2;
                        aRotZ_R = 0.4 - Math.sin(t * 2.5 * animSpeed) * 0.2;
                    }

                    if (detectedParts.hasBones) {
                        detectedParts.armLeftBones.forEach(b => {
                            const base = detectedParts.baseRotations.get(b);
                            if (base) {
                                if (aAxis === 'x') b.rotation.x = base.x + aLAngle;
                                if (aAxis === 'z') b.rotation.z = base.z + aLAngle;
                                if (aRotZ_L) b.rotation.z = base.z + aRotZ_L;
                            }
                        });
                        detectedParts.armRightBones.forEach(b => {
                            const base = detectedParts.baseRotations.get(b);
                            if (base) {
                                if (aAxis === 'x') b.rotation.x = base.x + aRAngle;
                                if (aAxis === 'z') b.rotation.z = base.z + aRAngle;
                                if (aRotZ_R) b.rotation.z = base.z + aRotZ_R;
                            }
                        });
                    }
                }

                // 1.5.C Leg Motion
                if (legMotion !== 'none') {
                    let legLAngle = 0, legRAngle = 0;
                    if (legMotion === 'leg_walk') {
                        const step = Math.sin(t * 3.5 * animSpeed) * 0.4;
                        legLAngle = step;
                        legRAngle = -step;
                    } else if (legMotion === 'leg_march') {
                        const m = (t * 3.0 * animSpeed) % (Math.PI * 2);
                        legLAngle = Math.max(0, Math.sin(m)) * 0.6;
                        legRAngle = Math.max(0, -Math.sin(m)) * 0.6;
                    } else if (legMotion === 'leg_tap') {
                        legLAngle = 0;
                        legRAngle = Math.abs(Math.sin(t * 6.5 * animSpeed)) * 0.25;
                    }

                    if (detectedParts.hasBones) {
                        detectedParts.legLeftBones.forEach(b => {
                            const base = detectedParts.baseRotations.get(b);
                            if (base) b.rotation.x = base.x + legLAngle;
                        });
                        detectedParts.legRightBones.forEach(b => {
                            const base = detectedParts.baseRotations.get(b);
                            if (base) b.rotation.x = base.x + legRAngle;
                        });
                    }
                }

                // 1.5.D Eye Blink
                if (eyeBlink !== 'none') {
                    let blinkWeight = 0;
                    if (eyeBlink === 'blink_natural') {
                        const cycle = (t * animSpeed) % 3.6;
                        if (cycle < 0.16) {
                            blinkWeight = Math.sin((cycle / 0.16) * Math.PI);
                        }
                    } else if (eyeBlink === 'blink_double') {
                        const cycle = (t * animSpeed) % 4.0;
                        if (cycle < 0.14) {
                            blinkWeight = Math.sin((cycle / 0.14) * Math.PI);
                        } else if (cycle >= 0.22 && cycle < 0.36) {
                            blinkWeight = Math.sin(((cycle - 0.22) / 0.14) * Math.PI);
                        }
                    } else if (eyeBlink === 'blink_wink') {
                        const cycle = (t * animSpeed) % 3.2;
                        if (cycle < 0.35) {
                            blinkWeight = Math.sin((cycle / 0.35) * Math.PI);
                        }
                    }

                    if (detectedParts.morphBlinks.length > 0) {
                        detectedParts.morphBlinks.forEach(m => {
                            m.mesh.morphTargetInfluences[m.index] = blinkWeight;
                        });
                    } else if (detectedParts.eyeMeshes.length > 0) {
                        const scaleY = 1.0 - (blinkWeight * 0.88);
                        detectedParts.eyeMeshes.forEach(mesh => {
                            const base = detectedParts.baseScales.get(mesh);
                            if (base) mesh.scale.y = base.y * scaleY;
                        });
                    }
                }

                // 1.5.E Mouth Movement
                if (mouthMotion !== 'none') {
                    let mouthWeight = 0;
                    if (mouthMotion === 'mouth_talk') {
                        mouthWeight = Math.abs(Math.sin(t * 7.5 * animSpeed) * Math.cos(t * 3.2));
                    } else if (mouthMotion === 'mouth_smile') {
                        mouthWeight = 0.65 + Math.sin(t * 2.0 * animSpeed) * 0.25;
                    } else if (mouthMotion === 'mouth_surprised') {
                        mouthWeight = 0.85 + Math.sin(t * 3.0 * animSpeed) * 0.15;
                    }

                    if (detectedParts.morphMouths.length > 0) {
                        detectedParts.morphMouths.forEach(m => {
                            m.mesh.morphTargetInfluences[m.index] = mouthWeight;
                        });
                    } else if (detectedParts.mouthMeshes.length > 0) {
                        detectedParts.mouthMeshes.forEach(m => {
                            const base = detectedParts.baseRotations.get(m);
                            if (base) {
                                m.rotation.x = base.x + (mouthWeight * 0.3);
                            } else {
                                const baseS = detectedParts.baseScales.get(m);
                                if (baseS) m.scale.y = baseS.y * (1 + mouthWeight * 0.4);
                            }
                        });
                    }
                } else {
                    // -----------------------------------------------------
                    // DICE ROLL / ACTION ANIMATIONS (0 - 1.6s Timeline)
                    // -----------------------------------------------------
                    const totalDuration = 1.6;
                    const progress = Math.min(1.0, (performance.now() - actionAnimStartTime) / 1000 / totalDuration);
                    const rollStyle = animConfig.rollStyle || 'roll_spin_jump';

                    if (rollStyle === 'roll_spin_jump') {
                        // กระโดดสูงหมุนตัว 360° (Spin Jump 720°)
                        const jumpH = Math.sin(progress * Math.PI) * 1.35 * H;
                        characterAnchorGroup.position.y = 0.35 + jumpH;
                        characterAnchorGroup.rotation.y = progress * Math.PI * 4; // 2 full spins!
                        characterAnchorGroup.rotation.x = Math.sin(progress * Math.PI) * 0.25;
                        characterAnchorGroup.position.z = Math.sin(progress * Math.PI) * 0.35;
                        const str = 1.0 + Math.sin(progress * Math.PI) * 0.2;
                        characterAnchorGroup.scale.set(1.0 / Math.sqrt(str), str, 1.0 / Math.sqrt(str));
                    } else if (rollStyle === 'roll_mega_jump') {
                        // กระโดดพุ่งไปข้างหน้า (Mega Forward Leap)
                        const jumpH = Math.sin(progress * Math.PI) * 1.45 * H;
                        characterAnchorGroup.position.y = 0.35 + jumpH;
                        characterAnchorGroup.position.z = Math.sin(progress * Math.PI) * 1.0;
                        characterAnchorGroup.rotation.x = Math.sin(progress * Math.PI) * 0.45;
                        characterAnchorGroup.rotation.y = 0;
                    } else if (rollStyle === 'roll_ground_slam') {
                        // กระโดดทุบพื้นสะเทือน (Ground Slam)
                        if (progress < 0.45) {
                            const p = progress / 0.45;
                            characterAnchorGroup.position.y = 0.35 + (p * 1.4 * H);
                            characterAnchorGroup.rotation.x = -p * 0.45;
                        } else if (progress < 0.72) {
                            const p = (progress - 0.45) / 0.27;
                            characterAnchorGroup.position.y = 0.35 + (1.4 * H * (1 - p));
                            characterAnchorGroup.rotation.x = (1 - p) * -0.45;
                        } else {
                            // Impact landing squash
                            const p = (progress - 0.72) / 0.28;
                            characterAnchorGroup.position.y = 0.35;
                            characterAnchorGroup.scale.set(1 + (1 - p) * 0.3, 1 - (1 - p) * 0.25, 1 + (1 - p) * 0.3);
                        }
                    } else if (rollStyle === 'roll_backflip') {
                        // กระโดดตีลังกาถอยหลัง (Somersault / Backflip 360°)
                        const jumpH = Math.sin(progress * Math.PI) * 1.35 * H;
                        characterAnchorGroup.position.y = 0.35 + jumpH;
                        characterAnchorGroup.rotation.x = -progress * Math.PI * 2;
                        characterAnchorGroup.position.z = -Math.sin(progress * Math.PI) * 0.4;
                    } else {
                        // กระโดดดึ๋งๆ รัวๆ ฉลอง (Frenzy Bounce)
                        const hopProgress = (progress * 3.0) % 1.0;
                        const hopY = Math.sin(hopProgress * Math.PI) * 0.9 * H;
                        characterAnchorGroup.position.y = 0.35 + hopY;
                        characterAnchorGroup.rotation.y = Math.sin(progress * Math.PI * 3) * 0.5;
                        characterAnchorGroup.rotation.z = Math.sin(progress * Math.PI * 4) * 0.25;
                    }

                    // Sword slash choreography
                    if (progress < 0.4) {
                        const p = progress / 0.4;
                        swordGroup.position.set(0.5 - p * 0.2, 1.4 + p * 0.3, -0.2);
                        swordGroup.rotation.set(-p * 0.8, 0, p * 0.6);
                        bladeMat.emissiveIntensity = 2.8 + p * 3.5;
                    } else if (progress < 0.8) {
                        const p = (progress - 0.4) / 0.4;
                        swordGroup.position.set(0.3 + p * 0.4, 1.7 - p * 0.7, 0.8);
                        swordGroup.rotation.set(0.6 - p * 1.8, 0, -1.2);
                        bladeMat.emissiveIntensity = 6.2;
                        bladeLight.intensity = 4.0;
                    } else {
                        const p = (progress - 0.8) / 0.8;
                        swordGroup.position.set(0.7, 1.0, 0.4);
                        bladeMat.emissiveIntensity = 3.0 + (1 - p) * 1.5;
                    }
                }

                // ---------------------------------------------------------
                // 2. Aura VFX Animations
                // ---------------------------------------------------------
                if (auraGroup && auraGroup.visible) {
                    const aStyle = auraConfig.style || 'heavenly_beam';

                    if (aStyle === 'heavenly_beam' && beamMesh) {
                        beamMesh.rotation.y += 0.008;
                        const pulseScale = 1.0 + Math.sin(t * 3.5) * 0.06;
                        beamMesh.scale.set(pulseScale, 1.0, pulseScale);
                    } else if (aStyle === 'runic_circle') {
                        if (groundRingMesh) groundRingMesh.rotation.z += 0.012;
                        if (innerRunicMesh) innerRunicMesh.rotation.z -= 0.02;
                    } else if (aStyle === 'blazing_fire') {
                        fireCone.rotation.y += 0.04;
                        fireCone.scale.y = 1.0 + Math.sin(t * 9.0) * 0.15;
                        emberParticles.forEach(ember => {
                            const ud = ember.userData;
                            const curY = (t * ud.speedY + ud.phase) % 2.6;
                            const spread = (curY / 2.6) * 0.6;
                            ember.position.set(
                                Math.cos(ud.angle + t) * (ud.radius + spread),
                                0.2 + curY,
                                Math.sin(ud.angle + t) * (ud.radius + spread)
                            );
                            ember.material.opacity = Math.max(0, 1.0 - (curY / 2.6));
                        });
                    } else if (aStyle === 'electric_lightning') {
                        lightningRings.forEach((ring, idx) => {
                            ring.rotation.x += 0.03 * (idx + 1);
                            ring.rotation.y -= 0.04 * (idx + 1);
                        });
                        // Strobe flash
                        if (Math.random() > 0.82) {
                            auraPointLight.intensity = (Number(auraConfig.intensity) || 1.8) * 2.5;
                        } else {
                            auraPointLight.intensity = Number(auraConfig.intensity) || 1.8;
                        }
                    } else if (aStyle === 'cosmic_starlight') {
                        stars.forEach(star => {
                            const ud = star.userData;
                            const angle = t * ud.orbitSpeed + ud.angleOffset;
                            star.position.set(
                                Math.cos(angle) * ud.radius,
                                ud.baseY + Math.sin(t * 2.5 + ud.angleOffset) * 0.18,
                                Math.sin(angle) * ud.radius
                            );
                            star.rotation.x += 0.04;
                            star.rotation.y += 0.05;
                        });
                    } else if (aStyle === 'pulse_shockwave') {
                        shockwaves.forEach(sw => {
                            const phase = (t * 1.4 + sw.userData.phase) % 1.0;
                            const s = 0.3 + phase * 2.8;
                            sw.scale.set(s, s, s);
                            sw.material.opacity = Math.max(0, (1.0 - phase) * 0.85);
                        });
                    }
                }

                // 3. Ground base aura & blade ring rotation
                if (groundRingMesh) {
                    groundRingMesh.rotation.z += 0.008;
                }
                if (bladeRingMesh) {
                    bladeRingMesh.rotation.z += 0.05;
                    bladeRingMesh.rotation.y += 0.02;
                    const ringScale = 1.0 + Math.sin(t * 5.0) * 0.15;
                    bladeRingMesh.scale.set(ringScale, ringScale, ringScale);
                }
                if (capeMesh) {
                    capeMesh.rotation.x = 0.18 + Math.sin(t * 3.5) * 0.08;
                }
            }
        };

        // Attach custom 3D model if provided directly or load via URL
        if (config.model3dMesh) {
            attachCustom3DModel(config.model3dMesh, config.modelMixer);
        } else if (config.model3dUrl || config.model_3d_url) {
            const mUrl = config.model3dUrl || config.model_3d_url;
            const mFmt = config.modelFormat || config.model_format;
            ag.space.load3DModel(mUrl, { format: mFmt, targetHeight: 2.2 }).then(res => {
                attachCustom3DModel(res.group, res.mixer);
            }).catch(e => {
                console.warn('ag.space.createCharacter: 3D model load error:', e);
            });
        }

        return charObj;
    };

    console.log('✅ [Antigravity] Character & Space Engine Loaded (ag.space.createCharacter & ag.ui.showDialogue ready)');
})();

