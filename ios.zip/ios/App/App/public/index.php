<?php

header('Content-Type: text/html; charset=UTF-8');
header('Content-Language: th');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/api/auth.php';
require_once __DIR__ . '/api/monopoly_board_service.php';

$activeUser = null;
$authToken = '';
$gameModesCfg = ['snake_enabled' => true, 'monopoly_enabled' => true, 'default_mode' => 'MONOPOLY'];
$activeMonoBoard = null;
$monoBoardsList = [];

try {
    $db = getDbConnection();
    ensureSocialAccountsMerged($db);
    if (function_exists('getGameModesConfig')) {
        $gameModesCfg = getGameModesConfig($db);
    }
    if (function_exists('getActiveDefaultMonopolyBoard')) {
        $activeMonoBoard = getActiveDefaultMonopolyBoard($db);
    }
    if (function_exists('getAllActiveMonopolyBoards')) {
        $monoBoardsList = getAllActiveMonopolyBoards($db);
    }

    // 1) ผู้เล่นที่ล็อกอินไว้แล้ว (Token จาก URL หรือ Cookie)
    $isLoggedOut = (string)($_COOKIE['snake_logged_out'] ?? '') === '1';
    $reqToken = (string)($_GET['token'] ?? $_GET['auth_token'] ?? (!$isLoggedOut ? ($_COOKIE['snake_auth_token'] ?? '') : ''));
    if ($reqToken !== '') {
        $uid = (int)(verifyAuthToken($reqToken) ?? 0);
        if ($uid > 0) {
            $activeUser = getFullUserProfileById($db, $uid);
            if ($activeUser && !empty($activeUser['id'])) {
                $authToken = $reqToken;
            } else {
                $activeUser = null;
            }
        }
    }

    if ($activeUser && $authToken !== '') {
        $activeUser['auth_token'] = $authToken;
        $activeUser['provider'] = !empty($activeUser['line_id']) ? 'line' : 'google';
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 80) === 443;
        setcookie('snake_auth_token', $authToken, ['expires' => time() + 86400 * 90, 'path' => '/', 'secure' => $isHttps, 'samesite' => 'Lax']);
        setcookie('snake_logged_out', '', ['expires' => time() - 3600, 'path' => '/', 'secure' => $isHttps, 'samesite' => 'Lax']);
    }
} catch (\Throwable $e) {
    $activeUser = null;
}

$html = file_get_contents(__DIR__ . '/index.html');
$html = preg_replace('/^(\xEF\xBB\xBF)+/', '', $html);

$otaBuster = '1794965500000';
$otaFile = __DIR__ . '/config/ota_version.json';
if (file_exists($otaFile)) {
    $otaJson = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', (string)@file_get_contents($otaFile)), true);
    if (!empty($otaJson['cache_buster'])) {
        $otaBuster = (string)$otaJson['cache_buster'];
    }
}
$html = preg_replace('/(<meta\s+name="game-ota-version"\s+content=")\d+(")/i', '${1}' . $otaBuster . '${2}', $html);
$html = preg_replace('/(window\.__GAME_OTA_VERSION__\s*=\s*")\d+(")/i', '${1}' . $otaBuster . '${2}', $html);
$html = preg_replace('/(\.(?:js|css)\?v=)\d+/i', '${1}' . $otaBuster, $html);

$modeBootstrapJs = '  window.GAME_MODES_CONFIG = ' . json_encode($gameModesCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ";\n" .
    '  window.selectedHomeGameMode = ' . json_encode($gameModesCfg['default_mode'] ?? 'MONOPOLY') . ";\n" .
    '  window.ACTIVE_MONOPOLY_BOARD = ' . json_encode($activeMonoBoard, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ";\n" .
    '  window.MONOPOLY_BOARDS_LIST = ' . json_encode($monoBoardsList, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ";\n";

if ($activeUser && $authToken !== '') {
    $inject = '<script id="instant-bootstrap-profile">' . "\n" .
        '  window.__OAUTH_INSTANT_TOKEN__ = ' . json_encode($authToken) . ';' . "\n" .
        '  window.__OAUTH_INSTANT_USER__ = ' . json_encode($activeUser, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';' . "\n" .
        $modeBootstrapJs .
        '</script>';
    if (str_contains($html, '<script id="instant-bootstrap-profile">')) {
        $html = preg_replace('/<script id="instant-bootstrap-profile">[\s\S]*?<\/script>/u', $inject, $html, 1);
    } else {
        $html = str_replace('</head>', $inject . "\n</head>", $html);
    }
} else {
    $inject = '<script id="instant-bootstrap-profile">' . "\n" .
        '  window.__OAUTH_INSTANT_TOKEN__ = null;' . "\n" .
        '  window.__OAUTH_INSTANT_USER__ = null;' . "\n" .
        $modeBootstrapJs .
        '</script>';
    if (str_contains($html, '<script id="instant-bootstrap-profile">')) {
        $html = preg_replace('/<script id="instant-bootstrap-profile">[\s\S]*?<\/script>/u', $inject, $html, 1);
    }
}

echo $html;