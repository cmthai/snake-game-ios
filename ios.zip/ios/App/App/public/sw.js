/**
 * 📱 Service Worker: Game Push & Lockscreen Notification Engine
 * รองรับการแจ้งเตือนขึ้นหน้าจอมือถือ (Lock Screen / Notification Bar)
 * ทั้ง Android Chrome, iOS Web App (PWA) และ Web Browser
 */

const OFFLINE_CACHE_NAME = 'snake-offline-fallback-v1';
const OFFLINE_FALLBACK_URL = './offline.html';
const OFFLINE_HTML = `<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Snake &amp; Ladder 3D — ออฟไลน์</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:radial-gradient(circle at 50% 20%,#0f172a,#050811 70%);color:#f8fafc}
  .card{width:min(92vw,380px);padding:28px 22px;border-radius:18px;text-align:center;background:rgba(15,23,42,.92);border:1px solid rgba(56,189,248,.45);box-shadow:0 24px 60px rgba(0,0,0,.7)}
  .ring{width:68px;height:68px;margin:0 auto 14px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(239,68,68,.15);border:2px solid rgba(248,113,113,.65);font-size:30px}
  h1{margin:0 0 8px;font-size:18px}
  p{margin:0 0 18px;font-size:13px;line-height:1.5;color:#cbd5e1}
  button{width:100%;padding:12px 16px;border:none;border-radius:12px;font-size:14.5px;font-weight:800;color:#04101f;background:linear-gradient(135deg,#38bdf8,#818cf8);cursor:pointer}
</style>
</head>
<body>
  <div class="card">
    <div class="ring">📡</div>
    <h1>การเชื่อมต่ออินเทอร์เน็ตขาดหาย</h1>
    <p>ไม่สามารถโหลดเกมได้ในขณะนี้ กรุณาตรวจสอบสัญญาณ Wi-Fi หรือเน็ตมือถือของคุณ แล้วกดลองเชื่อมต่อใหม่</p>
    <button onclick="location.reload()">🔄 ลองเชื่อมต่อใหม่</button>
  </div>
  <script>window.addEventListener('online',function(){location.reload();});</script>
</body>
</html>`;

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(OFFLINE_CACHE_NAME).then((cache) => {
            return cache.put(OFFLINE_FALLBACK_URL, new Response(OFFLINE_HTML, {
                headers: { 'Content-Type': 'text/html; charset=utf-8' }
            }));
        }).then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(self.clients.claim());
});

// 🌐 ดักจับ Navigation Request เมื่อเน็ตหลุด ให้แสดงหน้า Offline ธีมเกมแทนหน้า Error ของเบราว์เซอร์
self.addEventListener('fetch', (event) => {
    if (event.request.mode === 'navigate') {
        event.respondWith(
            fetch(event.request).catch(async () => {
                const cache = await caches.open(OFFLINE_CACHE_NAME);
                const cached = await cache.match(OFFLINE_FALLBACK_URL);
                return cached || new Response(OFFLINE_HTML, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
            })
        );
    }
});

// 🔔 จัดการเมื่อมี Push Notification ส่งเข้ามา
self.addEventListener('push', (event) => {
    let data = {
        title: '🎲 Snake & Ladder 3D',
        body: 'มีการแจ้งเตือนใหม่ในเกมส์!',
        icon: 'apple-touch-icon.png',
        badge: 'favicon.png',
        tag: 'game-alert',
        vibrate: [300, 100, 300, 100, 400]
    };

    if (event.data) {
        try {
            data = Object.assign(data, event.data.json());
        } catch (e) {
            data.body = event.data.text();
        }
    }

    event.waitUntil(
        self.registration.showNotification(data.title, {
            body: data.body,
            icon: data.icon || 'apple-touch-icon.png',
            badge: data.badge || 'favicon.png',
            vibrate: data.vibrate || [300, 100, 300, 100, 400],
            tag: data.tag || 'game-alert',
            renotify: true,
            data: { url: data.url || './' }
        })
    );
});

// 📩 รับคำสั่งแจ้งเตือนตรงจากหน้าเว็บ / แอป (รองรับทั้งแสดงทันทีและตั้งเวลาแจ้งเตือนเมื่อพับจอ)
const _swScheduledTimers = new Map();
self.addEventListener('message', (event) => {
    const msg = event.data;
    if (!msg || typeof msg !== 'object') return;

    const showNow = (payload) => {
        const title = payload.title || '🎲 Snake & Ladder 3D';
        const options = {
            body: payload.body || '',
            icon: payload.icon || 'apple-touch-icon.png',
            badge: payload.badge || 'favicon.png',
            vibrate: [300, 100, 300, 100, 400],
            tag: payload.tag || ('game-notif-' + (payload.id || Date.now())),
            renotify: true,
            requireInteraction: false,
            data: { url: payload.url || './', actionType: payload.actionType || '' }
        };
        return self.registration.showNotification(title, options);
    };

    if (msg.type === 'SHOW_NOTIFICATION') {
        event.waitUntil(showNow(msg));
    } else if (msg.type === 'SCHEDULE_NOTIFICATION') {
        const key = String(msg.id || msg.tag || Date.now());
        if (_swScheduledTimers.has(key)) {
            clearTimeout(_swScheduledTimers.get(key));
            _swScheduledTimers.delete(key);
        }
        const delayMs = Math.max(0, Number(msg.delayMs) || 0);
        if (delayMs <= 1200) {
            event.waitUntil(showNow(msg));
        } else {
            const t = setTimeout(() => {
                _swScheduledTimers.delete(key);
                showNow(msg);
            }, delayMs);
            _swScheduledTimers.set(key, t);
        }
    }
});

// 👆 เมื่อผู้เล่นแตะ/คลิกการแจ้งเตือนที่หน้าจอมือถือ (เหมือนไลน์)
self.addEventListener('notificationclick', (event) => {
    event.notification.close();

    const targetUrl = (event.notification.data && event.notification.data.url) ? event.notification.data.url : './';

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
            // หากมีแท็บเกมส์เปิดอยู่แล้ว ให้สลับไปยังแท็บนั้นทันที
            for (const client of clientList) {
                if ('focus' in client) {
                    return client.focus();
                }
            }
            // หากยังไม่ได้เปิด ให้เปิดหน้าต่างเกมส์ขึ้นมาใหม่
            if (clients.openWindow) {
                return clients.openWindow(targetUrl);
            }
        })
    );
});

