// =========================================================================
// 🌟 SEPARATED EVENT GACHA CONTROLLERS (แยกอีเวนต์กรอบรูป & อีเวนต์ลูกเต๋า 3D คนละหน้าคนละเมนู + Popup สุ่มเปิดซองแบบในคลิป)
// =========================================================================
let currentEventGachaData = null;
let eventGachaTimerInterval = null;
let lastGachaPullMeta = {
    source: 'EVENT',
    category: 'FRAME',
    count: 5,
    currency: 'DIAMOND',
    packTier: 'SPECIAL',
    displayCost: '💎 225'
};
let pendingGachaRevealDrops = [];
let pendingGachaRevealCategory = 'FRAME';
let gachaPackAutoTearTimeout = null;
let gachaCardRevealTimers = [];
let isAllRevealedCardsFlipped = false;

function clearGachaCardRevealTimers() {
    if (Array.isArray(gachaCardRevealTimers) && gachaCardRevealTimers.length > 0) {
        gachaCardRevealTimers.forEach(t => clearTimeout(t));
        gachaCardRevealTimers = [];
    }
}

function triggerSingleCardRevealSound(isRare = false) {
    try {
        if (window.ThaiAudio && typeof window.ThaiAudio.playCardReveal === 'function') {
            window.ThaiAudio.playCardReveal(isRare);
        } else if (window.soundEngine && typeof window.soundEngine.playCardRevealZap === 'function') {
            window.soundEngine.playCardRevealZap('zap_classic', isRare, 0.95);
        }
    } catch (e) {}
}

window.openFrameEventModal = async function() {
    closeModal('modal-event-dice');
    openModal('modal-event-frame');
    await loadEventGachaData('FRAME');
};

window.openDiceEventModal = async function() {
    closeModal('modal-event-frame');
    openModal('modal-event-dice');
    await loadEventGachaData('DICE');
};

// Backward-compatible alias if any news card or button calls openEventGachaModal
window.openEventGachaModal = async function(preferredType = 'FRAME') {
    if (String(preferredType).toUpperCase() === 'DICE') {
        return window.openDiceEventModal();
    }
    return window.openFrameEventModal();
};

function getDefaultFallbackEventData() {
    return {
        is_live_now: true,
        name: 'เทศกาลอีเวนต์พิเศษ',
        cost_diamond: 50,
        remaining_seconds: 86400 * 14,
        user_materials: {},
        reqs: { black: 25, red: 25, orange: 20, blue: 15, gold: 8 },
        dice_reqs: { black: 15, red: 15, orange: 15, blue: 10, gold: 4 },
        target_character: {
            id: 1,
            name: 'ดาราจักรเนบิวลา SS+',
            grade: 'SS+',
            avatar_url: 'avatars/avatar_01.png',
            skill_name: 'ความแม่นยำคุมลูกเต๋าสูงสุด + ส่วนลดค่าผ่านทาง & ป้องกันการถูกซื้อต่อ'
        },
        target_dice: {
            id: 1,
            name: 'ลูกเต๋านีออนมังกรทอง 3D',
            grade: 'SS+',
            dice_control: 85,
            skill_desc: 'ควบคุมแต้มลูกเต๋า +85% • โบนัสทอง & เอฟเฟกต์แสงมังกรทอง 3D'
        }
    };
}

window.loadEventGachaData = async function() {
    let evData = currentEventGachaData || getDefaultFallbackEventData();
    try {
        if (window.apiClient && typeof apiClient.getActiveEventGacha === 'function') {
            const res = await apiClient.getActiveEventGacha();
            if (res && res.status === 'success' && res.data) {
                evData = res.data;
                currentEventGachaData = evData;
            }
        }
    } catch (e) {
        console.warn('Event gacha fetch fallback:', e);
    }
    renderSeparatedEventGachaUIs(evData);
};

function updateSeparatedEventWalletsAndTimers(ev) {
    const userDia = Number((typeof DEFAULT_USER !== 'undefined' ? (DEFAULT_USER.diamond ?? DEFAULT_USER.diamonds) : 0) || 0);
    const userGold = Number((typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER.gold : 0) || 0);

    ['frame-event-user-dia', 'dice-event-user-dia'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerText = userDia.toLocaleString();
    });
    ['frame-event-user-gold', 'dice-event-user-gold'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerText = userGold.toLocaleString();
    });

    if (eventGachaTimerInterval) clearInterval(eventGachaTimerInterval);
    let rem = Number(ev.remaining_seconds || 0);
    const renderTick = () => {
        const txt = rem <= 0
            ? 'เปิดตลอดเวลา'
            : (() => {
                const days = Math.floor(rem / 86400);
                const hrs = Math.floor((rem % 86400) / 3600);
                const mins = Math.floor((rem % 3600) / 60);
                const secs = rem % 60;
                return `${days > 0 ? days + ' วัน ' : ''}${hrs} ชม. ${mins} นาที ${secs} วิ`;
            })();
        const fTimer = document.getElementById('frame-event-countdown');
        const dTimer = document.getElementById('dice-event-countdown');
        if (fTimer) fTimer.innerText = txt;
        if (dTimer) dTimer.innerText = txt;
    };
    renderTick();
    if (rem > 0) {
        eventGachaTimerInterval = setInterval(() => {
            rem = Math.max(0, rem - 1);
            renderTick();
            if (rem <= 0) clearInterval(eventGachaTimerInterval);
        }, 1000);
    }
}

function buildShadowMatsArray(uMats, reqMap, defaultReqs) {
    const specs = [
        { code: 'SHADOW_BLACK_A', name: 'เงาดำ A', icon: '⬛', color: '#94a3b8', reqKey: 'black', defReq: defaultReqs.black },
        { code: 'SHADOW_RED_A', name: 'เงาแดง A', icon: '🟥', color: '#ef4444', reqKey: 'red', defReq: defaultReqs.red },
        { code: 'SHADOW_ORANGE_A', name: 'เงาส้ม A', icon: '🟧', color: '#f97316', reqKey: 'orange', defReq: defaultReqs.orange },
        { code: 'SHADOW_BLUE_APLUS', name: 'เงาฟ้า A+', icon: '🟦', color: '#38bdf8', reqKey: 'blue', defReq: defaultReqs.blue, altCode: 'SHADOW_BLUE_A' },
        { code: 'SHADOW_GOLD_S', name: 'เงาทอง S', icon: '🟨', color: '#ffd700', reqKey: 'gold', defReq: defaultReqs.gold, altCode: 'SHADOW_GOLD_APLUS' }
    ];
    return specs.map(s => {
        const owned = Number(uMats[s.code] || 0) + (s.altCode ? Number(uMats[s.altCode] || 0) : 0);
        const req = parseInt(reqMap[s.reqKey] ?? s.defReq, 10) || s.defReq;
        return { ...s, owned, req, isReady: owned >= req };
    });
}

function renderSeparatedEventGachaUIs(ev) {
    updateSeparatedEventWalletsAndTimers(ev);

    const uMats = ev.user_materials || {};
    const reqs = ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {};
    const diceReqs = ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {};

    const costSingle = Math.max(10, parseInt(ev.cost_diamond || 50, 10));
    const costEvent5 = Math.round(costSingle * 5 * 0.9);
    const costPremium5 = Math.round(costSingle * 5 * 1.45);
    const costPremium10 = Math.round(costSingle * 10 * 1.35);

    // ---------------------------------------------------------
    // 1. Render FRAME EVENT PAGE (#frame-event-body)
    // ---------------------------------------------------------
    const frameBody = document.getElementById('frame-event-body');
    if (frameBody) {
        const frameMats = buildShadowMatsArray(uMats, reqs, { black: 25, red: 25, orange: 20, blue: 15, gold: 8 });
        const canExchangeFrame = frameMats.every(m => m.isReady);
        const missingFrameCount = frameMats.filter(m => !m.isReady).length;
        const char = ev.target_character || { id: 1, name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+' };
        const charAvatar = char.avatar_url || 'avatars/avatar_01.png';

        frameBody.innerHTML = `
            <!-- Left Showcase & Horizontal Shadow Exchange -->
            <div class="event-hero-panel">
                <div>
                    <div class="event-hero-poster">
                        <div class="event-hero-emblem">
                            <img src="${charAvatar}" alt="${char.name || 'Frame'}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src='avatars/avatar_01.png';">
                        </div>
                        <div style="min-width:0; flex:1;">
                            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                <span style="background:linear-gradient(135deg,#ffd700,#f59e0b); color:#000; font-size:10px; font-weight:900; padding:2px 7px; border-radius:5px;">${char.grade || 'SS+'}</span>
                                <span style="font-size:10px; color:#fde047; font-weight:800;">รางวัลใหญ่ประจำอีเวนต์กรอบรูป</span>
                            </div>
                            <div style="font-size:clamp(15px,1.9vw,20px); font-weight:900; color:#fff; margin-top:3px; text-shadow:0 2px 8px rgba(0,0,0,0.8);">${char.name || 'ดาราจักรเนบิวลา SS+'}</div>
                            <div style="font-size:11px; color:#bae6fd; margin-top:3px; line-height:1.35;">⚡ ${char.skill_name || 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง'}</div>
                        </div>
                    </div>

                    <!-- Horizontal Shadow Progress Strip -->
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                        <span style="font-size:11px; font-weight:800; color:#fde68a;">✨ สะสมการ์ดเงาแลกกรอบรูป (แนวนอน):</span>
                        ${canExchangeFrame
                            ? `<button type="button" class="btn-lgr-exchange-sparkle frame-sparkle" onclick="checkAndShowShadowCompleteModal('FRAME')" title="เงาครบแล้ว! กดแลกรับกรอบรูปทันที">
                                   <span class="btn-sparkle-star">✨</span>
                                   <span class="btn-text">ครบพร้อมแลก! (กดแลกทันที)</span>
                                   <span class="btn-sparkle-tag">FREE</span>
                               </button>`
                            : `<span style="background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">ขาดอีก ${missingFrameCount} ชนิด</span>`
                        }
                    </div>
                    <div class="shadow-horizontal-strip">
                        ${frameMats.map(m => `
                            <div class="shadow-strip-pill ${m.isReady ? 'is-ready' : 'is-missing'}">
                                <div style="font-size:14px; line-height:1;">${m.icon}</div>
                                <div style="font-size:9.5px; font-weight:800; color:${m.color}; margin-top:2px;">${m.name}</div>
                                <div style="font-size:10.5px; font-weight:900; color:${m.isReady ? '#34d399' : '#fca5a5'}; margin-top:1px;">${m.owned}/${m.req}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Exchange Target Card (Bright & Clickable if Ready | Dimmed & Unclickable if Incomplete) -->
                <div class="event-target-card ${canExchangeFrame ? 'ready-to-exchange' : 'not-ready'}" style="margin-top:6px; padding:10px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
                        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                            <img src="${charAvatar}" style="width:36px; height:36px; border-radius:50%; border:2px solid #ffd700; object-fit:cover;" onerror="this.src='avatars/avatar_01.png';">
                            <div style="min-width:0;">
                                <div style="font-size:12px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">👑 ${char.name || 'กรอบรูป SS+'}</div>
                                <div style="font-size:10px; color:#cbd5e1;">${canExchangeFrame ? 'สะสมเงาครบแล้ว กดแลกรับได้ทันที!' : 'สะสมเงาให้ครบทั้ง 5 สีเพื่อปลดล็อกปุ่มแลก'}</div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn-lgr-exchange-hero ${canExchangeFrame ? 'is-ready frame-ready' : 'is-disabled'}"
                        onclick="${canExchangeFrame ? `checkAndShowShadowCompleteModal('FRAME')` : ''}"
                        ${canExchangeFrame ? '' : 'disabled'}>
                        <span class="hero-shine-sweep"></span>
                        <span class="hero-btn-content">
                            ${canExchangeFrame ? '✨ 🎉 กดแลกรับกรอบรูป SS+ ทันที! 👑 ✨' : `🔒 เงายังไม่ครบ (ขาดอีก ${missingFrameCount} ชนิด)`}
                        </span>
                    </button>
                </div>
            </div>

            <!-- Right 6 Frame Gacha Pack Cards Grid (เหมือนในคลิป 00:00-00:01) -->
            <div class="event-packs-grid">
                <div class="gacha-pack-shop-card is-special" onclick="rollSeparatedEventGacha('FRAME', 1, 'DIAMOND', 'SPECIAL', '💎 ${costSingle}')">
                    <div class="pack-card-header-bar">แพ็คการ์ดกรอบพิเศษ (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil"><span class="mini-foil-icon">👑</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มการ์ดกรอบรูปพิเศษ<br>& การ์ดเงา (+1 ใบ)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costSingle.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('FRAME', 1, 'GOLD', 'NORMAL', '🪙 30,000')">
                    <div class="pack-card-header-bar">ชุดการ์ดกรอบทั่วไป (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🃏</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบการ์ดเงา<br>ระดับ A ~ A+ (1 ใบ)</div>
                    </div>
                    <div class="pack-card-price-btn">🪙 30,000</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('FRAME', 5, 'GOLD', 'NORMAL', '🪙 120,000')">
                    <div class="pack-card-header-bar">ชุดการ์ดกรอบทั่วไป (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🃏</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบการ์ดเงา<br>แบบคุ้มค่า 5 ใบรวด!</div>
                    </div>
                    <div class="pack-card-price-btn">🪙 120,000</div>
                </div>

                <div class="gacha-pack-shop-card is-event-hot" onclick="rollSeparatedEventGacha('FRAME', 5, 'DIAMOND', 'SPECIAL', '💎 ${costEvent5}')">
                    <span class="pack-card-event-flag">EVENT</span>
                    <div class="pack-card-header-bar">แพ็คการ์ดกรอบพิเศษ (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil"><span class="mini-foil-icon">👑</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">แพ็คอีเวนต์ยอดนิยม!<br>เปิดการ์ดกรอบ 5 ใบ (ลด 10%)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costEvent5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('FRAME', 5, 'DIAMOND', 'PREMIUM', '💎 ${costPremium5}')">
                    <div class="pack-card-header-bar">ชุดกรอบพรีเมียม (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil"><span class="mini-foil-icon">✨</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">เรตอัปเงาฟ้า A+ / ทอง S<br>& ลุ้นกรอบ SS+ 5 ใบ</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('FRAME', 10, 'DIAMOND', 'PREMIUM', '💎 ${costPremium10}')">
                    <span class="pack-card-event-flag">HOT</span>
                    <div class="pack-card-header-bar">ชุดกรอบพรีเมียม (+10)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil"><span class="mini-foil-icon">🌟</span><span class="mini-foil-qty">10</span></div>
                        <div class="pack-card-desc">แพ็คใหญ่จุใจ 10 ใบ<br>โอกาสออกเงาทอง S สูงสุด!</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium10.toLocaleString()}</div>
                </div>
            </div>
        `;
    }

    // ---------------------------------------------------------
    // 2. Render 3D DICE EVENT PAGE (#dice-event-body)
    // ---------------------------------------------------------
    const diceBody = document.getElementById('dice-event-body');
    if (diceBody) {
        const diceMats = buildShadowMatsArray(uMats, diceReqs, { black: 15, red: 15, orange: 15, blue: 10, gold: 4 });
        const canExchangeDice = diceMats.every(m => m.isReady);
        const missingDiceCount = diceMats.filter(m => !m.isReady).length;
        const dice = ev.target_dice || { id: 1, name: 'ลูกเต๋านีออนมังกรทอง 3D', grade: 'SS+', dice_control: 85 };

        diceBody.innerHTML = `
            <!-- Left Showcase & Horizontal Shadow Exchange (3D Dice Only) -->
            <div class="event-hero-panel">
                <div>
                    <div class="event-hero-poster">
                        <div class="event-hero-emblem dice-emblem">
                            ${dice.image_url ? `<img src="${dice.image_url}" alt="${dice.name}" style="width:100%; height:100%; object-fit:cover;" onerror="this.outerHTML='🎲';">` : '🎲'}
                        </div>
                        <div style="min-width:0; flex:1;">
                            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                <span style="background:linear-gradient(135deg,#00e5ff,#0284c7); color:#000; font-size:10px; font-weight:900; padding:2px 7px; border-radius:5px;">3D DICE ${dice.grade || 'SS+'}</span>
                                <span style="font-size:10px; color:#7dd3fc; font-weight:800;">ลูกเต๋าแรร์ประจำอีเวนต์</span>
                            </div>
                            <div style="font-size:clamp(15px,1.9vw,20px); font-weight:900; color:#fff; margin-top:3px; text-shadow:0 2px 8px rgba(0,0,0,0.8);">${dice.name || 'ลูกเต๋านีออนมังกรทอง 3D'}</div>
                            <div style="font-size:11px; color:#7dd3fc; margin-top:3px; line-height:1.35;">🎲 ควบคุมลูกเต๋า +${dice.dice_control || 85}% • เอฟเฟกต์ลูกเต๋า 3D สุดอลังการบนกระดาน</div>
                        </div>
                    </div>

                    <!-- Horizontal Shadow Progress Strip -->
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                        <span style="font-size:11px; font-weight:800; color:#7dd3fc;">✨ สะสมเงาแลกลูกเต๋า 3D (แนวนอน):</span>
                        ${canExchangeDice
                            ? `<button type="button" class="btn-lgr-exchange-sparkle dice-sparkle" onclick="checkAndShowShadowCompleteModal('DICE')" title="เงาครบแล้ว! กดแลกรับลูกเต๋า 3D ทันที">
                                   <span class="btn-sparkle-star">🎲</span>
                                   <span class="btn-text">ครบพร้อมแลก! (กดแลกทันที)</span>
                                   <span class="btn-sparkle-tag">FREE</span>
                               </button>`
                            : `<span style="background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">ขาดอีก ${missingDiceCount} ชนิด</span>`
                        }
                    </div>
                    <div class="shadow-horizontal-strip">
                        ${diceMats.map(m => `
                            <div class="shadow-strip-pill ${m.isReady ? 'is-ready' : 'is-missing'}">
                                <div style="font-size:14px; line-height:1;">${m.icon}</div>
                                <div style="font-size:9.5px; font-weight:800; color:${m.color}; margin-top:2px;">${m.name}</div>
                                <div style="font-size:10.5px; font-weight:900; color:${m.isReady ? '#34d399' : '#fca5a5'}; margin-top:1px;">${m.owned}/${m.req}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Exchange Target Dice Card (Bright & Clickable if Ready | Dimmed & Unclickable if Incomplete) -->
                <div class="event-target-card dice-card ${canExchangeDice ? 'ready-to-exchange' : 'not-ready'}" style="margin-top:6px; padding:10px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
                        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                            <div style="width:36px; height:36px; border-radius:10px; background:rgba(0,229,255,0.18); border:2px solid #00e5ff; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">🎲</div>
                            <div style="min-width:0;">
                                <div style="font-size:12px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">🎲 ${dice.name || 'ลูกเต๋า 3D แรร์'}</div>
                                <div style="font-size:10px; color:#cbd5e1;">${canExchangeDice ? 'สะสมเงาครบแล้ว กดแลกรับลูกเต๋าได้ทันที!' : 'สะสมเงาให้ครบทั้ง 5 สีเพื่อปลดล็อกปุ่มแลก'}</div>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn-lgr-exchange-hero ${canExchangeDice ? 'is-ready dice-ready' : 'is-disabled'}"
                        onclick="${canExchangeDice ? `checkAndShowShadowCompleteModal('DICE')` : ''}"
                        ${canExchangeDice ? '' : 'disabled'}>
                        <span class="hero-shine-sweep"></span>
                        <span class="hero-btn-content">
                            ${canExchangeDice ? '✨ 🎲 กดแลกรับลูกเต๋า 3D ทันที! ⚡ ✨' : `🔒 เงายังไม่ครบ (ขาดอีก ${missingDiceCount} ชนิด)`}
                        </span>
                    </button>
                </div>
            </div>

            <!-- Right 6 Dice Gacha Pack Cards Grid -->
            <div class="event-packs-grid">
                <div class="gacha-pack-shop-card is-special" onclick="rollSeparatedEventGacha('DICE', 1, 'DIAMOND', 'SPECIAL', '💎 ${costSingle}')">
                    <div class="pack-card-header-bar">แพ็คลูกเต๋าพิเศษ (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มชิ้นส่วนเงาลูกเต๋า<br>& ลุ้นลูกเต๋า 3D (+1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costSingle.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('DICE', 1, 'GOLD', 'NORMAL', '🪙 30,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มเต๋าทั่วไป (+1)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">1</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงาลูกเต๋า<br>ระดับ A ~ A+ (1 ชิ้น)</div>
                    </div>
                    <div class="pack-card-price-btn">🪙 30,000</div>
                </div>

                <div class="gacha-pack-shop-card" onclick="rollSeparatedEventGacha('DICE', 5, 'GOLD', 'NORMAL', '🪙 120,000')">
                    <div class="pack-card-header-bar">ชุดสุ่มเต๋าทั่วไป (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">สุ่มวัตถุดิบเงาลูกเต๋า<br>แบบแพ็คสุดคุ้ม 5 ชิ้น!</div>
                    </div>
                    <div class="pack-card-price-btn">🪙 120,000</div>
                </div>

                <div class="gacha-pack-shop-card is-event-hot" onclick="rollSeparatedEventGacha('DICE', 5, 'DIAMOND', 'SPECIAL', '💎 ${costEvent5}')">
                    <span class="pack-card-event-flag">EVENT</span>
                    <div class="pack-card-header-bar">แพ็คลูกเต๋าพิเศษ (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🎲</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">แพ็คลูกเต๋ายอดนิยม!<br>เปิดสุ่มลูกเต๋า 5 ชิ้น (ลด 10%)</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costEvent5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('DICE', 5, 'DIAMOND', 'PREMIUM', '💎 ${costPremium5}')">
                    <div class="pack-card-header-bar">ชุดเต๋าพรีเมียม (+5)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">💎</span><span class="mini-foil-qty">5</span></div>
                        <div class="pack-card-desc">เรตอัปเงาเต๋า A+ / S<br>& ลุ้นเต๋า 3D แรร์ 5 ชิ้น</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium5.toLocaleString()}</div>
                </div>

                <div class="gacha-pack-shop-card is-premium" onclick="rollSeparatedEventGacha('DICE', 10, 'DIAMOND', 'PREMIUM', '💎 ${costPremium10}')">
                    <span class="pack-card-event-flag">HOT</span>
                    <div class="pack-card-header-bar">ชุดเต๋าพรีเมียม (+10)</div>
                    <div class="pack-card-mid">
                        <div class="pack-mini-foil dice-foil"><span class="mini-foil-icon">🔥</span><span class="mini-foil-qty">10</span></div>
                        <div class="pack-card-desc">แพ็คใหญ่ลูกเต๋า 10 ชิ้น<br>โอกาสออกลูกเต๋าแรร์สูงสุด!</div>
                    </div>
                    <div class="pack-card-price-btn">💎 ${costPremium10.toLocaleString()}</div>
                </div>
            </div>
        `;
    }
}

window.openEventRatesInfoPopup = function(category = 'FRAME') {
    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const isDice = category === 'DICE';
    const title = isDice ? '📊 อัตราการสุ่มอีเวนต์ลูกเต๋า 3D' : '📊 อัตราการสุ่มอีเวนต์กรอบรูป';
    const jackpotLabel = isDice ? '🎲 แจ็คพอตลูกเต๋า 3D เป้าหมาย' : '👑 แจ็คพอตกรอบรูประดับ SS+ / S+';
    const msg = [
        `⬛ เงาสีดำ ระดับ A : ${ev.rate_shadow_black ?? 90}% (Weight)`,
        `🟥 เงาสีแดง ระดับ A : ${ev.rate_shadow_red ?? 80}% (Weight)`,
        `🟧 เงาสีส้ม ระดับ A : ${ev.rate_shadow_orange ?? 70}% (Weight)`,
        `🟦 เงาสีฟ้า ระดับ A+ : ${ev.rate_shadow_blue ?? 50}% (Weight)`,
        `🟨 เงาสีทอง ระดับ S : ${ev.rate_shadow_gold ?? 10}% (Weight)`,
        `✨ การ์ดปลุกพลังพิเศษ S : ${ev.rate_shadow_special ?? 15}% (Weight)`,
        `${jackpotLabel} : ${ev.rate_splus ?? 3}% (แพ็คพรีเมียมเรตคูณ 2!)`
    ].join('\n');
    showInGameAlert(msg, title, isDice ? '🎲' : '👑');
};


// =========================================================================
// 🌟 SHADOW COMPLETE CELEBRATION POPUP & INSTANT EXCHANGE LOGIC
// =========================================================================
let pendingShadowCompleteCategory = 'FRAME';
let pendingShadowCompleteTargetId = 1;
let pendingShadowCompleteGrade = 'SS+';

window.checkAndShowShadowCompleteModal = function(category = 'FRAME') {
    const ev = currentEventGachaData || (typeof getDefaultFallbackEventData === 'function' ? getDefaultFallbackEventData() : {});
    const uMats = ev.user_materials || {};
    const isDice = category === 'DICE';

    let canExchange = false;
    let targetItem = null;
    let mats = [];

    if (isDice) {
        const diceReqs = ev.dice_reqs || (ev.target_requirements ? ev.target_requirements.dice_shadows : {}) || {};
        mats = buildShadowMatsArray(uMats, diceReqs, { black: 15, red: 15, orange: 15, blue: 10, gold: 4 });
        canExchange = mats.every(m => m.isReady);
        targetItem = ev.target_dice || { id: 1, name: 'ลูกเต๋านีออนมังกรทอง 3D', grade: 'SS+', dice_control: 85 };
        pendingShadowCompleteCategory = 'DICE';
        pendingShadowCompleteTargetId = targetItem.id || 1;
        pendingShadowCompleteGrade = targetItem.grade || 'SS+';
    } else {
        const reqs = ev.reqs || (ev.target_requirements ? ev.target_requirements.character_shadows : {}) || {};
        mats = buildShadowMatsArray(uMats, reqs, { black: 25, red: 25, orange: 20, blue: 15, gold: 8 });
        canExchange = mats.every(m => m.isReady);
        targetItem = ev.target_character || { id: 1, name: 'ดาราจักรเนบิวลา SS+', grade: 'SS+' };
        pendingShadowCompleteCategory = 'FRAME';
        pendingShadowCompleteTargetId = targetItem.id || 1;
        pendingShadowCompleteGrade = targetItem.grade || 'SS+';
    }

    if (!canExchange) return false;

    const popup = document.getElementById('modal-shadow-complete-popup');
    if (!popup) return false;

    const headingEl = document.getElementById('shadow-complete-heading');
    const subEl = document.getElementById('shadow-complete-sub');
    const itemCardEl = document.getElementById('shadow-complete-item-card');
    const chipsBarEl = document.getElementById('shadow-complete-chips-bar');
    const btnLabel = document.getElementById('btn-complete-redeem-label');

    if (headingEl) {
        headingEl.innerHTML = isDice
            ? '🎉 สะสมชิ้นส่วนเงาลูกเต๋าครบแล้ว! 🎲'
            : '🎉 สะสมการ์ดเงากรอบรูปครบ 5 สีแล้ว! 👑';
    }
    if (subEl) {
        subEl.innerText = isDice
            ? 'สะสมชิ้นส่วนเงาครบตามเงื่อนไข 100% พร้อมแลกรับลูกเต๋า 3D แรร์ได้ทันที!'
            : 'สะสมการ์ดเงาครบทั้ง 5 ชนิด 100% พร้อมแลกรับกรอบรูปตัวละครระดับ SS+ ทันที!';
    }

    if (itemCardEl) {
        if (isDice) {
            itemCardEl.innerHTML = `
                <div class="complete-item-preview dice-theme">
                    <div class="complete-item-art">
                        ${targetItem.image_url ? `<img src="${targetItem.image_url}" alt="${targetItem.name}" style="width:60px; height:60px; object-fit:contain;">` : '<div class="dice-3d-glyph">🎲</div>'}
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge">3D DICE • เกรด ${targetItem.grade || 'SS+'}</div>
                        <div class="complete-item-name">${targetItem.name || 'ลูกเต๋านีออนมังกรทอง 3D'}</div>
                        <div class="complete-item-desc">🎲 ควบคุมเต๋าแม่นยำ +${targetItem.dice_control || 85}% • เอฟเฟกต์ลูกเต๋า 3D แสงนีออนสุดอลังการ</div>
                    </div>
                </div>
            `;
        } else {
            const avatarUrl = targetItem.avatar_url || (typeof DEFAULT_USER !== 'undefined' ? DEFAULT_USER.avatar_url : '') || 'avatars/avatar_01.png';
            itemCardEl.innerHTML = `
                <div class="complete-item-preview frame-theme">
                    <div class="complete-item-art frame-art">
                        <div class="complete-frame-ring-spin"></div>
                        <img src="${avatarUrl}" alt="${targetItem.name}" onerror="this.src='avatars/avatar_01.png';">
                    </div>
                    <div class="complete-item-details">
                        <div class="complete-item-badge">👑 กรอบรูปตัวละครระดับ ${targetItem.grade || 'SS+'}</div>
                        <div class="complete-item-name">${targetItem.name || 'ดาราจักรเนบิวลา SS+'}</div>
                        <div class="complete-item-desc">⚡ ${targetItem.skill_name || 'คุมลูกเต๋าแม่นยำสูง + ส่วนลดค่าผ่านทาง & ป้องกันการซื้อต่อเมือง'}</div>
                    </div>
                </div>
            `;
        }
    }

    if (chipsBarEl) {
        chipsBarEl.innerHTML = mats.map(m => `
            <div class="complete-chip-pill is-ready">
                <span class="chip-icon">${m.icon}</span>
                <span class="chip-name" style="color:${m.color}">${m.name}</span>
                <span class="chip-status">✔ ${m.owned}/${m.req}</span>
            </div>
        `).join('');
    }

    if (btnLabel) {
        btnLabel.innerText = isDice
            ? '✨ กดแลกรับลูกเต๋า 3D ทันที! 🎲'
            : '✨ กดแลกรับกรอบรูป SS+ ทันที! 👑';
    }

    popup.style.display = 'flex';

    if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
        try { window.soundEngine.playWin(); } catch (e) {}
    }

    return true;
};

window.triggerShadowCompleteRedeem = async function() {
    window.closeShadowCompletePopup();
    if (pendingShadowCompleteCategory === 'DICE') {
        await window.exchangeDiceAction(pendingShadowCompleteTargetId || 1);
    } else {
        await window.exchangeSPlusAction(pendingShadowCompleteTargetId || 1, pendingShadowCompleteGrade || 'SS+');
    }
};

window.closeShadowCompletePopup = function() {
    const pop = document.getElementById('modal-shadow-complete-popup');
    if (pop) pop.style.display = 'none';
};

window.exchangeSPlusAction = async function(charId, grade) {
    await window.doCraftFrameTier(grade || 'SS+', charId, 'event');
    await loadEventGachaData();
};

window.exchangeDiceAction = async function(diceId) {
    if (!window.apiClient) return;
    try {
        const res = await apiClient.exchangeDiceFromShadows(diceId);
        if (res && res.status === 'success') {
            showInGameAlert(res.message || 'แลกรับลูกเต๋าสำเร็จ!', 'ยินดีด้วย! 🎉', '🎲');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadEventGachaData();
        } else {
            showInGameAlert(res.message || 'สะสมเงายังไม่ครบตามที่กำหนด', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการแลกลูกเต๋า', 'ข้อผิดพลาด', '❌');
    }
};

// =========================================================================
// 💎 UNIFIED PURCHASE & CARD PACK CONFIRMATION MODAL (แสดงราคากี่เพชร/ทอง & ยืนยันก่อนเปิดการ์ด/ซื้อทุกหน้า)
// =========================================================================
let _pendingPurchaseConfirmCallback = null;

function ensurePurchaseConfirmModalDOM() {
    let modal = document.getElementById('modal-purchase-confirm');
    if (modal) return modal;

    modal = document.createElement('div');
    modal.id = 'modal-purchase-confirm';
    modal.className = 'modal-overlay';
    modal.style.cssText = 'display:none; z-index:125000; background:rgba(2,6,23,0.86); backdrop-filter:blur(8px); align-items:center; justify-content:center; padding:14px;';
    modal.innerHTML = `
        <div id="purchase-confirm-box" style="
            width:100%;
            max-width:430px;
            background:linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            border:2px solid #38bdf8;
            border-radius:20px;
            box-shadow:0 20px 55px rgba(0,0,0,0.85), 0 0 30px rgba(56,189,248,0.35);
            overflow:hidden;
            color:#f8fafc;
            font-family:inherit;
            animation:modalPopIn 0.2s cubic-bezier(0.16,1,0.3,1);
        ">
            <!-- Header -->
            <div id="purchase-confirm-header" style="
                background:linear-gradient(90deg, #0284c7 0%, #1d4ed8 100%);
                padding:12px 16px;
                display:flex;
                align-items:center;
                justify-content:space-between;
                border-bottom:1.5px solid rgba(255,255,255,0.2);
            ">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span id="purchase-confirm-header-icon" style="font-size:20px;">💎</span>
                    <span id="purchase-confirm-header-title" style="font-size:15.5px; font-weight:900; color:#fff; letter-spacing:0.3px;">ยืนยันการเปิดแพ็คการ์ด</span>
                </div>
                <button type="button" onclick="window.closePurchaseConfirmModal(false)" style="
                    width:30px; height:30px; border-radius:50%; border:1.5px solid rgba(255,255,255,0.4);
                    background:rgba(15,23,42,0.45); color:#fff; font-size:18px; font-weight:900;
                    cursor:pointer; display:flex; align-items:center; justify-content:center; line-height:1;
                ">&times;</button>
            </div>

            <!-- Body -->
            <div style="padding:16px 18px; display:flex; flex-direction:column; gap:12px;">
                <!-- Item Preview Card -->
                <div style="
                    background:rgba(15,23,42,0.75);
                    border:1.5px solid rgba(148,163,184,0.28);
                    border-radius:14px;
                    padding:12px 14px;
                    display:flex;
                    align-items:center;
                    gap:14px;
                ">
                    <div id="purchase-confirm-item-icon" style="
                        width:58px; height:58px; border-radius:14px;
                        background:radial-gradient(circle at 30% 30%, rgba(56,189,248,0.35), rgba(15,23,42,0.9));
                        border:2px solid #38bdf8;
                        display:flex; align-items:center; justify-content:center;
                        font-size:30px; flex-shrink:0;
                        box-shadow:0 4px 14px rgba(0,0,0,0.4);
                    ">👑</div>
                    <div style="min-width:0; flex:1; text-align:left;">
                        <div id="purchase-confirm-badge" style="
                            display:inline-block; font-size:10px; font-weight:900;
                            padding:2px 8px; border-radius:999px;
                            background:rgba(56,189,248,0.2); color:#38bdf8;
                            border:1px solid rgba(56,189,248,0.45); margin-bottom:4px;
                        ">ตรวจสอบราคาก่อนยืนยัน</div>
                        <div id="purchase-confirm-item-name" style="font-size:15.5px; font-weight:900; color:#fff; line-height:1.25;">แพ็คการ์ดกรอบพิเศษ (+1 ใบ)</div>
                        <div id="purchase-confirm-item-desc" style="font-size:12px; color:#cbd5e1; margin-top:3px; line-height:1.35;">สุ่มการ์ดกรอบรูปพิเศษ & การ์ดเงา (+1 ใบ)</div>
                    </div>
                </div>

                <!-- Prominent Price Display Box (ราคากี่เพชร / กี่ทอง) -->
                <div id="purchase-confirm-price-box" style="
                    background:linear-gradient(135deg, rgba(2,132,199,0.24) 0%, rgba(15,23,42,0.92) 100%);
                    border:2px solid #38bdf8;
                    border-radius:14px;
                    padding:12px 14px;
                    text-align:center;
                    box-shadow:inset 0 0 18px rgba(56,189,248,0.15);
                ">
                    <div style="font-size:11.5px; font-weight:800; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px;">ราคาที่ใช้ในการทำรายการนี้</div>
                    <div id="purchase-confirm-price-big" style="
                        font-size:24px; font-weight:900; color:#38bdf8;
                        margin:4px 0 8px 0;
                        text-shadow:0 2px 10px rgba(56,189,248,0.45);
                        display:flex; align-items:center; justify-content:center; gap:6px;
                    ">💎 50 เพชร</div>

                    <div style="
                        display:flex; justify-content:space-between; align-items:center;
                        border-top:1px dashed rgba(148,163,184,0.28);
                        padding-top:8px; font-size:12px; color:#cbd5e1;
                    ">
                        <span>ยอดคงเหลือของคุณ:</span>
                        <b id="purchase-confirm-balance-now" style="color:#fff; font-size:12.5px;">💎 0 เพชร</b>
                    </div>
                    <div style="
                        display:flex; justify-content:space-between; align-items:center;
                        margin-top:4px; font-size:12px; color:#cbd5e1;
                    ">
                        <span>คงเหลือหลังยืนยัน:</span>
                        <b id="purchase-confirm-balance-after" style="color:#4ade80; font-size:12.5px;">💎 0 เพชร</b>
                    </div>
                </div>

                <!-- Buttons -->
                <div style="display:grid; grid-template-columns:1fr 1.45fr; gap:10px; margin-top:2px;">
                    <button type="button" onclick="window.closePurchaseConfirmModal(false)" style="
                        padding:11px 12px; border-radius:12px;
                        border:1.5px solid #475569;
                        background:linear-gradient(180deg, #334155 0%, #1e293b 100%);
                        color:#e2e8f0; font-size:13.5px; font-weight:800;
                        cursor:pointer; transition:transform 0.12s;
                    ">❌ ยกเลิก</button>
                    <button type="button" id="purchase-confirm-ok-btn" onclick="window.closePurchaseConfirmModal(true)" style="
                        padding:11px 14px; border-radius:12px;
                        border:1.5px solid #bae6fd;
                        background:linear-gradient(180deg, #38bdf8 0%, #0284c7 100%);
                        color:#fff; font-size:14px; font-weight:900;
                        cursor:pointer; box-shadow:0 6px 18px rgba(2,132,199,0.5);
                        transition:transform 0.12s;
                    ">✅ ยืนยันเปิดการ์ด</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    return modal;
}

window.showPurchaseConfirmModal = function(opts = {}, onConfirm = null) {
    const modal = ensurePurchaseConfirmModalDOM();
    _pendingPurchaseConfirmCallback = onConfirm;

    const currency = String(opts.currency || 'DIAMOND').toUpperCase();
    const price = Math.max(0, Number(opts.price || 0));
    const isGold = currency === 'GOLD';
    const isThb = currency === 'THB';

    const currIcon = isThb ? '฿' : (isGold ? '🪙' : '💎');
    const currUnit = isThb ? 'บาท' : (isGold ? 'ทอง' : 'เพชร');
    const priceFormatted = isThb ? price.toFixed(2) : price.toLocaleString();
    const fullPriceText = `${currIcon} ${priceFormatted} ${currUnit}`;

    const userDia = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? Number(DEFAULT_USER.diamond || 0) : 0;
    const userGold = (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) ? Number(DEFAULT_USER.gold || 0) : 0;
    const currentBal = isGold ? userGold : userDia;
    const afterBal = currentBal - price;
    const isEnough = isThb ? true : (currentBal >= price);

    const accentColor = isGold ? '#f59e0b' : (isThb ? '#10b981' : '#38bdf8');
    const headerGrad = isGold
        ? 'linear-gradient(90deg, #d97706 0%, #b45309 100%)'
        : (isThb ? 'linear-gradient(90deg, #059669 0%, #047857 100%)' : 'linear-gradient(90deg, #0284c7 0%, #1d4ed8 100%)');

    const box = document.getElementById('purchase-confirm-box');
    const header = document.getElementById('purchase-confirm-header');
    const headerIcon = document.getElementById('purchase-confirm-header-icon');
    const headerTitle = document.getElementById('purchase-confirm-header-title');
    const itemIcon = document.getElementById('purchase-confirm-item-icon');
    const badge = document.getElementById('purchase-confirm-badge');
    const itemName = document.getElementById('purchase-confirm-item-name');
    const itemDesc = document.getElementById('purchase-confirm-item-desc');
    const priceBox = document.getElementById('purchase-confirm-price-box');
    const priceBig = document.getElementById('purchase-confirm-price-big');
    const balNow = document.getElementById('purchase-confirm-balance-now');
    const balAfter = document.getElementById('purchase-confirm-balance-after');
    const okBtn = document.getElementById('purchase-confirm-ok-btn');

    if (box) box.style.borderColor = accentColor;
    if (header) header.style.background = headerGrad;
    if (headerIcon) headerIcon.innerText = opts.headerIcon || currIcon;
    if (headerTitle) headerTitle.innerText = opts.headerTitle || 'ยืนยันราคาก่อนเปิดการ์ด / สั่งซื้อ';

    if (itemIcon) {
        itemIcon.style.borderColor = accentColor;
        itemIcon.innerHTML = opts.iconHtml || `<span style="font-size:30px;">${opts.icon || '🎴'}</span>`;
    }
    if (badge) {
        badge.style.color = accentColor;
        badge.style.borderColor = accentColor;
        badge.style.background = isGold ? 'rgba(245,158,11,0.18)' : 'rgba(56,189,248,0.18)';
        badge.innerText = opts.badgeText || `ใช้ ${fullPriceText}`;
    }
    if (itemName) itemName.innerText = opts.title || 'แพ็คการ์ดสุ่มไอเทม';
    if (itemDesc) itemDesc.innerText = opts.subtitle || 'กรุณาตรวจสอบราคาและกดยืนยันเพื่อทำรายการ';

    if (priceBox) {
        priceBox.style.borderColor = accentColor;
        priceBox.style.background = isGold
            ? 'linear-gradient(135deg, rgba(217,119,6,0.22) 0%, rgba(15,23,42,0.92) 100%)'
            : 'linear-gradient(135deg, rgba(2,132,199,0.24) 0%, rgba(15,23,42,0.92) 100%)';
    }
    if (priceBig) {
        priceBig.style.color = isGold ? '#fde047' : '#38bdf8';
        priceBig.innerText = `ราคา ${fullPriceText}`;
    }

    if (balNow) {
        balNow.innerText = isThb
            ? `💎 ${userDia.toLocaleString()} เพชร | 🪙 ${userGold.toLocaleString()} ทอง`
            : `${currIcon} ${currentBal.toLocaleString()} ${currUnit}`;
    }
    if (balAfter) {
        if (isThb) {
            balAfter.style.color = '#4ade80';
            balAfter.innerText = 'ชำระผ่าน QR พร้อมเพย์ / ช่องทางที่เลือก';
        } else if (isEnough) {
            balAfter.style.color = '#4ade80';
            balAfter.innerText = `${currIcon} ${afterBal.toLocaleString()} ${currUnit}`;
        } else {
            balAfter.style.color = '#f87171';
            balAfter.innerText = `⚠️ ${currUnit}ไม่เพียงพอ (ขาดอีก ${(price - currentBal).toLocaleString()} ${currUnit})`;
        }
    }

    if (okBtn) {
        const actionVerb = opts.confirmLabel || 'ยืนยันเปิดการ์ด';
        okBtn.innerText = `✅ ${actionVerb} (${currIcon} ${priceFormatted})`;
        okBtn.style.background = isGold
            ? 'linear-gradient(180deg, #fbbf24 0%, #d97706 100%)'
            : 'linear-gradient(180deg, #38bdf8 0%, #0284c7 100%)';
        okBtn.style.color = isGold ? '#0f172a' : '#ffffff';
        okBtn.style.borderColor = isGold ? '#fde68a' : '#bae6fd';
    }

    modal.style.display = 'flex';
};

window.closePurchaseConfirmModal = function(confirmed = false) {
    const modal = document.getElementById('modal-purchase-confirm');
    if (modal) modal.style.display = 'none';
    const cb = _pendingPurchaseConfirmCallback;
    _pendingPurchaseConfirmCallback = null;
    if (confirmed && typeof cb === 'function') {
        cb();
    }
};

window.rollSeparatedEventGacha = async function(category = 'FRAME', count = 5, currency = 'DIAMOND', packTier = 'SPECIAL', displayCost = '', skipConfirm = false) {
    if (!window.apiClient) return;

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const costSingle = Number(ev.cost_diamond || 50);
    const currUpper = String(currency || 'DIAMOND').toUpperCase();
    const tierUpper = String(packTier || 'SPECIAL').toUpperCase();
    const isDice = String(category || 'FRAME').toUpperCase() === 'DICE';

    // คำนวณราคาจริง (กี่เพชร / กี่ทอง) เพื่อให้แสดงในป๊อปอัปยืนยันอย่างแม่นยำ 100%
    let numericPrice = 0;
    if (displayCost) {
        const parsed = parseInt(String(displayCost).replace(/[^0-9]/g, ''), 10);
        if (!isNaN(parsed) && parsed > 0) numericPrice = parsed;
    }
    if (!numericPrice) {
        if (currUpper === 'GOLD') {
            numericPrice = count === 5 ? 120000 : (30000 * count);
        } else if (tierUpper === 'PREMIUM') {
            numericPrice = count >= 10 ? Math.round(costSingle * 10 * 1.35) : Math.round(costSingle * 5 * 1.45);
        } else {
            numericPrice = count >= 5 ? Math.round(costSingle * count * 0.9) : (costSingle * count);
        }
    }

    // ชื่อแพ็คและรายละเอียดให้ตรงกับการ์ดที่กด
    let packTitle = '';
    let packDesc = '';
    let packIcon = isDice ? '🎲' : '👑';
    if (isDice) {
        if (currUpper === 'GOLD') {
            packTitle = `ชุดสุ่มเต๋าทั่วไป (+${count} ชิ้น)`;
            packDesc = `สุ่มวัตถุดิบเงาลูกเต๋าระดับ A ~ A+ จำนวน ${count} ชิ้น`;
        } else if (tierUpper === 'PREMIUM') {
            packTitle = `ชุดเต๋าพรีเมียม (+${count} ชิ้น)`;
            packDesc = `เรตอัปเงาเต๋า A+ / S & ลุ้นลูกเต๋า 3D แรร์ จำนวน ${count} ชิ้น`;
            packIcon = count >= 10 ? '🔥' : '💎';
        } else {
            packTitle = `แพ็คลูกเต๋าพิเศษ (+${count} ชิ้น)`;
            packDesc = `สุ่มชิ้นส่วนเงาลูกเต๋า & ลุ้นลูกเต๋า 3D แรร์ จำนวน ${count} ชิ้น`;
        }
    } else {
        if (currUpper === 'GOLD') {
            packTitle = `ชุดการ์ดกรอบทั่วไป (+${count} ใบ)`;
            packDesc = `สุ่มวัตถุดิบการ์ดเงาระดับ A ~ A+ จำนวน ${count} ใบ`;
            packIcon = '🃏';
        } else if (tierUpper === 'PREMIUM') {
            packTitle = `ชุดกรอบพรีเมียม (+${count} ใบ)`;
            packDesc = `เรตอัปเงาฟ้า A+ / ทอง S & ลุ้นกรอบ SS+ จำนวน ${count} ใบ`;
            packIcon = count >= 10 ? '🌟' : '✨';
        } else {
            packTitle = `แพ็คการ์ดกรอบพิเศษ (+${count} ใบ)`;
            packDesc = `สุ่มการ์ดกรอบรูปพิเศษ & การ์ดเงา จำนวน ${count} ใบ`;
        }
    }

    if (!skipConfirm) {
        window.showPurchaseConfirmModal({
            headerIcon: currUpper === 'GOLD' ? '🪙' : '💎',
            headerTitle: isDice ? 'ยืนยันราคาเปิดแพ็คลูกเต๋า 3D' : 'ยืนยันราคาเปิดแพ็คการ์ดกรอบรูป',
            icon: packIcon,
            badgeText: `เปิดแพ็ค ${count} ${isDice ? 'ชิ้น' : 'ใบ'}`,
            title: packTitle,
            subtitle: packDesc,
            currency: currUpper,
            price: numericPrice,
            confirmLabel: 'ยืนยันเปิดการ์ด'
        }, () => {
            window.closeGachaVideoPopup();
            window.rollSeparatedEventGacha(category, count, currency, packTier, displayCost, true);
        });
        return;
    }

    lastGachaPullMeta = {
        source: 'EVENT',
        category,
        count,
        currency,
        packTier,
        displayCost: displayCost || (currUpper === 'GOLD' ? `🪙 ${numericPrice.toLocaleString()}` : `💎 ${numericPrice.toLocaleString()}`)
    };

    try {
        const res = await apiClient.rollEventGacha(count, category, currency, packTier);
        if (res && res.status === 'success') {
            if (res.user) {
                DEFAULT_USER.diamond = Number(res.user.diamond ?? DEFAULT_USER.diamond ?? 0);
                DEFAULT_USER.gold = Number(res.user.gold ?? DEFAULT_USER.gold ?? 0);
                updateUserBar(DEFAULT_USER);
            } else {
                apiClient.getProfile().then(prof => {
                    if (prof && prof.data) {
                        Object.assign(DEFAULT_USER, prof.data);
                        updateUserBar(DEFAULT_USER);
                    }
                }).catch(() => {});
            }

            if (res.event) {
                currentEventGachaData = res.event;
                renderSeparatedEventGachaUIs(res.event);
            } else {
                loadEventGachaData();
            }

            const actualCostLabel = (res.currency === 'GOLD')
                ? `🪙 ${Number(res.cost_spent || res.gold_spent || numericPrice).toLocaleString()}`
                : `💎 ${Number(res.cost_spent || res.diamonds_spent || numericPrice).toLocaleString()}`;
            lastGachaPullMeta.displayCost = actualCostLabel;

            window.openVideoStyleGachaPopup(res.drops || [], category, res.total_cards || count, actualCostLabel);
        } else {
            showInGameAlert((res && res.message) ? res.message : 'ทรัพยากรไม่เพียงพอสำหรับการสุ่ม', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'กรุณาเข้าสู่ระบบหรือตรวจสอบเพชร/ทองก่อนทำการสุ่ม', 'แจ้งเตือนการสุ่ม', '⚠️');
    }
};

window.rollEventGachaAction = function(count = 1) {
    return window.rollSeparatedEventGacha('FRAME', count, 'DIAMOND', 'SPECIAL');
};

// =========================================================================
// 🎴 VIDEO-STYLE 2-STAGE PACK TEAR & HORIZONTAL CARD REVEAL POPUP (00:02 - 00:15)
// =========================================================================
window.openVideoStyleGachaPopup = function(drops, category = 'FRAME', cardCount = 5, againCostLabel = '💎 225') {
    const popup = document.getElementById('modal-gacha-pack-popup');
    const stagePack = document.getElementById('gacha-popup-stage-pack');
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const foilBox = document.getElementById('gacha-foil-pack-box');
    const foilInner = document.getElementById('gacha-foil-pack-inner');
    const foilCount = document.getElementById('gacha-foil-pack-count');
    const againCostEl = document.getElementById('gacha-popup-again-cost');
    const inspectBar = document.getElementById('gacha-card-inspect-bar');

    if (!popup || !stagePack || !stageCards) return;

    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    clearGachaCardRevealTimers();

    pendingGachaRevealDrops = Array.isArray(drops) ? drops : [];
    pendingGachaRevealCategory = (category === 'DICE') ? 'DICE' : 'FRAME';
    isAllRevealedCardsFlipped = false;

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const isDice = pendingGachaRevealCategory === 'DICE';

    if (foilBox) {
        foilBox.classList.remove('tearing');
        foilBox.classList.toggle('dice-theme', isDice);
    }
    if (foilCount) {
        foilCount.innerText = String(pendingGachaRevealDrops.length || cardCount || 1);
    }
    if (againCostEl) {
        againCostEl.innerText = againCostLabel || lastGachaPullMeta.displayCost || '💎 225';
    }
    if (inspectBar) {
        inspectBar.style.display = 'none';
    }

    if (foilInner) {
        if (isDice) {
            const dName = ev.target_dice?.name || 'ลูกเต๋า 3D พิเศษ';
            foilInner.innerHTML = `
                <div style="font-size:11px; font-weight:900; color:#bae6fd; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">3D DICE EVENT</div>
                <div style="font-size:15px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">แพ็คลูกเต๋าพิเศษ</div>
                <div style="width:82px; height:82px; border-radius:18px; background:radial-gradient(circle, rgba(0,229,255,0.45), #0f172a); border:2.5px solid #7dd3fc; display:flex; align-items:center; justify-content:center; font-size:44px; box-shadow:0 0 22px rgba(0,229,255,0.7);">🎲</div>
                <div style="font-size:10.5px; font-weight:800; color:#fde047; margin-top:8px; text-shadow:0 1px 3px #000;">${dName}</div>
            `;
        } else {
            const cName = ev.target_character?.name || 'ดาราจักรเนบิวลา SS+';
            const cImg = ev.target_character?.avatar_url || 'avatars/avatar_01.png';
            foilInner.innerHTML = `
                <div style="font-size:11px; font-weight:900; color:#fef08a; letter-spacing:0.5px; text-shadow:0 1px 3px #000;">FRAME EVENT</div>
                <div style="font-size:15px; font-weight:900; color:#fff; margin:3px 0 8px 0; text-shadow:0 2px 6px #000; line-height:1.2;">แพ็คการ์ดพิเศษ</div>
                <div style="width:84px; height:84px; border-radius:50%; border:3px solid #fde047; overflow:hidden; box-shadow:0 0 22px rgba(255,215,0,0.75); background:#0f172a;">
                    <img src="${cImg}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src='avatars/avatar_01.png';">
                </div>
                <div style="font-size:10.5px; font-weight:800; color:#fef08a; margin-top:8px; text-shadow:0 1px 3px #000;">${cName}</div>
            `;
        }
    }

    stageCards.style.display = 'none';
    stagePack.style.display = 'flex';
    popup.style.display = 'flex';

    if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        try { window.soundEngine.playClick(); } catch (e) {}
    }

    // หากผู้เล่นไม่ทันแตะซองใน 1.35 วินาที ระบบจะฉีกซองเปิดการ์ดให้อัตโนมัติเหมือนในคลิป!
    gachaPackAutoTearTimeout = setTimeout(() => {
        if (stagePack.style.display !== 'none') {
            window.tearOpenGachaPackNow();
        }
    }, 1350);
};

window.tearOpenGachaPackNow = function() {
    const stagePack = document.getElementById('gacha-popup-stage-pack');
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const foilBox = document.getElementById('gacha-foil-pack-box');
    const flashEl = document.getElementById('gacha-tear-flash');
    if (!stagePack || !stageCards) return;

    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    if (foilBox && foilBox.classList.contains('tearing')) return;
    if (foilBox) foilBox.classList.add('tearing');

    if (flashEl) {
        flashEl.classList.add('active');
        setTimeout(() => flashEl.classList.remove('active'), 320);
    }
    if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        try { window.soundEngine.playClick(); } catch (e) {}
    }

    setTimeout(() => {
        stagePack.style.display = 'none';
        renderRevealedCardsStage();
        stageCards.style.display = 'flex';
    }, 240);
};

function buildOrnateCardBackEmblemSvg(rarityRaw, cardIsDice, isGrandAura, accentHex) {
    const primaryGold = isGrandAura ? '#fde047' : (rarityRaw === 'S' ? '#fbbf24' : (rarityRaw === 'A+' ? '#38bdf8' : '#fcd34d'));
    const secondaryGlow = isGrandAura ? '#f43f5e' : (cardIsDice ? '#00e5ff' : (accentHex || '#f59e0b'));
    const coreIcon = cardIsDice ? '🎲' : (isGrandAura ? '👑' : (rarityRaw === 'S' ? '🌟' : '⚜️'));

    return `
        <div class="lgr-back-emblem-wrap" style="position:relative; width:64px; height:64px; margin:2px auto; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
            <svg viewBox="0 0 100 100" style="position:absolute; inset:0; width:100%; height:100%; overflow:visible; filter:drop-shadow(0 0 8px ${secondaryGlow});">
                <defs>
                    <radialGradient id="backCoreGrad_${rarityRaw}_${cardIsDice ? 'D' : 'F'}" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.95"/>
                        <stop offset="40%" stop-color="${primaryGold}" stop-opacity="0.85"/>
                        <stop offset="78%" stop-color="${secondaryGlow}" stop-opacity="0.65"/>
                        <stop offset="100%" stop-color="#0f172a" stop-opacity="0"/>
                    </radialGradient>
                </defs>
                <!-- Outer Sacred Sunburst Ring -->
                <circle cx="50" cy="50" r="44" fill="url(#backCoreGrad_${rarityRaw}_${cardIsDice ? 'D' : 'F'})" stroke="${primaryGold}" stroke-width="2" stroke-dasharray="5 3" opacity="0.9"/>
                <!-- Ornate Octagram Star Frame -->
                <polygon points="50,6 61,35 92,35 67,54 76,85 50,67 24,85 33,54 8,35 39,35" fill="none" stroke="${primaryGold}" stroke-width="1.6" opacity="0.65"/>
                <polygon points="50,14 75,25 86,50 75,75 50,86 25,75 14,50 25,25" fill="rgba(15,23,42,0.72)" stroke="${primaryGold}" stroke-width="2.2"/>
                <!-- Inner Filigree Ring -->
                <circle cx="50" cy="50" r="24" fill="radial-gradient(circle, ${secondaryGlow}, #090d16)" stroke="#ffffff" stroke-width="1.2" opacity="0.9"/>
                <!-- Corner Gems -->
                <circle cx="50" cy="10" r="3" fill="${primaryGold}"/>
                <circle cx="50" cy="90" r="3" fill="${primaryGold}"/>
                <circle cx="10" cy="50" r="3" fill="${primaryGold}"/>
                <circle cx="90" cy="50" r="3" fill="${primaryGold}"/>
            </svg>
            <div style="position:relative; z-index:2; font-size:26px; line-height:1; filter:drop-shadow(0 2px 6px rgba(0,0,0,0.9)) drop-shadow(0 0 10px ${primaryGold});">
                ${coreIcon}
            </div>
        </div>
    `;
}

function renderRevealedCardsStage() {
    const stageCards = document.getElementById('gacha-popup-stage-cards');
    const ribbonEl = document.getElementById('gacha-popup-ribbon-title');
    const rowEl = document.getElementById('gacha-popup-cards-row');
    const flipLabel = document.getElementById('gacha-popup-flip-label');
    if (!rowEl) return;

    // Enforce responsive container constraints & top/bottom close buttons via JS as well for 100% cache-proof display
    if (stageCards) {
        stageCards.style.maxWidth = 'min(100vw, 1060px)';
        stageCards.style.width = '100%';
        stageCards.style.minWidth = '0';
        stageCards.style.margin = '0 auto';
        stageCards.style.boxSizing = 'border-box';
        stageCards.style.overflow = 'hidden';

        const closeTopBtn = stageCards.querySelector('.gacha-stage-close-x');
        if (closeTopBtn) {
            closeTopBtn.innerHTML = `<span style="font-size:17px; line-height:1;">✕</span><span>ปิด</span>`;
            closeTopBtn.style.cssText = 'position:fixed !important; top:max(12px, env(safe-area-inset-top, 12px)) !important; right:max(16px, env(safe-area-inset-right, 16px)) !important; min-width:78px !important; width:auto !important; height:38px !important; padding:0 14px !important; border-radius:10px !important; background:linear-gradient(180deg, #ef4444 0%, #b91c1c 100%) !important; border:2.5px solid #fde047 !important; color:#fff !important; font-size:14.5px !important; font-weight:900 !important; display:inline-flex !important; align-items:center !important; justify-content:center !important; gap:6px !important; z-index:100999 !important; cursor:pointer !important; box-shadow:0 4px 14px rgba(0,0,0,0.75) !important;';
        }

        const bottomBar = stageCards.querySelector('.gacha-stage-bottom-bar');
        if (bottomBar && !bottomBar.querySelector('.close-pack')) {
            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.className = 'gacha-act-btn close-pack';
            closeBtn.onclick = () => window.closeGachaVideoPopup();
            closeBtn.style.cssText = 'padding:9px 18px; border-radius:12px; font-weight:900; font-size:clamp(12px, 1.4vw, 14.5px); background:linear-gradient(180deg, #ef4444 0%, #b91c1c 100%); border:2px solid #fde047; color:#fff; display:inline-flex; align-items:center; gap:6px; cursor:pointer;';
            closeBtn.innerHTML = `<span class="gacha-act-icon">✕</span><span>ปิด</span>`;
            bottomBar.appendChild(closeBtn);
        }
    }

    const isDice = pendingGachaRevealCategory === 'DICE';
    if (ribbonEl) {
        ribbonEl.innerText = isDice ? 'การ์ดลูกเต๋า 3D' : 'การ์ดกรอบรูป';
        ribbonEl.classList.toggle('dice-ribbon', isDice);
    }
    if (flipLabel) {
        flipLabel.innerText = 'ดูด้านหลัง';
    }

    const ev = currentEventGachaData || getDefaultFallbackEventData();
    const uMats = ev.user_materials || {};
    const drops = pendingGachaRevealDrops;
    const isCount10 = drops.length > 5;
    rowEl.classList.toggle('count-10', isCount10);
    rowEl.style.width = '100%';
    rowEl.style.maxWidth = isCount10 ? '840px' : '920px';
    rowEl.style.minWidth = '0';
    rowEl.style.boxSizing = 'border-box';

    clearGachaCardRevealTimers();

    // ระยะเวลาห่างกันต่อใบ (ค่าเริ่มต้น 1.0 วินาที หรือตามที่ตั้งค่าในหน้า Admin)
    const intervalSec = (window.ThaiAudio && typeof window.ThaiAudio.getCardRevealIntervalSec === 'function')
        ? window.ThaiAudio.getCardRevealIntervalSec()
        : 1.0;
    const intervalMs = Math.round(intervalSec * 1000);

    const cardRareFlags = [];

    rowEl.innerHTML = drops.map((d, idx) => {
        const rarityRaw = String(d.rarity || 'A').toUpperCase();
        const gradeClass = rarityRaw === 'SS+' ? 'grade-SSPLUS'
            : (rarityRaw === 'S+' ? 'grade-SPLUS'
            : (rarityRaw === 'S' ? 'grade-S'
            : (rarityRaw === 'A+' ? 'grade-APLUS' : 'grade-A')));

        const cardIsDice = isDice || d.type === 'DICE' || d.category === 'DICE';
        const isJackpot = d.type === 'CHARACTER' || d.type === 'DICE';
        const isEventFeatured = isJackpot
            || rarityRaw === 'SS+'
            || rarityRaw === 'S+'
            || d.material_code === 'SPECIAL_CARD'
            || String(d.name || '').includes('ปลุกพลังพิเศษ');
        const isSubtleSAura = (!isEventFeatured && rarityRaw === 'S');

        cardRareFlags[idx] = Boolean(isEventFeatured || isSubtleSAura);

        const auraSlotClass = isEventFeatured
            ? 'card-aura-ssplus'
            : (isSubtleSAura ? 'card-aura-s' : '');

        const ownedQty = d.material_code ? Number(uMats[d.material_code] || 0) : 1;
        const accentHex = d.color || (rarityRaw === 'SS+' || rarityRaw === 'S' ? '#ffd700' : (cardIsDice ? '#00e5ff' : '#4ade80'));

        // Front Center Artwork (No transform/filter bleed-through onto back face!)
        let centerArtHtml = '';
        if (cardIsDice) {
            if (d.image_url) {
                centerArtHtml = `<img src="${d.image_url}" style="width:66px; height:66px; object-fit:contain; position:relative;" onerror="this.outerHTML='<div style=\\'font-size:46px;position:relative;\\'>🎲</div>';">`;
            } else {
                const diceTint = d.color || '#00e5ff';
                centerArtHtml = `
                    <div style="width:64px; height:64px; border-radius:16px; background:radial-gradient(circle at 30% 30%, #fff, ${diceTint} 65%, #0f172a 100%); border:2.5px solid #fff; box-shadow:0 6px 16px rgba(0,0,0,0.55), 0 0 16px ${diceTint}; display:flex; align-items:center; justify-content:center; font-size:34px; position:relative;">
                        🎲
                    </div>
                `;
            }
        } else if (d.image_url || (d.material_code && d.material_code.startsWith('SHADOW_'))) {
            const ringUrl = d.image_url || '';
            const ringIcon = rarityRaw === 'SS+' || rarityRaw === 'S+' ? '👑' : (rarityRaw === 'S' ? '🌟' : '⚜️');
            centerArtHtml = `
                <div style="width:66px; height:66px; border-radius:50%; position:relative; display:inline-flex; align-items:center; justify-content:center; background:radial-gradient(circle, ${accentHex}44 0%, #1e293b 65%, #090d16 100%); border:2.5px solid ${accentHex}; box-shadow:0 0 16px ${accentHex}aa, inset 0 0 12px ${accentHex}66;">
                    ${ringUrl ? `<img src="${ringUrl}" style="position:absolute; inset:-6%; width:112%; height:112%; object-fit:contain; pointer-events:none;" alt="">` : ''}
                    <span style="font-size:24px; line-height:1; filter:drop-shadow(0 2px 4px rgba(0,0,0,0.85));">${ringIcon}</span>
                </div>
            `;
        } else {
            centerArtHtml = `<div style="font-size:44px; position:relative; text-shadow:0 4px 12px rgba(0,0,0,0.75);">${d.icon || '👑'}</div>`;
        }

        // Aura Visual Layers (S = subtle golden aura | SS+ / Event = spectacular radiant god-ray + plasma + star particles aura)
        let auraOverlayHtml = '';
        if (isEventFeatured) {
            const badgeText = (rarityRaw === 'SS+' || isJackpot) ? `👑 GRAND ${rarityRaw}` : `🌟 EVENT SPECIAL`;
            auraOverlayHtml = `
                <div class="lgr-aura-fx-container ssplus-event-aura" aria-hidden="true">
                    <div class="lgr-aura-godrays"></div>
                    <div class="lgr-aura-plasma-ring"></div>
                    <div class="lgr-aura-sparkles">
                        <span class="sp-1">✦</span>
                        <span class="sp-2">★</span>
                        <span class="sp-3">✨</span>
                        <span class="sp-4">✦</span>
                    </div>
                </div>
                <div class="lgr-card-floating-aura-badge ssplus-badge">${badgeText}</div>
            `;
        } else if (isSubtleSAura) {
            auraOverlayHtml = `
                <div class="lgr-aura-fx-container s-subtle-aura" aria-hidden="true">
                    <div class="lgr-aura-soft-halo"></div>
                    <div class="lgr-aura-sparkles">
                        <span class="sp-1">✦</span>
                        <span class="sp-3">✨</span>
                    </div>
                </div>
                <div class="lgr-card-floating-aura-badge s-badge">✨ RARE S</div>
            `;
        }

        const shortTopName = String(d.name || '').replace(/^การ์ด/, '').replace(/^เงา/, 'เงา');
        const subTag = isJackpot
            ? '🎉 รางวัลแจ็คพอตถาวร!'
            : (isEventFeatured ? '🌟 [การ์ดจัดกิจกรรมพิเศษ]' : '[อีเวนต์พิเศษ] วัตถุดิบแลก');

        const backEmblemHtml = buildOrnateCardBackEmblemSvg(rarityRaw, cardIsDice, isEventFeatured, accentHex);
        const backOwnedBadge = isJackpot
            ? `<div class="lgr-back-pill jackpot-pill">🎉 รางวัลถาวรพร้อมสวมใส่!</div>`
            : `<div class="lgr-back-pill">📦 สะสมในคลัง: <strong>${ownedQty.toLocaleString()}</strong> ชิ้น</div>`;
        const backUsageText = isJackpot
            ? (cardIsDice ? 'ลูกเต๋า 3D แรร์ประจำกิจกรรม เพิ่มความแม่นยำทอยเต๋าสูงสุด' : 'กรอบรูปตัวละครแรร์ประจำกิจกรรม พร้อมออร่าและสกิลพิเศษ')
            : (d.material_code === 'SPECIAL_CARD'
                ? 'การ์ดปลุกพลังกิจกรรม ใช้ปลุกพลังLv.30 หรือแลกรางวัลพิเศษ'
                : `สะสมการ์ดเงาครบ 5 สี เพื่อแลก${cardIsDice ? 'ลูกเต๋า 3D SS+' : 'กรอบรูป SS+'} ฟรี!`);

        const slotInlineWidth = isCount10
            ? 'width:100%; max-width:142px; min-width:0;'
            : 'flex:0 1 158px; width:calc((100% - 48px) / 5); max-width:158px; min-width:0;';

        return `
            <div id="gacha-reveal-slot-${idx}" class="gacha-lgr-card-slot card-awaiting-reveal ${auraSlotClass}" style="animation-delay:${(idx * intervalSec).toFixed(2)}s; ${slotInlineWidth}" onclick="inspectOrFlipSingleCard(this, ${idx})">
                ${auraOverlayHtml}
                <div class="gacha-lgr-card-inner">
                    <!-- FRONT FACE (ดูด้านหน้า) -->
                    <div class="gacha-lgr-card-face gacha-lgr-card-front ${gradeClass}">
                        ${(isEventFeatured || isSubtleSAura) ? '<div class="lgr-card-holo-sweep"></div>' : ''}
                        <div class="lgr-card-top-bar">
                            <span class="lgr-card-grade-letter">${rarityRaw}</span>
                            <span class="lgr-card-top-name">${shortTopName}</span>
                        </div>
                        <div class="lgr-card-art-area">
                            <div class="lgr-card-art-glow"></div>
                            ${centerArtHtml}
                        </div>
                        <div class="lgr-card-bottom-tag ${cardIsDice ? 'dice-tag' : ''}">
                            <div class="lgr-card-tag-sub">${subTag}</div>
                            <div class="lgr-card-tag-main">${d.name || 'การ์ดอีเวนต์'}</div>
                        </div>
                    </div>

                    <!-- BACK FACE (ดูด้านหลัง - ภาพด้านหลังสวยเด่น ไม่มีวงกลมดำทับข้อความ) -->
                    <div class="gacha-lgr-card-face gacha-lgr-card-back ${gradeClass}">
                        <div class="lgr-back-top-header">
                            <span class="lgr-back-grade-chip">GRADE ${rarityRaw}</span>
                            <span class="lgr-back-type-chip">${cardIsDice ? '🎲 3D DICE' : '👑 FRAME'}</span>
                        </div>

                        ${backEmblemHtml}

                        <div class="lgr-back-info-panel">
                            <div class="lgr-back-card-title">${d.name || 'การ์ดอีเวนต์พิเศษ'}</div>
                            ${backOwnedBadge}
                            <div class="lgr-back-card-desc">${backUsageText}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    // เปิดการ์ดทีละ 1 ใบ ห่างกันใบละ intervalSec (1.0 วิ) พร้อมเล่นเสียง "แซ๊บ!" ต่อใบ (5 ใบ = 5 แซ๊บ)
    drops.forEach((d, idx) => {
        const delayMs = idx * intervalMs;
        const tId = setTimeout(() => {
            const slotEl = document.getElementById(`gacha-reveal-slot-${idx}`);
            if (slotEl) {
                slotEl.classList.remove('card-awaiting-reveal');
                slotEl.classList.add('card-revealed-active', 'card-zap-burst');
                setTimeout(() => {
                    if (slotEl) slotEl.classList.remove('card-zap-burst');
                }, 380);
            }
            triggerSingleCardRevealSound(Boolean(cardRareFlags[idx]));
        }, delayMs);
        gachaCardRevealTimers.push(tId);
    });

    const completeCheckTimer = setTimeout(() => {
        window.checkAndShowShadowCompleteModal(isDice ? 'DICE' : 'FRAME');
    }, (drops.length * intervalMs) + 450);
    gachaCardRevealTimers.push(completeCheckTimer);
}

window.syncCardFaceVisibility = function(slotEl) {
    if (!slotEl) return;
    const isFlipped = slotEl.classList.contains('is-flipped');
    const frontEl = slotEl.querySelector('.gacha-lgr-card-front');
    const backEl = slotEl.querySelector('.gacha-lgr-card-back');
    if (frontEl) {
        frontEl.style.visibility = isFlipped ? 'hidden' : 'visible';
        frontEl.style.opacity = isFlipped ? '0' : '1';
        frontEl.style.pointerEvents = isFlipped ? 'none' : 'auto';
    }
    if (backEl) {
        backEl.style.visibility = isFlipped ? 'visible' : 'hidden';
        backEl.style.opacity = isFlipped ? '1' : '0';
        backEl.style.pointerEvents = isFlipped ? 'auto' : 'none';
    }
};

window.inspectOrFlipSingleCard = function(slotEl, idx) {
    if (slotEl) {
        slotEl.classList.toggle('is-flipped');
        window.syncCardFaceVisibility(slotEl);
    }
    const d = pendingGachaRevealDrops[idx];
    const inspectBar = document.getElementById('gacha-card-inspect-bar');
    if (d && inspectBar) {
        const ev = currentEventGachaData || getDefaultFallbackEventData();
        const owned = d.material_code ? Number((ev.user_materials || {})[d.material_code] || 0) : 1;
        inspectBar.style.display = 'block';
        inspectBar.innerHTML = `🔍 <strong>[${d.rarity || 'A'}] ${d.name}</strong> — ${d.material_code ? `สะสมในคลังแล้ว <strong>${owned}</strong> ชิ้น (ใช้แลกรางวัลใหญ่ในหน้าอีเวนต์)` : 'ไอเทมถาวรส่งเข้าที่เก็บการ์ดเรียบร้อยแล้ว!'}`;
    }
};

window.toggleFlipAllRevealedCards = function() {
    isAllRevealedCardsFlipped = !isAllRevealedCardsFlipped;
    document.querySelectorAll('#gacha-popup-cards-row .gacha-lgr-card-slot').forEach(el => {
        el.classList.toggle('is-flipped', isAllRevealedCardsFlipped);
        window.syncCardFaceVisibility(el);
    });
    const flipLabel = document.getElementById('gacha-popup-flip-label');
    if (flipLabel) {
        flipLabel.innerText = isAllRevealedCardsFlipped ? 'ดูด้านหน้า' : 'ดูด้านหลัง';
    }
};

window.closeGachaVideoPopup = function() {
    if (gachaPackAutoTearTimeout) {
        clearTimeout(gachaPackAutoTearTimeout);
        gachaPackAutoTearTimeout = null;
    }
    clearGachaCardRevealTimers();
    const popup = document.getElementById('modal-gacha-pack-popup');
    if (popup) popup.style.display = 'none';
};

window.repeatLastGachaPullAction = function() {
    if (lastGachaPullMeta.source === 'SHOP' && typeof window.doGacha === 'function') {
        window.doGacha(lastGachaPullMeta.count || 1);
        return;
    }
    window.rollSeparatedEventGacha(
        lastGachaPullMeta.category || 'FRAME',
        lastGachaPullMeta.count || 5,
        lastGachaPullMeta.currency || 'DIAMOND',
        lastGachaPullMeta.packTier || 'SPECIAL',
        lastGachaPullMeta.displayCost || ''
    );
};

// Upgrade legacy Shop Gacha reveal to also use the Video-Style 2-Stage Pack Popup!
window.showGachaCardsRevealModal = function(drops, packCount, totalCards, spent) {
    const hasDiceOnly = Array.isArray(drops) && drops.length > 0 && drops.every(d => d.type === 'DICE' || d.category === 'DICE');
    lastGachaPullMeta = {
        source: 'SHOP',
        category: hasDiceOnly ? 'DICE' : 'FRAME',
        count: packCount || 1,
        currency: 'DIAMOND',
        packTier: 'SPECIAL',
        displayCost: `💎 ${Number(spent || 100).toLocaleString()}`
    };
    window.openVideoStyleGachaPopup(drops || [], hasDiceOnly ? 'DICE' : 'FRAME', totalCards || (drops ? drops.length : 5), `💎 ${Number(spent || 100).toLocaleString()}`);
};

// =========================================================================
// 🧊 MAGIC CUBE SPINNER CONTROLLER (หมุนลูกบาศก์นำโชค)
// =========================================================================
let currentCubesData = { cubes: [], configs: [] };
let selectedCubeForSpin = null;
let magicCubeInterval = null;

window.openMagicCubeModal = async function() {
    openModal('modal-magic-cube');
    await loadMagicCubesData();
};

window.loadMagicCubesData = async function() {
    try {
        const res = await apiClient.getUserCubes();
        if (res && res.status === 'success' && res.data) {
            currentCubesData = res.data;
            renderMagicCubeSlots();
            renderUserCubesTray();
            startMagicCubeLiveTimers();
        }
    } catch (e) {
        console.error('Failed to load magic cubes:', e);
    }
};

function startMagicCubeLiveTimers() {
    if (magicCubeInterval) clearInterval(magicCubeInterval);
    magicCubeInterval = setInterval(() => {
        let hasSpinning = false;
        if (currentCubesData && currentCubesData.cubes) {
            for (const c of currentCubesData.cubes) {
                if (c.status === 'SPINNING') {
                    if (c.remaining_seconds > 0) {
                        c.remaining_seconds--;
                        hasSpinning = true;
                    } else {
                        c.status = 'READY';
                    }
                }
            }
        }
        updateMagicCubeSlotTimers();
        if (!hasSpinning && (!currentCubesData.cubes.some(c => c.status === 'SPINNING'))) {
            clearInterval(magicCubeInterval);
        }
    }, 1000);
}

function updateMagicCubeSlotTimers() {
    for (let slot = 1; slot <= 4; slot++) {
        const cube = currentCubesData.cubes.find(c => c.slot_index === slot && c.status !== 'CLAIMED');
        const timerEl = document.getElementById(`cube-slot-${slot}-timer`);
        if (timerEl && cube) {
            if (cube.status === 'READY') {
                timerEl.innerHTML = '<span style="color:#10b981; font-weight:800;">🎉 หมุนเสร็จแล้ว! แตะเพื่อเปิดรับรางวัล</span>';
            } else if (cube.status === 'SPINNING') {
                const s = cube.remaining_seconds || 0;
                const hrs = Math.floor(s / 3600);
                const mins = Math.floor((s % 3600) / 60);
                const secs = s % 60;
                timerEl.innerHTML = `<span style="color:#ffd700; font-weight:800;">⏳ กำลังหมุน: ${hrs > 0 ? hrs + ' ชม. ' : ''}${mins} นาที ${secs} วิ</span>`;
            }
        }
    }
}

window.renderMagicCubeSlots = function() {
    const grid = document.getElementById('magic-cube-slots-grid');
    if (!grid) return;

    let html = '';
    for (let slot = 1; slot <= 4; slot++) {
        const cube = currentCubesData.cubes.find(c => c.slot_index === slot && c.status !== 'CLAIMED');
        if (!cube) {
            html += `
                <div class="cube-slot-card" style="border: 1.5px dashed rgba(56, 189, 248, 0.4); text-align: center; padding: 2px 4px; border-radius: 6px; background: rgba(15, 23, 42, 0.5); min-height: 64px; display:flex; flex-direction:column; justify-content:center; align-items:center;">
                    <div style="font-size: 8px; color: #64748b; font-weight: 700;">ช่อง ${slot}</div>
                    <div style="font-size: 15px; opacity: 0.35; margin: 1px 0;">🧊</div>
                    <div style="font-size: 8px; color: #94a3b8; font-weight: 700;">ว่าง</div>
                </div>
            `;
        } else {
            const isSpinning = cube.status === 'SPINNING';
            const isReady = cube.status === 'READY';
            const color = cube.color_hex || '#00e5ff';

            html += `
                <div class="cube-slot-card" style="border: 1.5px solid ${color}; text-align: center; padding: 2px 4px; border-radius: 6px; background: radial-gradient(circle at center, rgba(30, 41, 59, 0.9) 0%, rgba(10, 15, 29, 0.98) 100%); box-shadow: 0 0 8px ${color}33; position: relative; min-height: 64px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center; width:100%;">
                        <span style="font-size: 8px; color: #94a3b8; font-weight: 700;">ช่อง ${slot}</span>
                        ${!isSpinning && !isReady ? `<button onclick="removeCubeFromSlotAction(${cube.id})" style="background:none; border:none; color:#f87171; font-size:8.5px; cursor:pointer; font-weight:900; padding:0 2px;" title="นำออก">✕</button>` : ''}
                    </div>

                    <div style="margin: 1px 0; cursor:pointer;" onclick="${isReady ? `claimCubeRewardAction(${cube.id})` : (!isSpinning ? `showCubeSpinConfirmModal(${cube.id})` : `speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})`)}">
                        <div class="magic-cube-box ${isSpinning ? 'spinning-fast' : ''}" style="margin: 0 auto; width: 20px; height: 20px; font-size: 15px; display:flex; align-items:center; justify-content:center; filter: drop-shadow(0 0 5px ${color});">
                            🧊
                        </div>
                        <div style="font-size: 8.5px; font-weight: 800; color: #fff; margin-top: 1px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${cube.cube_name || cube.cube_type}</div>
                    </div>

                    <div id="cube-slot-${slot}-timer" style="font-size: 8px; min-height: 11px;">
                        ${isReady ? '<span style="color:#10b981; font-weight:800;">เสร็จแล้ว!</span>' :
                          (isSpinning ? `<span style="color:#ffd700; font-weight:800;">หมุน...</span>` :
                          '<span style="color:#38bdf8; font-weight:700;">แตะหมุน</span>')}
                    </div>

                    <div style="margin-top: 1px;">
                        ${isReady ? `
                            <button onclick="claimCubeRewardAction(${cube.id})" class="btn" style="width:100%; padding: 1px 3px; font-size: 8px; font-weight: 900; background: linear-gradient(135deg, #10b981, #059669); color: #fff; border:none; border-radius: 4px; cursor:pointer;">
                                🎁 รับ
                            </button>
                        ` : (isSpinning ? `
                            <button onclick="speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})" class="btn" style="width:100%; padding: 1px 3px; font-size: 7.5px; font-weight: 800; background: linear-gradient(135deg, #06b6d4, #0284c7); color: #fff; border:none; border-radius: 4px; cursor:pointer;">
                                ⚡ 💎${cube.instant_open_diamond || 10}
                            </button>
                        ` : `
                            <button onclick="showCubeSpinConfirmModal(${cube.id})" class="btn" style="width:100%; padding: 1px 3px; font-size: 8px; font-weight: 800; background: linear-gradient(135deg, #f59e0b, #d97706); color: #000; border:none; border-radius: 4px; cursor:pointer;">
                                🌀 หมุน
                            </button>
                        `)}
                    </div>
                </div>
            `;
        }
    }
    grid.innerHTML = html;
};

function renderUserCubesTray() {
    const tray = document.getElementById('user-cubes-slots-row');
    const countEl = document.getElementById('user-cube-count');
    if (!tray) return;

    const unequipped = currentCubesData.cubes.filter(c => c.slot_index === null && c.status === 'IDLE');
    if (countEl) countEl.innerText = unequipped.length;

    if (unequipped.length === 0) {
        tray.innerHTML = `
            <div style="color:#64748b; font-size:10px; padding:8px; text-align:center; width:100%;">
                ยังไม่มีลูกบาศก์ในกระเป๋า ชนะห้อง 2M / 5M / 10M เพื่อรับฟรี!
            </div>
        `;
        return;
    }

    tray.innerHTML = unequipped.map(c => `
        <div onclick="equipCubeToFirstEmptySlot(${c.id})" style="background: rgba(30, 41, 59, 0.85); border: 1.5px solid ${c.color_hex || '#38bdf8'}; border-radius: 6px; padding: 2px 5px; text-align: center; cursor: pointer; min-width: 52px; flex-shrink: 0; box-shadow: 0 0 6px ${c.color_hex || '#38bdf8'}33;" title="แตะเพื่อใส่">
            <div style="font-size: 15px;">🧊</div>
            <div style="font-size: 8px; font-weight: 800; color: #fff; margin-top: 1px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${c.cube_name || c.cube_type}</div>
            <div style="font-size: 7.5px; color: #38bdf8; margin-top: 1px;">+ ใส่</div>
        </div>
    `).join('');
}

window.equipCubeToFirstEmptySlot = async function(userCubeId) {
    const occupiedSlots = currentCubesData.cubes.filter(c => c.slot_index !== null && c.status !== 'CLAIMED').map(c => c.slot_index);
    let targetSlot = 1;
    while (occupiedSlots.includes(targetSlot) && targetSlot <= 4) {
        targetSlot++;
    }
    if (targetSlot > 4) {
        showToast('แท่นหมุนเต็มแล้วทั้ง 4 ช่อง! กรุณานำออกหรือรอหมุนเสร็จ');
        return;
    }

    try {
        const res = await apiClient.equipCubeToSlot(userCubeId, targetSlot);
        if (res && res.status === 'success') {
            showToast(`ใส่ลูกบาศก์ลงช่องที่ ${targetSlot} เรียบร้อยแล้ว`);
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถใส่ลูกบาศก์ได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.removeCubeFromSlotAction = async function(userCubeId) {
    try {
        const res = await apiClient.removeCubeFromSlot(userCubeId);
        if (res && res.status === 'success') {
            showToast('นำลูกบาศก์ออกจากช่องแล้ว');
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถนำออกได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.showCubeSpinConfirmModal = function(userCubeId) {
    const cube = currentCubesData.cubes.find(c => c.id === userCubeId);
    if (!cube) return;
    selectedCubeForSpin = cube;

    const prevEl = document.getElementById('spin-confirm-cube-preview');
    const diaCostEl = document.getElementById('spin-cost-dia-val');
    const goldCostEl = document.getElementById('spin-cost-gold-val');
    const userDiaEl = document.getElementById('spin-user-dia-val');
    const userGoldEl = document.getElementById('spin-user-gold-val');

    if (prevEl) {
        prevEl.innerHTML = `
            <div style="font-size: 48px; filter: drop-shadow(0 0 14px ${cube.color_hex || '#38bdf8'});">🧊</div>
            <h4 style="color: #fff; margin: 6px 0 0 0; font-size: 16px;">${cube.cube_name || cube.cube_type}</h4>
            <div style="font-size: 11px; color: #94a3b8;">ระยะเวลาหมุน: ${cube.min_hours || 1} - ${cube.max_hours || 4} ชม.</div>
        `;
    }
    if (diaCostEl) diaCostEl.innerText = `${cube.spin_cost_diamond || 25} เพชร`;
    if (goldCostEl) goldCostEl.innerText = `${(cube.spin_cost_gold || 15000).toLocaleString()} ทอง`;
    if (userDiaEl) userDiaEl.innerText = (DEFAULT_USER.diamond || 0).toLocaleString();
    if (userGoldEl) userGoldEl.innerText = (DEFAULT_USER.gold || 0).toLocaleString();

    openModal('modal-cube-spin-confirm');
};

window.confirmStartSpinAction = async function(currency) {
    if (!selectedCubeForSpin) return;
    closeModal('modal-cube-spin-confirm');

    try {
        const res = await apiClient.startSpinCube(selectedCubeForSpin.id, currency, selectedCubeForSpin.slot_index || 0);
        if (res && res.status === 'success') {
            showToast('🌀 เริ่มหมุนลูกบาศก์เรียบร้อยแล้ว!');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadMagicCubesData();
        } else {
            showInGameAlert(res.message || 'ทรัพยากรไม่เพียงพอ', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการเริ่มหมุน', 'ข้อผิดพลาด', '❌');
    }
};

window.speedupCubeAction = async function(userCubeId, costDiamond) {
    showInGameConfirm(`ต้องการใช้ 💎 ${costDiamond} เพชร เพื่อเปิดลูกบาศก์นี้ทันทีใช่หรือไม่?`, async () => {
        try {
            const res = await apiClient.speedupCube(userCubeId);
            if (res && res.status === 'success') {
                showToast('⚡ ปลดล็อกลูกบาศก์สำเร็จ!');
                const prof = await apiClient.getProfile();
                if (prof && prof.data) {
                    Object.assign(DEFAULT_USER, prof.data);
                    updateUserBar(DEFAULT_USER);
                }
                await loadMagicCubesData();
            } else {
                showInGameAlert(res.message || 'เพชรไม่เพียงพอ', 'แจ้งเตือน', '⚠️');
            }
        } catch (e) {
            showInGameAlert(e.message || 'เกิดข้อผิดพลาด', 'ข้อผิดพลาด', '❌');
        }
    });
};

window.claimCubeRewardAction = async function(userCubeId) {
    try {
        const res = await apiClient.claimCubeReward(userCubeId);
        if (res && res.status === 'success') {
            showInGameAlert(res.message || 'เปิดลูกบาศก์สำเร็จ ได้รับของรางวัลแล้ว!', '🎉 รับรางวัลลูกบาศก์', '🎁');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถรับรางวัลได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

/**
 * Animate number count up smoothly in top bar with glowing golden pulse effect
 */
window.animateCurrencyCounter = function(elementId, startVal, endVal, duration = 1000) {
    const el = document.getElementById(elementId);
    if (!el || startVal === endVal) return;
    const startTime = performance.now();
    el.style.transition = 'transform 0.2s ease, text-shadow 0.2s ease';
    el.style.transform = 'scale(1.25)';
    el.style.textShadow = '0 0 14px rgba(255, 215, 0, 0.9)';
    el.style.color = '#ffd700';

    function step(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOutQuad = 1 - (1 - progress) * (1 - progress);
        const currentVal = Math.round(startVal + (endVal - startVal) * easeOutQuad);
        el.innerText = currentVal.toLocaleString();
        if (progress < 1) {
            requestAnimationFrame(step);
        } else {
            el.innerText = endVal.toLocaleString();
            setTimeout(() => {
                el.style.transform = '';
                el.style.textShadow = '';
                el.style.color = '';
            }, 300);
        }
    }
    requestAnimationFrame(step);
};

// =========================================================================
// ระบบกล่องข้อความ (Speech Bubble แบบรูปที่ 2), อิโมจิเพียวๆ, อัปเดตอิโมจิล่าสุด และระบบ @ แท็กชื่อผู้เล่น
// =========================================================================

const DEFAULT_RECENT_EMOJIS = ['😍', '😃', '😫', '😖', '😣', '😄', '🌾', '🔥'];

/**
 * ดึงรายการอิโมจิที่ใช้ล่าสุดจาก localStorage
 */
window.getRecentEmojis = function() {
    try {
        const saved = JSON.parse(localStorage.getItem('snake_recent_emojis') || 'null');
        if (Array.isArray(saved) && saved.length > 0) {
            return saved.slice(0, 8);
        }
    } catch (e) {}
    return [...DEFAULT_RECENT_EMOJIS];
};

/**
 * บันทึกอิโมจิที่เพิ่งกดใช้ขึ้นเป็นอันดับแรกในหมวด "ใช้ล่าสุด" และอัปเดต UI ทันที
 */
window.recordRecentEmoji = function(emoji) {
    if (!emoji) return;
    const clean = String(emoji).trim();
    if (!clean) return;

    let list = window.getRecentEmojis().filter(item => item !== clean);
    list.unshift(clean);
    list = list.slice(0, 8);

    try {
        localStorage.setItem('snake_recent_emojis', JSON.stringify(list));
    } catch (e) {}

    window.renderRecentEmojisUI();
};

/**
 * อัปเดตปุ่มอิโมจิในหมวด "ใช้ล่าสุด" ทั้งบนกระดานหลักและในห้องบ้าน 3D
 */
window.renderRecentEmojisUI = function() {
    const list = window.getRecentEmojis();

    const boardGrid = document.getElementById('emoji-recent-grid');
    if (boardGrid) {
        boardGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendPlayerEmoji('${em}')">${em}</button>`
        ).join('');
    }

    const clanGrid = document.getElementById('clan-emoji-recent-grid');
    if (clanGrid) {
        clanGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendClanRoomEmoji('${em}')">${em}</button>`
        ).join('');
    }
};

// เรียกอัปเดตหมวด "ใช้ล่าสุด" ทันทีเมื่อโหลดหน้าเว็บ
setTimeout(() => {
    if (typeof window.renderRecentEmojisUI === 'function') {
        window.renderRecentEmojisUI();
    }
}, 200);

/**
 * ดึงรายชื่อผู้เล่นที่สามารถ @ คุยด้วยได้ (จากผู้เล่นบนกระดาน 3D และสมาชิกในห้องบ้าน 3D)
 */
window.getMentionablePlayers = function() {
    const map = new Map();
    const gameInstance = window.game || window.snakeGame3D;

    // 1. ผู้เล่นบนกระดาน 3D
    if (gameInstance && Array.isArray(gameInstance.players)) {
        gameInstance.players.forEach((p, idx) => {
            if (!p || !p.username) return;
            const cleanName = String(p.username).replace(/^🤖\s*/, '').trim();
            map.set(cleanName, {
                name: cleanName,
                rawName: p.username,
                avatar: p.picture || p.pictureUrl || p.avatar_url || 'avatars/google_avatar.png',
                playerIndex: idx,
                isBot: Boolean(p.is_bot)
            });
        });
    }

    // 2. สมาชิกในห้องบ้าน 3D (ถ้ามี)
    if (typeof currentClanData === 'object' && currentClanData && Array.isArray(currentClanData.members)) {
        currentClanData.members.forEach((m) => {
            if (!m || !m.username) return;
            const cleanName = String(m.username).trim();
            if (!map.has(cleanName)) {
                map.set(cleanName, {
                    name: cleanName,
                    rawName: m.username,
                    avatar: m.avatar_url || 'avatars/google_avatar.png',
                    playerIndex: 0,
                    isBot: false
                });
            }
        });
    }

    return Array.from(map.values());
};

/**
 * แสดงรายการผู้เล่นเมื่อพิมพ์ @ หรือกดปุ่ม @
 */
window.handleChatInputMention = function(inputEl, dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl || !dropdown) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    if (atIndex === -1) {
        dropdown.style.display = 'none';
        return;
    }

    const query = val.substring(atIndex + 1).toLowerCase();
    // หากพิมพ์เว้นวรรคหลังชื่อไปแล้ว ให้ซ่อนเมนู
    if (query.includes(' ')) {
        dropdown.style.display = 'none';
        return;
    }

    const candidates = window.getMentionablePlayers().filter(p =>
        !query || p.name.toLowerCase().includes(query) || p.rawName.toLowerCase().includes(query)
    );

    if (candidates.length === 0) {
        dropdown.style.display = 'none';
        return;
    }

    dropdown.innerHTML = candidates.map(c => {
        const safeName = c.name.replace(/'/g, "\\'");
        return `
            <div class="mention-item" onclick="insertMentionTag('${inputEl.id}', '${dropdownId}', '${safeName}')">
                <img src="${c.avatar}" onerror="this.src='avatars/google_avatar.png'">
                <span>@${c.name}</span>
            </div>
        `;
    }).join('');
    dropdown.style.display = 'block';
};

/**
 * เมื่อกดปุ่ม @ ให้เติมเครื่องหมาย @ ลงในช่องแชทและเปิดรายชื่อคนให้เลือกทันที
 */
window.triggerMentionList = function(inputId, dropdownId) {
    const inputEl = document.getElementById(inputId);
    if (!inputEl) return;

    if (!inputEl.value.endsWith('@')) {
        inputEl.value = (inputEl.value ? inputEl.value.trimEnd() + ' ' : '') + '@';
    }
    inputEl.focus();
    window.handleChatInputMention(inputEl, dropdownId);
};

/**
 * เมื่อคลิกเลือกชื่อคนที่ต้องการ @ จากรายการ
 */
window.insertMentionTag = function(inputId, dropdownId, targetName) {
    const inputEl = document.getElementById(inputId);
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    const cleanTag = targetName.replace(/\s+/g, '_');

    if (atIndex !== -1) {
        inputEl.value = val.substring(0, atIndex) + `@${cleanTag} `;
    } else {
        inputEl.value = `@${cleanTag} ` + val;
    }

    if (dropdown) dropdown.style.display = 'none';
    inputEl.focus();
};

let mentionPillTimer = null;

window.dismissMentionPill = function() {
    const pill = document.getElementById('mention-notification-pill');
    if (pill) pill.classList.remove('show');
    if (mentionPillTimer) {
        clearTimeout(mentionPillTimer);
        mentionPillTimer = null;
    }
};

/**
 * แจ้งเตือนเมื่อมีคน @ หา: "ชื่อ..พูดถึงคุณ"
 */
window.notifyUserMentioned = function(speakerName = 'ผู้เล่น', messageText = '', avatarUrl = '') {
    const rawSpeaker = String(speakerName || 'ผู้เล่น').trim();
    const rawMsg = String(messageText || '').trim();

    // 1. แสดงกล่องแจ้งเตือน Mention Notification Pill ลอยเด่นกึ่งกลางด้านบน
    const pill = document.getElementById('mention-notification-pill');
    const authorEl = document.getElementById('mention-pill-author');
    const textEl = document.getElementById('mention-pill-text');
    const avatarEl = document.getElementById('mention-pill-avatar');

    if (authorEl) authorEl.innerText = rawSpeaker;
    if (textEl) textEl.innerText = rawMsg || 'พูดถึงคุณ';
    if (avatarEl && avatarUrl) avatarEl.src = avatarUrl;

    if (pill) {
        pill.classList.remove('show');
        void pill.offsetWidth; // Force CSS reflow
        pill.classList.add('show');

        if (mentionPillTimer) clearTimeout(mentionPillTimer);
        mentionPillTimer = setTimeout(() => {
            pill.classList.remove('show');
        }, 5000);
    }

    // 2. ส่งเสียงแจ้งเตือนแบบ Chime
    if (window.soundEngine && typeof window.soundEngine.playNotification === 'function') {
        window.soundEngine.playNotification();
    } else if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        window.soundEngine.playClick();
    }

    // 3. แสดงข้อความ Toast เสริมความชัดเจน
    if (typeof window.showToast === 'function') {
        window.showToast(`🔔 ${rawSpeaker} พูดถึงคุณ`, 4500);
    }

    // 4. บันทึกลง Game Log
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        gameInstance.logMessage(`🔔 ${rawSpeaker} พูดถึงคุณ: "${rawMsg}"`, 'highlight');
    }
};

/**
 * ตรวจสอบว่าข้อความแชทมีการ @ หาตัวผู้เล่นคนปัจจุบันหรือไม่
 */
window.checkIfMessageMentionsMe = function(text) {
    if (!text) return false;
    const str = String(text);
    const myName = (window.DEFAULT_USER && window.DEFAULT_USER.username) || '';
    const myGameName = (window.game && window.game.players && window.game.players[0] && window.game.players[0].username) || '';

    if (str.includes('@คุณ')) return true;
    if (myName && str.includes(`@${myName}`)) return true;
    if (myGameName && str.includes(`@${myGameName}`)) return true;

    const lower = str.toLowerCase();
    if (myName && lower.includes(`@${myName.toLowerCase()}`)) return true;
    if (myGameName && lower.includes(`@${myGameName.toLowerCase()}`)) return true;

    return false;
};

/**
 * ฟังก์ชันกลางสำหรับเรียกแสดงกล่องข้อความ (Speech Bubble) หรืออิโมจิบนหัวตัวละคร 3D
 * @param {string} message ข้อความหรืออิโมจิที่ต้องการให้แสดง
 * @param {number} playerIndex ลำดับตัวละครบนกระดาน (ค่าเริ่มต้น 0 = ตัวละครของผู้เล่นหลัก)
 * @param {number} durationMs ระยะเวลาแสดงผลก่อนค่อยๆ จางหายไป (3000 - 5000 ms, ค่าเริ่มต้น 4000 ms)
 */
window.showSpeechBubble = function(message, playerIndex = 0, durationMs = 4000) {
    const text = String(message || '').trim();
    if (!text) return;

    // เชื่อมต่อกับอินสแตนซ์กระดาน 3D (window.game หรือ window.snakeGame3D)
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.showSpeechBubble === 'function') {
        gameInstance.showSpeechBubble(playerIndex, text, durationMs);
    }

    // หากคนพูดเป็นผู้เล่นอื่น (playerIndex !== 0) และข้อความมี @ หาเรา ให้แจ้งเตือนทันที!
    if (playerIndex !== 0 && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
        let speakerName = 'ผู้เล่น';
        let speakerAvatar = 'avatars/google_avatar.png';
        if (gameInstance && Array.isArray(gameInstance.players) && gameInstance.players[playerIndex]) {
            const p = gameInstance.players[playerIndex];
            speakerName = p.username || p.displayName || 'ผู้เล่น';
            speakerAvatar = p.avatar_url || p.picture || 'avatars/google_avatar.png';
        }
        if (typeof window.notifyUserMentioned === 'function') {
            window.notifyUserMentioned(speakerName, text, speakerAvatar);
        }
    }
};

/**
 * เปิด/ปิด หน้าต่างเลือกอิโมจิและส่งข้อความด่วน
 */
window.toggleEmojiChatPopover = function(forceClose = false) {
    const popover = document.getElementById('emoji-chat-popover');
    if (!popover) return;

    if (forceClose === true) {
        popover.style.display = 'none';
        const dd = document.getElementById('board-mention-dropdown');
        if (dd) dd.style.display = 'none';
        return;
    }

    const isVisible = popover.style.display !== 'none' && popover.style.display !== '';
    popover.style.display = isVisible ? 'none' : 'block';

    if (!isVisible) {
        window.renderRecentEmojisUI();
        const input = document.getElementById('input-speech-message');
        if (input) {
            setTimeout(() => input.focus(), 60);
        }
    }
};

/**
 * เมื่อผู้เล่นคลิกเลือกอิโมจิจากถาดอิโมจิ ให้แสดงเป็นตัวอิโมจิบนหัวรูปภาพทันที และอัปเดตหมวด "ใช้ล่าสุด"
 */
window.sendPlayerEmoji = function(emoji) {
    if (!emoji) return;

    // 1. บันทึกและอัปเดตอิโมจิล่าสุดขึ้นอันดับ 1 ในหมวด "ใช้ล่าสุด"
    window.recordRecentEmoji(emoji);

    // 2. แสดงอิโมจิเพียวๆ บนหัวรูปภาพตัวหมากของผู้เล่น (index 0) นาน 4 วินาที
    window.showSpeechBubble(emoji, 0, 4000);

    // 3. บันทึกลง Game Log ด้านขวาด้วย
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: ${emoji}`, 'highlight');
    }

    window.toggleEmojiChatPopover(true);
};

/**
 * เมื่อผู้เล่นพิมพ์ข้อความแชท (รองรับ @ชื่อผู้เล่น) และกดส่ง หรือกดปุ่ม Enter
 */
window.sendPlayerChatMessage = function() {
    const input = document.getElementById('input-speech-message');
    if (!input) return;

    const msg = input.value.trim();
    if (!msg) return;

    // 1. แสดงข้อความในกล่องข้อความทรงวงรีสีขาวขอบดำ (แบบรูปที่ 2) บนหัวรูปภาพตัวละครของผู้เล่น
    window.showSpeechBubble(msg, 0, 4500);

    const gameInstance = window.game || window.snakeGame3D;

    // 2. หากในข้อความมีการ @หาผู้เล่นคนอื่นบนกระดาน ให้แสดงแจ้งเตือนและขึ้นข้อความที่เกี่ยวข้องด้วย
    if (gameInstance && Array.isArray(gameInstance.players)) {
        const mentionMatch = msg.match(/@([^\s]+)/);
        if (mentionMatch && mentionMatch[1]) {
            const targetKey = mentionMatch[1].replace(/_/g, ' ').toLowerCase();
            const targetIdx = gameInstance.players.findIndex((p, idx) =>
                idx !== 0 && p.username && p.username.toLowerCase().includes(targetKey)
            );
            if (targetIdx > 0) {
                const targetPlayer = gameInstance.players[targetIdx];
                if (targetPlayer.is_bot) {
                    setTimeout(() => {
                        window.showSpeechBubble(`👋 รับทราบครับ @${DEFAULT_USER.username || 'คุณ'}!`, targetIdx, 4000);
                    }, 900);
                }
            }
        }
    }

    // 3. บันทึกลง Game Log ด้านขวา
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: "${msg}"`, 'highlight');
    }

    input.value = '';
    const dd = document.getElementById('board-mention-dropdown');
    if (dd) dd.style.display = 'none';
    window.toggleEmojiChatPopover(true);
};

// ปิดถาดเลือกอิโมจิเมื่อคลิกพื้นที่ว่างข้างนอก
document.addEventListener('click', function(e) {
    const popover = document.getElementById('emoji-chat-popover');
    const triggerBtn = document.getElementById('btn-toggle-emoji');
    if (popover && popover.style.display !== 'none') {
        if (!popover.contains(e.target) && (!triggerBtn || !triggerBtn.contains(e.target))) {
            popover.style.display = 'none';
        }
    }

    const clanEmojiPop = document.getElementById('clan-room-emoji-popover');
    const clanEmojiBtn = document.getElementById('btn-clan-room-emoji');
    if (clanEmojiPop && clanEmojiPop.style.display !== 'none') {
        if (!clanEmojiPop.contains(e.target) && (!clanEmojiBtn || !clanEmojiBtn.contains(e.target))) {
            clanEmojiPop.style.display = 'none';
        }
    }
});



// ==========================================================================
// 3D BOARD CATALOG, RULES & SPECIAL TILES (ROOM & MATCHMAKING FLOW)
// ==========================================================================
const BOARD_CATALOG = {
    classic: {
        id: 'classic',
        name: 'นีออนไซเบอร์ 3D (Cyber Neon)',
        shortName: 'นีออนไซเบอร์ 3D',
        badge: 'CYBER NEON',
        themeColor: '#00e5ff',
        auraDesc: 'ธีมไซไฟล้ำยุค เรืองแสงนีออนฟ้า-ชมพู คมชัดทุกสายตา',
        story: 'สังเวียนการแข่งขันใจกลางมหานครไซเบอร์พังก์ ล้อมรอบด้วยสถาปัตยกรรมดิจิทัลแห่งโลกอนาคต เส้นทางเชื่อมต่อด้วยบันไดลำแสงไฮเทค และพญางูเลเซอร์เรืองแสงสีชมพู ทุกย่างก้าวเต็มไปด้วยความเร็วและพลังงานนีออน',
        specialBonus: '⚡ ทัศนวิสัยคมชัดสูงพิเศษ แสงนีออนสะท้อนพื้นผิวบอร์ด 3D สังเกตตำแหน่งบันไดและงูได้ง่ายที่สุด',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="cyberBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#070b14"/><stop offset="50%" stop-color="#0c2340"/><stop offset="100%" stop-color="#034168"/></linearGradient><filter id="cyberGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#cyberBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#111c30" stroke="#00e5ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#00e5ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00e5ff" stroke-width="3.5" filter="url(#cyberGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00e5ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00e5ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00e5ff" stroke-width="2"/><path d="M 36 -36 Q 0 -12 24 24 T -12 36" fill="none" stroke="#ff0055" stroke-width="3.5" filter="url(#cyberGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#ff0055"/></g><text x="120" y="108" text-anchor="middle" fill="#00e5ff" font-size="11" font-weight="800" letter-spacing="1">CYBER NEON 3D</text></svg>`
    },
    ancient: {
        id: 'ancient',
        name: 'วิหารทองคำพญานาค (Golden Temple)',
        shortName: 'วิหารทองคำพญานาค',
        badge: 'GOLDEN NAGA',
        themeColor: '#ffd700',
        auraDesc: 'ศาลทองคำโบราณ มนต์ขลังพญานาคราชบันไดทอง',
        story: 'มหาปราสาททองคำลอยฟ้าโบราณที่สถิตของพญานาคราชผู้พิทักษ์ บันไดทองคำส่องแสงประกายมนต์ขลัง และงูเขียวมรกตเกล็ดนาคราช ทุกย่างก้าวจะได้รับพรแห่งโชคลาภในการทอยเต๋า',
        specialBonus: '👑 มนต์มหาโชคพญานาคราช เสริมบารมีแก่ผู้เล่นที่ก้าวขึ้นบันไดทองคำสู่เส้นชัย',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="ancientBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1f1406"/><stop offset="50%" stop-color="#422d0d"/><stop offset="100%" stop-color="#694a16"/></linearGradient><filter id="goldGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#ancientBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#33240e" stroke="#ffd700" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ffd700" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffd700" stroke-width="3.5" filter="url(#goldGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffd700" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffd700" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffd700" stroke-width="2"/><path d="M 36 -36 Q 10 -5 20 20 T -20 24" fill="none" stroke="#00e676" stroke-width="3.5" filter="url(#goldGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#00e676"/></g><text x="120" y="108" text-anchor="middle" fill="#ffd700" font-size="11" font-weight="800" letter-spacing="1">GOLDEN NAGA 3D</text></svg>`
    },
    lava: {
        id: 'lava',
        name: 'ภูเขาไฟลาวาเดือด (Lava Volcano)',
        shortName: 'ภูเขาไฟลาวาเดือด',
        badge: 'LAVA VOLCANO',
        themeColor: '#ff5722',
        auraDesc: 'ธารหินหลอมละลายร้อนแรง การแข่งขันสุดดุเดือดท้าทาย',
        story: 'ดินแดนปากปล่องภูเขาไฟใต้พิภพที่ปะทุด้วยลาวาเดือดพล่าน บันไดเหล็กหลอมเพลิงและพญางูดำอัคคี บรรยากาศร้อนระอุบีบคั้นการตัดสินใจ ผู้กล้าเท่านั้นที่จะพิชิตสู่ยอดเขา',
        specialBonus: '🔥 บรรยากาศเกมเร้าใจ ปลุกสัญชาตญาณความกระหายชัยชนะ การชิงตำแหน่งและหลบหลีกงูเพลิงสุดระทึก',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="lavaBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#240808"/><stop offset="50%" stop-color="#471111"/><stop offset="100%" stop-color="#751b14"/></linearGradient><filter id="lavaGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#lavaBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#2b0d0d" stroke="#ff5722" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ff3d00" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffab00" stroke-width="3" filter="url(#lavaGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffab00" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffab00" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffab00" stroke-width="2"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#212121" stroke-width="4.5"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#ff3d00" stroke-width="1.8" filter="url(#lavaGlow)"/><circle cx="36" cy="-36" r="4" fill="#ff1744"/></g><text x="120" y="108" text-anchor="middle" fill="#ff5722" font-size="11" font-weight="800" letter-spacing="1">LAVA VOLCANO 3D</text></svg>`
    },
    ice: {
        id: 'ice',
        name: 'แดนน้ำแข็งคริสตัล (Crystal Ice)',
        shortName: 'แดนน้ำแข็งคริสตัล',
        badge: 'CRYSTAL ICE',
        themeColor: '#38bdf8',
        auraDesc: 'มหาธารน้ำแข็งคริสตัลขั้วโลก แสงออโรร่าประกายแก้ว',
        story: 'ยอดเขาน้ำแข็งนิรันดร์ที่ปกคลุมด้วยผลึกคริสตัลใสประกายระยิบระยับ แสงออโรร่าสีฟ้าน้ำทะเลร่ายรำบนท้องฟ้า บันไดผลึกแก้วใสและงูหมอกมนตราสีม่วง เงียบสงบแต่เยือกเย็นและเฉียบคม',
        specialBonus: '❄️ แสงสะท้อนประกายแก้ว สบายตา สมาธิตั้งมั่น วางกลยุทธ์การเดินได้อย่างเยือกเย็น',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="display:block; border-radius:10px;"><defs><linearGradient id="iceBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#051524"/><stop offset="50%" stop-color="#0f3554"/><stop offset="100%" stop-color="#1e5987"/></linearGradient><filter id="iceGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#iceBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#0f2a3d" stroke="#80d8ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#80d8ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00b0ff" stroke-width="3" filter="url(#iceGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00b0ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00b0ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00b0ff" stroke-width="2"/><path d="M 36 -36 Q 10 -5 22 22 T -18 30" fill="none" stroke="#a855f7" stroke-width="3.5" filter="url(#iceGlow)"/><circle cx="36" cy="-36" r="4" fill="#a855f7"/></g><text x="120" y="108" text-anchor="middle" fill="#80d8ff" font-size="11" font-weight="800" letter-spacing="1">CRYSTAL ICE 3D</text></svg>`
    }
};

const ROOM_TIER_CONFIG = {
    '2M': {
        tier: '2M',
        room_tier: '2M',
        title: 'ห้อง 2M (ยอดนิยม)',
        fee: 2000,
        entry_fee_gold: 2000,
        start_match_gold: 2000000,
        winDia: 200,
        winGold: 100000,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '⚡ รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 2,000 🪙 • ทองเริ่มต้นในกระดาน: 2,000,000 🪙 | ชนะรับ: 200 💎 + 100,000 🪙'
    },
    '5M': {
        tier: '5M',
        room_tier: '5M',
        title: 'ห้อง 5M (ระดับเซียน)',
        fee: 5000,
        entry_fee_gold: 5000,
        start_match_gold: 5000000,
        winDia: 500,
        winGold: 300000,
        tax_amount: 120000,
        tax_percent: 22,
        city_base_cost: 300000,
        landmark_cost: 800000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🔥 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 5,000 🪙 • ทองเริ่มต้นในกระดาน: 5,000,000 🪙 | ชนะรับ: 500 💎 + 300,000 🪙'
    },
    '10M': {
        tier: '10M',
        room_tier: '10M',
        title: 'ห้อง 10M (มหาเศรษฐี)',
        fee: 10000,
        entry_fee_gold: 10000,
        start_match_gold: 10000000,
        winDia: 1200,
        winGold: 800000,
        tax_amount: 250000,
        tax_percent: 25,
        city_base_cost: 600000,
        landmark_cost: 1600000,
        toll_percent: 90,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '👑 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 10,000 🪙 • ทองเริ่มต้นในกระดาน: 10,000,000 🪙 | ชนะรับ: 1,200 💎 + 800,000 🪙'
    },
    'PRACTICE': {
        tier: 'PRACTICE',
        room_tier: 'PRACTICE',
        title: 'โหมดทดลองเล่น',
        fee: 0,
        entry_fee_gold: 0,
        start_match_gold: 2000000,
        winDia: 0,
        winGold: 0,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🎯 ฝึกซ้อมฟรี',
        desc: 'เล่นฟรีไม่เสียค่าเข้า • ทองเริ่มต้นในกระดาน: 2,000,000 🪙'
    }
};

window.getActiveRoomEconomyConfig = function(tier = null) {
    const key = String(tier || window.currentActiveRoomTier || (window.isPracticeMatch ? 'PRACTICE' : currentLobbyTier) || '2M').toUpperCase();
    return ROOM_TIER_CONFIG[key] || ROOM_TIER_CONFIG['2M'];
};

window.loadRoomConfigs = async function() {
    try {
        if (!window.apiClient || typeof window.apiClient.getRoomConfigs !== 'function') return;
        const res = await window.apiClient.getRoomConfigs();
        if (!res || res.status !== 'success' || !res.rooms) return;

        Object.entries(res.rooms).forEach(([tierKey, r]) => {
            const t = String(tierKey).toUpperCase();
            if (!ROOM_TIER_CONFIG[t]) ROOM_TIER_CONFIG[t] = { tier: t, room_tier: t, defaultMode: '2P' };
            const cfg = ROOM_TIER_CONFIG[t];
            cfg.title = r.room_title || cfg.title || `ห้อง ${t}`;
            cfg.fee = Number(r.entry_fee_gold ?? cfg.fee ?? 2000);
            cfg.entry_fee_gold = cfg.fee;
            cfg.start_match_gold = Number(r.start_match_gold ?? cfg.start_match_gold ?? 2000000);
            cfg.winDia = Number(r.reward_diamond ?? cfg.winDia ?? 0);
            cfg.winGold = Number(r.reward_gold ?? cfg.winGold ?? 0);
            cfg.tax_amount = Number(r.tax_amount ?? cfg.tax_amount ?? 50000);
            cfg.tax_percent = Number(r.tax_percent ?? cfg.tax_percent ?? 20);
            cfg.city_base_cost = Number(r.city_base_cost ?? cfg.city_base_cost ?? 120000);
            cfg.landmark_cost = Number(r.landmark_cost ?? cfg.landmark_cost ?? 320000);
            cfg.toll_percent = Number(r.toll_percent ?? cfg.toll_percent ?? 85);
            cfg.buyout_percent = Number(r.buyout_percent ?? cfg.buyout_percent ?? 160);
            cfg.desc = `ค่าผ่านทางเข้าเล่น: ${cfg.fee.toLocaleString()} 🪙 • ทองเริ่มต้นในกระดาน: ${cfg.start_match_gold.toLocaleString()} 🪙 | ชนะรับ: ${cfg.winDia.toLocaleString()} 💎 + ${cfg.winGold.toLocaleString()} 🪙`;

            // อัปเดตการ์ดห้องในหน้า Lobby แบบสดๆ
            const elTitle = document.getElementById(`room-title-${t}`);
            const elFee = document.getElementById(`room-fee-${t}`);
            const elStart = document.getElementById(`room-startgold-${t}`);
            const elDia = document.getElementById(`room-dia-${t}`);
            const elGold = document.getElementById(`room-gold-${t}`);
            if (elTitle) elTitle.innerText = cfg.title;
            if (elFee) elFee.innerText = cfg.fee.toLocaleString();
            if (elStart) elStart.innerText = cfg.start_match_gold.toLocaleString();
            if (elDia) elDia.innerText = `💎 ${cfg.winDia.toLocaleString()} เพชร`;
            if (elGold) elGold.innerText = `🪙 ${cfg.winGold.toLocaleString()} ทอง`;
        });
    } catch (e) {
        console.warn('loadRoomConfigs warning:', e);
    }
};

let currentLobbyTier = '2M';
let currentLobbyMode = '2P';
let currentLobbyBoard = localStorage.getItem('snake_board_theme') || 'ancient';
let activeInfoBoardId = 'ancient';

window.selectLobbyLayout = function(layoutType) {
    currentSelectedBoardLayout = layoutType;
    try {
        localStorage.setItem('snake_board_layout', layoutType);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layoutType);
    }
    updateLobbyLayoutUIState();
    if (typeof showToast === 'function') {
        const names = { square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'วงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม' };
        showToast(`เลือกผังกระดาน 3D: ${names[layoutType] || layoutType}`);
    }
};

window.updateLobbyLayoutUIState = function() {
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    ['square', 'spiral', 'hexagon'].forEach(l => {
        const btn = document.getElementById(`lobby-layout-btn-${l}`);
        if (btn) {
            if (l === layout) btn.classList.add('active');
            else btn.classList.remove('active');
        }
    });
    const display = document.getElementById('lobby-active-layout-display');
    if (display) {
        const labels = {
            square: '🟩 สี่เหลี่ยมดั้งเดิม (Classic Square)',
            spiral: '🌀 ทรงกลมก้นหอย (Spiral Galaxy)',
            hexagon: '⬡ ทรงหกเหลี่ยมรังผึ้ง (Hexagon Hive)'
        };
        display.textContent = labels[layout] || labels.square;
    }
};

window.selectLobbyRoom = function(tier = '2M') {
    currentLobbyTier = tier;
    window.goToBoardStep();
};

window.goToBoardStep = function() {
    // Switch views in modal: Show Step 2 (Boards)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'block';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '🗺️ ขั้นตอนที่ 2/3: เลือกกระดาน 3D & แผนที่';

    // Update Room Banner
    const isPractice = (currentLobbyTier === 'PRACTICE');
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const pill = document.getElementById('lobby-active-room-pill');
    const desc = document.getElementById('lobby-active-room-desc');
    if (pill) {
        pill.innerText = isPractice ? '🎯 โหมดทดลองเล่นเดี่ยว (1 ต่อ 1)' : cfg.title;
    }
    if (desc) {
        desc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : cfg.desc;
    }

    const btnNextText = document.querySelector('#lobby-view-boards .btn-start-match span');
    if (btnNextText) {
        btnNextText.innerText = isPractice
            ? 'ถัดไป: เลือกลำดับเล่น & สิทธิ์เริ่มก่อน ➔'
            : 'ถัดไป: เลือกคู่แข่ง & โหมดแข่งขัน ➔';
    }

    // Update Layout selector pills
    window.updateLobbyLayoutUIState();

    // Render Board Grid
    window.renderLobbyBoardsGrid();
};

window.backToRoomSelect = function() {
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'block';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '⚔️ ห้องแข่งขัน & เลือกกระดาน 3D';
};

window.goToLobbyModeSelect = function() {
    // Switch views: Show Step 3 (Opponents / Players count & Match mode)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'block';

    const isPractice = (currentLobbyTier === 'PRACTICE');
    const compBlock = document.getElementById('lobby-competitive-modes-block');
    const pracBlock = document.getElementById('lobby-practice-turn-block');

    if (title) {
        title.innerText = isPractice
            ? '🎲 ขั้นตอนที่ 3/3: เลือกสิทธิ์การเล่นก่อน-หลัง (โหมดทดลองเล่น)'
            : '👥 ขั้นตอนที่ 3/3: เลือกคู่แข่ง & รูปแบบแข่งขัน';
    }

    if (compBlock) compBlock.style.display = isPractice ? 'none' : 'block';
    if (pracBlock) pracBlock.style.display = isPractice ? 'block' : 'none';

    // Update Summary Banner in Step 3
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const board = BOARD_CATALOG[currentLobbyBoard] || BOARD_CATALOG.classic;
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    const layoutNames = { square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'ทรงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม' };
    const modeRoomPill = document.getElementById('mode-summary-room-pill');
    const modeBoardPill = document.getElementById('mode-summary-board-pill');
    const modeSummaryDesc = document.getElementById('mode-summary-desc');

    if (modeRoomPill) {
        modeRoomPill.innerText = isPractice ? '🎯 โหมดทดลองเล่น (1v1)' : `🏆 ${cfg.title}`;
    }
    if (modeBoardPill) {
        modeBoardPill.innerText = `🗺️ แผนที่: ${board.name} (${layoutNames[layout] || layout})`;
    }
    if (modeSummaryDesc) {
        modeSummaryDesc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : `ค่าเข้า: ${(cfg.fee || 2000).toLocaleString()} 🪙 • ชนะรับ: ${(cfg.winDia || 200).toLocaleString()} 💎 + ${(cfg.winGold || 100000).toLocaleString()} 🪙`;
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        if (isPractice) {
            btnText.innerText = '🚀 เริ่มทดลองเล่นทันที';
        } else {
            const modeLabel = (currentLobbyMode === '2P') ? '1 ต่อ 1' : ((currentLobbyMode === '3P') ? 'เดี่ยว 3' : ((currentLobbyMode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
            btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
        }
    }

    if (isPractice) {
        if (typeof window.updateTurnOrderUIState === 'function') {
            window.updateTurnOrderUIState();
        }
    } else {
        window.setLobbyGameMode(currentLobbyMode || '2P');
    }
};

window.backToBoardSelect = function() {
    window.goToBoardStep();
};

window.setLobbyGameMode = function(mode = '2P') {
    currentLobbyMode = mode;
    ['2P', '3P', '4P', 'TEAM'].forEach(m => {
        const card = document.getElementById('mode-card-' + m);
        if (card) {
            if (m === mode) {
                card.classList.add('active', 'selected');
            } else {
                card.classList.remove('active', 'selected');
            }
        }
    });

    const hint = document.getElementById('lobby-mode-hint');
    if (hint) {
        if (mode === '2P') hint.innerText = '👤 ดวลเดี่ยวตัวต่อตัว 2 คน (1 ต่อ 1)';
        else if (mode === '3P') hint.innerText = '🥉 ประลอง 3 ผู้เล่น ตะลุมบอน 3 ทิศทาง (เดี่ยว 3)';
        else if (mode === '4P') hint.innerText = '👑 ตะลุมบอน 4 ผู้เล่น อิสระทุกคน (เดี่ยว 4 คน)';
        else if (mode === 'TEAM') hint.innerText = '🛡️ รวมพลังต่อสู้เป็นคู่ แท็กทีม 2v2 (ทีมฟ้า vs ทีมแดง)';
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        const modeLabel = (mode === '2P') ? '1 ต่อ 1' : ((mode === '3P') ? 'เดี่ยว 3' : ((mode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
        btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
    }
};

window.scrollLobbyBoards = function(direction) {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    const scrollAmount = 296 * direction;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
};

function attachLobbyBoardsDragScroll(container) {
    if (!container || container._hasDragAttached) return;
    container._hasDragAttached = true;

    let isDown = false;
    let startX = 0;
    let scrollLeft = 0;

    container.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return;
        isDown = true;
        container._isDragging = false;
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
    });

    container.addEventListener('mouseleave', () => {
        isDown = false;
    });

    container.addEventListener('mouseup', () => {
        setTimeout(() => { container._isDragging = false; }, 50);
        isDown = false;
    });

    container.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 1.5;
        if (Math.abs(walk) > 6) {
            container._isDragging = true;
        }
        container.scrollLeft = scrollLeft - walk;
    });

    container.addEventListener('wheel', (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            container.scrollLeft += e.deltaY;
        }
    }, { passive: false });
}

window.selectLobbyBoard = function(boardId, autoAdvanceToStep3 = true) {
    currentLobbyBoard = boardId;
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(boardId);
    }
    window.renderLobbyBoardsGrid();
    if (autoAdvanceToStep3 && typeof window.goToLobbyModeSelect === 'function') {
        window.goToLobbyModeSelect();
    }
};

window.renderLobbyBoardsGrid = function() {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    container.innerHTML = '';

    Object.values(BOARD_CATALOG).forEach(board => {
        const isSelected = (currentLobbyBoard === board.id);
        const card = document.createElement('div');
        card.className = 'board-preview-card ' + (isSelected ? 'selected' : '');
        card.style.setProperty('--accent-board', board.themeColor);
        card.style.setProperty('--glow-board', board.themeColor + '66');
        card.style.cursor = 'pointer';
        
        card.innerHTML = `
            <div class="board-visual-preview">
                <span class="board-badge-tag" style="background:${board.themeColor}; color:#020617;">${board.badge}</span>
                ${board.svg}
            </div>
            <div>
                <div class="board-card-name">${board.name}</div>
                <div class="board-card-desc">${board.auraDesc}</div>
            </div>
            <div class="board-card-actions">
                <button class="btn-board-info-trigger" onclick="openBoardInfoModal('${board.id}', event)">
                    <span>ℹ️</span> คำอธิบาย & ช่องพิเศษ
                </button>
                <div class="board-check-indicator">
                    ${isSelected ? '✓ เลือก & ไปต่อ ➔' : 'คลิกเลือก ➔'}
                </div>
            </div>
        `;

        card.onclick = (e) => {
            if (e.target.closest('.btn-board-info-trigger')) return;
            if (container._isDragging) return;
            window.selectLobbyBoard(board.id, true);
        };

        container.appendChild(card);
    });

    attachLobbyBoardsDragScroll(container);

    const activeCard = container.querySelector('.board-preview-card.selected');
    if (activeCard) {
        setTimeout(() => {
            activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }, 60);
    }
};

window.confirmLobbyMatch = function() {
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    try {
        localStorage.setItem('snake_board_layout', layout);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layout);
    }
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(currentLobbyBoard);
    }

    if (currentLobbyTier === 'PRACTICE') {
        closeModal('modal-lobby');
        if (typeof window.startExplicitPracticeMatch === 'function') {
            window.startExplicitPracticeMatch();
        }
    } else {
        window.startQuickMatch(currentLobbyTier, currentLobbyMode, currentLobbyBoard);
    }
};

window.openBoardInfoModal = function(boardId = 'classic', event = null) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
    openModal('modal-board-info');
};

function renderBoardInfoModal() {
    const board = BOARD_CATALOG[activeInfoBoardId] || BOARD_CATALOG.classic;
    const nav = document.getElementById('board-info-tabs-nav');
    const body = document.getElementById('board-info-modal-body');

    // Render nav tabs
    if (nav) {
        nav.innerHTML = Object.values(BOARD_CATALOG).map(b => `
            <button class="board-info-tab-btn ${b.id === activeInfoBoardId ? 'active' : ''}" onclick="switchInfoBoardTab('${b.id}')">
                <span>${b.id === 'classic' ? '🌌' : (b.id === 'ancient' ? '🛕' : (b.id === 'lava' ? '🌋' : '❄️'))}</span>
                ${b.shortName}
            </button>
        `).join('');
    }

    if (body) {
        body.innerHTML = `
            <!-- Hero Banner -->
            <div class="board-info-hero" style="background:${board.themeColor}15; border-color:${board.themeColor}55;">
                <div class="board-info-hero-header">
                    <span class="board-info-hero-icon">${board.id === 'classic' ? '🌌' : (board.id === 'ancient' ? '🛕' : (board.id === 'lava' ? '🌋' : '❄️'))}</span>
                    <div>
                        <div style="font-size:11px; font-weight:800; color:${board.themeColor}; text-transform:uppercase; letter-spacing:1px;">แผนที่ / กระดาน 3D</div>
                        <div class="board-info-hero-title">${board.name}</div>
                    </div>
                </div>
                <div class="board-info-hero-story">
                    ${board.story}
                </div>
                <div style="margin-top:10px; font-size:12px; color:${board.themeColor}; font-weight:700;">
                    ${board.specialBonus}
                </div>
            </div>

            <!-- How to play & Win conditions -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🎯</span> กติกาและวิธีเล่น (How to Play & Winning Rules)
                </div>
                <div class="rules-grid">
                    <div class="rule-item">
                        <div class="rule-item-title">🎲 การทอยลูกเต๋า 2 ลูก</div>
                        <div class="rule-item-desc">ทอยลูกเต๋าคู่ ผลรวมแต้ม (2-12) คือจำนวนช่องที่ตัวหมากเดินไปข้างหน้า</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">⚡ ดับเบิ้ลโบนัส (Double)</div>
                        <div class="rule-item-desc">ทอยได้เลขคู่หน้าเหมือนกัน ได้สิทธิ์ทอยต่อทันที! (หากดับเบิ้ล 3 ครั้งติด โดนส่งไปคุกทันที)</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">🏆 เงื่อนไขคว้าชัยชนะ</div>
                        <div class="rule-item-desc">ผู้เล่นที่เดินถึงหรือทะลุ <strong>ช่อง 100</strong> คนแรก คว้าแชมป์ทันที และรับทอง+เพชรของห้อง</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">👥 รูปแบบผู้เล่น</div>
                        <div class="rule-item-desc">เลือกได้ทั้ง <strong>1 ต่อ 1 (2 คน)</strong>, <strong>เดี่ยว 3 (3 คน)</strong>, <strong>เดี่ยว 4 (4 คน)</strong> หรือ <strong>ทีม 2v2</strong> (ใครในทีมถึง 100 ชนะยกทีม)</div>
                    </div>
                </div>
            </div>

            <!-- Special Tiles -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🌟</span> รายการช่องพิเศษทั้งหมดบนกระดานนี้ (Special Tiles)
                </div>
                <div class="special-tiles-grid">
                    <!-- Start -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🚩 จุดเริ่มต้น (Start)</span>
                            <span class="tile-badge-number">ช่อง 1</span>
                        </div>
                        <div class="tile-card-desc">จุดออกสตาร์ท ทุกผู้เล่นเริ่มเดินทางพร้อมกันที่วงกลมสตาร์ทนี้</div>
                    </div>

                    <!-- Goal -->
                    <div class="special-tile-card" style="border-color:rgba(255, 215, 0, 0.4); background:rgba(255, 215, 0, 0.08);">
                        <div class="tile-card-header">
                            <span class="tile-card-title" style="color:#ffd700;">🏆 เส้นชัยสูงสุด (Goal)</span>
                            <span class="tile-badge-number" style="background:#ffd70033; color:#ffd700; border-color:#ffd700;">ช่อง 100</span>
                        </div>
                        <div class="tile-card-desc">ช่องแห่งชัยชนะ เข้าถึงช่องนี้ชนะการแข่งขันทันที รับรางวัลเต็มแม็กซ์</div>
                    </div>

                    <!-- Chance -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎁 ช่องโอกาส (Chance)</span>
                            <span class="tile-badge-number">11, 26, 45, 76</span>
                        </div>
                        <div class="tile-card-desc">สุ่มเปิดการ์ดดวงชะตา: โบนัสทอง 10k-50k, สปีดบูสต์ก้าวหน้า, วาร์ปขึ้นบันได, สลับที่คู่แข่ง</div>
                    </div>

                    <!-- Gamble -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎲 ช่องเสี่ยงโชค (Lucky Gamble)</span>
                            <span class="tile-badge-number">15, 36, 68, 88</span>
                        </div>
                        <div class="tile-card-desc">มินิเกมเสี่ยงดวงลูกเต๋า ลุ้นรับโบนัสทวีคูณทองและเพชรตามดวง</div>
                    </div>

                    <!-- Tax -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">💸 ช่องภาษีเมือง (City Tax)</span>
                            <span class="tile-badge-number">20, 52, 82</span>
                        </div>
                        <div class="tile-card-desc">จ่ายค่าบำรุงเมือง 5,000 ทอง เข้ากองกลางเพื่อพัฒนาอาณาจักร</div>
                    </div>

                    <!-- Jail -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">⛓️ เกาะร้าง / ติดคุก (Jail)</span>
                            <span class="tile-badge-number">ช่อง 10</span>
                        </div>
                        <div class="tile-card-desc">ถูกกักขัง 2 เทิร์น เว้นแต่จะทอยได้แต้มดับเบิ้ล หรือจ่ายเพชรประกันตัว</div>
                    </div>
                </div>

                <!-- Ladders & Snakes breakdown -->
                <div class="ladders-snakes-table">
                    <div class="ladder-list-box">
                        <div class="list-box-title" style="color:#38bdf8;">
                            <span>🪜</span> ช่องบันไดนำโชค (8 แห่ง) - พุ่งทะยานขึ้น
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-ladder">ช่อง 4 ➔ 14</span>
                            <span class="tile-chip chip-ladder">ช่อง 9 ➔ 31</span>
                            <span class="tile-chip chip-ladder">ช่อง 22 ➔ 38</span>
                            <span class="tile-chip chip-ladder" style="border-color:#ffd700; color:#ffd700;">ช่อง 28 ➔ 84 🚀</span>
                            <span class="tile-chip chip-ladder">ช่อง 40 ➔ 59</span>
                            <span class="tile-chip chip-ladder">ช่อง 51 ➔ 67</span>
                            <span class="tile-chip chip-ladder">ช่อง 63 ➔ 81</span>
                            <span class="tile-chip chip-ladder">ช่อง 71 ➔ 91</span>
                        </div>
                    </div>

                    <div class="snake-list-box">
                        <div class="list-box-title" style="color:#fb7185;">
                            <span>🐍</span> ช่องงูพิษอันตราย (8 แห่ง) - สไลด์ตกฮวบ
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-snake">ช่อง 17 ➔ 7</span>
                            <span class="tile-chip chip-snake">ช่อง 54 ➔ 34</span>
                            <span class="tile-chip chip-snake">ช่อง 62 ➔ 19</span>
                            <span class="tile-chip chip-snake">ช่อง 64 ➔ 60</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 87 ➔ 24 💀</span>
                            <span class="tile-chip chip-snake">ช่อง 93 ➔ 73</span>
                            <span class="tile-chip chip-snake">ช่อง 95 ➔ 75</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 99 ➔ 78 ⚠️</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Buttons -->
            <div class="board-info-actions">
                <button class="btn-back-step" onclick="closeModal('modal-board-info')">ปิดหน้าต่าง</button>
                <button class="btn-start-match" onclick="applyAndChooseBoard('${board.id}')" style="background:${board.themeColor}; color:#020617;">
                    ✓ เลือกกระดานนี้เลย
                </button>
            </div>
        `;
    }
}

window.switchInfoBoardTab = function(boardId) {
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
};

window.applyAndChooseBoard = function(boardId) {
    if (typeof window.selectBoardThemeAction === 'function') {
        window.selectBoardThemeAction(boardId);
    }
    if (typeof window.closeModal === 'function') {
        window.closeModal('modal-board-info');
    }
};

/* Side Panels Toggle (พับเก็บ / ขยาย เมนูลัดและข่าวสาร เพื่อดูหน้าจอ 3D เต็มตา) */
(function() {
    // Sync side panels: delegates to robust window.bindSidePanelButton / window.initSidePanelsDefaultShown
    if (typeof window.bindSidePanelButton === 'function') {
        ['left', 'right'].forEach(window.bindSidePanelButton);
    } else if (typeof window.initSidePanelsDefaultShown === 'function') {
        window.initSidePanelsDefaultShown();
    }
})();

/* ===================================================================
   Rewarded Video Ad - Free Daily Diamonds (30 เพชร ฟรี 0/1)
   Compatible with @capacitor-community/admob & Web Simulator
   =================================================================== */
window.adRewardState = {
    enabled: true,
    reward_diamonds: 30,
    claimed_today: 0,
    max_per_day: 1,
    can_claim: true,
    ad_unit_id: 'ca-app-pub-3940256099942544/1712485313'
};

window.renderRewardAdCard = async function() {
    const wrap = document.getElementById('reward-ad-card-topup-wrapper');
    if (!wrap) return;

    // Fetch live status from backend
    try {
        const token = localStorage.getItem('snake_auth_token') || sessionStorage.getItem('snake_auth_token') || '';
        const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
        const resp = await fetch('api/claim_ad_reward.php?action=status', { headers });
        if (resp.ok) {
            const data = await resp.json();
            if (data && data.success) {
                window.adRewardState = { ...window.adRewardState, ...data };
            }
        }
    } catch(e) {
        console.warn('Ad reward status offline check:', e);
    }

    const state = window.adRewardState;
    const isClaimed = (state.claimed_today >= 1);
    const diaAmount = state.reward_diamonds || 30;

    wrap.innerHTML = `
        <div style="
            width: 100%;
            max-width: 320px;
            margin: 0 auto 12px auto;
            background: radial-gradient(circle at 50% 25%, #f97316 0%, #c2410c 60%, #7c2d12 100%);
            border: 2px solid #fbbf24;
            box-shadow: 0 0 25px rgba(245, 158, 11, 0.45), inset 0 0 15px rgba(254, 240, 138, 0.25);
            border-radius: 14px;
            padding: 14px 16px 12px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            overflow: hidden;
            box-sizing: border-box;
        ">
            <!-- Top badge -->
            <div style="position:absolute; top:8px; left:8px; background:linear-gradient(135deg, #fbbf24, #d97706); color:#000; font-size:9.5px; font-weight:900; padding:2px 8px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.4);">
                🔥 รางวัลพิเศษประจำวัน
            </div>

            <!-- Diamond Amount Title -->
            <div style="font-size:20px; font-weight:900; color:#ffffff; text-shadow:0 2px 6px rgba(0,0,0,0.8), 0 0 14px rgba(255,255,255,0.5); margin-top:14px; letter-spacing:0.5px;">
                ${diaAmount} เพชร
            </div>

            <!-- Shiny 3D Diamond Graphic Cluster -->
            <div style="margin: 10px 0 12px 0; position:relative; display:flex; justify-content:center; align-items:center;">
                <div style="position:absolute; width:110px; height:110px; border-radius:50%; background:radial-gradient(circle, rgba(56, 189, 248, 0.6) 0%, rgba(56, 189, 248, 0) 70%); filter:blur(10px);"></div>
                <svg width="125" height="85" viewBox="0 0 140 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="position:relative; z-index:2; filter:drop-shadow(0 6px 14px rgba(0,0,0,0.55));">
                    <!-- Main Diamond -->
                    <polygon points="70,12 105,38 70,88 35,38" fill="#38bdf8" fill-opacity="0.95" />
                    <polygon points="70,12 88,38 70,88" fill="#0284c7" fill-opacity="0.85" />
                    <polygon points="70,12 52,38 70,88" fill="#bae6fd" fill-opacity="0.95" />
                    <polygon points="52,38 70,12 88,38" fill="#f0f9ff" />
                    <polygon points="35,38 52,38 70,88" fill="#0369a1" />
                    <polygon points="105,38 88,38 70,88" fill="#0284c7" />
                    <!-- Left Small Diamond -->
                    <polygon points="20,45 42,42 35,70 12,65" fill="#38bdf8" fill-opacity="0.85" />
                    <polygon points="20,45 35,70 12,65" fill="#0284c7" />
                    <!-- Right Small Diamond -->
                    <polygon points="120,45 98,42 105,70 128,65" fill="#38bdf8" fill-opacity="0.85" />
                    <polygon points="120,45 105,70 128,65" fill="#0284c7" />
                    <!-- Sparkles -->
                    <circle cx="95" cy="22" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 5px #ffffff)" />
                    <circle cx="45" cy="55" r="2.5" fill="#ffffff" />
                    <circle cx="70" cy="80" r="3" fill="#ffffff" />
                </svg>
            </div>

            <!-- Claim Button (0/1 or 1/1) -->
            <button type="button" id="btn-claim-ad-reward" onclick="handleAdRewardClick()" ${isClaimed ? 'disabled' : ''} style="
                width: 100%;
                padding: 10px 14px;
                background: ${isClaimed ? 'linear-gradient(180deg, #475569 0%, #334155 100%)' : 'linear-gradient(180deg, #b45309 0%, #78350f 100%)'};
                border: 1.5px solid ${isClaimed ? '#64748b' : '#fbbf24'};
                border-radius: 10px;
                color: ${isClaimed ? '#94a3b8' : '#ffffff'};
                font-size: 14px;
                font-weight: 800;
                cursor: ${isClaimed ? 'not-allowed' : 'pointer'};
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                box-shadow: ${isClaimed ? 'none' : '0 4px 14px rgba(0,0,0,0.4), 0 0 12px rgba(251, 191, 36, 0.4)'};
                transition: all 0.2s ease;
            ">
                <span style="display:inline-flex; align-items:center; justify-content:center; width:22px; height:22px; border-radius:50%; background:rgba(0,0,0,0.35); border:1px solid ${isClaimed ? '#94a3b8' : '#fff'}; font-size:10px;">
                    ${isClaimed ? '✓' : '▶'} AD
                </span>
                <span id="ad-reward-btn-label">${isClaimed ? 'ฟรี (1/1) - รับแล้ว' : 'ฟรี (0/1)'}</span>
            </button>
        </div>
    `;
};

window.handleAdRewardClick = async function() {
    if (window.adRewardState.claimed_today >= 1) {
        showToast('คุณได้รับเพชรฟรีจากโฆษณาของวันนี้ไปแล้ว (รีเซ็ตวันใหม่ 00:00 น.)');
        return;
    }

    const btn = document.getElementById('btn-claim-ad-reward');
    if (btn) btn.disabled = true;

    // Check Capacitor AdMob plugin
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob) {
        try {
            const { AdMob } = window.Capacitor.Plugins;
            const rewardId = window.adRewardState.ad_unit_id || 'ca-app-pub-3940256099942544/1712485313';
            showToast('กำลังโหลดโฆษณารางวัล AdMob...');
            await AdMob.prepareRewardVideoAd({ adId: rewardId });
            const rewardResult = await AdMob.showRewardVideoAd();
            console.log('AdMob reward result:', rewardResult);
            await window.sendClaimAdRewardRequest();
            return;
        } catch(err) {
            console.warn('AdMob native failed or cancelled, using simulator fallback:', err);
        }
    }

    // Web / fallback simulation
    window.openSimulatedAdRewardModal();
};

window.openSimulatedAdRewardModal = function() {
    const modal = document.getElementById('modal-simulated-reward-ad');
    if (!modal) {
        window.sendClaimAdRewardRequest();
        return;
    }

    modal.style.display = 'flex';
    let timeLeft = 5;
    const secEl = document.getElementById('ad-countdown-seconds');
    const barEl = document.getElementById('ad-countdown-bar');
    const statusEl = document.getElementById('ad-reward-status-pill');

    if (secEl) secEl.innerText = timeLeft;
    if (barEl) barEl.style.width = '0%';
    if (statusEl) {
        statusEl.innerText = '⏳ กำลังเล่น...';
        statusEl.style.borderColor = '#fbbf24';
        statusEl.style.color = '#fbbf24';
    }

    const timer = setInterval(() => {
        timeLeft--;
        if (secEl) secEl.innerText = Math.max(0, timeLeft);
        if (barEl) barEl.style.width = `${((5 - timeLeft) / 5) * 100}%`;

        if (timeLeft <= 0) {
            clearInterval(timer);
            if (statusEl) {
                statusEl.innerText = '✅ สำเร็จ!';
                statusEl.style.borderColor = '#10b981';
                statusEl.style.color = '#10b981';
            }
            setTimeout(() => {
                modal.style.display = 'none';
                window.sendClaimAdRewardRequest();
            }, 600);
        }
    }, 1000);
};

window.sendClaimAdRewardRequest = async function() {
    try {
        const token = localStorage.getItem('snake_auth_token') || sessionStorage.getItem('snake_auth_token') || '';
        const headers = {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        };
        const resp = await fetch('api/claim_ad_reward.php?action=claim', {
            method: 'POST',
            headers,
            body: JSON.stringify({ action: 'claim' })
        });
        const res = await resp.json();

        if (res && res.success) {
            window.adRewardState.claimed_today = 1;
            window.adRewardState.can_claim = false;
            if (res.new_diamonds !== undefined && typeof DEFAULT_USER !== 'undefined') {
                DEFAULT_USER.diamonds = res.new_diamonds;
                updateUserBar(DEFAULT_USER);
            }
            showToast(res.message || '🎉 ได้รับ 30 เพชรฟรีสำเร็จ!');
            window.renderRewardAdCard();
        } else {
            showToast((res && res.message) ? res.message : 'ไม่สามารถรับรางวัลได้ในขณะนี้');
            window.renderRewardAdCard();
        }
    } catch(e) {
        console.error('sendClaimAdRewardRequest error:', e);
        showToast('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
        window.renderRewardAdCard();
    }
};