<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

$db = getDbConnection();

$action = isset($_GET['action']) ? (string)$_GET['action'] : (isset($_POST['action']) ? (string)$_POST['action'] : '');

$DEFAULT_EVENTS = [
    'malei' => [
        'name' => 'เสียงพากย์เริ่มเกม ("มาเลยๆ")',
        'type' => 'voice',
        'files' => ['malei.mp3'],
        'description' => 'เด็กผู้หญิงพูดภาษาไทยคำว่า "มาเลยๆ" เมื่อเริ่มการแข่งขัน',
        'volume' => 1.0,
        'enabled' => true
    ],
    'yeay' => [
        'name' => 'เสียงได้เริ่มคนแรก ("เย้! ได้ทอยเป็นคนแรก")',
        'type' => 'voice',
        'files' => ['yeay.mp3'],
        'description' => 'เด็กผู้หญิงพูดภาษาไทยคำว่า "เย้! ได้ทอยเป็นคนแรก"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'dice_roll' => [
        'name' => 'เสียงทอยลูกเต๋า (Dice Roll)',
        'type' => 'sfx',
        'files' => ['dice.mp3'],
        'description' => 'เอฟเฟกต์ลูกเต๋าหมุนกระทบพื้นกระดาน (Dice Roll SFX)',
        'volume' => 0.9,
        'enabled' => true
    ],
    'step' => [
        'name' => 'เสียงเดินนับช่อง (Step SFX)',
        'type' => 'sfx',
        'files' => ['walk.mp3'],
        'description' => 'เสียงก้าวเดินสั้นๆ ตามจำนวนแต้มลูกเต๋าในแต่ละช่อง',
        'volume' => 0.85,
        'enabled' => true
    ],
    'double' => [
        'name' => 'เสียงทอยได้แต้มดับเบิล ("ดับเบิล!")',
        'type' => 'voice',
        'files' => ['double.mp3'],
        'description' => 'เด็กผู้หญิงพูดภาษาไทยชัดเจนว่า "ดับเบิล!"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'island_trap' => [
        'name' => 'เสียงตกเกาะ / ติดคุก ("หือๆๆ ติดเกาะซะแล้ว")',
        'type' => 'voice',
        'files' => ['tok-koh.mp3'],
        'description' => 'เด็กผู้หญิงร้องไห้/บ่นภาษาไทยว่า "หือๆๆ ติดเกาะซะแล้ว"',
        'volume' => 1.0,
        'enabled' => true
    ],
    'card_reveal' => [
        'name' => 'เสียงเปิดการ์ด / สุ่มเต๋าทีละใบ ("แซ๊บ!")',
        'type' => 'sfx',
        'files' => ['card_zap.mp3'],
        'description' => 'เอฟเฟกต์เสียงเปิดการ์ดหรือสุ่มเต๋าดัง "แซ๊บ!" ต่อใบ (เช่น 5 ใบ = 5 แซ๊บ ห่างกันใบละ 0.5 วินาที)',
        'volume' => 0.95,
        'enabled' => true,
        'interval_sec' => 0.5,
        'preset' => 'zap_classic'
    ],
    'card_reveal_rare' => [
        'name' => 'เสียงเปิดได้การ์ดแรร์ S / SS+ / กิจกรรม ("แซ๊บ-ออร่า!")',
        'type' => 'sfx',
        'files' => ['card_zap_rare.mp3'],
        'description' => 'เอฟเฟกต์เสียงออร่าพิเศษเมื่อเปิดได้การ์ดระดับ S, SS+ หรือการ์ดจัดกิจกรรม',
        'volume' => 1.0,
        'enabled' => true
    ]
];

function normalizeAudioEventsMap(array $events): array {
    $clean = [];
    foreach ($events as $k => $ev) {
        if ($k === '_schema_v' || !is_array($ev)) {
            continue;
        }
        $key = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim((string)$k));
        if ($key === '') {
            continue;
        }
        $files = [];
        if (isset($ev['files']) && is_array($ev['files'])) {
            foreach ($ev['files'] as $f) {
                $fStr = trim((string)$f);
                if ($fStr !== '' && !in_array($fStr, $files, true)) {
                    $files[] = $fStr;
                }
            }
        }
        $vol = isset($ev['volume']) ? (float)$ev['volume'] : 1.0;
        if ($vol < 0.0) $vol = 0.0;
        if ($vol > 1.0) $vol = 1.0;

        $item = [
            'name' => isset($ev['name']) && trim((string)$ev['name']) !== '' ? trim((string)$ev['name']) : $key,
            'type' => (isset($ev['type']) && $ev['type'] === 'sfx') ? 'sfx' : 'voice',
            'files' => $files,
            'description' => isset($ev['description']) ? trim((string)$ev['description']) : '',
            'volume' => round($vol, 2),
            'enabled' => isset($ev['enabled']) ? (bool)$ev['enabled'] : true
        ];

        if (isset($ev['interval_sec']) || $key === 'card_reveal') {
            $intSec = isset($ev['interval_sec']) ? (float)$ev['interval_sec'] : 0.5;
            if ($intSec < 0.08) $intSec = 0.08;
            if ($intSec > 3.0) $intSec = 3.0;
            $item['interval_sec'] = round($intSec, 2);
        }
        if (isset($ev['preset']) || $key === 'card_reveal') {
            $preset = isset($ev['preset']) && trim((string)$ev['preset']) !== '' ? trim((string)$ev['preset']) : 'zap_classic';
            $item['preset'] = $preset;
        }

        $clean[$key] = $item;
    }
    return $clean;
}

function ensureCardRevealDefaults(array $events, array $defaultEvents): array {
    foreach (['card_reveal', 'card_reveal_rare'] as $reqKey) {
        if (!isset($events[$reqKey]) && isset($defaultEvents[$reqKey])) {
            $events[$reqKey] = $defaultEvents[$reqKey];
        }
    }
    return $events;
}

function getAudioFallbackJsonPath(): string {
    return __DIR__ . '/../config/thai_audio_events.json';
}

function getStoredAudioState($db, array $defaultEvents): array {
    $updatedAt = time();
    try {
        $stmt = $db->prepare("SELECT setting_value, UNIX_TIMESTAMP(updated_at) AS ts FROM game_settings WHERE setting_key = 'thai_audio_events_json' LIMIT 1");
        if ($stmt) {
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                if (!empty($row['ts'])) {
                    $updatedAt = (int)$row['ts'];
                }
                $decoded = json_decode(isset($row['setting_value']) ? (string)$row['setting_value'] : '', true);
                if (is_array($decoded)) {
                    if (empty($decoded['_schema_v']) && isset($decoded['game_start']) && !isset($decoded['malei'])) {
                        $migrated = $defaultEvents;
                        foreach ($decoded as $k => $v) {
                            if ($k === 'game_start' || !is_array($v)) {
                                continue;
                            }
                            $migrated[$k] = array_merge(isset($migrated[$k]) ? $migrated[$k] : [], $v);
                        }
                        $stmt->close();
                        return [
                            'events' => normalizeAudioEventsMap(ensureCardRevealDefaults($migrated, $defaultEvents)),
                            'updatedAt' => $updatedAt
                        ];
                    }

                    $events = normalizeAudioEventsMap(ensureCardRevealDefaults($decoded, $defaultEvents));
                    $stmt->close();
                    return [
                        'events' => $events,
                        'updatedAt' => $updatedAt
                    ];
                }
            }
            $stmt->close();
        }
    } catch (Throwable $e) {
        // Fallback to JSON file or defaults
    }

    $jsonPath = getAudioFallbackJsonPath();
    if (@is_file($jsonPath)) {
        $rawJson = @file_get_contents($jsonPath);
        $decodedFile = is_string($rawJson) ? json_decode($rawJson, true) : null;
        if (is_array($decodedFile)) {
            $mtime = @filemtime($jsonPath);
            return [
                'events' => normalizeAudioEventsMap(ensureCardRevealDefaults($decodedFile, $defaultEvents)),
                'updatedAt' => $mtime ? (int)$mtime : $updatedAt
            ];
        }
    }

    return [
        'events' => normalizeAudioEventsMap($defaultEvents),
        'updatedAt' => $updatedAt
    ];
}

function persistAudioEvents($db, array $events): array {
    $cleanEvents = normalizeAudioEventsMap($events);
    $payloadToStore = $cleanEvents;
    $payloadToStore['_schema_v'] = 2;

    $jsonStr = json_encode($payloadToStore, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    $jsonPath = getAudioFallbackJsonPath();
    $cfgDir = dirname($jsonPath);
    if (!@is_dir($cfgDir)) {
        @mkdir($cfgDir, 0775, true);
    }
    @file_put_contents($jsonPath, $jsonStr);

    $savedDb = false;
    try {
        $stmt = $db->prepare("INSERT INTO game_settings (setting_key, setting_value, category, description, updated_at) VALUES ('thai_audio_events_json', ?, 'audio', 'รายการเสียงพากย์และ SFX ภาษาไทย', NOW()) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()");
        if ($stmt) {
            $stmt->bind_param('s', $jsonStr);
            $savedDb = $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        $savedDb = false;
    }

    if (!$savedDb) {
        try {
            $stmt2 = $db->prepare("INSERT INTO game_settings (setting_key, setting_value) VALUES ('thai_audio_events_json', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            if ($stmt2) {
                $stmt2->bind_param('s', $jsonStr);
                $savedDb = $stmt2->execute();
                $stmt2->close();
            }
        } catch (Throwable $e2) {
            // JSON mirror file already saved above
        }
    }

    return $cleanEvents;
}

if ($action === 'get_config') {
    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    echo json_encode([
        'status' => 'success',
        'basePath' => 'assets/audio/th/',
        'updatedAt' => $state['updatedAt'],
        'events' => $state['events']
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'upload_audio') {
    if (empty($_FILES['audio_file']) || empty($_FILES['audio_file']['tmp_name'])) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบไฟล์เสียงที่อัปโหลด หรือไฟล์มีขนาดใหญ่เกินกำหนด'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $file = $_FILES['audio_file'];
    if (!empty($file['error']) && (int)$file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'อัปโหลดไฟล์ไม่สำเร็จ (Error Code: ' . (int)$file['error'] . ')'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $eventKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($_POST['event_key']) ? (string)$_POST['event_key'] : ''));
    $customName = trim(isset($_POST['custom_name']) ? (string)$_POST['custom_name'] : '');
    $uploadMode = isset($_POST['mode']) && $_POST['mode'] === 'append' ? 'append' : 'replace';

    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['mp3', 'wav', 'ogg', 'm4a', 'aac'], true)) {
        echo json_encode(['status' => 'error', 'message' => 'รองรับเฉพาะไฟล์เสียง .mp3, .wav, .ogg, .m4a เท่านั้น'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $rawBase = $customName !== '' ? $customName : pathinfo((string)$file['name'], PATHINFO_FILENAME);
    $safeBase = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $rawBase);
    $safeBase = trim((string)$safeBase, '_');
    if ($safeBase === '') {
        $safeBase = ($eventKey !== '' ? $eventKey : 'thai_voice') . '_' . date('His');
    }
    $finalFilename = $safeBase . '.' . $ext;

    $primaryDir = __DIR__ . '/../assets/audio/th/';
    if (!@is_dir($primaryDir)) {
        @mkdir($primaryDir, 0777, true);
    }
    $primaryDest = $primaryDir . $finalFilename;

    $uploadedPrimary = false;
    if (function_exists('is_uploaded_file') && @is_uploaded_file($file['tmp_name'])) {
        $uploadedPrimary = @move_uploaded_file($file['tmp_name'], $primaryDest);
    }
    if (!$uploadedPrimary) {
        $uploadedPrimary = @copy($file['tmp_name'], $primaryDest);
    }

    if (!$uploadedPrimary) {
        echo json_encode(['status' => 'error', 'message' => 'บันทึกไฟล์ลงเซิร์ฟเวอร์ไม่สำเร็จ กรุณาตรวจสอบสิทธิ์โฟลเดอร์ assets/audio/th/'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $mirrorDirs = [
        __DIR__ . '/../www/assets/audio/th/',
        __DIR__ . '/../dist/assets/audio/th/',
        __DIR__ . '/../ios/App/App/public/assets/audio/th/'
    ];
    foreach ($mirrorDirs as $mDir) {
        if (!@is_dir($mDir)) {
            @mkdir($mDir, 0777, true);
        }
        if (@is_dir($mDir)) {
            @copy($primaryDest, $mDir . $finalFilename);
        }
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    if ($eventKey !== '') {
        if (!isset($events[$eventKey])) {
            $events[$eventKey] = [
                'name' => isset($_POST['event_name']) && trim((string)$_POST['event_name']) !== '' ? trim((string)$_POST['event_name']) : $eventKey,
                'type' => (isset($_POST['event_type']) && $_POST['event_type'] === 'sfx') ? 'sfx' : 'voice',
                'files' => [$finalFilename],
                'description' => isset($_POST['event_desc']) ? trim((string)$_POST['event_desc']) : '',
                'volume' => isset($_POST['event_volume']) ? (float)$_POST['event_volume'] : 1.0,
                'enabled' => isset($_POST['event_enabled']) ? ((string)$_POST['event_enabled'] !== '0' && (string)$_POST['event_enabled'] !== 'false') : true
            ];
        } else {
            if ($uploadMode === 'replace') {
                $events[$eventKey]['files'] = [$finalFilename];
            } else {
                if (!in_array($finalFilename, $events[$eventKey]['files'], true)) {
                    $events[$eventKey]['files'][] = $finalFilename;
                }
            }
            if (isset($_POST['event_name']) && trim((string)$_POST['event_name']) !== '') {
                $events[$eventKey]['name'] = trim((string)$_POST['event_name']);
            }
            if (isset($_POST['event_desc'])) {
                $events[$eventKey]['description'] = trim((string)$_POST['event_desc']);
            }
            if (isset($_POST['event_type'])) {
                $events[$eventKey]['type'] = ($_POST['event_type'] === 'sfx') ? 'sfx' : 'voice';
            }
            if (isset($_POST['event_volume'])) {
                $events[$eventKey]['volume'] = (float)$_POST['event_volume'];
            }
            if ($eventKey === 'card_reveal') {
                $events[$eventKey]['preset'] = 'custom_file';
            }
        }

        try {
            $events = persistAudioEvents($db, $events);
        } catch (Throwable $e) {
            echo json_encode(['status' => 'error', 'message' => 'อัปโหลดไฟล์สำเร็จ แต่บันทึกฐานข้อมูลไม่สำเร็จ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    echo json_encode([
        'status' => 'success',
        'message' => "อัปโหลดไฟล์เสียง {$finalFilename} สำเร็จเรียบร้อย!",
        'filename' => $finalFilename,
        'path' => 'assets/audio/th/' . $finalFilename,
        'updatedAt' => time(),
        'events' => $events
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'save_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูล JSON ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $origKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($data['orig_key']) ? (string)$data['orig_key'] : ''));
    $eventKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', trim(isset($data['event_key']) ? (string)$data['event_key'] : ''));
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุรหัสเหตุการณ์ (Event Key) เช่น malei, victory, step_1'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    if ($origKey !== '' && $origKey !== $eventKey && isset($events[$origKey])) {
        unset($events[$origKey]);
    }

    $existingItem = isset($events[$eventKey]) && is_array($events[$eventKey]) ? $events[$eventKey] : [];
    $existingFiles = isset($existingItem['files']) ? $existingItem['files'] : [];
    $files = isset($data['files']) && is_array($data['files']) ? $data['files'] : $existingFiles;

    $newItem = [
        'name' => isset($data['name']) && trim((string)$data['name']) !== '' ? trim((string)$data['name']) : $eventKey,
        'type' => (isset($data['type']) && $data['type'] === 'sfx') ? 'sfx' : 'voice',
        'files' => $files,
        'description' => isset($data['description']) ? trim((string)$data['description']) : '',
        'volume' => isset($data['volume']) ? (float)$data['volume'] : 1.0,
        'enabled' => isset($data['enabled']) ? (bool)$data['enabled'] : true
    ];
    if (isset($data['interval_sec']) || isset($existingItem['interval_sec']) || $eventKey === 'card_reveal') {
        $newItem['interval_sec'] = isset($data['interval_sec']) ? (float)$data['interval_sec'] : (isset($existingItem['interval_sec']) ? (float)$existingItem['interval_sec'] : 0.5);
    }
    if (isset($data['preset']) || isset($existingItem['preset']) || $eventKey === 'card_reveal') {
        $newItem['preset'] = isset($data['preset']) ? (string)$data['preset'] : (isset($existingItem['preset']) ? (string)$existingItem['preset'] : 'zap_classic');
    }
    $events[$eventKey] = $newItem;

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "บันทึกเหตุการณ์เสียง '{$eventKey}' สำเร็จ!",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'save_card_reveal_config') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูล JSON ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];

    $curReveal = isset($events['card_reveal']) && is_array($events['card_reveal']) ? $events['card_reveal'] : $DEFAULT_EVENTS['card_reveal'];
    $curRare = isset($events['card_reveal_rare']) && is_array($events['card_reveal_rare']) ? $events['card_reveal_rare'] : $DEFAULT_EVENTS['card_reveal_rare'];

    $preset = isset($data['preset']) && trim((string)$data['preset']) !== '' ? trim((string)$data['preset']) : ($curReveal['preset'] ?? 'zap_classic');
    $intervalSec = isset($data['interval_sec']) ? (float)$data['interval_sec'] : (float)($curReveal['interval_sec'] ?? 0.5);
    if ($intervalSec < 0.08) $intervalSec = 0.08;
    if ($intervalSec > 3.0) $intervalSec = 3.0;

    $vol = isset($data['volume']) ? (float)$data['volume'] : (float)($curReveal['volume'] ?? 0.95);
    $enabled = isset($data['enabled']) ? (bool)$data['enabled'] : (bool)($curReveal['enabled'] ?? true);
    $rareEnabled = isset($data['rare_enabled']) ? (bool)$data['rare_enabled'] : (bool)($curRare['enabled'] ?? true);

    $presetFileMap = [
        'zap_classic' => 'card_zap.mp3',
        'zap_magic'   => 'card_zap_magic.mp3',
        'card_whip'   => 'card_whip.mp3',
        'coin_ping'   => 'card_crystal.mp3'
    ];

    $files = isset($data['files']) && is_array($data['files']) && count($data['files']) > 0
        ? $data['files']
        : (isset($presetFileMap[$preset]) ? [$presetFileMap[$preset]] : ($curReveal['files'] ?? ['card_zap.mp3']));

    $events['card_reveal'] = [
        'name' => $curReveal['name'] ?? 'เสียงเปิดการ์ด / สุ่มเต๋าทีละใบ ("แซ๊บ!")',
        'type' => 'sfx',
        'files' => $files,
        'description' => "เอฟเฟกต์เสียงเปิดการ์ดหรือสุ่มเต๋าดัง แซ๊บ! ต่อใบ (ห่างกันใบละ {$intervalSec} วินาที)",
        'volume' => $vol,
        'enabled' => $enabled,
        'interval_sec' => round($intervalSec, 2),
        'preset' => $preset
    ];

    $events['card_reveal_rare'] = [
        'name' => $curRare['name'] ?? 'เสียงเปิดได้การ์ดแรร์ S / SS+ / กิจกรรม ("แซ๊บ-ออร่า!")',
        'type' => 'sfx',
        'files' => $curRare['files'] ?? ['card_zap_rare.mp3'],
        'description' => $curRare['description'] ?? 'เอฟเฟกต์เสียงออร่าพิเศษเมื่อเปิดได้การ์ดระดับ S, SS+ หรือการ์ดจัดกิจกรรม',
        'volume' => isset($data['rare_volume']) ? (float)$data['rare_volume'] : (float)($curRare['volume'] ?? 1.0),
        'enabled' => $rareEnabled
    ];

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "บันทึกตั้งค่าเสียงเปิดการ์ด/สุ่มเต๋า (ห่างกันใบละ {$intervalSec} วิ) เรียบร้อยแล้ว!",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'toggle_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    $eventKey = is_array($data) && isset($data['event_key']) ? trim((string)$data['event_key']) : '';
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรหัสเหตุการณ์เสียง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    if (!isset($events[$eventKey])) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรายการเสียงที่ต้องการเปิด/ปิด'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $events[$eventKey]['enabled'] = isset($data['enabled']) ? (bool)$data['enabled'] : !$events[$eventKey]['enabled'];

    try {
        $events = persistAudioEvents($db, $events);
        $statusTxt = $events[$eventKey]['enabled'] ? 'เปิดใช้งาน' : 'ปิดเสียง';
        echo json_encode([
            'status' => 'success',
            'message' => "{$statusTxt} '{$events[$eventKey]['name']}' เรียบร้อยแล้ว",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'delete_item') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    $eventKey = is_array($data) && isset($data['event_key']) ? trim((string)$data['event_key']) : '';
    if ($eventKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรหัสเหตุการณ์เสียง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    if (!isset($events[$eventKey])) {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบรายการเสียงที่ต้องการลบ'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $deletedName = $events[$eventKey]['name'];
    unset($events[$eventKey]);

    try {
        $events = persistAudioEvents($db, $events);
        echo json_encode([
            'status' => 'success',
            'message' => "ลบรายการเสียง '{$deletedName}' เรียบร้อยแล้ว",
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'reset_defaults') {
    $state = getStoredAudioState($db, $DEFAULT_EVENTS);
    $events = $state['events'];
    foreach ($DEFAULT_EVENTS as $defKey => $defVal) {
        $events[$defKey] = $defVal;
    }
    $ordered = [];
    foreach ($DEFAULT_EVENTS as $defKey => $defVal) {
        $ordered[$defKey] = $events[$defKey];
    }
    foreach ($events as $k => $v) {
        if (!isset($ordered[$k])) {
            $ordered[$k] = $v;
        }
    }

    try {
        $saved = persistAudioEvents($db, $ordered);
        echo json_encode([
            'status' => 'success',
            'message' => 'คืนค่ารายการเสียงเริ่มต้นครบทุกรายการเรียบร้อยแล้ว!',
            'updatedAt' => time(),
            'events' => $saved
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($action === 'save_events') {
    $raw = (string)file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['events']) || !is_array($data['events'])) {
        echo json_encode(['status' => 'error', 'message' => 'ข้อมูล events ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $events = persistAudioEvents($db, $data['events']);
        echo json_encode([
            'status' => 'success',
            'message' => 'บันทึกการตั้งค่าระบบเสียงภาษาไทยสำเร็จ!',
            'updatedAt' => time(),
            'events' => $events
        ], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการบันทึก: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Unknown action'], JSON_UNESCAPED_UNICODE);
