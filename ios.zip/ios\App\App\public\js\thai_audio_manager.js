/**
 * Snake & Ladder 3D - Thai Audio Manager Module (ระบบเสียงประกอบ & เสียงพากย์ภาษาไทย)
 * Supports HTML5 Audio pooling, async preloading, overlapping playback, and custom sound mappings from Admin Panel.
 */
(function(window) {
    'use strict';

    const DEFAULT_AUDIO_CONFIG = {
        enabled: true,
        voiceEnabled: true,
        sfxEnabled: true,
        masterVolume: 0.85,
        voiceVolume: 1.0,
        sfxVolume: 0.85,
        basePath: 'assets/audio/th/',
        updatedAt: 1,
        events: {
            'malei': {
                name: 'เสียงพากย์เริ่มเกม ("มาเลยๆ")',
                type: 'voice',
                files: ['malei.mp3'],
                description: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "มาเลยๆ" เมื่อเริ่มการแข่งขัน',
                volume: 1.0,
                enabled: true
            },
            'yeay': {
                name: 'เสียงได้เริ่มคนแรก ("เย้! ได้ทอยเป็นคนแรก")',
                type: 'voice',
                files: ['yeay.mp3'],
                description: 'เด็กผู้หญิงพูดภาษาไทยคำว่า "เย้! ได้ทอยเป็นคนแรก"',
                volume: 1.0,
                enabled: true
            },
            'dice_roll': {
                name: 'เสียงทอยลูกเต๋า (Dice Roll)',
                type: 'sfx',
                files: ['dice.mp3'],
                description: 'เอฟเฟกต์ลูกเต๋าหมุนกระทบพื้นกระดาน (Dice Roll SFX)',
                volume: 0.9,
                enabled: true
            },
            'step': {
                name: 'เสียงเดินนับช่อง (Step SFX)',
                type: 'sfx',
                files: ['walk.mp3'],
                description: 'เสียงก้าวเดินสั้นๆ ตามจำนวนแต้มลูกเต๋าในแต่ละช่อง',
                volume: 0.85,
                enabled: true
            },
            'double': {
                name: 'เสียงทอยได้แต้มดับเบิล ("ดับเบิล!")',
                type: 'voice',
                files: ['double.mp3'],
                description: 'เด็กผู้หญิงพูดภาษาไทยชัดเจนว่า "ดับเบิล!"',
                volume: 1.0,
                enabled: true
            },
            'island_trap': {
                name: 'เสียงตกเกาะ / ติดคุก ("หือๆๆ ติดเกาะซะแล้ว")',
                type: 'voice',
                files: ['tok-koh.mp3'],
                description: 'เด็กผู้หญิงร้องไห้/บ่นภาษาไทยว่า "หือๆๆ ติดเกาะซะแล้ว"',
                volume: 1.0,
                enabled: true
            },
            'card_reveal': {
                name: 'เสียงเปิดการ์ด / สุ่มเต๋าทีละใบ ("แซ๊บ!")',
                type: 'sfx',
                files: ['card_zap.mp3'],
                description: 'เอฟเฟกต์เสียงเปิดการ์ดหรือสุ่มเต๋าดัง "แซ๊บ!" ต่อใบ (5 ใบ = 5 แซ๊บ ห่างกันใบละ 1 วินาที)',
                volume: 0.95,
                enabled: true,
                interval_sec: 1.0,
                preset: 'zap_classic'
            },
            'card_reveal_rare': {
                name: 'เสียงเปิดได้การ์ดแรร์ S / SS+ / กิจกรรม ("แซ๊บ-ออร่า!")',
                type: 'sfx',
                files: ['card_zap_rare.mp3'],
                description: 'เอฟเฟกต์เสียงออร่าพิเศษเมื่อเปิดได้การ์ดระดับ S, SS+ หรือการ์ดจัดกิจกรรม',
                volume: 1.0,
                enabled: true
            }
        }
    };

    class ThaiAudioManager {
        constructor() {
            this.config = JSON.parse(JSON.stringify(DEFAULT_AUDIO_CONFIG));
            this.audioPool = {}; // soundId -> Array of HTMLAudioElement
            this.poolSizePerSound = 10; // allow rapid overlapping playback (e.g. 5-10 card reveals or footsteps) without delay
            this.poolIndices = {};
            this.isInitialized = false;
            this.audioContext = null;

            this.loadLocalPreferences();
        }

        loadLocalPreferences() {
            try {
                const saved = localStorage.getItem('snake_thai_audio_settings');
                if (saved) {
                    const parsed = JSON.parse(saved);
                    if (typeof parsed.enabled === 'boolean') this.config.enabled = parsed.enabled;
                    if (typeof parsed.voiceEnabled === 'boolean') this.config.voiceEnabled = parsed.voiceEnabled;
                    if (typeof parsed.sfxEnabled === 'boolean') this.config.sfxEnabled = parsed.sfxEnabled;
                    if (typeof parsed.masterVolume === 'number') this.config.masterVolume = parsed.masterVolume;
                    if (typeof parsed.voiceVolume === 'number') this.config.voiceVolume = parsed.voiceVolume;
                    if (typeof parsed.sfxVolume === 'number') this.config.sfxVolume = parsed.sfxVolume;
                }
            } catch (e) {
                console.warn('[ThaiAudio] Failed to load local preferences:', e);
            }
        }

        saveLocalPreferences() {
            try {
                localStorage.setItem('snake_thai_audio_settings', JSON.stringify({
                    enabled: this.config.enabled,
                    voiceEnabled: this.config.voiceEnabled,
                    sfxEnabled: this.config.sfxEnabled,
                    masterVolume: this.config.masterVolume,
                    voiceVolume: this.config.voiceVolume,
                    sfxVolume: this.config.sfxVolume
                }));
            } catch (e) {
                console.warn('[ThaiAudio] Failed to save local preferences:', e);
            }
        }

        /**
         * Initialize Audio Engine & Preload sound files asynchronously
         */
        init() {
            if (this.isInitialized) return;
            this.isInitialized = true;

            this.fetchServerConfig();

            // Unlock media playback on first user gesture (iOS / Capacitor WKWebView / Android policy)
            const unlockHandler = () => {
                try {
                    const AudioCtx = window.AudioContext || window.webkitAudioContext;
                    if (AudioCtx && !this.audioContext) {
                        this.audioContext = new AudioCtx();
                    }
                    if (this.audioContext && this.audioContext.state === 'suspended') {
                        this.audioContext.resume();
                    }
                } catch (e) {}
                window.removeEventListener('pointerdown', unlockHandler);
                window.removeEventListener('touchstart', unlockHandler);
                window.removeEventListener('keydown', unlockHandler);
            };
            window.addEventListener('pointerdown', unlockHandler, { once: true, passive: true });
            window.addEventListener('touchstart', unlockHandler, { once: true, passive: true });
            window.addEventListener('keydown', unlockHandler, { once: true });

            this.preloadAll();
            console.log('[ThaiAudio] Initialized Thai Voice & SFX Manager');
        }

        async fetchServerConfig() {
            try {
                const res = await fetch('api/audio_settings.php?action=get_config&t=' + Date.now());
                if (res.ok) {
                    const data = await res.json();
                    if (data && data.status === 'success' && data.events && typeof data.events === 'object') {
                        const prevVer = this.config.updatedAt;
                        this.config.events = data.events;
                        if (data.basePath) this.config.basePath = data.basePath;
                        this.config.updatedAt = data.updatedAt || Date.now();
                        if (prevVer !== this.config.updatedAt) {
                            this.audioPool = {};
                            this.poolIndices = {};
                        }
                        this.preloadAll();
                    }
                }
            } catch (e) {
                // Fallback to built-in audio files offline / Capacitor local bundle
            }
        }

        resolveAudioUrl(filename) {
            const basePath = this.config.basePath || 'assets/audio/th/';
            const ver = this.config.updatedAt || 1;
            if (filename.startsWith('http://') || filename.startsWith('https://') || filename.startsWith('/')) {
                return filename.includes('?') ? filename : `${filename}?v=${ver}`;
            }
            return `${basePath}${filename}?v=${ver}`;
        }

        /**
         * Preload all enabled sound files into HTML5 Audio element pools
         */
        preloadAll() {
            Object.keys(this.config.events || {}).forEach(eventKey => {
                const ev = this.config.events[eventKey];
                if (!ev || ev.enabled === false || !Array.isArray(ev.files) || !ev.files.length) return;

                ev.files.forEach(filename => {
                    if (!filename) return;
                    const soundId = `${eventKey}_${filename}_${this.config.updatedAt || 1}`;
                    if (!this.audioPool[soundId]) {
                        this.audioPool[soundId] = [];
                        this.poolIndices[soundId] = 0;

                        const fullUrl = this.resolveAudioUrl(filename);
                        const poolCount = ev.type === 'sfx' ? this.poolSizePerSound : 3;

                        for (let i = 0; i < poolCount; i++) {
                            const audio = new Audio();
                            audio.preload = 'auto';
                            audio.src = fullUrl;
                            try {
                                audio.load();
                            } catch (e) {}
                            this.audioPool[soundId].push(audio);
                        }
                    }
                });
            });
        }

        isEventPlayable(eventKey) {
            const ev = this.config.events && this.config.events[eventKey];
            return Boolean(ev && ev.enabled !== false && Array.isArray(ev.files) && ev.files.length > 0);
        }

        /**
         * Play sound registered to eventKey asynchronously without blocking
         * @param {string} eventKey - e.g. 'malei', 'yeay', 'dice_roll', 'step', 'double', 'island_trap'
         * @param {object} [options] - override options like volume, file
         */
        play(eventKey, options = {}) {
            if (!this.config.enabled) return;

            // Audio Ducking: ลดเสียงเพลงบรรยากาศล็อบบี้ลงชั่วคราวเมื่อมีเสียงพากย์หรือ SFX เล่น
            if (typeof window.duckLobbyAmbientSound === 'function') {
                window.duckLobbyAmbientSound(1600, 0.05);
            }

            const ev = this.config.events && this.config.events[eventKey];
            if (!ev || ev.enabled === false) return;

            if (ev.type === 'voice' && !this.config.voiceEnabled) return;
            if (ev.type === 'sfx' && !this.config.sfxEnabled) return;

            const files = Array.isArray(ev.files) ? ev.files : [];
            if (!files.length) return;

            let targetFile = files[0];
            if (files.length > 1) {
                targetFile = files[Math.floor(Math.random() * files.length)];
            }
            if (options.file && files.includes(options.file)) {
                targetFile = options.file;
            }

            const soundId = `${eventKey}_${targetFile}_${this.config.updatedAt || 1}`;
            let pool = this.audioPool[soundId];
            if (!pool || pool.length === 0) {
                const fullUrl = this.resolveAudioUrl(targetFile);
                pool = [];
                const poolCount = ev.type === 'sfx' ? this.poolSizePerSound : 3;
                for (let i = 0; i < poolCount; i++) {
                    const a = new Audio(fullUrl);
                    a.preload = 'auto';
                    pool.push(a);
                }
                this.audioPool[soundId] = pool;
                this.poolIndices[soundId] = 0;
            }

            const idx = this.poolIndices[soundId] || 0;
            const audioElem = pool[idx];
            this.poolIndices[soundId] = (idx + 1) % pool.length;

            const categoryVol = (ev.type === 'voice') ? this.config.voiceVolume : this.config.sfxVolume;
            const eventVol = (ev.volume !== undefined && !isNaN(Number(ev.volume))) ? Number(ev.volume) : 1.0;
            const optVol = (options.volume !== undefined) ? Number(options.volume) : 1.0;
            const finalVol = Math.max(0, Math.min(1, this.config.masterVolume * categoryVol * eventVol * optVol));

            try {
                audioElem.volume = finalVol;
                audioElem.currentTime = 0;
                const playPromise = audioElem.play();
                if (playPromise !== undefined) {
                    playPromise.catch(err => {
                        console.debug(`[ThaiAudio] Playback skipped or awaiting gesture for ${soundId}:`, err.message);
                    });
                }
            } catch (err) {
                console.warn(`[ThaiAudio] Audio error playing ${soundId}:`, err);
            }
        }

        playIfConfigured(eventKey, options = {}) {
            if (this.isEventPlayable(eventKey)) {
                this.play(eventKey, options);
            }
        }

        // Convenience trigger methods bound to Game Events
        playGameStart(isFirstPlayer = true) {
            // หยุดเสียงเพลงล็อบบี้ทันทีเมื่อเข้าสู่การแข่งขันจริง
            if (typeof window.stopLobbyAmbientSound === 'function') {
                window.stopLobbyAmbientSound();
            }

            // Refresh latest Admin settings in background when starting a match
            this.fetchServerConfig();

            const hasMalei = this.isEventPlayable('malei');
            const hasYeay = this.isEventPlayable('yeay');

            if (isFirstPlayer && hasMalei && hasYeay) {
                this.play(Math.random() < 0.5 ? 'malei' : 'yeay');
            } else if (isFirstPlayer && hasYeay) {
                this.play('yeay');
            } else if (hasMalei) {
                this.play('malei');
            } else if (hasYeay) {
                this.play('yeay');
            } else if (this.isEventPlayable('game_start')) {
                this.play('game_start');
            }
        }

        playDiceRoll() {
            this.playIfConfigured('dice_roll');
        }

        playStep(stepIndex = 1) {
            this.playIfConfigured('step');
            if (stepIndex >= 1 && stepIndex <= 12) {
                this.playIfConfigured(`step_${stepIndex}`);
            }
        }

        playDouble() {
            this.playIfConfigured('double');
        }

        playIslandTrap() {
            this.playIfConfigured('island_trap');
        }

        getCardRevealIntervalSec() {
            const ev = this.config && this.config.events && this.config.events['card_reveal'];
            if (ev && ev.interval_sec !== undefined && !isNaN(Number(ev.interval_sec))) {
                return Math.max(0.08, Math.min(3.0, Number(ev.interval_sec)));
            }
            return 1.0;
        }

        playCardReveal(isRare = false) {
            if (!this.config.enabled || !this.config.sfxEnabled) return;
            const ev = (this.config.events && this.config.events['card_reveal']) || {
                enabled: true,
                volume: 0.95,
                preset: 'zap_classic',
                files: ['card_zap.mp3']
            };
            if (ev.enabled === false) return;

            const preset = ev.preset || 'zap_classic';
            const vol = (ev.volume !== undefined && !isNaN(Number(ev.volume))) ? Number(ev.volume) : 0.95;

            if (this.isEventPlayable('card_reveal')) {
                this.play('card_reveal');
            }
            if (isRare && this.isEventPlayable('card_reveal_rare')) {
                this.play('card_reveal_rare');
            }
            if (preset !== 'custom_file' && window.soundEngine && typeof window.soundEngine.playCardRevealZap === 'function') {
                window.soundEngine.playCardRevealZap(preset, isRare, vol);
            }
        }

        // Volume controls
        setMasterVolume(val) {
            this.config.masterVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        setVoiceVolume(val) {
            this.config.voiceVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        setSfxVolume(val) {
            this.config.sfxVolume = Math.max(0, Math.min(1, parseFloat(val) || 0));
            this.saveLocalPreferences();
        }

        toggleMaster(enable) {
            this.config.enabled = (enable !== undefined) ? !!enable : !this.config.enabled;
            this.saveLocalPreferences();
            return this.config.enabled;
        }

        toggleVoice(enable) {
            this.config.voiceEnabled = (enable !== undefined) ? !!enable : !this.config.voiceEnabled;
            this.saveLocalPreferences();
            return this.config.voiceEnabled;
        }

        toggleSfx(enable) {
            this.config.sfxEnabled = (enable !== undefined) ? !!enable : !this.config.sfxEnabled;
            this.saveLocalPreferences();
            return this.config.sfxEnabled;
        }
    }

    window.ThaiAudio = new ThaiAudioManager();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => window.ThaiAudio.init());
    } else {
        window.ThaiAudio.init();
    }

})(window);
