/**
 * api_client.js - Client integration layer for Snake & Ladder 3D Backend APIs
 * Connects to PHP 8.4 backend on Nginx/1.31.6
 */

class SnakeApiClient {
    constructor(baseUrl = '') {
        this.baseUrl = baseUrl;
        this.token = localStorage.getItem('snake_auth_token') || '';
        this.user = JSON.parse(localStorage.getItem('snake_user_data') || 'null');
    }

    setToken(token) {
        this.token = token;
        localStorage.setItem('snake_auth_token', token);
        localStorage.setItem('game_session_token', token);
    }

    setAuth(token, user) {
        this.token = token;
        this.user = user;
        localStorage.setItem('snake_auth_token', token);
        localStorage.setItem('snake_user_data', JSON.stringify(user));
    }

    clearAuth() {
        this.token = '';
        this.user = null;
        localStorage.removeItem('snake_auth_token');
        localStorage.removeItem('game_session_token');
        localStorage.removeItem('snake_user_data');
    }

    async request(endpoint, options = {}) {
        let url = `${this.baseUrl}${endpoint}`;
        if (this.token && !url.includes('token=')) {
            const sep = url.includes('?') ? '&' : '?';
            url += `${sep}token=${encodeURIComponent(this.token)}`;
        }
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            ...(this.token ? { 'Authorization': `Bearer ${this.token}` } : {}),
            ...(options.headers || {})
        };

        try {
            const res = await fetch(url, { ...options, headers });
            const data = await res.json();
            return data;
        } catch (err) {
            console.error(`API Error on ${endpoint}:`, err);
            return { status: 'error', message: err.message };
        }
    }

    // --- Auth API ---
    async loginByUsername(username) {
        const res = await this.request('api/auth.php?action=login_by_username', {
            method: 'POST',
            body: JSON.stringify({ username })
        });
        if (res.status === 'success' && res.token) {
            this.setAuth(res.token, res.data);
        }
        return res;
    }

    async registerProfile(payload) {
        const res = await this.request('api/auth.php?action=register_profile', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        if (res.status === 'success' && res.token) {
            this.setAuth(res.token, res.data);
        }
        return res;
    }

    async loginWithLine(mockId = null, mockName = null, mockPicture = null, idToken = null, inviterId = null) {
        const payload = mockId 
            ? {
                action: 'login_line',
                userId: mockId,
                displayName: mockName,
                pictureUrl: mockPicture,
                mock_line_id: mockId,
                mock_name: mockName,
                mock_picture: mockPicture,
                id_token: idToken || '',
                inviter_id: inviterId
              }
            : { action: 'login_line', id_token: idToken || 'LIVE_LINE_TOKEN', inviter_id: inviterId };
        
        const res = await this.request('api/auth.php', { method: 'POST', body: JSON.stringify(payload) });
        if (res.status === 'success' && res.token) {
            this.setAuth(res.token, res.user);
        }
        return res;
    }

    async loginWithGoogle(googleIdOrObj = null, mockName = null, mockPicture = null, idToken = null, accessToken = null, inviterId = null) {
        let payload;
        if (googleIdOrObj && typeof googleIdOrObj === 'object') {
            payload = {
                action: 'login_google',
                google_id: googleIdOrObj.sub || googleIdOrObj.google_id || googleIdOrObj.id || googleIdOrObj.email || '',
                sub: googleIdOrObj.sub || googleIdOrObj.google_id || googleIdOrObj.id || '',
                name: googleIdOrObj.name || googleIdOrObj.displayName || googleIdOrObj.username || '',
                picture: googleIdOrObj.picture || googleIdOrObj.avatar_url || '',
                email: googleIdOrObj.email || '',
                mock_google_id: googleIdOrObj.sub || googleIdOrObj.google_id || googleIdOrObj.id || '',
                mock_name: googleIdOrObj.name || googleIdOrObj.displayName || '',
                mock_picture: googleIdOrObj.picture || googleIdOrObj.avatar_url || '',
                id_token: googleIdOrObj.id_token || googleIdOrObj.credential || idToken || '',
                access_token: googleIdOrObj.access_token || accessToken || '',
                inviter_id: inviterId
            };
        } else if (googleIdOrObj) {
            payload = {
                action: 'login_google',
                google_id: googleIdOrObj,
                name: mockName,
                picture: mockPicture,
                mock_google_id: googleIdOrObj,
                mock_name: mockName,
                mock_picture: mockPicture,
                id_token: idToken || '',
                access_token: accessToken || '',
                inviter_id: inviterId
            };
        } else {
            payload = { action: 'login_google', id_token: idToken || 'LIVE_GOOGLE_TOKEN', access_token: accessToken || '', inviter_id: inviterId };
        }

        const res = await this.request('api/auth.php', { method: 'POST', body: JSON.stringify(payload) });
        if (res.status === 'success' && res.token) {
            this.setAuth(res.token, res.user || res.data);
        }
        return res;
    }

    async getProfile() {
        const res = await this.request('api/auth.php?action=profile');
        if (res.status === 'success' && res.data) {
            this.user = res.data;
            localStorage.setItem('snake_user_data', JSON.stringify(res.data));
        }
        return res;
    }

    async syncProgress(payload = {}) {
        const res = await this.request('api/auth.php?action=sync_progress', {
            method: 'POST',
            body: JSON.stringify({ action: 'sync_progress', ...payload })
        });
        if (res && res.status === 'success' && res.data) {
            this.user = res.data;
            localStorage.setItem('snake_user_data', JSON.stringify(res.data));
        }
        return res;
    }

    async inviteFriend() {
        const res = await this.request('api/auth.php?action=invite_friend', {
            method: 'POST',
            body: JSON.stringify({ action: 'invite_friend' })
        });
        if (res && res.status === 'success' && res.data) {
            this.user = res.data;
            localStorage.setItem('snake_user_data', JSON.stringify(res.data));
        }
        return res;
    }

    async deleteAccount() {
        const res = await this.request('api/auth.php?action=delete_account', { method: 'POST' });
        if (res.status === 'success') {
            this.clearAuth();
        }
        return res;
    }

    // --- Shop & Gacha API ---
    async getCatalog() {
        return await this.request('api/shop.php?action=get_catalog');
    }

    async buyItem(itemType, itemId, currency = 'GOLD') {
        return await this.request('api/shop.php?action=buy_item', {
            method: 'POST',
            body: JSON.stringify({ item_type: itemType, item_id: itemId, currency })
        });
    }

    async gachaRoll(count = 1) {
        return await this.request('api/shop.php?action=gacha_roll', {
            method: 'POST',
            body: JSON.stringify({ count })
        });
    }

    async exchangeSPlusCard(targetCharacterId = 1, tierGrade = '') {
        return await this.request('api/shop.php?action=exchange_splus_card', {
            method: 'POST',
            body: JSON.stringify({ target_character_id: targetCharacterId, tier_grade: tierGrade })
        });
    }

    async upgradeCard(inventoryId) {
        return await this.request('api/shop.php?action=upgrade_card', {
            method: 'POST',
            body: JSON.stringify({ inventory_id: inventoryId })
        });
    }

    async getInventory() {
        return await this.request('api/shop.php?action=get_inventory');
    }

    async getMailbox() {
        return await this.request('api/shop.php?action=get_mailbox');
    }

    async claimMail(mailId = null, claimAll = false) {
        return await this.request('api/shop.php?action=claim_mail', {
            method: 'POST',
            body: JSON.stringify({ mail_id: mailId, claim_all: claimAll })
        });
    }

    async redeemPromoCode(code) {
        return await this.request('api/shop.php?action=redeem_code', {
            method: 'POST',
            body: JSON.stringify({ promo_code: code })
        });
    }

    async topupPurchase(packageId) {
        return await this.request('api/shop.php?action=topup_purchase', {
            method: 'POST',
            body: JSON.stringify({ package_id: packageId })
        });
    }

    // --- Matchmaking API ---
    async getRoomConfigs() {
        return await this.request('api/matchmaking.php?action=get_room_configs');
    }

    async createRoom(tier = '2M', mode = '2P', theme = 'classic') {
        return await this.request('api/matchmaking.php?action=create_room', {
            method: 'POST',
            body: JSON.stringify({ room_tier: tier, game_mode: mode, board_theme: theme })
        });
    }

    async joinRoomByCode(code) {
        return await this.request('api/matchmaking.php?action=join_room_by_code', {
            method: 'POST',
            body: JSON.stringify({ room_code: code })
        });
    }

    async quickMatch(tier = '2M', mode = '2P', boardTheme = 'classic') {
        return await this.request('api/matchmaking.php?action=quick_match', {
            method: 'POST',
            body: JSON.stringify({ room_tier: tier, game_mode: mode, board_theme: boardTheme })
        });
    }

    async checkRoomStatus(roomId, extraQuery = '') {
        const query = extraQuery ? `&${extraQuery}` : '';
        return await this.request(`api/matchmaking.php?action=check_room_status&room_id=${roomId}${query}`);
    }

    async triggerFastMatch(roomId) {
        return await this.request('api/matchmaking.php?action=fast_match', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId })
        });
    }

    async selectTurnCard(roomId, choice) {
        return await this.request('api/matchmaking.php?action=select_turn_card', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId, turn_choice: choice })
        });
    }

    async finishMatch(roomId, winnerUserId, isBot = false) {
        return await this.request('api/matchmaking.php?action=finish_match', {
            method: 'POST',
            body: JSON.stringify({ room_id: roomId, winner_user_id: winnerUserId, is_winner_bot: isBot })
        });
    }

    // --- Leaderboard API ---
    async getLeaderboard(type = 'all') {
        return await this.request(`api/leaderboard.php?type=${type}`);
    }

    // --- Event Gacha & Magic Cube API ---
    async getActiveEventGacha() {
        return await this.request('api/shop.php?action=get_active_event_gacha');
    }

    async rollEventGacha(packCount = 1) {
        return await this.request('api/shop.php?action=roll_event_gacha', {
            method: 'POST',
            body: JSON.stringify({ pack_count: packCount })
        });
    }

    async getUserCubes() {
        return await this.request('api/shop.php?action=get_user_cubes');
    }

    async equipCubeToSlot(userCubeId, slotIndex) {
        return await this.request('api/shop.php?action=equip_cube_to_slot', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId, slot_index: slotIndex })
        });
    }

    async removeCubeFromSlot(userCubeId) {
        return await this.request('api/shop.php?action=remove_cube_from_slot', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }

    async startSpinCube(userCubeId, currency = 'DIAMOND', slotIndex = 0) {
        return await this.request('api/shop.php?action=start_spin_cube', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId, currency: currency, slot_index: slotIndex })
        });
    }

    async speedupCube(userCubeId) {
        return await this.request('api/shop.php?action=speedup_cube', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }

    async claimCubeReward(userCubeId) {
        return await this.request('api/shop.php?action=claim_cube_reward', {
            method: 'POST',
            body: JSON.stringify({ user_cube_id: userCubeId })
        });
    }
}

window.apiClient = new SnakeApiClient();

