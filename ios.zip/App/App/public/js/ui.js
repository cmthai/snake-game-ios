/**
 * ui.js - Main UI Controller for In-Game Modals, Popups, Gacha, Lobby, Crafting, and Audio FX
 */

// 🌐 อัปเดตและล็อกชื่อแท็บเบราว์เซอร์ให้เป็นชื่อทางการของเกมส์
const GAME_APP_TITLE = '[เกมส์บันไดงู-เศรษฐี 3D]';
if (document.title !== GAME_APP_TITLE) {
    document.title = GAME_APP_TITLE;
}

/**
 * 🌐 ระบบ Auto Scale & Fit to Screen แบบอัตโนมัติตามสัดส่วนหน้าจอจริง (Window Dimensions & Aspect Ratio)
 * ควบคุมองค์ประกอบทั้งหมด (เมนูด้านซ้าย, แถบด้านบนเพชร/ทอง, กล่องกิจกรรมด้านขวา, ปุ่มทอยเต๋า)
 * ให้ยืดหยุ่นเต็มหน้าจอแนวนอนพอดี โดยไม่มีขอบสีดำเหลืออยู่รอบข้าง และป้องกัน UI เพี้ยน/ปุ่มซ้อนทับกัน
 */
window.updateResponsiveScreenLayout = function() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const aspect = w / Math.max(1, h);
    const isLandscape = aspect >= 1.0;

    let scale = 1.0;
    let topbarH = 46;
    let sidePanelW = 200;
    let hudScale = 0.95;

    if (isLandscape) {
        if (w >= 1920) {
            topbarH = 48;
            sidePanelW = 210;
            hudScale = 1.0;
        } else if (w >= 1440) {
            topbarH = 46;
            sidePanelW = 200;
            hudScale = 0.96;
        } else if (w >= 1150) {
            topbarH = 44;
            sidePanelW = 190;
            hudScale = 0.92;
        } else if (w >= 900) {
            topbarH = 42;
            sidePanelW = 180;
            hudScale = 0.88;
        } else if (w >= 750) {
            topbarH = 40;
            sidePanelW = 170;
            const freeMiddleSpace = w - (sidePanelW * 2) - 14;
            hudScale = Math.min(0.85, Math.max(0.65, freeMiddleSpace / 380));
        } else {
            // Very compact mobile landscape
            topbarH = 38;
            sidePanelW = Math.max(150, Math.min(168, Math.round(w * 0.22)));
            const freeMiddleSpace = w - (sidePanelW * 2) - 10;
            hudScale = Math.min(0.78, Math.max(0.60, freeMiddleSpace / 360));
        }
    } else {
        // Portrait fallback
        scale = Math.max(0.75, w / 480);
        topbarH = 48;
        sidePanelW = Math.round(w * 0.40);
        hudScale = 0.85;
    }

    const root = document.documentElement;
    root.style.setProperty('--ui-scale', scale.toFixed(3));
    root.style.setProperty('--topbar-h', topbarH + 'px');
    root.style.setProperty('--side-panel-w', sidePanelW + 'px');
    root.style.setProperty('--hud-scale', hudScale.toFixed(3));
    root.style.setProperty('--screen-w', w + 'px');
    root.style.setProperty('--screen-h', h + 'px');

    // Sync Three.js Camera & Renderer to fill the screen
    if (window.game3D && typeof window.game3D.onWindowResize === 'function') {
        window.game3D.onWindowResize();
    }
};

window.addEventListener('resize', window.updateResponsiveScreenLayout);
window.addEventListener('orientationchange', () => {
    setTimeout(window.updateResponsiveScreenLayout, 100);
    setTimeout(window.updateResponsiveScreenLayout, 300);
});
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', window.updateResponsiveScreenLayout);
} else {
    window.updateResponsiveScreenLayout();
}

// Fallback user data if offline or API is connecting
const DEFAULT_USER = {
    id: 1,
    username: 'ผู้เล่น',
    displayName: 'ผู้เล่น',
    name: 'ผู้เล่น',
    avatar_url: 'avatars/avatar_01.svg',
    diamond: 2000,
    gold: 20000,
    level: 1,
    clan_name: 'ห้องบ้านพักส่วนกลาง 3D (Lounge)'
};

// ล้างค่าชื่อเก่า dummy 'เขียนศักดิ์' ที่อาจค้างอยู่ใน localStorage ของผู้เล่น
try {
    const cachedRaw = localStorage.getItem('snake_user_data');
    if (cachedRaw) {
        const parsed = JSON.parse(cachedRaw);
        if (parsed && (parsed.username === 'เขียนศักดิ์' || parsed.name === 'เขียนศักดิ์' || parsed.displayName === 'เขียนศักดิ์')) {
            parsed.username = 'ผู้เล่น';
            parsed.displayName = 'ผู้เล่น';
            parsed.name = 'ผู้เล่น';
            parsed.avatar_url = 'avatars/avatar_01.svg';
            localStorage.setItem('snake_user_data', JSON.stringify(parsed));
        }
    }
    if (localStorage.getItem('snake_line_display_name') === 'เขียนศักดิ์') {
        localStorage.removeItem('snake_line_display_name');
    }
} catch(e) {}

/**
 * ดึง URL รูปโปรไฟล์ของไอดีผู้เล่นที่กำลังใช้งานอยู่จริงในปัจจุบัน (Single Source of Truth)
 * ป้องกันปัญหารูปภาพของไอดีเดิมติดค้างเมื่อสลับบัญชีหรือเปลี่ยนไอดีใหม่
 */
window.getActivePlayerAvatarUrl = function(specificUser = null) {
    const u = specificUser || window.DEFAULT_USER || {};
    // 1. ตรวจสอบจาก Object ข้อมูลผู้ใช้โดยตรงก่อนเสมอ (ไม่นำรูปของไอดีเดิมมาทับ)
    const directAvatar = u.avatar_url || u.pictureUrl || u.picture;
    if (directAvatar && typeof directAvatar === 'string' && directAvatar.trim() && !directAvatar.endsWith('/')) {
        return directAvatar.trim();
    }

    // 2. ใช้รูปจากแท็ก #bar-avatar มุมซ้ายบนของหน้าจอที่กำลังแสดงผลอยู่จริง
    const barAvatar = document.getElementById('bar-avatar');
    if (barAvatar && barAvatar.src && !barAvatar.src.endsWith('/') && !barAvatar.src.includes('undefined')) {
        return barAvatar.src;
    }

    return 'avatars/avatar_01.svg';
};

/**
 * อัปเดตโปรไฟล์ผู้ใช้ตามประเภทช่องทางการล็อกอิน (LINE หรือ Google)
 */
function applyUserProfileBasedOnProvider(user) {
    if (!user) return;
    Object.assign(DEFAULT_USER, user);
    const provider = (user.auth_provider || localStorage.getItem('snake_auth_provider') || '').toLowerCase();
    if (provider === 'line' || user.line_id || (!user.google_id && user.pictureUrl)) {
        updateProfileFromLineUser(user);
    } else if (provider === 'google' || user.google_id) {
        updateProfileFromGoogleUser(user);
    } else {
        updateUserBar(DEFAULT_USER);
    }
}

/**
 * ฟังก์ชันกลาง: นำชื่อจริงที่ดึงมาจาก LINE (profile.displayName)
 * ไปอัปเดตแทนที่ชื่อสุ่ม 'LINE Player ...' ในทุกตรรกะและทุกจุดบนหน้าจอเกมทันที
 */
window.propagateRealPlayerName = function(rawName) {
    if (!rawName) return;
    const cleanName = String(rawName).trim();
    if (!cleanName || cleanName === 'ยังไม่ได้เข้าสู่ระบบ') return;

    // 1. อัปเดตตัวแปร State ผู้ใช้หลักของเกม
    DEFAULT_USER.username = cleanName;
    DEFAULT_USER.displayName = cleanName;
    DEFAULT_USER.name = cleanName;

    try {
        localStorage.setItem('snake_line_display_name', cleanName);
        const uData = JSON.parse(localStorage.getItem('snake_user_data') || '{}');
        uData.username = cleanName;
        uData.displayName = cleanName;
        uData.name = cleanName;
        localStorage.setItem('snake_user_data', JSON.stringify(uData));
    } catch (e) {}

    // 2. อัปเดต UI มุมซ้ายบน และแท็กแสดงชื่อผู้เล่นทั้งหมด
    document.querySelectorAll('#bar-username, .top-bar .profile-details .username span').forEach(el => {
        el.textContent = cleanName;
        el.innerText = cleanName;
    });

    const editNameInput = document.getElementById('input-edit-username');
    if (editNameInput) editNameInput.value = cleanName;

    const profileChipEl = document.getElementById('btn-profile');
    if (profileChipEl) {
        profileChipEl.title = `โปรไฟล์ LINE: ${cleanName} - แตะเพื่อแก้ไข`;
    }

    // 3. อัปเดตในตัวแปรเกม 3D (window.game): ตัวหมาก, แผงเทิร์นด้านล่าง, บันทึก Game Log
    if (window.game) {
        // อัปเดตชื่อผู้เล่นที่เป็นคนจริง (Player Index 0 หรือ !is_bot)
        if (Array.isArray(window.game.players) && window.game.players.length > 0) {
            window.game.players.forEach((p, idx) => {
                if (idx === 0 || !p.is_bot) {
                    p.username = cleanName;
                    p.displayName = cleanName;
                }
            });
        }

        // อัปเดตแผงเทิร์นการเล่นด้านล่างทันที
        if (typeof window.game.updateActiveTurnUI === 'function') {
            window.game.updateActiveTurnUI();
        }

        // ค้นหาและแทนที่ชื่อสุ่ม 'LINE Player ...' ในกล่องข้อความสถานะเทิร์นด้านล่าง
        const turnStatusEl = document.getElementById('turn-status-text');
        if (turnStatusEl && /LINE Player\s+[a-zA-Z0-9]+/i.test(turnStatusEl.innerText)) {
            turnStatusEl.innerText = turnStatusEl.innerText.replace(/LINE Player\s+[a-zA-Z0-9]+/gi, cleanName);
        }

        // ค้นหาและแทนที่ชื่อสุ่ม 'LINE Player ...' ในบันทึกเหตุการณ์ (Game Log) ฝั่งขวา
        const logFeed = document.getElementById('log-feed');
        if (logFeed) {
            logFeed.querySelectorAll('.log-item').forEach(item => {
                if (/LINE Player\s+[a-zA-Z0-9]+/i.test(item.innerHTML)) {
                    item.innerHTML = item.innerHTML.replace(/LINE Player\s+[a-zA-Z0-9]+/gi, cleanName);
                }
            });
        }

        // อัปเดตเซสชันเกมที่บันทึกไว้ใน localStorage (snake_active_session)
        try {
            const activeRaw = localStorage.getItem('snake_active_session');
            if (activeRaw) {
                const sess = JSON.parse(activeRaw);
                if (sess && Array.isArray(sess.players) && sess.players[0] && !sess.players[0].is_bot) {
                    sess.players[0].username = cleanName;
                    sess.players[0].displayName = cleanName;
                }
                if (sess && Array.isArray(sess.recentLogs)) {
                    sess.recentLogs = sess.recentLogs.map(l => l.replace(/LINE Player\s+[a-zA-Z0-9]+/gi, cleanName));
                }
                localStorage.setItem('snake_active_session', JSON.stringify(sess));
            }
        } catch (e) {}

        if (typeof window.game.saveGameState === 'function') {
            window.game.saveGameState();
        }
    }

    // 4. อัปเดตชื่อในระบบแชทและห้องบ้าน 3D (Clan House)
    if (window.clanHouse) {
        if (typeof window.clanHouse.updatePlayerPawnName === 'function') {
            window.clanHouse.updatePlayerPawnName(cleanName);
        }
        if (typeof window.clanHouse.updateMembersBoard === 'function') {
            window.clanHouse.updateMembersBoard();
        }
    }

    // แทนที่ชื่อในฟีดแชทห้องบ้านทันที
    document.querySelectorAll('#clan-chat-feed, #clan-room-chat-feed').forEach(feed => {
        feed.querySelectorAll('.clan-msg-user, .clan-msg-author, .chat-user').forEach(userEl => {
            if (/LINE Player/i.test(userEl.textContent)) {
                userEl.textContent = cleanName;
            }
        });
    });
};

let customConfirmCallback = null;
let customPromptCallback = null;

// --- Custom In-Game Dialog Functions (No Browser Popups!) ---
window.showInGameConfirm = function(msg, onConfirm, title = 'ยืนยันการทำรายการ', icon = '👥') {
    customConfirmCallback = onConfirm;
    const msgEl = document.getElementById('confirm-dialog-message');
    const titleEl = document.getElementById('confirm-dialog-title');
    const iconEl = document.getElementById('confirm-dialog-icon');
    if (msgEl) msgEl.innerText = msg;
    if (titleEl) titleEl.innerText = title;
    if (iconEl) iconEl.innerText = icon;
    openModal('modal-custom-confirm');
};

window.closeCustomConfirm = function(confirmed) {
    closeModal('modal-custom-confirm');
    const cb = customConfirmCallback;
    customConfirmCallback = null;
    if (confirmed && typeof cb === 'function') {
        cb();
    }
};

window.showInGamePrompt = function(msg, onConfirm, title = 'กรอกข้อมูล', icon = '💌', placeholder = 'กรอกข้อมูล...', okText = 'ตกลง', defaultVal = '') {
    customPromptCallback = onConfirm;
    const msgEl = document.getElementById('prompt-dialog-message');
    const titleEl = document.getElementById('prompt-dialog-title');
    const iconEl = document.getElementById('prompt-dialog-icon');
    const inputEl = document.getElementById('prompt-dialog-input');
    const okBtn = document.getElementById('btn-prompt-ok');

    if (msgEl) msgEl.innerText = msg;
    if (titleEl) titleEl.innerText = title;
    if (iconEl) iconEl.innerText = icon;
    if (okBtn) okBtn.innerText = okText;
    if (inputEl) {
        inputEl.placeholder = placeholder;
        inputEl.value = defaultVal || '';
    }
    openModal('modal-custom-prompt');
    if (inputEl) {
        setTimeout(() => inputEl.focus(), 60);
    }
};

window.closeCustomPrompt = function(confirmed) {
    const inputEl = document.getElementById('prompt-dialog-input');
    const val = inputEl ? inputEl.value.trim() : '';
    closeModal('modal-custom-prompt');
    const cb = customPromptCallback;
    customPromptCallback = null;
    if (confirmed && typeof cb === 'function') {
        cb(val);
    }
};

window.showInGameAlert = function(msg, title = 'แจ้งเตือน', icon = '✨') {
    const msgEl = document.getElementById('alert-dialog-message');
    const titleEl = document.getElementById('alert-dialog-title');
    const iconEl = document.getElementById('alert-dialog-icon');
    if (msgEl) msgEl.innerText = msg;
    if (titleEl) titleEl.innerText = title;
    if (iconEl) iconEl.innerText = icon;
    openModal('modal-custom-alert');
};

window.closeCustomAlert = function() {
    closeModal('modal-custom-alert');
};

window.showToast = function(msg, duration = 3000) {
    const t = document.getElementById('game-toast');
    if (!t) return;
    t.innerText = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), duration);
};

// Global modal helpers exposed on window
window.openModal = function(id) {
    const el = document.getElementById(id);
    if (el) {
        if (id === 'modal-boards') {
            if (typeof window.initBoardSelection === 'function') {
                setTimeout(window.initBoardSelection, 40);
            }
        }
        if (id === 'modal-lobby') {
            const vRooms = document.getElementById('lobby-view-rooms');
            const vBoards = document.getElementById('lobby-view-boards');
            const vModes = document.getElementById('lobby-view-modes');
            const title = document.getElementById('lobby-header-title');
            if (vRooms) vRooms.style.display = 'block';
            if (vBoards) vBoards.style.display = 'none';
            if (vModes) vModes.style.display = 'none';
            if (title) title.innerText = '⚔️ ห้องแข่งขัน & เลือกกระดาน 3D';
            if (typeof window.loadRoomConfigs === 'function') {
                window.loadRoomConfigs();
            }
        }
        el.style.display = 'flex';
    }
};

window.closeModal = function(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';

    // หากปิดหน้าต่างเลือกกระดานและเกมยังไม่ได้เริ่มแข่งขัน ให้คืนค่าหน้าจอกลับสู่หน้าหลักปกติ
    if (id === 'modal-boards' && (!window.game || !window.game.isMatchActive)) {
        document.body.classList.remove('in-match-fullscreen');
        if (window.game && typeof window.game.onWindowResize === 'function') {
            setTimeout(() => window.game.onWindowResize(), 80);
        }
    }
};

window.closeAllModals = function() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
};

document.addEventListener('DOMContentLoaded', async () => {
    // 0. เมื่อเปิดหน้าเว็บ หรือกดรีเฟรช (Refresh / F5): ให้อยู่หน้าแรก (Home Screen) ในโหมดสแตนด์บายเสมอ ล้างเซสชันเกมที่ค้างอยู่
    try {
        localStorage.removeItem('snake_active_session');
        if (window.DEFAULT_USER && window.DEFAULT_USER.id) {
            localStorage.removeItem('snake_active_session_user_' + window.DEFAULT_USER.id);
        }
    } catch(e) {}
    document.body.classList.remove('in-match-fullscreen');

    // 1. Setup event listeners immediately
    setupEventListeners();

    // 2. Initialize 3D Game Engine
    try {
        window.game = new SnakeGame3D('canvas-container');
    } catch (e) {
        console.error('Three.js Init Error:', e);
    }

    initBoardSelection();
    if (typeof window.loadRoomConfigs === 'function') {
        window.loadRoomConfigs();
    }

    // 3. Game Finished Callback
    window.onGameFinished = async (winner, winReason = 'FINISH_LINE') => {
        const isPractice = Boolean(window.isPracticeMatch);
        const roomId = window.currentRoomId || null;
        const isBot = Boolean(winner.is_bot);
        const isTeamMode = Boolean(winner.team && winner.team !== 'NONE');
        const isUserTeam = winner.team === 'A' || winner.id === (DEFAULT_USER.id || 1);
        const reasonDesc = (winReason === 'BANKRUPTCY')
            ? 'คู่แข่งเงินทองหมดกระดาน ล้มละลาย (Bankruptcy Win)!'
            : (winReason === 'TIME_OUT' ? 'หมดเวลาแข่งขัน 10 นาที! ชนะด้วยทองและสิ่งก่อสร้างรวมสูงสุด!' : 'พิชิตเส้นชัยช่อง 100 สำเร็จ!');

        // โหมดทดลองเล่นหน้าหลัก: ไม่ได้รับรางวัลเพชรหรือทอง
        if (isPractice || !roomId) {
            setTimeout(() => {
                if (window.game && typeof window.game.setupIdlePreview === 'function') {
                    window.game.setupIdlePreview(DEFAULT_USER);
                }
                window.showMatchResultModal(winner, winReason, null, true);
            }, 1000);
            return;
        }

        // กรณีเล่นในห้องแข่งขันจริง (Room Match)
        let res = { status: 'success', reward_diamond: 0, reward_gold: 0 };
        try {
            if (window.apiClient && window.apiClient.token && roomId) {
                res = await apiClient.finishMatch(roomId, winner.id, isBot);
            }
        } catch (e) {
            console.warn('Finish match API warning:', e);
        }

        // บันทึกประวัติการแข่งขันลงระบบ (Match History & Stats Record)
        try {
            const ranked = window.game?.lastMatchRankedPlayers || window.game?.players || [];
            const playersData = ranked.map((p, idx) => ({
                id: p.id,
                username: p.username || `ผู้เล่น ${idx + 1}`,
                avatar_url: p.avatar_url || p.picture || 'avatars/bots/bot_f01.jpg',
                rank: idx + 1,
                is_winner: (p.id === winner.id),
                total_assets: p.totalAssets ?? (window.game ? window.game.getPlayerTotalAssets(p) : (p.matchGold || 0)),
                cash_gold: p.matchGold ?? 0,
                cities_count: p.cityCounts?.cities ?? 0
            }));

            const matchPayload = {
                match_id: 'match_' + Date.now(),
                user_id: DEFAULT_USER.id || 15,
                game_mode: window.currentActiveGameMode || (playersData.length >= 4 ? '4P' : '2P'),
                room_fee: window.game?.matchConfig?.entry_fee_gold || 2000,
                win_reason: winReason,
                players: playersData
            };

            // ส่งบันทึกไปยัง API
            fetch('api/leaderboard.php?action=record_match', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(matchPayload)
            }).catch(e => console.warn('Record match API error:', e));

            // บันทึกลง LocalStorage Cache สำรอง
            try {
                const rawHist = localStorage.getItem('snake_match_history_cache');
                let histList = rawHist ? JSON.parse(rawHist) : [];
                if (!Array.isArray(histList)) histList = [];
                histList.unshift({
                    ...matchPayload,
                    id: Date.now(),
                    created_at: new Date().toISOString()
                });
                localStorage.setItem('snake_match_history_cache', JSON.stringify(histList.slice(0, 30)));
            } catch(e) {}
        } catch(e) {
            console.warn('Record match history error:', e);
        }

        if (!isBot && res.reward_cube) {
            if (typeof window.checkUserCubesBadge === 'function') {
                window.checkUserCubesBadge();
            }
        }

        setTimeout(() => {
            if (window.game && typeof window.game.setupIdlePreview === 'function') {
                window.game.setupIdlePreview(DEFAULT_USER);
            }
            window.showMatchResultModal(winner, winReason, res, false);
            if (window.apiClient) apiClient.getProfile().then(r => { if (r && r.data) updateUserBar(r.data); }).catch(() => {});
        }, 1000);
    };

    // 3.5 เมื่อเปิดหน้าเว็บหรือรีเฟรช: สแตนด์บายหน้าแรกเสมอ ห้ามเข้าเกมเล่นเองอัตโนมัติ
    document.body.classList.remove('in-match-fullscreen');

    // 4. Check Authentication on Startup (NEVER AUTO-REGISTER ON REFRESH!)
    await checkAuthOnStartup();

    // 5. ตรวจสอบการอัปเดตเกมแบบเรียลไทม์ (OTA Update) จากเซิร์ฟเวอร์
    window.checkOtaGameUpdate();
});

// =========================================================================
// Real-time OTA Mobile & Web Game Update Monitor
// =========================================================================
window.checkOtaGameUpdate = async function() {
    try {
        const res = await fetch('api/app_config.php?t=' + Date.now()).then(r => r.json());
        if (res && res.status === 'success' && res.cache_version) {
            const serverVer = Number(res.cache_version);
            const currentVer = Number(window.__GAME_OTA_VERSION__ || 0);

            // หากเซิร์ฟเวอร์มีเวอร์ชันใหม่กว่าที่หน้านี้กำลังรันอยู่ (และไม่ได้อยู่ในระหว่างแข่งเกม)
            if (currentVer > 0 && serverVer > currentVer && !(window.game && window.game.isMatchActive)) {
                if (typeof showToast === 'function') {
                    showToast('🚀 มีการอัปเดตระบบเกมส์เวอร์ชันใหม่จากเซิร์ฟเวอร์! กำลังโหลดเวอร์ชันล่าสุด...');
                }
                setTimeout(() => {
                    window.location.reload(true);
                }, 1500);
            }
        }
    } catch (e) {}
};

if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            window.checkOtaGameUpdate();
        }
    });
    setInterval(window.checkOtaGameUpdate, 300000);
}

/**
 * แสดงหน้าต่างผลการแข่งขัน (Match Results Modal) พร้อมปุ่ม "กลับหน้าแรก" และ "เล่นต่อทันที"
 */
window.showMatchResultModal = function(winner, winReason = 'FINISH_LINE', res = null, isPractice = false) {
    const modal = document.getElementById('modal-match-result');
    if (!modal) return;

    const myId = DEFAULT_USER.id || 1;
    const isUser = (winner.id === myId);
    const isTeamMode = Boolean(winner.team && winner.team !== 'NONE');
    const isUserTeam = (winner.team === 'A' || isUser);
    const isWin = isTeamMode ? isUserTeam : isUser;

    const iconEl = document.getElementById('result-badge-icon');
    const titleEl = document.getElementById('result-title');
    const reasonEl = document.getElementById('result-reason');
    const avatarEl = document.getElementById('result-winner-avatar');
    const nameEl = document.getElementById('result-winner-name');
    const teamEl = document.getElementById('result-winner-team');
    const rewardsBox = document.getElementById('result-rewards-box');
    const diaPill = document.getElementById('result-reward-dia-item');
    const diaVal = document.getElementById('result-reward-dia');
    const goldPill = document.getElementById('result-reward-gold-item');
    const goldVal = document.getElementById('result-reward-gold');
    const cubePill = document.getElementById('result-reward-cube-item');
    const cubeVal = document.getElementById('result-reward-cube');
    const subNotice = document.getElementById('result-sub-notice');
    const rematchText = document.getElementById('btn-result-rematch-text');

    if (iconEl) iconEl.innerText = isWin ? '🏆' : '👏';
    if (titleEl) {
        titleEl.innerText = isWin
            ? (isTeamMode ? '🎉 ยินดีด้วย! ทีมของคุณคว้าชัยชนะ!' : '🎉 ยินดีด้วย! คุณคว้าชัยชนะ!')
            : (isTeamMode ? '⚔️ จบการแข่งขัน! ทีมคู่แข่งคว้าชัยชนะ' : '⚔️ จบการแข่งขัน!');
        titleEl.style.color = isWin ? '#ffd700' : '#38bdf8';
    }

    let reasonDesc = '🏁 พิชิตเส้นชัยช่อง 100 สำเร็จ!';
    if (winReason === 'BANKRUPTCY') {
        reasonDesc = '💥 คู่แข่งเงินทองหมดกระดาน ล้มละลาย (Bankruptcy Win)!';
    } else if (winReason === 'TIME_OUT') {
        reasonDesc = '⏰ หมดเวลาแข่งขัน 10 นาที! ชนะด้วยทองและสิ่งก่อสร้างรวมสูงสุด!';
    }
    if (reasonEl) reasonEl.innerText = reasonDesc;

    const myRealName = DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username || 'ผู้เล่น';
    const myRealAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl() : (DEFAULT_USER.avatar_url || DEFAULT_USER.picture);

    if (nameEl) {
        nameEl.innerText = isUser ? myRealName : (winner.username || 'ผู้เล่น');
    }
    if (avatarEl) {
        avatarEl.src = isUser ? myRealAvatar : (winner.avatar_url || winner.picture || 'avatars/google_avatar.png');
    }

    if (teamEl) {
        if (isTeamMode) {
            teamEl.style.display = 'block';
            teamEl.innerText = winner.team === 'A' ? '🛡️ ทีมสีฟ้า' : '⚔️ ทีมสีแดง';
            teamEl.style.color = winner.team === 'A' ? '#38bdf8' : '#f43f5e';
        } else {
            teamEl.style.display = 'none';
        }
    }

    // Leaderboard Rankings (จัดอันดับ 1-4)
    const lbBox = document.getElementById('result-leaderboard-box');
    const rankedPlayers = window.game?.lastMatchRankedPlayers
        || (window.game?.players?.length ? [...window.game.players].sort((a,b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = (window.game.getPlayerTotalAssets(b) || 0) - (window.game.getPlayerTotalAssets(a) || 0);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        }) : []);

    if (lbBox && rankedPlayers.length > 0) {
        const medals = ['🥇 ที่ 1', '🥈 ที่ 2', '🥉 ที่ 3', '4️⃣ ที่ 4'];
        const borderColors = ['#ffd700', '#38bdf8', '#f472b6', '#a78bfa'];
        const fmtGold = (val) => window.game ? window.game.formatCompactGold(val) : (Number(val) || 0).toLocaleString();

        lbBox.style.display = 'block';
        lbBox.innerHTML = `
            <div style="font-size:13px; font-weight:800; color:#38bdf8; margin-bottom:8px; text-align:left; display:flex; align-items:center; gap:6px;">
                <span>📊</span> ตารางจัดอันดับการแข่งขัน (อันดับ 1 - ${rankedPlayers.length}):
            </div>
            <div class="result-ranks-list">
                ${rankedPlayers.map((p, idx) => {
                    const rankLabel = medals[idx] || `ที่ ${idx + 1}`;
                    const isWinner = (p.id === winner.id);
                    const isMe = (p.id === myId) || !p.is_bot;
                    let pName = isMe ? myRealName : (p.username || 'ผู้เล่น');
                    if (isMe && (pName === 'เขียนศักดิ์' || pName === 'ผู้เล่น' || pName === 'Google Player')) {
                        pName = myRealName;
                    }
                    const avatar = isMe ? myRealAvatar : (p.avatar_url || p.picture || 'avatars/google_avatar.png');
                    const assets = p.totalAssets ?? (window.game ? window.game.getPlayerTotalAssets(p) : p.matchGold);
                    const counts = p.cityCounts ?? (window.game ? window.game.getPlayerCityCounts(p) : { cities: 0, landmarks: 0 });
                    const goldVal = p.matchGold ?? 0;

                    return `
                        <div class="result-rank-row ${isWinner ? 'winner-row' : ''}" style="border-left: 3px solid ${borderColors[idx] || '#64748b'};">
                            <div class="result-rank-badge rank-tag-${idx + 1}">${rankLabel}</div>
                            <img src="${avatar}" class="result-rank-avatar" onerror="this.onerror=null;this.src='avatars/google_avatar.png';">
                            <div class="result-rank-info">
                                <div class="result-rank-name" style="color:${isWinner ? '#ffd700' : '#fff'};">
                                    <span>${pName}</span> ${isMe ? '<span class="you-badge">(คุณ)</span>' : ''}
                                </div>
                                <div class="result-rank-sub">
                                    <span>สินทรัพย์รวม: <strong style="color:#6ee7b7;">${fmtGold(assets)}</strong></span>
                                    <span>• 🪙 ${fmtGold(goldVal)}</span>
                                    <span>• 🏠 ${(counts.cities || 0) + (counts.landmarks || 0)} หลัง</span>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    } else if (lbBox) {
        lbBox.style.display = 'none';
    }

    if (isPractice) {
        if (rewardsBox) rewardsBox.style.display = 'none';
        if (subNotice) {
            subNotice.style.display = 'block';
            subNotice.innerText = '📌 โหมดทดลองเล่นฝึกซ้อม: ไม่มีการหักหรือแจกรางวัลเพชรและทอง';
        }
        if (rematchText) rematchText.innerText = 'เล่นต่อทันที';
    } else {
        if (rewardsBox) rewardsBox.style.display = 'flex';
        if (subNotice) subNotice.style.display = 'none';
        if (rematchText) rematchText.innerText = 'เล่นต่อทันที';

        const dia = (res && res.reward_diamond) ? Number(res.reward_diamond) : 0;
        const gold = (res && res.reward_gold) ? Number(res.reward_gold) : 0;

        if (diaPill && diaVal) {
            if (dia > 0) {
                diaPill.style.display = 'inline-flex';
                diaVal.innerText = `+${dia.toLocaleString()} เพชร`;
            } else {
                diaPill.style.display = 'none';
            }
        }

        if (goldPill && goldVal) {
            if (gold > 0) {
                goldPill.style.display = 'inline-flex';
                goldVal.innerText = `+${gold.toLocaleString()} ทอง`;
            } else {
                goldPill.style.display = 'none';
            }
        }

        if (cubePill && cubeVal) {
            if (res && res.reward_cube) {
                cubePill.style.display = 'inline-flex';
                cubeVal.innerText = res.reward_cube.cube_name || 'ลูกบาศก์นำโชค';
            } else {
                cubePill.style.display = 'none';
            }
        }
    }

    openModal('modal-match-result');
};

/**
 * กลับหน้าแรกทันที (ออกจากโหมดเต็มจอ คืนค่าเมนูปกติ รีเซ็ตกระดาน)
 */
window.exitToHomeScreen = function() {
    closeModal('modal-match-result');
    closeModal('modal-custom-confirm');
    closeModal('modal-custom-alert');

    // ออกจากโหมดเต็มจอ
    document.body.classList.remove('in-match-fullscreen');
    window.isPracticeMatch = false;
    window.currentRoomId = null;

    if (window.soundEngine && typeof window.soundEngine.stopAll === 'function') {
        try { window.soundEngine.stopAll(); } catch(e) {}
    }

    if (window.game) {
        if (typeof window.game.clearSavedSession === 'function') {
            window.game.clearSavedSession();
        }
        if (typeof window.game.setupIdlePreview === 'function') {
            window.game.setupIdlePreview(DEFAULT_USER);
        }
        if (typeof window.game.onWindowResize === 'function') {
            setTimeout(() => window.game.onWindowResize(), 100);
        }
    }

    if (typeof window.updatePracticeExitButtonVisibility === 'function') {
        window.updatePracticeExitButtonVisibility();
    }

    if (window.apiClient) {
        apiClient.getProfile().then(p => { if (p && p.data) updateUserBar(p.data); }).catch(() => {});
    }
};

/**
 * เล่นต่อทันที (จับคู่ค้นหาคู่แข่งทันทีในห้องและโหมดเดิม)
 */
window.rematchQuickAction = function() {
    closeModal('modal-match-result');
    closeModal('modal-custom-confirm');
    closeModal('modal-custom-alert');

    if (window.isPracticeMatch) {
        if (typeof window.startExplicitPracticeMatch === 'function') {
            window.startExplicitPracticeMatch();
        }
        return;
    }

    const tier = window.currentActiveRoomTier || '2M';
    const mode = window.currentActiveGameMode || '2P';
    const board = window.currentLobbyBoard || 'classic';
    window.startQuickMatch(tier, mode, board);
};

/**
 * ยืนยันออกจากเกมระหว่างแข่งขัน
 */
window.confirmExitMatchAction = function() {
    showInGameConfirm(
        'คุณต้องการออกจากการแข่งขันและกลับสู่หน้าแรกหรือไม่?\n(หากออกจากห้องระหว่างแข่งขันจะถือว่าสละสิทธิ์)',
        () => {
            window.exitToHomeScreen();
            showToast('🏠 กลับสู่หน้าแรกเรียบร้อยแล้ว');
        },
        'กลับหน้าแรก',
        '🏠'
    );
};

// =========================================================================
// ป้องกันการกดออก / รีเฟรชหน้าจอระหว่างแข่งขัน และระบบ AUTO อัตโนมัติเมื่อหลุดหรือสลับหน้าจอ
// =========================================================================

// 1. ป้องกันการกดปุ่มคีย์บอร์ดรีเฟรช (F5, Ctrl+R, Command+R) ระหว่างแข่งขัน
window.addEventListener('keydown', function(e) {
    if (window.game && window.game.isMatchActive && !window.game.isGameOver) {
        if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R'))) {
            e.preventDefault();
            e.stopPropagation();
            showToast('⚠️ กำลังอยู่ระหว่างการแข่งขัน ห้ามรีเฟรชหน้าจอ!');
            return false;
        }
    }
}, true);

// 2. ป้องกันการปิดหน้าต่าง หรือสลับหน้าเว็บระหว่างแข่งขัน (แจ้งเตือน และเปิด AUTO เล่นต่อให้ทันที)
window.addEventListener('beforeunload', function(e) {
    if (window.game && window.game.isMatchActive && !window.game.isGameOver) {
        // บันทึกและเปิดโหมด AUTO ให้ระบบเล่นต่อจนจบเกม
        if (typeof window.game.enableAutoMode === 'function') {
            window.game.enableAutoMode(false);
        } else {
            window.game.isAutoMode = true;
        }
        if (typeof window.game.saveGameState === 'function') {
            window.game.saveGameState();
        }
        e.preventDefault();
        e.returnValue = '⚠️ การแข่งขันกำลังดำเนินอยู่ หากออกจากหน้านี้ระบบจะทำการเล่น AUTO ต่อให้อัตโนมัติจนจบเกม';
        return e.returnValue;
    }
});

// 3. เมื่อผู้เล่นสลับแท็บ ย่อหน้าต่าง หรือพักหน้าจอ (Visibility Change) -> สลับเป็นโหมด AUTO ทันที
document.addEventListener('visibilitychange', function() {
    if (!window.game || !window.game.isMatchActive || window.game.isGameOver) return;

    if (document.hidden) {
        if (typeof window.game.enableAutoMode === 'function') {
            window.game.enableAutoMode(true);
        } else {
            window.game.isAutoMode = true;
        }
        if (typeof window.game.saveGameState === 'function') {
            window.game.saveGameState();
        }
        window.game.logMessage('⚡ สลับหน้าจอ: ระบบเปิดโหมดเล่น AUTO ต่อเนื่องให้อัตโนมัติ', 'highlight');
    } else {
        showToast('⚡ เกมกำลังดำเนินอยู่ (โหมด AUTO) — แตะปุ่มทอยเต๋าเพื่อกลับมาควบคุมเองได้ทันที');
    }
});

// 4. เมื่อสัญญาณอินเทอร์เน็ตขาดหาย (Offline) -> สลับเป็น AUTO ทันที เพื่อไม่ให้เกมค้าง
window.addEventListener('offline', function() {
    if (!window.game || !window.game.isMatchActive || window.game.isGameOver) return;
    if (typeof window.game.enableAutoMode === 'function') {
        window.game.enableAutoMode(true);
    } else {
        window.game.isAutoMode = true;
    }
    window.game.logMessage('📶 สัญญาณเน็ตขัดข้อง: ระบบเปิดเล่น AUTO ให้อัตโนมัติจนกว่าสัญญาณจะกลับมา', 'highlight');
    showToast('📶 สัญญาณเน็ตขาดหาย: ระบบกำลังเล่น AUTO ให้อัตโนมัติ');
});

// 5. เมื่อสัญญาณอินเทอร์เน็ตกลับมา (Online)
window.addEventListener('online', function() {
    if (!window.game || !window.game.isMatchActive || window.game.isGameOver) return;
    showToast('🟢 สัญญาณเน็ตกลับมาแล้ว! แตะที่ปุ่มทอยเต๋าเพื่อกลับมาเล่นเองได้ทันที');
});

/**
 * Decode JWT payload (e.g. Google ID Token / GIS credential) into a Google User Object
 */
window.parseGoogleJwt = function(token) {
    try {
        const base64Url = token.split('.')[1];
        if (!base64Url) return null;
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(
            atob(base64)
                .split('')
                .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                .join('')
        );
        return JSON.parse(jsonPayload);
    } catch (e) {
        console.warn('Failed to decode Google JWT:', e);
        return null;
    }
};

/**
 * ดึงข้อมูล name (ชื่อโปรไฟล์), picture (URL รูปภาพ), และ email (หรือ ID)
 * จาก Google User Object ที่ได้กลับมา แล้วนำไปแสดงผลใน UI หน้าเกมตรงมุมซ้ายบนแทนที่ข้อมูลเดิมทันที
 *
 * @param {Object} googleUserObj - Google User Object ({ name, picture, email, sub, id } หรือ { credential / id_token })
 * @returns {Object|null} ข้อมูลผู้ใช้ที่อัปเดตแล้ว { name, picture, emailOrId }
 */
window.updateProfileFromGoogleUser = function(googleUserObj) {
    if (!googleUserObj) return null;

    // กรณีได้ Google JWT (credential หรือ id_token) ให้ถอดรหัสออกมาเป็น Google User Object ก่อน
    let payload = googleUserObj;
    if (typeof googleUserObj === 'string') {
        payload = window.parseGoogleJwt(googleUserObj) || { name: googleUserObj };
    } else if (googleUserObj.credential || googleUserObj.id_token) {
        const decoded = window.parseGoogleJwt(googleUserObj.credential || googleUserObj.id_token);
        if (decoded) {
            payload = { ...googleUserObj, ...decoded };
        }
    } else if (googleUserObj.user && typeof googleUserObj.user === 'object') {
        payload = { ...googleUserObj, ...googleUserObj.user };
    } else if (googleUserObj.data && typeof googleUserObj.data === 'object') {
        payload = { ...googleUserObj, ...googleUserObj.data };
    }

    // ตรวจสอบข้อมูลโปรไฟล์ Google จริงที่เคยบันทึกไว้ (ป้องกันค่า fallback 'Google Player' มาทับชื่อจริง)
    let savedGoogleProf = null;
    try {
        savedGoogleProf = JSON.parse(localStorage.getItem('snake_google_profile') || 'null');
    } catch (e) {}

    // 1. ดึงข้อมูล name (ชื่อโปรไฟล์), picture (URL รูปภาพ), และ email (หรือ ID) จาก Google User Object
    let rawName = (
        payload.name ||
        payload.displayName ||
        payload.given_name ||
        payload.username ||
        ''
    ).toString().trim();

    if ((!rawName || rawName === 'Google Player') && savedGoogleProf && savedGoogleProf.name) {
        rawName = savedGoogleProf.name;
    }
    const name = rawName || DEFAULT_USER.username || 'ผู้เล่น Google';

    let rawPicture = (
        payload.picture ||
        payload.photoURL ||
        payload.avatar_url ||
        ''
    ).toString().trim();

    if ((!rawPicture || rawPicture === 'avatars/google_avatar.png' || rawPicture.startsWith('avatars/avatar_')) && savedGoogleProf && savedGoogleProf.picture) {
        rawPicture = savedGoogleProf.picture;
    }
    const picture = rawPicture || DEFAULT_USER.avatar_url || 'avatars/google_avatar.png';

    const emailOrId = (
        payload.email ||
        payload.sub ||
        payload.google_id ||
        payload.id ||
        (savedGoogleProf && (savedGoogleProf.email || savedGoogleProf.sub)) ||
        DEFAULT_USER.google_id ||
        DEFAULT_USER.id ||
        ''
    ).toString().trim();

    // หากได้ชื่อจริงจากบัญชี Google (ไม่ใช่ค่าเริ่มต้น 'Google Player') ให้จำไว้ใน snake_google_profile
    if (name && name !== 'Google Player' && name !== 'ยังไม่ได้เข้าสู่ระบบ') {
        try {
            localStorage.setItem('snake_google_profile', JSON.stringify({
                name: name,
                picture: picture,
                email: payload.email || emailOrId,
                sub: payload.sub || payload.google_id || emailOrId
            }));
        } catch (e) {}
    }

    // 2. อัปเดตข้อมูลเข้าสู่ State หลักของเกม (DEFAULT_USER) และบันทึกใน localStorage
    DEFAULT_USER.auth_provider = 'google';
    DEFAULT_USER.username = name;
    DEFAULT_USER.name = name;
    DEFAULT_USER.avatar_url = picture;
    DEFAULT_USER.picture = picture;
    try {
        localStorage.setItem('snake_auth_provider', 'google');
    } catch (e) {}
    if (payload.id !== undefined && payload.id !== null && !isNaN(Number(payload.id))) {
        DEFAULT_USER.id = Number(payload.id);
    }
    if (payload.diamond !== undefined && payload.diamond !== null) {
        DEFAULT_USER.diamond = Number(payload.diamond);
    }
    if (payload.gold !== undefined && payload.gold !== null) {
        DEFAULT_USER.gold = Number(payload.gold);
    }
    if (payload.level !== undefined && payload.level !== null) {
        DEFAULT_USER.level = Number(payload.level);
    }
    if (payload.clan_name !== undefined && payload.clan_name !== null) {
        DEFAULT_USER.clan_name = payload.clan_name;
    }
    if (payload.clan_id !== undefined) {
        DEFAULT_USER.clan_id = payload.clan_id;
    }
    if (emailOrId) {
        DEFAULT_USER.email = payload.email || DEFAULT_USER.email || emailOrId;
        DEFAULT_USER.google_id = payload.sub || payload.google_id || emailOrId;
    }

    try {
        const cached = JSON.parse(localStorage.getItem('snake_user_data') || '{}');
        const merged = {
            ...cached,
            ...DEFAULT_USER,
            username: name,
            name: name,
            avatar_url: picture,
            picture: picture,
            email: DEFAULT_USER.email,
            google_id: DEFAULT_USER.google_id
        };
        localStorage.setItem('snake_user_data', JSON.stringify(merged));
    } catch (e) {
        console.warn('Failed to save Google user to localStorage:', e);
    }

    // 3. นำไปแสดงผลใน UI หน้าเกมตรงมุมซ้ายบนแทนที่ข้อมูลเดิมทันที
    // ชี้ไปยัง ID และ Class ใน index.html:
    // - แท็กรูปภาพ: <img id="bar-avatar" class="profile-avatar">
    // - แท็กข้อความชื่อ: <span id="bar-username"> (ภายใน <div class="username">)
    // - กล่องโปรไฟล์มุมซ้ายบน: <div id="btn-profile" class="profile-chip">
    const avatarEl = document.getElementById('bar-avatar')
                  || document.querySelector('#btn-profile img.profile-avatar')
                  || document.querySelector('.top-bar img.profile-avatar');
    if (avatarEl) {
        avatarEl.referrerPolicy = 'no-referrer'; // ป้องกัน Google CDN บล็อกการโหลดรูปภาพ (403)
        avatarEl.onerror = function() {
            this.onerror = null;
            this.src = 'avatars/google_avatar.png';
        };
        avatarEl.src = picture;
        avatarEl.alt = name;
    }

    const nameEl = document.getElementById('bar-username')
                || document.querySelector('#btn-profile .username span')
                || document.querySelector('.top-bar .profile-details .username');
    if (nameEl) {
        nameEl.textContent = name;
        nameEl.innerText = name;
    }

    const diaEl = document.getElementById('bar-diamond');
    const goldEl = document.getElementById('bar-gold');
    const lvlEl = document.getElementById('bar-level-badge');
    const clanEl = document.getElementById('bar-clan-name');
    if (diaEl && DEFAULT_USER.diamond !== undefined) diaEl.innerText = Number(DEFAULT_USER.diamond).toLocaleString();
    if (goldEl && DEFAULT_USER.gold !== undefined) goldEl.innerText = Number(DEFAULT_USER.gold).toLocaleString();
    if (lvlEl && DEFAULT_USER.level !== undefined) lvlEl.innerText = `Lv.${DEFAULT_USER.level || 1} ⭐`;
    if (clanEl && DEFAULT_USER.clan_name) clanEl.innerText = DEFAULT_USER.clan_name;

    const profileChipEl = document.getElementById('btn-profile')
                       || document.querySelector('.top-bar .profile-chip');
    if (profileChipEl) {
        profileChipEl.dataset.googleId = emailOrId;
        profileChipEl.title = emailOrId
            ? `โปรไฟล์ Google: ${name} (${emailOrId}) - แตะเพื่อแก้ไข`
            : `โปรไฟล์: ${name} - แตะเพื่อแก้ไข`;
    }

    // อัปเดต UI ในหน้าต่างแก้ไขโปรไฟล์ให้ตรงกันด้วย
    const previewImg = document.getElementById('edit-avatar-preview');
    if (previewImg) {
        previewImg.referrerPolicy = 'no-referrer';
        previewImg.src = picture;
    }
    const editNameInput = document.getElementById('input-edit-username');
    if (editNameInput) editNameInput.value = name;
    const editAvatarInput = document.getElementById('input-edit-avatar-url');
    if (editAvatarInput) editAvatarInput.value = picture;

    // 4. อัปเดตชื่อและรูปภาพโปรไฟล์ (picture) ลงบนตัวหมาก 3D บนกระดานเกม และแถบสถานะเทิร์นด้านล่าง (#turn-status-text) ทันที
    if (window.game && Array.isArray(window.game.players) && window.game.players.length > 0) {
        if (typeof window.game.updatePlayerPawnAvatar === 'function') {
            window.game.updatePlayerPawnAvatar(0, { picture, name, auth_provider: 'google' }, name, 'google');
        } else {
            window.game.players[0].username = name;
            window.game.players[0].picture = picture;
            window.game.players[0].avatar_url = picture;
            window.game.players[0].auth_provider = 'google';
            if (typeof window.game.updateActiveTurnUI === 'function') {
                window.game.updateActiveTurnUI();
            }
            if (typeof window.game.saveGameState === 'function') {
                window.game.saveGameState();
            }
        }
    }

    // 5. อัปเดตหัวตัวละครในห้องบ้าน 3D (Clan House) ทันทีหากเปิดอยู่
    if (window.clanHouse && window.clanHouse.playerPawn && typeof window.clanHouse.applyHeadAvatarTexture === 'function') {
        window.clanHouse.applyHeadAvatarTexture(window.clanHouse.playerPawn, picture, name, 0x00e5ff);
    }

    return { name, picture, emailOrId };
};

// Alias สำหรับเรียกใช้งานเมื่อ Google OAuth Callback สำเร็จ
window.handleGoogleLoginSuccess = window.updateProfileFromGoogleUser;

/**
 * สร้างหรือดึงรหัสประจำเครื่อง (Persistent Device UID) เพื่อใช้ผูกบัญชีไม่ให้สูญหายเมื่อออกจากระบบแล้วเข้าใหม่
 */
window.getOrCreateDeviceUid = function() {
    let uid = localStorage.getItem('snake_device_uid');
    if (!uid) {
        uid = 'u_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 10);
        localStorage.setItem('snake_device_uid', uid);
    }
    return uid;
};

/**
 * ซิงค์ค่าเพชร ทอง และข้อมูลผู้เล่นเข้าสู่ฐานข้อมูลทันที พร้อมอัปเดต DEFAULT_USER และ localStorage
 */
window.syncUserProgress = async function(options = {}) {
    if (options.diamond !== undefined && options.diamond !== null) {
        DEFAULT_USER.diamond = Math.max(0, Number(options.diamond));
    } else if (options.diamond_delta) {
        DEFAULT_USER.diamond = Math.max(0, Number(DEFAULT_USER.diamond || 0) + Number(options.diamond_delta));
    }

    if (options.gold !== undefined && options.gold !== null) {
        DEFAULT_USER.gold = Math.max(0, Number(options.gold));
    } else if (options.gold_delta) {
        DEFAULT_USER.gold = Math.max(0, Number(DEFAULT_USER.gold || 0) + Number(options.gold_delta));
    }

    updateUserBar(DEFAULT_USER);
    try {
        localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
    } catch (e) {}

    if (window.apiClient && window.apiClient.token) {
        try {
            const res = await window.apiClient.syncProgress(options);
            if (res && res.status === 'success' && res.data) {
                Object.assign(DEFAULT_USER, res.data);
                updateUserBar(DEFAULT_USER);
                localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
                return res.data;
            }
        } catch (err) {
            console.warn('syncUserProgress warning:', err);
        }
    }
    return DEFAULT_USER;
};

// ===================================================================
// LINE LIFF SDK Integration (liff.init -> liff.getProfile -> Update Top-Left UI)
// ===================================================================
// กำหนดรหัส LIFF ID ของแอป LINE (ดึงจาก URL query, localStorage หรือค่าเริ่มต้น)
const detectedLiffId = (new URLSearchParams(window.location.search)).get('liffId') 
                    || localStorage.getItem('snake_liff_id') 
                    || window.LINE_LIFF_ID 
                    || '2012374389-Snake3D';
window.LINE_LIFF_ID = detectedLiffId;
try { localStorage.setItem('snake_liff_id', detectedLiffId); } catch(e) {}
let isLiffInitialized = false;

/**
 * ====================================================================================
 * 📌 คำแนะนำการตั้งค่าสิทธิ์ 'Profile' (Scopes) บน LINE Developers Console:
 * ====================================================================================
 * เพื่อป้องกันไม่ให้ LINE บล็อกการส่งข้อมูลรูปโปรไฟล์ (pictureUrl) และชื่อ (displayName):
 * 1. เข้าสู่ระบบ https://developers.line.biz/console/
 * 2. เลือก Provider ของคุณ > คลิกเลือก Channel ของ "LINE Login"
 * 3. ไปที่แท็บ "LIFF" (LIFF tab)
 *    - คลิกที่ LIFF App ของคุณ (หรือกด Edit)
 *    - เลื่อนลงมาที่หัวข้อ "Scopes" (สิทธิ์การเข้าถึงข้อมูลของผู้ใช้)
 *    - ตรวจสอบว่าได้ "ติ๊กถูก (Check)" ที่ช่อง:
 *        ✅ profile (จำเป็นมาก: สำหรับอนุญาตให้เข้าถึง displayName และ pictureUrl)
 *        ✅ openid  (สำหรับเข้าถึง userId / ID Token)
 *    - กดปุ่ม "Update" หรือ "Save" เพื่อบันทึกการตั้งค่า
 * 4. ไปที่แท็บ "LINE Login" (LINE Login tab):
 *    - เลื่อนไปที่หัวข้อ Scopes ให้แน่ใจว่าเปิดใช้งาน 'profile' และ 'openid' เช่นเดียวกัน
 * 5. หมายเหตุ: หากไม่เปิด Scope 'profile' คำสั่ง liff.getProfile() จะไม่ส่งค่า pictureUrl 
 *    ทำให้หน้าเว็บได้ค่าว่างหรือ undefined
 * ====================================================================================
 */

/**
 * นำข้อมูลที่ได้จาก liff.getProfile() ได้แก่ displayName (ชื่อ), pictureUrl (รูปภาพโปรไฟล์),
 * และ userId (ไอดีผู้ใช้) ไปอัปเดตแสดงผลที่มุมซ้ายบนของหน้าจอเกมแทนที่ข้อมูลเดิมทันที
 *
 * @param {Object} lineProfile - ข้อมูลที่ได้จาก liff.getProfile() ({ userId, displayName, pictureUrl, statusMessage })
 * @returns {Object|null} { displayName, pictureUrl, userId }
 */
window.updateProfileFromLineUser = function(lineProfile) {
    if (!lineProfile) return null;

    // 1. ดึงข้อมูล displayName (ชื่อ), pictureUrl (รูปภาพโปรไฟล์), และ userId (ไอดีผู้ใช้)
    const displayName = (
        lineProfile.displayName ||
        lineProfile.name ||
        lineProfile.username ||
        DEFAULT_USER.username ||
        'ผู้เล่น LINE'
    ).trim();

    // ดึงรูปโปรไฟล์ของไอดี LINE นี้โดยเฉพาะ (หากไม่มีให้ใช้ default ทันที ไม่สืบทอดรูปเดิมของไอดีก่อนหน้า)
    let pictureUrl = (
        lineProfile.pictureUrl ||
        lineProfile.picture ||
        lineProfile.avatar_url ||
        ''
    ).toString().trim();
    if (!pictureUrl || pictureUrl.includes('avatar_01.png') || pictureUrl.includes('avatar_02.png')) {
        pictureUrl = 'avatars/google_avatar.png';
    }

    const userId = (
        lineProfile.userId ||
        lineProfile.sub ||
        lineProfile.line_id ||
        lineProfile.id ||
        ''
    ).toString().trim();

    // 2. อัปเดตเข้าสู่ State หลักของเกม (DEFAULT_USER) และบันทึกลง localStorage
    DEFAULT_USER.auth_provider = 'line';
    DEFAULT_USER.username = displayName;
    DEFAULT_USER.displayName = displayName;
    window.propagateRealPlayerName(displayName);
    delete DEFAULT_USER.picture; // ลบรูป Google เดิมของไอดีก่อนหน้าออก
    DEFAULT_USER.avatar_url = pictureUrl;
    DEFAULT_USER.pictureUrl = pictureUrl;
    try {
        localStorage.setItem('snake_auth_provider', 'line');
    } catch (e) {}
    if (lineProfile.id !== undefined && lineProfile.id !== null && !isNaN(Number(lineProfile.id))) {
        DEFAULT_USER.id = Number(lineProfile.id);
    }
    if (lineProfile.diamond !== undefined && lineProfile.diamond !== null) {
        DEFAULT_USER.diamond = Number(lineProfile.diamond);
    }
    if (lineProfile.gold !== undefined && lineProfile.gold !== null) {
        DEFAULT_USER.gold = Number(lineProfile.gold);
    }
    if (lineProfile.level !== undefined && lineProfile.level !== null) {
        DEFAULT_USER.level = Number(lineProfile.level);
    }
    if (lineProfile.clan_name !== undefined && lineProfile.clan_name !== null) {
        DEFAULT_USER.clan_name = lineProfile.clan_name;
    }
    if (userId) {
        DEFAULT_USER.line_id = userId;
        DEFAULT_USER.userId = userId;
    }

    try {
        const cached = JSON.parse(localStorage.getItem('snake_user_data') || '{}');
        delete cached.picture;
        const merged = {
            ...cached,
            ...DEFAULT_USER,
            username: displayName,
            displayName: displayName,
            avatar_url: pictureUrl,
            pictureUrl: pictureUrl,
            picture: pictureUrl,
            line_id: userId || cached.line_id
        };
        localStorage.setItem('snake_user_data', JSON.stringify(merged));
    } catch (e) {
        console.warn('Failed to save LINE user to localStorage:', e);
    }

    // 3. อัปเดตแสดงผลใน UI มุมซ้ายบนของหน้าจอเกม (#bar-avatar, #bar-username, #btn-profile)
    const avatarEl = document.getElementById('bar-avatar');
    if (avatarEl) {
        avatarEl.referrerPolicy = 'no-referrer';
        avatarEl.onerror = function() {
            this.onerror = null;
            this.src = 'avatars/google_avatar.png';
        };
        avatarEl.src = pictureUrl;
        avatarEl.alt = displayName;
    }

    const nameEl = document.getElementById('bar-username');
    if (nameEl) {
        nameEl.textContent = displayName;
        nameEl.innerText = displayName;
    }

    const diaEl = document.getElementById('bar-diamond');
    const goldEl = document.getElementById('bar-gold');
    const lvlEl = document.getElementById('bar-level-badge');
    const clanEl = document.getElementById('bar-clan-name');
    if (diaEl && DEFAULT_USER.diamond !== undefined) diaEl.innerText = Number(DEFAULT_USER.diamond).toLocaleString();
    if (goldEl && DEFAULT_USER.gold !== undefined) goldEl.innerText = Number(DEFAULT_USER.gold).toLocaleString();
    if (lvlEl && DEFAULT_USER.level !== undefined) lvlEl.innerText = `Lv.${DEFAULT_USER.level || 1} ⭐`;
    if (clanEl && DEFAULT_USER.clan_name) clanEl.innerText = DEFAULT_USER.clan_name;

    const profileChipEl = document.getElementById('btn-profile');
    if (profileChipEl) {
        profileChipEl.dataset.lineUserId = userId;
        profileChipEl.title = userId
            ? `โปรไฟล์ LINE: ${displayName} (ID: ${userId}) - แตะเพื่อแก้ไข`
            : `โปรไฟล์ LINE: ${displayName} - แตะเพื่อแก้ไข`;
    }

    // อัปเดตข้อมูลในหน้าต่างแก้ไขโปรไฟล์ให้ตรงกันด้วย
    const previewImg = document.getElementById('edit-avatar-preview');
    if (previewImg) {
        previewImg.referrerPolicy = 'no-referrer';
        previewImg.src = pictureUrl;
    }
    const editNameInput = document.getElementById('input-edit-username');
    if (editNameInput) editNameInput.value = displayName;
    const editAvatarInput = document.getElementById('input-edit-avatar-url');
    if (editAvatarInput) editAvatarInput.value = pictureUrl;

    // 4. อัปเดตชื่อและรูปโปรไฟล์ลงบนตัวหมาก 3D บนกระดานเกมทันที
    if (window.game && Array.isArray(window.game.players) && window.game.players.length > 0) {
        if (typeof window.game.updatePlayerPawnAvatar === 'function') {
            window.game.updatePlayerPawnAvatar(0, { pictureUrl, displayName, auth_provider: 'line' }, displayName, 'line');
        } else {
            window.game.players[0].username = displayName;
            window.game.players[0].pictureUrl = pictureUrl;
            window.game.players[0].avatar_url = pictureUrl;
            window.game.players[0].auth_provider = 'line';
            if (typeof window.game.updateActiveTurnUI === 'function') {
                window.game.updateActiveTurnUI();
            }
        }
    }

    // 5. อัปเดตหัวตัวละครในห้องบ้าน 3D (Clan House) ทันทีหากเปิดอยู่
    if (window.clanHouse && window.clanHouse.playerPawn && typeof window.clanHouse.applyHeadAvatarTexture === 'function') {
        window.clanHouse.applyHeadAvatarTexture(window.clanHouse.playerPawn, pictureUrl, displayName, 0x00e5ff);
    }

    return { displayName, pictureUrl, userId };
};

/**
 * เรียกใช้คำสั่ง liff.getProfile() หลังจากเข้าสู่ระบบ LINE LIFF สำเร็จ
 * เพื่อดึง displayName, pictureUrl, และ userId มาอัปเดต UI มุมซ้ายบนและซิงค์กับฐานข้อมูล
 */
/**
 * ฟังก์ชัน Callback หลังจากผู้ใช้เข้าสู่ระบบด้วย LINE Login (ผ่าน LIFF SDK) สำเร็จแล้ว
 * ดึงข้อมูลรูปภาพจากคำสั่ง liff.getProfile() โดยอ้างอิงตัวแปร profile.pictureUrl (ลิงก์รูปภาพโปรไฟล์จาก LINE)
 * จากนั้นนำลิงก์รูปภาพนี้ ไปแทนที่ใน UI ของหน้าเกมตรงมุมซ้ายบน (#bar-avatar)
 * โดยสั่งอัปเดตค่า .src ของแท็กรูปภาพให้แสดงผลเป็นรูปโปรไฟล์วงกลมของ LINE บัญชีนั้นๆ ทันที
 * พร้อมตรวจสอบหากผู้ใช้ไม่มีการตั้งรูปโปรไฟล์ใน LINE ให้ใส่รูป Default สำรองไว้เพื่อไม่ให้ขึ้นเป็นช่องวงกลมสีขาวว่างๆ
 *
 * @param {Object} profile - Object โปรไฟล์จาก liff.getProfile() ({ userId, displayName, pictureUrl, statusMessage })
 * @returns {string} ลิงก์รูปภาพที่ถูกนำไปใช้ใน .src
 */
window.handleLineLiffProfileCallback = function(profile) {
    if (!profile) return 'avatars/google_avatar.png';

    // 1. รูปภาพ Default สำรอง เพื่อไม่ให้ขึ้นเป็นช่องวงกลมสีขาวว่างๆ หากผู้ใช้ไม่มีการตั้งรูปโปรไฟล์ใน LINE
    const DEFAULT_AVATAR = 'avatars/google_avatar.png';

    // 2. ดึงข้อมูลรูปภาพจากคำสั่ง liff.getProfile() โดยอ้างอิงตัวแปร profile.pictureUrl (ลิงก์รูปภาพโปรไฟล์จาก LINE)
    let avatarUrl = profile.pictureUrl;

    // 3. ตรวจสอบว่าหากผู้ใช้ไม่มีการตั้งรูปโปรไฟล์ใน LINE ให้ใส่รูป Default สำรองไว้เพื่อไม่ให้ขึ้นเป็นช่องวงกลมสีขาวว่างๆ
    if (!avatarUrl || typeof avatarUrl !== 'string' || avatarUrl.trim() === '') {
        avatarUrl = DEFAULT_AVATAR;
    } else {
        avatarUrl = avatarUrl.trim();
    }

    // 4. นำลิงก์รูปภาพนี้ ไปแทนที่ใน UI ของหน้าเกมตรงมุมซ้ายบน โดยสั่งอัปเดตค่า .src ของแท็กรูปภาพให้แสดงผลเป็นรูปโปรไฟล์วงกลมของ LINE ทันที
    const barAvatar = document.getElementById('bar-avatar') || document.querySelector('.profile-avatar');
    if (barAvatar) {
        barAvatar.referrerPolicy = 'no-referrer'; // ป้องกันข้อจำกัด referrerpolicy จาก LINE CDN
        barAvatar.src = avatarUrl;               // อัปเดต .src เป็นรูปโปรไฟล์ LINE หรือ Default สำรอง

        // กำหนดการแสดงผลเป็นรูปโปรไฟล์วงกลม
        barAvatar.style.borderRadius = '50%';
        barAvatar.style.objectFit = 'cover';

        // สำรองกรณีเกิดข้อผิดพลาดในการโหลดรูปภาพ ให้สลับเป็นรูป Default ป้องกันกรอบขาวว่าง
        barAvatar.onerror = function() {
            this.onerror = null;
            this.src = DEFAULT_AVATAR;
        };
    }

    // อัปเดตชื่อผู้ใช้ตรงมุมซ้ายบน (#bar-username) ให้สอดคล้องกัน
    const barUsername = document.getElementById('bar-username');
    if (barUsername && profile.displayName) {
        barUsername.textContent = profile.displayName;
    }

    return avatarUrl;
};

/**
 * ฟังก์ชัน Callback รองรับการเรียกแบบ liff.getProfile().then(profile => { ... })
 * สำหรับการเรียกใช้งานแบบ Promise / Callback Pattern หลังจากเข้าสู่ระบบ LINE Login สำเร็จ
 */
window.onLineLiffLoginCallback = function(customCallback) {
    if (typeof liff === 'undefined') return Promise.reject(new Error('LIFF SDK is not loaded'));

    return liff.getProfile().then(function(profile) {
        // ดึงข้อมูลรูปภาพจากคำสั่ง liff.getProfile() โดยอ้างอิงตัวแปร profile.pictureUrl
        const DEFAULT_AVATAR = 'avatars/google_avatar.png';
        let pictureSrc = profile.pictureUrl;

        // ตรวจสอบว่าหากผู้ใช้ไม่มีการตั้งรูปโปรไฟล์ใน LINE ให้ใส่รูป Default สำรองไว้เพื่อไม่ให้ขึ้นเป็นช่องวงกลมสีขาวว่างๆ
        if (!pictureSrc || typeof pictureSrc !== 'string' || !pictureSrc.trim()) {
            pictureSrc = DEFAULT_AVATAR;
        } else {
            pictureSrc = pictureSrc.trim();
        }

        // นำลิงก์รูปภาพนี้ ไปแทนที่ใน UI ของหน้าเกมตรงมุมซ้ายบน โดยสั่งอัปเดตค่า .src ของแท็กรูปภาพทันที
        const barAvatarImg = document.getElementById('bar-avatar');
        if (barAvatarImg) {
            barAvatarImg.referrerPolicy = 'no-referrer';
            barAvatarImg.src = pictureSrc;
            barAvatarImg.style.borderRadius = '50%';
            barAvatarImg.style.objectFit = 'cover';
            barAvatarImg.onerror = function() {
                this.onerror = null;
                this.src = DEFAULT_AVATAR;
            };
        }

        // นำข้อมูลไปอัปเดต State และ UI ของเกม
        window.updateProfileFromLineUser({
            displayName: profile.displayName,
            pictureUrl: pictureSrc,
            userId: profile.userId
        });

        if (typeof customCallback === 'function') {
            customCallback(profile, pictureSrc);
        }
        return profile;
    }).catch(function(err) {
        console.error('Callback error on liff.getProfile():', err);
        throw err;
    });
};

window.fetchAndApplyLineLiffProfile = async function() {
    if (typeof liff === 'undefined') {
        console.warn('LIFF SDK not loaded');
        return null;
    }

    try {
        // 1. ในส่วนฟังก์ชันตรวจสอบการล็อกอิน ให้ใช้ liff.getProfile() ดึงค่า displayName (ชื่อ) และ pictureUrl (ลิงก์รูปภาพ)
        const profile = await liff.getProfile();
        if (!profile) {
            console.warn('liff.getProfile() returned empty');
            return null;
        }

        const displayName = (profile.displayName || '').trim();
        let pictureUrl = (profile.pictureUrl || '').trim();
        const userId = (profile.userId || '').trim();
        const DEFAULT_AVATAR = 'avatars/google_avatar.png';

        if (displayName) {
            window.propagateRealPlayerName(displayName);
        }

        // ตรวจสอบว่าหากผู้ใช้ไม่มีการตั้งรูปโปรไฟล์ใน LINE ให้ใส่รูป Default สำรองไว้เพื่อไม่ให้ขึ้นเป็นช่องวงกลมสีขาวว่างๆ
        if (!pictureUrl) {
            pictureUrl = DEFAULT_AVATAR;
        }

        // 2. เขียนคำสั่งให้อัปเดต UI:
        // 2.1 นำ profile.displayName ไปแสดงแทนที่ข้อความชื่อเดิมตรงมุมซ้ายบน
        const barUsername = document.getElementById('bar-username')
                         || document.querySelector('#btn-profile .username span')
                         || document.querySelector('.top-bar .profile-details .username');
        if (barUsername) {
            barUsername.textContent = displayName || 'ผู้เล่น LINE';
            barUsername.innerText = displayName || 'ผู้เล่น LINE';
        }

        // 2.2 นำ profile.pictureUrl ไปใส่ในแท็กรูปภาพวงกลมที่มุมซ้ายบน (#bar-avatar)
        const barAvatar = document.getElementById('bar-avatar') || document.querySelector('.profile-avatar');
        if (barAvatar) {
            barAvatar.referrerPolicy = 'no-referrer'; // ป้องกัน LINE CDN บล็อก referrerpolicy
            barAvatar.src = pictureUrl;               // อัปเดต .src ทันที
            barAvatar.alt = displayName || 'LINE User';
            barAvatar.style.borderRadius = '50%';     // แสดงผลเป็นรูปวงกลม
            barAvatar.style.objectFit = 'cover';      // ไม่ให้ภาพเบี้ยวหรือยืด
            barAvatar.onerror = function() {
                this.onerror = null;
                this.src = DEFAULT_AVATAR;            // ป้องกันรูปแตกหรือเป็นกรอบขาวว่าง
            };
        }

        // 2.3 อัปเดต State หลักของเกม (DEFAULT_USER)
        window.updateProfileFromLineUser({
            displayName: displayName || 'ผู้เล่น LINE',
            pictureUrl: pictureUrl,
            userId: userId
        });

        // 2.4 ซิงค์ข้อมูลเข้าสู่ระบบหลังบ้าน (PHP / MariaDB) เพื่อรับ Token และข้อมูลเพชร/ทอง
        const idToken = (typeof liff.getIDToken === 'function') ? liff.getIDToken() : '';
        if (window.apiClient) {
            try {
                const res = await apiClient.loginWithLine(userId, displayName, pictureUrl, idToken);
                if (res && res.status === 'success' && res.token) {
                    localStorage.setItem('game_session_token', res.token);
                    localStorage.setItem('snake_auth_token', res.token);
                    if (res.user) {
                        const finalName = displayName || (res.user.username && !res.user.username.startsWith('LINE Player ') ? res.user.username : displayName);
                        Object.assign(DEFAULT_USER, res.user, {
                            username: finalName || DEFAULT_USER.username,
                            displayName: finalName || DEFAULT_USER.displayName,
                            avatar_url: pictureUrl,
                            line_id: userId
                        });
                        localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
                        window.propagateRealPlayerName(DEFAULT_USER.username);
                    }
                }
            } catch (apiErr) {
                console.warn('LINE backend sync warning:', apiErr);
            }
        }

        // 2.5 อัปเดตแถบผู้ใช้ ปิดหน้าต่างล็อกอิน และเริ่มเกม 3D
        updateUserBar(DEFAULT_USER);
        const authModal = document.getElementById('modal-auth');
        if (authModal) authModal.style.display = 'none';

        resumeOrStartGame(DEFAULT_USER);
        showToast(`🟢 เข้าสู่ระบบ LINE สำเร็จ! ยินดีต้อนรับคุณ ${displayName || 'ผู้เล่น LINE'}`);
        if (typeof confetti === 'function') {
            confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
        }

        return profile;
    } catch (err) {
        console.error('Error calling liff.getProfile():', err);
        showToast('⚠️ ไม่สามารถดึงข้อมูลโปรไฟล์จาก LINE LIFF ได้ (โปรดตรวจสอบ Scope: profile ใน LINE Developers Console)');
        return null;
    }
};

window.checkLineLoginStatus = window.fetchAndApplyLineLiffProfile;

window.loginWithLineLiff = async function() {
    sessionStorage.setItem('active_oauth_provider', 'line');

    // ตรวจสอบว่าโหลด LINE LIFF SDK และตั้งค่า LIFF ID ที่ใช้งานได้จริงหรือไม่
    if (typeof liff !== 'undefined' && window.LINE_LIFF_ID) {
        try {
            if (!isLiffInitialized) {
                await liff.init({ liffId: window.LINE_LIFF_ID });
                isLiffInitialized = true;
            }

            if (!liff.isLoggedIn()) {
                // หากยังไม่ได้ล็อกอิน ให้เรียกหน้าล็อกอินของ LINE LIFF
                liff.login({ redirectUri: window.location.origin + window.location.pathname });
                return;
            }

            // หากเข้าสู่ระบบสำเร็จแล้ว ให้เรียก liff.getProfile() เพื่อดึง displayName, pictureUrl, userId ทันที
            await window.fetchAndApplyLineLiffProfile();
            return;
        } catch (liffErr) {
            console.warn('LIFF init/login fallback to LINE OAuth v2.1:', liffErr);
        }
    }

    // Fallback: กรณีเปิดผ่านเว็บเบราว์เซอร์ปกติหรือยังไม่ได้ผูก LIFF ID ให้ใช้ LINE OAuth 2.1 ซึ่งดึง displayName, pictureUrl, userId กลับมาที่ฟังก์ชันเดียวกัน
    window.location.href = 'api/auth.php?action=login&provider=line';
};

async function checkAuthOnStartup() {
    const urlParams = new URLSearchParams(window.location.search);
    const hashParams = new URLSearchParams(window.location.hash ? window.location.hash.substring(1) : '');
    const tokenFromUrl = urlParams.get('token') || urlParams.get('auth_token');
    const codeFromUrl = urlParams.get('code');
    const googleIdTokenFromHash = hashParams.get('id_token') || urlParams.get('id_token');
    const googleAccessTokenFromHash = hashParams.get('access_token') || urlParams.get('access_token');

    // 0. ตรวจสอบกรณีกลับมาจาก LINE LIFF SDK (มี liff.state หรืออยู่ในแอป LINE LIFF)
    if (typeof liff !== 'undefined' && window.LINE_LIFF_ID) {
        try {
            await liff.init({ liffId: window.LINE_LIFF_ID });
            isLiffInitialized = true;
            if (liff.isLoggedIn()) {
                const profile = await window.fetchAndApplyLineLiffProfile();
                if (profile) return;
            }
        } catch (e) {
            console.warn('LIFF startup check skipped:', e);
        }
    }

    // 0.5 ตรวจสอบกรณีกลับมาจาก Google OAuth (Implicit/Hybrid Flow: #access_token=...&id_token=...)
    // ดึงข้อมูล name, picture, email, sub จาก Google User Object แล้วนำไปแสดงผลที่ #bar-avatar และ #bar-username ทันที
    if (googleIdTokenFromHash || googleAccessTokenFromHash) {
        let googleUserObj = {};

        // ถอดรหัส Google ID Token (JWT) ทันทีที่ฝั่ง Client
        if (googleIdTokenFromHash) {
            const decodedJwt = window.parseGoogleJwt(googleIdTokenFromHash);
            if (decodedJwt) {
                googleUserObj = { ...googleUserObj, ...decodedJwt };
            }
        }

        // ดึงข้อมูลโปรไฟล์ล่าสุดจาก Google UserInfo API ด้วย access_token (เพื่อความแม่นยำ 100%)
        if (googleAccessTokenFromHash) {
            try {
                const uRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                    headers: { 'Authorization': `Bearer ${googleAccessTokenFromHash}` }
                });
                if (uRes.ok) {
                    const uData = await uRes.json();
                    if (uData && (uData.name || uData.picture || uData.sub)) {
                        googleUserObj = { ...googleUserObj, ...uData };
                    }
                }
            } catch (err) {
                console.warn('Google UserInfo fetch warning:', err);
            }
        }

        googleUserObj.id_token = googleIdTokenFromHash || '';
        googleUserObj.access_token = googleAccessTokenFromHash || '';

        // 1) อัปเดต UI มุมซ้ายบน (#bar-avatar และ #bar-username) ทันทีจาก Google User Object
        const applied = window.updateProfileFromGoogleUser(googleUserObj);

        // ปิดหน้าต่าง Login และล้างค่า Hash บน URL
        const authModal = document.getElementById('modal-auth');
        if (authModal) authModal.style.display = 'none';
        try {
            window.history.replaceState({}, document.title, window.location.pathname);
        } catch (e) {}

        // 2) ซิงค์ข้อมูลเข้าสู่ฐานข้อมูลหลังบ้าน (api/auth.php?action=login_google)
        if (window.apiClient) {
            try {
                const res = await apiClient.loginWithGoogle(googleUserObj);
                if (res && res.status === 'success' && res.token) {
                    localStorage.setItem('game_session_token', res.token);
                    localStorage.setItem('snake_auth_token', res.token);
                    const serverUser = res.user || res.data || {};
                    const mergedUser = {
                        ...serverUser,
                        username: (applied && applied.name) || serverUser.username,
                        name: (applied && applied.name) || serverUser.username,
                        avatar_url: (applied && applied.picture) || serverUser.avatar_url,
                        picture: (applied && applied.picture) || serverUser.avatar_url,
                        email: googleUserObj.email || serverUser.email || '',
                        google_id: googleUserObj.sub || serverUser.google_id || ''
                    };
                    Object.assign(DEFAULT_USER, mergedUser);
                    window.updateProfileFromGoogleUser(mergedUser);
                    updateUserBar(DEFAULT_USER);
                    resumeOrStartGame(DEFAULT_USER);
                    showToast(`🎉 เข้าสู่ระบบ Google สำเร็จ! ยินดีต้อนรับคุณ ${DEFAULT_USER.username}`);
                    if (typeof confetti === 'function') {
                        confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
                    }
                    return;
                }
            } catch (apiErr) {
                console.warn('Google backend sync warning:', apiErr);
            }
        }

        updateUserBar(DEFAULT_USER);
        resumeOrStartGame(DEFAULT_USER);
        showToast(`🎉 เข้าสู่ระบบ Google สำเร็จ! ยินดีต้อนรับคุณ ${DEFAULT_USER.username}`);
        return;
    }

    // 1. If returning with ?code= from LINE / Google OAuth: forward to backend to exchange code
    if (codeFromUrl) {
        const storedProvider = sessionStorage.getItem('active_oauth_provider');
        const isGoogle = storedProvider === 'google' 
                      || window.location.search.includes('scope=') 
                      || window.location.search.includes('google')
                      || window.location.search.includes('authuser');
        const providerName = isGoogle ? 'Google' : 'LINE';
        const actionName = isGoogle ? 'google_callback' : 'line_callback';

        showToast(`🔄 กำลังยืนยันตัวตนกับระบบ ${providerName}...`);
        window.location.href = `api/auth.php?action=${actionName}&code=` + encodeURIComponent(codeFromUrl);
        return;
    }

    // 2. If returning with ?token= from Backend OAuth Redirect:
    if (tokenFromUrl) {
        localStorage.setItem('game_session_token', tokenFromUrl);
        localStorage.setItem('snake_auth_token', tokenFromUrl);

        // ดึงข้อมูล LINE / Google User Object จาก URL Redirect (ถ้ามี) เพื่ออัปเดต UI มุมซ้ายบนทันที
        const authProvider = (urlParams.get('auth_provider') || '').toUpperCase();
        const googleUserB64 = urlParams.get('google_user');
        const nameParam = urlParams.get('name');
        const pictureParam = urlParams.get('picture');
        const emailParam = urlParams.get('email') || urlParams.get('sub');

        if (googleUserB64) {
            try {
                const decodedJson = decodeURIComponent(escape(atob(googleUserB64)));
                const socialUserObj = JSON.parse(decodedJson);
                if (authProvider === 'LINE' || socialUserObj.provider === 'line') {
                    updateProfileFromLineUser({
                        displayName: socialUserObj.name,
                        pictureUrl: socialUserObj.picture,
                        userId: socialUserObj.sub || socialUserObj.id
                    });
                } else {
                    updateProfileFromGoogleUser(socialUserObj);
                }
            } catch (e) {
                console.warn('Error parsing social user payload:', e);
            }
        } else if (nameParam || pictureParam || emailParam) {
            if (authProvider === 'LINE') {
                updateProfileFromLineUser({
                    displayName: nameParam,
                    pictureUrl: pictureParam,
                    userId: urlParams.get('sub') || emailParam
                });
            } else {
                updateProfileFromGoogleUser({
                    name: nameParam,
                    picture: pictureParam,
                    email: emailParam,
                    sub: urlParams.get('sub') || emailParam
                });
            }
        }

        // Hide Login Modal immediately
        const authModal = document.getElementById('modal-auth');
        if (authModal) authModal.style.display = 'none';

        // Clean URL parameters cleanly
        try {
            window.history.replaceState({}, document.title, window.location.pathname);
        } catch (e) {}

        // Set token on apiClient safely
        if (window.apiClient) {
            if (typeof apiClient.setToken === 'function') {
                apiClient.setToken(tokenFromUrl);
            } else {
                apiClient.token = tokenFromUrl;
            }

            try {
                const res = await apiClient.getProfile();
                if (res && res.status === 'success' && res.data) {
                    const user = res.data;
                    localStorage.setItem('snake_user_data', JSON.stringify(user));
                    applyUserProfileBasedOnProvider(user);
                    resumeOrStartGame(DEFAULT_USER);
                    showToast(`🎉 ยินดีต้อนรับคุณ ${DEFAULT_USER.username} เข้าสู่ระบบสำเร็จ!`);
                    return;
                }
            } catch (e) {
                console.warn('Profile fetch error on oauth return:', e);
            }
        }

        resumeOrStartGame(DEFAULT_USER);
        return;
    }

    // 3. Check existing saved session in localStorage (WHEN USER REFRESHES F5!)
    const savedToken = localStorage.getItem('game_session_token') || localStorage.getItem('snake_auth_token');
    const savedUserJson = localStorage.getItem('snake_user_data');

    if (savedToken) {
        // KEEP LOGIN MODAL HIDDEN! Do not pop up modal on refresh!
        const authModal = document.getElementById('modal-auth');
        if (authModal) authModal.style.display = 'none';

        if (window.apiClient) {
            if (typeof apiClient.setToken === 'function') {
                apiClient.setToken(savedToken);
            } else {
                apiClient.token = savedToken;
            }
        }

        // Instantly display cached user data for zero UI flicker
        if (savedUserJson) {
            try {
                const user = JSON.parse(savedUserJson);
                if (user && (user.username || user.name) && user.username !== 'ยังไม่ได้เข้าสู่ระบบ' && user.username !== 'Google Player') {
                    applyUserProfileBasedOnProvider(user);
                    resumeOrStartGame(DEFAULT_USER);
                }
            } catch (e) {
                console.warn('Error parsing cached user:', e);
            }
        }

        // Asynchronously sync latest profile from server (ดึงเพชร ทอง สังกัดบ้าน และชื่อ Google/LINE ล่าสุดจากฐานข้อมูลเสมอ)
        if (window.apiClient) {
            try {
                const res = await apiClient.getProfile();
                if (res && res.status === 'success' && res.data) {
                    const user = res.data;
                    localStorage.setItem('snake_user_data', JSON.stringify(user));
                    applyUserProfileBasedOnProvider(user);
                    resumeOrStartGame(DEFAULT_USER);
                    return;
                } else if (res && res.status === 'error' && (res.message?.includes('Unauthorized') || res.message?.includes('Invalid token') || res.message?.includes('User not found'))) {
                    // Token expired/revoked: clear and prompt login
                    localStorage.removeItem('game_session_token');
                    localStorage.removeItem('snake_auth_token');
                    localStorage.removeItem('snake_user_data');
                    openAuthModal();
                    return;
                }
            } catch (e) {
                console.warn('Background profile refresh warning:', e);
            }
        }

        if (savedUserJson) {
            return;
        }
    }

    // 4. Truly not logged in: show login modal (only if NOT inside an active match!)
    if (document.body.classList.contains('in-match-fullscreen') || (window.game && window.game.isMatchActive)) {
        return;
    }
    DEFAULT_USER.username = 'ยังไม่ได้เข้าสู่ระบบ';
    DEFAULT_USER.diamond = 0;
    DEFAULT_USER.gold = 0;
    updateUserBar(DEFAULT_USER);

    if (window.game) {
        window.game.players = [];
        const turnEl = document.getElementById('turn-status-text');
        if (turnEl) turnEl.innerText = 'กรุณาสร้าง ID หรือเข้าสู่ระบบเพื่อเริ่มเล่น';
    }

    setTimeout(() => {
        openAuthModal();
    }, 250);
}

function updateUserBar(user) {
    if (!user) user = DEFAULT_USER;

    // ซิงค์ DEFAULT_USER ให้ตรงกับบัญชีผู้ใช้ปัจจุบันเสมอ ป้องกันข้อมูลไอดีเก่าตกค้าง
    if (user && user !== DEFAULT_USER) {
        if (user.id !== undefined && user.id !== null) DEFAULT_USER.id = user.id;
        if (user.username) DEFAULT_USER.username = user.username;
        if (user.name) DEFAULT_USER.name = user.name;
        if (user.displayName) DEFAULT_USER.displayName = user.displayName;
        if (user.avatar_url) DEFAULT_USER.avatar_url = user.avatar_url;
        if (user.picture) DEFAULT_USER.picture = user.picture;
        if (user.pictureUrl) DEFAULT_USER.pictureUrl = user.pictureUrl;
        if (user.level !== undefined) DEFAULT_USER.level = user.level;
        if (user.diamond !== undefined) DEFAULT_USER.diamond = user.diamond;
        if (user.gold !== undefined) DEFAULT_USER.gold = user.gold;
        if (user.clan_name !== undefined) DEFAULT_USER.clan_name = user.clan_name;
        if (user.auth_provider) DEFAULT_USER.auth_provider = user.auth_provider;
    }

    const nameEl = document.getElementById('bar-username')
                || document.querySelector('#btn-profile .username span')
                || document.querySelector('.top-bar .profile-details .username');
    const diaEl = document.getElementById('bar-diamond');
    const goldEl = document.getElementById('bar-gold');
    const lvlEl = document.getElementById('bar-level-badge');
    const clanEl = document.getElementById('bar-clan-name');

    const displayName = user.name || user.username || DEFAULT_USER.username;
    if (nameEl) {
        nameEl.textContent = displayName;
        nameEl.innerText = displayName;
    }
    if (diaEl) diaEl.innerText = Number(user.diamond ?? DEFAULT_USER.diamond).toLocaleString();
    if (goldEl) goldEl.innerText = Number(user.gold ?? DEFAULT_USER.gold).toLocaleString();
    if (lvlEl) lvlEl.innerText = `Lv.${user.level || 1} ⭐`;
    if (clanEl) clanEl.innerText = user.clan_name || DEFAULT_USER.clan_name;

    // Update avatar image from Google / LINE / Profile (#bar-avatar / .profile-avatar)
    const avatarEl = document.getElementById('bar-avatar')
                  || document.querySelector('#btn-profile img.profile-avatar')
                  || document.querySelector('.top-bar img.profile-avatar');
    if (avatarEl) {
        const provider = (user.auth_provider || DEFAULT_USER.auth_provider || localStorage.getItem('snake_auth_provider') || '').toLowerCase();
        let avatarUrl = user.avatar_url || user.pictureUrl || user.picture || DEFAULT_USER.avatar_url || DEFAULT_USER.pictureUrl || DEFAULT_USER.picture || 'avatars/avatar_01.svg';
        avatarEl.referrerPolicy = 'no-referrer';
        avatarEl.onerror = function() {
            this.onerror = null;
            this.src = 'avatars/avatar_01.svg';
        };
        avatarEl.src = avatarUrl;
        avatarEl.alt = displayName;
        avatarEl.style.borderRadius = '50%';
        avatarEl.style.objectFit = 'cover';

        if (window.game) {
            if (typeof window.game.updatePlayerPawnAvatar === 'function' && displayName !== 'ยังไม่ได้เข้าสู่ระบบ') {
                window.game.updatePlayerPawnAvatar(0, user, displayName, provider);
            }
            if (!window.game.isMatchActive && typeof window.game.setupIdlePreview === 'function') {
                window.game.setupIdlePreview(user);
            }
        }
        const frameGrade = user.character_grade || user.equipped_character_grade || localStorage.getItem('snake_equipped_frame_grade') || 'A';
        const frameAura = user.aura_type || user.character_aura || localStorage.getItem('snake_equipped_frame_aura') || '';
        const frameIntensity = user.aura_intensity !== undefined ? parseInt(user.aura_intensity) : (parseInt(localStorage.getItem('snake_equipped_frame_intensity')) || 100);
        const frameRingUrl = user.character_frame_url !== undefined ? (user.character_frame_url || '') : (localStorage.getItem('snake_equipped_frame_ring_url') || '');
        const frameFx = user.character_frame_fx || localStorage.getItem('snake_equipped_frame_fx') || 'pulse_breathe';
        const frameScale = user.character_frame_scale !== undefined ? parseInt(user.character_frame_scale) : (parseInt(localStorage.getItem('snake_equipped_frame_scale')) || 120);
        applyTopBarAvatarAura(frameGrade, frameAura, frameIntensity, frameRingUrl, frameFx, frameScale);
    }
}

// =========================================================================
// ระบบสุ่มชื่อผู้เล่นคู่แข่ง (ไทย & อังกฤษ) และรูปโปรไฟล์หลากหลายรูปแบบ (ไม่ซ้ำกัน และไม่แสดงคำว่าบอท)
// =========================================================================
const OPPONENT_THAI_NAMES = [
    'ภัทร สายฟ้า', 'แพรวา พารวย', 'ต้นกล้า นาคราช', 'มินตรา ดาวเหนือ',
    'นนท์ เซียนเต๋า', 'พลอย ประกายเพชร', 'กานต์ อัศวิน', 'ออมสิน มังกรทอง',
    'คิริน พิชิตชัย', 'นารา จันทรา', 'ภูผา เพลิงกัลป์', 'รินรดา สายหมอก',
    'ธาม ทะเลดาว', 'ของขวัญ นำโชค', 'เจเจ สปีด', 'ปั้นจั่น พญาอินทรี',
    'ใบเฟิร์น ทองคำ', 'เตชินท์ วายุ', 'ทอฝัน มณีรุ้ง', 'วินเนอร์ สายลุย',
    'ตะวัน ฉายแสง', 'แก้มใส ใจดี', 'น้ำหนึ่ง พารวย', 'บอส พันล้าน',
    'เมฆา ลอยลม', 'ไอซ์ซี่ สโนว์', 'ออสติน สตาร์', 'ไบร์ท สายเปย์',
    'เบลล่า เศรษฐีนี', 'มาริโอ้ ซูเปอร์ริช', 'ลิซ่า พารวย', 'ณเดชน์ พารวย'
];

const OPPONENT_ENGLISH_NAMES = [
    'ภัทร สายฟ้า', 'แพรวา พารวย', 'ต้นกล้า นาคราช', 'มินตรา ดาวเหนือ',
    'นนท์ เซียนเต๋า', 'พลอย ประกายเพชร', 'กานต์ อัศวิน', 'ออมสิน มังกรทอง',
    'คิริน พิชิตชัย', 'นารา จันทรา', 'ภูผา เพลิงกัลป์', 'รินรดา สายหมอก'
];

const OPPONENT_AVATAR_THEMES = [
    { id: 1,  bg1: '#ff416c', bg2: '#ff4b2b', hair: '#1e1b4b', skin: '#fde68a', shirt: '#fbbf24', acc: 'crown' },
    { id: 2,  bg1: '#00c6ff', bg2: '#0072ff', hair: '#0f172a', skin: '#fed7aa', shirt: '#38bdf8', acc: 'visor' },
    { id: 3,  bg1: '#a855f7', bg2: '#6366f1', hair: '#f472b6', skin: '#fef3c7', shirt: '#c084fc', acc: 'star' },
    { id: 4,  bg1: '#10b981', bg2: '#047857', hair: '#451a03', skin: '#fde68a', shirt: '#34d399', acc: 'headband' },
    { id: 5,  bg1: '#f59e0b', bg2: '#b45309', hair: '#7c2d12', skin: '#ffedd5', shirt: '#ef4444', acc: 'glasses' },
    { id: 6,  bg1: '#ec4899', bg2: '#be185d', hair: '#31102f', skin: '#fce7f3', shirt: '#f43f5e', acc: 'ribbon' },
    { id: 7,  bg1: '#14b8a6', bg2: '#0f766e', hair: '#134e4a', skin: '#fef08a', shirt: '#2dd4bf', acc: 'headphones' },
    { id: 8,  bg1: '#f97316', bg2: '#c2410c', hair: '#1c1917', skin: '#fed7aa', shirt: '#fb923c', acc: 'flame' },
    { id: 9,  bg1: '#3b82f6', bg2: '#1d4ed8', hair: '#e2e8f0', skin: '#ffedd5', shirt: '#60a5fa', acc: 'halo' },
    { id: 10, bg1: '#8b5cf6', bg2: '#4c1d95', hair: '#fde047', skin: '#fef3c7', shirt: '#a78bfa', acc: 'crown' },
    { id: 11, bg1: '#ef4444', bg2: '#7f1d1d', hair: '#090d16', skin: '#fde68a', shirt: '#f87171', acc: 'visor' },
    { id: 12, bg1: '#06b6d4', bg2: '#155e75', hair: '#fb7185', skin: '#fff1f2', shirt: '#22d3ee', acc: 'star' },
    { id: 13, bg1: '#84cc16', bg2: '#3f6212', hair: '#27272a', skin: '#fef9c3', shirt: '#a3e635', acc: 'headband' },
    { id: 14, bg1: '#d946ef', bg2: '#701a75', hair: '#38bdf8', skin: '#fce7f3', shirt: '#e879f9', acc: 'glasses' },
    { id: 15, bg1: '#eab308', bg2: '#713f12', hair: '#1e293b', skin: '#ffedd5', shirt: '#facc15', acc: 'headphones' },
    { id: 16, bg1: '#6366f1', bg2: '#312e81', hair: '#f43f5e', skin: '#fde68a', shirt: '#818cf8', acc: 'ribbon' }
];

window.buildOpponentAvatarSvgDataUrl = function(themeIndex = 0) {
    const t = OPPONENT_AVATAR_THEMES[Math.abs(Number(themeIndex) || 0) % OPPONENT_AVATAR_THEMES.length];
    let accSvg = '';
    if (t.acc === 'crown') {
        accSvg = '<polygon points="82,58 96,34 128,52 160,34 174,58" fill="#ffd700" stroke="#ffffff" stroke-width="3"/>';
    } else if (t.acc === 'visor') {
        accSvg = '<rect x="82" y="102" width="92" height="22" rx="11" fill="#00e5ff" stroke="#ffffff" stroke-width="3" opacity="0.92"/>';
    } else if (t.acc === 'star') {
        accSvg = '<circle cx="168" cy="68" r="14" fill="#ffd700" stroke="#fff" stroke-width="2.5"/>';
    } else if (t.acc === 'headband') {
        accSvg = '<path d="M76,90 Q128,78 180,90" stroke="#ef4444" stroke-width="11" stroke-linecap="round" fill="none"/>';
    } else if (t.acc === 'glasses') {
        accSvg = '<circle cx="106" cy="114" r="15" fill="#0f172a" stroke="#ffd700" stroke-width="4"/><circle cx="150" cy="114" r="15" fill="#0f172a" stroke="#ffd700" stroke-width="4"/><line x1="121" y1="114" x2="135" y2="114" stroke="#ffd700" stroke-width="4"/>';
    } else if (t.acc === 'headphones') {
        accSvg = '<path d="M72,120 A56,56 0 0,1 184,120" stroke="#00e5ff" stroke-width="10" fill="none"/><rect x="62" y="106" width="16" height="32" rx="8" fill="#00e5ff"/><rect x="178" y="106" width="16" height="32" rx="8" fill="#00e5ff"/>';
    } else if (t.acc === 'ribbon') {
        accSvg = '<circle cx="128" cy="52" r="10" fill="#ff007f"/><polygon points="102,42 124,52 102,62" fill="#ff007f"/><polygon points="154,42 132,52 154,62" fill="#ff007f"/>';
    } else {
        accSvg = '<ellipse cx="128" cy="44" rx="34" ry="8" fill="none" stroke="#00ffcc" stroke-width="5"/>';
    }

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" width="256" height="256">
        <defs>
            <linearGradient id="bg${t.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="${t.bg1}"/>
                <stop offset="100%" stop-color="${t.bg2}"/>
            </linearGradient>
        </defs>
        <rect width="256" height="256" rx="128" fill="url(#bg${t.id})"/>
        <circle cx="128" cy="128" r="116" fill="none" stroke="rgba(255,255,255,0.28)" stroke-width="4"/>
        <!-- ลำตัว/เสื้อ -->
        <path d="M56,244 C62,186 92,172 128,172 C164,172 194,186 200,244 Z" fill="${t.shirt}"/>
        <path d="M102,174 L128,206 L154,174" fill="#ffffff" opacity="0.85"/>
        <!-- ทรงผมด้านหลัง -->
        <circle cx="128" cy="108" r="56" fill="${t.hair}"/>
        <!-- ใบหน้า -->
        <circle cx="128" cy="118" r="46" fill="${t.skin}"/>
        <!-- ดวงตาสดใส -->
        <circle cx="110" cy="116" r="6.5" fill="#0f172a"/>
        <circle cx="146" cy="116" r="6.5" fill="#0f172a"/>
        <circle cx="112" cy="114" r="2.2" fill="#ffffff"/>
        <circle cx="148" cy="114" r="2.2" fill="#ffffff"/>
        <!-- แก้มชมพู & รอยยิ้ม -->
        <ellipse cx="98" cy="128" rx="7" ry="4" fill="#fb7185" opacity="0.55"/>
        <ellipse cx="158" cy="128" rx="7" ry="4" fill="#fb7185" opacity="0.55"/>
        <path d="M114,134 Q128,146 142,134" stroke="#0f172a" stroke-width="4.5" stroke-linecap="round" fill="none"/>
        <!-- ผมด้านหน้า -->
        <path d="M82,102 Q105,64 148,76 Q168,82 174,104 Q146,84 118,92 Q96,96 82,102 Z" fill="${t.hair}"/>
        ${accSvg}
    </svg>`;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
};

window.isLegacyBotDisplayName = function(name) {
    const str = String(name || '').trim();
    if (!str) return true;
    return /บอท|🤖|\(AI\)|\bAI\b|\bBot\b/i.test(str);
};

window.getOpponentAvatarByName = function(name = '', index = 0) {
    if (typeof window.getDeterministicRealisticAvatar === 'function') {
        return window.getDeterministicRealisticAvatar(name, index);
    }
    const str = String(name || '').trim();
    let hash = 0;
    for (let c = 0; c < str.length; c++) {
        hash = (hash << 5) - hash + str.charCodeAt(c);
        hash |= 0;
    }
    const themeIdx = Math.abs(hash + Number(index || 0)) % OPPONENT_AVATAR_THEMES.length;
    return (typeof window.buildOpponentAvatarSvgDataUrl === 'function') 
        ? window.buildOpponentAvatarSvgDataUrl(themeIdx) 
        : 'avatars/google_avatar.png';
};

window.pickUniqueOpponentProfiles = function(count = 1, excludeNames = []) {
    const usedNames = new Set(
        (Array.isArray(excludeNames) ? excludeNames : [excludeNames])
            .map(n => String(n || '').trim().toLowerCase())
            .filter(Boolean)
    );

    // สุ่มชื่อผู้เล่นคู่แข่งคนไทยและเอเชียแบบไม่ซ้ำ
    const allNames = [...OPPONENT_THAI_NAMES]
        .filter(n => !usedNames.has(n.toLowerCase()))
        .sort(() => Math.random() - 0.5);

    const results = [];
    for (let i = 0; i < count; i++) {
        const chosenName = allNames[i % allNames.length] || `ผู้เล่น ${i + 2}`;
        usedNames.add(chosenName.toLowerCase());
        const avatarUrl = (typeof window.getDeterministicRealisticAvatar === 'function')
            ? window.getDeterministicRealisticAvatar(chosenName, i)
            : `avatars/bots/bot_${i % 2 === 0 ? 'f' : 'm'}01.jpg`;
        results.push({
            username: chosenName,
            avatar_url: avatarUrl,
            picture: avatarUrl,
            avatar_theme_id: i + 1
        });
    }
    return results;
};

window.simulateOfflineMatchTurns = function(saved, elapsedMs) {
    if (!saved || saved.isGameOver || !Array.isArray(saved.players) || saved.players.length < 1) return;
    if (elapsedMs < 3500) return;

    // จำกัดจำนวนเทิร์นที่จำลองไว้ไม่เกิน 2 เทิร์น เพื่อให้เกมยังคงดำเนินต่อบนหน้าจอในโหมด AUTO
    // และไม่ตัดจบเป็นหน้าแพ้ชนะหรือดีดกลับหน้าแรกก่อนที่ผู้เล่นจะเข้ามาเล่นต่อ
    const turnsToSim = Math.min(Math.floor(elapsedMs / 4000), 2);
    const ladders = { 4: 14, 9: 31, 22: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91 };
    const snakes = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78 };
    saved.cityStates = saved.cityStates || {};

    for (let s = 0; s < turnsToSim; s++) {
        if (saved.isGameOver) break;
        let active = saved.players[saved.currentTurnIndex];
        if (!active || active.isBankrupt) {
            const alive = saved.players.filter(p => !p.isBankrupt);
            if (alive.length <= 1) {
                saved.isGameOver = true;
                saved.winner = alive[0] || active;
                saved.winReason = 'BANKRUPTCY';
                break;
            }
            saved.currentTurnIndex = (saved.currentTurnIndex + 1) % saved.players.length;
            continue;
        }

        const d1 = Math.floor(Math.random() * 6) + 1;
        const d2 = Math.floor(Math.random() * 6) + 1;
        const roll = d1 + d2;
        let target = (active.currentTile || 1) + roll;
        if (target > 100) target = 100 - (target - 100);

        if (ladders[target]) target = ladders[target];
        else if (snakes[target]) target = snakes[target];
        active.currentTile = target;

        if (target === 100) {
            saved.isGameOver = true;
            saved.winner = active;
            saved.winReason = 'FINISH_LINE';
            break;
        }

        if (target > 1 && target < 100 && ![10, 11, 15, 20, 45, 52, 68, 76, 82, 88].includes(target)) {
            const city = saved.cityStates[target];
            if (!city) {
                const baseCost = saved.matchConfig?.city_base_cost || 120000;
                if ((active.matchGold || 0) >= baseCost) {
                    active.matchGold -= baseCost;
                    saved.cityStates[target] = {
                        ownerId: active.id,
                        ownerName: active.username,
                        level: 1,
                        isLandmark: false,
                        investedGold: baseCost,
                        color: active.color
                    };
                }
            } else if (city.ownerId !== active.id && (saved.gameMode !== 'TEAM' || city.team !== active.team)) {
                const toll = Math.round((city.investedGold || 120000) * 0.85);
                active.matchGold = (active.matchGold || 0) - toll;
                const owner = saved.players.find(p => p.id === city.ownerId);
                if (owner) owner.matchGold = (owner.matchGold || 0) + toll;
                if (active.matchGold <= 0) {
                    active.isBankrupt = true;
                    const alive = saved.players.filter(p => !p.isBankrupt);
                    if (alive.length <= 1) {
                        saved.isGameOver = true;
                        saved.winner = alive[0] || active;
                        saved.winReason = 'BANKRUPTCY';
                        break;
                    }
                }
            }
        }

        saved.currentTurnIndex = (saved.currentTurnIndex + 1) % saved.players.length;
    }

    saved.timestamp = Date.now();
};

function resumeOrStartGame(currentUser) {
    if (!window.game) return;
    const u = currentUser || DEFAULT_USER;
    const savedLineName = localStorage.getItem('snake_line_display_name');
    let activeName = u.displayName || u.name || u.username || DEFAULT_USER.username;
    if ((!activeName || activeName.startsWith('LINE Player ') || activeName === 'LINE Player') && savedLineName) {
        activeName = savedLineName;
        u.username = savedLineName;
        u.displayName = savedLineName;
        DEFAULT_USER.username = savedLineName;
        DEFAULT_USER.displayName = savedLineName;
    }
    const activeProvider = (u.auth_provider || DEFAULT_USER.auth_provider || localStorage.getItem('snake_auth_provider') || '').toLowerCase();
    const activeAvatar = (typeof window.getActivePlayerAvatarUrl === 'function')
        ? window.getActivePlayerAvatarUrl(u)
        : (u.avatar_url || u.pictureUrl || u.picture || 'avatars/avatar_01.svg');

    // สแตนด์บายหน้ากระดานหลักเสมอเมื่อโหลดหน้าเว็บหรือล็อกอิน: ห้ามเริ่มเล่นอัตโนมัติเด็ดขาดจนกว่าผู้เล่นจะกดปุ่ม "ทดลองเล่น" หรือเลือก "ห้องแข่งขัน"
    window.isPracticeMatch = false;
    window.currentRoomId = null;
    document.body.classList.remove('in-match-fullscreen');
    if (typeof window.game.setupIdlePreview === 'function') {
        window.game.setupIdlePreview(u);
    }
}

window.openPracticeBoardSelectModal = function() {
    // 1. เด้งไปหน้าจอใหญ่ทันที
    document.body.classList.add('in-match-fullscreen');
    if (window.game && typeof window.game.onWindowResize === 'function') {
        setTimeout(() => window.game.onWindowResize(), 60);
    }

    // 2. ปรับข้อความหัวข้อใน Modal สำหรับโหมดทดลองเล่น
    const titleEl = document.getElementById('board-modal-title');
    const subEl = document.getElementById('board-modal-subtitle');
    const playBtn = document.getElementById('btn-confirm-board-play');
    if (titleEl) titleEl.innerText = '🎮 ทดลองเล่น (1 ต่อ 1) — เลือกกระดาน 3D';
    if (subEl) subEl.innerText = 'เลือกรูปทรงกระดานและธีม 3D ที่ต้องการทดสอบ แล้วเริ่มเล่นกับบอททันที!';
    if (playBtn) playBtn.innerHTML = '🚀 เริ่มเล่นกับบอททันที (1v1)';

    openModal('modal-boards');
};

window.exitPracticeMatch = function() {
    if (!window.game) return;

    // หากเป็นการแข่งขันในห้องจริง (ไม่ใช่ทดลองเล่น) ให้ถามยืนยันก่อน
    if (!window.isPracticeMatch && window.game.isMatchActive) {
        const ok = confirm('คุณกำลังแข่งขันในห้องแข่งขันจริง หากออกจากเกมจะถือว่าสละสิทธิ์ ต้องการออกจากเกมใช่หรือไม่?');
        if (!ok) return;
    }

    // หยุดระบบเสียงหรือเอฟเฟกต์ที่กำลังทำงาน
    if (window.soundEngine && typeof window.soundEngine.stopAll === 'function') {
        try { window.soundEngine.stopAll(); } catch(e) {}
    }

    // ล้างสถานะการแข่งขันในเครื่อง
    window.isPracticeMatch = false;
    window.currentRoomId = null;
    document.body.classList.remove('in-match-fullscreen');

    if (typeof window.game.clearSavedSession === 'function') {
        window.game.clearSavedSession();
    }

    // รีเซ็ตกระดาน 3D กลับสู่สถานะสแตนด์บายหน้าหลัก (แสดงหมากคนเดียวที่จุด START)
    if (typeof window.game.setupIdlePreview === 'function') {
        window.game.setupIdlePreview(window.DEFAULT_USER);
    }

    if (typeof window.game.onWindowResize === 'function') {
        setTimeout(() => window.game.onWindowResize(), 80);
    }

    if (typeof window.updatePracticeExitButtonVisibility === 'function') {
        window.updatePracticeExitButtonVisibility();
    }

    if (typeof showToast === 'function') {
        showToast('🚪 ออกจากการทดลองเล่น กลับสู่หน้าหลักเรียบร้อยแล้ว');
    }
};

window.updatePracticeExitButtonVisibility = function() {
    const exitBtn = document.getElementById('btn-exit-practice');
    const isMatchActive = Boolean(window.game && window.game.isMatchActive && !window.game.isGameOver);
    if (exitBtn) {
        exitBtn.style.display = isMatchActive ? 'inline-flex' : 'none';
    }
};

window.startExplicitPracticeMatch = function() {
    document.body.classList.add('in-match-fullscreen');
    const u = (window.apiClient && window.apiClient.currentUser) ||
              (typeof window.getActiveUserObject === 'function' ? window.getActiveUserObject() : null) ||
              DEFAULT_USER;
    startQuickDemoMatch(u);
    if (typeof window.updatePracticeExitButtonVisibility === 'function') {
        window.updatePracticeExitButtonVisibility();
    }
    if (typeof showToast === 'function') {
        showToast('🎮 เริ่มโหมดทดลองเล่น (1 ต่อ 1) แล้ว! กด "ทอยลูกเต๋า" เพื่อเริ่มเดิน');
    }
};

function startQuickDemoMatch(currentUser) {
    if (!window.game) return;
    const u = currentUser || DEFAULT_USER;
    let myDisplayName = u.displayName || u.name || u.username || 'ผู้เล่น';
    if (myDisplayName === 'เขียนศักดิ์' || myDisplayName === 'Google Player') {
        myDisplayName = 'ผู้เล่น';
    }
    const activeProvider = (u.auth_provider || DEFAULT_USER.auth_provider || localStorage.getItem('snake_auth_provider') || 'credentials').toLowerCase();
    const activeAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl(u) : (u.avatar_url || u.pictureUrl || u.picture || 'avatars/avatar_01.svg');
    window.isPracticeMatch = true; // โหมดทดลองเล่นเดี่ยว (1 ต่อ 1)
    window.currentRoomId = null;
    window.currentActiveRoomTier = 'PRACTICE';

    // สุ่มชื่อคู่แข่ง (ไทย/อังกฤษ ไม่ซ้ำกับผู้เล่น) และสุ่มรูปโปรไฟล์ที่ไม่ซ้ำกัน
    const [opponentProfile] = window.pickUniqueOpponentProfiles(1, [myDisplayName]);
    const practiceCfg = typeof window.getActiveRoomEconomyConfig === 'function'
        ? window.getActiveRoomEconomyConfig('PRACTICE')
        : null;

    const players = [
        // 1. ผู้เล่นหลัก (เล่นเดี่ยว พร้อมค่าสกิลกรอบรูปและสกิลเต๋าที่สวมใส่)
        {
            id: u.id || 1,
            username: myDisplayName,
            auth_provider: activeProvider || (u.pictureUrl ? 'line' : 'google'),
            picture: activeProvider === 'line' ? undefined : activeAvatar,
            pictureUrl: activeProvider === 'line' ? activeAvatar : undefined,
            avatar_url: activeAvatar,
            team: 'NONE',
            team_name: '',
            color: 0x00e5ff, // Neon Cyan
            is_bot: false,
            is_awakened: true,
            skill: { code: 'PULL_BACK_8', power: 8 },
            dice_control_rate: Number(u.dice_control_rate ?? DEFAULT_USER.dice_control_rate ?? 35),
            win_rate_bonus: Number(u.win_rate_bonus ?? DEFAULT_USER.win_rate_bonus ?? 30),
            roll_rate: Number(u.roll_rate ?? DEFAULT_USER.roll_rate ?? 40),
            play_skill_rate: Number(u.play_skill_rate ?? DEFAULT_USER.play_skill_rate ?? 25),
            char_grade: u.char_grade || DEFAULT_USER.char_grade || 'S+'
        },
        // 2. คู่แข่ง 1 คน (เล่นเดี่ยว 1 ต่อ 1 ชื่อไทย/อังกฤษ และรูปโปรไฟล์สุ่มไม่ซ้ำ)
        {
            id: 901,
            username: opponentProfile.username,
            avatar_url: opponentProfile.avatar_url,
            picture: opponentProfile.picture,
            team: 'NONE',
            team_name: '',
            color: 0xf43f5e, // Vibrant Rose Red
            is_bot: true,
            is_awakened: false,
            skill: { code: 'PULL_BACK_5', power: 5 },
            dice_control_rate: 20,
            win_rate_bonus: 15,
            roll_rate: 20,
            play_skill_rate: 12,
            char_grade: 'A+'
        }
    ];

    const orderedPlayers = (typeof window.applyTurnOrderSelection === 'function')
        ? window.applyTurnOrderSelection(players)
        : players;

    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layout);
    }
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(currentLobbyBoard || currentSelectedBoardTheme || 'classic');
    }

    document.body.classList.add('in-match-fullscreen');
    window.game.setupPlayers(orderedPlayers, { roomConfig: practiceCfg });
    if (typeof window.game.onWindowResize === 'function') {
        setTimeout(() => window.game.onWindowResize(), 80);
    }
    if (typeof window.updatePracticeExitButtonVisibility === 'function') {
        window.updatePracticeExitButtonVisibility();
    }
    window.game.logMessage(`🎮 เข้าสู่โหมดทดลองเล่นเดี่ยว (1 ต่อ 1): ${myDisplayName} VS ${opponentProfile.username}!`, 'highlight');
    window.game.logMessage('💡 โหมดทดลองเล่นหน้าหลัก: เล่นฟรีไม่เสียค่าเข้า มีทองในกระดานสร้างเมือง & แลนด์มาร์คได้ครบ!', 'skill');
}

function setupEventListeners() {
    // Roll Dice Button
    const rollBtn = document.getElementById('btn-roll-dice');
    if (rollBtn) {
        rollBtn.onclick = () => {
            if (window.game) {
                if (typeof window.game.handleRollButtonClick === 'function') {
                    window.game.handleRollButtonClick();
                } else {
                    window.game.rollDice();
                }
            }
        };
    }

    // Top Navigation Modal Triggers
    const btnBoards = document.getElementById('btn-open-boards');
    if (btnBoards) btnBoards.onclick = () => openPracticeBoardSelectModal();

    const btnLobby = document.getElementById('btn-open-lobby');
    if (btnLobby) btnLobby.onclick = () => openModal('modal-lobby');

    const btnShop = document.getElementById('btn-open-shop');
    if (btnShop) btnShop.onclick = () => { openModal('modal-shop'); loadShopData(); };

    const btnInventory = document.getElementById('btn-open-inventory');
    if (btnInventory) btnInventory.onclick = () => openInventoryModal();

    const btnLeaderboard = document.getElementById('btn-open-leaderboard');
    if (btnLeaderboard) btnLeaderboard.onclick = () => { openModal('modal-leaderboard'); loadLeaderboardData(); };

    const btnMail = document.getElementById('btn-open-mail');
    if (btnMail) btnMail.onclick = () => { openModal('modal-mail'); loadMailData(); };

    const btnClan = document.getElementById('btn-open-clan');
    if (btnClan) btnClan.onclick = () => openClanModal();

    const btnDaily = document.getElementById('btn-open-daily');
    if (btnDaily) btnDaily.onclick = () => openDailyMatchModal();

    const btnEvent = document.getElementById('btn-open-event');
    if (btnEvent) btnEvent.onclick = () => openEventGachaModal();

    const btnCube = document.getElementById('btn-open-cube');
    if (btnCube) btnCube.onclick = () => openMagicCubeModal();

    const btnInvite = document.getElementById('btn-invite-friend');
    if (btnInvite) btnInvite.onclick = inviteFriendAction;

    const btnSound = document.getElementById('btn-toggle-sound');
    if (btnSound) btnSound.onclick = () => { if (typeof toggleSoundAction === 'function') toggleSoundAction(); };

    const btnLogout = document.getElementById('btn-logout');
    if (btnLogout) btnLogout.onclick = () => { if (typeof logoutAction === 'function') logoutAction(); };

    const btnDelete = document.getElementById('btn-delete-account');
    if (btnDelete) btnDelete.onclick = deleteAccountAction;

    // Close Modals buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.onclick = (e) => {
            const overlay = e.target.closest('.modal-overlay');
            if (overlay) overlay.style.display = 'none';
        };
    });

    // Close modal when click on dark backdrop
    document.querySelectorAll('.modal-overlay').forEach(ov => {
        ov.onclick = (e) => {
            if (e.target === ov) {
            // NEVER close modal-auth on backdrop click!
            if (ov.id === 'modal-auth') return;
            ov.style.display = 'none';
        }
        };
    });
}

// =========================================================================
// 🗺️ BOARD SELECTION MENU CONTROLLER (LAYOUTS & THEMES WITH MINI-PREVIEWS)
// =========================================================================

// ค่าเริ่มต้นหน้าแรก: แสดงกระดานสี่เหลี่ยมดั้งเดิม (Square) ธีมสีทองวิหารพญานาคราช (Ancient Gold)
try {
    if (!localStorage.getItem('snake_home_board_gold_v119')) {
        localStorage.setItem('snake_board_layout', 'square');
        localStorage.setItem('snake_board_theme', 'ancient');
        localStorage.setItem('snake_home_board_gold_v119', 'true');
    }
} catch(e) {}

let currentSelectedBoardLayout = localStorage.getItem('snake_board_layout') || 'square';
let currentSelectedBoardTheme = localStorage.getItem('snake_board_theme') || 'ancient';
window.currentTurnOrderSetting = localStorage.getItem('snake_turn_order_pref') || 'me_first';
window.previewOpponentProfile = null;

window.initBoardSelection = function() {
    if (window.game) {
        currentSelectedBoardLayout = window.game.boardLayout || currentSelectedBoardLayout;
        currentSelectedBoardTheme = window.game.boardTheme || currentSelectedBoardTheme;
    }

    if (!window.previewOpponentProfile && typeof window.pickUniqueOpponentProfiles === 'function') {
        const u = window.DEFAULT_USER || {};
        const myName = u.displayName || u.name || u.username || 'คุณ';
        const [prof] = window.pickUniqueOpponentProfiles(1, [myName]);
        if (prof) window.previewOpponentProfile = prof;
    }

    updateBoardSelectionUIState();
    updateTurnOrderUIState();
    renderAllBoardMiniPreviews();
};

window.openBoardSelectionModal = function() {
    openModal('modal-lobby');
};

window.setTurnOrderPreset = function(preset) {
    window.currentTurnOrderSetting = preset;
    try {
        localStorage.setItem('snake_turn_order_pref', preset);
    } catch(e) {}
    updateTurnOrderUIState();
    updateBoardSelectionUIState();

    if (preset === 'me_first') {
        showToast('🥇 ตั้งค่า: คุณเล่นก่อน (เดินตาแรก 🚀)');
    } else if (preset === 'opp_first') {
        showToast('🥈 ตั้งค่า: ให้คู่แข่งเล่นก่อน (มือ 1 🎲)');
    } else {
        showToast('🎲 ตั้งค่า: สุ่มลำดับการเล่น 50/50 เมื่อเริ่มเกม');
    }
};

window.swapTurnOrder = function() {
    if (window.currentTurnOrderSetting === 'me_first') {
        window.setTurnOrderPreset('opp_first');
    } else if (window.currentTurnOrderSetting === 'opp_first') {
        window.setTurnOrderPreset('me_first');
    } else {
        window.setTurnOrderPreset('me_first');
    }
};

window.updateTurnOrderUIState = function() {
    const setting = window.currentTurnOrderSetting || 'me_first';

    // 1. Highlight preset buttons (for both modal-boards and modal-lobby)
    ['me_first', 'opp_first', 'random'].forEach(k => {
        const id1 = k === 'me_first' ? 'btn-turn-me-first' : (k === 'opp_first' ? 'btn-turn-opp-first' : 'btn-turn-random');
        const id2 = k === 'me_first' ? 'lobby-turn-btn-me' : (k === 'opp_first' ? 'lobby-turn-btn-opp' : 'lobby-turn-btn-rnd');
        [document.getElementById(id1), document.getElementById(id2)].forEach(btn => {
            if (!btn) return;
            if (k === setting) btn.classList.add('active');
            else btn.classList.remove('active');
        });
    });

    // 2. Status badges
    [document.getElementById('turn-order-status-badge'), document.getElementById('lobby-turn-status-badge')].forEach(badge => {
        if (!badge) return;
        if (setting === 'me_first') {
            badge.innerHTML = '🥇 คุณได้สิทธิ์เล่นก่อน (เดินตาแรก 🚀)';
            badge.style.color = '#00e5ff';
            badge.style.borderColor = '#00e5ff';
            badge.style.background = 'rgba(0,229,255,0.15)';
        } else if (setting === 'opp_first') {
            badge.innerHTML = '🥈 คู่แข่งได้สิทธิ์เล่นก่อน (เดินตาแรก 🎲)';
            badge.style.color = '#f59e0b';
            badge.style.borderColor = '#f59e0b';
            badge.style.background = 'rgba(245,158,11,0.15)';
        } else {
            badge.innerHTML = '🎲 สุ่มสิทธิ์การเล่น 50/50 เมื่อเริ่มเกม';
            badge.style.color = '#c084fc';
            badge.style.borderColor = '#c084fc';
            badge.style.background = 'rgba(192,132,252,0.15)';
        }
    });

    // 3. Populate slots
    const u = window.DEFAULT_USER || {};
    const myName = u.displayName || u.name || u.username || 'คุณ (ผู้เล่น)';
    const activeProvider = (u.auth_provider || localStorage.getItem('snake_auth_provider') || '').toLowerCase();
    const myAvatar = (activeProvider === 'line' || u.pictureUrl)
        ? (u.pictureUrl || u.avatar_url || 'avatars/google_avatar.png')
        : (u.picture || u.avatar_url || 'avatars/google_avatar.png');

    if (!window.previewOpponentProfile && typeof window.pickUniqueOpponentProfiles === 'function') {
        const [prof] = window.pickUniqueOpponentProfiles(1, [myName]);
        if (prof) window.previewOpponentProfile = prof;
    }
    const opp = window.previewOpponentProfile || { username: 'แพรวา พารวย', avatar_url: 'avatars/bots/bot_f01.jpg' };
    const oppName = opp.username || 'แพรวา พารวย';
    const oppAvatar = opp.avatar_url || opp.picture || 'avatars/google_avatar.png';

    const pairs = [
        { card1: 'turn-card-slot-1', card2: 'turn-card-slot-2', num1: 'turn-num-slot-1', num2: 'turn-num-slot-2', av1: 'turn-avatar-slot-1', av2: 'turn-avatar-slot-2', cr1: 'turn-crown-slot-1', cr2: 'turn-crown-slot-2', tag1: 'turn-tag-slot-1', tag2: 'turn-tag-slot-2', nm1: 'turn-name-slot-1', nm2: 'turn-name-slot-2' },
        { card1: 'lobby-turn-card-1', card2: 'lobby-turn-card-2', num1: 'lobby-turn-num-1', num2: 'lobby-turn-num-2', av1: 'lobby-turn-avatar-1', av2: 'lobby-turn-avatar-2', cr1: 'lobby-turn-crown-1', cr2: 'lobby-turn-crown-2', tag1: 'lobby-turn-tag-1', tag2: 'lobby-turn-tag-2', nm1: 'lobby-turn-name-1', nm2: 'lobby-turn-name-2' }
    ];

    pairs.forEach(p => {
        const card1 = document.getElementById(p.card1);
        const card2 = document.getElementById(p.card2);
        const num1 = document.getElementById(p.num1);
        const num2 = document.getElementById(p.num2);
        const avatar1 = document.getElementById(p.av1);
        const avatar2 = document.getElementById(p.av2);
        const crown1 = document.getElementById(p.cr1);
        const crown2 = document.getElementById(p.cr2);
        const tag1 = document.getElementById(p.tag1);
        const tag2 = document.getElementById(p.tag2);
        const name1 = document.getElementById(p.nm1);
        const name2 = document.getElementById(p.nm2);

        if (!card1 && !card2) return;

        if (setting === 'opp_first') {
            if (card1) card1.classList.add('is-first');
            if (card2) card2.classList.remove('is-first');
            if (num1) { num1.className = 'turn-number-badge badge-rank-1'; num1.style.background = ''; num1.innerText = '1'; }
            if (num2) { num2.className = 'turn-number-badge badge-rank-2'; num2.style.background = ''; num2.innerText = '2'; }
            if (avatar1) avatar1.src = oppAvatar;
            if (avatar2) avatar2.src = myAvatar;
            if (crown1) crown1.style.display = 'block';
            if (crown2) crown2.style.display = 'none';
            if (tag1) tag1.innerText = '🚀 เดินตาแรก (มือ 1)';
            if (tag2) tag2.innerText = 'เดินตาสอง (มือ 2)';
            if (name1) name1.innerText = `${oppName} (คู่แข่ง)`;
            if (name2) name2.innerText = `${myName} (คุณ)`;
        } else if (setting === 'random') {
            if (card1) card1.classList.remove('is-first');
            if (card2) card2.classList.remove('is-first');
            if (num1) { num1.className = 'turn-number-badge'; num1.style.background = '#8b5cf6'; num1.innerText = '?'; }
            if (num2) { num2.className = 'turn-number-badge'; num2.style.background = '#8b5cf6'; num2.innerText = '?'; }
            if (avatar1) avatar1.src = myAvatar;
            if (avatar2) avatar2.src = oppAvatar;
            if (crown1) crown1.style.display = 'none';
            if (crown2) crown2.style.display = 'none';
            if (tag1) tag1.innerText = '🎲 สุ่มลำดับ (50/50)';
            if (tag2) tag2.innerText = '🎲 สุ่มลำดับ (50/50)';
            if (name1) name1.innerText = `${myName} (คุณ)`;
            if (name2) name2.innerText = `${oppName} (คู่แข่ง)`;
        } else {
            if (card1) card1.classList.add('is-first');
            if (card2) card2.classList.remove('is-first');
            if (num1) { num1.className = 'turn-number-badge badge-rank-1'; num1.style.background = ''; num1.innerText = '1'; }
            if (num2) { num2.className = 'turn-number-badge badge-rank-2'; num2.style.background = ''; num2.innerText = '2'; }
            if (avatar1) avatar1.src = myAvatar;
            if (avatar2) avatar2.src = oppAvatar;
            if (crown1) crown1.style.display = 'block';
            if (crown2) crown2.style.display = 'none';
            if (tag1) tag1.innerText = '🚀 เดินตาแรก (มือ 1)';
            if (tag2) tag2.innerText = 'เดินตาสอง (มือ 2)';
            if (name1) name1.innerText = `${myName} (คุณ)`;
            if (name2) name2.innerText = `${oppName} (คู่แข่ง)`;
        }
    });
};

window.applyTurnOrderSelection = function(playersList) {
    if (!Array.isArray(playersList) || playersList.length < 2) return playersList;

    let setting = window.currentTurnOrderSetting || 'me_first';
    if (setting === 'random') {
        setting = Math.random() < 0.5 ? 'me_first' : 'opp_first';
        const chosenFirstText = setting === 'me_first' ? 'คุณ' : 'คู่แข่ง';
        if (typeof showToast === 'function') {
            showToast(`🎲 ผลการสุ่ม: ${chosenFirstText} ได้เริ่มเดินเป็นคนแรก (มือ 1)!`);
        }
    }

    const humanIdx = playersList.findIndex(p => !p.is_bot);
    const botIdx = playersList.findIndex(p => p.is_bot);

    if (humanIdx === -1 || botIdx === -1) return playersList;

    let ordered = [...playersList];
    if (setting === 'opp_first') {
        // Put bot at index 0, human at index 1
        const botPlayer = ordered[botIdx];
        const humanPlayer = ordered[humanIdx];
        ordered[0] = botPlayer;
        ordered[1] = humanPlayer;
        if (window.game) {
            window.game.logMessage(`🎲 สิทธิ์การเล่น: ${botPlayer.username} ได้เริ่มเดินเป็นคนแรก (มือ 1 🚀)!`, 'highlight');
        }
    } else {
        // Put human at index 0, bot at index 1
        const humanPlayer = ordered[humanIdx];
        const botPlayer = ordered[botIdx];
        ordered[0] = humanPlayer;
        ordered[1] = botPlayer;
        if (window.game) {
            window.game.logMessage(`🎲 สิทธิ์การเล่น: ${humanPlayer.username} ได้เริ่มเดินเป็นคนแรก (มือ 1 🚀)!`, 'highlight');
        }
    }
    return ordered;
};

function updateBoardSelectionUIState() {
    // 1. Highlight layout cards
    ['square', 'spiral', 'hexagon'].forEach(layout => {
        const card = document.getElementById(`layout-card-${layout}`);
        const btn = document.getElementById(`btn-layout-${layout}`);
        const isSel = (currentSelectedBoardLayout === layout);

        if (card) {
            if (isSel) card.classList.add('selected');
            else card.classList.remove('selected');
        }
        if (btn) {
            if (isSel) {
                btn.innerHTML = '🚀 เริ่มเล่นกระดานนี้ทันที!';
                btn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
                btn.style.borderColor = '#34d399';
                btn.style.color = '#fff';
            } else {
                btn.innerHTML = 'เลือก & เริ่มเล่นทันที 🚀';
                btn.style.background = 'rgba(0, 229, 255, 0.12)';
                btn.style.borderColor = 'rgba(0, 229, 255, 0.4)';
                btn.style.color = '#38bdf8';
            }
        }
    });

    // 2. Highlight theme pills
    ['classic', 'ancient', 'lava', 'ice'].forEach(th => {
        const pill = document.getElementById(`pill-theme-${th}`);
        if (pill) {
            if (currentSelectedBoardTheme === th) pill.classList.add('active');
            else pill.classList.remove('active');
        }
    });

    // 3. Update summary text
    const summaryEl = document.getElementById('board-selection-summary-text');
    if (summaryEl) {
        const layoutNames = {
            'square': 'กระดานสี่เหลี่ยมดั้งเดิม',
            'spiral': 'กระดานทรงกลมก้นหอย (Spiral)',
            'hexagon': 'กระดานทรงหกเหลี่ยม (Hexagon)'
        };
        const themeNames = {
            'classic': 'ธีมนีออนไซเบอร์ 3D',
            'ancient': 'ธีมวิหารทองคำพญานาคราช (สีทอง)',
            'lava': 'ธีมภูเขาไฟลาวาเดือด',
            'ice': 'ธีมแดนน้ำแข็งคริสตัล'
        };
        const turnLabels = {
            'me_first': 'คุณเริ่มก่อน 🥇',
            'opp_first': 'คู่แข่งเริ่มก่อน 🥈',
            'random': 'สุ่มลำดับ 🎲'
        };
        const turnText = turnLabels[window.currentTurnOrderSetting || 'me_first'] || 'คุณเริ่มก่อน 🥇';
        summaryEl.innerText = `${layoutNames[currentSelectedBoardLayout] || currentSelectedBoardLayout} • ${themeNames[currentSelectedBoardTheme] || currentSelectedBoardTheme} • ลำดับ: ${turnText}`;
    }

    // 4. Update lobby active layout display badge
    const lobbyLayoutEl = document.getElementById('lobby-active-layout-display');
    if (lobbyLayoutEl) {
        const layoutLabels = {
            'square': '🟩 สี่เหลี่ยมดั้งเดิม (Classic Square)',
            'spiral': '🌀 ทรงกลมก้นหอย (Spiral Galaxy)',
            'hexagon': '⬡ ทรงหกเหลี่ยมรังผึ้ง (Hexagon Hive)'
        };
        lobbyLayoutEl.textContent = layoutLabels[currentSelectedBoardLayout] || layoutLabels.square;
    }
}

window.selectBoardLayoutAction = function(layoutType, startImmediately = false) {
    const wasAlreadySelected = (currentSelectedBoardLayout === layoutType);
    currentSelectedBoardLayout = layoutType;
    try {
        localStorage.setItem('snake_board_layout', layoutType);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layoutType);
    }
    updateBoardSelectionUIState();
    renderAllBoardMiniPreviews();

    // หากกดปุ่มเริ่มเล่น หรือกดซ้ำบนกระดานที่เลือกไว้แล้ว -> เด้งเข้าสู่เกมทันที!
    if (startImmediately || wasAlreadySelected) {
        confirmBoardSelectionAndPlay();
        return;
    }

    showToast(`เลือกรูปแบบ: ${layoutType === 'square' ? 'สี่เหลี่ยม' : (layoutType === 'spiral' ? 'ทรงกลมก้นหอย' : 'ทรงหกเหลี่ยม')} (แตะอีกครั้งเพื่อเริ่มเล่นทันที)`);
};

window.selectBoardThemeAction = function(themeName) {
    currentSelectedBoardTheme = themeName;
    try {
        localStorage.setItem('snake_board_theme', themeName);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(themeName);
    }
    updateBoardSelectionUIState();
    renderAllBoardMiniPreviews();
    showToast(`เปลี่ยนธีมกระดานเป็น: ${themeName}`);
};

window.confirmBoardSelectionAndPlay = function() {
    closeModal('modal-boards');
    document.body.classList.add('in-match-fullscreen');
    showToast('🚀 เข้าสู่เกมด้วยกระดานที่เลือกเรียบร้อย!');
    if (typeof window.startExplicitPracticeMatch === 'function') {
        window.startExplicitPracticeMatch();
    }
};

function renderAllBoardMiniPreviews() {
    const theme = currentSelectedBoardTheme || (window.game ? window.game.boardTheme : 'classic');
    drawMiniBoardCanvas('board-mini-canvas-square', 'square', theme);
    drawMiniBoardCanvas('board-mini-canvas-spiral', 'spiral', theme);
    drawMiniBoardCanvas('board-mini-canvas-hexagon', 'hexagon', theme);
}

function drawMiniBoardCanvas(canvasId, layoutType, themeName = 'classic') {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#090e17';
    ctx.fillRect(0, 0, w, h);

    const themeColors = {
        classic: { border: '#00e5ff', tileA: '#0d1d31', tileB: '#091522', start: '#00e5ff', goal: '#ffd700', ladder: '#38bdf8', snake: '#f43f5e' },
        ancient: { border: '#ffd700', tileA: '#2c1e0b', tileB: '#3e2c13', start: '#38bdf8', goal: '#ffd700', ladder: '#facc15', snake: '#ef4444' },
        lava:    { border: '#ff4d4d', tileA: '#2a0909', tileB: '#3b1212', start: '#38bdf8', goal: '#ffd700', ladder: '#f97316', snake: '#dc2626' },
        ice:     { border: '#67e8f9', tileA: '#08253a', tileB: '#0f3856', start: '#38bdf8', goal: '#ffd700', ladder: '#a5f3fc', snake: '#e11d48' }
    };
    const pal = themeColors[themeName] || themeColors.classic;

    if (layoutType === 'square') {
        const pad = 14;
        const gridW = w - pad * 2;
        const gridH = h - pad * 2;
        const cellW = gridW / 10;
        const cellH = gridH / 10;

        ctx.strokeStyle = pal.border;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(pad, pad, gridW, gridH);

        for (let row = 0; row < 10; row++) {
            for (let col = 0; col < 10; col++) {
                ctx.fillStyle = ((row + col) % 2 === 0) ? pal.tileA : pal.tileB;
                ctx.fillRect(pad + col * cellW + 1, pad + (9 - row) * cellH + 1, cellW - 2, cellH - 2);
            }
        }

        ctx.strokeStyle = 'rgba(0, 229, 255, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        for (let i = 1; i <= 100; i++) {
            const row = Math.floor((i - 1) / 10);
            const colInRow = (i - 1) % 10;
            const col = (row % 2 === 0) ? colInRow : (9 - colInRow);
            const cx = pad + col * cellW + cellW / 2;
            const cy = pad + (9 - row) * cellH + cellH / 2;
            if (i === 1) ctx.moveTo(cx, cy);
            else ctx.lineTo(cx, cy);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        // Sample Ladders
        drawCanvasLadder(ctx, pad + 3 * cellW + cellW/2, pad + 9 * cellH + cellH/2, pad + 6 * cellW + cellW/2, pad + 7 * cellH + cellH/2, pal.ladder);
        drawCanvasLadder(ctx, pad + 8 * cellW + cellW/2, pad + 7 * cellH + cellH/2, pad + 7 * cellW + cellW/2, pad + 1 * cellH + cellH/2, pal.ladder);

        // Sample Snakes
        drawCanvasSnake(ctx, pad + 2 * cellW + cellW/2, pad + 4 * cellH + cellH/2, pad + 3 * cellW + cellW/2, pad + 8 * cellH + cellH/2, pal.snake);
        drawCanvasSnake(ctx, pad + 9 * cellW + cellW/2, pad + 0 * cellH + cellH/2, pad + 8 * cellW + cellW/2, pad + 2 * cellH + cellH/2, pal.snake);

        // Start (1) & Goal (100)
        drawStartGoalBadges(ctx, pad + cellW/2, pad + 9 * cellH + cellH/2, pad + cellW/2, pad + cellH/2);

    } else if (layoutType === 'spiral') {
        const cx = w / 2;
        const cy = h / 2;
        const maxR = Math.min(w, h) / 2 - 14;

        ctx.strokeStyle = pal.border;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, maxR + 4, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(168, 85, 247, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        const spiralPts = [];
        for (let i = 1; i <= 100; i++) {
            const u = (i - 1) / 99;
            const angle = u * (3.8 * Math.PI * 2) - Math.PI / 2;
            const r = maxR * (1 - 0.92 * u);
            const px = cx + r * Math.cos(angle);
            const py = cy + r * Math.sin(angle);
            spiralPts.push({ x: px, y: py });
            if (i === 1) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        spiralPts.forEach((pt, idx) => {
            if (idx % 2 === 0 || idx === 0 || idx === 99) {
                ctx.fillStyle = (idx % 4 === 0) ? pal.tileA : pal.tileB;
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, Math.max(3, 7 - 4 * (idx / 99)), 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.25)';
                ctx.lineWidth = 0.8;
                ctx.stroke();
            }
        });

        // Sample radial shortcut ladders
        if (spiralPts[25] && spiralPts[55]) {
            drawCanvasLadder(ctx, spiralPts[25].x, spiralPts[25].y, spiralPts[55].x, spiralPts[55].y, pal.ladder);
        }
        if (spiralPts[10] && spiralPts[38]) {
            drawCanvasLadder(ctx, spiralPts[10].x, spiralPts[10].y, spiralPts[38].x, spiralPts[38].y, pal.ladder);
        }

        // Sample Snakes
        if (spiralPts[70] && spiralPts[40]) {
            drawCanvasSnake(ctx, spiralPts[70].x, spiralPts[70].y, spiralPts[40].x, spiralPts[40].y, pal.snake);
        }

        // Start & Goal
        drawStartGoalBadges(ctx, spiralPts[0].x, spiralPts[0].y, cx, cy);

    } else if (layoutType === 'hexagon') {
        const padX = 16;
        const padY = 14;
        const hexR = (w - padX * 2) / 19;
        const stepX = hexR * 1.72;
        const stepY = hexR * 1.5;

        ctx.strokeStyle = pal.border;
        ctx.lineWidth = 1.5;
        drawCanvasPolygon(ctx, w / 2, h / 2, Math.min(w, h) / 2 - 8, 6, Math.PI / 6);
        ctx.stroke();

        const hexPts = [];
        for (let row = 0; row < 10; row++) {
            for (let col = 0; col < 10; col++) {
                const stagger = (row % 2 === 1) ? (stepX * 0.5) : 0;
                const px = padX + col * (stepX * 0.95) + stagger + 8;
                const py = padY + (9 - row) * (stepY * 0.95) + 8;
                hexPts.push({ x: px, y: py, row, col });

                ctx.fillStyle = ((row + col) % 2 === 0) ? pal.tileA : pal.tileB;
                drawCanvasPolygon(ctx, px, py, hexR * 0.9, 6, Math.PI / 6);
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.2)';
                ctx.lineWidth = 0.8;
                ctx.stroke();
            }
        }

        ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        for (let i = 1; i <= 100; i++) {
            const row = Math.floor((i - 1) / 10);
            const colInRow = (i - 1) % 10;
            const col = (row % 2 === 0) ? colInRow : (9 - colInRow);
            const pt = hexPts.find(p => p.row === row && p.col === col);
            if (pt) {
                if (i === 1) ctx.moveTo(pt.x, pt.y);
                else ctx.lineTo(pt.x, pt.y);
            }
        }
        ctx.stroke();
        ctx.setLineDash([]);

        const p4 = hexPts[3];
        const p14 = hexPts[16];
        if (p4 && p14) drawCanvasLadder(ctx, p4.x, p4.y, p14.x, p14.y, pal.ladder);

        const p80 = hexPts[80];
        const p45 = hexPts[45];
        if (p80 && p45) drawCanvasSnake(ctx, p80.x, p80.y, p45.x, p45.y, pal.snake);

        const pStart = hexPts[0];
        const pGoal = hexPts[hexPts.length - 1];
        if (pStart && pGoal) {
            drawStartGoalBadges(ctx, pStart.x, pStart.y, pGoal.x, pGoal.y);
        }
    }
}

function drawCanvasLadder(ctx, x1, y1, x2, y2, color) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy);
    if (len < 4) return;
    const nx = -dy / len;
    const ny = dx / len;
    const w = 4;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.8;
    ctx.setLineDash([]);

    // Rails
    ctx.beginPath();
    ctx.moveTo(x1 - nx * w, y1 - ny * w);
    ctx.lineTo(x2 - nx * w, y2 - ny * w);
    ctx.moveTo(x1 + nx * w, y1 + ny * w);
    ctx.lineTo(x2 + nx * w, y2 + ny * w);
    ctx.stroke();

    // Rungs
    const rungs = Math.floor(len / 10);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.2;
    for (let i = 1; i < rungs; i++) {
        const t = i / rungs;
        const rx = x1 + dx * t;
        const ry = y1 + dy * t;
        ctx.beginPath();
        ctx.moveTo(rx - nx * w, ry - ny * w);
        ctx.lineTo(rx + nx * w, ry + ny * w);
        ctx.stroke();
    }
    ctx.restore();
}

function drawCanvasSnake(ctx, x1, y1, x2, y2, color) {
    const mx = (x1 + x2) / 2 + 15;
    const my = (y1 + y2) / 2 - 10;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.4;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.quadraticCurveTo(mx, my, x2, y2);
    ctx.stroke();

    ctx.fillStyle = '#ff0055';
    ctx.beginPath();
    ctx.arc(x1, y1, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function drawStartGoalBadges(ctx, sx, sy, gx, gy) {
    ctx.save();
    // Start Badge (Green)
    ctx.fillStyle = '#059669';
    ctx.beginPath();
    ctx.arc(sx, sy, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#34d399';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 8px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('1', sx, sy);

    // Goal Badge (Gold)
    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(gx, gy, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#000';
    ctx.font = 'bold 8px sans-serif';
    ctx.fillText('👑', gx, gy);
    ctx.restore();
}

function drawCanvasPolygon(ctx, x, y, radius, sides, rot = 0) {
    ctx.beginPath();
    for (let i = 0; i < sides; i++) {
        const a = rot + (i * Math.PI * 2) / sides;
        const px = x + radius * Math.cos(a);
        const py = y + radius * Math.sin(a);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    }
    ctx.closePath();
}

// --- Friend Invite System (Max 2/day, 1000 Dia & 100,000 Gold) ---
window.inviteFriendAction = function() {
    showInGameConfirm(
        'ต้องการส่งคำเชิญเพื่อนเข้าเล่นเกมบันไดงู 3D ใช่หรือไม่?\n\n✨ รับ 1,000 เพชร และ 100,000 ทองทันที\n(จำกัด 2 คนต่อวัน)',
        async () => {
            try {
                const res = await apiClient.inviteFriend();
                showInGameAlert(res.message || 'ส่งคำเชิญเพื่อนสำเร็จ!', 'เชิญเพื่อนสำเร็จ', '🎉');
                if (res.status === 'success') {
                    if (res.data) {
                        Object.assign(DEFAULT_USER, res.data);
                        updateUserBar(DEFAULT_USER);
                    } else {
                        const p = await apiClient.getProfile();
                        if (p && p.data) {
                            Object.assign(DEFAULT_USER, p.data);
                            updateUserBar(DEFAULT_USER);
                        }
                    }
                }
            } catch (e) {
                await window.syncUserProgress({ diamond_delta: 1000, gold_delta: 100000 });
                showInGameAlert('เชิญเพื่อนสำเร็จ! ได้รับ 1,000 เพชร และ 100,000 ทอง เข้ากระเป๋าเรียบร้อย!', 'เชิญเพื่อนสำเร็จ', '🎁');
            }
        },
        'เชิญเพื่อนรับรางวัลฟรี',
        '👥'
    );
};

// --- Delete Account ---
window.deleteAccountAction = function() {
    showInGameConfirm(
        '⚠️ คำเตือน: คุณต้องการลบบัญชีและข้อมูลทั้งหมดอย่างถาวรใช่หรือไม่?\n\nข้อมูลการ์ด เพชร ทอง และอันดับ จะถูกลบทันที!',
        async () => {
            try {
                const res = await apiClient.deleteAccount();
                showInGameAlert(res.message || 'ลบบัญชีเรียบร้อยแล้ว', 'ลบบัญชีสำเร็จ', '🗑️');
            } catch (e) {
                showInGameAlert('ลบบัญชีตัวอย่างเรียบร้อยแล้ว', 'ลบบัญชีสำเร็จ', '🗑️');
            }
            localStorage.removeItem('snake_active_session');
            setTimeout(() => location.reload(), 1500);
        },
        'ยืนยันการลบบัญชีผู้เล่น',
        '⚠️'
    );
};

// --- Matchmaking Lobby & 5-Second Turn Selection ---
let matchCheckInterval = null;
let turnSelectionTimer = null;
let mmSearchSeconds = 0;
let mmSearchTimerInterval = null;
let isFastMatchArmed = false;
let currentWaitingRoomId = null;

window.startQuickMatch = async function(tier = '2M', mode = '2P', boardTheme = 'classic') {
    const econCfg = typeof window.getActiveRoomEconomyConfig === 'function'
        ? window.getActiveRoomEconomyConfig(tier)
        : { entry_fee_gold: tier === '2M' ? 2000 : (tier === '5M' ? 5000 : 10000), start_match_gold: tier === '2M' ? 2000000 : (tier === '5M' ? 5000000 : 10000000) };
    const fee = Number(econCfg.entry_fee_gold ?? 2000);

    if ((Number(DEFAULT_USER.gold) || 0) < fee) {
        showInGameAlert(
            `ทองในกระเป๋าของคุณไม่พอจ่ายค่าผ่านทางเข้าห้อง ${tier}\nต้องการ ${fee.toLocaleString()} ทอง (ปัจจุบันมี ${(Number(DEFAULT_USER.gold) || 0).toLocaleString()} ทอง)`,
            '🪙 ทองไม่พอจ่ายค่าผ่านทาง',
            '⚠️'
        );
        return;
    }

    window.isPracticeMatch = false;
    window.currentActiveRoomTier = tier;
    window.currentActiveGameMode = mode;
    currentLobbyBoard = boardTheme || currentLobbyBoard || 'classic';

    // หยุดและล้างเกมเดิมทันทีก่อนเริ่มค้นหาคู่แข่งห้องใหม่ (ห้ามเล่นเกมซ้อนด้านหลัง)
    if (window.game) {
        window.game.clearTurnTimers();
        window.game.isMatchActive = false;
        window.game.isGameOver = false;
        window.game.isRolling = false;
        window.game.isAutoMode = false;
        window.game.closeCityActionPrompt(null);
        window.game.clearAllCities3D();
    }
    try {
        localStorage.removeItem('snake_active_session');
        if (window.DEFAULT_USER?.id) {
            localStorage.removeItem(`snake_active_session_user_${window.DEFAULT_USER.id}`);
        }
    } catch (e) {}

    // Apply board layout and theme immediately to 3D board
    const layout = localStorage.getItem('snake_board_layout') || 'square';
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layout);
    }
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(currentLobbyBoard);
    }
    if (window.game && typeof window.game.setupIdlePreview === 'function') {
        window.game.setupIdlePreview(DEFAULT_USER);
    }

    // Close lobby modal immediately so 3D board is shown
    closeModal('modal-lobby');
    DEFAULT_USER.gold = Math.max(0, (Number(DEFAULT_USER.gold) || 0) - fee);
    updateUserBar(DEFAULT_USER);
    showToast(`เข้าสู่ห้อง ${tier} (${mode}) หักค่าผ่านทาง ${fee.toLocaleString()} ทอง • เตรียมความพร้อมเข้าสู่สนามแข่ง!`);

    try {
        const res = await apiClient.quickMatch(tier, mode, currentLobbyBoard);
        if (res && res.status === 'error') {
            showInGameAlert(res.message || 'ไม่สามารถเข้าห้องแข่งขันได้', '⚠️ แจ้งเตือนห้องแข่งขัน', '⚠️');
            openModal('modal-lobby');
            return;
        }
        if (res && res.status === 'success' && res.room_id) {
            window.currentRoomId = res.room_id;
            if (res.room_config) {
                window.activeRoomConfigFromServer = res.room_config;
            }
            apiClient.getProfile().then(p => { if (p && p.data) updateUserBar(p.data); }).catch(() => {});
            startWaitingForMatch(res.room_id, tier, mode, currentLobbyBoard);
            return;
        }
    } catch (e) {
        console.warn('Matchmaking API:', e);
    }

    // Fallback / local match start
    window.currentRoomId = window.currentRoomId || Date.now();
    window.activeRoomConfigFromServer = econCfg;
    startWaitingForMatch(window.currentRoomId, tier, mode, currentLobbyBoard);
};

window.joinRoomCode = async function() {
    const code = document.getElementById('input-room-code').value.trim();
    if (!code) return showToast('กรุณากรอกรหัสห้อง');
    try {
        const res = await apiClient.joinRoomByCode(code);
        showToast(res.message);
        if (res.status === 'success' && res.room_id) {
            window.isPracticeMatch = false;
            window.currentRoomId = res.room_id;
            const rTier = res.room_config?.room_tier || '2M';
            const rMode = res.room_config?.game_mode || '2P';
            const rBoard = res.room_config?.board_theme || 'classic';
            if (res.room_config) {
                window.activeRoomConfigFromServer = res.room_config;
                window.currentActiveRoomTier = rTier;
                window.currentActiveGameMode = rMode;
            }
            apiClient.getProfile().then(p => { if (p && p.data) updateUserBar(p.data); }).catch(() => {});
            closeModal('modal-lobby');
            startWaitingForMatch(res.room_id, rTier, rMode, rBoard);
            return;
        }
    } catch (e) {
        window.isPracticeMatch = false;
        showToast(`เข้าร่วมห้อง ${code} สำเร็จ!`);
        closeModal('modal-lobby');
        startWaitingForMatch(1, '2M', '2P', 'classic');
    }
};

function showMatchmakingWaitingScreen(tier, mode, boardTheme, maxPlayers) {
    const overlay = document.getElementById('matchmaking-waiting-overlay');
    if (!overlay) return;

    // ตั้งค่าสถานะเพื่อซ่อน HUD การแข่งและแผงทอยเต๋าด้านล่างอย่างเด็ดขาด
    document.body.classList.add('in-matchmaking');
    document.body.classList.remove('in-match-fullscreen');

    // หยุดเกมบนกระดานด้านหลังโดยเด็ดขาดขณะกำลังค้นหาคู่แข่ง (ห้ามเล่นเกมซ้อนด้านหลัง!)
    if (window.game) {
        window.game.clearTurnTimers();
        window.game.isMatchActive = false;
        window.game.isGameOver = false;
        window.game.isRolling = false;
        window.game.isAutoMode = false;
        window.game.closeCityActionPrompt(null);
        window.game.clearAllCities3D();
        if (typeof window.game.setBoardTheme === 'function') {
            window.game.setBoardTheme(boardTheme || currentLobbyBoard || 'classic');
        }
        if (typeof window.game.setupIdlePreview === 'function') {
            window.game.setupIdlePreview(DEFAULT_USER);
        }
    }

    // ซ่อน Match Wealth HUD และแผงล่างระหว่างค้นหา
    const hud = document.getElementById('match-wealth-hud');
    if (hud) {
        hud.style.display = 'none';
        hud.innerHTML = '';
    }
    const bottomHud = document.querySelector('.bottom-hud');
    if (bottomHud) bottomHud.style.display = 'none';

    // ล้าง Active Session เก่าออกทันที เพื่อไม่ให้ระบบดึงเซฟเกมเดิมมารันแข่งซ้ำซ้อนด้านหลัง
    try {
        localStorage.removeItem('snake_active_session');
        if (window.DEFAULT_USER?.id) {
            localStorage.removeItem(`snake_active_session_user_${window.DEFAULT_USER.id}`);
        }
    } catch (e) {}

    const tagTier = document.getElementById('mm-tag-tier');
    const tagBoard = document.getElementById('mm-tag-board');
    const tagMode = document.getElementById('mm-tag-mode');

    const cfg = (typeof ROOM_TIER_CONFIG !== 'undefined' && ROOM_TIER_CONFIG[tier]) ? ROOM_TIER_CONFIG[tier] : { title: `ห้อง ${tier}` };
    const bCatalog = (typeof BOARD_CATALOG !== 'undefined' && BOARD_CATALOG[boardTheme]) ? BOARD_CATALOG[boardTheme] : { name: boardTheme };
    const modeLabel = (mode === '2P') ? '1 ต่อ 1' : ((mode === '3P') ? 'เดี่ยว 3' : ((mode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));

    if (tagTier) tagTier.innerText = `🏆 ${cfg.title}`;
    if (tagBoard) tagBoard.innerText = `🗺️ ${bCatalog.name}`;
    if (tagMode) tagMode.innerText = `👥 ${modeLabel}`;

    // Initial slot rendering with Host
    let myName = DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username || 'ผู้เล่น';
    if (myName === 'เขียนศักดิ์' || myName === 'Google Player') {
        myName = 'ผู้เล่น';
    }
    const myAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl(DEFAULT_USER) : (DEFAULT_USER.avatar_url || DEFAULT_USER.pictureUrl || DEFAULT_USER.picture || 'avatars/avatar_01.svg');

    window.currentWaitingPlayers = [
        {
            user_id: DEFAULT_USER.id || 1,
            username: `${myName} (คุณ)`,
            avatar_url: myAvatar,
            picture: myAvatar,
            team: mode === 'TEAM' ? 'A' : 'NONE',
            is_bot: false,
            is_ready: true,
            is_me: true
        }
    ];

    // เตรียมรายชื่อและโปรไฟล์คู่แข่งแบบสุ่มล่วงหน้า
    window.availableMatchmakingOpponents = window.pickUniqueOpponentProfiles(maxPlayers, [myName]);

    updateMatchmakingWaitingSlots(window.currentWaitingPlayers, maxPlayers);

    overlay.style.display = 'flex';
}

function updateMatchmakingWaitingSlots(players = [], maxPlayers = 2) {
    const container = document.getElementById('mm-slots-container');
    if (!container) return;
    container.innerHTML = '';

    for (let i = 0; i < maxPlayers; i++) {
        const p = players[i];
        const slotEl = document.createElement('div');
        if (p) {
            slotEl.className = 'mm-player-slot slot-filled';
            let rawAvatar = p.avatar_url || p.picture;
            if (i > 0 || p.is_bot || !rawAvatar || rawAvatar.includes('google_avatar')) {
                rawAvatar = window.getOpponentAvatarByName(p.username || p.bot_name, i);
                p.avatar_url = rawAvatar;
                p.picture = rawAvatar;
            }
            const safeName = String(p.username || `Player ${i+1}`).replace(/'/g, '');
            slotEl.innerHTML = `
                <div class="mm-slot-avatar-wrap">
                    <img src="${rawAvatar}" class="mm-slot-avatar" alt="${safeName}" onerror="this.onerror=null;this.src=window.getOpponentAvatarByName('${safeName}', ${i});">
                    <span class="mm-slot-badge ready">✓</span>
                </div>
                <div class="mm-slot-name" title="${safeName}">${p.username || `Player ${i+1}`}</div>
                <div class="mm-slot-status status-ready">🟢 พร้อมเข้าแข่ง</div>
            `;
        } else {
            slotEl.className = 'mm-player-slot slot-waiting';
            slotEl.innerHTML = `
                <div class="mm-slot-avatar-wrap">
                    <div class="mm-slot-empty-icon">⏳</div>
                    <div class="mm-slot-radar-ring"></div>
                </div>
                <div class="mm-slot-name">ค้นหาคู่แข่ง #${i+1}</div>
                <div class="mm-slot-status status-searching">กำลังค้นหา...</div>
            `;
        }
        container.appendChild(slotEl);
    }
}

/**
 * ดึงคู่แข่งเข้ามาในห้องทีละ 1 คนแบบเรียลไทม์ พร้อมเอฟเฟกต์และอัปเดตช่องผู้เล่นทันที
 */
function addMatchmakingOpponentStep(maxPlayers) {
    if (!window.currentWaitingPlayers) window.currentWaitingPlayers = [];
    if (window.currentWaitingPlayers.length >= maxPlayers) return;

    const idx = window.currentWaitingPlayers.length;
    const opp = (window.availableMatchmakingOpponents && window.availableMatchmakingOpponents.length > 0)
        ? window.availableMatchmakingOpponents.shift()
        : window.pickUniqueOpponentProfiles(1, window.currentWaitingPlayers.map(p => p.username))[0];

    const isTeam = (window.currentActiveGameMode === 'TEAM');
    const newPlayer = {
        user_id: 900 + idx,
        bot_name: opp.username,
        username: opp.username,
        avatar_url: opp.avatar_url,
        picture: opp.picture,
        team: isTeam ? ((idx + 1) % 2 === 0 ? 'A' : 'B') : 'NONE',
        is_bot: true,
        is_awakened: false,
        is_ready: true
    };

    window.currentWaitingPlayers.push(newPlayer);
    updateMatchmakingWaitingSlots(window.currentWaitingPlayers, maxPlayers);
    showToast(`⚡ ${opp.username} เข้าสู่ห้องแข่งขันแล้ว!`);
    if (window.soundEngine && typeof window.soundEngine.playEffect === 'function') {
        try { window.soundEngine.playEffect('CLICK'); } catch(e){}
    }

    // เมื่อคนครบตามจำนวนห้องแข่งขันแล้ว -> ปิดหน้าค้นหาแล้วเปิดหน้าเลือกการ์ดสุ่มลำดับทอยเต๋าทันที!
    if (window.currentWaitingPlayers.length >= maxPlayers) {
        if (mmSearchTimerInterval) { clearInterval(mmSearchTimerInterval); mmSearchTimerInterval = null; }
        if (matchCheckInterval) { clearInterval(matchCheckInterval); matchCheckInterval = null; }
        setTimeout(() => {
            closeMatchmakingWaitingScreen();
            openTurnCardPicker(currentWaitingRoomId || Date.now(), maxPlayers, window.currentWaitingPlayers);
        }, 500);
    }
}

function closeMatchmakingWaitingScreen() {
    if (matchCheckInterval) { clearInterval(matchCheckInterval); matchCheckInterval = null; }
    if (mmSearchTimerInterval) { clearInterval(mmSearchTimerInterval); mmSearchTimerInterval = null; }
    const overlay = document.getElementById('matchmaking-waiting-overlay');
    if (overlay) overlay.style.display = 'none';
}

window.cancelMatchmakingAction = function() {
    closeMatchmakingWaitingScreen();
    document.body.classList.remove('in-matchmaking');
    document.body.classList.remove('in-match-fullscreen');

    const bottomHud = document.querySelector('.bottom-hud');
    if (bottomHud) bottomHud.style.display = 'flex';
    const hud = document.getElementById('match-wealth-hud');
    if (hud) {
        hud.style.display = 'none';
        hud.innerHTML = '';
    }

    if (window.game) {
        window.game.clearTurnTimers();
        window.game.isMatchActive = false;
        window.game.isGameOver = false;
        window.game.isRolling = false;
        window.game.isAutoMode = false;
        if (typeof window.game.setupIdlePreview === 'function') {
            window.game.setupIdlePreview(DEFAULT_USER);
        }
    }

    showToast('ยกเลิกการค้นหาคู่แข่งแล้ว');
    openModal('modal-lobby');
};

window.triggerFastMatchAction = async function() {
    isFastMatchArmed = true;
    const btnFast = document.getElementById('btn-mm-fast-text');
    if (btnFast) btnFast.innerText = '⚡ เปิดโหมดจับคู่ด่วนแล้ว!';

    if (mmSearchSeconds >= 15) {
        window.triggerInstantBotFillAction();
        return;
    }

    try {
        if (apiClient && currentWaitingRoomId) {
            await apiClient.triggerFastMatch(currentWaitingRoomId);
        }
    } catch(e) {}
    showToast('⚡ เปิดระบบจับคู่ด่วน: ระบบจะดึงคู่แข่งเข้าห้องภายใน 15 วินาที!');
};

window.triggerInstantBotFillAction = async function() {
    showToast('⚡ กำลังค้นหาคู่แข่งแบบด่วน...');
    try {
        if (apiClient && currentWaitingRoomId) {
            await apiClient.triggerFastMatch(currentWaitingRoomId);
        }
    } catch(e) {}

    // Fill slots locally and proceed
    const mode = window.currentActiveGameMode || '2P';
    const maxPlayers = mode === '2P' ? 2 : (mode === '3P' ? 3 : 4);
    const curCount = window.currentWaitingPlayers ? window.currentWaitingPlayers.length : 1;
    const oppCount = maxPlayers - curCount;
    const oppProfiles = window.pickUniqueOpponentProfiles(oppCount, (window.currentWaitingPlayers || []).map(p => p.username));

    const filledPlayers = [...(window.currentWaitingPlayers || [
        {
            user_id: DEFAULT_USER.id || 1,
            username: DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username,
            avatar_url: DEFAULT_USER.avatar_url || DEFAULT_USER.picture || DEFAULT_USER.pictureUrl,
            team: mode === 'TEAM' ? 'A' : 'NONE',
            is_bot: false,
            is_awakened: true
        }
    ])];

    oppProfiles.forEach((op, idx) => {
        filledPlayers.push({
            user_id: 901 + idx,
            bot_name: op.username,
            username: op.username,
            avatar_url: op.avatar_url,
            team: mode === 'TEAM' ? ((filledPlayers.length + 1) % 2 === 0 ? 'A' : 'B') : 'NONE',
            is_bot: true,
            is_awakened: false
        });
    });

    window.currentWaitingPlayers = filledPlayers;
    updateMatchmakingWaitingSlots(filledPlayers, maxPlayers);
    setTimeout(() => {
        closeMatchmakingWaitingScreen();
        openTurnCardPicker(currentWaitingRoomId || Date.now(), maxPlayers, filledPlayers);
    }, 400);
};

function startWaitingForMatch(roomId, tier = null, mode = null, boardTheme = null) {
    const validRoomId = roomId || ('room_' + Date.now());
    currentWaitingRoomId = validRoomId;
    window.currentRoomId = validRoomId;
    window.isPracticeMatch = false;
    const activeTier = tier || window.currentActiveRoomTier || currentLobbyTier || '2M';
    const activeMode = mode || window.currentActiveGameMode || currentLobbyMode || '2P';
    const activeBoard = boardTheme || currentLobbyBoard || 'classic';
    window.currentActiveRoomTier = activeTier;
    window.currentActiveGameMode = activeMode;
    const maxPlayers = activeMode === '2P' ? 2 : (activeMode === '3P' ? 3 : 4);

    if (window.game) window.game.logMessage('⏳ กำลังค้นหาผู้เล่นเข้าสู่ห้องแข่งขัน...', 'highlight');

    // Show Visual Waiting Screen over 3D board
    showMatchmakingWaitingScreen(activeTier, activeMode, activeBoard, maxPlayers);

    // Reset search timer
    mmSearchSeconds = 0;
    isFastMatchArmed = false;
    if (mmSearchTimerInterval) clearInterval(mmSearchTimerInterval);

    const timerText = document.getElementById('mm-timer-seconds');
    const progressFill = document.getElementById('mm-timer-progress-fill');
    const btnFast = document.getElementById('btn-mm-fast-text');

    mmSearchTimerInterval = setInterval(() => {
        mmSearchSeconds++;
        const mins = String(Math.floor(mmSearchSeconds / 60)).padStart(2, '0');
        const secs = String(mmSearchSeconds % 60).padStart(2, '0');
        if (timerText) timerText.innerText = `${mins}:${secs}`;
        if (progressFill) progressFill.style.width = `${Math.min(100, (mmSearchSeconds / 60) * 100)}%`;

        if (isFastMatchArmed && btnFast && mmSearchSeconds <= 15) {
            btnFast.innerText = `⚡ ดึงคู่แข่งใน ${15 - mmSearchSeconds} วิ...`;
        }

        // 1. ระบบจับคู่ด่วน 15 วินาที
        if (isFastMatchArmed && mmSearchSeconds >= 15) {
            clearInterval(mmSearchTimerInterval);
            window.triggerInstantBotFillAction();
            return;
        }

        // 2. ทยอยเรียกผู้เล่น/คู่แข่งเข้ามาทีละคนเมื่อเลย 50 วินาที:
        // ตัวอย่างเช่น หากค้าง 3 คน:
        // - วินาทีที่ 50: ดึงมา 1 คน (เหลือขาด 2)
        // - วินาทีที่ 53: ดึงมาอีกคน (เหลือขาด 1)
        // - วินาทีที่ 58: ดึงมาอีกคนจนครบ!
        // หากค้าง 1 คน: วินาทีที่ 52-58 ดึงมาเล่นแทนทันที!
        const curCount = window.currentWaitingPlayers ? window.currentWaitingPlayers.length : 1;
        const missing = maxPlayers - curCount;

        if (missing > 0 && mmSearchSeconds >= 50) {
            // กรณีห้อง 4 คน ที่เริ่มต้นขาด 3 คน:
            // วินาทีที่ 50: ดึงมา 1 คน (เหลือขาด 2)
            // วินาทีที่ 53: ดึงมาอีกคน (เหลือขาด 1)
            // วินาทีที่ 58: ดึงมาอีกคนจนครบ 4 คน
            if (maxPlayers === 4 && curCount === 1) {
                if (mmSearchSeconds === 50) {
                    addMatchmakingOpponentStep(maxPlayers);
                }
            } else if (maxPlayers === 4 && curCount === 2) {
                if (mmSearchSeconds === 53) {
                    addMatchmakingOpponentStep(maxPlayers);
                }
            } else if (missing === 1) {
                // หากค้าง 1 คน: วินาทีที่ 52-58 ดึงมาเล่นแทนทันที
                // (ถ้าเป็นห้อง 4 คนที่รอคนสุดท้าย ให้เข้าที่วินาทีที่ 58)
                if (maxPlayers === 4 && curCount === 3) {
                    if (mmSearchSeconds >= 58) {
                        addMatchmakingOpponentStep(maxPlayers);
                    }
                } else if (mmSearchSeconds >= 52) {
                    addMatchmakingOpponentStep(maxPlayers);
                }
            } else if (missing === 2) {
                // หากค้าง 2 คน (เช่น ห้อง 3 คน หรือห้อง 4 คนที่มี 2 คน):
                if (curCount === maxPlayers - 2 && mmSearchSeconds === 52) {
                    addMatchmakingOpponentStep(maxPlayers);
                } else if (mmSearchSeconds >= 58) {
                    addMatchmakingOpponentStep(maxPlayers);
                }
            }

            // ป้องกันหลุดลอย: เมื่อถึงวินาทีที่ 58 แล้วยังไม่เต็มห้อง ให้ดึงจนครบคนทันที
            if (mmSearchSeconds >= 58 && (window.currentWaitingPlayers?.length < maxPlayers)) {
                addMatchmakingOpponentStep(maxPlayers);
            }
        }

        // 3. ป้องกันหลุดลอย เกิน 60 วิ ให้เติมจนเต็มทันที
        if (mmSearchSeconds >= 60) {
            clearInterval(mmSearchTimerInterval);
            window.triggerInstantBotFillAction();
            return;
        }
    }, 1000);

    // Poll room status every 1.5 seconds
    if (matchCheckInterval) clearInterval(matchCheckInterval);
    matchCheckInterval = setInterval(async () => {
        try {
            const extra = (isFastMatchArmed ? 'fast_match=1' : '');
            const statusRes = await apiClient.checkRoomStatus(roomId, extra);
            if (statusRes && statusRes.status === 'success') {
                const room = statusRes.room;
                const players = statusRes.players;
                if (statusRes.room_config) {
                    window.activeRoomConfigFromServer = statusRes.room_config;
                }

                if (players && players.length >= (window.currentWaitingPlayers ? window.currentWaitingPlayers.length : 1)) {
                    players.forEach((p, idx) => {
                        if (idx > 0 || p.is_bot || !p.avatar_url || p.avatar_url.includes('google_avatar')) {
                            p.avatar_url = window.getOpponentAvatarByName(p.username || p.bot_name, idx);
                            p.picture = p.avatar_url;
                        }
                    });
                    window.currentWaitingPlayers = players;
                    updateMatchmakingWaitingSlots(players, maxPlayers);
                }

                if (room.status === 'SELECTING_TURN' || (window.currentWaitingPlayers && window.currentWaitingPlayers.length >= maxPlayers)) {
                    closeMatchmakingWaitingScreen();
                    openTurnCardPicker(roomId, room.max_players || maxPlayers, window.currentWaitingPlayers, statusRes.room_config || null);
                } else if (room.status === 'PLAYING') {
                    closeMatchmakingWaitingScreen();
                    startGameWithPlayers(window.currentWaitingPlayers, statusRes.room_config || null, roomId);
                }
            }
        } catch (e) {
            // Offline / local mock fallback: handled by timer and action buttons
        }
    }, 1500);
}

function openTurnCardPicker(roomId, maxPlayers = 2, preloadedPlayers = null, preloadedRoomCfg = null) {
    document.body.classList.add('in-matchmaking');
    const overlay = document.getElementById('turn-picker-overlay');
    const timerEl = document.getElementById('countdown-seconds');
    const container = document.getElementById('pick-cards-box');
    if (!overlay || !container) return;

    container.innerHTML = '';
    overlay.style.display = 'flex';

    let userHasPicked = false;
    let selectedChoice = null;

    for (let i = 1; i <= maxPlayers; i++) {
        const card = document.createElement('div');
        card.className = 'pick-card';
        card.id = `pick-turn-card-${i}`;
        card.innerHTML = `<span>🃏</span><strong style="margin-top:8px;">การ์ดใบที่ ${i}</strong>`;
        card.onclick = async () => {
            if (userHasPicked) return;
            userHasPicked = true;
            selectedChoice = i;
            try { await apiClient.selectTurnCard(roomId, i); } catch(e){}
            card.style.borderColor = '#00e5ff';
            card.style.boxShadow = '0 0 25px rgba(0,229,255,0.7)';
            card.innerHTML = `<span>✨</span><strong style="margin-top:8px; color:#00e5ff;">เลือกใบที่ ${i}!</strong>`;
        };
        container.appendChild(card);
    }

    let timeLeft = 5;
    if (timerEl) timerEl.innerText = timeLeft;
    if (turnSelectionTimer) clearInterval(turnSelectionTimer);

    turnSelectionTimer = setInterval(async () => {
        timeLeft--;
        if (timerEl) timerEl.innerText = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(turnSelectionTimer);

            // หากไม่มีใครกด หรือกดไม่ครบภายใน 5 วินาที ให้ระบบเลือกสุ่มได้ทันทีแล้วเข้าเริ่มเกมส์ได้เลย
            if (!userHasPicked) {
                userHasPicked = true;
                selectedChoice = Math.floor(Math.random() * maxPlayers) + 1;
                const autoCard = document.getElementById(`pick-turn-card-${selectedChoice}`);
                if (autoCard) {
                    autoCard.style.borderColor = '#ffd700';
                    autoCard.style.boxShadow = '0 0 25px rgba(255,215,0,0.7)';
                    autoCard.innerHTML = `<span>🎲</span><strong style="margin-top:8px; color:#ffd700;">ระบบสุ่มให้!</strong>`;
                }
                try { await apiClient.selectTurnCard(roomId, selectedChoice); } catch(e){}
            }

            overlay.style.display = 'none';

            let players = preloadedPlayers;
            let srvRoomCfg = preloadedRoomCfg;
            try {
                const res = await apiClient.checkRoomStatus(roomId);
                if (res && res.status === 'success') {
                    if (res.players && res.players.length >= maxPlayers) {
                        players = res.players;
                    }
                    srvRoomCfg = res.room_config || srvRoomCfg;
                }
            } catch(e) {}

            let finalPlayers = Array.isArray(players) ? [...players] : [];
            // รับประกันว่าจำนวนผู้เล่นจะเต็มตามจำนวนโหมดห้องแข่งขันเสมอ (เดี่ยว 4 ต้องมี 4 คนเสมอ!)
            if (finalPlayers.length < maxPlayers) {
                const isTeam = (window.currentActiveGameMode === 'TEAM');
                if (finalPlayers.length === 0) {
                    finalPlayers.push({
                        user_id: DEFAULT_USER.id || 1,
                        username: DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username,
                        avatar_url: DEFAULT_USER.avatar_url || DEFAULT_USER.picture || DEFAULT_USER.pictureUrl,
                        team: isTeam ? 'A' : 'NONE',
                        is_bot: false,
                        is_awakened: true,
                        dice_control_rate: Number(DEFAULT_USER.dice_control_rate ?? 35),
                        win_rate_bonus: Number(DEFAULT_USER.win_rate_bonus ?? 30),
                        roll_rate: Number(DEFAULT_USER.roll_rate ?? 40),
                        play_skill_rate: Number(DEFAULT_USER.play_skill_rate ?? 25),
                        char_grade: DEFAULT_USER.char_grade || 'S+',
                        base_power_value: 8
                    });
                }
                const missingCount = maxPlayers - finalPlayers.length;
                const usedNames = finalPlayers.map(p => p.username || p.bot_name || '');
                const oppProfiles = window.pickUniqueOpponentProfiles(missingCount, usedNames);

                oppProfiles.forEach((op, idx) => {
                    const pIdx = finalPlayers.length;
                    finalPlayers.push({
                        user_id: 901 + pIdx,
                        bot_name: op.username,
                        username: op.username,
                        avatar_url: op.avatar_url,
                        picture: op.picture,
                        team: isTeam ? ((pIdx + 1) % 2 === 0 ? 'A' : 'B') : 'NONE',
                        is_bot: true,
                        is_awakened: false,
                        dice_control_rate: 20,
                        win_rate_bonus: 15,
                        roll_rate: 20,
                        play_skill_rate: 12,
                        char_grade: 'A+',
                        base_power_value: 5
                    });
                });
            }
            startGameWithPlayers(finalPlayers, srvRoomCfg, roomId);
        }
    }, 1000);
}

function startGameWithPlayers(players, roomConfig = null, roomId = null) {
    window.isPracticeMatch = false;
    const mode = window.currentActiveGameMode || '2P';
    const targetPlayerCount = (mode === '2P') ? 2 : ((mode === '3P') ? 3 : 4);
    const effectiveRoomId = roomId || window.currentRoomId || currentWaitingRoomId || ('room_' + Date.now());
    window.currentRoomId = effectiveRoomId;

    let fullPlayers = Array.isArray(players) ? [...players] : [];
    // ความปลอดภัยขั้นสูงสุด: ป้องกันไม่ให้ห้อง 4 คน หรือห้อง 3 คนเริ่มเกมโดยมีผู้เล่นไม่ครบ
    if (fullPlayers.length < targetPlayerCount) {
        const missing = targetPlayerCount - fullPlayers.length;
        const usedNames = fullPlayers.map(p => p.username || p.bot_name || '');
        const extraProfiles = window.pickUniqueOpponentProfiles(missing, usedNames);
        const isTeam = (mode === 'TEAM');
        extraProfiles.forEach((op, idx) => {
            const pIdx = fullPlayers.length;
            fullPlayers.push({
                user_id: 901 + pIdx,
                id: 901 + pIdx,
                bot_name: op.username,
                username: op.username,
                avatar_url: op.avatar_url,
                picture: op.picture,
                team: isTeam ? ((pIdx + 1) % 2 === 0 ? 'A' : 'B') : 'NONE',
                is_bot: true,
                is_awakened: false,
                char_grade: 'A+',
                dice_control_rate: 20,
                win_rate_bonus: 15,
                roll_rate: 20,
                play_skill_rate: 12,
                base_power_value: 5
            });
        });
    }

    const usedNames = [DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username || ''];
    const oppProfiles = window.pickUniqueOpponentProfiles(fullPlayers.length, usedNames);

    const mapped = fullPlayers.map((p, idx) => {
        const isBot = Boolean(Number(p.is_bot));
        const profile = oppProfiles[idx % oppProfiles.length];
        const realPlayerName = DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username || 'ผู้เล่น';
        let rawName = isBot ? (p.bot_name || p.username) : realPlayerName;
        if (!isBot && rawName === 'เขียนศักดิ์') {
            rawName = DEFAULT_USER.username || 'ผู้เล่น';
        }
        if (isBot && (window.isLegacyBotDisplayName(rawName) || usedNames.includes(rawName))) {
            rawName = profile.username;
        }
        usedNames.push(rawName);

        const realPlayerAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl(DEFAULT_USER) : (DEFAULT_USER.avatar_url || DEFAULT_USER.pictureUrl || DEFAULT_USER.picture || 'avatars/avatar_01.svg');
        const avatarUrl = isBot
            ? ((p.avatar_url && !p.avatar_url.includes('google_avatar')) ? p.avatar_url : profile.avatar_url)
            : realPlayerAvatar;

        const teamCode = p.team || 'NONE';
        const teamName = teamCode === 'A' ? 'ทีมฟ้า' : (teamCode === 'B' ? 'ทีมแดง' : '');

        return {
            id: isBot ? (900 + idx) : (p.user_id || p.id || (900 + idx)),
            username: rawName,
            avatar_url: avatarUrl,
            picture: avatarUrl,
            team: teamCode,
            team_name: teamName,
            color: idx === 0 ? 0x00e5ff : (idx === 1 ? 0xf43f5e : (idx === 2 ? 0xffd700 : 0xa855f7)),
            is_bot: isBot,
            is_awakened: Boolean(p.is_awakened),
            dice_control_rate: Number(p.dice_control_rate || (isBot ? 20 : (DEFAULT_USER.dice_control_rate || 35))),
            win_rate_bonus: Number(p.win_rate_bonus || (isBot ? 15 : (DEFAULT_USER.win_rate_bonus || 30))),
            roll_rate: Number(p.roll_rate || (isBot ? 20 : (DEFAULT_USER.roll_rate || 40))),
            play_skill_rate: Number(p.play_skill_rate || (isBot ? 12 : (DEFAULT_USER.play_skill_rate || 25))),
            char_grade: p.char_grade || (isBot ? 'A+' : (DEFAULT_USER.char_grade || 'S+')),
            skill: { code: p.skill_code || 'PULL_BACK_5', power: p.base_power_value || 5 }
        };
    });

    const resolvedCfg = roomConfig
        || window.activeRoomConfigFromServer
        || (typeof window.getActiveRoomEconomyConfig === 'function' ? window.getActiveRoomEconomyConfig(window.currentActiveRoomTier || currentLobbyTier) : null);

    const orderedMapped = (typeof window.applyTurnOrderSelection === 'function')
        ? window.applyTurnOrderSelection(mapped)
        : mapped;

    // ปลดสถานะค้นหาคู่แข่ง (in-matchmaking) เพื่อให้ HUD และปุ่มทอยลูกเต๋าทำงาน
    document.body.classList.remove('in-matchmaking');
    const bottomHud = document.querySelector('.bottom-hud');
    if (bottomHud) bottomHud.style.display = 'flex';

    // เข้าสู่โหมดแสดงกระดานเต็มจอ (Fullscreen Immersive Board Mode)
    document.body.classList.add('in-match-fullscreen');

    if (window.game) {
        window.game.setupPlayers(orderedMapped, { roomConfig: resolvedCfg, roomId: effectiveRoomId, gameMode: mode });
        window.game.logMessage('🎲 การแข่งขันเริ่มต้นขึ้นแล้ว! สร้างเมือง อัปแลนด์มาร์ค หรือพิชิตเส้นชัยช่อง 100!', 'highlight');
        if (typeof window.game.onWindowResize === 'function') {
            setTimeout(() => window.game.onWindowResize(), 80);
        }
    }
}

// --- Shop & Gacha ---
window.readMatQty = function(matsObj, code) {
    if (!matsObj || matsObj[code] === undefined || matsObj[code] === null) return 0;
    const raw = matsObj[code];
    if (typeof raw === 'number') return isNaN(raw) ? 0 : raw;
    if (typeof raw === 'object' && raw.quantity !== undefined) return parseInt(raw.quantity) || 0;
    return parseInt(raw) || 0;
};

window.syncGachaShadowAndTierCache = function(ev) {
    if (!ev) return;

    const defaults = [
        { slot: 'black',  code: 'SHADOW_BLACK_A',    altCode: '',                  name: 'เงาสีดำ A',   grade: 'A',  color: '#94a3b8', aura: 'none',    intensity: 80,  rate: parseFloat(ev.rate_shadow_black ?? 90),  icon: '⬛', image_url: '' },
        { slot: 'red',    code: 'SHADOW_RED_A',      altCode: '',                  name: 'เงาสีแดง A',  grade: 'A',  color: '#ef4444', aura: 'crimson', intensity: 95,  rate: parseFloat(ev.rate_shadow_red ?? 80),    icon: '🟥', image_url: '' },
        { slot: 'orange', code: 'SHADOW_ORANGE_A',   altCode: '',                  name: 'เงาสีส้ม A',  grade: 'A',  color: '#ff8800', aura: 'orange',  intensity: 100, rate: parseFloat(ev.rate_shadow_orange ?? 70), icon: '🟧', image_url: '' },
        { slot: 'blue',   code: 'SHADOW_BLUE_APLUS', altCode: 'SHADOW_BLUE_A',     name: 'เงาสีฟ้า A+', grade: 'A+', color: '#38bdf8', aura: 'cyan',    intensity: 115, rate: parseFloat(ev.rate_shadow_blue ?? 50),   icon: '🟦', image_url: '' },
        { slot: 'gold',   code: 'SHADOW_GOLD_S',     altCode: 'SHADOW_GOLD_APLUS', name: 'เงาสีทอง S',  grade: 'S',  color: '#ffd700', aura: 'gold',    intensity: 140, rate: parseFloat(ev.rate_shadow_gold ?? 10),   icon: '🟨', image_url: '' }
    ];

    const rawShadows = Array.isArray(ev.shadow_configs) ? ev.shadow_configs : [];
    const bySlot = {};
    rawShadows.forEach(s => {
        if (s && s.slot) bySlot[s.slot] = s;
    });

    window.currentShadowConfigs = defaults.map(d => {
        const c = bySlot[d.slot] || {};
        return {
            slot: d.slot,
            code: d.code,
            altCode: d.altCode,
            name: c.name || d.name,
            grade: c.grade || d.grade,
            color: c.color || d.color,
            aura: c.aura || d.aura,
            intensity: c.intensity !== undefined ? parseInt(c.intensity) : d.intensity,
            rate: c.rate !== undefined ? parseFloat(c.rate) : d.rate,
            icon: d.icon,
            image_url: c.image_url || ''
        };
    });

    if (ev.target_character && ev.target_character.name) {
        window.currentGachaTargetName = ev.target_character.name;
    }
    window.currentGachaTargetCharId = parseInt(ev.target_character_id) || 1;
    window.currentGachaReqs = {
        black: parseInt(ev.req_shadow_black) || 15,
        red: parseInt(ev.req_shadow_red) || 15,
        orange: parseInt(ev.req_shadow_orange) || 15,
        blue: parseInt(ev.req_shadow_blue) || 10,
        gold: parseInt(ev.req_shadow_gold) || 4
    };

    if (ev.exchange_tiers && typeof ev.exchange_tiers === 'object') {
        window.currentExchangeTiers = ev.exchange_tiers;
    } else {
        window.currentExchangeTiers = {
            'SS+': { grade: 'SS+', enabled: true, character_id: 0, character: null, reqs: { black: 25, red: 25, orange: 20, blue: 15, gold: 8 } },
            'S+':  { grade: 'S+',  enabled: true, character_id: window.currentGachaTargetCharId, character: ev.target_character || null, reqs: { ...window.currentGachaReqs } },
            'S':   { grade: 'S',   enabled: true, character_id: 0, character: null, reqs: { black: 10, red: 10, orange: 8, blue: 5, gold: 1 } }
        };
    }
};

window.buildShadowRingBadgeHtml = function(sObj, sizePx = 36) {
    const color = (sObj && sObj.color) ? sObj.color : '#38bdf8';
    const aura = (sObj && sObj.aura) ? String(sObj.aura).toLowerCase() : 'none';
    const intensity = (sObj && sObj.intensity !== undefined) ? parseInt(sObj.intensity) : 100;
    const auraColors = {
        gold: '#ffd700', yellow: '#facc15', orange: '#ff5500', crimson: '#ef4444',
        cyan: '#00e5ff', purple: '#a855f7', white: '#ffffff', rainbow: '#00e5ff'
    };
    const glowHex = aura !== 'none' ? (auraColors[aura] || color) : color;
    const factor = Math.max(0.3, intensity / 100);
    const blurPx = aura === 'none' ? Math.round(4 * Math.min(1.5, factor)) : Math.round(9 * Math.min(2.6, factor));
    const imgUrl = (sObj && sObj.image_url) ? sObj.image_url : '';

    if (imgUrl) {
        return `
            <div style="width:${sizePx}px; height:${sizePx}px; border-radius:50%; position:relative; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; background:radial-gradient(circle, #0b1120 42%, #020617 100%); border:1.5px solid ${color}aa; box-shadow:0 0 ${blurPx}px ${glowHex}99;">
                <img src="${imgUrl}" style="width:112%; height:112%; object-fit:contain; pointer-events:none; filter:drop-shadow(0 0 ${Math.max(3, Math.round(blurPx * 0.55))}px ${glowHex});" alt="">
            </div>
        `;
    }
    return `
        <div style="width:${sizePx}px; height:${sizePx}px; border-radius:50%; position:relative; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; background:radial-gradient(circle, ${color}33 25%, #020617 75%); border:2px dashed ${color}; box-shadow:0 0 ${blurPx}px ${glowHex}88, inset 0 0 8px ${color}66;">
            <span style="width:${Math.round(sizePx * 0.42)}px; height:${Math.round(sizePx * 0.42)}px; border-radius:50%; border:2px solid ${color}; box-shadow:0 0 6px ${glowHex};"></span>
        </div>
    `;
};

window.buildMultiTierExchangeHtml = function(materials, afterCraftMode = 'shop') {
    const shadows = Array.isArray(window.currentShadowConfigs) && window.currentShadowConfigs.length === 5
        ? window.currentShadowConfigs
        : [
            { slot: 'black',  code: 'SHADOW_BLACK_A',    altCode: '',                  name: 'เงาสีดำ A',   grade: 'A',  color: '#94a3b8', aura: 'none',    intensity: 80,  image_url: '' },
            { slot: 'red',    code: 'SHADOW_RED_A',      altCode: '',                  name: 'เงาสีแดง A',  grade: 'A',  color: '#ef4444', aura: 'crimson', intensity: 95,  image_url: '' },
            { slot: 'orange', code: 'SHADOW_ORANGE_A',   altCode: '',                  name: 'เงาสีส้ม A',  grade: 'A',  color: '#ff8800', aura: 'orange',  intensity: 100, image_url: '' },
            { slot: 'blue',   code: 'SHADOW_BLUE_APLUS', altCode: 'SHADOW_BLUE_A',     name: 'เงาสีฟ้า A+', grade: 'A+', color: '#38bdf8', aura: 'cyan',    intensity: 115, image_url: '' },
            { slot: 'gold',   code: 'SHADOW_GOLD_S',     altCode: 'SHADOW_GOLD_APLUS', name: 'เงาสีทอง S',  grade: 'S',  color: '#ffd700', aura: 'gold',    intensity: 140, image_url: '' }
        ];

    const haveBySlot = {
        black: window.readMatQty(materials, 'SHADOW_BLACK_A'),
        red: window.readMatQty(materials, 'SHADOW_RED_A'),
        orange: window.readMatQty(materials, 'SHADOW_ORANGE_A'),
        blue: window.readMatQty(materials, 'SHADOW_BLUE_APLUS') + window.readMatQty(materials, 'SHADOW_BLUE_A'),
        gold: window.readMatQty(materials, 'SHADOW_GOLD_S') + window.readMatQty(materials, 'SHADOW_GOLD_APLUS')
    };
    const haveSpecial = window.readMatQty(materials, 'SPECIAL_CARD');

    const tiersObj = window.currentExchangeTiers || {
        'SS+': { grade: 'SS+', enabled: true, character_id: 0, character: null, reqs: { black: 25, red: 25, orange: 20, blue: 15, gold: 8 } },
        'S+':  { grade: 'S+',  enabled: true, character_id: window.currentGachaTargetCharId || 1, character: null, reqs: window.currentGachaReqs || { black: 15, red: 15, orange: 15, blue: 10, gold: 4 } },
        'S':   { grade: 'S',   enabled: true, character_id: 0, character: null, reqs: { black: 10, red: 10, orange: 8, blue: 5, gold: 1 } }
    };

    const tierList = ['SS+', 'S+', 'S']
        .map(g => tiersObj[g] ? { ...tiersObj[g], grade: g } : null)
        .filter(t => t && t.enabled !== false);

    const myAvatar = typeof window.getActivePlayerAvatarUrl === 'function' ? window.getActivePlayerAvatarUrl() : 'avatars/google_avatar.png';

    const walletPillsHtml = shadows.map(s => {
        const qty = haveBySlot[s.slot] || 0;
        return `
            <span class="currency-pill" style="display:inline-flex; align-items:center; gap:6px; border-color:${s.color}66;">
                ${window.buildShadowRingBadgeHtml(s, 22)}
                <span style="color:${s.color}; font-weight:700;">${s.name}:</span>
                <strong style="color:#fff;">${qty.toLocaleString()}</strong>
            </span>
        `;
    }).join('') + `
        <span class="currency-pill" style="color:#c084fc;">✨ การ์ดพิเศษ: <strong>${haveSpecial.toLocaleString()} ใบ</strong></span>
    `;

    const tierStyleMap = {
        'SS+': { border: '#ffd700', bg: 'linear-gradient(145deg, rgba(255,215,0,0.14), rgba(15,23,42,0.92))', badgeBg: '#ffd700', badgeColor: '#000', titleIcon: '👑' },
        'S+':  { border: '#f59e0b', bg: 'linear-gradient(145deg, rgba(245,158,11,0.13), rgba(15,23,42,0.92))', badgeBg: '#f59e0b', badgeColor: '#000', titleIcon: '🌟' },
        'S':   { border: '#38bdf8', bg: 'linear-gradient(145deg, rgba(56,189,248,0.13), rgba(15,23,42,0.92))', badgeBg: '#38bdf8', badgeColor: '#020617', titleIcon: '💎' }
    };

    const tierCardsHtml = tierList.map(t => {
        const st = tierStyleMap[t.grade] || tierStyleMap['S+'];
        const reqs = t.reqs || { black: 15, red: 15, orange: 15, blue: 10, gold: 4 };
        const charObj = t.character || null;
        const frameName = charObj && charObj.name ? charObj.name : `กรอบรูปเกรด ${t.grade}`;
        const charId = parseInt(t.character_id || (charObj ? charObj.id : 0)) || 0;
        const auraClass = typeof getFrameAuraClass === 'function' ? getFrameAuraClass(t.grade, charObj ? charObj.aura_type : '') : '';
        const overdriveCss = typeof buildAuraOverdriveStyle === 'function' ? buildAuraOverdriveStyle(t.grade, charObj ? charObj.aura_type : '', charObj ? charObj.aura_intensity : 100) : '';
        const customRingHtml = (charObj && typeof buildCustomFrameLayersHtml === 'function') ? buildCustomFrameLayersHtml(charObj) : '';

        let canCraft = true;
        const reqBadges = shadows.map(s => {
            const need = parseInt(reqs[s.slot]) || 0;
            if (need <= 0) return '';
            const have = haveBySlot[s.slot] || 0;
            const ok = have >= need;
            if (!ok) canCraft = false;
            return `
                <span style="display:inline-flex; align-items:center; gap:4px; font-size:11px; padding:3px 7px; border-radius:7px; background:${ok ? 'rgba(16,185,129,0.16)' : 'rgba(15,23,42,0.85)'}; border:1px solid ${ok ? '#10b981' : 'rgba(148,163,184,0.28)'}; color:${ok ? '#6ee7b7' : '#cbd5e1'};">
                    <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:${s.color}; box-shadow:0 0 5px ${s.color};"></span>
                    <span>${s.name}:</span>
                    <strong style="color:${ok ? '#34d399' : '#fbbf24'};">${have}/${need}</strong>
                </span>
            `;
        }).filter(Boolean).join('');

        return `
            <div style="background:${st.bg}; border:1.5px solid ${st.border}; border-radius:10px; padding:6px 8px; display:flex; flex-direction:column; justify-content:space-between; gap:4px; box-shadow:0 4px 12px rgba(0,0,0,0.45);">
                <div style="display:flex; align-items:center; gap:6px;">
                    <div class="frame-circle-wrap ${auraClass}" style="width:34px; height:34px; flex-shrink:0; position:relative; ${overdriveCss}">
                        <img src="${myAvatar}" class="frame-avatar-img" onerror="this.onerror=null; this.src='avatars/google_avatar.png';">
                        ${customRingHtml}
                        <span class="avatar-grade-tag" style="background:${st.badgeBg}; color:${st.badgeColor}; font-size:7.5px; padding:1px 3px;">${t.grade}</span>
                    </div>
                    <div style="min-width:0; flex:1;">
                        <div style="font-size:9.5px; font-weight:800; color:${st.border};">${st.titleIcon} แลกกรอบระดับ ${t.grade}</div>
                        <div style="font-size:11.5px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${frameName}">${frameName}</div>
                        ${charObj ? `<div style="font-size:9px; color:#94a3b8;">🏆 ชนะ +${parseFloat(charObj.win_rate_bonus || 0)}% | 🎲 ทอย +${parseFloat(charObj.roll_rate || 0)}%</div>` : ''}
                    </div>
                </div>

                <div style="display:flex; flex-wrap:wrap; gap:3px;">
                    ${reqBadges || '<span style="font-size:9.5px; color:#34d399;">แลกได้ทันที!</span>'}
                </div>

                <button type="button" class="btn-roll"
                    style="width:100%; justify-content:center; padding:4px 6px; font-size:10.5px; font-weight:800; border-radius:6px; ${canCraft ? `background:linear-gradient(135deg, ${st.border}, #ea580c); color:#020617; box-shadow:0 0 8px ${st.border}66;` : 'background:#334155; color:#cbd5e1; opacity:0.88;'}"
                    onclick="doCraftFrameTier('${t.grade}', ${charId}, '${afterCraftMode}')">
                    ${canCraft ? `✨ แลกรับกรอบ ${t.grade}` : `🔮 สะสมเงาแลก ${t.grade}`}
                </button>
            </div>
        `;
    }).join('');

    return `
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:4px; margin-bottom:4px;">
            <h3 style="color:#ffd700; font-size:12.5px; margin:0;">✨ ศูนย์สะสมการ์ดเงา แลกรับกรอบรูป SS+ / S+ / S</h3>
            <span style="font-size:10px; color:#38bdf8;">สะสมเงาแลกกรอบที่ต้องการได้ทันที</span>
        </div>
        <div style="display:flex; gap:4px; flex-wrap:wrap; margin-bottom:6px; font-size:10px;">
            ${walletPillsHtml}
        </div>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:6px;">
            ${tierCardsHtml}
        </div>
    `;
};

window.switchShopTab = function(tabKey) {
    const tabs = ['gacha', 'upgrade', 'topup'];
    tabs.forEach(t => {
        const pane = document.getElementById(`shop-tab-pane-${t}`);
        const btn = document.getElementById(`tab-btn-shop-${t}`);
        if (pane) pane.style.display = (t === tabKey) ? 'block' : 'none';
        if (btn) {
            if (t === tabKey) {
                btn.classList.add('active');
                btn.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
                btn.style.color = '#fff';
                btn.style.borderColor = '#38bdf8';
            } else {
                btn.classList.remove('active');
                btn.style.background = 'rgba(15,23,42,0.8)';
                btn.style.color = '#94a3b8';
                btn.style.borderColor = 'rgba(255,255,255,0.1)';
            }
        }
    });
};

window.loadShopData = async function() {
    let cat = null;
    let inv = null;
    try {
        cat = await apiClient.getCatalog();
        inv = await apiClient.getInventory();
    } catch(e) {
        console.warn('Shop API offline, using mock store:', e);
    }

    const ev = (cat && cat.catalog && cat.catalog.gacha_event) ? cat.catalog.gacha_event : null;
    if (ev) {
        window.syncGachaShadowAndTierCache(ev);

        const titleEl = document.getElementById('gacha-event-title');
        const periodEl = document.getElementById('gacha-event-period');
        const costLabel = document.getElementById('gacha-cost-label');
        const cardsPerPackLabel = document.getElementById('gacha-cards-per-pack-label');
        const btnRoll1 = document.getElementById('btn-gacha-roll-1');
        const btnRoll10 = document.getElementById('btn-gacha-roll-10');

        const cardsPerPack = parseInt(ev.cards_per_pack) || 5;
        const cost = parseInt(ev.cost_diamond) || 100;

        if (titleEl) titleEl.innerText = '🎰 ' + (ev.event_name || `แพ็คการ์ดสุ่มกรอบรูป (1 แพ็ค = เปิด ${cardsPerPack} ใบ)`);
        if (periodEl && ev.start_date && ev.end_date) {
            periodEl.innerText = `📅 กำหนดการจัดกิจกรรม: ${ev.start_date.substring(0, 10)} ถึง ${ev.end_date.substring(0, 10)}`;
        }
        if (costLabel) costLabel.innerText = cost.toLocaleString();
        if (cardsPerPackLabel) cardsPerPackLabel.innerText = cardsPerPack;
        if (btnRoll1) {
            btnRoll1.innerHTML = `🎴 เปิด 1 แพ็ค (${cardsPerPack} ใบ) [<span id="gacha-btn-cost-1">${cost.toLocaleString()}</span> 💎]`;
        }
        if (btnRoll10) {
            btnRoll10.innerHTML = `⚡ เปิด 10 แพ็ค (${cardsPerPack * 10} ใบ) [<span id="gacha-btn-cost-10">${Number(cost * 10).toLocaleString()}</span> 💎]`;
        }
        const btnAgain = document.getElementById('btn-gacha-again');
        if (btnAgain) {
            btnAgain.innerHTML = `🎴 เปิดอีก 1 แพ็ค (${cardsPerPack} ใบ) [${cost.toLocaleString()} 💎]`;
        }

        const ratesBar = document.getElementById('gacha-rates-bar');
        if (ratesBar && Array.isArray(window.currentShadowConfigs)) {
            const sRateItems = window.currentShadowConfigs.map(s => `
                <span style="display:inline-flex; align-items:center; gap:5px;">
                    ${window.buildShadowRingBadgeHtml(s, 20)}
                    <span>${s.name}: <strong style="color:${s.color};">${s.rate}%</strong></span>
                </span>
            `).join('<span style="color:rgba(255,255,255,0.2);">|</span>');

            const tGrade = (ev.target_character && ev.target_character.grade) ? ev.target_character.grade : 'S+';
            ratesBar.innerHTML = `
                ${sRateItems}
                <span style="color:rgba(255,255,255,0.2);">|</span>
                <span>👑 แจ็คพอต ${tGrade}: <strong style="color:#ffd700;">${parseFloat(ev.rate_splus ?? 3)}%</strong></span>
                <span style="color:rgba(255,255,255,0.2);">|</span>
                <span>✨ การ์ดพิเศษ: <strong style="color:#ec4899;">${parseFloat(ev.rate_shadow_special ?? 15)}%</strong></span>
            `;
        }

        window.currentGachaCost = cost;
    }

    const mats = (inv && inv.materials) ? inv.materials : {
        SHADOW_BLACK_A: 0, SHADOW_RED_A: 0, SHADOW_ORANGE_A: 0, SHADOW_BLUE_APLUS: 0, SHADOW_BLUE_A: 0, SHADOW_GOLD_S: 0, SHADOW_GOLD_APLUS: 0, SPECIAL_CARD: 0
    };

    const shopCraftBox = document.getElementById('shop-crafting-box');
    if (shopCraftBox) {
        shopCraftBox.innerHTML = window.buildMultiTierExchangeHtml(mats, 'shop');
    }

    // Render Packages
    const pkgBox = document.getElementById('packages-container');
    if (pkgBox) {
        pkgBox.innerHTML = '';
        const pkgs = (cat && cat.catalog && cat.catalog.topup_packages) ? cat.catalog.topup_packages : [
            { id: 1, reward_diamond: 500, price_thb: 30.00 },
            { id: 2, reward_diamond: 1200, price_thb: 69.00 },
            { id: 3, reward_diamond: 3000, price_thb: 159.00 }
        ];

        pkgs.forEach(p => {
            const div = document.createElement('div');
            div.className = 'currency-pill';
            div.style.cursor = 'pointer';
            div.innerHTML = `💎 ${p.reward_diamond} เพชร (${p.price_thb} บ.)`;
            div.onclick = async () => {
                try {
                    const res = await apiClient.topupPurchase(p.id);
                    showToast(res.message);
                    const prof = await apiClient.getProfile();
                    if (prof && prof.data) {
                        Object.assign(DEFAULT_USER, prof.data);
                        updateUserBar(DEFAULT_USER);
                    }
                } catch(e) {
                    await window.syncUserProgress({ diamond_delta: p.reward_diamond });
                    showToast(`จำลองเติมเงินสำเร็จ! ได้รับ +${p.reward_diamond} เพชร`);
                }
            };
            pkgBox.appendChild(div);
        });
    }

    // Render Inventory
    const invItems = (inv && inv.inventory && inv.inventory.length) ? inv.inventory : [
        { id: 1, char_name: 'พญานาคราช 3D', level: 30, is_awakened: 1, skill_name: 'มหาเวทย์ดึงถอยหลัง 8 ช่อง' },
        { id: 2, char_name: 'พยัคฆ์สายฟ้า', level: 15, is_awakened: 0, skill_name: 'ส่งคู่ต่อสู้ถอยหลัง 5 ช่อง' },
        { id: 3, dice_name: 'ลูกเต๋าทองคำจักรพรรดิ 3D', level: 20, is_awakened: 0, skill_name: 'ทอยแม่นยำ 50%' }
    ];
    renderInventoryUpgradeList(invItems);
};

function renderInventoryUpgradeList(items) {
    const box = document.getElementById('inventory-cards-list');
    if (!box) return;
    box.innerHTML = '';

    items.forEach(item => {
        const isMax = item.level >= 30;
        const div = document.createElement('div');
        div.className = `board-card ${item.is_awakened ? 'awakened-gold' : ''}`;
        div.style.marginBottom = '12px';
        div.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h4 style="font-size:15px; color:#fff;">${item.char_name || item.dice_name} [Lv.${item.level}/30] ${item.is_awakened ? '✨ ออร่าทอง' : ''}</h4>
                    <p style="font-size:12px; color:#94a3b8;">สกิล: ${item.skill_name || 'ทอยเต๋า'}</p>
                </div>
                <div>
                    ${!isMax 
                        ? `<button class="btn-roll" style="padding:6px 14px; font-size:13px;" onclick="upgradeItem(${item.id})">อัปเกรด (Lv.${item.level + 1})</button>`
                        : `<span style="color:#ffd700; font-weight:bold;">MAX LV.30 ✨</span>`
                    }
                </div>
            </div>
        `;
        box.appendChild(div);
    });
}

window.doGacha = async function(count = 1) {
    try {
        const res = await apiClient.gachaRoll(count);
        if (res.status === 'success') {
            loadShopData();
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }

            // Show 5-Card Reveal Modal with animation
            showGachaCardsRevealModal(res.drops, res.pack_count || count, res.total_cards || (count * 5), res.diamonds_spent);
            return;
        } else {
            showToast(res.message);
        }
    } catch(e) {
        showToast('เกิดข้อผิดพลาดในการเปิดแพ็คการ์ด');
    }
};

window.showGachaCardsRevealModal = function(drops, packCount, totalCards, spent) {
    const modal = document.getElementById('modal-gacha-reveal');
    const container = document.getElementById('gacha-cards-container');
    const subtitle = document.getElementById('gacha-reveal-subtitle');
    if (!modal || !container) {
        // Fallback alert if modal not in DOM
        let msg = `เปิดแพ็คการ์ดได้รับ:\n`;
        drops.forEach(d => { msg += `${d.icon || '🃏'} [${d.rarity}] ${d.name}\n`; });
        showInGameAlert(msg, '🎉 ผลลัพธ์กาชาปอง', '🎰');
        return;
    }

    if (subtitle) {
        subtitle.innerHTML = `ยินดีด้วย! เปิดสำเร็จ <strong>${packCount} แพ็ค</strong> (${totalCards} ใบ) สิ้นเปลือง <span style="color:#00e5ff; font-weight:700;">💎 ${spent} เพชร</span>:`;
    }

    container.innerHTML = drops.map((d, idx) => {
        const isSPlus = d.rarity === 'S+' || d.rarity === 'SS+';
        const isGold = d.rarity === 'S' || (d.material_code && d.material_code.includes('GOLD'));
        const borderColor = isSPlus ? '#ffd700' : (isGold ? '#f59e0b' : (d.color || '#38bdf8'));
        const bgGlow = isSPlus ? 'rgba(255,215,0,0.2)' : (isGold ? 'rgba(245,158,11,0.15)' : 'rgba(15,23,42,0.85)');

        const visualHtml = (d.image_url || (d.material_code && d.material_code.startsWith('SHADOW_')))
            ? `<div style="margin-bottom:8px;">${window.buildShadowRingBadgeHtml(d, 58)}</div>`
            : `<div style="font-size:38px; margin-bottom:8px; filter:drop-shadow(0 0 6px ${borderColor});">${d.icon || '🃏'}</div>`;

        return `
            <div style="background:${bgGlow}; border:2px solid ${borderColor}; border-radius:12px; padding:14px 10px; width:142px; min-height:175px; display:flex; flex-direction:column; align-items:center; justify-content:center; box-shadow:0 0 16px ${borderColor}55; animation: cardFlipIn 0.5s ease-out ${idx * 0.08}s both;">
                ${visualHtml}
                <div style="font-size:12px; font-weight:800; color:#fff; margin-bottom:4px; text-align:center; line-height:1.3;">
                    ${d.name}
                </div>
                <div style="font-size:11px; background:${borderColor}; color:#000; font-weight:800; padding:2px 8px; border-radius:10px; margin-top:auto;">
                    ${d.rarity}
                </div>
            </div>
        `;
    }).join('');

    modal.style.display = 'flex';
};

window.doCraftFrameTier = async function(tierGrade = 'S+', targetCharId = 0, afterMode = 'shop') {
    try {
        const resolvedId = parseInt(targetCharId) || (window.currentGachaTargetCharId || 1);
        const res = await apiClient.exchangeSPlusCard(resolvedId, tierGrade);
        if (res && res.status === 'success') {
            showInGameAlert(res.message, `🎉 แลกรับกรอบระดับ ${tierGrade || 'S+'} สำเร็จ!`, '👑');
            if (afterMode === 'inventory' && typeof loadInventoryData === 'function') {
                loadInventoryData();
            } else {
                loadShopData();
            }
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
        } else {
            showInGameAlert((res && res.message) ? res.message : 'วัตถุดิบการ์ดเงายังไม่ครบตามที่กำหนด', 'ยังไม่สามารถแลกได้', '⚠️');
        }
    } catch(e) {
        const errMsg = (e && e.message) ? e.message : 'วัตถุดิบการ์ดเงายังไม่ครบตามที่กำหนด กรุณาสะสมการ์ดเงาจากการเปิดแพ็คการ์ดสุ่ม';
        showInGameAlert(errMsg, 'ยังไม่สามารถแลกได้', '⚠️');
    }
};

window.doCraftSPlus = async function() {
    return window.doCraftFrameTier('S+', window.currentGachaTargetCharId || 1, 'shop');
};

window.upgradeItem = async function(invId) {
    try {
        const res = await apiClient.upgradeCard(invId);
        showInGameAlert(res.message, '⚡ อัปเกรดสำเร็จ', '✨');
        loadShopData();
        const prof = await apiClient.getProfile();
        if (prof && prof.data) {
            Object.assign(DEFAULT_USER, prof.data);
            updateUserBar(DEFAULT_USER);
        }
    } catch(e) {
        showToast('อัปเกรดการ์ดสำเร็จ!');
    }
};

// --- Mailbox ---
window.loadMailData = async function() {
    let mails = [];
    try {
        const res = await apiClient.getMailbox();
        if (res && res.mailbox) mails = res.mailbox;
    } catch(e) {}

    if (mails.length === 0) {
        mails = [
            { id: 1, title: 'ยินดีต้อนรับสู่เกมบันไดงู 3D!', message: 'รับเพชร 500 เม็ด และ 100,000 ทอง ขวัญถุงต้อนรับเปิดเซิร์ฟ', reward_diamond: 500, reward_gold: 100000, is_claimed: 0 }
        ];
    }

    const box = document.getElementById('mail-list-box');
    if (!box) return;
    box.innerHTML = '';

    mails.forEach(m => {
        const div = document.createElement('div');
        div.className = 'board-card';
        div.style.marginBottom = '10px';
        div.style.textAlign = 'left';
        div.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h4 style="color:#00e5ff;">${m.title}</h4>
                <span>${m.is_claimed ? '✅ รับแล้ว' : '🎁 ยังไม่ได้รับ'}</span>
            </div>
            <p style="font-size:13px; color:#cbd5e1; margin:6px 0;">${m.message}</p>
            ${!m.is_claimed && (m.reward_diamond > 0 || m.reward_gold > 0) ? `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
                    <div>
                        ${m.reward_diamond > 0 ? `<span style="color:#00e5ff; margin-right:8px;">💎 +${m.reward_diamond}</span>` : ''}
                        ${m.reward_gold > 0 ? `<span style="color:#f59e0b;">🪙 +${m.reward_gold.toLocaleString()}</span>` : ''}
                    </div>
                    <button class="btn-roll" style="padding:4px 12px; font-size:12px;" onclick="claimMailReward(${m.id})">กดรับ</button>
                </div>
            ` : ''}
        `;
        box.appendChild(div);
    });
};

window.claimMailReward = async function(mailId) {
    try {
        const res = await apiClient.claimMail(mailId);
        showToast(res.message);
        loadMailData();
        const prof = await apiClient.getProfile();
        if (prof && prof.data) {
            Object.assign(DEFAULT_USER, prof.data);
            updateUserBar(DEFAULT_USER);
        }
    } catch(e) {
        await window.syncUserProgress({ diamond_delta: 500, gold_delta: 100000 });
        showToast('กดรับรางวัลสำเร็จ! +500 เพชร และ +100,000 ทอง');
        loadMailData();
    }
};

window.redeemPromo = async function() {
    const code = document.getElementById('input-promo-code').value.trim();
    if (!code) return showToast('กรุณากรอกรหัสโปรโมชั่น');
    try {
        const res = await apiClient.redeemPromoCode(code);
        showInGameAlert(res.message, 'แลกโค้ดสำเร็จ', '🎁');
        if (res.status === 'success') {
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
        }
    } catch(e) {
        await window.syncUserProgress({ diamond_delta: 500, gold_delta: 100000 });
        showInGameAlert(`แลกโค้ด ${code} สำเร็จ!\nได้รับ 500 เพชร และ 100,000 ทอง`, '🎁 แลกของรางวัล', '🎉');
    }
};

// --- Leaderboard & Weekly Season Reset ---
let leaderboardCountdownInterval = null;

window.loadLeaderboardData = async function() {
    let solo = null;
    let clan = null;
    let resetInfo = null;

    try {
        const res = await apiClient.getLeaderboard('all');
        if (res) {
            solo = res.solo_leaderboard;
            clan = res.clan_leaderboard;
            resetInfo = res.weekly_reset_info;
        }
    } catch(e) {
        console.warn('loadLeaderboardData error:', e);
    }

    // อัปเดตแบนเนอร์นับถอยหลังรอบจัดอันดับประจำสัปดาห์ (รีเซ็ตทุกวันพุธ 10:00 น.)
    const seasonBadgeEl = document.getElementById('lb-season-badge');
    const cycleTextEl = document.getElementById('lb-season-cycle-text');
    const countdownEl = document.getElementById('lb-countdown-text');

    if (resetInfo) {
        if (seasonBadgeEl) seasonBadgeEl.innerText = `รอบแข่งขันจัดอันดับ 1 สัปดาห์ (Season #${resetInfo.season_number || 1})`;
        if (cycleTextEl) cycleTextEl.innerText = resetInfo.rule_description || 'รีเซ็ตอันดับทุกวันพุธ เวลา 10:00 น. ตรง • แข่งขันเพื่อรักษาระดับอันดับ';

        if (countdownEl) {
            if (leaderboardCountdownInterval) clearInterval(leaderboardCountdownInterval);
            let remSec = resetInfo.seconds_remaining || 0;
            const updateLbTimer = () => {
                const d = Math.floor(remSec / 86400);
                const h = Math.floor((remSec % 86400) / 3600);
                const m = Math.floor((remSec % 3600) / 60);
                const s = remSec % 60;
                countdownEl.innerText = `⏳ เหลืออีก ${d} วัน ${h} ชม. ${m} นาที ${s} วินาที`;
                if (remSec > 0) remSec--;
            };
            updateLbTimer();
            leaderboardCountdownInterval = setInterval(updateLbTimer, 1000);
        }
    }

    const soloBox = document.getElementById('solo-ranking-table');
    const clanBox = document.getElementById('clan-ranking-table');

    if (!solo || solo.length === 0) {
        solo = [
            { ranking: 1, user_id: 2, username: 'สมชายสายสุ่ม', avatar_url: 'avatars/bots/bot_m01.jpg', level: 8, level_icon: '🥈', clan_name: 'บ้านมังกรทอง', rank_points: 1920, tier: 'DIAMOND', total_wins: 52, total_losses: 28, win_rate: '65.00' },
            { ranking: 2, user_id: 3, username: 'มังกรหยกสามมิติ', avatar_url: 'avatars/bots/bot_f01.jpg', level: 4, level_icon: '🥉', clan_name: 'บ้านพญานาคราช', rank_points: 1340, tier: 'GOLD', total_wins: 23, total_losses: 22, win_rate: '51.11' },
            { ranking: 3, user_id: 15, username: 'เอ็นซีพี คอมพิวเตอร์', avatar_url: 'avatars/bots/bot_m02.jpg', level: 2, level_icon: '🥉', clan_name: '@PIMMY', rank_points: 1040, tier: 'BRONZE', total_wins: 2, total_losses: 1, win_rate: '66.67' }
        ];
    }

    if (!clan || clan.length === 0) {
        clan = [
            { ranking: 1, clan_name: 'บ้านพญานาคราช', clan_tag: 'NAGA', leader_name: 'เซียนเต๋าสายฟ้า', total_score: 125000, clan_level: 5, current_members: 38, max_members: 50 },
            { ranking: 2, clan_name: 'บ้านมังกรทองคำ', clan_tag: 'DRG', leader_name: 'มังกรหยก 3D', total_score: 98400, clan_level: 4, current_members: 31, max_members: 40 }
        ];
    }

    if (soloBox) {
        soloBox.innerHTML = '';
        solo.forEach(r => {
            const tr = document.createElement('tr');
            tr.title = 'คลิกเพื่อดูสถิติและประวัติการเล่นย้อนหลัง (เดี่ยว 4 / 1v1)';
            tr.onclick = () => window.openPlayerStatsAndHistoryModal(r.user_id, r.username, r.avatar_url, r);

            const rankMedal = r.ranking === 1 ? '🥇' : (r.ranking === 2 ? '🥈' : (r.ranking === 3 ? '🥉' : `#${r.ranking}`));
            const av = r.avatar_url || 'avatars/bots/bot_f01.jpg';

            tr.innerHTML = `
                <td style="padding:10px 8px;"><strong>${rankMedal}</strong></td>
                <td>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <img src="${av}" alt="${r.username}" style="width:28px; height:28px; border-radius:50%; object-fit:cover; border:1px solid #38bdf8;">
                        <div>
                            <span style="font-weight:700; color:#fff;">${r.username}</span>
                            <span style="font-size:11px; color:#ffd700; margin-left:4px;">[${r.level_icon || '⭐'} Lv.${r.level}]</span>
                        </div>
                    </div>
                </td>
                <td><span style="color:#94a3b8;">${r.clan_name || '-'}</span></td>
                <td><strong style="color:#ffd700;">${Number(r.rank_points || 0).toLocaleString()} RP</strong> <span style="font-size:11px; color:#38bdf8;">(${r.tier || 'BRONZE'})</span></td>
                <td><span style="color:#10b981;">${r.total_wins}W</span> / <span style="color:#f43f5e;">${r.total_losses}L</span> (${r.win_rate}%)</td>
            `;
            soloBox.appendChild(tr);
        });
    }

    if (clanBox) {
        clanBox.innerHTML = '';
        clan.forEach(c => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="padding:8px;"><strong>#${c.ranking}</strong></td>
                <td><strong style="color:#ffd700;">${c.clan_name}</strong> [${c.clan_tag || ''}]</td>
                <td>${c.leader_name || '-'}</td>
                <td><strong>${Number(c.total_score).toLocaleString()}</strong> คะแนน</td>
                <td>Lv.${c.clan_level} (${c.current_members}/${c.max_members} คน)</td>
            `;
            clanBox.appendChild(tr);
        });
    }
};

// =========================================================================
// 📊 PLAYER STATS & MATCH HISTORY POPUP LOGIC
// =========================================================================
let currentPlayerHistoryData = null;
let currentHistoryFilterMode = 'ALL';

window.openPlayerStatsAndHistoryModal = async function(userId, fallbackName = 'ผู้เล่น', fallbackAvatar = '', rowData = null) {
    const modal = document.getElementById('modal-player-history');
    if (!modal) return;
    openModal('modal-player-history');

    // Reset view with loading state
    const nameEl = document.getElementById('ph-username');
    const avEl = document.getElementById('ph-avatar');
    const rankBadgeEl = document.getElementById('ph-rank-badge');
    const lvlBadgeEl = document.getElementById('ph-level-badge');
    const clanEl = document.getElementById('ph-clan');
    const tierEl = document.getElementById('ph-tier-text');
    const rpEl = document.getElementById('ph-rank-points');
    const listEl = document.getElementById('ph-matches-list');

    if (nameEl) nameEl.innerText = fallbackName || 'ผู้เล่น';
    if (avEl) avEl.src = fallbackAvatar || 'avatars/bots/bot_f01.jpg';
    if (rankBadgeEl) rankBadgeEl.innerText = rowData ? `#${rowData.ranking}` : '#1';
    if (lvlBadgeEl) lvlBadgeEl.innerText = `${rowData?.level_icon || '⭐'} Lv.${rowData?.level || 1}`;
    if (clanEl) clanEl.innerText = `สังกัด: ${rowData?.clan_name || '-'}`;
    if (tierEl) tierEl.innerText = rowData?.tier || 'BRONZE';
    if (rpEl) rpEl.innerText = `${Number(rowData?.rank_points || 1000).toLocaleString()} RP`;
    if (listEl) listEl.innerHTML = '<div style="color:#64748b; text-align:center; padding:30px;">⏳ กำลังโหลดประวัติการแข่งขันและสถิติ...</div>';

    let data = null;
    try {
        const uId = userId || DEFAULT_USER.id || 15;
        const res = await fetch(`api/leaderboard.php?type=player_history&user_id=${uId}`);
        data = await res.json();
    } catch(e) {
        console.warn('fetch player_history err:', e);
    }

    // รวมข้อมูล LocalStorage match history cache หากเป็นบัญชีของตนเอง
    const isMe = (userId === DEFAULT_USER.id || userId === 15 || !userId);
    let localMatches = [];
    if (isMe) {
        try {
            const raw = localStorage.getItem('snake_match_history_cache');
            if (raw) localMatches = JSON.parse(raw) || [];
        } catch(e) {}
    }

    if (!data || !data.player_profile) {
        data = {
            status: 'success',
            weekly_reset_info: {
                formatted_countdown: '4 วัน 23:30:00 ชม.',
                rule_description: 'แข่งจัดอันดับ 1 สัปดาห์ • รีเซ็ตทุกวันพุธ เวลา 10:00 น. ตรง'
            },
            player_profile: {
                user_id: userId,
                username: fallbackName,
                avatar_url: fallbackAvatar || 'avatars/bots/bot_f01.jpg',
                level: rowData?.level || 5,
                level_badge_title: rowData?.level_badge_title || 'อัศวินทองคำ (Gold)',
                level_icon: rowData?.level_icon || '🥇',
                clan_name: rowData?.clan_name || 'ไม่มีสังกัด',
                rank_points: rowData?.rank_points || 1500,
                ranking_place: rowData?.ranking || 1,
                tier: rowData?.tier || 'GOLD',
                total_matches: rowData?.total_matches || (localMatches.length || 5),
                total_wins: rowData?.total_wins || 3,
                total_losses: rowData?.total_losses || 2,
                win_rate: rowData?.win_rate || '60.00',
                is_rank_maintained: true
            },
            match_history: localMatches.length > 0 ? localMatches : []
        };
    } else if (localMatches.length > 0 && isMe) {
        const existingIds = new Set((data.match_history || []).map(m => m.match_id));
        const newLocal = localMatches.filter(m => !existingIds.has(m.match_id));
        data.match_history = [...newLocal, ...(data.match_history || [])];
    }

    currentPlayerHistoryData = data;
    currentHistoryFilterMode = 'ALL';
    renderPlayerHistoryModal(data);
};

window.filterPlayerHistoryMode = function(mode) {
    currentHistoryFilterMode = mode;
    document.querySelectorAll('.ph-mode-tab').forEach(btn => {
        btn.classList.toggle('active', btn.id === ('ph-tab-' + mode.toLowerCase()));
    });
    if (currentPlayerHistoryData) {
        renderPlayerHistoryMatches(currentPlayerHistoryData.match_history || []);
    }
};

function renderPlayerHistoryModal(data) {
    const p = data.player_profile || {};
    const reset = data.weekly_reset_info || {};

    const nameEl = document.getElementById('ph-username');
    const avEl = document.getElementById('ph-avatar');
    const rankBadgeEl = document.getElementById('ph-rank-badge');
    const lvlBadgeEl = document.getElementById('ph-level-badge');
    const clanEl = document.getElementById('ph-clan');
    const tierEl = document.getElementById('ph-tier-text');
    const rpEl = document.getElementById('ph-rank-points');
    const maintEl = document.getElementById('ph-maintenance-pill');
    const cdEl = document.getElementById('ph-season-reset-countdown');

    const totMatchesEl = document.getElementById('ph-total-matches');
    const totWinsEl = document.getElementById('ph-total-wins');
    const totLossesEl = document.getElementById('ph-total-losses');
    const winRateEl = document.getElementById('ph-win-rate');

    if (nameEl) nameEl.innerText = p.username || 'ผู้เล่น';
    if (avEl) avEl.src = p.avatar_url || 'avatars/bots/bot_f01.jpg';
    if (rankBadgeEl) rankBadgeEl.innerText = `#${p.ranking_place || 1}`;
    if (lvlBadgeEl) lvlBadgeEl.innerText = `${p.level_icon || '⭐'} Lv.${p.level || 1}`;
    if (clanEl) clanEl.innerText = `สังกัด: ${p.clan_name || 'ไม่มีสังกัด'}`;
    if (tierEl) tierEl.innerText = p.tier || 'BRONZE';
    if (rpEl) rpEl.innerText = `${Number(p.rank_points || 1000).toLocaleString()} RP`;

    if (maintEl) {
        const matchesCount = Number(p.total_matches || 0);
        if (p.is_rank_maintained || matchesCount >= 5) {
            maintEl.innerText = `🟢 รักษาระดับอันดับปลอดภัย (แข่งแล้ว ${matchesCount} แมตช์)`;
            maintEl.style.background = 'rgba(16,185,129,0.15)';
            maintEl.style.borderColor = 'rgba(16,185,129,0.4)';
            maintEl.style.color = '#10b981';
        } else {
            const need = Math.max(1, 5 - matchesCount);
            maintEl.innerText = `🟡 ต้องลงแข่งเพิ่มอีก ${need} แมตช์เพื่อรักษาอันดับ`;
            maintEl.style.background = 'rgba(245,158,11,0.15)';
            maintEl.style.borderColor = 'rgba(245,158,11,0.4)';
            maintEl.style.color = '#f59e0b';
        }
    }

    if (cdEl) cdEl.innerText = `เหลือเวลาอีก ${reset.formatted_countdown || '4 วัน 23 ชม.'}`;

    if (totMatchesEl) totMatchesEl.innerText = p.total_matches || 0;
    if (totWinsEl) totWinsEl.innerText = p.total_wins || 0;
    if (totLossesEl) totLossesEl.innerText = p.total_losses || 0;
    if (winRateEl) winRateEl.innerText = `${p.win_rate || '0.00'}%`;

    renderPlayerHistoryMatches(data.match_history || []);
}

function renderPlayerHistoryMatches(matches) {
    const listEl = document.getElementById('ph-matches-list');
    const countEl = document.getElementById('ph-history-count');
    if (!listEl) return;

    let filtered = matches || [];
    if (currentHistoryFilterMode !== 'ALL') {
        filtered = filtered.filter(m => {
            const mode = String(m.game_mode || '').toUpperCase();
            if (currentHistoryFilterMode === '4P') return mode === '4P' || (!mode.includes('1V1') && !mode.includes('2P') && !mode.includes('TEAM'));
            if (currentHistoryFilterMode === '2P') return mode === '2P' || mode === '1V1';
            if (currentHistoryFilterMode === 'TEAM') return mode === 'TEAM';
            return true;
        });
    }

    if (countEl) countEl.innerText = `(แสดง ${filtered.length} แมตช์)`;

    if (filtered.length === 0) {
        listEl.innerHTML = `
            <div style="background:rgba(15,23,42,0.6); border:1px dashed var(--panel-border); border-radius:12px; padding:30px; text-align:center; color:#64748b;">
                ยังไม่มีบันทึกประวัติการแข่งขันในหมวดหมู่นี้
            </div>
        `;
        return;
    }

    const fmtGold = (val) => {
        const n = Number(val) || 0;
        if (Math.abs(n) >= 1000000) return (n / 1000000).toFixed(2).replace(/\.00$/, '') + 'M';
        if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
        return n.toLocaleString();
    };

    listEl.innerHTML = filtered.map(m => {
        const isWin = Boolean(m.is_winner || m.rank_place === 1);
        const rankMedal = m.rank_place === 1 ? '🥇 อันดับ 1 (ชนะเลิศ)' : (m.rank_place === 2 ? '🥈 อันดับ 2 (รองชนะ)' : (m.rank_place === 3 ? '🥉 อันดับ 3' : '4️⃣ อันดับ 4 (พ่ายแพ้)'));
        const medalColor = m.rank_place === 1 ? '#ffd700' : (m.rank_place === 2 ? '#38bdf8' : (m.rank_place === 3 ? '#f472b6' : '#f43f5e'));

        let reasonText = '🏁 พิชิตเส้นชัยช่อง 100';
        if (m.win_reason === 'TIME_OUT') reasonText = '⏰ ชนะด้วยสินทรัพย์สูงสุด (หมดเวลา 10 นาที)';
        else if (m.win_reason === 'BANKRUPTCY') reasonText = '💥 คู่แข่งล้มละลาย (Bankruptcy Win)';

        const modeBadge = (m.game_mode === '2P' || m.game_mode === '1v1') ? '⚔️ เดี่ยว 2 (1v1)' : ((m.game_mode === 'TEAM') ? '👥 ทีม 2v2' : '🎮 เดี่ยว 4 (4P)');
        const dateStr = m.created_at ? new Date(m.created_at).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' }) : 'ล่าสุด';

        const rpSign = (m.rank_points_change >= 0) ? `+${m.rank_points_change}` : `${m.rank_points_change}`;
        const rpColor = (m.rank_points_change >= 0) ? '#10b981' : '#f43f5e';
        const goldSign = (m.gold_change >= 0) ? `+${fmtGold(m.gold_change)}` : `-${fmtGold(Math.abs(m.gold_change))}`;
        const goldColor = (m.gold_change >= 0) ? '#ffd700' : '#f43f5e';

        const players = Array.isArray(m.players) ? m.players : [];

        return `
            <div class="ph-match-card ${isWin ? 'is-winner-card' : ''}">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:8px;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:11px; font-weight:800; background:rgba(14,165,233,0.18); border:1px solid rgba(14,165,233,0.4); color:#38bdf8; padding:2px 8px; border-radius:6px;">${modeBadge}</span>
                        <span style="font-size:12px; font-weight:800; color:${medalColor};">${rankMedal}</span>
                    </div>
                    <div style="font-size:11px; color:#64748b;">${dateStr} • ${reasonText}</div>
                </div>

                <!-- Score & Gold Row -->
                <div style="display:flex; gap:16px; margin-bottom:12px; font-size:12px; font-weight:800;">
                    <div>
                        <span style="color:#94a3b8;">คะแนน RP:</span>
                        <span style="color:${rpColor}; margin-left:4px;">${rpSign} RP (รักษาอันดับ)</span>
                    </div>
                    <div>
                        <span style="color:#94a3b8;">ทองที่ได้/เสีย:</span>
                        <span style="color:${goldColor}; margin-left:4px;">${goldSign} ทอง</span>
                    </div>
                    ${m.total_assets ? `<div><span style="color:#94a3b8;">สินทรัพย์รวม:</span> <span style="color:#38bdf8; margin-left:4px;">${fmtGold(m.total_assets)}</span></div>` : ''}
                </div>

                <!-- 4 Players Breakdown Table (ใครชนะ ใครแพ้ อันดับ 1-4) -->
                ${players.length > 0 ? `
                    <div style="border-top:1px solid rgba(255,255,255,0.06); padding-top:8px;">
                        <div style="font-size:11px; font-weight:700; color:#94a3b8; margin-bottom:6px;">สรุปอันดับผู้เล่นในแมตช์นี้ (อันดับ 1 ถึง ${players.length}):</div>
                        ${players.map((p, idx) => {
                            const pRank = p.rank || (idx + 1);
                            const pRankTag = pRank === 1 ? '🥇 ที่ 1' : (pRank === 2 ? '🥈 ที่ 2' : (pRank === 3 ? '🥉 ที่ 3' : '4️⃣ ที่ 4'));
                            const pIsWin = Boolean(p.is_winner || pRank === 1);
                            const pAssets = p.total_assets ?? p.totalAssets ?? p.matchGold ?? 0;
                            const pAv = p.avatar_url || 'avatars/bots/bot_f01.jpg';
                            const pName = p.username || `ผู้เล่น #${pRank}`;

                            return `
                                <div class="ph-match-player-row ${pIsWin ? 'is-winner-row' : ''}">
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <span style="font-size:11px; font-weight:800; min-width:38px; color:${pRank === 1 ? '#ffd700' : '#94a3b8'};">${pRankTag}</span>
                                        <img src="${pAv}" alt="${pName}" style="width:22px; height:22px; border-radius:50%; object-fit:cover; border:1px solid #38bdf8;">
                                        <span style="font-weight:700; color:#fff;">${pName}</span>
                                        ${pIsWin ? '<span style="font-size:10px; font-weight:800; color:#ffd700; background:rgba(255,215,0,0.15); padding:1px 6px; border-radius:4px;">👑 ชนะเลิศ</span>' : ''}
                                    </div>
                                    <div style="text-align:right;">
                                        <span style="font-size:11px; color:#94a3b8;">สินทรัพย์รวม:</span>
                                        <strong style="color:#ffd700; font-size:12px; margin-left:4px;">${fmtGold(pAssets)}</strong>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
}

// --- Jail / Deserted Island Escape Actions ---
window.openJailModal = function(player) {
    const turnsEl = document.getElementById('jail-turns-count');
    if (turnsEl) turnsEl.innerText = player.jailTurns || 2;
    openModal('modal-jail');
};

window.jailTryRollDoubles = function() {
    closeModal('modal-jail');
    if (window.game) {
        window.game.clearTurnTimers();
        window.game.rollDice();
    }
};

window.jailPayBail = function(currency = 'DIAMOND') {
    const cost = (currency === 'DIAMOND') ? 50 : 50000;
    const player = window.game ? window.game.players[window.game.currentTurnIndex] : null;
    if (!player) return;

    showInGameConfirm(
        `ต้องการจ่าย ${cost.toLocaleString()} ${currency === 'DIAMOND' ? 'เพชร' : 'ทอง'} เพื่อหลบหนีออกจากเกาะร้างทันทีหรือไม่?`,
        async () => {
            if (currency === 'DIAMOND' && DEFAULT_USER.diamond < cost) {
                return showToast('เพชรไม่พอสำหรับจ่ายค่าประกันตัว!');
            }
            if (currency === 'GOLD' && DEFAULT_USER.gold < cost) {
                return showToast('ทองไม่พอสำหรับจ่ายค่าประกันตัว!');
            }
            player.jailTurns = 0;
            closeModal('modal-jail');
            window.game.logMessage(`🔓 ${player.username} จ่ายค่าประกันตัว ${cost.toLocaleString()} ${currency === 'DIAMOND' ? 'เพชร' : 'ทอง'} พ้นโทษเกาะร้างทันที!`, 'highlight');
            window.game.showSkillBanner(`🔓 พ้นโทษเกาะร้างทันที! สามารถทอยเต๋าได้เลย`);
            if (currency === 'DIAMOND') {
                await window.syncUserProgress({ diamond_delta: -cost });
            } else {
                await window.syncUserProgress({ gold_delta: -cost });
            }
            if (window.game) {
                window.game.beginTurn();
            }
        },
        'จ่ายค่าประกันตัวออกจากเกาะร้าง',
        '🔓'
    );
};

// ===================================================================
// Lucky Gamble Wheel System (ช่องเล่นเสี่ยงโชค ชิงเพชร & ทองคำ)
// ===================================================================
const WHEEL_SEGMENTS = [
    { label: '💎 500 เพชร', type: 'DIAMOND', amount: 500, color: '#0284c7', textCol: '#ffffff' },
    { label: '🪙 20,000 ทอง', type: 'GOLD', amount: 20000, color: '#f59e0b', textCol: '#000000' },
    { label: '💎 100 เพชร', type: 'DIAMOND', amount: 100, color: '#06b6d4', textCol: '#000000' },
    { label: '🪙 50,000 ทอง', type: 'GOLD', amount: 50000, color: '#d97706', textCol: '#ffffff' },
    { label: '💎 50 เพชร', type: 'DIAMOND', amount: 50, color: '#10b981', textCol: '#000000' },
    { label: '🪙 100,000 ทอง', type: 'GOLD', amount: 100000, color: '#eab308', textCol: '#000000' },
    { label: '💎 200 เพชร', type: 'DIAMOND', amount: 200, color: '#8b5cf6', textCol: '#ffffff' },
    { label: '🪙 30,000 ทอง', type: 'GOLD', amount: 30000, color: '#ec4899', textCol: '#ffffff' }
];

let isWheelSpinning = false;
let currentWheelRotation = 0;
let pendingWheelPlayer = null;
let gambleModalResolve = null;
let gambleAutoSpinTimer = null;
let gambleAutoSpinInterval = null;
let gambleAutoCloseTimer = null;
let gambleAutoCloseInterval = null;

function clearGambleTimers() {
    if (gambleAutoSpinTimer) {
        clearTimeout(gambleAutoSpinTimer);
        gambleAutoSpinTimer = null;
    }
    if (gambleAutoSpinInterval) {
        clearInterval(gambleAutoSpinInterval);
        gambleAutoSpinInterval = null;
    }
    if (gambleAutoCloseTimer) {
        clearTimeout(gambleAutoCloseTimer);
        gambleAutoCloseTimer = null;
    }
    if (gambleAutoCloseInterval) {
        clearInterval(gambleAutoCloseInterval);
        gambleAutoCloseInterval = null;
    }
}

function drawLuckyWheel() {
    const canvas = document.getElementById('lucky-wheel-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const numSegs = WHEEL_SEGMENTS.length;
    const arc = (2 * Math.PI) / numSegs;
    const cx = 110;
    const cy = 110;
    const r = 105;

    ctx.clearRect(0, 0, 220, 220);

    for (let i = 0; i < numSegs; i++) {
        const seg = WHEEL_SEGMENTS[i];
        const angle = i * arc;

        // Wedge
        ctx.beginPath();
        ctx.fillStyle = seg.color;
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, angle, angle + arc);
        ctx.lineTo(cx, cy);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Text
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(angle + arc / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = seg.textCol;
        ctx.font = 'bold 12px "Kanit", sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,0.6)';
        ctx.shadowBlur = 4;
        ctx.fillText(seg.label, r - 10, 4);
        ctx.restore();
    }
}

window.openLuckyGambleModal = function(player, isAuto = false) {
    return new Promise((resolve) => {
        clearGambleTimers();
        gambleModalResolve = resolve;
        pendingWheelPlayer = player;
        isWheelSpinning = false;

        const isAutoActive = Boolean(isAuto || (window.game && window.game.isAutoMode));

        const resBox = document.getElementById('gamble-result-box');
        const spinBtn = document.getElementById('btn-spin-wheel');
        const closeBtn = document.getElementById('btn-close-gamble');

        if (resBox) resBox.style.display = 'none';
        if (closeBtn) closeBtn.style.display = 'none';

        drawLuckyWheel();
        openModal('modal-lucky-gamble');

        // หากกำลังเล่นโหมด AUTO: ให้ระบบสุ่มหมุนวงล้ออัตโนมัติทันที ไม่ต้องรอกด
        if (isAutoActive) {
            if (spinBtn) {
                spinBtn.style.display = 'block';
                spinBtn.disabled = true;
                spinBtn.innerText = '⚡ โหมด AUTO: กำลังสุ่มวงล้ออัตโนมัติ...';
            }
            gambleAutoSpinTimer = setTimeout(() => {
                window.spinLuckyWheel(true, true);
            }, 350);
            return;
        }

        let secLeft = 5;
        if (spinBtn) {
            spinBtn.style.display = 'block';
            spinBtn.disabled = false;
            spinBtn.innerText = `🎲 กดหมุนวงล้อเสี่ยงโชค! (หมุนอัตโนมัติใน ${secLeft} วิ)`;
        }

        // นับถอยหลัง 5 วินาที หากผู้เล่นไม่กด ให้ระบบหมุนวงล้อเสี่ยงโชคแทนอัตโนมัติ
        gambleAutoSpinInterval = setInterval(() => {
            secLeft--;
            if (secLeft > 0 && spinBtn && !isWheelSpinning) {
                spinBtn.innerText = `🎲 กดหมุนวงล้อเสี่ยงโชค! (หมุนอัตโนมัติใน ${secLeft} วิ)`;
            } else {
                clearInterval(gambleAutoSpinInterval);
                gambleAutoSpinInterval = null;
            }
        }, 1000);

        gambleAutoSpinTimer = setTimeout(() => {
            if (!isWheelSpinning) {
                showToast('🎡 ครบ 5 วินาที ระบบหมุนวงล้อเสี่ยงโชคให้อัตโนมัติ!');
                window.spinLuckyWheel(true, true);
            }
        }, 5000);
    });
};

window.spinLuckyWheel = function(isAutoTriggered = false, isQuickAuto = false) {
    if (isWheelSpinning) return;
    isWheelSpinning = true;
    clearGambleTimers();

    const isAutoModeActive = Boolean(isQuickAuto || (window.game && window.game.isAutoMode));

    const spinBtn = document.getElementById('btn-spin-wheel');
    if (spinBtn) {
        spinBtn.disabled = true;
        spinBtn.innerText = (isAutoTriggered || isAutoModeActive) ? '⚡ โหมด AUTO: กำลังสุ่มวงล้ออัตโนมัติ...' : '🎡 กำลังหมุนวงล้อเสี่ยงโชค...';
    }

    const canvas = document.getElementById('lucky-wheel-canvas');
    const numSegs = WHEEL_SEGMENTS.length;
    const winningIndex = Math.floor(Math.random() * numSegs);
    const segArcDeg = 360 / numSegs;

    // Pointer is at TOP (270 deg). Calculate rotation so winning segment stops under pointer
    const segCenter = winningIndex * segArcDeg + segArcDeg / 2;
    const extraSpins = (5 + Math.floor(Math.random() * 3)) * 360;
    const targetDeg = extraSpins + (270 - segCenter);

    currentWheelRotation += targetDeg;
    if (canvas) {
        canvas.style.transform = `rotate(${currentWheelRotation}deg)`;
    }

    setTimeout(async () => {
        isWheelSpinning = false;
        const winner = WHEEL_SEGMENTS[winningIndex];
        const resBox = document.getElementById('gamble-result-box');
        const resText = document.getElementById('gamble-result-text');
        const closeBtn = document.getElementById('btn-close-gamble');

        if (resBox && resText) {
            resBox.style.display = 'block';
            resText.innerHTML = `🎉 ยินดีด้วย! คุณได้รับ <strong style="color:#ffd700;">${winner.label}</strong>`;
        }
        if (spinBtn) spinBtn.style.display = 'none';

        let closeSecLeft = 5;
        if (closeBtn) {
            closeBtn.style.display = 'block';
            closeBtn.innerText = `รับรางวัล & ปิดหน้าต่าง (${closeSecLeft} วิ)`;
        }

        if (typeof confetti === 'function') {
            confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
        }

        if (winner.type === 'DIAMOND') {
            await window.syncUserProgress({ diamond_delta: winner.amount });
        } else if (winner.type === 'GOLD') {
            await window.syncUserProgress({ gold_delta: winner.amount });
        }

        if (window.game) {
            window.game.logMessage(`🎰 ${pendingWheelPlayer ? pendingWheelPlayer.username : 'คุณ'} หมุนวงล้อเสี่ยงโชคได้รับ ${winner.label}!`, 'highlight');
            window.game.showSkillBanner(`🎉 รับรางวัล ${winner.label}!`);
        }

        // หากเล่นโหมด AUTO: ปิดหน้าต่างรับรางวัลและส่งต่อเทิร์นทันทีใน 1.2 วินาที
        if (isAutoModeActive) {
            if (closeBtn) {
                closeBtn.style.display = 'block';
                closeBtn.innerText = '⚡ AUTO: กำลังส่งต่อตาเดิน... (1 วิ)';
            }
            gambleAutoCloseTimer = setTimeout(() => {
                window.closeLuckyGambleModal();
            }, 1200);
            return;
        }

        // โหมดเล่นเอง: หากผู้เล่นยังไม่กดปิดหลังหมุนเสร็จ ให้ปิดหน้าต่างและส่งต่อเทิร์นให้อัตโนมัติใน 5 วินาที
        gambleAutoCloseInterval = setInterval(() => {
            closeSecLeft--;
            if (closeSecLeft > 0 && closeBtn) {
                closeBtn.innerText = `รับรางวัล & ปิดหน้าต่าง (${closeSecLeft} วิ)`;
            } else {
                clearInterval(gambleAutoCloseInterval);
                gambleAutoCloseInterval = null;
            }
        }, 1000);

        gambleAutoCloseTimer = setTimeout(() => {
            window.closeLuckyGambleModal();
        }, 5000);
    }, 3600);
};

window.closeLuckyGambleModal = function() {
    clearGambleTimers();
    isWheelSpinning = false;
    closeModal('modal-lucky-gamble');

    if (typeof gambleModalResolve === 'function') {
        const resFn = gambleModalResolve;
        gambleModalResolve = null;
        resFn();
    }
};


// ===================================================================
// Login & Initial Profile Setup System (เพศ ชาย/หญิง, ตัวละคร, ลูกเต๋า, ชื่อ >= 3)
// ===================================================================
let selectedGender = 'MALE';
let selectedStarterCharId = 1;
let selectedStarterDiceId = 1;

window.openAuthModal = function() {
    const input = document.getElementById('auth-input-username');
    if (input) {
        input.value = ''; // ALWAYS EMPTY! No prefilled names!
        input.placeholder = 'กรุณากรอกชื่อตัวละคร (ไทย/อังกฤษ/อักษรพิเศษ >= 3 ตัว)';
        const counter = document.getElementById('auth-name-counter');
        if (counter) counter.innerText = '0/30';
        const err = document.getElementById('auth-name-error');
        if (err) err.style.display = 'none';
        input.style.borderColor = 'var(--panel-border)';
    }

    const loginInput = document.getElementById('auth-login-key');
    if (loginInput) loginInput.value = '';

    if (window.switchAuthTab) {
        switchAuthTab('LOGIN');
    }

    openModal('modal-auth');
};

window.selectGender = function(gender) {
    selectedGender = gender;
    const btnMale = document.getElementById('btn-gender-male');
    const btnFemale = document.getElementById('btn-gender-female');

    if (btnMale && btnFemale) {
        if (gender === 'MALE') {
            btnMale.style.background = 'rgba(2,132,199,0.25)';
            btnMale.style.borderColor = '#0284c7';
            btnMale.style.color = '#fff';
            btnFemale.style.background = 'rgba(15,23,42,0.6)';
            btnFemale.style.borderColor = 'var(--panel-border)';
            btnFemale.style.color = '#94a3b8';
        } else {
            btnFemale.style.background = 'rgba(236,72,153,0.25)';
            btnFemale.style.borderColor = '#ec4899';
            btnFemale.style.color = '#fff';
            btnMale.style.background = 'rgba(15,23,42,0.6)';
            btnMale.style.borderColor = 'var(--panel-border)';
            btnMale.style.color = '#94a3b8';
        }
    }
};

window.selectStarterChar = function(charId) {
    selectedStarterCharId = charId;
    [1, 2, 3, 4].forEach(id => {
        const el = document.getElementById(`auth-char-${id}`);
        if (!el) return;
        if (id === charId) {
            el.style.background = 'rgba(245,158,11,0.15)';
            el.style.borderColor = '#ffd700';
            el.style.borderWidth = '2px';
        } else {
            el.style.background = 'rgba(15,23,42,0.6)';
            el.style.borderColor = 'var(--panel-border)';
            el.style.borderWidth = '1px';
        }
    });
};

window.selectStarterDice = function(diceId) {
    selectedStarterDiceId = diceId;
    [1, 2, 3].forEach(id => {
        const el = document.getElementById(`auth-dice-${id}`);
        if (!el) return;
        if (id === diceId) {
            el.style.background = 'rgba(0,229,255,0.15)';
            el.style.borderColor = '#00e5ff';
            el.style.borderWidth = '2px';
        } else {
            el.style.background = 'rgba(15,23,42,0.6)';
            el.style.borderColor = 'var(--panel-border)';
            el.style.borderWidth = '1px';
        }
    });
};

window.validateAuthNameInput = function() {
    const input = document.getElementById('auth-input-username');
    const counter = document.getElementById('auth-name-counter');
    const err = document.getElementById('auth-name-error');
    if (!input) return false;

    const val = input.value.trim();
    if (counter) counter.innerText = `${val.length}/30`;

    if (val.length < 3) {
        if (err) {
            err.style.display = 'block';
            err.innerText = '⚠️ ชื่อผู้เล่นต้องมีความยาวอย่างน้อย 3 ตัวอักษร';
        }
        input.style.borderColor = '#ef4444';
        return false;
    } else {
        if (err) err.style.display = 'none';
        input.style.borderColor = '#10b981';
        return true;
    }
};

window.submitAuthProfile = async function() {
    const input = document.getElementById('auth-input-username');
    const name = input ? input.value.trim() : '';

    if (!validateAuthNameInput() || name.length < 3) {
        showInGameAlert('กรุณากรอกชื่อผู้เล่นอย่างน้อย 3 ตัวอักษร (ภาษาไทย อังกฤษ หรืออักษรพิเศษได้)', 'ข้อมูลไม่ครบถ้วน', '⚠️');
        if (input) input.focus();
        return;
    }

    const payload = {
        auth_type: currentAuthLinkType,
        social_id: currentSocialProfile ? currentSocialProfile.id : null,
        username: name,
        gender: selectedGender,
        character_id: selectedStarterCharId,
        dice_id: selectedStarterDiceId,
        avatar_url: currentSocialProfile ? currentSocialProfile.avatar : (selectedGender === 'FEMALE' ? 'avatars/avatar_02.png' : 'avatars/avatar_01.png')
    };

    let userResult = null;
    try {
        if (window.apiClient) {
            const res = await apiClient.registerProfile(payload);
            if (res.status === 'success' && res.data) {
                userResult = res.data;
            }
        }
    } catch (e) {
        console.warn('Backend register failed, fallback to local session:', e);
    }

    if (!userResult) {
        userResult = {
            id: Date.now(),
            username: name,
            gender: selectedGender,
            character_id: selectedStarterCharId,
            dice_id: selectedStarterDiceId,
            avatar_url: selectedGender === 'FEMALE' ? 'avatars/avatar_02.png' : 'avatars/avatar_01.png',
            diamond: 2000,
            gold: 20000,
            level: 1,
            clan_name: 'บ้านพญานาคราช'
        };
        localStorage.setItem('snake_user_data', JSON.stringify(userResult));
        localStorage.setItem('snake_auth_token', 'local_token_' + Date.now());
    }

    Object.assign(DEFAULT_USER, userResult);
    updateUserBar(DEFAULT_USER);
    closeModal('modal-auth');

    // Update active player in 3D game if initialized
    if (window.game && window.game.players && window.game.players.length > 0) {
        window.game.players[0].username = userResult.username || name;
        if (window.game.updateActiveTurnUI) window.game.updateActiveTurnUI();
    }

    resumeOrStartGame(DEFAULT_USER);
    showToast(`🎉 ยินดีต้อนรับคุณ ${userResult.username || name} เข้าสู่เกมบันไดงู 3D!`);
    if (typeof confetti === 'function') {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
    }
};

window.logoutAction = function() {
    showInGameConfirm(
        'ต้องการออกจากระบบใช่หรือไม่?\n\nข้อมูลเพชร ทอง การ์ดไอเทม และความคืบหน้าทั้งหมดจะถูกบันทึกไว้ในบัญชีของคุณ เมื่อเข้าสู่ระบบใหม่ข้อมูลจะกลับมาเหมือนเดิม',
        async () => {
            // 1. บันทึกข้อมูลเพชร/ทอง และตำแหน่งกระดานล่าสุดลงฐานข้อมูลและ localStorage ของยูสเซอร์ก่อนออกจากระบบ
            try {
                if (window.game && typeof window.game.saveActiveSession === 'function') {
                    window.game.saveActiveSession();
                }
                const activeSessionRaw = localStorage.getItem('snake_active_session');
                if (activeSessionRaw && DEFAULT_USER && DEFAULT_USER.id) {
                    localStorage.setItem('snake_active_session_user_' + DEFAULT_USER.id, activeSessionRaw);
                }
                if (window.apiClient && window.apiClient.token && (DEFAULT_USER.diamond > 0 || DEFAULT_USER.gold > 0)) {
                    await window.apiClient.syncProgress({
                        diamond: Number(DEFAULT_USER.diamond || 0),
                        gold: Number(DEFAULT_USER.gold || 0),
                        level: Number(DEFAULT_USER.level || 1)
                    });
                }
            } catch (e) {
                console.warn('Pre-logout sync warning:', e);
            }

            if (window.apiClient) {
                try {
                    await window.apiClient.request('api/shop.php?action=set_offline', { method: 'POST' });
                } catch (e) {}
                window.apiClient.clearAuth();
            }
            if (typeof liff !== 'undefined' && isLiffInitialized && liff.isLoggedIn()) {
                try { liff.logout(); } catch (e) {}
            }
            localStorage.removeItem('game_session_token');
            localStorage.removeItem('snake_auth_token');
            localStorage.removeItem('snake_user_data');
            localStorage.removeItem('snake_guest_profile');
            localStorage.removeItem('snake_google_profile');
            localStorage.removeItem('snake_auth_provider');
            localStorage.removeItem('snake_equipped_frame_grade');
            localStorage.removeItem('snake_equipped_frame_aura');

            // ทำลายห้อง 3D และตัวละครเก่า ป้องกันภาพตัวละครและไอดีเดิมค้างเดินในห้อง
            if (window.clanHouse) {
                try { window.clanHouse.destroy(); } catch(e) {}
                window.clanHouse = null;
            }
            currentClanData = null;

            // รีเซ็ตตัวแปร State ผู้ใช้ทั้งหมด ป้องกันรูปและข้อมูลไอดีเก่าตกค้าง
            DEFAULT_USER.id = 0;
            DEFAULT_USER.username = 'ผู้เล่น';
            DEFAULT_USER.displayName = 'ผู้เล่น';
            DEFAULT_USER.name = 'ผู้เล่น';
            DEFAULT_USER.avatar_url = 'avatars/avatar_01.svg';
            delete DEFAULT_USER.picture;
            delete DEFAULT_USER.pictureUrl;
            delete DEFAULT_USER.google_id;
            delete DEFAULT_USER.line_id;
            DEFAULT_USER.auth_provider = '';
            DEFAULT_USER.clan_name = '-';
            DEFAULT_USER.diamond = 0;
            DEFAULT_USER.gold = 0;
            DEFAULT_USER.level = 1;

            showToast('🚪 บันทึกข้อมูลและออกจากระบบเรียบร้อยแล้ว');

            // Reset profile bar display while logged out (without overwriting server data)
            const loggedOutDisplay = {
                username: 'ยังไม่ได้เข้าสู่ระบบ',
                avatar_url: 'avatars/avatar_01.png',
                diamond: 0,
                gold: 0,
                level: 1,
                clan_name: '-'
            };
            const nameEl = document.getElementById('bar-username');
            const avatarEl = document.getElementById('bar-avatar');
            const diaEl = document.getElementById('bar-diamond');
            const goldEl = document.getElementById('bar-gold');
            const clanEl = document.getElementById('bar-clan-name');
            if (nameEl) nameEl.textContent = loggedOutDisplay.username;
            if (avatarEl) avatarEl.src = loggedOutDisplay.avatar_url;
            if (diaEl) diaEl.textContent = '0';
            if (goldEl) goldEl.textContent = '0';
            if (clanEl) clanEl.textContent = '-';

            // Clear active players from board view until login
            if (window.game) {
                window.game.players = [];
                const turnEl = document.getElementById('turn-status-text');
                if (turnEl) turnEl.innerText = 'กรุณาสร้าง ID หรือเข้าสู่ระบบเพื่อเริ่มเล่น';
            }

            setTimeout(() => {
                openAuthModal();
            }, 350);
        },
        'ยืนยันการออกจากระบบ',
        '🚪'
    );
};


let currentAuthLinkType = 'LINE';

window.switchAuthTab = function(tabName) {
    const regTab = document.getElementById('tab-btn-register');
    const logTab = document.getElementById('tab-btn-login');
    const regPanel = document.getElementById('auth-panel-register');
    const logPanel = document.getElementById('auth-panel-login');

    if (tabName === 'REGISTER') {
        if (regTab) {
            regTab.style.background = 'linear-gradient(135deg, #00e5ff, #0077ff)';
            regTab.style.color = '#000';
        }
        if (logTab) {
            logTab.style.background = 'transparent';
            logTab.style.color = '#94a3b8';
        }
        if (regPanel) regPanel.style.display = 'block';
        if (logPanel) logPanel.style.display = 'none';
    } else {
        if (logTab) {
            logTab.style.background = 'linear-gradient(135deg, #ffd700, #ff8c00)';
            logTab.style.color = '#000';
        }
        if (regTab) {
            regTab.style.background = 'transparent';
            regTab.style.color = '#94a3b8';
        }
        if (logPanel) logPanel.style.display = 'block';
        if (regPanel) regPanel.style.display = 'none';
        const loginInput = document.getElementById('auth-login-key');
        if (loginInput) loginInput.focus();
    }
};

let currentSocialProfile = null;
let activeSocialConnectSource = 'REGISTER'; // 'REGISTER' or 'LOGIN'

// Direct OAuth Navigation (No simulated popup modals)
window.connectLineAction = function(fromTab = 'LOGIN') {
    window.loginWithLineLiff();
};

window.connectGoogleAction = function(fromTab = 'LOGIN') {
    sessionStorage.setItem('active_oauth_provider', 'google');
    window.location.href = 'api/auth.php?action=login&provider=google';
};

// Event Listeners for login buttons
function bindOAuthEventListeners() {
    const btnLine = document.getElementById('btn-line') || document.querySelector('.btn-line');
    if (btnLine) {
        btnLine.onclick = function(e) {
            e.preventDefault();
            window.loginWithLineLiff();
        };
    }
    const btnGoogle = document.getElementById('btn-google') || document.querySelector('.btn-google');
    if (btnGoogle) {
        btnGoogle.onclick = function(e) {
            e.preventDefault();
            sessionStorage.setItem('active_oauth_provider', 'google');
            window.location.href = 'api/auth.php?action=login&provider=google';
        };
    }
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindOAuthEventListeners);
} else {
    bindOAuthEventListeners();
}

window.selectPresetLineProfile = function(name, avatar, socialId) {
    applyLineProfile(name, avatar, socialId);
};

window.confirmCustomLineConnect = function() {
    const input = document.getElementById('line-custom-name-input');
    const name = input ? input.value.trim() : '';
    if (!name || name.length < 2) {
        showInGameAlert('กรุณากรอกชื่อโปรไฟล์ LINE ของคุณอย่างน้อย 2 ตัวอักษร', 'ข้อมูลไม่ถูกต้อง', '⚠️');
        if (input) input.focus();
        return;
    }
    const socialId = 'line_' + Math.random().toString(36).substring(2, 10);
    applyLineProfile(name, 'avatars/avatar_01.png', socialId);
};

async function applyLineProfile(name, avatar, socialId) {
    closeModal('modal-line-connect');

    if (activeSocialConnectSource === 'LOGIN') {
        // Login or Auto-Register via backend API
        let userResult = null;
        let tokenResult = null;
        try {
            if (window.apiClient) {
                const res = await apiClient.loginWithLine(socialId, name);
                if (res.status === 'success' && res.token) {
                    tokenResult = res.token;
                    userResult = res.user || res.player || res.data;
                }
            }
        } catch(e) {
            console.warn('Backend LINE login error:', e);
        }

        // Fallback profile if offline/demo
        if (!userResult) {
            userResult = {
                id: Date.now(),
                username: name,
                avatar_url: avatar || 'avatars/avatar_01.png',
                diamond: 2000,
                gold: 20000,
                level: 1,
                clan_name: 'บ้านพญานาคราช',
                equipped_character_id: 1,
                equipped_dice_id: 1
            };
            tokenResult = 'line_tok_' + Date.now();
        }

        // 1. Save Session Token & User Profile to localStorage
        localStorage.setItem('snake_auth_token', tokenResult);
        localStorage.setItem('snake_user_data', JSON.stringify(userResult));
        if (window.apiClient) apiClient.setAuth(tokenResult, userResult);

        // 2. Update user state & UI top-bar (Gold & Diamond)
        Object.assign(DEFAULT_USER, userResult);
        updateProfileFromGoogleUser({
            ...userResult,
            name: name || userResult.username,
            picture: avatar || userResult.avatar_url,
            sub: socialId
        });
        updateUserBar(DEFAULT_USER);

        // 3. Close Auth Modal
        document.getElementById('modal-auth').style.display = 'none';

        // 4. Load 3D Game Board (Idle Standby until player chooses Practice or Room Match)
        resumeOrStartGame(DEFAULT_USER);

        // 5. Celebration Effects
        showToast(`🎉 เข้าสู่ระบบด้วย LINE: ${userResult.username} สำเร็จ! (รับ 💎 2,000 | 🪙 20,000)`);
        if (typeof confetti === 'function') {
            confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
        }
        return;
    }

    currentSocialProfile = {
        type: 'LINE',
        id: socialId,
        name: name,
        avatar: avatar
    };
    currentAuthLinkType = 'LINE';

    // Auto-fill username with fetched LINE name
    const input = document.getElementById('auth-input-username');
    if (input) {
        input.value = name;
        validateAuthNameInput();
    }

    updateConnectedBadgeUI();
    showToast(`🎉 ดึงข้อมูลจาก LINE: "${name}" มาแสดงในแบบฟอร์มเรียบร้อย!`);
}

window.selectPresetGoogleProfile = function(name, email, avatar, socialId) {
    applyGoogleProfile(name, email, avatar, socialId);
};

window.confirmCustomGoogleConnect = function() {
    const nameInput = document.getElementById('google-custom-name-input');
    const emailInput = document.getElementById('google-custom-email-input');
    const name = nameInput ? nameInput.value.trim() : '';
    const email = emailInput ? emailInput.value.trim() : '';

    if (!name || name.length < 2) {
        showInGameAlert('กรุณากรอกชื่อ Google Profile อย่างน้อย 2 ตัวอักษร', 'ข้อมูลไม่ถูกต้อง', '⚠️');
        if (nameInput) nameInput.focus();
        return;
    }

    const socialId = 'google_' + Math.random().toString(36).substring(2, 10);
    applyGoogleProfile(name, email || (name.toLowerCase().replace(/\s+/g, '') + '@gmail.com'), 'avatars/avatar_02.png', socialId);
};

async function applyGoogleProfile(name, email, avatar, socialId) {
    closeModal('modal-google-connect');

    if (activeSocialConnectSource === 'LOGIN') {
        let userResult = null;
        let tokenResult = null;
        try {
            if (window.apiClient) {
                const res = await apiClient.loginWithGoogle(socialId, name);
                if (res.status === 'success' && res.token) {
                    tokenResult = res.token;
                    userResult = res.user || res.player || res.data;
                }
            }
        } catch(e) {
            console.warn('Backend Google login error:', e);
        }

        if (!userResult) {
            userResult = {
                id: Date.now(),
                username: name,
                avatar_url: avatar || 'avatars/avatar_02.png',
                diamond: 2000,
                gold: 20000,
                level: 1,
                clan_name: 'บ้านพญานาคราช',
                equipped_character_id: 1,
                equipped_dice_id: 1
            };
            tokenResult = 'google_tok_' + Date.now();
        }

        // 1. Save Session Token & User Profile to localStorage
        localStorage.setItem('snake_auth_token', tokenResult);
        localStorage.setItem('snake_user_data', JSON.stringify(userResult));
        if (window.apiClient) apiClient.setAuth(tokenResult, userResult);

        // 2. Update user state & UI top-bar (Gold, Diamond, Google Name & Picture)
        Object.assign(DEFAULT_USER, userResult);
        updateProfileFromGoogleUser({
            ...userResult,
            name: name || userResult.username,
            picture: avatar || userResult.avatar_url,
            email: email || socialId,
            sub: socialId
        });
        updateUserBar(DEFAULT_USER);

        // 3. Close Auth Modal
        document.getElementById('modal-auth').style.display = 'none';

        // 4. Load 3D Game Board (Idle Standby until player chooses Practice or Room Match)
        resumeOrStartGame(DEFAULT_USER);

        // 5. Celebration Effects
        showToast(`🎉 เข้าสู่ระบบด้วย Google: ${userResult.username} สำเร็จ! (รับ 💎 2,000 | 🪙 20,000)`);
        if (typeof confetti === 'function') {
            confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
        }
        return;
    }

    currentSocialProfile = {
        type: 'GOOGLE',
        id: socialId,
        name: name,
        email: email,
        avatar: avatar
    };
    currentAuthLinkType = 'GOOGLE';

    const input = document.getElementById('auth-input-username');
    if (input) {
        input.value = name;
        validateAuthNameInput();
    }

    updateConnectedBadgeUI();
    showToast(`🎉 ดึงข้อมูลจาก Google: "${name}" มาแสดงในแบบฟอร์มเรียบร้อย!`);
}

window.disconnectSocialAuth = function() {
    currentSocialProfile = null;
    currentAuthLinkType = 'GUEST';

    const input = document.getElementById('auth-input-username');
    if (input) {
        input.value = '';
        validateAuthNameInput();
    }

    updateConnectedBadgeUI();
    showToast('⚡ ยกเลิกการเชื่อมต่อ เปลี่ยนเป็นไอดีทั่วไป');
};

function updateConnectedBadgeUI() {
    const box = document.getElementById('auth-connected-box');
    const hint = document.getElementById('auth-unconnected-hint');
    const btnLine = document.getElementById('link-btn-line');
    const btnGoogle = document.getElementById('link-btn-google');
    const btnGuest = document.getElementById('link-btn-guest');

    [btnLine, btnGoogle, btnGuest].forEach(btn => {
        if (!btn) return;
        btn.style.background = 'rgba(15,23,42,0.6)';
        btn.style.borderColor = 'var(--panel-border)';
        btn.style.color = '#94a3b8';
    });

    if (currentSocialProfile && currentSocialProfile.type === 'LINE') {
        if (btnLine) {
            btnLine.style.background = 'rgba(6,199,85,0.25)';
            btnLine.style.borderColor = '#06c755';
            btnLine.style.color = '#fff';
        }
        if (box) {
            box.style.display = 'block';
            box.innerHTML = `
                <div style="background: rgba(6, 199, 85, 0.15); border: 1.5px solid #06c755; border-radius: 10px; padding: 10px 14px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 0 15px rgba(6,199,85,0.2);">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <img src="${currentSocialProfile.avatar}" style="width: 36px; height: 36px; border-radius: 50%; border: 2px solid #06c755; object-fit: cover;">
                        <div>
                            <div style="font-size: 13px; font-weight: 700; color: #fff;">${currentSocialProfile.name}</div>
                            <div style="font-size: 11px; color: #86efac;">✓ บัญชี LINE เชื่อมต่อแล้ว (ID: ${currentSocialProfile.id.substring(0, 12)}...)</div>
                        </div>
                    </div>
                    <button type="button" onclick="disconnectSocialAuth()" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #cbd5e1; border-radius: 6px; padding: 4px 10px; font-size: 11px; cursor: pointer;">เปลี่ยน</button>
                </div>
            `;
        }
        if (hint) hint.style.display = 'none';
    } else if (currentSocialProfile && currentSocialProfile.type === 'GOOGLE') {
        if (btnGoogle) {
            btnGoogle.style.background = 'rgba(234,67,53,0.25)';
            btnGoogle.style.borderColor = '#4285f4';
            btnGoogle.style.color = '#fff';
        }
        if (box) {
            box.style.display = 'block';
            box.innerHTML = `
                <div style="background: rgba(66, 133, 244, 0.15); border: 1.5px solid #4285f4; border-radius: 10px; padding: 10px 14px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 0 15px rgba(66,133,244,0.2);">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <img src="${currentSocialProfile.avatar}" style="width: 36px; height: 36px; border-radius: 50%; border: 2px solid #4285f4; object-fit: cover;">
                        <div>
                            <div style="font-size: 13px; font-weight: 700; color: #fff;">${currentSocialProfile.name}</div>
                            <div style="font-size: 11px; color: #93c5fd;">✓ บัญชี Google: ${currentSocialProfile.email || 'เชื่อมต่อแล้ว'}</div>
                        </div>
                    </div>
                    <button type="button" onclick="disconnectSocialAuth()" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #cbd5e1; border-radius: 6px; padding: 4px 10px; font-size: 11px; cursor: pointer;">เปลี่ยน</button>
                </div>
            `;
        }
        if (hint) hint.style.display = 'none';
    } else {
        if (btnGuest) {
            btnGuest.style.background = 'rgba(255,215,0,0.15)';
            btnGuest.style.borderColor = '#ffd700';
            btnGuest.style.color = '#fff';
        }
        if (box) box.style.display = 'none';
        if (hint) {
            hint.style.display = 'block';
            hint.innerText = '⚡ ใช้งานแบบไอดีทั่วไป (บันทึกข้อมูลในเครื่องนี้)';
        }
    }
}

window.selectAuthLinkType = function(type) {
    if (type === 'LINE') {
        connectLineAction('REGISTER');
    } else if (type === 'GOOGLE') {
        connectGoogleAction('REGISTER');
    } else {
        currentSocialProfile = null;
        currentAuthLinkType = 'GUEST';
        updateConnectedBadgeUI();
    }
};

window.submitDirectLogin = async function() {
    const input = document.getElementById('auth-login-key');
    const loginKey = input ? input.value.trim() : '';

    if (!loginKey) {
        showInGameAlert('กรุณากรอกชื่อผู้เล่นหรือไอดีที่เคยสร้างไว้', 'กรุณากรอกข้อมูล', '⚠️');
        if (input) input.focus();
        return;
    }

    try {
        if (window.apiClient) {
            const res = await apiClient.loginByUsername(loginKey);
            if (res.status === 'success' && res.data) {
                // ล้างค่ารูปโปรไฟล์และ session เดิมของบัญชีก่อนหน้าทั้งหมด ป้องกันภาพเก่าติดค้าง
                delete DEFAULT_USER.picture;
                delete DEFAULT_USER.pictureUrl;
                delete DEFAULT_USER.google_id;
                delete DEFAULT_USER.line_id;
                localStorage.removeItem('snake_google_profile');
                localStorage.removeItem('snake_line_display_name');

                Object.assign(DEFAULT_USER, res.data);
                DEFAULT_USER.auth_provider = res.data.auth_provider || (res.data.line_id ? 'line' : (res.data.google_id ? 'google' : 'credentials'));
                DEFAULT_USER.avatar_url = res.data.avatar_url || res.data.picture || res.data.pictureUrl || 'avatars/avatar_01.svg';

                if (res.token) {
                    localStorage.setItem('snake_auth_token', res.token);
                    localStorage.setItem('game_session_token', res.token);
                    if (typeof apiClient.setToken === 'function') apiClient.setToken(res.token);
                }
                localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
                localStorage.setItem('snake_auth_provider', DEFAULT_USER.auth_provider);

                updateUserBar(DEFAULT_USER);
                document.getElementById('modal-auth').style.display = 'none';
                resumeOrStartGame(DEFAULT_USER);
                showToast(`🎉 ยินดีต้อนรับกลับ ${res.data.username}!`);
                if (window.game && window.game.players && window.game.players.length > 0) {
                    window.game.players[0].username = res.data.username;
                    if (window.game.updateActiveTurnUI) window.game.updateActiveTurnUI();
                }
                return;
            } else {
                showInGameAlert(res.message || 'ไม่พบบัญชีนี้ในระบบ', 'เข้าสู่ระบบไม่สำเร็จ', '❌');
                return;
            }
        }
    } catch (e) {
        console.warn('API login failed, checking local data:', e);
    }

    // Check if matching locally saved data
    const saved = localStorage.getItem('snake_user_data');
    if (saved) {
        try {
            const u = JSON.parse(saved);
            if (u.username.toLowerCase() === loginKey.toLowerCase()) {
                delete DEFAULT_USER.picture;
                delete DEFAULT_USER.pictureUrl;
                delete DEFAULT_USER.google_id;
                delete DEFAULT_USER.line_id;
                localStorage.removeItem('snake_google_profile');
                localStorage.removeItem('snake_line_display_name');

                Object.assign(DEFAULT_USER, u);
                DEFAULT_USER.avatar_url = u.avatar_url || 'avatars/avatar_01.svg';
                updateUserBar(DEFAULT_USER);
                document.getElementById('modal-auth').style.display = 'none';
                resumeOrStartGame(DEFAULT_USER);
                showToast(`🎉 ยินดีต้อนรับกลับ ${u.username}!`);
                return;
            }
        } catch (e) {}
    }

    showInGameAlert(`ไม่พบบัญชี '${loginKey}' ในระบบ กรุณาตรวจสอบหรือสร้าง ID ใหม่`, 'ไม่พบไอดี', '❌');
};

window.loginWithLineAction = async function() {
    showInGameConfirm(
        'ยืนยันการเข้าสู่ระบบด้วย LINE Login ใช่หรือไม่?',
        async () => {
            try {
                if (window.apiClient) {
                    const res = await apiClient.loginWithLine();
                    if (res.status === 'success' && res.data) {
                        Object.assign(DEFAULT_USER, res.data);
                        updateUserBar(DEFAULT_USER);
                        document.getElementById('modal-auth').style.display = 'none';
                        resumeOrStartGame(DEFAULT_USER);
                        showToast(`🎉 เข้าสู่ระบบ LINE สำเร็จ! ยินดีต้อนรับคุณ ${res.data.username}`);
                        return;
                    }
                }
            } catch (e) {}

            // Demo / fallback LINE login
            const demoLineUser = {
                id: Date.now(),
                username: 'ผู้เล่น LINE (User)',
                avatar_url: 'avatars/avatar_01.png',
                diamond: 2000,
                gold: 20000,
                level: 1,
                clan_name: 'บ้านพญานาคราช'
            };
            localStorage.setItem('snake_user_data', JSON.stringify(demoLineUser));
            localStorage.setItem('snake_auth_token', 'line_token_' + Date.now());
            Object.assign(DEFAULT_USER, demoLineUser);
            updateUserBar(DEFAULT_USER);
            document.getElementById('modal-auth').style.display = 'none';
            resumeOrStartGame(DEFAULT_USER);
            showToast('🟢 เข้าสู่ระบบด้วย LINE ID เรียบร้อยแล้ว!');
        },
        'เข้าสู่ระบบ LINE',
        '🟢'
    );
};

window.loginWithGoogleAction = async function() {
    showInGameConfirm(
        'ยืนยันการเข้าสู่ระบบด้วย Google Account ใช่หรือไม่?',
        async () => {
            try {
                if (window.apiClient) {
                    const res = await apiClient.loginWithGoogle();
                    if (res.status === 'success' && res.data) {
                        Object.assign(DEFAULT_USER, res.data);
                        updateUserBar(DEFAULT_USER);
                        document.getElementById('modal-auth').style.display = 'none';
                        resumeOrStartGame(DEFAULT_USER);
                        showToast(`🎉 เข้าสู่ระบบ Google สำเร็จ! ยินดีต้อนรับคุณ ${res.data.username}`);
                        return;
                    }
                }
            } catch (e) {}

            // Demo / fallback Google login
            const demoGoogleUser = {
                id: Date.now(),
                username: 'ผู้เล่น Google (User)',
                avatar_url: 'avatars/avatar_02.png',
                diamond: 2000,
                gold: 20000,
                level: 1,
                clan_name: 'บ้านมังกรทอง'
            };
            localStorage.setItem('snake_user_data', JSON.stringify(demoGoogleUser));
            localStorage.setItem('snake_auth_token', 'google_token_' + Date.now());
            Object.assign(DEFAULT_USER, demoGoogleUser);
            updateUserBar(DEFAULT_USER);
            document.getElementById('modal-auth').style.display = 'none';
            resumeOrStartGame(DEFAULT_USER);
            showToast('🔴 เข้าสู่ระบบด้วย Google ID เรียบร้อยแล้ว!');
        },
        'เข้าสู่ระบบ Google',
        '🔴'
    );
};


// ===================================================================
// OAuth Return Token Handler (เมื่อกลับมาจาก LINE หรือ Google OAuth)
// ===================================================================
// OAuth return handled by checkAuthOnStartup

// ===================================================================
// Profile & Avatar Management (แก้ไขชื่อ และ รูปโปรไฟล์ LINE / Google)
// ===================================================================
window.openProfileEditModal = function() {
    const user = DEFAULT_USER;
    const nameInput = document.getElementById('input-edit-username');
    const avatarInput = document.getElementById('input-edit-avatar-url');
    const previewImg = document.getElementById('edit-avatar-preview');

    if (nameInput) nameInput.value = (user.username && user.username !== 'ยังไม่ได้เข้าสู่ระบบ') ? user.username : '';
    if (avatarInput) avatarInput.value = (user.avatar_url && !user.avatar_url.includes('avatar_01.png')) ? user.avatar_url : '';
    if (previewImg) previewImg.src = user.avatar_url || 'avatars/avatar_01.svg';

    openModal('modal-profile-edit');
};

window.selectPresetAvatar = function(url) {
    const avatarInput = document.getElementById('input-edit-avatar-url');
    const previewImg = document.getElementById('edit-avatar-preview');
    if (avatarInput) avatarInput.value = url;
    if (previewImg) previewImg.src = url;
};

window.saveProfileEdit = async function() {
    const nameInput = document.getElementById('input-edit-username');
    const avatarInput = document.getElementById('input-edit-avatar-url');

    const newName = nameInput ? nameInput.value.trim() : '';
    let newAvatar = avatarInput ? avatarInput.value.trim() : '';
    if (!newAvatar) newAvatar = 'avatars/avatar_01.svg';

    if (!newName) {
        showToast('⚠️ กรุณากรอกชื่อผู้เล่น');
        return;
    }

    delete DEFAULT_USER.picture;
    delete DEFAULT_USER.pictureUrl;
    DEFAULT_USER.username = newName;
    DEFAULT_USER.displayName = newName;
    DEFAULT_USER.name = newName;
    DEFAULT_USER.avatar_url = newAvatar;

    updateUserBar(DEFAULT_USER);
    localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));

    // Update active player in 3D game
    if (window.game) {
        if (typeof window.game.updatePlayerPawnAvatar === 'function') {
            window.game.updatePlayerPawnAvatar(0, newAvatar, newName, DEFAULT_USER.auth_provider);
        }
        if (!window.game.isMatchActive && typeof window.game.setupIdlePreview === 'function') {
            window.game.setupIdlePreview(DEFAULT_USER);
        }
        if (window.game.players && window.game.players.length > 0) {
            window.game.players[0].username = newName;
            if (window.game.updateActiveTurnUI) window.game.updateActiveTurnUI();
        }
    }

    // Save to backend database
    if (window.apiClient) {
        try {
            await apiClient.request('api/auth.php', {
                method: 'POST',
                body: JSON.stringify({
                    action: 'update_profile',
                    username: newName,
                    avatar_url: newAvatar
                })
            });
        } catch (e) {
            console.warn('Update profile backend warning:', e);
        }
    }

    closeModal('modal-profile-edit');
    showToast(`🎉 บันทึกชื่อคุณ "${newName}" และรูปโปรไฟล์เรียบร้อยแล้ว!`);
};

// ===================================================================
// SYSTEM 1: CLAN / HOUSE / FAMILY SYSTEM (สมาชิกไม่เกิน 30 คน)
// ===================================================================
let currentClanData = null;
let clanChatPollInterval = null;

window.openClanModal = async function() {
    openModal('modal-clan');

    await loadClanData();

    // เปิดหน้าห้อง 3D (ทั้งผู้เล่นที่มีบ้าน และผู้เล่นที่เข้าบ้านพักส่วนกลาง Public Lounge)
    window.switchClanHouseTab('house');

    setTimeout(() => {
        if (!window.clanHouse && window.ClanHouse3D) {
            window.clanHouse = new ClanHouse3D('clan-house-canvas-container');
        }
        if (window.clanHouse) {
            window.clanHouse.updateRoomMembers(currentClanData || { has_clan: false }, DEFAULT_USER);
            window.clanHouse.onResize();
        }
    }, 80);
};

window.loadClanData = async function() {
    if (!window.apiClient) return;
    try {
        const res = await apiClient.request('api/shop.php?action=get_clan_info');
        if (res && res.status === 'success') {
            currentClanData = res;
            renderClanUI(res);
        }
    } catch(e) {
        console.warn('Load clan error:', e);
    }
};

window.switchClanHouseTab = function(tab) {
    const hasView = document.getElementById('clan-view-has-house');
    const noView = document.getElementById('clan-view-no-house');
    const hasClan = Boolean(currentClanData && currentClanData.has_clan && currentClanData.clan && (currentClanData.clan.clan_id || currentClanData.clan.clan_id_real));

    // เมื่อผู้ใช้กดปุ่ม 'ค้นหา / สร้างบ้านใหม่' ให้เปิดหน้า browse
    if (tab === 'browse') {
        if (hasView) hasView.style.display = 'none';
        if (noView) noView.style.display = 'block';
        window.switchClanNoHouseTab('join');
        return;
    }

    if (hasView) hasView.style.display = 'flex';
    if (noView) noView.style.display = 'none';

    const tabs = ['house', 'members', 'chat', 'requests', 'all-families'];
    tabs.forEach(t => {
        const btn = document.getElementById(`btn-clan-tab-${t}`);
        const view = document.getElementById(`clan-${t === 'house' ? 'house-tab-view' : t + '-tab-view'}`);
        if (btn) {
            if (t === tab) btn.classList.add('active');
            else btn.classList.remove('active');
        }
        if (view) {
            view.style.display = (t === tab) ? (t === 'house' ? 'flex' : 'block') : 'none';
        }
    });

    if (tab === 'all-families') {
        if (typeof window.renderAllClanFamiliesTab === 'function') {
            window.renderAllClanFamiliesTab();
        }
    } else if (tab === 'house') {
        scrollClanChatToBottom();
        if (!clanChatPollInterval) {
            clanChatPollInterval = setInterval(pollClanChat, 3500);
        }
        setTimeout(() => {
            if (!window.clanHouse && window.ClanHouse3D) {
                window.clanHouse = new ClanHouse3D('clan-house-canvas-container');
            }
            if (window.clanHouse) {
                window.clanHouse.updateRoomMembers(currentClanData || { has_clan: false }, DEFAULT_USER);
                window.clanHouse.onResize();
            }
        }, 60);
    } else if (tab === 'chat') {
        scrollClanChatToBottom();
        if (!clanChatPollInterval) {
            clanChatPollInterval = setInterval(pollClanChat, 3500);
        }
    } else {
        if (clanChatPollInterval) {
            clearInterval(clanChatPollInterval);
            clanChatPollInterval = null;
        }
    }
};

window.clanHouseMoveTo = function(spot) {
    if (!window.clanHouse) return;
    if (spot === 'sofa') window.clanHouse.moveToPosition(0, 4.3); // Sit comfortably on sofa cushion
    else if (spot === 'tv') window.clanHouse.moveToPosition(0, -6.5); // Watch TV
    else if (spot === 'center') window.clanHouse.moveToPosition(0, -2.8); // Center room clear of furniture
};

function renderClanUI(data) {
    const hasClan = Boolean(data.has_clan && data.clan && (data.clan.clan_id || data.clan.clan_id_real));
    const hasView = document.getElementById('clan-view-has-house');
    const noView = document.getElementById('clan-view-no-house');
    const browseBtn = document.getElementById('btn-clan-tab-browse');
    const headerActions = document.getElementById('clan-header-actions');
    const tabHouseBtn = document.getElementById('btn-clan-tab-house');
    const returnHouseBtn = document.getElementById('btn-return-house-3d');

    // บ้านพักส่วนกลาง (Public Lounge) สำหรับทุกคนร่วมเข้าได้ (ไม่ใช่บ้านประจำ)
    if (hasView) hasView.style.display = 'flex';
    if (noView) noView.style.display = 'none';

    if (returnHouseBtn) returnHouseBtn.style.display = 'inline-block';
    if (tabHouseBtn) {
        tabHouseBtn.style.display = 'inline-block';
        tabHouseBtn.innerHTML = hasClan ? '🏠 ห้องบ้าน 3D' : '🏠 ห้องพักส่วนกลาง 3D';
    }
    if (browseBtn) browseBtn.style.display = 'inline-block';
    if (headerActions) headerActions.style.display = 'flex';

    const c = hasClan ? data.clan : {
        clan_name: 'ห้องบ้านพักส่วนกลาง 3D (Lounge)',
        tag: 'PUBLIC',
        description: 'บ้านพักส่วนกลางสำหรับทุกคนร่วมเข้าได้ ไม่ใช่บ้านประจำ เป็นบ้านพักสำหรับคนที่ยังไม่มีบ้าน (และทุกคน) เข้ามาร่วมพูดคุย พบปะ แลกเปลี่ยน และเดินเล่นด้วยกันได้',
        leader_name: 'ระบบส่วนกลาง',
        clan_level: 1
    };

    if (true) {
        const nameEl = document.getElementById('clan-info-name');
        const tagEl = document.getElementById('clan-info-tag');
        const descEl = document.getElementById('clan-info-desc');
        const leaderEl = document.getElementById('clan-info-leader');
        const levelEl = document.getElementById('clan-info-level');
        const counterEl = document.getElementById('clan-members-counter');
        const onlineEl = document.getElementById('clan-online-counter');
        const tabCountEl = document.getElementById('tab-members-count');
        const roleBadgeEl = document.getElementById('clan-my-role-badge');
        const barClan = document.getElementById('bar-clan-name');

        const roleLabels = {
            'leader': '👑 หัวหน้าบ้าน',
            'co_leader': '🥈 รองหัวหน้า',
            'elder': '🥉 สมาชิกอาวุโส',
            'member': '👤 สมาชิกทั่วไป'
        };

        if (nameEl) nameEl.innerText = c.clan_name || 'บ้านของฉัน';
        if (tagEl) tagEl.innerText = '[' + (c.tag || 'HOME') + ']';
        if (descEl) descEl.innerText = c.description || 'สโลแกนประจำบ้าน';
        if (leaderEl) leaderEl.innerText = c.leader_name || (DEFAULT_USER.username || '-');
        if (levelEl) levelEl.innerText = 'Lv.' + (c.clan_level || 1);
        if (barClan && hasClan) barClan.innerText = c.clan_name || 'บ้านของฉัน';

        const myRole = hasClan ? (data.my_role || 'member') : 'guest';
        if (roleBadgeEl) {
            roleBadgeEl.innerText = hasClan ? (roleLabels[myRole] || '👤 สมาชิก') : '🏠 บ้านพักส่วนกลาง';
            if (myRole === 'leader') {
                roleBadgeEl.style.borderColor = '#f59e0b';
                roleBadgeEl.style.color = '#fbbf24';
            } else if (myRole === 'co_leader') {
                roleBadgeEl.style.borderColor = '#38bdf8';
                roleBadgeEl.style.color = '#38bdf8';
            } else {
                roleBadgeEl.style.borderColor = '#00e5ff';
                roleBadgeEl.style.color = '#00e5ff';
            }
        }

        const effectiveMembers = (hasClan && Array.isArray(data.members) && data.members.length > 0)
            ? data.members
            : [{
                id: DEFAULT_USER.id || 1,
                username: DEFAULT_USER.username || 'ผู้เล่น',
                avatar_url: DEFAULT_USER.avatar_url || DEFAULT_USER.picture || DEFAULT_USER.pictureUrl || 'avatars/google_avatar.png',
                clan_role: 'leader',
                level: DEFAULT_USER.level || 1,
                is_online: true
            }];

        const count = hasClan ? (data.members_count || effectiveMembers.length) : 1;
        const online = hasClan ? (data.online_count || 1) : 1;
        if (counterEl) counterEl.innerText = `${count}/30 คน`;
        if (onlineEl) onlineEl.innerText = `${online} คน`;
        if (tabCountEl) tabCountEl.innerText = count;

        // อัปเดตปุ่มออกจากบ้าน / ยุบบ้าน (ลบครอบครัว)
        const leaveBtn = document.getElementById('btn-clan-leave');
        if (leaveBtn) {
            if (!hasClan) {
                leaveBtn.innerHTML = '🔍 ค้นหา/สมัครเข้าบ้าน';
                leaveBtn.style.color = '#38bdf8';
                leaveBtn.style.borderColor = '#38bdf8';
                leaveBtn.style.background = 'rgba(56, 189, 248, 0.15)';
                leaveBtn.style.fontWeight = '700';
                leaveBtn.title = 'ค้นหาครอบครัวและสมัครเข้าบ้านประจำของคุณ';
                leaveBtn.onclick = () => window.switchClanHouseTab('browse');
            } else if (myRole === 'leader') {
                if (count <= 1) {
                    leaveBtn.innerHTML = '💥 ยุบบ้าน (ลบครอบครัว)';
                    leaveBtn.style.color = '#f87171';
                    leaveBtn.style.borderColor = '#ef4444';
                    leaveBtn.style.background = 'rgba(239,68,68,0.2)';
                    leaveBtn.style.fontWeight = '700';
                    leaveBtn.title = 'คุณเป็นสมาชิกคนเดียว สามารถยุบและลบบ้านนี้ได้';
                } else {
                    leaveBtn.innerHTML = '🚪 ยุบบ้าน (ต้องเหลือ 1 คน)';
                    leaveBtn.style.color = '#f59e0b';
                    leaveBtn.style.borderColor = '#f59e0b';
                    leaveBtn.style.background = 'rgba(245,158,11,0.15)';
                    leaveBtn.style.fontWeight = '700';
                    leaveBtn.title = `ยังมีสมาชิกอีก ${count-1} คน ต้องให้สมาชิกออกจนเหลือคนเดียวก่อนถึงจะยุบบ้านได้`;
                }
            } else {
                leaveBtn.innerHTML = '🚪 ออกจากบ้าน';
                leaveBtn.style.color = '#ef4444';
                leaveBtn.style.borderColor = 'rgba(239,68,68,0.4)';
                leaveBtn.style.background = 'transparent';
                leaveBtn.style.fontWeight = 'normal';
                leaveBtn.title = 'คลิกเพื่อออกจากบ้านนี้';
            }
        }
        // Leader Settings Box (เปิดรับสมาชิก อิสระ vs รออนุมัติ)
        const settingsBox = document.getElementById('clan-leader-settings-box');
        if (settingsBox) {
            if (hasClan && myRole === 'leader') {
                settingsBox.style.display = 'block';
                const radioFree = document.getElementById('radio-join-free');
                const radioApp = document.getElementById('radio-join-approval');
                if (radioFree) radioFree.checked = (data.join_type !== 'approval');
                if (radioApp) radioApp.checked = (data.join_type === 'approval');
            } else {
                settingsBox.style.display = 'none';
            }
        }

        // Requests Tab (สำหรับหัวหน้า / รองหัวหน้า)
        const reqTabBtn = document.getElementById('btn-clan-tab-requests');
        const reqTabCount = document.getElementById('tab-requests-count');
        const reqList = document.getElementById('clan-requests-list');
        const pending = data.pending_requests || [];

        if (hasClan && (myRole === 'leader' || myRole === 'co_leader')) {
            if (reqTabBtn) {
                reqTabBtn.style.display = 'inline-block';
                if (reqTabCount) reqTabCount.innerText = pending.length;
            }
            if (reqList) {
                if (pending.length === 0) {
                    reqList.innerHTML = '<div style="text-align:center; padding:24px; color:#94a3b8; font-size:12px;">ไม่มีคำขอเข้าร่วมบ้านในขณะนี้</div>';
                } else {
                    reqList.innerHTML = pending.map(r => `
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(30,41,59,0.7); border:1px solid rgba(255,255,255,0.08); padding:10px 14px; border-radius:10px; margin-bottom:8px;">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <img src="${r.avatar_url || 'avatars/google_avatar.png'}" style="width:38px; height:38px; border-radius:50%; object-fit:cover; border:1.5px solid #00e5ff;" onerror="this.src='avatars/google_avatar.png';">
                                <div>
                                    <div style="font-size:13px; font-weight:700; color:#fff;">${r.username}</div>
                                    <div style="font-size:11px; color:#94a3b8;">Lv.${r.level || 1} • ส่งคำขอเมื่อ: ${(r.created_at || '').substring(5, 16)}</div>
                                </div>
                            </div>
                            <div style="display:flex; gap:8px;">
                                <button class="btn btn-primary" onclick="respondClanRequestAction(${r.request_id}, 'approve', '${r.username}')" style="padding:6px 12px; font-size:11px; background:#10b981; color:#fff; border-radius:8px; cursor:pointer;">
                                    ✅ อนุมัติ
                                </button>
                                <button class="btn btn-secondary" onclick="respondClanRequestAction(${r.request_id}, 'reject', '${r.username}')" style="padding:6px 10px; font-size:11px; color:#ef4444; border-radius:8px; cursor:pointer;">
                                    ❌ ปฏิเสธ
                                </button>
                            </div>
                        </div>
                    `).join('');
                }
            }
        } else {
            if (reqTabBtn) reqTabBtn.style.display = 'none';
        }

        // Members Roster List with Online status, Role badge, Role adjustment & Kick buttons
        const listEl = document.getElementById('clan-members-list');
        if (listEl && effectiveMembers) {
            listEl.innerHTML = effectiveMembers.map((m, idx) => {
                const isSelf = m.id === (DEFAULT_USER.id || 15);
                const isLeader = m.clan_role === 'leader' || m.is_leader;
                const canManage = hasClan && ((myRole === 'leader' && !isLeader && !isSelf) || 
                                  (myRole === 'co_leader' && m.clan_role !== 'leader' && m.clan_role !== 'co_leader' && !isSelf));

                const roleBadgeHtml = `
                    <span style="font-size:10px; padding:2px 8px; border-radius:10px; font-weight:600; 
                        ${isLeader ? 'color:#ffd700; background:rgba(255,215,0,0.18); border:1px solid rgba(255,215,0,0.4);' : 
                          m.clan_role === 'co_leader' ? 'color:#38bdf8; background:rgba(56,189,248,0.18); border:1px solid rgba(56,189,248,0.4);' : 
                          m.clan_role === 'elder' ? 'color:#a78bfa; background:rgba(167,139,250,0.18); border:1px solid rgba(167,139,250,0.4);' : 
                          'color:#cbd5e1; background:rgba(255,255,255,0.08);'}">
                        ${roleLabels[m.clan_role] || '👤 สมาชิกทั่วไป'}
                    </span>
                `;

                const onlineDot = m.is_online ? 
                    `<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981; box-shadow:0 0 8px #10b981;" title="ออนไลน์"></span> <span style="font-size:10px; color:#34d399;">ออนไลน์</span>` : 
                    `<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#64748b;" title="ออฟไลน์"></span> <span style="font-size:10px; color:#64748b;">ออฟไลน์</span>`;

                let actionButtonsHtml = '';
                if (canManage) {
                    if (myRole === 'leader') {
                        actionButtonsHtml += `
                            <select onchange="changeClanMemberRole(${m.id}, this.value, '${m.username}')" style="background:#0f172a; border:1px solid rgba(0,229,255,0.3); color:#38bdf8; font-size:11px; padding:3px 6px; border-radius:6px; outline:none; cursor:pointer;">
                                <option value="" disabled selected>⚙️ ปรับระดับ...</option>
                                <option value="co_leader" ${m.clan_role === 'co_leader' ? 'selected' : ''}>🥈 รองหัวหน้า</option>
                                <option value="elder" ${m.clan_role === 'elder' ? 'selected' : ''}>🥉 สมาชิกอาวุโส</option>
                                <option value="member" ${m.clan_role === 'member' ? 'selected' : ''}>👤 สมาชิกทั่วไป</option>
                            </select>
                        `;
                    }
                    actionButtonsHtml += `
                        <button onclick="kickClanMemberAction(${m.id}, '${m.username}')" title="เตะออกจากบ้าน" style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.4); color:#ef4444; font-size:11px; padding:3px 8px; border-radius:6px; cursor:pointer;">
                            🚫 เตะออก
                        </button>
                    `;
                }

                return `
                    <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(15,23,42,0.65); border:1px solid rgba(255,255,255,0.06); padding:9px 12px; border-radius:10px; margin-bottom:6px;">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <span style="font-weight:700; color:#64748b; font-size:11px; width:22px;">#${idx + 1}</span>
                            <div style="position:relative;">
                                <img src="${m.avatar_url || 'avatars/google_avatar.png'}" style="width:38px; height:38px; border-radius:50%; object-fit:cover; border:1.5px solid ${m.is_online ? '#10b981' : '#475569'};" onerror="this.src='avatars/google_avatar.png';">
                                <span style="position:absolute; bottom:0; right:0; width:10px; height:10px; border-radius:50%; background:${m.is_online ? '#10b981' : '#64748b'}; border:1.5px solid #0f172a;"></span>
                            </div>
                            <div>
                                <div style="display:flex; align-items:center; gap:6px;">
                                    <span style="font-size:13px; font-weight:700; color:#fff;">${m.username}</span>
                                    ${isSelf ? '<span style="font-size:9px; background:#00e5ff; color:#000; font-weight:800; padding:1px 5px; border-radius:6px;">คุณ</span>' : ''}
                                    ${roleBadgeHtml}
                                </div>
                                <div style="display:flex; gap:8px; align-items:center; margin-top:2px;">
                                    <span style="font-size:10px; color:#94a3b8;">Lv.${m.level || 1} ⭐</span>
                                    <span style="font-size:10px; color:#475569;">•</span>
                                    ${onlineDot}
                                </div>
                            </div>
                        </div>
                        <div style="display:flex; gap:6px; align-items:center;">
                            ${actionButtonsHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Render Clan Chat Feed
        renderClanChatFeed(data.recent_messages || []);

        // Update 3D House Room (เฉพาะกรณีที่มีบ้านสังกัดอยู่จริงเท่านั้น)
        if (hasClan) {
            if (window.clanHouse) {
                window.clanHouse.updateRoomMembers({
                    ...data,
                    clan: c,
                    my_role: myRole,
                    members: effectiveMembers
                }, DEFAULT_USER);
                window.clanHouse.onResize();
            }
        } else {
            // หากยังไม่มีบ้าน หรืออยู่ระหว่างรออนุมัติ ให้ทำลายห้อง 3D ป้องกันตัวละครค้างเดินในห้อง
            if (window.clanHouse) {
                try { window.clanHouse.destroy(); } catch(e) {}
                window.clanHouse = null;
            }
        }
    }

    // อัปเดตรายการบ้านสำหรับแท็บค้นหา/สร้างบ้านใหม่ด้วยเสมอ
    // หน้าสำหรับคนไม่มีครอบครัว: แสดงครอบครัวบอทด้วย (สถานะ: ปิดรับสมัครสมาชิกบ้าน คนใหม่เข้าร่วมไม่ได้)
    // และบ้านผู้เล่นจริง (สถานะ: บ้านว่าง เข้าได้ ให้เข้าร่วมได้)
    const availList = document.getElementById('available-clans-list');
    if (availList) {
        // 1. ดึงบ้านผู้เล่นจริงจากเซิร์ฟเวอร์ (Human clans)
        const humanClans = (data.available_clans || []).map(c => ({
            ...c,
            is_bot: false
        }));

        // 2. ดึงบ้านระบบ / บอท 25 ครอบครัว (Bot clans)
        let botClans = [];
        if (typeof window.getAllClanFamilies === 'function') {
            botClans = window.getAllClanFamilies().map(bf => ({
                id: 'bot_' + bf.id,
                name: bf.name,
                tag: bf.tag,
                description: bf.slogan,
                leader_name: bf.leader,
                leader_avatar: (bf.members && bf.members[0] ? bf.members[0].avatar_url : 'avatars/google_avatar.png'),
                clan_level: bf.level,
                current_members: bf.members_count || 28,
                max_members: 30,
                is_bot: true,
                join_type: 'closed',
                members: (bf.members || []).slice(0, 5)
            }));
        }

        // จัดลำดับ: บ้านผู้เล่นจริงอยู่ด้านบน ตามด้วยบ้านระบบ/บอท
        const combinedClans = [...humanClans, ...botClans];

        // ตรวจสอบว่าผู้เล่นได้ส่งคำขอเข้าร่วมบ้านใดไว้หรือไม่ (สถานะรออนุมัติ)
        const pendingClan = combinedClans.find(c => (c.has_pending === true || c.has_pending === 1 || c.has_pending === '1'));
        let pendingBannerHtml = '';
        if (pendingClan) {
            pendingBannerHtml = `
                <div style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.22), rgba(180, 83, 9, 0.18)); border: 1.5px solid #f59e0b; border-radius: 14px; padding: 14px 18px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; box-shadow: 0 4px 18px rgba(245, 158, 11, 0.25);">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <span style="font-size: 30px;">⏳</span>
                        <div>
                            <div style="font-size: 14px; font-weight: 800; color: #fbbf24;">คำขอเข้าร่วมบ้านของคุณ: อยู่ระหว่าง "รอการอนุมัติ"</div>
                            <div style="font-size: 12px; color: #cbd5e1; margin-top: 3px;">คุณได้ส่งคำขอเข้าร่วมครอบครัว <strong style="color: #fff; font-size: 13px;">${pendingClan.name}</strong> เรียบร้อยแล้ว โปรดรอการอนุมัติจากหัวหน้าบ้าน หรือกดยกเลิกเพื่อเลือกบ้านอื่น</div>
                        </div>
                    </div>
                    <button class="btn btn-secondary" onclick="cancelClanRequestAction(${pendingClan.id})" style="padding: 8px 18px; font-size: 12px; font-weight: 700; color: #fca5a5; border: 1px solid rgba(239,68,68,0.5); background: rgba(239,68,68,0.2); border-radius: 20px; cursor: pointer; white-space: nowrap; transition: all 0.2s ease;">
                        ❌ ยกเลิกคำขอ
                    </button>
                </div>
            `;
        }

        if (combinedClans.length === 0) {
            availList.innerHTML = `
                <div style="text-align:center; padding:45px 20px; background:rgba(15,23,42,0.6); border:1.5px dashed rgba(255,255,255,0.15); border-radius:16px;">
                    <div style="font-size:46px; margin-bottom:10px;">🏰</div>
                    <div style="font-size:17px; font-weight:700; color:#fff; margin-bottom:6px;">ยังไม่มีครอบครัวที่เปิดรับสมาชิกในขณะนี้</div>
                    <div style="font-size:13px; color:#94a3b8; margin-bottom:18px;">คุณสามารถเป็นผู้นำ สร้างบ้านครอบครัวของคุณเองได้เลยทันที!</div>
                    <button class="btn btn-primary" onclick="switchClanNoHouseTab('create')" style="padding:12px 28px; font-size:14px; font-weight:800; border-radius:24px; background:linear-gradient(135deg, #818cf8, #6366f1); color:#fff; cursor:pointer; box-shadow:0 4px 18px rgba(99,102,241,0.45);">
                        🏰 สร้างครอบครัวใหม่ตอนนี้
                    </button>
                </div>
            `;
        } else {
            availList.innerHTML = pendingBannerHtml + combinedClans.map(cItem => {
                const isBot = Boolean(cItem.is_bot);
                const isApproval = (cItem.join_type === 'approval');
                const hasPending = (cItem.has_pending === true || cItem.has_pending === 1 || cItem.has_pending === '1');
                const isMyClan = Boolean(hasClan && (cItem.id == (data.clan?.clan_id || data.clan?.clan_id_real || data.clan?.id)));

                // 1. ปุ่มสมัครเข้าบ้าน / ย้ายบ้าน / ปิดรับสมัคร
                let btnActionHtml = '';
                if (isBot) {
                    // บ้านบอท: สถานะปิดรับสมัครสมาชิกบ้าน คนใหม่จะเข้าร่วมไม่ได้
                    btnActionHtml = `
                        <button class="btn-clan-join-action" onclick="showBotClanClosedAlert('${cItem.name}')" style="padding:9px 20px; font-size:12.5px; font-weight:800; background:rgba(239,68,68,0.15); color:#fca5a5; border:1.5px solid rgba(239,68,68,0.55); border-radius:25px; cursor:not-allowed; box-shadow:0 2px 10px rgba(239,68,68,0.2); display:inline-flex; align-items:center; gap:6px; white-space:nowrap;" title="ครอบครัวนี้เป็นบ้านระบบ (AI/บอท) ปิดรับสมัครสมาชิกบ้าน">
                            <span>🔒</span> ปิดรับสมัคร
                        </button>
                    `;
                } else if (isMyClan) {
                    btnActionHtml = `
                        <span style="padding:8px 18px; font-size:12px; font-weight:800; background:rgba(99,102,241,0.22); border:1.5px solid #818cf8; color:#c7d2fe; border-radius:25px; display:inline-flex; align-items:center; gap:6px; white-space:nowrap;">
                            🏡 บ้านปัจจุบันของคุณ
                        </span>
                    `;
                } else if (hasClan) {
                    // ผู้เล่นมีบ้านอยู่แล้วแต่กำลังดูบ้านคนอื่น (ที่ไม่ใช่บอท) -> มีปุ่มย้ายมาบ้านนี้
                    btnActionHtml = `
                        <button class="btn-clan-join-action" onclick="switchClanAction(${cItem.id}, '${cItem.name}')" style="padding:9px 20px; font-size:13px; font-weight:800; background:linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color:#ffffff; border:1.5px solid #818cf8; border-radius:25px; cursor:pointer; box-shadow:0 4px 16px rgba(99,102,241,0.45); display:inline-flex; align-items:center; gap:8px; white-space:nowrap; transition:transform 0.15s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                            <span>🔄</span> ย้ายมาบ้านนี้
                        </button>
                    `;
                } else {
                    // ผู้เล่นยังไม่มีบ้าน และเป็นบ้านผู้เล่นจริง -> สมัครเข้าได้ทันที
                    if (hasPending) {
                        btnActionHtml = `
                            <button class="btn-clan-join-action" onclick="cancelClanRequestAction(${cItem.id})" style="padding:9px 18px; font-size:12px; font-weight:800; background:rgba(245,158,11,0.25); border:1.5px solid #f59e0b; color:#fbbf24; border-radius:25px; cursor:pointer; display:inline-flex; align-items:center; gap:6px; white-space:nowrap;" title="คลิกเพื่อยกเลิกคำขอ">
                                <span>⏳</span> ส่งคำขอแล้ว (รออนุมัติ)
                            </button>
                        `;
                    } else if (isApproval) {
                        btnActionHtml = `
                            <button class="btn-clan-join-action" onclick="joinClanAction(${cItem.id}, '${cItem.name}')" style="padding:9px 22px; font-size:13px; font-weight:800; background:linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color:#ffffff; border:1.5px solid #fbbf24; border-radius:25px; cursor:pointer; box-shadow:0 4px 18px rgba(245,158,11,0.45); display:inline-flex; align-items:center; gap:8px; white-space:nowrap; transition:transform 0.15s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <span>📝</span> สมัครเข้าบ้าน <span style="font-size:11px; color:#fef3c7;">(รออนุมัติ)</span>
                            </button>
                        `;
                    } else {
                        btnActionHtml = `
                            <button class="btn-clan-join-action" onclick="joinClanAction(${cItem.id}, '${cItem.name}')" style="padding:9px 24px; font-size:13px; font-weight:800; background:linear-gradient(135deg, #10b981 0%, #059669 100%); color:#ffffff; border:1.5px solid #34d399; border-radius:25px; cursor:pointer; box-shadow:0 4px 20px rgba(16,185,129,0.5); display:inline-flex; align-items:center; gap:8px; white-space:nowrap; transition:transform 0.15s ease;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <span>✨</span> สมัครเข้าบ้าน 🚀
                            </button>
                        `;
                    }
                }

                // 2. สถานะรับสมัคร: บอทให้แสดง "ปิดรับสมัครสมาชิกบ้าน" / ผู้เล่นจริงแสดง "บ้านว่าง เข้าได้"
                const statusBadgeHtml = isBot
                    ? `<span style="font-size:11.5px; padding:3px 10px; border-radius:8px; font-weight:700; color:#ef4444; background:rgba(239,68,68,0.18); border:1px solid rgba(239,68,68,0.45); display:inline-flex; align-items:center; gap:5px;">
                        ⛔ ปิดรับสมัครสมาชิกบ้าน
                       </span>
                       <span style="font-size:10px; padding:2px 6px; border-radius:6px; font-weight:700; color:#94a3b8; background:rgba(148,163,184,0.15); border:1px solid rgba(148,163,184,0.3);">
                        🤖 บ้านระบบ
                       </span>`
                    : `<span style="font-size:11.5px; padding:3px 10px; border-radius:8px; font-weight:700; color:#34d399; background:rgba(16,185,129,0.18); border:1px solid rgba(16,185,129,0.45); display:inline-flex; align-items:center; gap:5px;">
                        🟢 บ้านว่าง เข้าได้
                       </span>
                       ${isApproval ? '<span style="font-size:10px; color:#fbbf24; background:rgba(245,158,11,0.2); border:1px solid rgba(245,158,11,0.4); padding:2px 6px; border-radius:6px;">🟡 รออนุมัติ</span>' : '<span style="font-size:10px; color:#38bdf8; background:rgba(56,189,248,0.2); border:1px solid rgba(56,189,248,0.4); padding:2px 6px; border-radius:6px;">⚡ เข้าได้ทันที</span>'}`;

                return `
                    <div class="item-card-row" style="display:flex; justify-content:space-between; align-items:center; background:rgba(15,23,42,0.85); border:1.5px solid ${isBot ? 'rgba(239,68,68,0.25)' : 'rgba(129,140,248,0.25)'}; padding:14px 20px; border-radius:14px; margin-bottom:12px; box-shadow:0 4px 18px rgba(0,0,0,0.45); gap:16px;">
                        <!-- ข้อมูลบ้านฝั่งซ้าย (ไม่มีรูปสมาชิก แสดงข้อมูลกระชับพอดีหน้าจอ) -->
                        <div style="display:flex; align-items:center; gap:14px; flex:1; min-width:240px;">
                            <div style="width:48px; height:48px; border-radius:12px; background:linear-gradient(135deg, ${isBot ? 'rgba(239,68,68,0.25), rgba(244,63,94,0.15)' : 'rgba(99,102,241,0.35), rgba(0,229,255,0.25)'}); border:1.5px solid ${isBot ? '#ef4444' : '#00e5ff'}; display:flex; align-items:center; justify-content:center; font-size:26px; flex-shrink:0; box-shadow:0 0 14px ${isBot ? 'rgba(239,68,68,0.2)' : 'rgba(0,229,255,0.25)'};">
                                🏡
                            </div>
                            <div style="flex:1;">
                                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                    <span style="font-size:15.5px; font-weight:800; color:#fff;">${cItem.name}</span>
                                    <span class="badge" style="background:#6366f1; color:#fff; font-size:11px; padding:2px 8px; border-radius:8px;">[${cItem.tag || 'CLAN'}]</span>
                                    ${statusBadgeHtml}
                                </div>
                                <div style="font-size:12px; color:#cbd5e1; margin-top:3px; max-width:650px;">
                                    ${cItem.description || 'สโลแกนประจำบ้าน'}
                                </div>
                                <div style="font-size:11px; color:#94a3b8; margin-top:4px; display:flex; gap:14px; flex-wrap:wrap;">
                                    <span>👑 หัวหน้า: <strong style="color:#ffd700;">${cItem.leader_name || '-'}</strong></span>
                                    <span>👥 สมาชิก: <strong style="color:#38bdf8;">${cItem.current_members || 1}/30 คน</strong></span>
                                    <span>⭐ เลเวล: <strong style="color:#a78bfa;">Lv.${cItem.clan_level || 1}</strong></span>
                                </div>
                            </div>
                        </div>

                        <!-- ฝั่งขวา: ปุ่มสมัครเข้าบ้าน / ย้ายบ้าน / ปิดรับสมัคร -->
                        <div style="flex-shrink:0; display:flex; align-items:center; justify-content:flex-end;">
                            ${btnActionHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }
    }
}

function renderClanChatFeed(messages) {
    const feed = document.getElementById('clan-chat-feed');
    const roomOverlayFeed = document.getElementById('clan-room-chat-feed');

    const roleBadgeChat = {
        'leader': '<span style="color:#ffd700; font-size:9px; background:rgba(255,215,0,0.15); padding:1px 5px; border-radius:6px; margin-left:4px;">👑 หัวหน้า</span>',
        'co_leader': '<span style="color:#38bdf8; font-size:9px; background:rgba(56,189,248,0.15); padding:1px 5px; border-radius:6px; margin-left:4px;">🥈 รอง</span>',
        'elder': '<span style="color:#a78bfa; font-size:9px; background:rgba(167,139,250,0.15); padding:1px 5px; border-radius:6px; margin-left:4px;">🥉 อาวุโส</span>',
        'member': ''
    };

    if (feed) {
        if (!messages || messages.length === 0) {
            feed.innerHTML = '<div style="text-align:center; padding:30px; color:#64748b; font-size:12px;">ยังไม่มีข้อความแชท เริ่มต้นพูดคุยกับลูกทีมในบ้านได้เลย!</div>';
        } else {
            feed.innerHTML = messages.map(m => {
                const isSelf = m.user_id === (DEFAULT_USER.id || 15);
                const timeStr = m.created_at ? m.created_at.substring(11, 16) : '';
                return `
                    <div style="display:flex; gap:8px; ${isSelf ? 'flex-direction:row-reverse;' : ''} align-items:flex-start;">
                        <img src="${m.avatar_url || 'avatars/google_avatar.png'}" style="width:30px; height:30px; border-radius:50%; object-fit:cover; border:1px solid #00e5ff; flex-shrink:0;" onerror="this.src='avatars/google_avatar.png';">
                        <div style="max-width:75%;">
                            <div style="display:flex; align-items:center; gap:4px; ${isSelf ? 'justify-content:flex-end;' : ''} margin-bottom:2px;">
                                <span style="font-size:11px; font-weight:700; color:#cbd5e1;">${m.username}</span>
                                ${roleBadgeChat[m.clan_role] || ''}
                                <span style="font-size:9px; color:#64748b;">${timeStr}</span>
                            </div>
                            <div style="padding:8px 12px; border-radius:12px; font-size:12px; line-height:1.4; word-break:break-word;
                                ${isSelf ? 'background:linear-gradient(135deg, #0284c7, #0369a1); color:#fff; border-top-right-radius:2px;' : 'background:rgba(30,41,59,0.9); color:#f1f5f9; border-top-left-radius:2px; border:1px solid rgba(255,255,255,0.08);'}">
                                ${m.message}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }
    }

    // อัปเดตกล่องแชทพื้นหลังจางด้านขวาของห้องบ้าน 3D (ตัวหนังสือเล็กแต่เด่นคมชัด)
    if (roomOverlayFeed) {
        if (!messages || messages.length === 0) {
            roomOverlayFeed.innerHTML = `
                <div class="clan-room-chat-item">
                    <div>
                        <span class="chat-sender">🏡 ระบบห้อง 3D:</span>
                        <span class="chat-text">ยินดีต้อนรับ! พิมพ์ข้อความหรือกด 😊 ส่งอิโมจิพูดคุยในห้องได้เลย</span>
                    </div>
                </div>
            `;
        } else {
            roomOverlayFeed.innerHTML = messages.map(m => {
                const isSelf = m.user_id === (DEFAULT_USER.id || 15);
                const timeStr = m.created_at ? m.created_at.substring(11, 16) : '';
                const formattedMsg = String(m.message || '')
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/(@[^\s]+)/g, '<span style="color:#38bdf8; background:rgba(56,189,248,0.18); padding:0 5px; border-radius:6px; font-weight:800;">$1</span>');
                return `
                    <div class="clan-room-chat-item ${isSelf ? 'is-self' : ''}">
                        <img src="${m.avatar_url || 'avatars/google_avatar.png'}" style="width:20px; height:20px; border-radius:50%; object-fit:cover; border:1px solid #00e5ff; flex-shrink:0; margin-top:1px;" onerror="this.src='avatars/google_avatar.png';">
                        <div style="flex:1; min-width:0;">
                            <span class="chat-sender">${m.username}:</span>
                            <span class="chat-text">${formattedMsg}</span>
                            ${timeStr ? `<span class="chat-time">${timeStr}</span>` : ''}
                        </div>
                    </div>
                `;
            }).join('');
        }
        roomOverlayFeed.scrollTop = roomOverlayFeed.scrollHeight;
    }

    scrollClanChatToBottom();
}

function scrollClanChatToBottom() {
    const feed = document.getElementById('clan-chat-feed');
    if (feed) feed.scrollTop = feed.scrollHeight;
    const roomOverlayFeed = document.getElementById('clan-room-chat-feed');
    if (roomOverlayFeed) roomOverlayFeed.scrollTop = roomOverlayFeed.scrollHeight;
}

let localClanRoomMessages = [];

window.submitClanChatText = async function(rawText) {
    const msg = String(rawText || '').trim();
    if (!msg) return;

    // 1. แสดง Speech Bubble ลอยบนหัวตัวละครในห้องบ้าน 3D ทันที
    if (window.clanHouse && typeof window.clanHouse.showPawnSpeechBubble === 'function') {
        window.clanHouse.showPawnSpeechBubble(msg, 4000);
    }

    // 2. เพิ่มข้อความลงในรายการแชทด้านขวาของห้อง 3D ทันที (Optimistic UI)
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newEntry = {
        user_id: DEFAULT_USER.id || 15,
        username: DEFAULT_USER.displayName || DEFAULT_USER.name || DEFAULT_USER.username || 'คุณ',
        avatar_url: DEFAULT_USER.avatar_url || DEFAULT_USER.picture || DEFAULT_USER.pictureUrl || 'avatars/google_avatar.png',
        clan_role: (currentClanData && currentClanData.my_role) || 'leader',
        message: msg,
        created_at: `2026-11-04 ${timeStr}:00`
    };

    if (currentClanData && Array.isArray(currentClanData.recent_messages)) {
        currentClanData.recent_messages.push(newEntry);
        renderClanChatFeed(currentClanData.recent_messages);
    } else {
        localClanRoomMessages.push(newEntry);
        renderClanChatFeed(localClanRoomMessages);
    }

    // 3. ส่งไปบันทึกที่เซิร์ฟเวอร์ (กรณีมีบ้านสังกัด)
    if (window.apiClient) {
        try {
            const res = await apiClient.request('api/shop.php', {
                method: 'POST',
                body: JSON.stringify({
                    action: 'send_clan_message',
                    message: msg
                })
            });
            if (res && res.status === 'success') {
                await pollClanChat();
            }
        } catch(e) {
            console.warn('Clan room chat sync warning:', e);
        }
    }
};

window.sendClanChatMessage = async function() {
    const input = document.getElementById('input-clan-chat-msg');
    if (!input) return;
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    await window.submitClanChatText(msg);
};

window.sendClanRoomOverlayChat = async function() {
    const input = document.getElementById('input-clan-room-chat');
    if (!input) return;
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    window.toggleClanRoomEmojiPopover(true);
    await window.submitClanChatText(msg);
};

window.toggleClanRoomEmojiPopover = function(forceClose = false) {
    const pop = document.getElementById('clan-room-emoji-popover');
    if (!pop) return;
    if (forceClose === true) {
        pop.style.display = 'none';
        return;
    }
    const isShowing = pop.style.display !== 'none' && pop.style.display !== '';
    pop.style.display = isShowing ? 'none' : 'block';
};

window.sendClanRoomEmoji = async function(emoji) {
    if (!emoji) return;
    if (typeof window.recordRecentEmoji === 'function') {
        window.recordRecentEmoji(emoji);
    }
    window.toggleClanRoomEmojiPopover(true);
    await window.submitClanChatText(emoji);
};

async function pollClanChat() {
    try {
        const res = await apiClient.request('api/shop.php?action=get_clan_messages');
        if (res && res.status === 'success' && res.messages) {
            renderClanChatFeed(res.messages);
        }
    } catch(e) {}
}

window.changeClanMemberRole = function(targetId, newRole, username) {
    if (!newRole) return;
    const roleLabels = {
        'co_leader': '🥈 รองหัวหน้า',
        'elder': '🥉 สมาชิกอาวุโส',
        'member': '👤 สมาชิกทั่วไป'
    };
    showInGameConfirm(
        `ต้องการปรับระดับของคุณ '${username}' เป็น ${roleLabels[newRole]} ใช่หรือไม่?`,
        async () => {
            try {
                const res = await apiClient.request('api/shop.php', {
                    method: 'POST',
                    body: JSON.stringify({
                        action: 'update_member_role',
                        target_user_id: targetId,
                        new_role: newRole
                    })
                });
                if (res && res.status === 'success') {
                    showToast('🎉 ' + res.message);
                    await loadClanData();
                } else {
                    showInGameAlert(res.message || 'ไม่สามารถปรับตำแหน่งได้', 'แจ้งเตือน', '⚠️');
                }
            } catch(e) {
                showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
            }
        },
        'ยืนยันการปรับระดับลูกทีม',
        '⚙️'
    );
};

window.kickClanMemberAction = function(targetId, username) {
    showInGameConfirm(
        `คำเตือน: คุณต้องการเตะ '${username}' ออกจากครอบครัวใช่หรือไม่?`,
        async () => {
            try {
                const res = await apiClient.request('api/shop.php', {
                    method: 'POST',
                    body: JSON.stringify({
                        action: 'kick_clan_member',
                        target_user_id: targetId
                    })
                });
                if (res && res.status === 'success') {
                    showToast('🚫 ' + res.message);
                    await loadClanData();
                } else {
                    showInGameAlert(res.message || 'ไม่สามารถเตะสมาชิกได้', 'แจ้งเตือน', '⚠️');
                }
            } catch(e) {
                showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
            }
        },
        'ยืนยันเตะลูกทีมออกจากบ้าน',
        '🚫'
    );
};

window.changeClanJoinType = async function(joinType) {
    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'set_clan_join_type',
                join_type: joinType
            })
        });
        if (res && res.status === 'success') {
            showToast('⚙️ ' + res.message);
        } else {
            showToast(res.message || 'ไม่สามารถเปลี่ยนการตั้งค่าได้');
        }
    } catch(e) {
        console.error(e);
    }
};

window.respondClanRequestAction = async function(requestId, decision, username) {
    const actionText = (decision === 'approve') ? 'อนุมัติรับเข้าบ้าน' : 'ปฏิเสธคำขอ';
    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'respond_clan_request',
                request_id: requestId,
                decision: decision
            })
        });
        if (res && res.status === 'success') {
            showToast('✅ ' + res.message);
            await loadClanData();
        } else {
            showInGameAlert(res.message || 'ดำเนินการไม่สำเร็จ', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.switchClanNoHouseTab = function(tab) {
    const btnJoin = document.getElementById('btn-tab-join-house');
    const btnCreate = document.getElementById('btn-tab-create-house');
    const subJoin = document.getElementById('clan-sub-join');
    const subCreate = document.getElementById('clan-sub-create');

    if (tab === 'join') {
        if (btnJoin) btnJoin.classList.add('active');
        if (btnCreate) btnCreate.classList.remove('active');
        if (subJoin) subJoin.style.display = 'block';
        if (subCreate) subCreate.style.display = 'none';
    } else {
        if (btnJoin) btnJoin.classList.remove('active');
        if (btnCreate) btnCreate.classList.add('active');
        if (subJoin) subJoin.style.display = 'none';
        if (subCreate) subCreate.style.display = 'block';
    }
};

window.submitCreateClan = async function() {
    const nameInput = document.getElementById('input-create-clan-name');
    const tagInput = document.getElementById('input-create-clan-tag');
    const descInput = document.getElementById('input-create-clan-desc');
    const joinTypeRadio = document.querySelector('input[name="create_clan_join_type"]:checked');

    const name = nameInput ? nameInput.value.trim() : '';
    const tag = tagInput ? tagInput.value.trim() : '';
    const desc = descInput ? descInput.value.trim() : '';
    const joinType = joinTypeRadio ? joinTypeRadio.value : 'free';

    if (!name) {
        showToast('⚠️ กรุณากรอกชื่อบ้าน / ครอบครัว');
        return;
    }

    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'create_clan',
                name: name,
                tag: tag,
                description: desc,
                join_type: joinType,
                badge_icon: 'badge_naga.png'
            })
        });

        if (res && res.status === 'success') {
            showToast('🎉 ' + res.message);
            if (typeof confetti === 'function') confetti({ particleCount: 60, spread: 60 });
            await loadClanData();
            if (window.apiClient) apiClient.getProfile().then(updateUserBar).catch(() => {});
        } else {
            showInGameAlert(res.message || 'สร้างบ้านไม่สำเร็จ', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาดในการสร้างบ้าน: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.joinClanAction = async function(clanId, clanName) {
    // ป้องกันการสมัครเข้าบ้านระบบ / บอท (คนใหม่จะเข้าร่วมไม่ได้ตามเงื่อนไข)
    if (typeof clanId === 'string' && clanId.startsWith('bot_')) {
        if (typeof window.showBotClanClosedAlert === 'function') {
            window.showBotClanClosedAlert(clanName);
        } else {
            showInGameAlert(`⛔ ขออภัย ครอบครัว '${clanName || ''}' เป็นบ้านระบบ (AI/บอท) ปิดรับสมัครสมาชิกบ้าน\n\n📌 ผู้เล่นใหม่ไม่สามารถเข้าร่วมได้ สามารถเข้าร่วมได้เฉพาะบ้านที่ไม่ใช่บอทที่ขึ้นสถานะ [🟢 บ้านว่าง เข้าได้] เท่านั้น`, 'ปิดรับสมัครสมาชิกบ้าน', '⛔');
        }
        return;
    }

    // บ้านสามารถเข้าบ้านได้หลังเดียวเท่านั้น
    if (window.clanData && window.clanData.has_clan && window.clanData.clan && (window.clanData.clan.clan_id || window.clanData.clan.clan_id_real)) {
        const myClanName = window.clanData.clan.clan_name || window.clanData.clan.name || 'บ้านเดิม';
        const isLeader = (window.clanData.my_role === 'leader' || window.clanData.is_leader);
        const memberCount = parseInt(window.clanData.clan.current_members) || window.clanData.members_count || 1;

        if (window.clanData.clan.clan_id === clanId || window.clanData.clan.clan_id_real === clanId) {
            showToast('คุณเป็นสมาชิกของบ้านนี้อยู่แล้ว');
            return;
        }

        if (isLeader && memberCount > 1) {
            showInGameAlert(
                `⚠️ คุณเป็นหัวหน้าบ้าน '${myClanName}' และยังมีสมาชิกอื่นอยู่ในบ้าน (${memberCount} คน)\n\nไม่สามารถย้ายบ้านได้จนกว่าสมาชิกจะออกจากบ้านจนหมด หรือยุบบ้านเมื่อเหลือคุณคนเดียวเท่านั้น`,
                'ไม่สามารถย้ายบ้านได้',
                '⚠️'
            );
            return;
        }

        showInGameConfirm(
            `คุณสังกัด '${myClanName}' อยู่แล้ว (สามารถเข้าบ้านได้หลังเดียวเท่านั้น)\n\nคุณต้องการออกจากบ้านเดิมและย้ายเข้าสังกัด '${clanName || 'บ้านใหม่'}' หรือไม่?`,
            async () => {
                await switchClanAction(clanId, clanName);
            },
            'ยืนยันย้ายบ้าน',
            '🔄'
        );
        return;
    }

    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'join_clan',
                clan_id: clanId
            })
        });

        if (res && res.status === 'success') {
            showToast('🎉 ' + res.message);
            await loadClanData();
            if (window.apiClient) apiClient.getProfile().then(updateUserBar).catch(() => {});
        } else if (res && res.has_clan) {
            window.switchClanAction(clanId, clanName || 'บ้านใหม่');
        } else {
            showInGameAlert(res.message || 'ไม่สามารถเข้าร่วมได้', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.cancelClanRequestAction = async function(clanId) {
    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'cancel_clan_request',
                clan_id: clanId
            })
        });
        if (res && res.status === 'success') {
            showToast('✅ ' + res.message);
            await loadClanData();
        } else {
            showInGameAlert(res.message || 'ไม่สามารถยกเลิกได้', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.switchClanAction = function(clanId, clanName) {
    showInGameConfirm(`คุณต้องการออกจากครอบครัวปัจจุบัน และสมัครย้ายเข้าสังกัด '${clanName}' หรือไม่?`, async () => {
        try {
            const res = await apiClient.request('api/shop.php', {
                method: 'POST',
                body: JSON.stringify({
                    action: 'join_clan',
                    clan_id: clanId,
                    leave_previous: true
                })
            });
            if (res && res.status === 'success') {
                showToast('🎉 ' + res.message);
                await loadClanData();
                if (window.apiClient) apiClient.getProfile().then(updateUserBar).catch(() => {});
            } else {
                showInGameAlert(res.message || 'ไม่สามารถย้ายบ้านได้', 'แจ้งเตือน', '⚠️');
            }
        } catch(e) {
            showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
        }
    }, 'ยืนยันย้ายบ้าน', '🔄');
};

window.confirmLeaveClan = function() {
    const isLeader = (window.clanData && (window.clanData.my_role === 'leader' || window.clanData.is_leader));
    const memberCount = (window.clanData && window.clanData.clan) 
        ? (parseInt(window.clanData.clan.current_members) || 1)
        : (document.querySelectorAll('.member-list-item').length || 1);

    if (isLeader) {
        if (memberCount > 1) {
            showInGameAlert(
                `⚠️ ไม่สามารถยุบบ้านได้เนื่องจากยังมีสมาชิกอื่นอยู่ในบ้าน (${memberCount} คน)\n\nตามกฎของระบบ สมาชิกต้องเหลือเพียงคนเดียวเท่านั้นจึงจะยุบบ้านได้!\n(โปรดรอให้สมาชิกออกจากบ้านจนเหลือคนเดียวก่อน หรือจัดการสมาชิกให้เหลือคนเดียว)`,
                'ไม่สามารถยุบบ้านได้',
                '⚠️'
            );
            return;
        }

        // Sole member & leader -> Can disband!
        showInGameConfirm(
            'คุณเป็นสมาชิกคนสุดท้ายของบ้าน คุณต้องการยุบและลบครอบครัวนี้อย่างถาวรใช่หรือไม่?',
            async () => {
                try {
                    const res = await apiClient.request('api/shop.php', {
                        method: 'POST',
                        body: JSON.stringify({ action: 'disband_clan' })
                    });
                    if (res && res.status === 'success') {
                        showToast(res.message || 'ยุบบ้านเรียบร้อยแล้ว');
                        const barClan = document.getElementById('bar-clan-name');
                        if (barClan) barClan.innerText = '-';
                        if (window.clanHouse) {
                            window.clanHouse.destroy();
                            window.clanHouse = null;
                        }
                        await loadClanData();
                    } else {
                        showInGameAlert(res.message || 'ไม่สามารถยุบบ้านได้', 'แจ้งเตือน', '⚠️');
                    }
                } catch(e) {
                    showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
                }
            },
            '💥 ยืนยันยุบและลบบ้าน',
            '💥'
        );
        return;
    }

    // Normal member
    showInGameConfirm('คุณแน่ใจหรือไม่ว่าต้องการออกจากครอบครัวนี้?', async () => {
        try {
            const res = await apiClient.request('api/shop.php', {
                method: 'POST',
                body: JSON.stringify({ action: 'leave_clan' })
            });
            if (res && res.status === 'success') {
                showToast('ออกจากบ้านเรียบร้อยแล้ว');
                const barClan = document.getElementById('bar-clan-name');
                if (barClan) barClan.innerText = '-';
                if (window.clanHouse) {
                    window.clanHouse.destroy();
                    window.clanHouse = null;
                }
                await loadClanData();
            } else {
                showInGameAlert(res.message, 'แจ้งเตือน', '⚠️');
            }
        } catch(e) {
            console.error(e);
        }
    }, 'ยืนยันออกจากบ้าน', '🚪');
};

window.inviteFriendToClanModal = function() {
    window.showInGamePrompt(
        'กรอกชื่อผู้เล่นหรือรหัส ID ของเพื่อนที่ต้องการเชิญเข้าบ้าน:',
        (friendName) => {
            if (!friendName || !friendName.trim()) {
                showToast('⚠️ กรุณากรอกชื่อผู้เล่นหรือรหัส ID ของเพื่อน');
                return;
            }

            apiClient.request('api/shop.php', {
                method: 'POST',
                body: JSON.stringify({
                    action: 'invite_to_clan',
                    target_username: friendName.trim()
                })
            }).then(res => {
                if (res && res.status === 'success') {
                    showToast('💌 ' + res.message);
                } else {
                    showInGameAlert(res.message || 'ไม่สามารถเชิญได้', 'แจ้งเตือน', '⚠️');
                }
            }).catch(e => {
                showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
            });
        },
        '💌 เชิญเพื่อนเข้าบ้าน',
        '💌',
        'กรอกชื่อผู้เล่น หรือ รหัส ID ของเพื่อน...',
        '💌 ส่งคำเชิญ'
    );
};

// ===================================================================
// SYSTEM 2: INVENTORY & DIAMOND SELL EXCHANGE (แยกการ์ด / เงา / เต๋า)
// ===================================================================
let inventorySellPrices = {};
let inventorySellCurrencies = {};
let inventorySellItems = {};

function getSellConfig(codeKey, fallbackAmount = 50) {
    const cleanKey = String(codeKey || '').toUpperCase();
    const item = inventorySellItems[cleanKey];
    const pKey = 'SELL_PRICE_' + cleanKey;
    const cKey = 'SELL_CURRENCY_' + cleanKey;
    const rawAmt = (item && item.amount !== undefined)
        ? Number(item.amount)
        : (inventorySellPrices[pKey] !== undefined ? Number(inventorySellPrices[pKey]) : fallbackAmount);
    const amount = Number.isFinite(rawAmt) ? rawAmt : fallbackAmount;
    const currency = String((item && item.currency) || inventorySellCurrencies[cKey] || 'DIAMOND').toUpperCase() === 'GOLD'
        ? 'GOLD'
        : 'DIAMOND';
    return {
        amount,
        currency,
        icon: currency === 'GOLD' ? '🪙' : '💎',
        unit: currency === 'GOLD' ? 'ทอง' : 'เพชร'
    };
}

function getSafeMaterialQty(materials, code) {
    if (!materials || materials[code] === undefined || materials[code] === null) return 0;
    const val = materials[code];
    const num = (typeof val === 'object') ? Number(val.quantity ?? 0) : Number(val);
    return Number.isFinite(num) ? num : 0;
}

window.openInventoryModal = async function() {
    openModal('modal-inventory');
    await loadInventoryData();
};


// =========================================================================
// 🎲 3D DICE SKINS & PRESETS SYSTEM
// =========================================================================
window.DICE_SKIN_PRESETS = {
    'AuroraCrystalDice': {
        name: 'ลูกเต๋าคริสตัลออโรร่า 3D',
        grade: 'EPIC',
        bgGradient: ['#7c3aed', '#06b6d4', '#3b82f6'],
        borderColor: '#00e5ff',
        pipColor: '#00e5ff',
        pipOneColor: '#ec4899',
        borderWidth: 10,
        roughness: 0.12,
        metalness: 0.35,
        emissive: 0x002244,
        description: 'ลูกเต๋าผลึกคริสตัลออโรร่าเรืองแสง เพิ่มการควบคุมเต๋าและสกิลขั้นสูง',
        glowAura: 'rgba(0, 229, 255, 0.45)'
    },
    'EmperorGoldDice': {
        name: 'ลูกเต๋าทองคำจักรพรรดิ 3D',
        grade: 'LEGENDARY',
        bgGradient: ['#f59e0b', '#ffd700', '#b45309'],
        borderColor: '#fef08a',
        pipColor: '#b91c1c',
        pipOneColor: '#dc2626',
        borderWidth: 14,
        roughness: 0.18,
        metalness: 0.88,
        emissive: 0x332200,
        description: 'ลูกเต๋าทองคำบริสุทธิ์แกะสลักลวดลายราชวงศ์ เพิ่มอัตราการทอยแต้มเบิ้ลและคุมเต๋าขั้นสูงสุด',
        glowAura: 'rgba(255, 215, 0, 0.55)'
    },
    'ClassicWoodDice': {
        name: 'ลูกเต๋าไม้คลาสสิก 3D',
        grade: 'NORMAL',
        bgGradient: ['#78350f', '#92400e', '#592507'],
        borderColor: '#d97706',
        pipColor: '#fef3c7',
        pipOneColor: '#ef4444',
        borderWidth: 10,
        roughness: 0.65,
        metalness: 0.05,
        emissive: 0x000000,
        description: 'ลูกเต๋าไม้แกะสลักคลาสสิก แข็งแกร่ง ทนทาน ให้ความรู้สึกดั้งเดิม',
        glowAura: 'rgba(217, 119, 6, 0.25)'
    },
    'CyberNeonDice': {
        name: 'ลูกเต๋าไซเบอร์นีออน 3D',
        grade: 'S+',
        bgGradient: ['#090d16', '#1e1b4b', '#0f172a'],
        borderColor: '#10b981',
        pipColor: '#10b981',
        pipOneColor: '#00e5ff',
        borderWidth: 12,
        roughness: 0.2,
        metalness: 0.5,
        emissive: 0x001a14,
        description: 'ลูกเต๋าอนาคตไซเบอร์พังก์ ลวดลายวงจรนีออนเรืองแสงสีเขียวมรกต',
        glowAura: 'rgba(16, 185, 129, 0.45)'
    },
    'RubyFireDice': {
        name: 'ลูกเต๋าทับทิมเพลิงมังกร 3D',
        grade: 'SS+',
        bgGradient: ['#991b1b', '#ef4444', '#7f1d1d'],
        borderColor: '#fbbf24',
        pipColor: '#fef08a',
        pipOneColor: '#fbbf24',
        borderWidth: 12,
        roughness: 0.15,
        metalness: 0.45,
        emissive: 0x2b0505,
        description: 'ลูกเต๋าอัญมณีทับทิมเพลิงมังกร เปล่งแสงเพลิงร้อนแรง พลังควบคุมขั้นสุดยอด',
        glowAura: 'rgba(239, 68, 68, 0.5)'
    }
};

window.resolveDiceSkinKey = function(name, prefab) {
    const s = String(name || prefab || '').toLowerCase();
    if (s.includes('aurora') || s.includes('crystal') || s.includes('คริสตัล') || s.includes('ออโรร่า')) {
        return 'AuroraCrystalDice';
    }
    if (s.includes('emperor') || s.includes('gold') || s.includes('ทองคำ') || s.includes('จักรพรรดิ')) {
        return 'EmperorGoldDice';
    }
    if (s.includes('cyber') || s.includes('neon') || s.includes('ไซเบอร์') || s.includes('นีออน')) {
        return 'CyberNeonDice';
    }
    if (s.includes('ruby') || s.includes('fire') || s.includes('ทับทิม') || s.includes('เพลิง')) {
        return 'RubyFireDice';
    }
    return 'ClassicWoodDice';
};

window.createDiceSkinMaterials = function(skinKey) {
    if (typeof THREE === 'undefined') return [];
    const preset = window.DICE_SKIN_PRESETS[skinKey] || window.DICE_SKIN_PRESETS['ClassicWoodDice'];
    const pipConfigs = {
        1: [[0.5, 0.5]],
        2: [[0.25, 0.25], [0.75, 0.75]],
        3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
        4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
        5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
        6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
    };

    const faceOrder = [1, 6, 2, 5, 3, 4];
    const materials = [];

    faceOrder.forEach(num => {
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');

        // พื้นหลัง Gradient ตามสกิน
        const grad = ctx.createLinearGradient(0, 0, 256, 256);
        const bg = preset.bgGradient;
        grad.addColorStop(0, bg[0]);
        grad.addColorStop(0.5, bg[1] || bg[0]);
        grad.addColorStop(1, bg[2] || bg[1] || bg[0]);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 256, 256);

        // กรอบขอบลูกเต๋า (Bevel / Inlay)
        ctx.strokeStyle = preset.borderColor;
        ctx.lineWidth = preset.borderWidth || 10;
        ctx.strokeRect(8, 8, 240, 240);

        // เส้นขอบเงาชั้นใน
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = 2;
        ctx.strokeRect(18, 18, 220, 220);

        // แต้มลูกเต๋า (Pips) พร้อมเอฟเฟกต์เรืองแสง
        const pColor = (num === 1) ? (preset.pipOneColor || preset.pipColor) : preset.pipColor;
        ctx.fillStyle = pColor;
        ctx.shadowColor = preset.borderColor;
        ctx.shadowBlur = (preset.grade === 'EPIC' || preset.grade === 'LEGENDARY' || preset.grade === 'S+' || preset.grade === 'SS+') ? 14 : 4;

        const pips = pipConfigs[num];
        pips.forEach(([x, y]) => {
            ctx.beginPath();
            ctx.arc(x * 256, y * 256, num === 1 ? 34 : 22, 0, Math.PI * 2);
            ctx.fill();
        });

        const texture = new THREE.CanvasTexture(canvas);
        materials.push(new THREE.MeshStandardMaterial({
            map: texture,
            roughness: preset.roughness ?? 0.25,
            metalness: preset.metalness ?? 0.2,
            emissive: preset.emissive ?? 0x000000
        }));
    });

    return materials;
};

window.currentInspectedDice = null;
window.dicePreview3DState = null;

window.initDicePreview3DScene = function(containerId, skinKey) {
    if (typeof THREE === 'undefined') return;
    const container = document.getElementById(containerId);
    if (!container) return;

    // เคลียร์ Scene เดิมออกอย่างปลอดภัย
    if (window.dicePreview3DState) {
        if (window.dicePreview3DState.animId) cancelAnimationFrame(window.dicePreview3DState.animId);
        if (window.dicePreview3DState.renderer && window.dicePreview3DState.renderer.domElement) {
            window.dicePreview3DState.renderer.dispose();
            if (window.dicePreview3DState.renderer.domElement.parentNode) {
                window.dicePreview3DState.renderer.domElement.parentNode.removeChild(window.dicePreview3DState.renderer.domElement);
            }
        }
        window.dicePreview3DState = null;
    }

    container.innerHTML = '';

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 185;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 8.8);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // ไฟส่องสว่าง
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.95);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.25);
    dirLight.position.set(5, 10, 7);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const preset = window.DICE_SKIN_PRESETS[skinKey] || window.DICE_SKIN_PRESETS['ClassicWoodDice'];
    const pointLight = new THREE.PointLight(preset.borderColor, 1.6, 20);
    pointLight.position.set(0, 2, 4);
    scene.add(pointLight);

    // เงาพื้นวงกลม
    const shadowGeo = new THREE.PlaneGeometry(6, 6);
    const shadowMat = new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.35
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = -1.1;
    scene.add(shadowMesh);

    // สร้างลูกเต๋าคู่ (Hero Dice 1 & 2)
    const diceGeo = new THREE.BoxGeometry(1.85, 1.85, 1.85);
    const mats1 = window.createDiceSkinMaterials(skinKey);
    const mats2 = window.createDiceSkinMaterials(skinKey);

    const mesh1 = new THREE.Mesh(diceGeo, mats1);
    mesh1.position.set(-1.4, 0, 0);
    mesh1.castShadow = true;
    scene.add(mesh1);

    const mesh2 = new THREE.Mesh(diceGeo, mats2);
    mesh2.position.set(1.4, 0, 0);
    mesh2.castShadow = true;
    scene.add(mesh2);

    const state = {
        scene,
        camera,
        renderer,
        mesh1,
        mesh2,
        isRolling: false,
        animId: null,
        skinKey: skinKey,
        startTime: performance.now()
    };
    window.dicePreview3DState = state;

    function renderLoop(now) {
        if (!window.dicePreview3DState) return;
        const s = window.dicePreview3DState;

        if (!s.isRolling) {
            const t = (now - s.startTime) * 0.001;
            s.mesh1.rotation.y += 0.012;
            s.mesh1.rotation.x += 0.008;
            s.mesh2.rotation.y -= 0.010;
            s.mesh2.rotation.z += 0.007;

            s.mesh1.position.y = Math.sin(t * 2.0) * 0.14;
            s.mesh2.position.y = Math.cos(t * 2.0) * 0.14;
        }

        s.renderer.render(s.scene, s.camera);
        s.animId = requestAnimationFrame(renderLoop);
    }

    state.animId = requestAnimationFrame(renderLoop);
};

window.testRollDice3D = function() {
    const s = window.dicePreview3DState;
    if (!s || s.isRolling) return;

    s.isRolling = true;
    const btn = document.getElementById('btn-test-roll-dice');
    if (btn) {
        btn.disabled = true;
        btn.style.opacity = '0.6';
        btn.innerHTML = '<span>🎲</span> กำลังทอย...';
    }

    const resultEl = document.getElementById('dice-preview-roll-result');
    if (resultEl) {
        resultEl.innerHTML = '<span style="color:#f59e0b;">🎲 กำลังทอยลูกเต๋า 3D...</span>';
    }

    const d1 = Math.floor(Math.random() * 6) + 1;
    const d2 = Math.floor(Math.random() * 6) + 1;
    const total = d1 + d2;
    const isDouble = (d1 === d2);

    const faceRotations = {
        1: new THREE.Euler(0, 0, Math.PI / 2),
        2: new THREE.Euler(0, 0, 0),
        3: new THREE.Euler(-Math.PI / 2, 0, 0),
        4: new THREE.Euler(Math.PI / 2, 0, 0),
        5: new THREE.Euler(Math.PI, 0, 0),
        6: new THREE.Euler(0, 0, -Math.PI / 2)
    };

    const targetRot1 = faceRotations[d1] || new THREE.Euler(0, 0, 0);
    const targetRot2 = faceRotations[d2] || new THREE.Euler(0, 0, 0);

    const duration = 1200;
    const startTime = performance.now();

    function tumbleStep(now) {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);

        if (progress < 1) {
            // กระดอนขึ้นสู่อากาศพร้อมหมุน 3D รวดเร็ว
            s.mesh1.position.y = Math.sin(progress * Math.PI) * 2.8;
            s.mesh2.position.y = Math.sin(progress * Math.PI * 1.1) * 3.0;

            s.mesh1.rotation.x += 0.38;
            s.mesh1.rotation.y += 0.48;
            s.mesh1.rotation.z += 0.28;

            s.mesh2.rotation.x -= 0.42;
            s.mesh2.rotation.y += 0.38;
            s.mesh2.rotation.z += 0.32;

            requestAnimationFrame(tumbleStep);
        } else {
            // ลงสู่พื้นและหยุดที่หน้าแต้มเป้าหมาย
            s.mesh1.position.set(-1.4, 0, 0);
            s.mesh2.position.set(1.4, 0, 0);
            s.mesh1.rotation.copy(targetRot1);
            s.mesh2.rotation.copy(targetRot2);

            s.isRolling = false;
            s.startTime = performance.now();

            if (resultEl) {
                resultEl.innerHTML = `
                    <span style="font-size:15px; color:#fff;">🎉 ทอยได้:</span>
                    <strong style="font-size:16px; color:#ffd700;">[${d1}] + [${d2}] = ${total} แต้ม</strong>
                    ${isDouble ? '<span class="badge badge-gold" style="font-size:11px; margin-left:4px;">🔥 แต้มเบิ้ล!</span>' : ''}
                `;
            }

            if (isDouble && typeof confetti === 'function') {
                confetti({ particleCount: 50, spread: 60, origin: { y: 0.5 } });
            }

            if (btn) {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.innerHTML = '<span>🎲</span> ทดสอบทอยเต๋า 3D';
            }
        }
    }

    requestAnimationFrame(tumbleStep);
};

window.switchInventoryTab = function(tab) {
    const bChars = document.getElementById('tab-btn-inv-chars');
    const bShadows = document.getElementById('tab-btn-inv-shadows');
    const bDice = document.getElementById('tab-btn-inv-dice');
    const pChars = document.getElementById('inv-panel-chars');
    const pShadows = document.getElementById('inv-panel-shadows');
    const pDice = document.getElementById('inv-panel-dice');

    if (bChars) bChars.classList.toggle('active', tab === 'chars');
    if (bShadows) bShadows.classList.toggle('active', tab === 'shadows');
    if (bDice) bDice.classList.toggle('active', tab === 'dice');

    if (pChars) pChars.style.display = tab === 'chars' ? 'flex' : 'none';
    if (pShadows) pShadows.style.display = tab === 'shadows' ? 'block' : 'none';
    if (pDice) pDice.style.display = tab === 'dice' ? 'flex' : 'none';

    if (tab === 'dice' && window.currentInspectedDice) {
        requestAnimationFrame(() => {
            window.renderDiceInspectionBox(window.currentInspectedDice);
        });
    } else if (tab === 'chars' && window.currentInspectedFrame) {
        requestAnimationFrame(() => {
            window.renderFrameInspectionBox(window.currentInspectedFrame);
        });
    }
};

window.loadInventoryData = async function() {
    if (!window.apiClient) return;
    try {
        // 1. Load Sell Prices & Currencies (Diamond / Gold) + Gacha Reqs
        const [pRes, catRes] = await Promise.all([
            apiClient.request('api/shop.php?action=get_sell_prices').catch(() => null),
            apiClient.getCatalog().catch(() => null)
        ]);
        if (pRes && pRes.status === 'success') {
            inventorySellPrices = pRes.prices || {};
            inventorySellCurrencies = pRes.currencies || {};
            inventorySellItems = pRes.items || {};
        }
        if (catRes && catRes.catalog && catRes.catalog.gacha_event) {
            window.syncGachaShadowAndTierCache(catRes.catalog.gacha_event);
        }

        // 2. Load Inventory
        const res = await apiClient.request('api/shop.php?action=get_inventory');
        if (res && res.status === 'success') {
            renderInventoryUI(res.inventory || [], res.materials || {});
        }
    } catch(e) {
        console.warn('Load inventory error:', e);
    }
};

function getFrameAuraClass(grade, auraType) {
    const g = (grade || 'A').toUpperCase();
    if (auraType === 'orange') return 'aura-grade-orange';
    if (auraType === 'crimson') return 'aura-grade-crimson';
    if (auraType === 'purple') return 'aura-grade-purple';
    if (auraType === 'rainbow') return 'aura-grade-rainbow';
    if (g === 'SS+' || auraType === 'gold') return 'aura-grade-ssplus';
    if (g === 'S+' || auraType === 'yellow') return 'aura-grade-splus';
    if (g === 'S' || auraType === 'cyan') return 'aura-grade-s';
    if (g === 'A+' || auraType === 'white') return 'aura-grade-aplus';
    return 'aura-grade-a';
}

function buildAuraOverdriveStyle(grade, auraType, intensity = 100) {
    const intVal = parseInt(intensity) || 100;
    const g = (grade || 'A').toUpperCase();
    const a = String(auraType || '').toLowerCase();
    if (a === 'none' || (!a && g === 'A')) return '';

    const colorMap = {
        orange: '#ff5500',
        crimson: '#ef4444',
        purple: '#a855f7',
        rainbow: '#00e5ff',
        gold: '#ffd700',
        yellow: '#facc15',
        cyan: '#00e5ff',
        white: '#ffffff'
    };
    const fallbackHex = g === 'SS+' ? '#ffd700' : (g === 'S+' ? '#facc15' : (g === 'S' ? '#00e5ff' : '#ffffff'));
    const hex = colorMap[a] || fallbackHex;

    if (intVal < 100) {
        const factor = Math.max(0.15, intVal / 100);
        return `filter: brightness(${(0.8 + 0.25 * factor).toFixed(2)}) saturate(${(0.7 + 0.35 * factor).toFixed(2)});`;
    }
    if (intVal > 100) {
        const over = Math.min(4.0, (intVal - 100) / 100); // 101%..500% -> 0..4
        const d1 = Math.round(8 + over * 16);
        const d2 = Math.round(16 + over * 30);
        const bright = (1 + over * 0.28).toFixed(2);
        const sat = (1 + over * 0.25).toFixed(2);
        return `filter: brightness(${bright}) saturate(${sat}) drop-shadow(0 0 ${d1}px ${hex}) drop-shadow(0 0 ${d2}px ${hex});`;
    }
    return '';
}

function getFrameAuraText(grade, auraType, intensity = 100, frameFx = '') {
    const g = (grade || 'A').toUpperCase();
    const intVal = parseInt(intensity) || 100;
    const intTag = intVal > 100
        ? ` (${intVal}% พลังออร่าขั้นสุด 🔥✨)`
        : (intVal < 100 ? ` (${intVal}%)` : ' (100% เต็มพลัง 🔥)');
    const fxLabels = {
        spin_pulse: ' • 🌀 หมุน+พัลส์',
        spin_slow: ' • 🔄 หมุน 360°',
        reverse_dual: ' • 💫 วงแหวนคู่',
        electric_orbit: ' • ⚡ ดาวสายฟ้า',
        flame_halo: ' • 🔥 เปลวเพลิง',
        pulse_breathe: ' • ✨ พัลส์แสง'
    };
    const fxSuffix = (frameFx && fxLabels[frameFx]) ? fxLabels[frameFx] : '';
    if (auraType === 'orange') return `🔥 แสงเออร่าสีส้มเพลิงร้อนแรง${intTag}${fxSuffix}`;
    if (auraType === 'crimson') return `🩸 แสงเออร่าสีแดงเพลิงโลหิต${intTag}${fxSuffix}`;
    if (auraType === 'purple') return `🔮 แสงเออร่าสีม่วงดาราจักร${intTag}${fxSuffix}`;
    if (auraType === 'rainbow') return `🌈 แสงเออร่ารุ้งปริซึม 7 สี${intTag}${fxSuffix}`;
    if (g === 'SS+' || auraType === 'gold') return `✨ แสงเออร่าสีทองสง่างาม${intTag}${fxSuffix}`;
    if (g === 'S+' || auraType === 'yellow') return `🌟 แสงเออร่าสีเหลืองเต็มๆ${intTag}${fxSuffix}`;
    if (g === 'S' || auraType === 'cyan') return `❄️ แสงเออร่าสีฟ้านีออน${intTag}${fxSuffix}`;
    if (g === 'A+' || auraType === 'white') return `⚪ แสงเออร่าสีขาวบริสุทธิ์${intTag}${fxSuffix}`;
    return 'ขอบเรียบหรู ไม่มีแสงเออร่า' + fxSuffix;
}

function buildCustomFrameLayersHtml(frameObj) {
    if (!frameObj) return '';
    const ringUrl = frameObj.avatar_url || frameObj.character_frame_url || '';
    const fx = frameObj.frame_fx || frameObj.character_frame_fx || 'pulse_breathe';
    const scalePct = parseInt(frameObj.frame_scale || frameObj.character_frame_scale) || 120;
    let html = '';
    if (fx === 'reverse_dual') {
        html += '<div class="game-fx-deco dual-ring"></div>';
    } else if (fx === 'electric_orbit') {
        html += '<div class="game-fx-deco spark-orbit"></div>';
    } else if (fx === 'flame_halo') {
        html += '<div class="game-fx-deco flame-ring"></div>';
    }
    if (ringUrl) {
        html += `<img src="${ringUrl}" class="custom-frame-ring-overlay game-fx-ring-${fx}" style="width:${scalePct}%; height:${scalePct}%;" alt="">`;
    }
    return html;
}

window.currentInspectedFrame = null;
window.latestInventoryList = [];

function renderInventoryUI(inventory, materials) {
    window.latestInventoryList = inventory;

    // 1. Characters list (Circular Profile Frames)
    const charsListEl = document.getElementById('inv-chars-list');
    const chars = inventory.filter(i => i.item_type === 'CHARACTER');
    if (charsListEl) {
        if (chars.length === 0) {
            charsListEl.innerHTML = '<div style="text-align:center; padding:30px; color:#94a3b8;">ยังไม่มีกรอบรูปตัวละครในคลังของคุณ<br><span style="font-size:12px; color:#38bdf8;">สุ่มได้รับจากร้านค้ากาชาปองกิจกรรม</span></div>';
            renderFrameInspectionBox(null);
        } else {
            // Find equipped or first
            let activeFrame = chars.find(c => Boolean(Number(c.is_equipped))) || chars[0];
            if (window.currentInspectedFrame) {
                const found = chars.find(c => c.id === window.currentInspectedFrame.id);
                if (found) activeFrame = found;
            }
            window.currentInspectedFrame = activeFrame;

            const myAvatar = window.getActivePlayerAvatarUrl();

            charsListEl.innerHTML = chars.map(c => {
                const grade = (c.char_grade || 'A').toUpperCase();
                const codeKey = 'CHAR_' + grade.replace('+', 'PLUS');
                const fallbackPrice = (grade === 'SS+' ? 1000 : (grade === 'S+' ? 400 : (grade === 'S' ? 250 : 100)));
                const sellCfg = getSellConfig(codeKey, fallbackPrice);
                const isEq = Boolean(Number(c.is_equipped));
                const isSelected = (activeFrame && activeFrame.id === c.id);
                const auraClass = getFrameAuraClass(grade, c.aura_type);
                const intensityVal = c.aura_intensity !== undefined ? parseInt(c.aura_intensity) : 100;
                const cardLvl = parseInt(c.level) || 1;
                const safeCharName = String(c.char_name || 'กรอบรูปตัวละคร').replace(/'/g, "\\'");

                const winBonus = parseFloat(c.win_rate_bonus) || (grade === 'SS+' ? 85 : (grade === 'S+' ? 55 : (grade === 'S' ? 30 : (grade === 'A+' ? 15 : 5))));
                const rollRate = parseFloat(c.roll_rate) || (grade === 'SS+' ? 90 : (grade === 'S+' ? 65 : (grade === 'S' ? 45 : (grade === 'A+' ? 30 : 20))));
                const playSkill = parseFloat(c.play_skill_rate) || (grade === 'SS+' ? 45 : (grade === 'S+' ? 30 : (grade === 'S' ? 20 : (grade === 'A+' ? 12 : 8))));

                return `
                    <div class="frame-item-card ${isSelected ? 'active-selected' : ''}" onclick="selectFrameForInspection(${c.id})">
                        <div style="display:flex; align-items:center; gap:14px;">
                            <div class="frame-circle-wrap ${auraClass}" style="position:relative; ${buildAuraOverdriveStyle(grade, c.aura_type, intensityVal)}">
                                <img src="${myAvatar}" class="frame-avatar-img" onerror="this.onerror=null; this.src='avatars/google_avatar.png';">
                                ${buildCustomFrameLayersHtml(c)}
                                <span class="avatar-grade-tag tag-${grade.toLowerCase().replace('+', 'plus')}">${grade}</span>
                            </div>
                            <div>
                                <div style="font-size:15px; font-weight:800; color:#fff; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                    ${c.char_name || 'กรอบรูปตัวละคร'}
                                    <span class="badge ${grade==='SS+'?'badge-gold':(grade==='S+'?'badge-gold':'badge-dia')}" style="font-size:10px; font-weight:800;">เกรด ${grade}</span>
                                    <span style="font-size:11px; color:#fbbf24; font-weight:800;">Lv.${cardLvl}/30</span>
                                </div>
                                <div style="font-size:11px; color:#38bdf8; margin: 3px 0;">
                                    🏆 ชนะ +${winBonus}% | 🎲 ทอย +${rollRate}% | ⚡ ฝีมือ +${playSkill}
                                </div>
                                <div style="font-size:11px; color:#94a3b8;">
                                    ${getFrameAuraText(grade, c.aura_type, intensityVal, c.frame_fx)}
                                </div>
                            </div>
                        </div>

                        <div style="display:flex; flex-direction:column; gap:6px; align-items:flex-end;">
                            ${isEq ? `
                                <span style="background:rgba(16, 185, 129, 0.15); border:1px solid #10b981; color:#34d399; font-size:11px; font-weight:800; padding:5px 12px; border-radius:8px;">
                                    🟢 กำลังสวมใส่
                                </span>
                            ` : `
                                <button class="btn btn-primary" onclick="event.stopPropagation(); equipFrameAction(${c.id})" style="padding:6px 14px; font-size:12px; background:linear-gradient(135deg, #00e5ff, #0284c7); color:#020617; font-weight:800; border-radius:8px;">
                                    🔘 สวมใส่
                                </button>
                                <button class="btn btn-secondary" onclick="event.stopPropagation(); sellItemAction('CHARACTER', ${c.id}, '', 1, ${sellCfg.amount}, '${safeCharName}', '${sellCfg.currency}')" style="padding:4px 10px; font-size:11px; background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#fca5a5; border-radius:8px; white-space:nowrap;">
                                    ${sellCfg.icon} ขาย ${sellCfg.amount.toLocaleString()} ${sellCfg.unit}
                                </button>
                            `}
                        </div>
                    </div>
                `;
            }).join('');

            renderFrameInspectionBox(activeFrame);
        }
    }

    // 2. Shadows materials list (รองรับเงา AI สวยๆ + เออร่า + แลกกรอบ SS+ / S+ / S)
    const shadowsListEl = document.getElementById('inv-shadows-list');
    if (shadowsListEl) {
        const reqs = window.currentGachaReqs || { black: 15, red: 15, orange: 15, blue: 10, gold: 4 };
        const sCfgs = Array.isArray(window.currentShadowConfigs) && window.currentShadowConfigs.length === 5
            ? window.currentShadowConfigs
            : [
                { slot: 'black',  code: 'SHADOW_BLACK_A',    altCode: '',                  name: 'การ์ดเงาสีดำ ระดับ A',   grade: 'A',  color: '#94a3b8', aura: 'none',    intensity: 80,  image_url: '' },
                { slot: 'red',    code: 'SHADOW_RED_A',      altCode: '',                  name: 'การ์ดเงาสีแดง ระดับ A',  grade: 'A',  color: '#ef4444', aura: 'crimson', intensity: 95,  image_url: '' },
                { slot: 'orange', code: 'SHADOW_ORANGE_A',   altCode: '',                  name: 'การ์ดเงาสีส้ม ระดับ A',  grade: 'A',  color: '#ff8800', aura: 'orange',  intensity: 100, image_url: '' },
                { slot: 'blue',   code: 'SHADOW_BLUE_APLUS', altCode: 'SHADOW_BLUE_A',     name: 'การ์ดเงาสีฟ้า ระดับ A+', grade: 'A+', color: '#38bdf8', aura: 'cyan',    intensity: 115, image_url: '' },
                { slot: 'gold',   code: 'SHADOW_GOLD_S',     altCode: 'SHADOW_GOLD_APLUS', name: 'การ์ดเงาสีทอง ระดับ S',  grade: 'S',  color: '#ffd700', aura: 'gold',    intensity: 140, image_url: '' }
            ];

        const fallbackMap = { black: 20, red: 20, orange: 20, blue: 35, gold: 50 };
        const matConfigs = sCfgs.map(s => ({
            slot: s.slot,
            code: s.code,
            altCode: s.altCode || '',
            name: s.name,
            grade: s.grade || 'A',
            color: s.color,
            aura: s.aura || 'none',
            intensity: s.intensity || 100,
            image_url: s.image_url || '',
            isShadowRing: true,
            req: reqs[s.slot] || 0,
            fallbackAmt: fallbackMap[s.slot] || 20
        }));
        matConfigs.push({
            code: 'SPECIAL_CARD',
            name: 'การ์ดพิเศษ (Special Awakening Card)',
            grade: 'S',
            color: '#c084fc',
            icon: '✨',
            isShadowRing: false,
            req: 1,
            fallbackAmt: 80
        });

        let html = `
            <div style="grid-column: 1 / -1; background:linear-gradient(135deg, rgba(6,182,212,0.12), rgba(245,158,11,0.12)); border:1.5px solid #ffd700; border-radius:14px; padding:16px; margin-bottom:10px;">
                ${window.buildMultiTierExchangeHtml(materials, 'inventory')}
            </div>
        `;

        html += matConfigs.map(m => {
            let qty = getSafeMaterialQty(materials, m.code);
            if (m.altCode) qty += getSafeMaterialQty(materials, m.altCode);

            const sellCfg = getSellConfig(m.code, m.fallbackAmt);
            const safeMatName = String(m.name).replace(/'/g, "\\'");
            const badgeHtml = m.isShadowRing
                ? window.buildShadowRingBadgeHtml(m, 44)
                : `<div style="font-size:28px; width:44px; height:44px; display:flex; align-items:center; justify-content:center;">${m.icon || '✨'}</div>`;

            return `
                <div class="item-card-row" style="margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; gap:12px;">
                    <div style="display:flex; align-items:center; gap:12px;">
                        ${badgeHtml}
                        <div>
                            <div style="font-size:14px; font-weight:700; color:${m.color}; display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                <span>${m.name}</span>
                                <span style="font-size:10px; background:${m.color}22; border:1px solid ${m.color}; color:${m.color}; padding:1px 6px; border-radius:8px;">เกรด ${m.grade || 'A'}</span>
                            </div>
                            <div style="font-size:12px; color:#cbd5e1;">มีอยู่ในคลัง: <strong style="color:#fff;">${qty.toLocaleString()}</strong> ใบ</div>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-secondary" ${qty <= 0 ? 'disabled style="opacity:0.4; cursor:not-allowed; padding:6px 12px; font-size:12px;"' : 'style="padding:6px 12px; font-size:12px; background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#fca5a5; cursor:pointer; white-space:nowrap;"'} onclick="promptSellMaterial('${m.code}', ${qty}, ${sellCfg.amount}, '${safeMatName}', '${sellCfg.currency}')">
                            ${sellCfg.icon} ขายรับ${sellCfg.unit} (ใบละ ${sellCfg.amount.toLocaleString()})
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        shadowsListEl.innerHTML = html;
    }

    // 3. Dice list
    const diceListEl = document.getElementById('inv-dice-list');
    const dice = inventory.filter(i => i.item_type === 'DICE');
    if (diceListEl) {
        if (dice.length === 0) {
            diceListEl.innerHTML = '<div style="text-align:center; padding:30px; color:#94a3b8;">ยังไม่มีลูกเต๋าในคลังของคุณ<br><span style="font-size:12px; color:#38bdf8;">สุ่มได้รับจากร้านค้ากาชาปอง</span></div>';
            window.renderDiceInspectionBox(null);
        } else {
            // Find equipped or first
            let activeDice = dice.find(d => Boolean(Number(d.is_equipped))) || dice[0];
            if (window.currentInspectedDice) {
                const found = dice.find(d => d.id === window.currentInspectedDice.id);
                if (found) activeDice = found;
            }
            window.currentInspectedDice = activeDice;

            diceListEl.innerHTML = dice.map(d => {
                const grade = (d.dice_grade || 'NORMAL').toUpperCase();
                const diceKey = 'DICE_' + grade.replace('+', 'PLUS');
                const fallbackDiceAmt = (grade === 'LEGENDARY' ? 500 : (grade === 'EPIC' ? 200 : (grade === 'RARE' ? 80 : 30)));
                const sellCfg = getSellConfig(diceKey, fallbackDiceAmt);
                const isEq = Boolean(Number(d.is_equipped));
                const isSelected = (activeDice && activeDice.id === d.id);
                const skinKey = window.resolveDiceSkinKey(d.dice_name, d.model_prefab_name);
                const preset = window.DICE_SKIN_PRESETS[skinKey] || window.DICE_SKIN_PRESETS['ClassicWoodDice'];
                const safeDiceName = String(d.dice_name || 'ลูกเต๋า 3D').replace(/'/g, "\\'");

                let gradeBadgeClass = 'badge-dia';
                if (grade === 'EPIC') gradeBadgeClass = 'badge-purple';
                if (grade === 'LEGENDARY' || grade === 'S+' || grade === 'SS+') gradeBadgeClass = 'badge-gold';

                return `
                    <div class="frame-item-card ${isSelected ? 'active-selected' : ''}" onclick="selectDiceForInspection(${d.id})" style="cursor:pointer; margin-bottom:12px;">
                        <div style="display:flex; align-items:center; gap:14px;">
                            <div class="dice-circle-wrap" style="width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; background:${preset.bgGradient[0]}; border:2px solid ${preset.borderColor}; box-shadow:0 0 12px ${preset.glowAura}; font-size:26px; flex-shrink:0;">
                                🎲
                            </div>
                            <div>
                                <div style="font-size:15px; font-weight:800; color:#fff; display:flex; align-items:center; gap:8px;">
                                    ${d.dice_name || 'ลูกเต๋า 3D'}
                                    <span class="badge ${gradeBadgeClass}" style="font-size:10px; font-weight:800;">${grade}</span>
                                </div>
                                <div style="font-size:11px; color:#38bdf8; margin: 3px 0;">
                                    🎲 อัตราคุมลูกเต๋าแม่นยำ: <strong>${d.dice_control_rate || 10.00}%</strong>
                                </div>
                                <div style="font-size:11px; color:#94a3b8;">
                                    ${preset.description || 'ลูกเต๋าสำหรับการแข่งขันบันไดงู 3D'}
                                </div>
                            </div>
                        </div>

                        <div style="display:flex; flex-direction:column; gap:6px; align-items:flex-end;">
                            ${isEq ? `
                                <span style="background:rgba(16, 185, 129, 0.15); border:1px solid #10b981; color:#34d399; font-size:11px; font-weight:800; padding:6px 14px; border-radius:8px;">
                                    🟢 กำลังสวมใส่
                                </span>
                            ` : `
                                <button class="btn btn-primary" onclick="event.stopPropagation(); equipDiceAction(${d.id})" style="padding:6px 14px; font-size:12px; background:linear-gradient(135deg, #00e5ff, #0284c7); color:#020617; font-weight:800; border-radius:8px; box-shadow:0 2px 8px rgba(0,229,255,0.3); cursor:pointer;">
                                    🔘 เลือกใช้งาน
                                </button>
                                <button class="btn btn-secondary" onclick="event.stopPropagation(); sellItemAction('DICE', ${d.id}, '', 1, ${sellCfg.amount}, '${safeDiceName}', '${sellCfg.currency}')" style="padding:4px 10px; font-size:11px; background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#fca5a5; border-radius:8px; cursor:pointer; white-space:nowrap;">
                                    ${sellCfg.icon} ขาย ${sellCfg.amount.toLocaleString()} ${sellCfg.unit}
                                </button>
                            `}
                        </div>
                    </div>
                `;
            }).join('');

            window.renderDiceInspectionBox(activeDice);
        }
    }
}

window.selectDiceForInspection = function(diceId) {
    if (!window.latestInventoryList) return;
    const item = window.latestInventoryList.find(i => i.id === diceId);
    if (item) {
        window.currentInspectedDice = item;
        document.querySelectorAll('#inv-dice-list .frame-item-card').forEach(el => el.classList.remove('active-selected'));
        if (event && event.currentTarget) event.currentTarget.classList.add('active-selected');
        window.renderDiceInspectionBox(item);
    }
};

window.renderDiceInspectionBox = function(dice) {
    const box = document.getElementById('dice-preview-inspection-box');
    if (!box) return;

    if (!dice) {
        box.innerHTML = '<div style="margin:auto; color:#94a3b8; font-size:13px;">ยังไม่มีลูกเต๋าที่เลือก</div>';
        return;
    }

    const grade = (dice.dice_grade || 'NORMAL').toUpperCase();
    const isEq = Boolean(Number(dice.is_equipped));
    const skinKey = window.resolveDiceSkinKey(dice.dice_name, dice.model_prefab_name);
    const preset = window.DICE_SKIN_PRESETS[skinKey] || window.DICE_SKIN_PRESETS['ClassicWoodDice'];
    const diceKey = 'DICE_' + grade.replace('+', 'PLUS');
    const fallbackDiceAmt = (grade === 'LEGENDARY' ? 500 : (grade === 'EPIC' ? 200 : (grade === 'RARE' ? 80 : 30)));
    const sellCfg = getSellConfig(diceKey, fallbackDiceAmt);
    const ctrlRate = parseFloat(dice.dice_control_rate) || 10.0;

    box.innerHTML = `
        <div style="font-size:13px; font-weight:800; color:#f59e0b; text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:6px;">
            <span>🎲</span> ตัวอย่างลูกเต๋า 3D & ทดสอบทอย
        </div>

        <!-- 3D Canvas Viewport for Dice Preview -->
        <div id="dice-3d-preview-canvas" style="width: 100%; height: 185px; position: relative; border-radius: 14px; overflow: hidden; background: radial-gradient(circle, rgba(30,41,59,0.95) 0%, rgba(15,23,42,0.98) 100%); border: 1.5px solid rgba(245, 158, 11, 0.45); margin: 8px 0; box-shadow: inset 0 0 25px rgba(0,0,0,0.6);">
            <!-- Three.js Canvas injected here -->
        </div>

        <!-- Roll result display area -->
        <div id="dice-preview-roll-result" style="font-size:13px; font-weight:700; color:#38bdf8; min-height:22px; margin-bottom:4px; display:flex; align-items:center; justify-content:center; gap:6px;">
            <span>✨</span> แตะปุ่ม "ทดสอบทอยเต๋า 3D" เพื่อดูผลการทอย
        </div>

        <div style="margin-bottom:4px;">
            <div style="font-size:18px; font-weight:900; color:#fff;">
                ${dice.dice_name || 'ลูกเต๋า 3D'}
            </div>
            <div style="font-size:12px; color:#f59e0b; font-weight:700; margin-top:2px;">
                เกรด ${grade} • ${preset.name}
            </div>
        </div>

        <!-- Stats metric box -->
        <div class="frame-stats-box" style="margin: 8px 0;">
            <div class="stat-metric">
                <span class="stat-metric-title">🎲 คุมเต๋า</span>
                <span class="stat-metric-val">+${ctrlRate.toFixed(1)}%</span>
            </div>
            <div class="stat-metric">
                <span class="stat-metric-title">✨ รูปแบบ 3D</span>
                <span class="stat-metric-val" style="font-size:12px;">${grade}</span>
            </div>
            <div class="stat-metric">
                <span class="stat-metric-title">${sellCfg.icon} มูลค่าขาย</span>
                <span class="stat-metric-val">${sellCfg.amount.toLocaleString()} ${sellCfg.unit}</span>
            </div>
        </div>

        <div style="width:100%; display:flex; flex-direction:column; gap:8px; margin-top:4px;">
            ${isEq ? `
                <button class="btn-equip-frame equipped" style="width:100%;">
                    🟢 กำลังสวมใส่ใช้งานอยู่
                </button>
            ` : `
                <button class="btn-equip-frame" onclick="equipDiceAction(${dice.id})" style="width:100%; cursor:pointer; background:linear-gradient(135deg, #00e5ff, #0284c7); color:#020617; font-weight:800;">
                    🔘 เลือกใช้งานลูกเต๋านี้
                </button>
            `}
            <button id="btn-test-roll-dice" onclick="testRollDice3D()" class="btn btn-primary" style="width:100%; padding:10px; font-size:14px; font-weight:800; background:linear-gradient(135deg, #f59e0b, #d97706); color:#000; border:none; border-radius:10px; cursor:pointer; box-shadow:0 0 15px rgba(245,158,11,0.4); display:flex; align-items:center; justify-content:center; gap:8px;">
                <span>🎲</span> ทดสอบทอยเต๋า 3D
            </button>
        </div>
    `;

    // Initialize 3D Mini Scene in container
    window.initDicePreview3DScene('dice-3d-preview-canvas', skinKey);
};


window.renderFrameInspectionBox = function(frame) {
    const box = document.getElementById('frame-preview-inspection-box');
    if (!box) return;

    if (!frame) {
        box.innerHTML = '<div style="margin:auto; color:#94a3b8; font-size:13px;">ยังไม่มีกรอบรูปที่เลือก</div>';
        return;
    }

    const grade = (frame.char_grade || 'A').toUpperCase();
    const isEq = Boolean(Number(frame.is_equipped));
    const cardLvl = parseInt(frame.level) || 1;
    const isMaxLvl = cardLvl >= 30;
    const nextUpgradeCost = cardLvl < 10 ? 100 : (cardLvl < 20 ? 150 : (cardLvl < 29 ? 200 : 500));
    const intensityVal = frame.aura_intensity !== undefined ? parseInt(frame.aura_intensity) : 100;
    const auraClass = getFrameAuraClass(grade, frame.aura_type);
    const auraText = getFrameAuraText(grade, frame.aura_type, intensityVal, frame.frame_fx);

    const winBonus = parseFloat(frame.win_rate_bonus) || (grade === 'SS+' ? 85 : (grade === 'S+' ? 55 : (grade === 'S' ? 30 : (grade === 'A+' ? 15 : 5))));
    const rollRate = parseFloat(frame.roll_rate) || (grade === 'SS+' ? 90 : (grade === 'S+' ? 65 : (grade === 'S' ? 45 : (grade === 'A+' ? 30 : 20))));
    const playSkill = parseFloat(frame.play_skill_rate) || (grade === 'SS+' ? 45 : (grade === 'S+' ? 30 : (grade === 'S' ? 20 : (grade === 'A+' ? 12 : 8))));

    const myAvatar = window.getActivePlayerAvatarUrl();

    box.innerHTML = `
        <div style="font-size:13px; font-weight:800; color:#f59e0b; text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:6px;">
            <span>✨</span> ตัวอย่างการสวมใส่จริง (Preview)
        </div>

        <!-- Giant circular frame with user avatar, custom AI ring overlay & grade aura -->
        <div class="giant-frame-circle-wrap ${auraClass}" style="${buildAuraOverdriveStyle(grade, frame.aura_type, intensityVal)}">
            <img src="${myAvatar}" class="giant-frame-avatar-img" onerror="this.onerror=null; this.src='avatars/google_avatar.png';">
            ${buildCustomFrameLayersHtml(frame)}
            <span class="giant-avatar-grade-tag tag-${grade.toLowerCase().replace('+', 'plus')}">${grade}</span>
        </div>

        <div style="margin-bottom:4px;">
            <div style="font-size:18px; font-weight:900; color:#fff;">
                ${frame.char_name || 'กรอบรูปตัวละคร'} <span style="font-size:13px; color:#38bdf8;">[Lv.${cardLvl}/30]</span>
            </div>
            <div style="font-size:12px; color:#f59e0b; font-weight:700; margin-top:2px;">
                เกรด ${grade} • ${auraText}
            </div>
        </div>

        <!-- Stats metric box -->
        <div class="frame-stats-box">
            <div class="stat-metric">
                <span class="stat-metric-title">🏆 อัตราชนะ</span>
                <span class="stat-metric-val">+${winBonus}%</span>
            </div>
            <div class="stat-metric">
                <span class="stat-metric-title">🎲 อัตราทอย</span>
                <span class="stat-metric-val">+${rollRate}%</span>
            </div>
            <div class="stat-metric">
                <span class="stat-metric-title">⚡ เล่นเก่ง</span>
                <span class="stat-metric-val">+${playSkill}</span>
            </div>
        </div>

        <div style="width:100%; margin-top:6px; display:flex; flex-direction:column; gap:8px;">
            ${isEq ? `
                <button class="btn-equip-frame equipped">
                    🟢 กำลังสวมใส่กรอบนี้อยู่
                </button>
            ` : `
                <button class="btn-equip-frame" onclick="equipFrameAction(${frame.id})">
                    ✨ สวมใส่กรอบรูปนี้ทันที
                </button>
            `}
            ${!isMaxLvl ? `
                <button class="btn btn-primary" onclick="upgradeItemFromInventory(${frame.id})" style="width:100%; padding:9px 12px; font-size:13px; font-weight:800; background:linear-gradient(135deg, #f59e0b, #d97706); color:#000; border:none; border-radius:10px; cursor:pointer;">
                    ⚡ อัปเลเวล Lv.${cardLvl} ➔ Lv.${cardLvl + 1} (${cardLvl === 29 ? 'การ์ดพิเศษ + 500💎' : nextUpgradeCost + ' 💎'})
                </button>
            ` : `
                <div style="font-size:12px; font-weight:800; color:#ffd700; padding:6px;">🌟 MAX LEVEL 30 ปลุกพลังสมบูรณ์ ✨</div>
            `}
        </div>
    `;
};

window.upgradeItemFromInventory = async function(invId) {
    try {
        const res = await apiClient.upgradeCard(invId);
        if (res && res.status === 'success') {
            showToast('⚡ ' + res.message);
            const prof = await apiClient.getProfile().catch(() => null);
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadInventoryData();
        } else {
            showInGameAlert((res && res.message) || 'ไม่สามารถอัปเลเวลได้', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert('เกิดข้อผิดพลาดในการอัปเลเวล: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.sellItemAction = function(itemType, inventoryId, materialCode, quantity, unitPrice, itemName, currency = 'DIAMOND') {
    const currUpper = String(currency || 'DIAMOND').toUpperCase() === 'GOLD' ? 'GOLD' : 'DIAMOND';
    const currIcon = currUpper === 'GOLD' ? '🪙' : '💎';
    const currUnit = currUpper === 'GOLD' ? 'ทอง' : 'เพชร';
    const totalEarn = (Number(unitPrice) || 0) * Math.max(1, parseInt(quantity) || 1);

    showInGameConfirm(
        `ยืนยันการขาย "${itemName}" จำนวน ${quantity} ชิ้น?\n\nคุณจะได้รับ: +${totalEarn.toLocaleString()} ${currIcon} ${currUnit} ทันที`,
        async () => {
            try {
                const oldDia = Number(DEFAULT_USER.diamond || 0);
                const oldGold = Number(DEFAULT_USER.gold || 0);

                const res = await apiClient.request('api/shop.php?action=sell_item', {
                    method: 'POST',
                    body: JSON.stringify({
                        action: 'sell_item',
                        item_type: itemType,
                        inventory_id: inventoryId,
                        material_code: materialCode,
                        quantity: quantity
                    })
                });

                if (res && res.status === 'success') {
                    const newDia = res.new_diamond !== undefined ? Number(res.new_diamond) : oldDia;
                    const newGold = res.new_gold !== undefined ? Number(res.new_gold) : oldGold;
                    DEFAULT_USER.diamond = newDia;
                    DEFAULT_USER.gold = newGold;
                    try {
                        localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
                    } catch (e) {}

                    updateUserBar(DEFAULT_USER);
                    if (newDia !== oldDia) animateCurrencyCounter('bar-diamond', oldDia, newDia, 900);
                    if (newGold !== oldGold) animateCurrencyCounter('bar-gold', oldGold, newGold, 900);

                    showToast('💰 ' + res.message);
                    await loadInventoryData();
                } else {
                    showInGameAlert((res && res.message) || 'ไม่สามารถขายไอเทมได้', 'แจ้งเตือน', '⚠️');
                }
            } catch (e) {
                showInGameAlert('เกิดข้อผิดพลาดในการขายไอเทม: ' + e.message, 'ข้อผิดพลาด', '❌');
            }
        },
        `ยืนยันการขายแลก${currUnit}`,
        currIcon
    );
};

window.promptSellMaterial = function(matCode, maxQty, unitPrice, matName, currency = 'DIAMOND') {
    if (maxQty <= 0) {
        showToast('คุณยังไม่มีการ์ดใบนี้ในคลัง');
        return;
    }
    const currUpper = String(currency || 'DIAMOND').toUpperCase() === 'GOLD' ? 'GOLD' : 'DIAMOND';
    const currIcon = currUpper === 'GOLD' ? '🪙' : '💎';
    const currUnit = currUpper === 'GOLD' ? 'ทอง' : 'เพชร';

    window.showInGamePrompt(
        `ต้องการขาย "${matName}" กี่ใบ? (มีทั้งหมด ${maxQty} ใบ | ใบละ ${Number(unitPrice).toLocaleString()} ${currIcon} ${currUnit}):`,
        (valStr) => {
            if (!valStr) return;
            const trimmed = String(valStr).trim().toLowerCase();
            const qty = (trimmed === 'all' || trimmed === 'ทั้งหมด') ? maxQty : parseInt(trimmed);
            if (!qty || qty <= 0) {
                showToast('⚠️ กรุณาระบุจำนวนใบที่ถูกต้อง');
                return;
            }
            if (qty > maxQty) {
                showInGameAlert(`คุณมีเพียง ${maxQty} ใบในคลัง`, 'จำนวนเกินที่มี', '⚠️');
                return;
            }
            window.sellItemAction('MATERIAL', 0, matCode, qty, unitPrice, matName, currUpper);
        },
        `${currIcon} ขายการ์ดเงาแลก${currUnit}`,
        currIcon,
        `กรอกจำนวนใบ (1 - ${maxQty})...`,
        `${currIcon} ตกลงขาย`
    );
};

window.selectFrameForInspection = function(inventoryId) {
    if (!window.latestInventoryList) return;
    const item = window.latestInventoryList.find(i => i.id === inventoryId);
    if (item) {
        window.currentInspectedFrame = item;
        document.querySelectorAll('.frame-item-card').forEach(el => el.classList.remove('active-selected'));
        if (event && event.currentTarget) event.currentTarget.classList.add('active-selected');
        renderFrameInspectionBox(item);
    }
};

window.equipFrameAction = async function(inventoryId) {
    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'equip_item',
                item_type: 'CHARACTER',
                inventory_id: inventoryId
            })
        });

        if (res && res.status === 'success') {
            showToast(res.message);
            if (res.equipped_character) {
                const grade = res.equipped_character.grade || res.equipped_character.char_grade || 'A';
                const auraType = res.equipped_character.aura_type || 'none';
                const auraIntensity = res.equipped_character.aura_intensity !== undefined ? parseInt(res.equipped_character.aura_intensity) : 100;
                const ringUrl = res.equipped_character.avatar_url || '';
                const frameFx = res.equipped_character.frame_fx || 'pulse_breathe';
                const frameScale = parseInt(res.equipped_character.frame_scale) || 120;
                localStorage.setItem('snake_equipped_frame_grade', grade);
                localStorage.setItem('snake_equipped_frame_aura', auraType);
                localStorage.setItem('snake_equipped_frame_intensity', auraIntensity);
                localStorage.setItem('snake_equipped_frame_ring_url', ringUrl);
                localStorage.setItem('snake_equipped_frame_fx', frameFx);
                localStorage.setItem('snake_equipped_frame_scale', frameScale);

                // ซิงก์ค่าพลังสกิลกรอบรูปเข้าสู่ DEFAULT_USER & ตัวละครบนกระดาน (สำหรับสุ่มตัวคูณแลนด์มาร์ค X2-X4-X6-X8)
                const eqChar = res.equipped_character;
                DEFAULT_USER.char_grade = grade;
                DEFAULT_USER.win_rate_bonus = parseFloat(eqChar.win_rate_bonus) || (grade === 'SS+' ? 85 : (grade === 'S+' ? 55 : 25));
                DEFAULT_USER.roll_rate = parseFloat(eqChar.roll_rate) || (grade === 'SS+' ? 90 : (grade === 'S+' ? 65 : 35));
                DEFAULT_USER.play_skill_rate = parseFloat(eqChar.play_skill_rate) || (grade === 'SS+' ? 45 : (grade === 'S+' ? 30 : 20));
                if (window.game && window.game.players && window.game.players[0] && !window.game.players[0].is_bot) {
                    window.game.players[0].char_grade = DEFAULT_USER.char_grade;
                    window.game.players[0].win_rate_bonus = DEFAULT_USER.win_rate_bonus;
                    window.game.players[0].roll_rate = DEFAULT_USER.roll_rate;
                    window.game.players[0].play_skill_rate = DEFAULT_USER.play_skill_rate;
                }

                applyTopBarAvatarAura(grade, auraType, auraIntensity, ringUrl, frameFx, frameScale);
                if (window.game && typeof window.game.updatePlayerPawnAvatar === 'function') {
                    window.game.updatePlayerPawnAvatar(0, DEFAULT_USER, DEFAULT_USER.username, DEFAULT_USER.auth_provider, grade, auraType);
                }
            }
            await loadInventoryData();
        } else {
            showInGameAlert(res.message || 'ไม่สามารถสวมใส่ได้', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

window.equipDiceAction = async function(inventoryId) {
    try {
        const res = await apiClient.request('api/shop.php', {
            method: 'POST',
            body: JSON.stringify({
                action: 'equip_item',
                item_type: 'DICE',
                inventory_id: inventoryId
            })
        });

        if (res && res.status === 'success') {
            showToast(res.message);

            // อัปเดตสกินลูกเต๋าเข้าสู่ DEFAULT_USER และ State ของเกม 3D ทันที
            if (window.latestInventoryList) {
                const diceItem = window.latestInventoryList.find(i => i.id === inventoryId);
                if (diceItem) {
                    const skinKey = window.resolveDiceSkinKey(diceItem.dice_name, diceItem.model_prefab_name);
                    DEFAULT_USER.dice_skin = skinKey;
                    DEFAULT_USER.equipped_dice_name = diceItem.dice_name;
                    DEFAULT_USER.equipped_dice_id = diceItem.dice_id || diceItem.id;
                    DEFAULT_USER.dice_control_rate = parseFloat(diceItem.dice_control_rate) || 25;
                    try {
                        const cached = JSON.parse(localStorage.getItem('snake_user_data') || '{}');
                        cached.dice_skin = skinKey;
                        cached.equipped_dice_name = diceItem.dice_name;
                        cached.equipped_dice_id = DEFAULT_USER.equipped_dice_id;
                        cached.dice_control_rate = DEFAULT_USER.dice_control_rate;
                        localStorage.setItem('snake_user_data', JSON.stringify(cached));
                    } catch(e) {}

                    if (window.game && window.game.players && window.game.players[0]) {
                        window.game.players[0].dice_skin = skinKey;
                        window.game.players[0].dice_name = diceItem.dice_name;
                        window.game.players[0].dice_control_rate = DEFAULT_USER.dice_control_rate;
                        if (window.game.currentTurnIndex === 0) {
                            window.game.applyDiceSkin(skinKey);
                        }
                    }
                }
            }

            await loadInventoryData();
        } else {
            showInGameAlert(res.message || 'ไม่สามารถสวมใส่ได้', 'แจ้งเตือน', '⚠️');
        }
    } catch(e) {
        showInGameAlert('เกิดข้อผิดพลาด: ' + e.message, 'ข้อผิดพลาด', '❌');
    }
};

function applyTopBarAvatarAura(grade, auraType, intensity = 100, ringUrl = '', frameFx = 'pulse_breathe', frameScale = 120) {
    const avatarImg = document.getElementById('bar-avatar');
    if (!avatarImg) return;
    const g = (grade || 'A').toUpperCase();
    const auraClass = getFrameAuraClass(g, auraType);
    avatarImg.className = 'profile-avatar ' + auraClass;
    avatarImg.style.border = '';
    avatarImg.style.boxShadow = '';

    const intVal = parseInt(intensity) || 100;
    if (intVal < 100 && auraClass !== 'aura-grade-a') {
        const factor = Math.max(0.2, intVal / 100);
        avatarImg.style.filter = `brightness(${0.8 + 0.3 * factor}) saturate(${0.7 + 0.4 * factor})`;
    } else if (intVal > 100 && auraClass !== 'aura-grade-a') {
        const over = Math.min(4.0, (intVal - 100) / 100);
        const colorMap = { orange: '#ff5500', crimson: '#ef4444', purple: '#a855f7', rainbow: '#00e5ff', gold: '#ffd700', yellow: '#facc15', cyan: '#00e5ff', white: '#ffffff' };
        const hex = colorMap[String(auraType || '').toLowerCase()] || (g === 'SS+' ? '#ffd700' : '#00e5ff');
        const d1 = Math.round(6 + over * 12);
        const d2 = Math.round(12 + over * 22);
        avatarImg.style.filter = `brightness(${(1 + over * 0.22).toFixed(2)}) drop-shadow(0 0 ${d1}px ${hex}) drop-shadow(0 0 ${d2}px ${hex})`;
    } else {
        avatarImg.style.filter = '';
    }

    // Render custom AI Ring Overlay & FX around #topbar-avatar-container
    const container = document.getElementById('topbar-avatar-container') || avatarImg.parentElement;
    if (container) {
        container.querySelectorAll('.custom-frame-ring-overlay, .game-fx-deco').forEach(el => el.remove());
        const fx = frameFx || 'pulse_breathe';
        if (fx === 'reverse_dual' || fx === 'electric_orbit' || fx === 'flame_halo') {
            const deco = document.createElement('div');
            deco.className = 'game-fx-deco ' + (fx === 'reverse_dual' ? 'dual-ring' : (fx === 'electric_orbit' ? 'spark-orbit' : 'flame-ring'));
            container.appendChild(deco);
        }
        if (ringUrl) {
            const ringEl = document.createElement('img');
            ringEl.src = ringUrl;
            ringEl.className = 'custom-frame-ring-overlay game-fx-ring-' + fx;
            const sc = parseInt(frameScale) || 120;
            ringEl.style.width = sc + '%';
            ringEl.style.height = sc + '%';
            container.appendChild(ringEl);
        }
    }

    const tagEl = document.getElementById('bar-avatar-grade-tag');
    if (tagEl) {
        const tagClass = 'tag-' + g.toLowerCase().replace('+', 'plus');
        tagEl.className = 'avatar-grade-tag ' + tagClass;
        tagEl.textContent = g;
        tagEl.style.display = 'inline-block';
    }
    window.equippedFrameGrade = g;
    window.equippedFrameAura = auraType;
    window.equippedFrameIntensity = intVal;
}

// =========================================================================
// 🎁 DAILY MATCH 4x2 MINI-GAME (กิจกรรมประจำวัน สุ่มจับคู่แผ่นป้าย)
// =========================================================================
let dailyChancesLeft = 3;
let dailyMatchTiles = [];
let dailyMatchedPairs = [];
let dailyFlippedIndices = [];
let dailyCanPlay = true;
let dailyResetInterval = null;

window.openDailyMatchModal = async function() {
    openModal('modal-daily-match');
    try {
        const res = await apiClient.request('api/shop.php?action=get_daily_match_status');
        if (res && res.status === 'success') {
            dailyCanPlay = Boolean(res.can_play);
            dailyChancesLeft = res.can_play ? (res.max_chances || 3) : 0;
            dailyMatchTiles = res.tiles || [];
            dailyMatchedPairs = [];
            dailyFlippedIndices = [];

            if (res.seconds_until_reset !== undefined) {
                startDailyResetCountdown(res.seconds_until_reset);
            }

            const playView = document.getElementById('daily-match-play-view');
            const claimedView = document.getElementById('daily-match-claimed-view');

            if (!res.can_play && res.last_rewards && res.last_rewards.length > 0) {
                if (playView) playView.style.display = 'none';
                if (claimedView) claimedView.style.display = 'block';
                renderDailyClaimedView(res.last_rewards);
            } else {
                if (playView) playView.style.display = 'block';
                if (claimedView) claimedView.style.display = 'none';
                renderDailyMatchGrid();
            }
        }
    } catch (e) {
        console.error('Failed to load daily match:', e);
        renderDailyMatchGrid();
    }
};

function startDailyResetCountdown(initialSeconds) {
    if (dailyResetInterval) clearInterval(dailyResetInterval);
    let remaining = initialSeconds;

    const timerEl = document.getElementById('daily-reset-timer');
    const claimedTimerEl = document.getElementById('daily-claimed-next-timer');
    function updateTimerDisplay() {
        const text = remaining <= 0 ? 'รีเซ็ตรอบใหม่แล้ว!' : `เหลืออีก ${Math.floor(remaining / 3600)} ชม. ${Math.floor((remaining % 3600) / 60)} นาที ${remaining % 60} วิ (21:00 น.)`;
        if (timerEl) timerEl.innerText = text;
        if (claimedTimerEl) claimedTimerEl.innerText = text;
    }

    updateTimerDisplay();
    dailyResetInterval = setInterval(() => {
        remaining--;
        updateTimerDisplay();
        if (remaining <= 0) {
            clearInterval(dailyResetInterval);
        }
    }, 1000);
}

function renderDailyMatchGrid() {
    const gridEl = document.getElementById('daily-match-tiles-grid');
    const badgeEl = document.getElementById('daily-chances-badge');
    const basketEl = document.getElementById('daily-matched-basket');
    const claimBtn = document.getElementById('btn-claim-daily-match');

    if (badgeEl) badgeEl.innerText = `${dailyChancesLeft} / 3 ครั้ง`;
    if (basketEl) basketEl.innerHTML = '<span style="font-size: 11px; color: #64748b;">(ยังไม่ได้จับคู่สำเร็จ แตะเปิดแผ่นป้ายด้านบนเพื่อค้นหาคู่ที่ตรงกัน)</span>';

    if (!dailyCanPlay) {
        if (claimBtn) {
            claimBtn.disabled = true;
            claimBtn.style.opacity = '0.5';
            claimBtn.style.cursor = 'not-allowed';
            claimBtn.innerText = '✅ คุณใช้สิทธิ์ของวันนี้แล้ว (รีเซ็ตใหม่ 21:00 น. หลัง 3 ทุ่ม)';
        }
        if (gridEl) {
            gridEl.innerHTML = dailyMatchTiles.map((t, idx) => `
                <div class="match-tile flipped matched">
                    <div class="tile-face tile-back">
                        <div class="card-back-ornament"></div>
                        <div class="card-back-icon">🃏</div>
                        <div class="card-back-badge">แผ่นที่ ${idx + 1}</div>
                    </div>
                    <div class="tile-face tile-front">
                        <div class="tile-icon">${t.icon}</div>
                        <div class="tile-name">${t.name}</div>
                    </div>
                </div>
            `).join('');
        }
        return;
    }

    if (claimBtn) {
        claimBtn.disabled = true;
        claimBtn.style.opacity = '0.6';
        claimBtn.style.cursor = 'not-allowed';
        claimBtn.innerText = '🎁 เปิดให้ครบ 3 ครั้ง เพื่อกดรับไอเทมรางวัล';
    }

    if (gridEl) {
        gridEl.innerHTML = dailyMatchTiles.map((t, idx) => `
            <div class="match-tile" id="daily-tile-${idx}" onclick="handleDailyTileClick(${idx})">
                <div class="tile-face tile-back">
                    <div class="card-back-ornament"></div>
                    <div class="card-back-icon">🃏</div>
                    <div class="card-back-badge">แผ่นที่ ${idx + 1}</div>
                </div>
                <div class="tile-face tile-front">
                    <div class="tile-icon">${t.icon}</div>
                    <div class="tile-name">${t.name}</div>
                </div>
            </div>
        `).join('');
    }
}

let isProcessingDailyFlip = false;
window.handleDailyTileClick = function(idx) {
    if (!dailyCanPlay || isProcessingDailyFlip || dailyChancesLeft <= 0) return;
    const tileEl = document.getElementById('daily-tile-' + idx);
    if (!tileEl || tileEl.classList.contains('flipped') || tileEl.classList.contains('matched')) return;

    // Flip this tile
    tileEl.classList.add('flipped');
    dailyFlippedIndices.push(idx);

    if (dailyFlippedIndices.length === 2) {
        isProcessingDailyFlip = true;
        const [idx1, idx2] = dailyFlippedIndices;
        const tile1 = dailyMatchTiles[idx1];
        const tile2 = dailyMatchTiles[idx2];
        const el1 = document.getElementById('daily-tile-' + idx1);
        const el2 = document.getElementById('daily-tile-' + idx2);

        dailyChancesLeft--;
        const badgeEl = document.getElementById('daily-chances-badge');
        if (badgeEl) badgeEl.innerText = `${dailyChancesLeft} / 3 ครั้ง`;

        // Check Match
        if (tile1.pair_id === tile2.pair_id) {
            // MATCH!
            setTimeout(() => {
                if (el1) el1.classList.add('matched');
                if (el2) el2.classList.add('matched');
                dailyMatchedPairs.push(tile1);

                // Update matched basket
                updateMatchedBasket();
                if (typeof confetti === 'function') confetti({ particleCount: 30, spread: 45 });

                dailyFlippedIndices = [];
                isProcessingDailyFlip = false;
                checkDailyChancesFinished();
            }, 500);
        } else {
            // NO MATCH: แสดงแบบจางๆ ให้ผู้เล่นจดจำ แล้วคว่ำกลับ
            setTimeout(() => {
                if (el1) el1.classList.add('dimmed');
                if (el2) el2.classList.add('dimmed');

                setTimeout(() => {
                    if (el1) {
                        el1.classList.remove('flipped');
                        el1.classList.remove('dimmed');
                    }
                    if (el2) {
                        el2.classList.remove('flipped');
                        el2.classList.remove('dimmed');
                    }
                    dailyFlippedIndices = [];
                    isProcessingDailyFlip = false;
                    checkDailyChancesFinished();
                }, 1100);
            }, 500);
        }
    }
};

function updateMatchedBasket() {
    const basketEl = document.getElementById('daily-matched-basket');
    if (!basketEl) return;
    if (dailyMatchedPairs.length === 0) {
        basketEl.innerHTML = '<span style="font-size: 11px; color: #64748b;">(ยังไม่ได้จับคู่สำเร็จ แตะเปิดแผ่นป้ายด้านบนเพื่อค้นหาคู่ที่ตรงกัน)</span>';
        return;
    }
    basketEl.innerHTML = dailyMatchedPairs.map(p => `
        <div style="display:flex; align-items:center; gap:6px; background:rgba(255,215,0,0.18); border:1.5px solid #ffd700; padding:4px 10px; border-radius:12px; box-shadow:0 0 10px rgba(255,215,0,0.3);">
            <span style="font-size:16px;">${p.icon}</span>
            <span style="font-size:12px; font-weight:700; color:#fff;">${p.name}</span>
        </div>
    `).join('');
}

function checkDailyChancesFinished() {
    const claimBtn = document.getElementById('btn-claim-daily-match');
    if (dailyChancesLeft <= 0 || dailyMatchedPairs.length >= 3) {
        if (claimBtn) {
            if (dailyMatchedPairs.length > 0) {
                claimBtn.disabled = false;
                claimBtn.style.opacity = '1';
                claimBtn.style.cursor = 'pointer';
                claimBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
                claimBtn.style.color = '#fff';
                claimBtn.innerText = `🎉 กดรับของรางวัล (${dailyMatchedPairs.length} รายการ)`;
            } else {
                claimBtn.disabled = true;
                claimBtn.style.opacity = '0.6';
                claimBtn.style.cursor = 'not-allowed';
                claimBtn.innerText = '❌ ไม่ตรงกันในรอบนี้ (ไว้ลองใหม่หลัง 3 ทุ่ม 21:00 น.)';
            }
        }
    }
}

function renderDailyClaimedView(rewards) {
    const playView = document.getElementById('daily-match-play-view');
    const claimedView = document.getElementById('daily-match-claimed-view');
    const listEl = document.getElementById('daily-claimed-rewards-list');

    if (playView) playView.style.display = 'none';
    if (claimedView) claimedView.style.display = 'block';

    if (!listEl) return;

    if (!rewards || rewards.length === 0) {
        listEl.innerHTML = `
            <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 18px; color: #cbd5e1; font-size: 13px;">
                <div style="font-size: 32px; margin-bottom: 6px;">🎯</div>
                <div>ในรอบนี้ยังเปิดไม่ตรงคู่กัน</div>
                <div style="color: #fbbf24; font-size: 12px; margin-top: 4px;">อย่าเพิ่งท้อ! สิทธิ์ใหม่จะรีเซ็ตให้เปิดอีกครั้งหลัง 21:00 น. วันนี้</div>
            </div>
        `;
        return;
    }

    listEl.innerHTML = rewards.map(r => `
        <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(30, 41, 59, 0.75); border: 1.5px solid rgba(245, 158, 11, 0.4); border-radius: 12px; padding: 12px 18px; box-shadow: 0 4px 15px rgba(0,0,0,0.35);">
            <div style="display: flex; align-items: center; gap: 14px;">
                <span style="font-size: 32px; filter: drop-shadow(0 0 10px rgba(245,158,11,0.5));">${r.icon || '🎁'}</span>
                <div style="text-align: left;">
                    <div style="font-size: 15px; font-weight: 800; color: #fff;">${r.name}</div>
                    <div style="font-size: 11px; color: #fbbf24;">รางวัลจากการจับคู่สำเร็จ</div>
                </div>
            </div>
            <span style="font-size: 13px; font-weight: 800; color: #34d399; background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; padding: 5px 14px; border-radius: 20px;">
                ✓ รับแล้ว
            </span>
        </div>
    `).join('');
}

window.claimDailyMatchRewardsAction = async function() {
    if (dailyMatchedPairs.length === 0) return;
    const claimBtn = document.getElementById('btn-claim-daily-match');
    if (claimBtn) {
        claimBtn.disabled = true;
        claimBtn.innerText = 'กำลังบันทึกของรางวัล...';
    }

    try {
        const res = await apiClient.request('api/shop.php?action=claim_daily_match', {
            method: 'POST',
            body: JSON.stringify({
                action: 'claim_daily_match',
                matched_pairs: dailyMatchedPairs
            })
        });

        if (res && res.status === 'success') {
            if (typeof confetti === 'function') {
                confetti({ particleCount: 150, spread: 85, origin: { y: 0.6 } });
            }

            const oldDia = Number(DEFAULT_USER.diamond || 0);
            const oldGold = Number(DEFAULT_USER.gold || 0);
            const targetDia = (res.new_diamond !== undefined) ? Number(res.new_diamond) : (oldDia + (res.awarded_diamond || 0));
            const targetGold = (res.new_gold !== undefined) ? Number(res.new_gold) : (oldGold + (res.awarded_gold || 0));

            DEFAULT_USER.diamond = targetDia;
            DEFAULT_USER.gold = targetGold;

            // Persist immediately in localStorage
            try {
                localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
            } catch (e) {}

            // Update top bar numbers immediately
            updateUserBar(DEFAULT_USER);
            animateCurrencyCounter('bar-diamond', oldDia, targetDia, 1200);
            animateCurrencyCounter('bar-gold', oldGold, targetGold, 1200);

            // Fetch latest fresh profile in background for 100% guarantee
            if (window.apiClient) {
                apiClient.getProfile().then(prof => {
                    if (prof && prof.status === 'success' && prof.data) {
                        Object.assign(DEFAULT_USER, prof.data);
                        localStorage.setItem('snake_user_data', JSON.stringify(DEFAULT_USER));
                        updateUserBar(DEFAULT_USER);
                    }
                }).catch(() => {});
            }

            // Play sound if available
            if (window.soundManager && typeof soundManager.play === 'function') {
                soundManager.play('win');
            }

            showToast(`🎉 รับของรางวัลสำเร็จ! +${(res.awarded_diamond || 0).toLocaleString()} เพชร / +${(res.awarded_gold || 0).toLocaleString()} ทอง`);

            // Switch to claimed view
            renderDailyClaimedView(dailyMatchedPairs);
        } else {
            showToast(res.message || 'ไม่สามารถรับรางวัลได้');
            if (claimBtn) {
                claimBtn.disabled = false;
                claimBtn.innerText = 'ลองใหม่อีกครั้ง';
            }
        }
    } catch(e) {
        console.error('Claim error:', e);
        showToast('เกิดข้อผิดพลาดในการรับของรางวัล');
        if (claimBtn) {
            claimBtn.disabled = false;
            claimBtn.innerText = 'ลองใหม่อีกครั้ง';
        }
    }
};

// =========================================================================
// 🌟 EVENT GACHA CONTROLLER (อีเวนต์พิเศษ สุ่มกรอบรูป & ลูกเต๋า 3D)
// =========================================================================
let currentEventGachaData = null;
let eventGachaTimerInterval = null;

window.openEventGachaModal = async function() {
    openModal('modal-event-gacha');
    await loadEventGachaData();
};

window.loadEventGachaData = async function() {
    try {
        const res = await apiClient.getActiveEventGacha();
        if (res && res.status === 'success' && res.data) {
            currentEventGachaData = res.data;
            renderEventGachaUI(res.data);
        }
    } catch (e) {
        console.error('Failed to load event gacha:', e);
    }
};

function renderEventGachaUI(ev) {
    const badgeEl = document.getElementById('event-gacha-badge');
    const titleEl = document.getElementById('event-gacha-title');
    const descEl = document.getElementById('event-gacha-desc');
    const timerEl = document.getElementById('event-gacha-countdown');
    const showcaseEl = document.getElementById('event-gacha-targets-showcase');
    const exchangeEl = document.getElementById('event-gacha-shadow-exchange-panel');
    const singleCostEl = document.getElementById('btn-cost-single');
    const packCostEl = document.getElementById('btn-cost-pack');

    if (badgeEl) badgeEl.innerText = ev.is_live_now ? '✨ กิจกรรมพิเศษเปิดอยู่' : '⏳ กิจกรรมปิดแล้ว';
    if (titleEl) titleEl.innerText = ev.name || 'เทศกาลสุ่มการ์ด & ลูกเต๋า 3D';
    if (descEl) descEl.innerText = ev.description || 'เปิดแพ็คการ์ดสุ่ม สะสมการ์ดเงา 5 สีแลกกรอบรูปตัวละครระดับ SS+ และลุ้นรับลูกเต๋า 3D เรตอัปเป้าหมายทันที';

    const costSingle = ev.cost_diamond || 100;
    const costPack = Math.round(costSingle * 5 * 0.9);
    if (singleCostEl) singleCostEl.innerText = `💎 ${costSingle}`;
    if (packCostEl) packCostEl.innerText = `💎 ${costPack} (ลด 10%)`;

    // Countdown
    if (eventGachaTimerInterval) clearInterval(eventGachaTimerInterval);
    let rem = ev.remaining_seconds || 0;
    function updateTimer() {
        if (!timerEl) return;
        if (rem <= 0) {
            timerEl.innerText = 'เปิดตลอดเวลา / สิ้นสุดรอบแล้ว';
        } else {
            const days = Math.floor(rem / 86400);
            const hrs = Math.floor((rem % 86400) / 3600);
            const mins = Math.floor((rem % 3600) / 60);
            const secs = rem % 60;
            timerEl.innerText = `${days > 0 ? days + ' วัน ' : ''}${hrs} ชม. ${mins} นาที ${secs} วิ`;
        }
    }
    updateTimer();
    if (rem > 0) {
        eventGachaTimerInterval = setInterval(() => {
            rem--;
            updateTimer();
            if (rem <= 0) clearInterval(eventGachaTimerInterval);
        }, 1000);
    }

    // Showcase
    if (showcaseEl && ev.target_character) {
        const char = ev.target_character;
        const dice = ev.target_dice;
        showcaseEl.innerHTML = `
            <div style="background: rgba(15, 23, 42, 0.75); border: 1.5px solid #ffd700; border-radius: 10px; padding: 6px 10px; display: flex; align-items: center; gap: 8px; box-shadow: 0 0 14px rgba(255, 215, 0, 0.2);">
                <div style="width: 38px; height: 38px; border-radius: 50%; border: 1.5px solid #ffd700; overflow: hidden; flex-shrink: 0; box-shadow: 0 0 10px #ffd700;">
                    <img src="${char.avatar_url || 'avatars/google_avatar.png'}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src='avatars/google_avatar.png';">
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="display:flex; align-items:center; gap:5px;">
                        <span style="font-size: 10px; background: #ffd700; color: #000; font-weight: 900; padding: 1px 5px; border-radius: 4px;">${char.grade || 'SS+'}</span>
                        <strong style="color: #fff; font-size: 12.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${char.name || 'ตัวละครเป้าหมาย'}</strong>
                    </div>
                    <div style="font-size: 10px; color: #38bdf8; margin-top: 1px;">⚡ สกิล: ${char.skill_name || 'พลังควบคุมเต๋าขั้นสูง'}</div>
                    <div style="font-size: 9.5px; color: #94a3b8; margin-top: 1px;">ควบคุมเต๋า +${char.dice_control_bonus || 85}% • ส่วนลดค่าผ่านทาง +${char.toll_discount_bonus || 90}%</div>
                </div>
            </div>
            ${dice ? `
            <div style="background: rgba(15, 23, 42, 0.75); border: 1.5px solid #00e5ff; border-radius: 10px; padding: 6px 10px; display: flex; align-items: center; gap: 8px; box-shadow: 0 0 14px rgba(0, 229, 255, 0.2);">
                <div style="font-size: 24px; width: 38px; height: 38px; display:flex; align-items:center; justify-content:center; background: rgba(0,229,255,0.15); border-radius: 8px; border: 1px solid #00e5ff; flex-shrink: 0;">
                    🎲
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="display:flex; align-items:center; gap:5px;">
                        <span style="font-size: 10px; background: #00e5ff; color: #000; font-weight: 900; padding: 1px 5px; border-radius: 4px;">3D DICE</span>
                        <strong style="color: #fff; font-size: 12.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${dice.name || 'ลูกเต๋าเป้าหมาย'}</strong>
                    </div>
                    <div style="font-size: 10px; color: #00e5ff; margin-top: 1px;">🎲 ควบคุมเต๋า: +${dice.dice_control || 75}%</div>
                    <div style="font-size: 9.5px; color: #94a3b8; margin-top: 1px;">เอฟเฟกต์ทอย 3D เปล่งแสงพิเศษเฉพาะตัว</div>
                </div>
            </div>
            ` : ''}
        `;
    }

    // Shadow Exchange Panel
    if (exchangeEl && ev.reqs) {
        const uMats = ev.user_materials || {};
        const mats = [
            { code: 'SHADOW_BLACK_A', name: 'เงาดำ A', user: uMats['SHADOW_BLACK_A'] || 0, req: ev.reqs.black || 15, color: '#94a3b8' },
            { code: 'SHADOW_RED_A', name: 'เงาแดง A', user: uMats['SHADOW_RED_A'] || 0, req: ev.reqs.red || 15, color: '#ef4444' },
            { code: 'SHADOW_ORANGE_A', name: 'เงาส้ม A', user: uMats['SHADOW_ORANGE_A'] || 0, req: ev.reqs.orange || 15, color: '#f97316' },
            { code: 'SHADOW_BLUE_APLUS', name: 'เงาฟ้า A+', user: (uMats['SHADOW_BLUE_APLUS'] || 0) + (uMats['SHADOW_BLUE_A'] || 0), req: ev.reqs.blue || 10, color: '#38bdf8' },
            { code: 'SHADOW_GOLD_S', name: 'เงาทอง S+', user: (uMats['SHADOW_GOLD_S'] || 0) + (uMats['SHADOW_GOLD_APLUS'] || 0), req: ev.reqs.gold || 4, color: '#ffd700' }
        ];

        let canExchange = mats.every(m => m.user >= m.req);

        exchangeEl.innerHTML = `
            <div style="background: rgba(15, 23, 42, 0.9); border: 1.5px solid rgba(255, 215, 0, 0.4); border-radius: 10px; padding: 6px 10px; height:100%; box-sizing:border-box; display:flex; flex-direction:column; justify-content:space-between;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 4px;">
                    <div style="font-size: 11.5px; font-weight: 800; color: #ffd700; display:flex; align-items:center; gap:5px;">
                        <span>🃏</span> สะสมเงาแลก [เกรด ${ev.target_character?.grade || 'SS+'}] ${ev.target_character?.name || 'ตัวละคร'}:
                    </div>
                    <button onclick="exchangeSPlusAction(${ev.target_character?.id || 1}, '${ev.target_character?.grade || 'SS+'}')" class="btn" style="padding: 3px 10px; font-size: 10.5px; font-weight: 800; border-radius: 6px; border: none; cursor: ${canExchange ? 'pointer' : 'not-allowed'}; background: ${canExchange ? 'linear-gradient(135deg, #ffd700, #f59e0b)' : 'rgba(255,255,255,0.1)'}; color: ${canExchange ? '#000' : '#64748b'}; box-shadow: ${canExchange ? '0 0 10px #ffd700' : 'none'};" ${canExchange ? '' : 'disabled'}>
                        ${canExchange ? '🎉 แลกรับทันที!' : 'เงาไม่ครบ'}
                    </button>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(95px, 1fr)); gap: 4px;">
                    ${mats.map(m => {
                        const isEnough = m.user >= m.req;
                        return `
                            <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid ${isEnough ? m.color : 'rgba(255,255,255,0.1)'}; border-radius: 6px; padding: 4px 6px; text-align: center;">
                                <div style="font-size: 10px; font-weight: 700; color: ${m.color};">${m.name}</div>
                                <div style="font-size: 11px; font-weight: 800; color: ${isEnough ? '#10b981' : '#f87171'}; margin-top: 1px;">
                                    ${m.user} / ${m.req} ${isEnough ? '✓' : ''}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }
}

window.exchangeSPlusAction = function(charId, grade) {
    return window.doCraftFrameTier(grade || 'SS+', charId, 'event');
};

window.rollEventGachaAction = async function(count = 1) {
    if (!window.apiClient) return;
    try {
        const res = await apiClient.rollEventGacha(count);
        if (res && res.status === 'success') {
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            if (typeof showGachaCardsRevealModal === 'function') {
                showGachaCardsRevealModal(res.drops, res.pack_count || count, res.total_cards || (count * 5), res.diamonds_spent);
            }
            await loadEventGachaData();
        } else {
            showInGameAlert(res.message || 'เพชรไม่เพียงพอ', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการสุ่ม', 'ข้อผิดพลาด', '❌');
    }
};

// =========================================================================
// 🧊 MAGIC CUBE SPINNER CONTROLLER (หมุนลูกบาศก์นำโชค)
// =========================================================================
let currentCubesData = { cubes: [], configs: [] };
let selectedCubeForSpin = null;
let magicCubeInterval = null;

window.openMagicCubeModal = async function() {
    openModal('modal-magic-cube');
    await loadMagicCubesData();
};

window.loadMagicCubesData = async function() {
    try {
        const res = await apiClient.getUserCubes();
        if (res && res.status === 'success' && res.data) {
            currentCubesData = res.data;
            renderMagicCubeSlots();
            renderUserCubesTray();
            startMagicCubeLiveTimers();
        }
    } catch (e) {
        console.error('Failed to load magic cubes:', e);
    }
};

function startMagicCubeLiveTimers() {
    if (magicCubeInterval) clearInterval(magicCubeInterval);
    magicCubeInterval = setInterval(() => {
        let hasSpinning = false;
        if (currentCubesData && currentCubesData.cubes) {
            for (const c of currentCubesData.cubes) {
                if (c.status === 'SPINNING') {
                    if (c.remaining_seconds > 0) {
                        c.remaining_seconds--;
                        hasSpinning = true;
                    } else {
                        c.status = 'READY';
                    }
                }
            }
        }
        updateMagicCubeSlotTimers();
        if (!hasSpinning && (!currentCubesData.cubes.some(c => c.status === 'SPINNING'))) {
            clearInterval(magicCubeInterval);
        }
    }, 1000);
}

function updateMagicCubeSlotTimers() {
    for (let slot = 1; slot <= 4; slot++) {
        const cube = currentCubesData.cubes.find(c => c.slot_index === slot && c.status !== 'CLAIMED');
        const timerEl = document.getElementById(`cube-slot-${slot}-timer`);
        if (timerEl && cube) {
            if (cube.status === 'READY') {
                timerEl.innerHTML = '<span style="color:#10b981; font-weight:800;">🎉 หมุนเสร็จแล้ว! แตะเพื่อเปิดรับรางวัล</span>';
            } else if (cube.status === 'SPINNING') {
                const s = cube.remaining_seconds || 0;
                const hrs = Math.floor(s / 3600);
                const mins = Math.floor((s % 3600) / 60);
                const secs = s % 60;
                timerEl.innerHTML = `<span style="color:#ffd700; font-weight:800;">⏳ กำลังหมุน: ${hrs > 0 ? hrs + ' ชม. ' : ''}${mins} นาที ${secs} วิ</span>`;
            }
        }
    }
}

window.renderMagicCubeSlots = function() {
    const grid = document.getElementById('magic-cube-slots-grid');
    if (!grid) return;

    let html = '';
    for (let slot = 1; slot <= 4; slot++) {
        const cube = currentCubesData.cubes.find(c => c.slot_index === slot && c.status !== 'CLAIMED');
        if (!cube) {
            html += `
                <div class="cube-slot-card" style="border: 1.5px dashed rgba(56, 189, 248, 0.4); text-align: center; padding: 8px 6px; border-radius: 10px; background: rgba(15, 23, 42, 0.5); min-height: 125px; display:flex; flex-direction:column; justify-content:center; align-items:center;">
                    <div style="font-size: 10px; color: #64748b; font-weight: 700; margin-bottom: 4px;">ช่องที่ ${slot}</div>
                    <div style="font-size: 26px; opacity: 0.35; margin-bottom: 4px;">🧊</div>
                    <div style="font-size: 11px; color: #94a3b8; font-weight: 700;">ช่องว่าง</div>
                    <div style="font-size: 9.5px; color: #64748b; margin-top: 2px;">แตะลูกบาศก์ด้านล่าง</div>
                </div>
            `;
        } else {
            const isSpinning = cube.status === 'SPINNING';
            const isReady = cube.status === 'READY';
            const color = cube.color_hex || '#00e5ff';

            html += `
                <div class="cube-slot-card" style="border: 1.5px solid ${color}; text-align: center; padding: 6px 8px; border-radius: 10px; background: radial-gradient(circle at center, rgba(30, 41, 59, 0.9) 0%, rgba(10, 15, 29, 0.98) 100%); box-shadow: 0 0 14px ${color}33; position: relative; min-height: 125px; display:flex; flex-direction:column; justify-content:space-between;">
                    <div style="display:flex; justify-content:space-between; align-items:center; width:100%;">
                        <span style="font-size: 9.5px; color: #94a3b8; font-weight: 700;">ช่องที่ ${slot}</span>
                        ${!isSpinning && !isReady ? `<button onclick="removeCubeFromSlotAction(${cube.id})" style="background:none; border:none; color:#f87171; font-size:10px; cursor:pointer; font-weight:800;">✕ นำออก</button>` : ''}
                    </div>

                    <div style="margin: 4px 0; cursor:pointer;" onclick="${isReady ? `claimCubeRewardAction(${cube.id})` : (!isSpinning ? `showCubeSpinConfirmModal(${cube.id})` : `speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})`)}">
                        <div class="magic-cube-box ${isSpinning ? 'spinning-fast' : ''}" style="margin: 0 auto; width: 34px; height: 34px; font-size: 26px; display:flex; align-items:center; justify-content:center; filter: drop-shadow(0 0 8px ${color});">
                            🧊
                        </div>
                        <div style="font-size: 11.5px; font-weight: 800; color: #fff; margin-top: 2px;">${cube.cube_name || cube.cube_type}</div>
                    </div>

                    <div id="cube-slot-${slot}-timer" style="font-size: 10px; min-height: 16px;">
                        ${isReady ? '<span style="color:#10b981; font-weight:800;">🎉 หมุนเสร็จแล้ว! แตะรับ</span>' :
                          (isSpinning ? `<span style="color:#ffd700; font-weight:800;">⏳ กำลังหมุน...</span>` :
                          '<span style="color:#38bdf8; font-weight:700;">แตะเพื่อหมุน</span>')}
                    </div>

                    <div style="margin-top: 4px;">
                        ${isReady ? `
                            <button onclick="claimCubeRewardAction(${cube.id})" class="btn" style="width:100%; padding: 4px; font-size: 10.5px; font-weight: 900; background: linear-gradient(135deg, #10b981, #059669); color: #fff; border:none; border-radius: 6px; cursor:pointer; box-shadow: 0 0 10px rgba(16,185,129,0.5);">
                                🎁 รับรางวัล
                            </button>
                        ` : (isSpinning ? `
                            <button onclick="speedupCubeAction(${cube.id}, ${cube.instant_open_diamond || 10})" class="btn" style="width:100%; padding: 3px; font-size: 10px; font-weight: 800; background: linear-gradient(135deg, #06b6d4, #0284c7); color: #fff; border:none; border-radius: 6px; cursor:pointer;">
                                ⚡ เปิดทันที (💎 ${cube.instant_open_diamond || 10})
                            </button>
                        ` : `
                            <button onclick="showCubeSpinConfirmModal(${cube.id})" class="btn" style="width:100%; padding: 4px; font-size: 10.5px; font-weight: 800; background: linear-gradient(135deg, #f59e0b, #d97706); color: #000; border:none; border-radius: 6px; cursor:pointer;">
                                🌀 เริ่มหมุน
                            </button>
                        `)}
                    </div>
                </div>
            `;
        }
    }
    grid.innerHTML = html;
};

function renderUserCubesTray() {
    const tray = document.getElementById('user-cubes-slots-row');
    const countEl = document.getElementById('user-cube-count');
    if (!tray) return;

    const unequipped = currentCubesData.cubes.filter(c => c.slot_index === null && c.status === 'IDLE');
    if (countEl) countEl.innerText = unequipped.length;

    if (unequipped.length === 0) {
        tray.innerHTML = `
            <div style="color:#64748b; font-size:12px; padding:20px; text-align:center; width:100%;">
                ยังไม่มีลูกบาศก์ในกระเป๋า ชนะการแข่งขันในห้อง 2M / 5M / 10M เพื่อรับลูกบาศก์ฟรี!
            </div>
        `;
        return;
    }

    tray.innerHTML = unequipped.map(c => `
        <div onclick="equipCubeToFirstEmptySlot(${c.id})" style="background: rgba(30, 41, 59, 0.85); border: 1.5px solid ${c.color_hex || '#38bdf8'}; border-radius: 10px; padding: 8px 12px; text-align: center; cursor: pointer; min-width: 90px; flex-shrink: 0; box-shadow: 0 0 10px ${c.color_hex || '#38bdf8'}33;" title="แตะเพื่อใส่แท่นหมุน">
            <div style="font-size: 26px;">🧊</div>
            <div style="font-size: 11px; font-weight: 800; color: #fff; margin-top: 3px;">${c.cube_name || c.cube_type}</div>
            <div style="font-size: 9.5px; color: #38bdf8; margin-top: 2px;">+ ใส่แท่นหมุน</div>
        </div>
    `).join('');
}

window.equipCubeToFirstEmptySlot = async function(userCubeId) {
    const occupiedSlots = currentCubesData.cubes.filter(c => c.slot_index !== null && c.status !== 'CLAIMED').map(c => c.slot_index);
    let targetSlot = 1;
    while (occupiedSlots.includes(targetSlot) && targetSlot <= 4) {
        targetSlot++;
    }
    if (targetSlot > 4) {
        showToast('แท่นหมุนเต็มแล้วทั้ง 4 ช่อง! กรุณานำออกหรือรอหมุนเสร็จ');
        return;
    }

    try {
        const res = await apiClient.equipCubeToSlot(userCubeId, targetSlot);
        if (res && res.status === 'success') {
            showToast(`ใส่ลูกบาศก์ลงช่องที่ ${targetSlot} เรียบร้อยแล้ว`);
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถใส่ลูกบาศก์ได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.removeCubeFromSlotAction = async function(userCubeId) {
    try {
        const res = await apiClient.removeCubeFromSlot(userCubeId);
        if (res && res.status === 'success') {
            showToast('นำลูกบาศก์ออกจากช่องแล้ว');
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถนำออกได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

window.showCubeSpinConfirmModal = function(userCubeId) {
    const cube = currentCubesData.cubes.find(c => c.id === userCubeId);
    if (!cube) return;
    selectedCubeForSpin = cube;

    const prevEl = document.getElementById('spin-confirm-cube-preview');
    const diaCostEl = document.getElementById('spin-cost-dia-val');
    const goldCostEl = document.getElementById('spin-cost-gold-val');
    const userDiaEl = document.getElementById('spin-user-dia-val');
    const userGoldEl = document.getElementById('spin-user-gold-val');

    if (prevEl) {
        prevEl.innerHTML = `
            <div style="font-size: 48px; filter: drop-shadow(0 0 14px ${cube.color_hex || '#38bdf8'});">🧊</div>
            <h4 style="color: #fff; margin: 6px 0 0 0; font-size: 16px;">${cube.cube_name || cube.cube_type}</h4>
            <div style="font-size: 11px; color: #94a3b8;">ระยะเวลาหมุน: ${cube.min_hours || 1} - ${cube.max_hours || 4} ชม.</div>
        `;
    }
    if (diaCostEl) diaCostEl.innerText = `${cube.spin_cost_diamond || 25} เพชร`;
    if (goldCostEl) goldCostEl.innerText = `${(cube.spin_cost_gold || 15000).toLocaleString()} ทอง`;
    if (userDiaEl) userDiaEl.innerText = (DEFAULT_USER.diamond || 0).toLocaleString();
    if (userGoldEl) userGoldEl.innerText = (DEFAULT_USER.gold || 0).toLocaleString();

    openModal('modal-cube-spin-confirm');
};

window.confirmStartSpinAction = async function(currency) {
    if (!selectedCubeForSpin) return;
    closeModal('modal-cube-spin-confirm');

    try {
        const res = await apiClient.startSpinCube(selectedCubeForSpin.id, currency, selectedCubeForSpin.slot_index || 0);
        if (res && res.status === 'success') {
            showToast('🌀 เริ่มหมุนลูกบาศก์เรียบร้อยแล้ว!');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadMagicCubesData();
        } else {
            showInGameAlert(res.message || 'ทรัพยากรไม่เพียงพอ', 'แจ้งเตือน', '⚠️');
        }
    } catch (e) {
        showInGameAlert(e.message || 'เกิดข้อผิดพลาดในการเริ่มหมุน', 'ข้อผิดพลาด', '❌');
    }
};

window.speedupCubeAction = async function(userCubeId, costDiamond) {
    showInGameConfirm(`ต้องการใช้ 💎 ${costDiamond} เพชร เพื่อเปิดลูกบาศก์นี้ทันทีใช่หรือไม่?`, async () => {
        try {
            const res = await apiClient.speedupCube(userCubeId);
            if (res && res.status === 'success') {
                showToast('⚡ ปลดล็อกลูกบาศก์สำเร็จ!');
                const prof = await apiClient.getProfile();
                if (prof && prof.data) {
                    Object.assign(DEFAULT_USER, prof.data);
                    updateUserBar(DEFAULT_USER);
                }
                await loadMagicCubesData();
            } else {
                showInGameAlert(res.message || 'เพชรไม่เพียงพอ', 'แจ้งเตือน', '⚠️');
            }
        } catch (e) {
            showInGameAlert(e.message || 'เกิดข้อผิดพลาด', 'ข้อผิดพลาด', '❌');
        }
    });
};

window.claimCubeRewardAction = async function(userCubeId) {
    try {
        const res = await apiClient.claimCubeReward(userCubeId);
        if (res && res.status === 'success') {
            showInGameAlert(res.message || 'เปิดลูกบาศก์สำเร็จ ได้รับของรางวัลแล้ว!', '🎉 รับรางวัลลูกบาศก์', '🎁');
            const prof = await apiClient.getProfile();
            if (prof && prof.data) {
                Object.assign(DEFAULT_USER, prof.data);
                updateUserBar(DEFAULT_USER);
            }
            await loadMagicCubesData();
        } else {
            showToast(res.message || 'ไม่สามารถรับรางวัลได้');
        }
    } catch (e) {
        showToast(e.message || 'เกิดข้อผิดพลาด');
    }
};

/**
 * Animate number count up smoothly in top bar with glowing golden pulse effect
 */
window.animateCurrencyCounter = function(elementId, startVal, endVal, duration = 1000) {
    const el = document.getElementById(elementId);
    if (!el || startVal === endVal) return;
    const startTime = performance.now();
    el.style.transition = 'transform 0.2s ease, text-shadow 0.2s ease';
    el.style.transform = 'scale(1.25)';
    el.style.textShadow = '0 0 14px rgba(255, 215, 0, 0.9)';
    el.style.color = '#ffd700';

    function step(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOutQuad = 1 - (1 - progress) * (1 - progress);
        const currentVal = Math.round(startVal + (endVal - startVal) * easeOutQuad);
        el.innerText = currentVal.toLocaleString();
        if (progress < 1) {
            requestAnimationFrame(step);
        } else {
            el.innerText = endVal.toLocaleString();
            setTimeout(() => {
                el.style.transform = '';
                el.style.textShadow = '';
                el.style.color = '';
            }, 300);
        }
    }
    requestAnimationFrame(step);
};

// =========================================================================
// ระบบกล่องข้อความ (Speech Bubble แบบรูปที่ 2), อิโมจิเพียวๆ, อัปเดตอิโมจิล่าสุด และระบบ @ แท็กชื่อผู้เล่น
// =========================================================================

const DEFAULT_RECENT_EMOJIS = ['😍', '😃', '😫', '😖', '😣', '😄', '🌾', '🔥'];

/**
 * ดึงรายการอิโมจิที่ใช้ล่าสุดจาก localStorage
 */
window.getRecentEmojis = function() {
    try {
        const saved = JSON.parse(localStorage.getItem('snake_recent_emojis') || 'null');
        if (Array.isArray(saved) && saved.length > 0) {
            return saved.slice(0, 8);
        }
    } catch (e) {}
    return [...DEFAULT_RECENT_EMOJIS];
};

/**
 * บันทึกอิโมจิที่เพิ่งกดใช้ขึ้นเป็นอันดับแรกในหมวด "ใช้ล่าสุด" และอัปเดต UI ทันที
 */
window.recordRecentEmoji = function(emoji) {
    if (!emoji) return;
    const clean = String(emoji).trim();
    if (!clean) return;

    let list = window.getRecentEmojis().filter(item => item !== clean);
    list.unshift(clean);
    list = list.slice(0, 8);

    try {
        localStorage.setItem('snake_recent_emojis', JSON.stringify(list));
    } catch (e) {}

    window.renderRecentEmojisUI();
};

/**
 * อัปเดตปุ่มอิโมจิในหมวด "ใช้ล่าสุด" ทั้งบนกระดานหลักและในห้องบ้าน 3D
 */
window.renderRecentEmojisUI = function() {
    const list = window.getRecentEmojis();

    const boardGrid = document.getElementById('emoji-recent-grid');
    if (boardGrid) {
        boardGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendPlayerEmoji('${em}')">${em}</button>`
        ).join('');
    }

    const clanGrid = document.getElementById('clan-emoji-recent-grid');
    if (clanGrid) {
        clanGrid.innerHTML = list.map(em =>
            `<button type="button" class="emoji-btn" onclick="sendClanRoomEmoji('${em}')">${em}</button>`
        ).join('');
    }
};

// เรียกอัปเดตหมวด "ใช้ล่าสุด" ทันทีเมื่อโหลดหน้าเว็บ
setTimeout(() => {
    if (typeof window.renderRecentEmojisUI === 'function') {
        window.renderRecentEmojisUI();
    }
}, 200);

/**
 * ดึงรายชื่อผู้เล่นที่สามารถ @ คุยด้วยได้ (จากผู้เล่นบนกระดาน 3D และสมาชิกในห้องบ้าน 3D)
 */
window.getMentionablePlayers = function() {
    const map = new Map();
    const gameInstance = window.game || window.snakeGame3D;

    // 1. ผู้เล่นบนกระดาน 3D
    if (gameInstance && Array.isArray(gameInstance.players)) {
        gameInstance.players.forEach((p, idx) => {
            if (!p || !p.username) return;
            const cleanName = String(p.username).replace(/^🤖\s*/, '').trim();
            map.set(cleanName, {
                name: cleanName,
                rawName: p.username,
                avatar: p.picture || p.pictureUrl || p.avatar_url || 'avatars/google_avatar.png',
                playerIndex: idx,
                isBot: Boolean(p.is_bot)
            });
        });
    }

    // 2. สมาชิกในห้องบ้าน 3D (ถ้ามี)
    if (typeof currentClanData === 'object' && currentClanData && Array.isArray(currentClanData.members)) {
        currentClanData.members.forEach((m) => {
            if (!m || !m.username) return;
            const cleanName = String(m.username).trim();
            if (!map.has(cleanName)) {
                map.set(cleanName, {
                    name: cleanName,
                    rawName: m.username,
                    avatar: m.avatar_url || 'avatars/google_avatar.png',
                    playerIndex: 0,
                    isBot: false
                });
            }
        });
    }

    return Array.from(map.values());
};

/**
 * แสดงรายการผู้เล่นเมื่อพิมพ์ @ หรือกดปุ่ม @
 */
window.handleChatInputMention = function(inputEl, dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl || !dropdown) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    if (atIndex === -1) {
        dropdown.style.display = 'none';
        return;
    }

    const query = val.substring(atIndex + 1).toLowerCase();
    // หากพิมพ์เว้นวรรคหลังชื่อไปแล้ว ให้ซ่อนเมนู
    if (query.includes(' ')) {
        dropdown.style.display = 'none';
        return;
    }

    const candidates = window.getMentionablePlayers().filter(p =>
        !query || p.name.toLowerCase().includes(query) || p.rawName.toLowerCase().includes(query)
    );

    if (candidates.length === 0) {
        dropdown.style.display = 'none';
        return;
    }

    dropdown.innerHTML = candidates.map(c => {
        const safeName = c.name.replace(/'/g, "\\'");
        return `
            <div class="mention-item" onclick="insertMentionTag('${inputEl.id}', '${dropdownId}', '${safeName}')">
                <img src="${c.avatar}" onerror="this.src='avatars/google_avatar.png'">
                <span>@${c.name}</span>
            </div>
        `;
    }).join('');
    dropdown.style.display = 'block';
};

/**
 * เมื่อกดปุ่ม @ ให้เติมเครื่องหมาย @ ลงในช่องแชทและเปิดรายชื่อคนให้เลือกทันที
 */
window.triggerMentionList = function(inputId, dropdownId) {
    const inputEl = document.getElementById(inputId);
    if (!inputEl) return;

    if (!inputEl.value.endsWith('@')) {
        inputEl.value = (inputEl.value ? inputEl.value.trimEnd() + ' ' : '') + '@';
    }
    inputEl.focus();
    window.handleChatInputMention(inputEl, dropdownId);
};

/**
 * เมื่อคลิกเลือกชื่อคนที่ต้องการ @ จากรายการ
 */
window.insertMentionTag = function(inputId, dropdownId, targetName) {
    const inputEl = document.getElementById(inputId);
    const dropdown = document.getElementById(dropdownId);
    if (!inputEl) return;

    const val = inputEl.value;
    const atIndex = val.lastIndexOf('@');
    const cleanTag = targetName.replace(/\s+/g, '_');

    if (atIndex !== -1) {
        inputEl.value = val.substring(0, atIndex) + `@${cleanTag} `;
    } else {
        inputEl.value = `@${cleanTag} ` + val;
    }

    if (dropdown) dropdown.style.display = 'none';
    inputEl.focus();
};

let mentionPillTimer = null;

window.dismissMentionPill = function() {
    const pill = document.getElementById('mention-notification-pill');
    if (pill) pill.classList.remove('show');
    if (mentionPillTimer) {
        clearTimeout(mentionPillTimer);
        mentionPillTimer = null;
    }
};

/**
 * แจ้งเตือนเมื่อมีคน @ หา: "ชื่อ..พูดถึงคุณ"
 */
window.notifyUserMentioned = function(speakerName = 'ผู้เล่น', messageText = '', avatarUrl = '') {
    const rawSpeaker = String(speakerName || 'ผู้เล่น').trim();
    const rawMsg = String(messageText || '').trim();

    // 1. แสดงกล่องแจ้งเตือน Mention Notification Pill ลอยเด่นกึ่งกลางด้านบน
    const pill = document.getElementById('mention-notification-pill');
    const authorEl = document.getElementById('mention-pill-author');
    const textEl = document.getElementById('mention-pill-text');
    const avatarEl = document.getElementById('mention-pill-avatar');

    if (authorEl) authorEl.innerText = rawSpeaker;
    if (textEl) textEl.innerText = rawMsg || 'พูดถึงคุณ';
    if (avatarEl && avatarUrl) avatarEl.src = avatarUrl;

    if (pill) {
        pill.classList.remove('show');
        void pill.offsetWidth; // Force CSS reflow
        pill.classList.add('show');

        if (mentionPillTimer) clearTimeout(mentionPillTimer);
        mentionPillTimer = setTimeout(() => {
            pill.classList.remove('show');
        }, 5000);
    }

    // 2. ส่งเสียงแจ้งเตือนแบบ Chime
    if (window.soundEngine && typeof window.soundEngine.playNotification === 'function') {
        window.soundEngine.playNotification();
    } else if (window.soundEngine && typeof window.soundEngine.playClick === 'function') {
        window.soundEngine.playClick();
    }

    // 3. แสดงข้อความ Toast เสริมความชัดเจน
    if (typeof window.showToast === 'function') {
        window.showToast(`🔔 ${rawSpeaker} พูดถึงคุณ`, 4500);
    }

    // 4. บันทึกลง Game Log
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        gameInstance.logMessage(`🔔 ${rawSpeaker} พูดถึงคุณ: "${rawMsg}"`, 'highlight');
    }
};

/**
 * ตรวจสอบว่าข้อความแชทมีการ @ หาตัวผู้เล่นคนปัจจุบันหรือไม่
 */
window.checkIfMessageMentionsMe = function(text) {
    if (!text) return false;
    const str = String(text);
    const myName = (window.DEFAULT_USER && window.DEFAULT_USER.username) || '';
    const myGameName = (window.game && window.game.players && window.game.players[0] && window.game.players[0].username) || '';

    if (str.includes('@คุณ')) return true;
    if (myName && str.includes(`@${myName}`)) return true;
    if (myGameName && str.includes(`@${myGameName}`)) return true;

    const lower = str.toLowerCase();
    if (myName && lower.includes(`@${myName.toLowerCase()}`)) return true;
    if (myGameName && lower.includes(`@${myGameName.toLowerCase()}`)) return true;

    return false;
};

/**
 * ฟังก์ชันกลางสำหรับเรียกแสดงกล่องข้อความ (Speech Bubble) หรืออิโมจิบนหัวตัวละคร 3D
 * @param {string} message ข้อความหรืออิโมจิที่ต้องการให้แสดง
 * @param {number} playerIndex ลำดับตัวละครบนกระดาน (ค่าเริ่มต้น 0 = ตัวละครของผู้เล่นหลัก)
 * @param {number} durationMs ระยะเวลาแสดงผลก่อนค่อยๆ จางหายไป (3000 - 5000 ms, ค่าเริ่มต้น 4000 ms)
 */
window.showSpeechBubble = function(message, playerIndex = 0, durationMs = 4000) {
    const text = String(message || '').trim();
    if (!text) return;

    // เชื่อมต่อกับอินสแตนซ์กระดาน 3D (window.game หรือ window.snakeGame3D)
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.showSpeechBubble === 'function') {
        gameInstance.showSpeechBubble(playerIndex, text, durationMs);
    }

    // หากคนพูดเป็นผู้เล่นอื่น (playerIndex !== 0) และข้อความมี @ หาเรา ให้แจ้งเตือนทันที!
    if (playerIndex !== 0 && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
        let speakerName = 'ผู้เล่น';
        let speakerAvatar = 'avatars/google_avatar.png';
        if (gameInstance && Array.isArray(gameInstance.players) && gameInstance.players[playerIndex]) {
            const p = gameInstance.players[playerIndex];
            speakerName = p.username || p.displayName || 'ผู้เล่น';
            speakerAvatar = p.avatar_url || p.picture || 'avatars/google_avatar.png';
        }
        if (typeof window.notifyUserMentioned === 'function') {
            window.notifyUserMentioned(speakerName, text, speakerAvatar);
        }
    }
};

/**
 * เปิด/ปิด หน้าต่างเลือกอิโมจิและส่งข้อความด่วน
 */
window.toggleEmojiChatPopover = function(forceClose = false) {
    const popover = document.getElementById('emoji-chat-popover');
    if (!popover) return;

    if (forceClose === true) {
        popover.style.display = 'none';
        const dd = document.getElementById('board-mention-dropdown');
        if (dd) dd.style.display = 'none';
        return;
    }

    const isVisible = popover.style.display !== 'none' && popover.style.display !== '';
    popover.style.display = isVisible ? 'none' : 'block';

    if (!isVisible) {
        window.renderRecentEmojisUI();
        const input = document.getElementById('input-speech-message');
        if (input) {
            setTimeout(() => input.focus(), 60);
        }
    }
};

/**
 * เมื่อผู้เล่นคลิกเลือกอิโมจิจากถาดอิโมจิ ให้แสดงเป็นตัวอิโมจิบนหัวรูปภาพทันที และอัปเดตหมวด "ใช้ล่าสุด"
 */
window.sendPlayerEmoji = function(emoji) {
    if (!emoji) return;

    // 1. บันทึกและอัปเดตอิโมจิล่าสุดขึ้นอันดับ 1 ในหมวด "ใช้ล่าสุด"
    window.recordRecentEmoji(emoji);

    // 2. แสดงอิโมจิเพียวๆ บนหัวรูปภาพตัวหมากของผู้เล่น (index 0) นาน 4 วินาที
    window.showSpeechBubble(emoji, 0, 4000);

    // 3. บันทึกลง Game Log ด้านขวาด้วย
    const gameInstance = window.game || window.snakeGame3D;
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: ${emoji}`, 'highlight');
    }

    window.toggleEmojiChatPopover(true);
};

/**
 * เมื่อผู้เล่นพิมพ์ข้อความแชท (รองรับ @ชื่อผู้เล่น) และกดส่ง หรือกดปุ่ม Enter
 */
window.sendPlayerChatMessage = function() {
    const input = document.getElementById('input-speech-message');
    if (!input) return;

    const msg = input.value.trim();
    if (!msg) return;

    // 1. แสดงข้อความในกล่องข้อความทรงวงรีสีขาวขอบดำ (แบบรูปที่ 2) บนหัวรูปภาพตัวละครของผู้เล่น
    window.showSpeechBubble(msg, 0, 4500);

    const gameInstance = window.game || window.snakeGame3D;

    // 2. หากในข้อความมีการ @หาผู้เล่นคนอื่นบนกระดาน ให้แสดงแจ้งเตือนและขึ้นข้อความที่เกี่ยวข้องด้วย
    if (gameInstance && Array.isArray(gameInstance.players)) {
        const mentionMatch = msg.match(/@([^\s]+)/);
        if (mentionMatch && mentionMatch[1]) {
            const targetKey = mentionMatch[1].replace(/_/g, ' ').toLowerCase();
            const targetIdx = gameInstance.players.findIndex((p, idx) =>
                idx !== 0 && p.username && p.username.toLowerCase().includes(targetKey)
            );
            if (targetIdx > 0) {
                const targetPlayer = gameInstance.players[targetIdx];
                if (targetPlayer.is_bot) {
                    setTimeout(() => {
                        window.showSpeechBubble(`👋 รับทราบครับ @${DEFAULT_USER.username || 'คุณ'}!`, targetIdx, 4000);
                    }, 900);
                }
            }
        }
    }

    // 3. บันทึกลง Game Log ด้านขวา
    if (gameInstance && typeof gameInstance.logMessage === 'function') {
        const playerName = (window.DEFAULT_USER && window.DEFAULT_USER.username) ? window.DEFAULT_USER.username : 'คุณ';
        gameInstance.logMessage(`💬 ${playerName}: "${msg}"`, 'highlight');
    }

    input.value = '';
    const dd = document.getElementById('board-mention-dropdown');
    if (dd) dd.style.display = 'none';
    window.toggleEmojiChatPopover(true);
};

// ปิดถาดเลือกอิโมจิเมื่อคลิกพื้นที่ว่างข้างนอก
document.addEventListener('click', function(e) {
    const popover = document.getElementById('emoji-chat-popover');
    const triggerBtn = document.getElementById('btn-toggle-emoji');
    if (popover && popover.style.display !== 'none') {
        if (!popover.contains(e.target) && (!triggerBtn || !triggerBtn.contains(e.target))) {
            popover.style.display = 'none';
        }
    }

    const clanEmojiPop = document.getElementById('clan-room-emoji-popover');
    const clanEmojiBtn = document.getElementById('btn-clan-room-emoji');
    if (clanEmojiPop && clanEmojiPop.style.display !== 'none') {
        if (!clanEmojiPop.contains(e.target) && (!clanEmojiBtn || !clanEmojiBtn.contains(e.target))) {
            clanEmojiPop.style.display = 'none';
        }
    }
});



// ==========================================================================
// 3D BOARD CATALOG, RULES & SPECIAL TILES (ROOM & MATCHMAKING FLOW)
// ==========================================================================
const BOARD_CATALOG = {
    classic: {
        id: 'classic',
        name: 'นีออนไซเบอร์ 3D (Cyber Neon)',
        shortName: 'นีออนไซเบอร์ 3D',
        badge: 'CYBER NEON',
        themeColor: '#00e5ff',
        auraDesc: 'ธีมไซไฟล้ำยุค เรืองแสงนีออนฟ้า-ชมพู คมชัดทุกสายตา',
        story: 'สังเวียนการแข่งขันใจกลางมหานครไซเบอร์พังก์ ล้อมรอบด้วยสถาปัตยกรรมดิจิทัลแห่งโลกอนาคต เส้นทางเชื่อมต่อด้วยบันไดลำแสงไฮเทค และพญางูเลเซอร์เรืองแสงสีชมพู ทุกย่างก้าวเต็มไปด้วยความเร็วและพลังงานนีออน',
        specialBonus: '⚡ ทัศนวิสัยคมชัดสูงพิเศษ แสงนีออนสะท้อนพื้นผิวบอร์ด 3D สังเกตตำแหน่งบันไดและงูได้ง่ายที่สุด',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" style="display:block; border-radius:10px;"><defs><linearGradient id="cyberBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#070b14"/><stop offset="50%" stop-color="#0c2340"/><stop offset="100%" stop-color="#034168"/></linearGradient><filter id="cyberGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#cyberBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#111c30" stroke="#00e5ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#00e5ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00e5ff" stroke-width="3.5" filter="url(#cyberGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00e5ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00e5ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00e5ff" stroke-width="2"/><path d="M 36 -36 Q 0 -12 24 24 T -12 36" fill="none" stroke="#ff0055" stroke-width="3.5" filter="url(#cyberGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#ff0055"/></g><text x="120" y="108" text-anchor="middle" fill="#00e5ff" font-size="11" font-weight="800" letter-spacing="1">CYBER NEON 3D</text></svg>`
    },
    ancient: {
        id: 'ancient',
        name: 'วิหารทองคำพญานาค (Golden Temple)',
        shortName: 'วิหารทองคำพญานาค',
        badge: 'GOLDEN NAGA',
        themeColor: '#ffd700',
        auraDesc: 'ศาลทองคำโบราณ มนต์ขลังพญานาคราชบันไดทอง',
        story: 'มหาปราสาททองคำลอยฟ้าโบราณที่สถิตของพญานาคราชผู้พิทักษ์ บันไดทองคำส่องแสงประกายมนต์ขลัง และงูเขียวมรกตเกล็ดนาคราช ทุกย่างก้าวจะได้รับพรแห่งโชคลาภในการทอยเต๋า',
        specialBonus: '👑 มนต์มหาโชคพญานาคราช เสริมบารมีแก่ผู้เล่นที่ก้าวขึ้นบันไดทองคำสู่เส้นชัย',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" style="display:block; border-radius:10px;"><defs><linearGradient id="ancientBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1f1406"/><stop offset="50%" stop-color="#422d0d"/><stop offset="100%" stop-color="#694a16"/></linearGradient><filter id="goldGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#ancientBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#33240e" stroke="#ffd700" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ffd700" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffd700" stroke-width="3.5" filter="url(#goldGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffd700" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffd700" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffd700" stroke-width="2"/><path d="M 36 -36 Q 10 -5 20 20 T -20 24" fill="none" stroke="#00e676" stroke-width="3.5" filter="url(#goldGlow)"/><circle cx="36" cy="-36" r="4.5" fill="#00e676"/></g><text x="120" y="108" text-anchor="middle" fill="#ffd700" font-size="11" font-weight="800" letter-spacing="1">GOLDEN NAGA 3D</text></svg>`
    },
    lava: {
        id: 'lava',
        name: 'ภูเขาไฟลาวาเดือด (Lava Volcano)',
        shortName: 'ภูเขาไฟลาวาเดือด',
        badge: 'LAVA VOLCANO',
        themeColor: '#ff5722',
        auraDesc: 'ธารหินหลอมละลายร้อนแรง การแข่งขันสุดดุเดือดท้าทาย',
        story: 'ดินแดนปากปล่องภูเขาไฟใต้พิภพที่ปะทุด้วยลาวาเดือดพล่าน บันไดเหล็กหลอมเพลิงและพญางูดำอัคคี บรรยากาศร้อนระอุบีบคั้นการตัดสินใจ ผู้กล้าเท่านั้นที่จะพิชิตสู่ยอดเขา',
        specialBonus: '🔥 บรรยากาศเกมเร้าใจ ปลุกสัญชาตญาณความกระหายชัยชนะ การชิงตำแหน่งและหลบหลีกงูเพลิงสุดระทึก',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" style="display:block; border-radius:10px;"><defs><linearGradient id="lavaBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#240808"/><stop offset="50%" stop-color="#471111"/><stop offset="100%" stop-color="#751b14"/></linearGradient><filter id="lavaGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#lavaBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#2b0d0d" stroke="#ff5722" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#ff3d00" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#ffab00" stroke-width="3" filter="url(#lavaGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#ffab00" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#ffab00" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#ffab00" stroke-width="2"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#212121" stroke-width="4.5"/><path d="M 36 -36 Q 5 -10 25 15 T -15 28" fill="none" stroke="#ff3d00" stroke-width="1.8" filter="url(#lavaGlow)"/><circle cx="36" cy="-36" r="4" fill="#ff1744"/></g><text x="120" y="108" text-anchor="middle" fill="#ff5722" font-size="11" font-weight="800" letter-spacing="1">LAVA VOLCANO 3D</text></svg>`
    },
    ice: {
        id: 'ice',
        name: 'แดนน้ำแข็งคริสตัล (Crystal Ice)',
        shortName: 'แดนน้ำแข็งคริสตัล',
        badge: 'CRYSTAL ICE',
        themeColor: '#38bdf8',
        auraDesc: 'มหาธารน้ำแข็งคริสตัลขั้วโลก แสงออโรร่าประกายแก้ว',
        story: 'ยอดเขาน้ำแข็งนิรันดร์ที่ปกคลุมด้วยผลึกคริสตัลใสประกายระยิบระยับ แสงออโรร่าสีฟ้าน้ำทะเลร่ายรำบนท้องฟ้า บันไดผลึกแก้วใสและงูหมอกมนตราสีม่วง เงียบสงบแต่เยือกเย็นและเฉียบคม',
        specialBonus: '❄️ แสงสะท้อนประกายแก้ว สบายตา สมาธิตั้งมั่น วางกลยุทธ์การเดินได้อย่างเยือกเย็น',
        svg: `<svg viewBox="0 0 240 120" width="100%" height="100%" style="display:block; border-radius:10px;"><defs><linearGradient id="iceBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#051524"/><stop offset="50%" stop-color="#0f3554"/><stop offset="100%" stop-color="#1e5987"/></linearGradient><filter id="iceGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="240" height="120" fill="url(#iceBg)"/><g transform="translate(120, 58) scale(1, 0.58) rotate(45)" opacity="0.85"><rect x="-48" y="-48" width="96" height="96" fill="#0f2a3d" stroke="#80d8ff" stroke-width="2"/><path d="M-48,-24 H48 M-48,0 H48 M-48,24 H48 M-24,-48 V48 M0,-48 V48 M24,-48 V48" stroke="#80d8ff" stroke-width="1" opacity="0.6"/><line x1="-36" y1="36" x2="12" y2="-12" stroke="#00b0ff" stroke-width="3" filter="url(#iceGlow)"/><line x1="-30" y1="30" x2="-22" y2="38" stroke="#00b0ff" stroke-width="2"/><line x1="-15" y1="15" x2="-7" y2="23" stroke="#00b0ff" stroke-width="2"/><line x1="0" y1="0" x2="8" y2="8" stroke="#00b0ff" stroke-width="2"/><path d="M 36 -36 Q 10 -5 22 22 T -18 30" fill="none" stroke="#a855f7" stroke-width="3.5" filter="url(#iceGlow)"/><circle cx="36" cy="-36" r="4" fill="#a855f7"/></g><text x="120" y="108" text-anchor="middle" fill="#80d8ff" font-size="11" font-weight="800" letter-spacing="1">CRYSTAL ICE 3D</text></svg>`
    }
};

const ROOM_TIER_CONFIG = {
    '2M': {
        tier: '2M',
        room_tier: '2M',
        title: 'ห้อง 2M (ยอดนิยม)',
        fee: 2000,
        entry_fee_gold: 2000,
        start_match_gold: 2000000,
        winDia: 200,
        winGold: 100000,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '⚡ รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 2,000 🪙 • ทองเริ่มต้นในกระดาน: 2,000,000 🪙 | ชนะรับ: 200 💎 + 100,000 🪙'
    },
    '5M': {
        tier: '5M',
        room_tier: '5M',
        title: 'ห้อง 5M (ระดับเซียน)',
        fee: 5000,
        entry_fee_gold: 5000,
        start_match_gold: 5000000,
        winDia: 500,
        winGold: 300000,
        tax_amount: 120000,
        tax_percent: 22,
        city_base_cost: 300000,
        landmark_cost: 800000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🔥 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 5,000 🪙 • ทองเริ่มต้นในกระดาน: 5,000,000 🪙 | ชนะรับ: 500 💎 + 300,000 🪙'
    },
    '10M': {
        tier: '10M',
        room_tier: '10M',
        title: 'ห้อง 10M (มหาเศรษฐี)',
        fee: 10000,
        entry_fee_gold: 10000,
        start_match_gold: 10000000,
        winDia: 1200,
        winGold: 800000,
        tax_amount: 250000,
        tax_percent: 25,
        city_base_cost: 600000,
        landmark_cost: 1600000,
        toll_percent: 90,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '👑 รองรับ 1v1 • เดี่ยว3 • เดี่ยว4 • ทีม',
        desc: 'ค่าผ่านทางเข้าเล่น: 10,000 🪙 • ทองเริ่มต้นในกระดาน: 10,000,000 🪙 | ชนะรับ: 1,200 💎 + 800,000 🪙'
    },
    'PRACTICE': {
        tier: 'PRACTICE',
        room_tier: 'PRACTICE',
        title: 'โหมดทดลองเล่น',
        fee: 0,
        entry_fee_gold: 0,
        start_match_gold: 2000000,
        winDia: 0,
        winGold: 0,
        tax_amount: 50000,
        tax_percent: 20,
        city_base_cost: 120000,
        landmark_cost: 320000,
        toll_percent: 85,
        buyout_percent: 160,
        defaultMode: '2P',
        badge: '🎯 ฝึกซ้อมฟรี',
        desc: 'เล่นฟรีไม่เสียค่าเข้า • ทองเริ่มต้นในกระดาน: 2,000,000 🪙'
    }
};

window.getActiveRoomEconomyConfig = function(tier = null) {
    const key = String(tier || window.currentActiveRoomTier || (window.isPracticeMatch ? 'PRACTICE' : currentLobbyTier) || '2M').toUpperCase();
    return ROOM_TIER_CONFIG[key] || ROOM_TIER_CONFIG['2M'];
};

window.loadRoomConfigs = async function() {
    try {
        if (!window.apiClient || typeof window.apiClient.getRoomConfigs !== 'function') return;
        const res = await window.apiClient.getRoomConfigs();
        if (!res || res.status !== 'success' || !res.rooms) return;

        Object.entries(res.rooms).forEach(([tierKey, r]) => {
            const t = String(tierKey).toUpperCase();
            if (!ROOM_TIER_CONFIG[t]) ROOM_TIER_CONFIG[t] = { tier: t, room_tier: t, defaultMode: '2P' };
            const cfg = ROOM_TIER_CONFIG[t];
            cfg.title = r.room_title || cfg.title || `ห้อง ${t}`;
            cfg.fee = Number(r.entry_fee_gold ?? cfg.fee ?? 2000);
            cfg.entry_fee_gold = cfg.fee;
            cfg.start_match_gold = Number(r.start_match_gold ?? cfg.start_match_gold ?? 2000000);
            cfg.winDia = Number(r.reward_diamond ?? cfg.winDia ?? 0);
            cfg.winGold = Number(r.reward_gold ?? cfg.winGold ?? 0);
            cfg.tax_amount = Number(r.tax_amount ?? cfg.tax_amount ?? 50000);
            cfg.tax_percent = Number(r.tax_percent ?? cfg.tax_percent ?? 20);
            cfg.city_base_cost = Number(r.city_base_cost ?? cfg.city_base_cost ?? 120000);
            cfg.landmark_cost = Number(r.landmark_cost ?? cfg.landmark_cost ?? 320000);
            cfg.toll_percent = Number(r.toll_percent ?? cfg.toll_percent ?? 85);
            cfg.buyout_percent = Number(r.buyout_percent ?? cfg.buyout_percent ?? 160);
            cfg.desc = `ค่าผ่านทางเข้าเล่น: ${cfg.fee.toLocaleString()} 🪙 • ทองเริ่มต้นในกระดาน: ${cfg.start_match_gold.toLocaleString()} 🪙 | ชนะรับ: ${cfg.winDia.toLocaleString()} 💎 + ${cfg.winGold.toLocaleString()} 🪙`;

            // อัปเดตการ์ดห้องในหน้า Lobby แบบสดๆ
            const elTitle = document.getElementById(`room-title-${t}`);
            const elFee = document.getElementById(`room-fee-${t}`);
            const elStart = document.getElementById(`room-startgold-${t}`);
            const elDia = document.getElementById(`room-dia-${t}`);
            const elGold = document.getElementById(`room-gold-${t}`);
            if (elTitle) elTitle.innerText = cfg.title;
            if (elFee) elFee.innerText = cfg.fee.toLocaleString();
            if (elStart) elStart.innerText = cfg.start_match_gold.toLocaleString();
            if (elDia) elDia.innerText = `💎 ${cfg.winDia.toLocaleString()} เพชร`;
            if (elGold) elGold.innerText = `🪙 ${cfg.winGold.toLocaleString()} ทอง`;
        });
    } catch (e) {
        console.warn('loadRoomConfigs warning:', e);
    }
};

let currentLobbyTier = '2M';
let currentLobbyMode = '2P';
let currentLobbyBoard = localStorage.getItem('snake_board_theme') || 'ancient';
let activeInfoBoardId = 'ancient';

window.selectLobbyLayout = function(layoutType) {
    currentSelectedBoardLayout = layoutType;
    try {
        localStorage.setItem('snake_board_layout', layoutType);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layoutType);
    }
    updateLobbyLayoutUIState();
    if (typeof showToast === 'function') {
        const names = { square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'วงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม' };
        showToast(`เลือกผังกระดาน 3D: ${names[layoutType] || layoutType}`);
    }
};

window.updateLobbyLayoutUIState = function() {
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    ['square', 'spiral', 'hexagon'].forEach(l => {
        const btn = document.getElementById(`lobby-layout-btn-${l}`);
        if (btn) {
            if (l === layout) btn.classList.add('active');
            else btn.classList.remove('active');
        }
    });
    const display = document.getElementById('lobby-active-layout-display');
    if (display) {
        const labels = {
            square: '🟩 สี่เหลี่ยมดั้งเดิม (Classic Square)',
            spiral: '🌀 ทรงกลมก้นหอย (Spiral Galaxy)',
            hexagon: '⬡ ทรงหกเหลี่ยมรังผึ้ง (Hexagon Hive)'
        };
        display.textContent = labels[layout] || labels.square;
    }
};

window.selectLobbyRoom = function(tier = '2M') {
    currentLobbyTier = tier;
    window.goToBoardStep();
};

window.goToBoardStep = function() {
    // Switch views in modal: Show Step 2 (Boards)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'block';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '🗺️ ขั้นตอนที่ 2/3: เลือกกระดาน 3D & แผนที่';

    // Update Room Banner
    const isPractice = (currentLobbyTier === 'PRACTICE');
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const pill = document.getElementById('lobby-active-room-pill');
    const desc = document.getElementById('lobby-active-room-desc');
    if (pill) {
        pill.innerText = isPractice ? '🎯 โหมดทดลองเล่นเดี่ยว (1 ต่อ 1)' : cfg.title;
    }
    if (desc) {
        desc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : cfg.desc;
    }

    const btnNextText = document.querySelector('#lobby-view-boards .btn-start-match span');
    if (btnNextText) {
        btnNextText.innerText = isPractice
            ? 'ถัดไป: เลือกลำดับเล่น & สิทธิ์เริ่มก่อน ➔'
            : 'ถัดไป: เลือกคู่แข่ง & โหมดแข่งขัน ➔';
    }

    // Update Layout selector pills
    window.updateLobbyLayoutUIState();

    // Render Board Grid
    window.renderLobbyBoardsGrid();
};

window.backToRoomSelect = function() {
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'block';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'none';

    if (title) title.innerText = '⚔️ ห้องแข่งขัน & เลือกกระดาน 3D';
};

window.goToLobbyModeSelect = function() {
    // Switch views: Show Step 3 (Opponents / Players count & Match mode)
    const viewRooms = document.getElementById('lobby-view-rooms');
    const viewBoards = document.getElementById('lobby-view-boards');
    const viewModes = document.getElementById('lobby-view-modes');
    const title = document.getElementById('lobby-header-title');

    if (viewRooms) viewRooms.style.display = 'none';
    if (viewBoards) viewBoards.style.display = 'none';
    if (viewModes) viewModes.style.display = 'block';

    const isPractice = (currentLobbyTier === 'PRACTICE');
    const compBlock = document.getElementById('lobby-competitive-modes-block');
    const pracBlock = document.getElementById('lobby-practice-turn-block');

    if (title) {
        title.innerText = isPractice
            ? '🎲 ขั้นตอนที่ 3/3: เลือกสิทธิ์การเล่นก่อน-หลัง (โหมดทดลองเล่น)'
            : '👥 ขั้นตอนที่ 3/3: เลือกคู่แข่ง & รูปแบบแข่งขัน';
    }

    if (compBlock) compBlock.style.display = isPractice ? 'none' : 'block';
    if (pracBlock) pracBlock.style.display = isPractice ? 'block' : 'none';

    // Update Summary Banner in Step 3
    const cfg = ROOM_TIER_CONFIG[currentLobbyTier] || ROOM_TIER_CONFIG['2M'];
    const board = BOARD_CATALOG[currentLobbyBoard] || BOARD_CATALOG.classic;
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    const layoutNames = { square: 'สี่เหลี่ยมดั้งเดิม', spiral: 'ทรงกลมก้นหอย', hexagon: 'ทรงหกเหลี่ยม' };
    const modeRoomPill = document.getElementById('mode-summary-room-pill');
    const modeBoardPill = document.getElementById('mode-summary-board-pill');
    const modeSummaryDesc = document.getElementById('mode-summary-desc');

    if (modeRoomPill) {
        modeRoomPill.innerText = isPractice ? '🎯 โหมดทดลองเล่น (1v1)' : `🏆 ${cfg.title}`;
    }
    if (modeBoardPill) {
        modeBoardPill.innerText = `🗺️ แผนที่: ${board.name} (${layoutNames[layout] || layout})`;
    }
    if (modeSummaryDesc) {
        modeSummaryDesc.innerText = isPractice
            ? 'เล่นฟรีไม่เสียค่าเข้า • ฝึกซ้อมทอยเต๋าและทดสอบสกิลตัวละคร'
            : `ค่าเข้า: ${(cfg.fee || 2000).toLocaleString()} 🪙 • ชนะรับ: ${(cfg.winDia || 200).toLocaleString()} 💎 + ${(cfg.winGold || 100000).toLocaleString()} 🪙`;
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        if (isPractice) {
            btnText.innerText = '🚀 เริ่มทดลองเล่นทันที';
        } else {
            const modeLabel = (currentLobbyMode === '2P') ? '1 ต่อ 1' : ((currentLobbyMode === '3P') ? 'เดี่ยว 3' : ((currentLobbyMode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
            btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
        }
    }

    if (isPractice) {
        if (typeof window.updateTurnOrderUIState === 'function') {
            window.updateTurnOrderUIState();
        }
    } else {
        window.setLobbyGameMode(currentLobbyMode || '2P');
    }
};

window.backToBoardSelect = function() {
    window.goToBoardStep();
};

window.setLobbyGameMode = function(mode = '2P') {
    currentLobbyMode = mode;
    ['2P', '3P', '4P', 'TEAM'].forEach(m => {
        const card = document.getElementById('mode-card-' + m);
        if (card) {
            if (m === mode) {
                card.classList.add('active', 'selected');
            } else {
                card.classList.remove('active', 'selected');
            }
        }
    });

    const hint = document.getElementById('lobby-mode-hint');
    if (hint) {
        if (mode === '2P') hint.innerText = '👤 ดวลเดี่ยวตัวต่อตัว 2 คน (1 ต่อ 1)';
        else if (mode === '3P') hint.innerText = '🥉 ประลอง 3 ผู้เล่น ตะลุมบอน 3 ทิศทาง (เดี่ยว 3)';
        else if (mode === '4P') hint.innerText = '👑 ตะลุมบอน 4 ผู้เล่น อิสระทุกคน (เดี่ยว 4 คน)';
        else if (mode === 'TEAM') hint.innerText = '🛡️ รวมพลังต่อสู้เป็นคู่ แท็กทีม 2v2 (ทีมฟ้า vs ทีมแดง)';
    }

    const btnText = document.getElementById('btn-start-match-text');
    if (btnText) {
        const modeLabel = (mode === '2P') ? '1 ต่อ 1' : ((mode === '3P') ? 'เดี่ยว 3' : ((mode === '4P') ? 'เดี่ยว 4' : 'ทีม 2v2'));
        btnText.innerText = `🚀 เริ่มแข่งขัน (${currentLobbyTier} • ${modeLabel})`;
    }
};

window.scrollLobbyBoards = function(direction) {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    const scrollAmount = 296 * direction;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
};

function attachLobbyBoardsDragScroll(container) {
    if (!container || container._hasDragAttached) return;
    container._hasDragAttached = true;

    let isDown = false;
    let startX = 0;
    let scrollLeft = 0;

    container.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return;
        isDown = true;
        container._isDragging = false;
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
    });

    container.addEventListener('mouseleave', () => {
        isDown = false;
    });

    container.addEventListener('mouseup', () => {
        setTimeout(() => { container._isDragging = false; }, 50);
        isDown = false;
    });

    container.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 1.5;
        if (Math.abs(walk) > 6) {
            container._isDragging = true;
        }
        container.scrollLeft = scrollLeft - walk;
    });

    container.addEventListener('wheel', (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            container.scrollLeft += e.deltaY;
        }
    }, { passive: false });
}

window.selectLobbyBoard = function(boardId) {
    currentLobbyBoard = boardId;
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(boardId);
    }
    window.renderLobbyBoardsGrid();
};

window.renderLobbyBoardsGrid = function() {
    const container = document.getElementById('lobby-boards-container');
    if (!container) return;
    container.innerHTML = '';

    Object.values(BOARD_CATALOG).forEach(board => {
        const isSelected = (currentLobbyBoard === board.id);
        const card = document.createElement('div');
        card.className = 'board-preview-card ' + (isSelected ? 'selected' : '');
        card.style.setProperty('--accent-board', board.themeColor);
        card.style.setProperty('--glow-board', board.themeColor + '66');
        
        card.innerHTML = `
            <div class="board-visual-preview">
                <span class="board-badge-tag" style="background:${board.themeColor}; color:#020617;">${board.badge}</span>
                ${board.svg}
            </div>
            <div>
                <div class="board-card-name">${board.name}</div>
                <div class="board-card-desc">${board.auraDesc}</div>
            </div>
            <div class="board-card-actions">
                <button class="btn-board-info-trigger" onclick="openBoardInfoModal('${board.id}', event)">
                    <span>ℹ️</span> คำอธิบาย & ช่องพิเศษ
                </button>
                <div class="board-check-indicator">
                    ${isSelected ? '✓ เลือกอยู่' : 'คลิกเลือก'}
                </div>
            </div>
        `;

        card.onclick = (e) => {
            if (e.target.closest('.btn-board-info-trigger')) return;
            if (container._isDragging) return;
            window.selectLobbyBoard(board.id);
        };

        container.appendChild(card);
    });

    attachLobbyBoardsDragScroll(container);

    const activeCard = container.querySelector('.board-preview-card.selected');
    if (activeCard) {
        setTimeout(() => {
            activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }, 60);
    }
};

window.confirmLobbyMatch = function() {
    const layout = currentSelectedBoardLayout || localStorage.getItem('snake_board_layout') || 'square';
    try {
        localStorage.setItem('snake_board_layout', layout);
    } catch(e) {}
    if (window.game && typeof window.game.setBoardLayout === 'function') {
        window.game.setBoardLayout(layout);
    }
    if (window.game && typeof window.game.setBoardTheme === 'function') {
        window.game.setBoardTheme(currentLobbyBoard);
    }

    if (currentLobbyTier === 'PRACTICE') {
        closeModal('modal-lobby');
        if (typeof window.startExplicitPracticeMatch === 'function') {
            window.startExplicitPracticeMatch();
        }
    } else {
        window.startQuickMatch(currentLobbyTier, currentLobbyMode, currentLobbyBoard);
    }
};

window.openBoardInfoModal = function(boardId = 'classic', event = null) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
    openModal('modal-board-info');
};

function renderBoardInfoModal() {
    const board = BOARD_CATALOG[activeInfoBoardId] || BOARD_CATALOG.classic;
    const nav = document.getElementById('board-info-tabs-nav');
    const body = document.getElementById('board-info-modal-body');

    // Render nav tabs
    if (nav) {
        nav.innerHTML = Object.values(BOARD_CATALOG).map(b => `
            <button class="board-info-tab-btn ${b.id === activeInfoBoardId ? 'active' : ''}" onclick="switchInfoBoardTab('${b.id}')">
                <span>${b.id === 'classic' ? '🌌' : (b.id === 'ancient' ? '🛕' : (b.id === 'lava' ? '🌋' : '❄️'))}</span>
                ${b.shortName}
            </button>
        `).join('');
    }

    if (body) {
        body.innerHTML = `
            <!-- Hero Banner -->
            <div class="board-info-hero" style="background:${board.themeColor}15; border-color:${board.themeColor}55;">
                <div class="board-info-hero-header">
                    <span class="board-info-hero-icon">${board.id === 'classic' ? '🌌' : (board.id === 'ancient' ? '🛕' : (board.id === 'lava' ? '🌋' : '❄️'))}</span>
                    <div>
                        <div style="font-size:11px; font-weight:800; color:${board.themeColor}; text-transform:uppercase; letter-spacing:1px;">แผนที่ / กระดาน 3D</div>
                        <div class="board-info-hero-title">${board.name}</div>
                    </div>
                </div>
                <div class="board-info-hero-story">
                    ${board.story}
                </div>
                <div style="margin-top:10px; font-size:12px; color:${board.themeColor}; font-weight:700;">
                    ${board.specialBonus}
                </div>
            </div>

            <!-- How to play & Win conditions -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🎯</span> กติกาและวิธีเล่น (How to Play & Winning Rules)
                </div>
                <div class="rules-grid">
                    <div class="rule-item">
                        <div class="rule-item-title">🎲 การทอยลูกเต๋า 2 ลูก</div>
                        <div class="rule-item-desc">ทอยลูกเต๋าคู่ ผลรวมแต้ม (2-12) คือจำนวนช่องที่ตัวหมากเดินไปข้างหน้า</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">⚡ ดับเบิ้ลโบนัส (Double)</div>
                        <div class="rule-item-desc">ทอยได้เลขคู่หน้าเหมือนกัน ได้สิทธิ์ทอยต่อทันที! (หากดับเบิ้ล 3 ครั้งติด โดนส่งไปคุกทันที)</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">🏆 เงื่อนไขคว้าชัยชนะ</div>
                        <div class="rule-item-desc">ผู้เล่นที่เดินถึงหรือทะลุ <strong>ช่อง 100</strong> คนแรก คว้าแชมป์ทันที และรับทอง+เพชรของห้อง</div>
                    </div>
                    <div class="rule-item">
                        <div class="rule-item-title">👥 รูปแบบผู้เล่น</div>
                        <div class="rule-item-desc">เลือกได้ทั้ง <strong>1 ต่อ 1 (2 คน)</strong>, <strong>เดี่ยว 3 (3 คน)</strong>, <strong>เดี่ยว 4 (4 คน)</strong> หรือ <strong>ทีม 2v2</strong> (ใครในทีมถึง 100 ชนะยกทีม)</div>
                    </div>
                </div>
            </div>

            <!-- Special Tiles -->
            <div class="info-section-card">
                <div class="info-section-title">
                    <span>🌟</span> รายการช่องพิเศษทั้งหมดบนกระดานนี้ (Special Tiles)
                </div>
                <div class="special-tiles-grid">
                    <!-- Start -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🚩 จุดเริ่มต้น (Start)</span>
                            <span class="tile-badge-number">ช่อง 1</span>
                        </div>
                        <div class="tile-card-desc">จุดออกสตาร์ท ทุกผู้เล่นเริ่มเดินทางพร้อมกันที่วงกลมสตาร์ทนี้</div>
                    </div>

                    <!-- Goal -->
                    <div class="special-tile-card" style="border-color:rgba(255, 215, 0, 0.4); background:rgba(255, 215, 0, 0.08);">
                        <div class="tile-card-header">
                            <span class="tile-card-title" style="color:#ffd700;">🏆 เส้นชัยสูงสุด (Goal)</span>
                            <span class="tile-badge-number" style="background:#ffd70033; color:#ffd700; border-color:#ffd700;">ช่อง 100</span>
                        </div>
                        <div class="tile-card-desc">ช่องแห่งชัยชนะ เข้าถึงช่องนี้ชนะการแข่งขันทันที รับรางวัลเต็มแม็กซ์</div>
                    </div>

                    <!-- Chance -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎁 ช่องโอกาส (Chance)</span>
                            <span class="tile-badge-number">11, 26, 45, 76</span>
                        </div>
                        <div class="tile-card-desc">สุ่มเปิดการ์ดดวงชะตา: โบนัสทอง 10k-50k, สปีดบูสต์ก้าวหน้า, วาร์ปขึ้นบันได, สลับที่คู่แข่ง</div>
                    </div>

                    <!-- Gamble -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">🎲 ช่องเสี่ยงโชค (Lucky Gamble)</span>
                            <span class="tile-badge-number">15, 36, 68, 88</span>
                        </div>
                        <div class="tile-card-desc">มินิเกมเสี่ยงดวงลูกเต๋า ลุ้นรับโบนัสทวีคูณทองและเพชรตามดวง</div>
                    </div>

                    <!-- Tax -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">💸 ช่องภาษีเมือง (City Tax)</span>
                            <span class="tile-badge-number">20, 52, 82</span>
                        </div>
                        <div class="tile-card-desc">จ่ายค่าบำรุงเมือง 5,000 ทอง เข้ากองกลางเพื่อพัฒนาอาณาจักร</div>
                    </div>

                    <!-- Jail -->
                    <div class="special-tile-card">
                        <div class="tile-card-header">
                            <span class="tile-card-title">⛓️ เกาะร้าง / ติดคุก (Jail)</span>
                            <span class="tile-badge-number">ช่อง 10</span>
                        </div>
                        <div class="tile-card-desc">ถูกกักขัง 2 เทิร์น เว้นแต่จะทอยได้แต้มดับเบิ้ล หรือจ่ายเพชรประกันตัว</div>
                    </div>
                </div>

                <!-- Ladders & Snakes breakdown -->
                <div class="ladders-snakes-table">
                    <div class="ladder-list-box">
                        <div class="list-box-title" style="color:#38bdf8;">
                            <span>🪜</span> ช่องบันไดนำโชค (8 แห่ง) - พุ่งทะยานขึ้น
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-ladder">ช่อง 4 ➔ 14</span>
                            <span class="tile-chip chip-ladder">ช่อง 9 ➔ 31</span>
                            <span class="tile-chip chip-ladder">ช่อง 22 ➔ 38</span>
                            <span class="tile-chip chip-ladder" style="border-color:#ffd700; color:#ffd700;">ช่อง 28 ➔ 84 🚀</span>
                            <span class="tile-chip chip-ladder">ช่อง 40 ➔ 59</span>
                            <span class="tile-chip chip-ladder">ช่อง 51 ➔ 67</span>
                            <span class="tile-chip chip-ladder">ช่อง 63 ➔ 81</span>
                            <span class="tile-chip chip-ladder">ช่อง 71 ➔ 91</span>
                        </div>
                    </div>

                    <div class="snake-list-box">
                        <div class="list-box-title" style="color:#fb7185;">
                            <span>🐍</span> ช่องงูพิษอันตราย (8 แห่ง) - สไลด์ตกฮวบ
                        </div>
                        <div class="tile-chips">
                            <span class="tile-chip chip-snake">ช่อง 17 ➔ 7</span>
                            <span class="tile-chip chip-snake">ช่อง 54 ➔ 34</span>
                            <span class="tile-chip chip-snake">ช่อง 62 ➔ 19</span>
                            <span class="tile-chip chip-snake">ช่อง 64 ➔ 60</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 87 ➔ 24 💀</span>
                            <span class="tile-chip chip-snake">ช่อง 93 ➔ 73</span>
                            <span class="tile-chip chip-snake">ช่อง 95 ➔ 75</span>
                            <span class="tile-chip chip-snake" style="border-color:#ff0055; color:#ff0055;">ช่อง 99 ➔ 78 ⚠️</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Buttons -->
            <div class="board-info-actions">
                <button class="btn-back-step" onclick="closeModal('modal-board-info')">ปิดหน้าต่าง</button>
                <button class="btn-start-match" onclick="applyAndChooseBoard('${board.id}')" style="background:${board.themeColor}; color:#020617;">
                    ✓ เลือกกระดานนี้เลย
                </button>
            </div>
        `;
    }
}

window.switchInfoBoardTab = function(boardId) {
    activeInfoBoardId = boardId;
    renderBoardInfoModal();
};

window.applyAndChooseBoard = function(boardId) {
    if (typeof window.selectBoardThemeAction === 'function') {
        window.selectBoardThemeAction(boardId);
    }
    if (typeof window.closeModal === 'function') {
        window.closeModal('modal-board-info');
    }
};