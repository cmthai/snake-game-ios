<?php
declare(strict_types=1);

/**
 * admin_dashboard.php
 * Snake 3D Game - Backend Admin Dashboard & Mobile Settings (iOS Capacitor & Web)
 * Features:
 *  1. Orders & Billing Management (1,000 เพชร 10 บ. / โปร 2 แถม 1 ได้ 3,000 เพชร 20 บ.)
 *  2. Responsive Landscape UI (Wide Screen Optimized)
 *  3. System Settings: WebView Domain, Live OTA Deploy Update, 4 Payment Gateway Toggles
 * PHP 8.4.25 / Nginx 1.31.6 / MariaDB 11.8.6
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/api/ota_deploy_service.php';

$db = getDbConnection();

// Ensure all database tables exist and are properly seeded
ensureOrdersAndSettingsTables($db);
ensureOtaDeploymentsTable($db);

// Helper function to get a game setting
function getGameSetting(mysqli $db, string $key, string $default = ''): string {
    $stmt = $db->prepare("SELECT setting_value FROM `game_settings` WHERE setting_key = ? LIMIT 1");
    if (!$stmt) return $default;
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $res ? (string)$res['setting_value'] : $default;
}

// Helper function to update or insert a game setting
function setGameSetting(mysqli $db, string $key, string $value, string $category = 'general', string $desc = ''): bool {
    $stmt = $db->prepare("INSERT INTO `game_settings` (`setting_key`, `setting_value`, `category`, `description`) 
        VALUES (?, ?, ?, ?) 
        ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`), `updated_at` = NOW()");
    if (!$stmt) return false;
    $stmt->bind_param("ssss", $key, $value, $category, $desc);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

// Handle AJAX API requests directly
$isAjax = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) 
          || (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json'))
          || isset($_GET['api']);

if ($isAjax) {
    header('Content-Type: application/json; charset=utf-8');
    $rawInput = file_get_contents('php://input');
    $input = !empty($rawInput) ? (json_decode($rawInput, true) ?: []) : $_POST;
    $action = $_GET['action'] ?? ($input['action'] ?? ($_POST['action'] ?? ''));

    // -------------------------------------------------------------
    // API 1: ดึงรายการคำสั่งซื้อและสรุปยอดสถิติ (Orders & Stats)
    // -------------------------------------------------------------
    if ($action === 'get_orders') {
        $statusFilter = trim($input['status'] ?? ($_GET['status'] ?? ''));
        $paymentFilter = trim($input['payment_method'] ?? ($_GET['payment_method'] ?? ''));
        $search = trim($input['search'] ?? ($_GET['search'] ?? ''));

        $where = ["1=1"];
        $params = [];
        $types = "";

        if ($statusFilter !== '' && $statusFilter !== 'ALL') {
            $where[] = "`status` = ?";
            $params[] = $statusFilter;
            $types .= "s";
        }
        if ($paymentFilter !== '' && $paymentFilter !== 'ALL') {
            $where[] = "`payment_method` = ?";
            $params[] = $paymentFilter;
            $types .= "s";
        }
        if ($search !== '') {
            $where[] = "(`order_no` LIKE ? OR `username` LIKE ? OR `package_name` LIKE ? OR `transaction_ref` LIKE ?)";
            $sWild = "%{$search}%";
            $params[] = $sWild;
            $params[] = $sWild;
            $params[] = $sWild;
            $params[] = $sWild;
            $types .= "ssss";
        }

        $sql = "SELECT * FROM `orders` WHERE " . implode(" AND ", $where) . " ORDER BY `created_at` DESC LIMIT 150";
        $stmt = $db->prepare($sql);
        if ($types !== "") {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Calculate Overview Statistics
        $statsRes = $db->query("
            SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN `status` = 'PAID' THEN `amount_thb` ELSE 0 END) as total_revenue,
                SUM(CASE WHEN `status` = 'PAID' THEN (`diamond_amount` + `bonus_diamonds`) ELSE 0 END) as total_diamonds,
                SUM(CASE WHEN `status` = 'PAID' AND DATE(`created_at`) = CURDATE() THEN `amount_thb` ELSE 0 END) as today_revenue,
                SUM(CASE WHEN `status` = 'PAID' THEN 1 ELSE 0 END) as paid_count,
                SUM(CASE WHEN `status` = 'PENDING' THEN 1 ELSE 0 END) as pending_count
            FROM `orders`
        ");
        $stats = $statsRes ? $statsRes->fetch_assoc() : [];

        echo json_encode([
            'status' => 'success',
            'orders' => $orders,
            'stats' => [
                'total_revenue' => (float)($stats['total_revenue'] ?? 0),
                'today_revenue' => (float)($stats['today_revenue'] ?? 0),
                'total_orders' => (int)($stats['total_orders'] ?? 0),
                'paid_count' => (int)($stats['paid_count'] ?? 0),
                'pending_count' => (int)($stats['pending_count'] ?? 0),
                'total_diamonds' => (int)($stats['total_diamonds'] ?? 0),
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API 2: ดึงการตั้งค่าระบบ (Get Settings)
    // -------------------------------------------------------------
    if ($action === 'get_settings') {
        $settingsRes = $db->query("SELECT setting_key, setting_value, category, description FROM `game_settings`");
        $settingsMap = [];
        if ($settingsRes) {
            while ($row = $settingsRes->fetch_assoc()) {
                $settingsMap[$row['setting_key']] = $row['setting_value'];
            }
        }

        // อ่านค่าจาก config/ota_version.json เพิ่มเติม
        $otaFile = __DIR__ . '/config/ota_version.json';
        $otaData = file_exists($otaFile) ? (json_decode(file_get_contents($otaFile), true) ?: []) : [];

        echo json_encode([
            'status' => 'success',
            'settings' => $settingsMap,
            'ota' => $otaData
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API 3: บันทึกการตั้งค่าระบบ (Save Settings)
    // -------------------------------------------------------------
    if ($action === 'save_settings') {
        if (!empty($input['webview_domain'])) {
            $domain = trim($input['webview_domain']);
            if (!str_ends_with($domain, '/')) $domain .= '/';
            setGameSetting($db, 'webview_domain', $domain, 'network', 'โดเมนหลักของเกมบน WebView');
            setGameSetting($db, 'MOBILE_APP_GAME_URL', $domain, 'network', 'โดเมนหลักของเกมบน WebView');

            // อัปเดตลง config/ota_version.json ด้วย
            $otaFile = __DIR__ . '/config/ota_version.json';
            $otaData = file_exists($otaFile) ? (json_decode(file_get_contents($otaFile), true) ?: []) : [];
            $otaData['game_url'] = $domain;
            @file_put_contents($otaFile, json_encode($otaData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        // Toggles ช่องทางการชำระเงิน
        $gateways = ['promptpay', 'creditcard', 'truemoney', 'paypal', 'shopeepay'];
        foreach ($gateways as $gw) {
            $key = "payment_{$gw}_enabled";
            if (isset($input[$key])) {
                $val = ($input[$key] === true || $input[$key] === 1 || $input[$key] === '1') ? '1' : '0';
                setGameSetting($db, $key, $val, 'payment', "เปิด/ปิดการชำระเงิน {$gw}");
            }
        }

        // บันทึกข้อมูลบัญชีพร้อมเพย์สำหรับรับเงิน
        if (isset($input['promptpay_id'])) {
            $ppId = preg_replace('/[^0-9]/', '', trim((string)$input['promptpay_id']));
            setGameSetting($db, 'payment_promptpay_id', $ppId, 'payment', 'หมายเลขพร้อมเพย์สำหรับรับเงิน');
        }
        if (isset($input['promptpay_name'])) {
            setGameSetting($db, 'payment_promptpay_name', trim((string)$input['promptpay_name']), 'payment', 'ชื่อบัญชีพร้อมเพย์');
        }
        if (isset($input['promptpay_bank'])) {
            setGameSetting($db, 'payment_promptpay_bank', trim((string)$input['promptpay_bank']), 'payment', 'ธนาคารบัญชีพร้อมเพย์');
        }

        // บันทึกข้อมูลบัญชี ShopeePay สำหรับรับเงิน
        if (isset($input['shopeepay_id'])) {
            setGameSetting($db, 'payment_shopeepay_id', trim((string)$input['shopeepay_id']), 'payment', 'หมายเลขหรือไอดี ShopeePay');
        }
        if (isset($input['shopeepay_name'])) {
            setGameSetting($db, 'payment_shopeepay_name', trim((string)$input['shopeepay_name']), 'payment', 'ชื่อร้านค้าบัญชี ShopeePay');
        }
        if (isset($input['shopeepay_qr_url'])) {
            setGameSetting($db, 'payment_shopeepay_qr_url', trim((string)$input['shopeepay_qr_url']), 'payment', 'ลิงก์รูป QR Code ShopeePay');
        }

        // บันทึกข้อมูลบัญชี PayPal สำหรับรับเงิน
        if (isset($input['paypal_email'])) {
            setGameSetting($db, 'payment_paypal_email', trim((string)$input['paypal_email']), 'payment', 'อีเมลบัญชี PayPal สำหรับรับเงิน');
        }
        if (isset($input['paypal_client_id'])) {
            setGameSetting($db, 'payment_paypal_client_id', trim((string)$input['paypal_client_id']), 'payment', 'PayPal REST API Client ID');
        }
        if (isset($input['paypal_currency'])) {
            setGameSetting($db, 'payment_paypal_currency', trim((string)$input['paypal_currency']), 'payment', 'สกุลเงิน PayPal');
        }
        if (isset($input['paypal_sandbox'])) {
            $sbVal = (!empty($input['paypal_sandbox']) && $input['paypal_sandbox'] !== '0' && $input['paypal_sandbox'] !== false) ? '1' : '0';
            setGameSetting($db, 'payment_paypal_sandbox', $sbVal, 'payment', 'โหมดทดสอบ PayPal Sandbox');
        }

        if (isset($input['maintenance_mode'])) {
            $mVal = ($input['maintenance_mode'] === true || $input['maintenance_mode'] === 1 || $input['maintenance_mode'] === '1') ? '1' : '0';
            setGameSetting($db, 'maintenance_mode', $mVal, 'general', 'โหมดปิดปรับปรุง');
            setGameSetting($db, 'MOBILE_APP_MAINTENANCE', $mVal, 'general', 'โหมดปิดปรับปรุง');
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'บันทึกการตั้งค่าระบบเรียบร้อยแล้ว'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API 4: ปุ่ม Deploy Update (อัปเดตเวอร์ชันสดลง app_config.php)
    // -------------------------------------------------------------
    if ($action === 'deploy_update') {
        $releaseNote = trim($input['release_note'] ?? 'อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล');
        $forceClear = !empty($input['force_clear_cache']);
        $newCacheBuster = time();

        // ดึงเวอร์ชันเก่ามา bump เล็กน้อย
        $curVersion = getGameSetting($db, 'app_version', '1.0.0');
        $vParts = explode('.', $curVersion);
        if (count($vParts) === 3) {
            $vParts[2] = (string)(((int)$vParts[2]) + 1);
            $newVersion = implode('.', $vParts);
        } else {
            $newVersion = '1.0.' . ($newCacheBuster % 1000);
        }

        if (!empty($input['target_version'])) {
            $newVersion = trim($input['target_version']);
        }

        $domain = getGameSetting($db, 'webview_domain', 'https://pmix01.thddns.net:7175/home/snake/');

        // บันทึกลง game_settings
        setGameSetting($db, 'app_version', $newVersion, 'version', 'เวอร์ชันปัจจุบัน');
        setGameSetting($db, 'MOBILE_APP_VERSION', $newVersion, 'version', 'เวอร์ชันปัจจุบัน');
        setGameSetting($db, 'MOBILE_APP_CACHE_BUSTER', (string)$newCacheBuster, 'version', 'Cache Buster Timestamp');
        setGameSetting($db, 'OTA_LAST_DEPLOY_TIME', date('Y-m-d H:i:s'), 'ota', 'เวลาที่ Deploy ล่าสุด');
        setGameSetting($db, 'OTA_LAST_RELEASE_NOTE', $releaseNote, 'ota', 'รายละเอียดบันทึกการอัปเดต');

        // บันทึกลง config/ota_version.json
        $otaFile = __DIR__ . '/config/ota_version.json';
        $otaData = [
            'version' => $newVersion,
            'cache_buster' => $newCacheBuster,
            'game_url' => $domain,
            'force_clear_cache' => $forceClear,
            'release_note' => $releaseNote,
            'update_size' => '2.8 MB',
            'last_deployed_at' => date('Y-m-d H:i:s'),
            'deployed_by' => 'Admin'
        ];
        @file_put_contents($otaFile, json_encode($otaData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

        // บันทึกประวัติลง ota_deployments table
        $depStmt = $db->prepare("INSERT INTO `ota_deployments` (`version_tag`, `build_number`, `package_size`, `release_notes`, `deployed_by`, `status`) VALUES (?, ?, '2.8 MB', ?, 'Admin', 'SUCCESS')");
        if ($depStmt) {
            $bNum = $newCacheBuster;
            $depStmt->bind_param("sis", $newVersion, $bNum, $releaseNote);
            $depStmt->execute();
            $depStmt->close();
        }

        echo json_encode([
            'status' => 'success',
            'message' => "🚀 Deploy Update สำเร็จ! แอปพลิเคชันอัปเกรดสู่เวอร์ชัน {$newVersion} เรียบร้อยแล้ว",
            'version' => $newVersion,
            'cache_buster' => $newCacheBuster,
            'deployed_at' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API 5: สร้างคำสั่งซื้อทดสอบ (Create Test Order)
    // -------------------------------------------------------------
    if ($action === 'create_test_order') {
        $pkg = $input['package'] ?? 'dia_1000';
        $user = !empty($input['username']) ? trim($input['username']) : 'ผู้เล่นทดสอบ ' . rand(10, 99);
        $method = $input['payment_method'] ?? 'promptpay';

        if ($pkg === 'dia_promo_2plus1') {
            $pkgName = 'โปรโมชัน 2 แถม 1 (3,000 เพชร)';
            $amount = 20.00;
            $dia = 2000;
            $bonus = 1000;
        } else {
            $pkgName = '1,000 เพชร';
            $amount = 10.00;
            $dia = 1000;
            $bonus = 0;
        }

        $orderNo = 'ORD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $txnRef = 'TXN-' . strtoupper($method) . '-' . rand(100000, 999999);

        $stmt = $db->prepare("INSERT INTO `orders` (`order_no`, `user_id`, `username`, `package_id`, `package_name`, `amount_thb`, `diamond_amount`, `bonus_diamonds`, `payment_method`, `status`, `transaction_ref`) VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, 'PAID', ?)");
        $stmt->bind_param("ssssdiisss", $orderNo, $user, $pkg, $pkgName, $amount, $dia, $bonus, $method, $txnRef);
        $stmt->execute();
        $stmt->close();

        echo json_encode([
            'status' => 'success',
            'message' => "สร้างบิลทดสอบ {$orderNo} เรียบร้อยแล้ว (+{$dia} เพชร / {$amount} บาท)",
            'order_no' => $orderNo
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API 5.5: อนุมัติตัดยอดบิลและเติมเพชร (Approve & Fulfill Order)
    // -------------------------------------------------------------
    if ($action === 'approve_order') {
        $orderNo = trim((string)($input['order_no'] ?? ($_GET['order_no'] ?? '')));
        $cleanOrderNo = preg_replace('/^REF-/', '', $orderNo);

        if (empty($orderNo)) {
            echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ order_no'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $chk = $db->query("SELECT * FROM payment_orders WHERE order_no = '{$orderNo}' OR order_no = '{$cleanOrderNo}' LIMIT 1")->fetch_assoc();
        if ($chk) {
            $pId = (int)$chk['id'];
            $uId = (int)$chk['user_id'];
            $rDia = (int)$chk['reward_diamond'];
            $rGold = (int)$chk['reward_gold'];
            $amt = (float)$chk['amount_thb'];
            $iName = (string)$chk['item_name'];

            $db->query("UPDATE payment_orders SET status = 'paid', is_fulfilled = 1, paid_at = NOW() WHERE id = {$pId}");
            $db->query("UPDATE orders SET status = 'PAID' WHERE order_no = '{$orderNo}' OR order_no = '{$cleanOrderNo}'");
            $db->query("UPDATE users SET diamond = diamond + {$rDia}, gold = gold + {$rGold} WHERE id = {$uId}");

            $mailTitle = "อนุมัติเติมเพชรสำเร็จ: {$iName}";
            $mailMsg = "แอดมินได้ตรวจสอบยอดโอน " . number_format($amt, 2) . " บาท และอนุมัติส่งมอบ {$rDia} เพชร เรียบร้อยแล้วค่ะ";
            $mStmt = $db->prepare("INSERT INTO mailbox (user_id, title, message, reward_diamond, reward_gold, is_claimed) VALUES (?, ?, ?, 0, 0, 1)");
            if ($mStmt) {
                $mStmt->bind_param("iss", $uId, $mailTitle, $mailMsg);
                $mStmt->execute();
                $mStmt->close();
            }

            echo json_encode([
                'status' => 'success',
                'message' => "อนุมัติบิล {$orderNo} สำเร็จ! ส่งมอบ +{$rDia} เพชร เข้าตัวละคร ID {$uId} เรียบร้อยแล้ว",
                'order_no' => $orderNo
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $db->query("UPDATE `orders` SET `status` = 'PAID' WHERE `order_no` = '{$orderNo}' OR `order_no` = '{$cleanOrderNo}'");
        echo json_encode(['status' => 'success', 'message' => "ปรับสถานะบิล {$orderNo} เป็น PAID เรียบร้อยแล้ว"], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // -------------------------------------------------------------
    // API: เสิร์ฟรูปภาพไอคอนแอป (Get App Icon Image)
    // -------------------------------------------------------------
    if ($action === 'get_app_icon') {
        $dataUrl = getGameSetting($db, 'app_icon_data_url', '');
        if (!empty($dataUrl) && str_contains($dataUrl, 'base64,')) {
            $raw = substr($dataUrl, strpos($dataUrl, 'base64,') + 7);
            $bin = base64_decode($raw);
            if ($bin && strlen($bin) > 50) {
                header('Content-Type: image/png');
                header('Cache-Control: public, max-age=86400');
                echo $bin;
                exit;
            }
        }

        $fallback = __DIR__ . '/ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png';
        if (file_exists($fallback)) {
            header('Content-Type: image/png');
            readfile($fallback);
            exit;
        }

        header('HTTP/1.1 404 Not Found');
        exit;
    }

    // -------------------------------------------------------------
    // API 6: อัปโหลดและจัดการไอคอนแอป (Upload & Manage App Icon)
    // -------------------------------------------------------------
    if ($action === 'upload_app_icon') {
        $imgBinary = null;
        $dataUrl = null;

        if (isset($_FILES['icon_file']) && $_FILES['icon_file']['error'] === UPLOAD_ERR_OK) {
            $tmpPath = $_FILES['icon_file']['tmp_name'];
            $imgBinary = @file_get_contents($tmpPath);
            if ($imgBinary) {
                $dataUrl = 'data:image/png;base64,' . base64_encode($imgBinary);
            }
        } elseif (!empty($input['image_data'])) {
            $raw = (string)$input['image_data'];
            $dataUrl = $raw;
            if (str_contains($raw, ';base64,')) {
                $raw = substr($raw, strpos($raw, ';base64,') + 8);
            }
            $imgBinary = base64_decode($raw);
        }

        if (!$imgBinary || strlen($imgBinary) < 100) {
            echo json_encode(['status' => 'error', 'message' => 'ไม่พบข้อมูลไฟล์รูปภาพ หรือขนาดไฟล์ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // หากมีโมดูล GD ตรวจสอบและย่อ/ขยายเป็น 1024x1024 แบบทึบแสง (Opaque RGB 24-bit ไม่มี Alpha Channel ตามข้อบังคับของ Apple iOS AppIcon)
        $finalPng = null;
        $srcImg = null;
        if (function_exists('imagecreatefromstring')) {
            $srcImg = @imagecreatefromstring($imgBinary);
            if ($srcImg !== false) {
                $w = imagesx($srcImg);
                $h = imagesy($srcImg);
                $dst = imagecreatetruecolor(1024, 1024);
                imagealphablending($dst, true);
                imagesavealpha($dst, false);
                $bgColor = imagecolorallocate($dst, 241, 251, 253);
                imagefilledrectangle($dst, 0, 0, 1024, 1024, $bgColor);
                imagecopyresampled($dst, $srcImg, 0, 0, 0, 0, 1024, 1024, $w, $h);

                ob_start();
                imagepng($dst, null, 9);
                $finalPng = ob_get_clean();
                imagedestroy($dst);
            }
        }

        if (!$finalPng) {
            $finalPng = $imgBinary;
        }

        $finalDataUrl = 'data:image/png;base64,' . base64_encode($finalPng);

        // บันทึกเข้า MySQL Database game_settings
        $tNow = time();
        setGameSetting($db, 'app_icon_data_url', $finalDataUrl, 'assets', 'App Icon 1024x1024 Data URL');
        setGameSetting($db, 'app_icon_last_updated', (string)$tNow, 'assets', 'เวลาที่อัปเดตไอคอนแอป');

        // Helper สร้าง PNG ขนาดต่างๆ แบบ Opaque RGB สำหรับ iOS AppIcon.appiconset และ Web
        $makeSizedPng = function(int $targetSize) use ($srcImg, $finalPng): string {
            if (!$srcImg || !function_exists('imagecreatetruecolor')) {
                return $finalPng;
            }
            $w = imagesx($srcImg);
            $h = imagesy($srcImg);
            $canvas = imagecreatetruecolor($targetSize, $targetSize);
            imagealphablending($canvas, true);
            imagesavealpha($canvas, false);
            $bg = imagecolorallocate($canvas, 241, 251, 253);
            imagefilledrectangle($canvas, 0, 0, $targetSize, $targetSize, $bg);
            imagecopyresampled($canvas, $srcImg, 0, 0, 0, 0, $targetSize, $targetSize, $w, $h);
            ob_start();
            imagepng($canvas, null, 9);
            $out = ob_get_clean();
            imagedestroy($canvas);
            return $out ?: $finalPng;
        };

        $iosIconSizes = [
            'AppIcon-20x20@1x.png'    => 20,
            'AppIcon-20x20@2x.png'    => 40,
            'AppIcon-20x20@3x.png'    => 60,
            'AppIcon-29x29@1x.png'    => 29,
            'AppIcon-29x29@2x.png'    => 58,
            'AppIcon-29x29@3x.png'    => 87,
            'AppIcon-40x40@1x.png'    => 40,
            'AppIcon-40x40@2x.png'    => 80,
            'AppIcon-40x40@3x.png'    => 120,
            'AppIcon-60x60@2x.png'    => 120,
            'AppIcon-60x60@3x.png'    => 180,
            'AppIcon-76x76@1x.png'    => 76,
            'AppIcon-76x76@2x.png'    => 152,
            'AppIcon-83.5x83.5@2x.png'=> 167,
            'AppIcon-512@2x.png'      => 1024,
        ];

        $sizeCache = [1024 => $finalPng];
        $getPngForSize = function(int $sz) use (&$sizeCache, $makeSizedPng): string {
            if (!isset($sizeCache[$sz])) {
                $sizeCache[$sz] = $makeSizedPng($sz);
            }
            return $sizeCache[$sz];
        };

        $savedCount = 0;
        $iconSetDir = __DIR__ . '/ios/App/App/Assets.xcassets/AppIcon.appiconset';
        if (!is_dir($iconSetDir)) {
            @mkdir($iconSetDir, 0775, true);
        }

        foreach ($iosIconSizes as $fileName => $sz) {
            $dstPath = $iconSetDir . '/' . $fileName;
            if (@file_put_contents($dstPath, $getPngForSize($sz)) !== false) {
                $savedCount++;
            }
        }

        $webDestinations = [
            __DIR__ . '/assets/images/app_icon.png'                     => 1024,
            __DIR__ . '/apple-touch-icon.png'                           => 180,
            __DIR__ . '/apple-touch-icon-precomposed.png'               => 180,
            __DIR__ . '/apple-touch-icon-180x180.png'                   => 180,
            __DIR__ . '/apple-touch-icon-152x152.png'                   => 152,
            __DIR__ . '/apple-touch-icon-120x120.png'                   => 120,
            __DIR__ . '/favicon.png'                                    => 192,
            __DIR__ . '/www/apple-touch-icon.png'                       => 180,
            __DIR__ . '/www/apple-touch-icon-precomposed.png'           => 180,
            __DIR__ . '/www/favicon.png'                                => 192,
            __DIR__ . '/www/assets/images/app_icon.png'                 => 1024,
            __DIR__ . '/ios/App/App/public/apple-touch-icon.png'        => 180,
            __DIR__ . '/ios/App/App/public/apple-touch-icon-precomposed.png' => 180,
            __DIR__ . '/ios/App/App/public/favicon.png'                 => 192,
            __DIR__ . '/ios/App/App/public/assets/images/app_icon.png'  => 1024,
        ];

        foreach ($webDestinations as $dstPath => $sz) {
            $dDir = dirname($dstPath);
            if (!is_dir($dDir)) {
                @mkdir($dDir, 0775, true);
            }
            if (@file_put_contents($dstPath, $getPngForSize($sz)) !== false) {
                $savedCount++;
            }
        }

        if ($srcImg) {
            imagedestroy($srcImg);
        }

        // อัปเดตไฟล์ไอคอนเข้าใน ios.zip โดยอัตโนมัติทันที
        $zipUpdated = false;
        $iosZipPath = __DIR__ . '/ios.zip';
        if (class_exists('ZipArchive') && file_exists($iosZipPath)) {
            $zip = new ZipArchive();
            if (@$zip->open($iosZipPath) === true) {
                foreach ($iosIconSizes as $fileName => $sz) {
                    $zip->addFromString('ios/App/App/Assets.xcassets/AppIcon.appiconset/' . $fileName, $getPngForSize($sz));
                }
                $contentsJsonPath = $iconSetDir . '/Contents.json';
                if (file_exists($contentsJsonPath)) {
                    $zip->addFromString('ios/App/App/Assets.xcassets/AppIcon.appiconset/Contents.json', (string)file_get_contents($contentsJsonPath));
                }
                $zip->addFromString('ios/App/App/public/apple-touch-icon.png', $getPngForSize(180));
                $zip->addFromString('ios/App/App/public/apple-touch-icon-precomposed.png', $getPngForSize(180));
                $zip->addFromString('ios/App/App/public/favicon.png', $getPngForSize(192));
                $zip->addFromString('ios/App/App/public/assets/images/app_icon.png', $getPngForSize(1024));
                @$zip->close();
                $zipUpdated = true;
            }
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'บันทึกไอคอนแอปครบทุกขนาด (iOS AppIcon 15 ขนาด + Web Icon + อัปเดต ios.zip) เรียบร้อยแล้ว!',
            'saved_count' => $savedCount,
            'zip_updated' => $zipUpdated,
            'icon_url' => 'admin_dashboard.php?api=1&action=get_app_icon&v=' . $tNow,
            'ios_zip_url' => 'ios.zip?v=' . $tNow,
            'data_url' => $finalDataUrl,
            'updated_at' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Invalid action'], 400);
    exit;
}

// Read current settings for initial HTML rendering
$curDomain = getGameSetting($db, 'webview_domain', 'https://pmix01.thddns.net:7175/home/snake/');
$curVersion = getGameSetting($db, 'app_version', '1.0.0');
$payPromptPay = getGameSetting($db, 'payment_promptpay_enabled', '1') === '1';
$payCredit = getGameSetting($db, 'payment_creditcard_enabled', '1') === '1';
$payTrueMoney = getGameSetting($db, 'payment_truemoney_enabled', '1') === '1';
$payPayPal = getGameSetting($db, 'payment_paypal_enabled', '1') === '1';
$payShopeePay = getGameSetting($db, 'payment_shopeepay_enabled', '1') === '1';
$isMaintenance = getGameSetting($db, 'maintenance_mode', '0') === '1';
$promptpayId = getGameSetting($db, 'payment_promptpay_id', '');
$promptpayName = getGameSetting($db, 'payment_promptpay_name', '');
$promptpayBank = getGameSetting($db, 'payment_promptpay_bank', 'พร้อมเพย์กลาง (PromptPay)');
$shopeepayId = getGameSetting($db, 'payment_shopeepay_id', '');
$shopeepayName = getGameSetting($db, 'payment_shopeepay_name', '');
$shopeepayQrUrl = getGameSetting($db, 'payment_shopeepay_qr_url', '');
$paypalEmail = getGameSetting($db, 'payment_paypal_email', '');
$paypalClientId = getGameSetting($db, 'payment_paypal_client_id', '');
$paypalCurrency = getGameSetting($db, 'payment_paypal_currency', 'THB');
$paypalSandbox = getGameSetting($db, 'payment_paypal_sandbox', '0') === '1';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>🎮 Admin Dashboard & Settings - เกมเศรษฐีบันไดงู 3D (iOS Capacitor)</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #00e5ff;
            --primary-glow: rgba(0, 229, 255, 0.4);
            --accent: #ffd700;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --purple: #a855f7;
            --bg-dark: #070b14;
            --panel-bg: rgba(15, 23, 42, 0.88);
            --panel-border: rgba(56, 189, 248, 0.28);
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Kanit', sans-serif;
        }

        body {
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(circle at 10% 10%, rgba(2, 132, 199, 0.16) 0%, transparent 40%),
                radial-gradient(circle at 90% 90%, rgba(0, 229, 255, 0.12) 0%, transparent 40%),
                linear-gradient(180deg, #070b14 0%, #030712 100%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Top Bar - Full Width Edge to Edge */
        .topbar {
            background: rgba(15, 23, 42, 0.92);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-bottom: 1px solid var(--panel-border);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
        }

        .topbar-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 800;
            color: #fff;
            text-decoration: none;
        }

        .topbar-brand span {
            background: linear-gradient(135deg, #00e5ff, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-link-action {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: 0.2s;
            cursor: pointer;
        }

        .btn-link-action:hover {
            background: rgba(0, 229, 255, 0.2);
            border-color: var(--primary);
            color: var(--primary);
        }

        /* Container - Full Width Landscape (iOS / Android / Desktop) */
        .dashboard-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            padding: 14px 16px 40px;
            box-sizing: border-box;
            flex: 1;
        }

        /* 4 Top Overview Stats Cards (Grid 4 Columns Horizontal) */
        .stats-overview-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 10px;
            margin-bottom: 14px;
        }

        .stat-box {
            background: linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(8, 14, 28, 0.92));
            border: 1.5px solid var(--panel-border);
            border-radius: 14px;
            padding: 12px 14px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .stat-box::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 60px;
            height: 60px;
            background: radial-gradient(circle, var(--stat-glow, rgba(0,229,255,0.15)) 0%, transparent 70%);
            pointer-events: none;
        }

        .stat-label {
            font-size: 11.5px;
            font-weight: 700;
            color: var(--text-sub);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .stat-value {
            font-size: 22px;
            font-weight: 900;
            color: #fff;
            margin: 6px 0 2px;
            letter-spacing: -0.5px;
        }

        .stat-sub {
            font-size: 11px;
            color: #a7f3d0;
            font-weight: 600;
        }

        /* Main Navigation Tabs */
        .dash-tabs-bar {
            display: flex;
            gap: 8px;
            border-bottom: 1.5px solid rgba(56, 189, 248, 0.25);
            padding-bottom: 10px;
            margin-bottom: 14px;
            overflow-x: auto;
            flex-wrap: nowrap;
        }

        .dash-tab-btn {
            background: rgba(15, 23, 42, 0.8);
            border: 1.5px solid var(--panel-border);
            color: var(--text-sub);
            padding: 9px 18px;
            border-radius: 10px;
            font-size: 13.5px;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
            transition: all 0.2s ease;
        }

        .dash-tab-btn:hover {
            border-color: var(--primary);
            color: #fff;
        }

        .dash-tab-btn.active {
            background: linear-gradient(135deg, rgba(0, 229, 255, 0.22), rgba(2, 132, 199, 0.35));
            border-color: var(--primary);
            color: var(--primary);
            box-shadow: 0 0 16px rgba(0, 229, 255, 0.3);
        }

        .tab-pane {
            display: none;
            width: 100%;
        }

        .tab-pane.active {
            display: block;
            width: 100%;
        }

        /* Card Panels */
        .glass-card {
            background: var(--panel-bg);
            border: 1.5px solid var(--panel-border);
            border-radius: 14px;
            padding: 18px 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45);
            margin-bottom: 14px;
            width: 100%;
            box-sizing: border-box;
        }

        .card-header-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding-bottom: 10px;
        }

        .card-title-text {
            font-size: 15px;
            font-weight: 800;
            color: #fff;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Responsive Table Container */
        .table-responsive-box {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(8, 14, 28, 0.85);
            margin-top: 10px;
        }

        table.orders-table {
            width: 100%;
            min-width: 950px;
            border-collapse: collapse;
            font-size: 13px;
            white-space: nowrap;
        }

        table.orders-table th {
            background: rgba(15, 23, 42, 0.98);
            color: #94a3b8;
            font-weight: 700;
            padding: 12px 14px;
            text-align: left;
            border-bottom: 2px solid var(--panel-border);
            letter-spacing: 0.3px;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        table.orders-table td {
            padding: 12px 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            color: #e2e8f0;
            vertical-align: middle;
        }

        table.orders-table tr:hover {
            background: rgba(0, 229, 255, 0.05);
        }

        /* Badges */
        .badge-status {
            font-size: 10.5px;
            font-weight: 800;
            padding: 3px 8px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .badge-paid {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid #10b981;
            color: #34d399;
        }

        .badge-pending {
            background: rgba(245, 158, 11, 0.2);
            border: 1px solid #f59e0b;
            color: #fbbf24;
        }

        .badge-paymethod {
            font-size: 11px;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.08);
            color: #cbd5e1;
            border: 1px solid rgba(255, 255, 255, 0.12);
        }

        /* Form Controls */
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 14px;
            margin-bottom: 14px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-sub);
        }

        .form-control {
            background: #090d16;
            border: 1.5px solid var(--panel-border);
            border-radius: 8px;
            padding: 9px 12px;
            color: #fff;
            font-size: 13px;
            font-weight: 600;
            width: 100%;
            transition: 0.2s;
        }

        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 10px rgba(0, 229, 255, 0.3);
        }

        /* Switches for Payment Gateways */
        .gateways-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 10px;
        }

        .gateway-card {
            background: rgba(8, 14, 28, 0.85);
            border: 1.5px solid rgba(255, 255, 255, 0.12);
            border-radius: 12px;
            padding: 12px 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            transition: all 0.2s;
        }

        .gateway-card.enabled {
            border-color: #10b981;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(8, 14, 28, 0.9));
            box-shadow: 0 0 14px rgba(16, 185, 129, 0.2);
        }

        .gw-meta {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .gw-icon {
            font-size: 24px;
        }

        .gw-title {
            font-size: 13px;
            font-weight: 800;
            color: #fff;
        }

        .gw-status-text {
            font-size: 10.5px;
            color: var(--text-sub);
        }

        /* Toggle Switch UI */
        .switch {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            flex-shrink: 0;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #334155;
            transition: .3s;
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #10b981;
            box-shadow: 0 0 12px rgba(16, 185, 129, 0.6);
        }

        input:checked + .slider:before {
            transform: translateX(20px);
        }

        /* Buttons */
        .btn-deploy {
            background: linear-gradient(135deg, #10b981, #059669);
            color: #fff;
            font-weight: 800;
            font-size: 14px;
            padding: 11px 22px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 18px rgba(16, 185, 129, 0.45);
            transition: all 0.2s;
        }

        .btn-deploy:hover {
            transform: translateY(-2px);
            filter: brightness(1.1);
        }

        .btn-action-primary {
            background: linear-gradient(135deg, #0284c7, #00e5ff);
            color: #000;
            font-weight: 800;
            font-size: 13px;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-action-primary:hover {
            filter: brightness(1.15);
        }

        /* Notification Popup Modal */
        .popup-modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(8px);
            z-index: 99999;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 14px;
        }

        .popup-modal-card {
            background: #0f172a;
            border: 2px solid var(--primary);
            border-radius: 16px;
            width: min(94vw, 440px);
            padding: 22px;
            text-align: center;
            box-shadow: 0 10px 45px rgba(0, 0, 0, 0.8), 0 0 30px rgba(0, 229, 255, 0.35);
        }

        /* Media Queries for Mobile/Compact Landscape (iOS & Android) */
        @media (max-width: 900px) {
            .stats-overview-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .gateways-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .dashboard-container {
                padding: 10px 10px 30px;
            }
        }

        @media (max-width: 600px) {
            .stats-overview-grid {
                grid-template-columns: 1fr;
            }
            .gateways-grid {
                grid-template-columns: 1fr;
            }
            .topbar {
                padding: 8px 12px;
            }
            .card-header-row {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>

    <!-- Top Navigation Bar -->
    <header class="topbar">
        <a href="admin_dashboard.php" class="topbar-brand">
            <span>🎲 บันไดงู 3D</span>
            <span style="font-size: 14px; color: #94a3b8; font-weight: 500;">| Admin Dashboard (iOS Capacitor)</span>
        </a>

        <div class="topbar-actions">
            <span style="font-size: 11px; background: rgba(16, 185, 129, 0.2); border: 1px solid #10b981; color: #34d399; padding: 3px 8px; border-radius: 6px; font-weight: 700;">
                ● LIVE OTA ACTIVE
            </span>
            <a href="index.html" target="_blank" class="btn-link-action">
                🎮 เปิดหน้าเกม 3D
            </a>
            <a href="admin/admin_panel.php" class="btn-link-action" style="border-color:#00e5ff; color:#00e5ff;">
                🛠️ แผงควบคุมใหญ่
            </a>
        </div>
    </header>

    <!-- Main Container -->
    <main class="dashboard-container">

        <!-- 4 Top Overview Stats Cards -->
        <section class="stats-overview-grid">
            <!-- 1. Total Revenue -->
            <div class="stat-box" style="--stat-glow: rgba(16, 185, 129, 0.3); border-color: rgba(16, 185, 129, 0.35);">
                <div class="stat-label">
                    <span>💰 ยอดขายทั้งหมด (Revenue)</span>
                    <span style="color:#10b981;">THB</span>
                </div>
                <div class="stat-value" id="stat-total-revenue" style="color:#34d399;">฿0.00</div>
                <div class="stat-sub" id="stat-today-revenue">วันนี้: ฿0.00</div>
            </div>

            <!-- 2. Paid Orders -->
            <div class="stat-box" style="--stat-glow: rgba(56, 189, 248, 0.3); border-color: rgba(56, 189, 248, 0.35);">
                <div class="stat-label">
                    <span>🧾 บิลชำระเงิน (Orders)</span>
                    <span style="color:#38bdf8;">บิลสำเร็จ</span>
                </div>
                <div class="stat-value" id="stat-paid-orders" style="color:#38bdf8;">0 บิล</div>
                <div class="stat-sub" id="stat-pending-orders" style="color:#fbbf24;">รอดำเนินการ: 0 บิล</div>
            </div>

            <!-- 3. Total Diamonds Sold -->
            <div class="stat-box" style="--stat-glow: rgba(255, 215, 0, 0.3); border-color: rgba(255, 215, 0, 0.35);">
                <div class="stat-label">
                    <span>💎 เพชรที่เติมทั้งหมด</span>
                    <span style="color:#ffd700;">DIAMONDS</span>
                </div>
                <div class="stat-value" id="stat-total-diamonds" style="color:#ffd700;">0 💎</div>
                <div class="stat-sub" style="color:#94a3b8;">1,000 เพชร 10 บ. / โปร 3,000 เพชร 20 บ.</div>
            </div>

            <!-- 4. WebView & OTA Status -->
            <div class="stat-box" style="--stat-glow: rgba(168, 85, 247, 0.3); border-color: rgba(168, 85, 247, 0.35);">
                <div class="stat-label">
                    <span>📱 สถานะ WebView & เวอร์ชัน</span>
                    <span style="color:#c084fc;">iOS READY</span>
                </div>
                <div class="stat-value" id="stat-app-version" style="color:#c084fc; font-size: 19px;">v<?= htmlspecialchars($curVersion) ?></div>
                <div class="stat-sub" style="color:#38bdf8; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" id="stat-webview-domain" title="<?= htmlspecialchars($curDomain) ?>">
                    <?= htmlspecialchars($curDomain) ?>
                </div>
            </div>
        </section>

        <!-- Navigation Tabs -->
        <nav class="dash-tabs-bar">
            <button type="button" class="dash-tab-btn active" onclick="switchDashboardTab('tab-orders')">
                <span>📋 รายการชำระเงินซื้อเพชร (Orders &amp; Invoices)</span>
            </button>
            <button type="button" class="dash-tab-btn" onclick="switchDashboardTab('tab-settings')">
                <span>⚙️ ตั้งค่าระบบ &amp; ช่องทางชำระเงิน (System Settings)</span>
            </button>
            <button type="button" class="dash-tab-btn" onclick="switchDashboardTab('tab-deploy')">
                <span>🚀 Live Deploy Update (OTA Version)</span>
            </button>
            <button type="button" class="dash-tab-btn" onclick="switchDashboardTab('tab-icon')">
                <span>📱 จัดการไอคอนแอป iOS &amp; Web (App Icon)</span>
            </button>
            <button type="button" class="dash-tab-btn" onclick="switchDashboardTab('tab-card-audio')">
                <span>⚡ ตั้งค่าเสียงเปิดการ์ด &amp; สุ่มเต๋า (Card Sound)</span>
            </button>
        </nav>

        <!-- ============================================================ -->
        <!-- TAB 1: รายการชำระเงินซื้อเพชร (Orders & Invoices) -->
        <!-- ============================================================ -->
        <section id="tab-orders" class="tab-pane active">
            <div class="glass-card">
                <div class="card-header-row">
                    <div class="card-title-text">
                        <span>📋 บันทึกประวัติการเติมเงิน &amp; รายการชำระเงินซื้อเพชร</span>
                    </div>

                    <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                        <!-- Filter Status -->
                        <select id="order-filter-status" onchange="loadOrdersList()" style="background:#0b1120; border:1px solid var(--panel-border); color:#fff; padding:6px 10px; border-radius:8px; font-size:12px;">
                            <option value="ALL">สถานะทั้งหมด</option>
                            <option value="PAID">ชำระสำเร็จ (PAID)</option>
                            <option value="PENDING">รอดำเนินการ (PENDING)</option>
                        </select>

                        <!-- Filter Payment Method -->
                        <select id="order-filter-method" onchange="loadOrdersList()" style="background:#0b1120; border:1px solid var(--panel-border); color:#fff; padding:6px 10px; border-radius:8px; font-size:12px;">
                            <option value="ALL">ช่องทางทั้งหมด</option>
                            <option value="promptpay">PromptPay</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="truemoney">TrueMoney</option>
                            <option value="paypal">PayPal</option>
                        </select>

                        <!-- Search -->
                        <input type="text" id="order-search-input" placeholder="ค้นหาเลขบิล, ชื่อผู้เล่น..." oninput="debounceLoadOrders()"
                            style="background:#0b1120; border:1px solid var(--panel-border); color:#fff; padding:6px 10px; border-radius:8px; font-size:12px; width:160px;">

                        <button type="button" class="btn-action-primary" onclick="loadOrdersList()">
                            🔄 รีเฟรช
                        </button>
                        <button type="button" class="btn-action-primary" style="background:#10b981; color:#fff;" onclick="openTestOrderModal()">
                            ➕ สร้างบิลทดสอบ
                        </button>
                    </div>
                </div>

                <!-- Orders Table -->
                <div class="table-responsive-box">
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>เลขที่คำสั่งซื้อ (Order No)</th>
                                <th>ผู้เล่น (Username)</th>
                                <th>แพ็กเกจเพชร (Package Details)</th>
                                <th>เพชรที่ได้รับ</th>
                                <th>ยอดเงิน (THB)</th>
                                <th>ช่องทางชำระเงิน</th>
                                <th>สถานะ</th>
                                <th>เลขอ้างอิง (Ref)</th>
                                <th>วัน-เวลาที่ทำรายการ</th>
                                <th>จัดการ (Action)</th>
                            </tr>
                        </thead>
                        <tbody id="orders-table-body">
                            <tr>
                                <td colspan="10" style="text-align:center; padding:24px; color:var(--text-sub);">
                                    ⏳ กำลังโหลดรายการชำระเงิน...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- ============================================================ -->
        <!-- TAB 2: ตั้งค่าระบบ & ช่องทางชำระเงิน (System Settings) -->
        <!-- ============================================================ -->
        <section id="tab-settings" class="tab-pane">
            <div class="glass-card">
                <div class="card-header-row">
                    <div class="card-title-text">
                        <span>🌐 ตั้งค่าโดเมนหลักของเกมบน WebView (iOS / Android)</span>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group" style="grid-column: span 2;">
                        <label for="setting-webview-domain">
                            โดเมนหลัก WebView URL (สำหรับแอปพลิเคชัน iOS Capacitor ดึงไปแสดงผลแบบ Edge-to-Edge):
                        </label>
                        <div style="display:flex; gap:8px;">
                            <input type="url" id="setting-webview-domain" class="form-control" value="<?= htmlspecialchars($curDomain) ?>" placeholder="https://pmix01.thddns.net:7175/home/snake/">
                            <button type="button" class="btn-action-primary" onclick="saveWebviewDomainAction()" style="white-space:nowrap;">
                                💾 บันทึกโดเมน
                            </button>
                        </div>
                        <span style="font-size:11px; color:#94a3b8; margin-top:2px;">
                            * เมื่อบันทึก โดเมนนี้จะถูกกระจายไปยัง <code>app_config.php</code> และ <code>ota_version.json</code> เพื่อให้แอปมือถือเชื่อมต่อตรงทันที
                        </span>
                    </div>
                </div>
            </div>

            <!-- Payment Gateways Toggles -->
            <div class="glass-card">
                <div class="card-header-row">
                    <div class="card-title-text">
                        <span>💳 สลับเปิด/ปิด ช่องทางการชำระเงิน (Payment Gateway Toggles)</span>
                    </div>
                    <span style="font-size:11px; color:#10b981; font-weight:700;">● สลับแล้วบันทึกลงระบบทันที</span>
                </div>

                <div class="gateways-grid">
                    <!-- 1. PromptPay -->
                    <div class="gateway-card <?= $payPromptPay ? 'enabled' : '' ?>" id="gw-box-promptpay">
                        <div class="gw-meta">
                            <span class="gw-icon">🇹🇭</span>
                            <div>
                                <div class="gw-title">PromptPay QR</div>
                                <div class="gw-status-text" id="gw-status-promptpay"><?= $payPromptPay ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน' ?></div>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-promptpay" <?= $payPromptPay ? 'checked' : '' ?> onchange="toggleGateway('promptpay', this.checked)">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- 2. Credit Card -->
                    <div class="gateway-card <?= $payCredit ? 'enabled' : '' ?>" id="gw-box-creditcard">
                        <div class="gw-meta">
                            <span class="gw-icon">💳</span>
                            <div>
                                <div class="gw-title">บัตรเครดิต/เดบิต</div>
                                <div class="gw-status-text" id="gw-status-creditcard"><?= $payCredit ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน' ?></div>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-creditcard" <?= $payCredit ? 'checked' : '' ?> onchange="toggleGateway('creditcard', this.checked)">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- 3. TrueMoney Wallet -->
                    <div class="gateway-card <?= $payTrueMoney ? 'enabled' : '' ?>" id="gw-box-truemoney">
                        <div class="gw-meta">
                            <span class="gw-icon">🟠</span>
                            <div>
                                <div class="gw-title">TrueMoney Wallet</div>
                                <div class="gw-status-text" id="gw-status-truemoney"><?= $payTrueMoney ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน' ?></div>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-truemoney" <?= $payTrueMoney ? 'checked' : '' ?> onchange="toggleGateway('truemoney', this.checked)">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- 4. PayPal -->
                    <div class="gateway-card <?= $payPayPal ? 'enabled' : '' ?>" id="gw-box-paypal">
                        <div class="gw-meta">
                            <span class="gw-icon">🌐</span>
                            <div>
                                <div class="gw-title">PayPal Global</div>
                                <div class="gw-status-text" id="gw-status-paypal"><?= $payPayPal ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน' ?></div>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-paypal" <?= $payPayPal ? 'checked' : '' ?> onchange="toggleGateway('paypal', this.checked)">
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- 5. ShopeePay -->
                    <div class="gateway-card <?= $payShopeePay ? 'enabled' : '' ?>" id="gw-box-shopeepay">
                        <div class="gw-meta">
                            <span class="gw-icon">🛍️</span>
                            <div>
                                <div class="gw-title">ShopeePay</div>
                                <div class="gw-status-text" id="gw-status-shopeepay"><?= $payShopeePay ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน' ?></div>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-shopeepay" <?= $payShopeePay ? 'checked' : '' ?> onchange="toggleGateway('shopeepay', this.checked)">
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- PromptPay Configuration Card -->
            <div class="glass-card" style="margin-top:20px; border:1.5px solid rgba(0, 229, 255, 0.4); background:linear-gradient(135deg, rgba(15,23,42,0.95), rgba(8,14,28,0.95));">
                <div class="card-header-row" style="margin-bottom:14px;">
                    <div class="card-title-text" style="color:#00e5ff;">
                        <span>🇹🇭 กำหนดรหัสและบัญชีรับเงินพร้อมเพย์ (PromptPay QR Code Settings)</span>
                    </div>
                    <span style="font-size:12px; color:#a7f3d0; font-weight:600;">⚡ รองรับแอป Mobile Banking ทุกธนาคารในไทย</span>
                </div>

                <div style="display:grid; grid-template-columns: 1.4fr 1fr; gap:20px; align-items:start;">
                    <!-- Left Form -->
                    <div style="display:flex; flex-direction:column; gap:14px;">
                        <div>
                            <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                📱 หมายเลขพร้อมเพย์ (เบอร์โทรศัพท์มือถือ 10 หลัก หรือ เลขประจำตัวประชาชน 13 หลัก):
                            </label>
                            <input type="text" id="setting-promptpay-id" class="form-control" 
                                   value="<?= htmlspecialchars($promptpayId) ?>" 
                                   placeholder="เช่น 0812345678 หรือ 1100400123456" 
                                   maxlength="18" 
                                   oninput="updatePromptPayQrPreview()">
                            <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                                * ใส่เบอร์มือถือ เช่น <code>0891234567</code> หรือ เลขบัตร ปชช. <code>1100400123456</code> (ระบบจะแปลงเข้าฟอร์แมตมาตรฐาน EMVCo อัตโนมัติ)
                            </div>
                        </div>

                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
                            <div>
                                <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                    👤 ชื่อบัญชีผู้รับเงิน (Account Name):
                                </label>
                                <input type="text" id="setting-promptpay-name" class="form-control" 
                                       value="<?= htmlspecialchars($promptpayName) ?>" 
                                       placeholder="เช่น นาย สมชาย ใจดี / บันทึกชื่อร้าน"
                                       oninput="updatePromptPayQrPreview()">
                                <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                                    * แสดงชื่อให้ผู้เล่นตรวจสอบก่อนกดยืนยันโอนเงิน
                                </div>
                            </div>
                            <div>
                                <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                    🏦 ธนาคาร / บริการ (Bank):
                                </label>
                                <input type="text" id="setting-promptpay-bank" class="form-control" 
                                       value="<?= htmlspecialchars($promptpayBank) ?>" 
                                       placeholder="เช่น กสิกรไทย (KBANK), ไทยพาณิชย์ หรือ พร้อมเพย์">
                                <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                                    * ระบุธนาคารเจ้าของบัญชี
                                </div>
                            </div>
                        </div>

                        <div style="display:flex; gap:12px; align-items:center; margin-top:4px;">
                            <button type="button" class="btn-action-primary" onclick="savePromptPaySettingsAction()" style="padding:10px 24px; font-size:13px; font-weight:700;">
                                💾 บันทึกรหัสพร้อมเพย์
                            </button>
                            <span id="promptpay-save-status" style="font-size:12px; color:#34d399; font-weight:700; display:none;">
                                ✓ บันทึกสำเร็จแล้ว
                            </span>
                        </div>
                    </div>

                    <!-- Right Live QR Preview -->
                    <div style="background:rgba(15,23,42,0.85); border:1.5px solid rgba(0,229,255,0.3); border-radius:14px; padding:18px; text-align:center;">
                        <div style="font-size:12px; font-weight:700; color:#00e5ff; margin-bottom:10px;">
                            📷 ตัวอย่าง QR Code พร้อมเพย์ (Live Preview)
                        </div>
                        <div id="pp-preview-wrap" style="display:inline-block; background:#fff; padding:10px; border-radius:12px; box-shadow:0 0 25px rgba(0,229,255,0.25);">
                            <img id="pp-preview-img" src="" alt="PromptPay QR Code" style="width:160px; height:160px; object-fit:contain; display:block; border-radius:4px;">
                        </div>
                        <div style="margin-top:10px; font-size:13px; color:#f8fafc; font-weight:700;" id="pp-preview-label-name">
                            <?= $promptpayName ? htmlspecialchars($promptpayName) : 'ชื่อบัญชี: (ยังไม่ได้ระบุ)' ?>
                        </div>
                        <div style="font-size:12px; color:#00e5ff; font-weight:600;" id="pp-preview-label-id">
                            <?= $promptpayId ? 'พร้อมเพย์: ' . htmlspecialchars($promptpayId) : 'ยังไม่ได้ระบุหมายเลขพร้อมเพย์' ?>
                        </div>
                        <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                            * ตัวอย่าง QR โค้ดสำหรับเติมเพชร 10.00 บาท (1,000 เพชร)
                        </div>
                    </div>
                </div>
            </div>

            <!-- ShopeePay Configuration Card -->
            <div class="glass-card" style="margin-top:20px; border:1.5px solid #ee4d2d; background:linear-gradient(135deg, rgba(32,14,12,0.95), rgba(15,5,5,0.95));">
                <div class="card-header-row" style="margin-bottom:14px;">
                    <div class="card-title-text" style="color:#ee4d2d;">
                        <span>🛍️ กำหนดรหัสและบัญชีรับเงิน ShopeePay (Shopee ID Settings)</span>
                    </div>
                    <span style="font-size:12px; color:#ff7337; font-weight:600;">⚡ สแกนจ่าย / เปิดแอป Shopee รับเหรียญคืน</span>
                </div>

                <div style="display:grid; grid-template-columns: 1.4fr 1fr; gap:20px; align-items:start;">
                    <!-- Left Form -->
                    <div style="display:flex; flex-direction:column; gap:14px;">
                        <div>
                            <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                🛍️ Shopee ID / หมายเลขบัญชี ShopeePay (เบอร์โทร หรือ Merchant ID):
                            </label>
                            <input type="text" id="setting-shopeepay-id" class="form-control" 
                                   value="<?= htmlspecialchars($shopeepayId) ?>" 
                                   placeholder="เช่น 0891234567 หรือ SHOPEE_STORE_01" 
                                   oninput="updateShopeePayQrPreview()">
                        </div>

                        <div>
                            <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                👤 ชื่อร้านค้า / บัญชีผู้รับเงิน ShopeePay:
                            </label>
                            <input type="text" id="setting-shopeepay-name" class="form-control" 
                                   value="<?= htmlspecialchars($shopeepayName) ?>" 
                                   placeholder="เช่น Snake & Ladder 3D Official" 
                                   oninput="updateShopeePayQrPreview()">
                        </div>

                        <div>
                            <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                                🔗 ลิงก์รูป QR Code รับเงิน Shopee (ถ้ามี):
                            </label>
                            <input type="text" id="setting-shopeepay-qr-url" class="form-control" 
                                   value="<?= htmlspecialchars($shopeepayQrUrl) ?>" 
                                   placeholder="https://... หรือ assets/img/shopee_qr.png" 
                                   oninput="updateShopeePayQrPreview()">
                        </div>

                        <div style="display:flex; align-items:center; gap:12px; margin-top:4px;">
                            <button type="button" class="btn-action-primary" onclick="saveShopeePaySettingsAction()" style="background:linear-gradient(135deg, #ee4d2d, #ff5722); color:#fff; font-size:13px; padding:10px 20px;">
                                💾 บันทึกรหัส ShopeePay
                            </button>
                            <span id="shopeepay-save-status" style="font-size:12px; font-weight:700;"></span>
                        </div>
                    </div>

                    <!-- Right Live Preview -->
                    <div style="background:rgba(8,14,28,0.8); border:1.5px solid rgba(238,77,45,0.35); border-radius:12px; padding:16px; text-align:center;">
                        <div style="font-size:12px; font-weight:800; color:#ff7337; margin-bottom:10px;">
                            🛍️ ตัวอย่าง QR Code ShopeePay (Live Preview)
                        </div>
                        <div style="background:#fff; border-radius:10px; padding:8px; display:inline-block; box-shadow:0 0 16px rgba(238,77,45,0.3); border:2px solid #ee4d2d;">
                            <img id="sp-preview-img" src="" alt="ShopeePay QR Preview" style="width:160px; height:160px; object-fit:contain; display:block;">
                        </div>
                        <div style="margin-top:10px;">
                            <div id="sp-preview-label-name" style="font-size:13px; font-weight:800; color:#fff;">ชื่อบัญชี: <?= htmlspecialchars($shopeepayName ?: '(ยังไม่ได้ระบุ)') ?></div>
                            <div id="sp-preview-label-id" style="font-size:12px; color:#ff7337; font-weight:700; margin-top:2px;">Shopee ID: <?= htmlspecialchars($shopeepayId ?: 'ยังไม่ได้ระบุ') ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PayPal Configuration Card -->
            <div class="glass-card" style="margin-top:20px; border:1.5px solid rgba(2, 132, 199, 0.45); background:linear-gradient(135deg, rgba(15,23,42,0.95), rgba(8,14,28,0.95));">
                <div class="card-header-row" style="margin-bottom:14px;">
                    <div class="card-title-text" style="color:#38bdf8; display:flex; align-items:center; gap:8px;">
                        <span>🌐 กำหนดบัญชีและไอดีรับเงิน PayPal Global (PayPal Merchant Account)</span>
                    </div>
                    <span style="font-size:12px; color:#93c5fd; font-weight:600;">⚡ รับเงินตรงเข้ากระเป๋า PayPal Business ของคุณ</span>
                </div>

                <div style="background:rgba(2,132,199,0.12); border:1px solid rgba(56,189,248,0.3); border-radius:10px; padding:12px 14px; margin-bottom:16px; font-size:12.5px; line-height:1.6; color:#cbd5e1;">
                    <div>💡 <strong>เงินเข้าตรงไหน:</strong> เมื่อผู้เล่นชำระเงินผ่าน PayPal ยอดเงินจะเข้าสู่ <strong>บัญชี PayPal Business (PayPal Wallet)</strong> ของคุณทันที และคุณสามารถกดถอนเข้าบัญชีธนาคารไทยได้ตลอด 24 ชม.</div>
                    <div style="margin-top:4px;">🔑 <strong>ต้องกรอกไอดีที่ไหน:</strong> กรอก <strong>PayPal Business Email</strong> ด้านล่างนี้เพื่อให้ระบบเปิดหน้าชำระเงินไปยังบัญชีคุณ และหากต้องการระบบตัดเงินอัตโนมัติ (REST API) ให้ใส่ <strong>PayPal Client ID</strong> จาก developer.paypal.com</div>
                </div>

                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:16px; align-items:start;">
                    <div>
                        <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                            📧 PayPal Business Email (อีเมลบัญชี PayPal สำหรับรับเงิน):
                        </label>
                        <input type="email" id="setting-paypal-email" class="form-control" 
                               value="<?= htmlspecialchars($paypalEmail) ?>" 
                               placeholder="เช่น your-paypal-business@domain.com">
                        <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                            * อีเมลที่ใช้ล็อกอินบัญชี PayPal ธุรกิจของคุณที่ต้องการให้ผู้เล่นโอนเงินเข้า
                        </div>
                    </div>

                    <div>
                        <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                            🔑 PayPal Client ID (รหัส REST API Client ID - ออปชันเสริม):
                        </label>
                        <input type="text" id="setting-paypal-client-id" class="form-control" 
                               value="<?= htmlspecialchars($paypalClientId) ?>" 
                               placeholder="เช่น AXYZ123... (สร้างได้ฟรีที่ developer.paypal.com)">
                        <div style="font-size:11px; color:#94a3b8; margin-top:4px;">
                            * รหัส Client ID สำหรับเรียกปุ่ม PayPal Smart Buttons ตัดเงินอัจฉริยะ
                        </div>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin-top:14px; align-items:center;">
                    <div>
                        <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                            💱 สกุลเงินที่แสดงในบิล (Currency):
                        </label>
                        <select id="setting-paypal-currency" class="form-control">
                            <option value="THB" <?= ($paypalCurrency === 'THB') ? 'selected' : '' ?>>THB — เงินบาทไทย (฿)</option>
                            <option value="USD" <?= ($paypalCurrency === 'USD') ? 'selected' : '' ?>>USD — US Dollars ($)</option>
                        </select>
                    </div>

                    <div>
                        <label style="display:block; font-size:12px; color:#cbd5e1; font-weight:700; margin-bottom:6px;">
                            🧪 โหมดทดสอบ (Sandbox Mode):
                        </label>
                        <label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer; font-size:12px; color:#cbd5e1; margin-top:6px;">
                            <input type="checkbox" id="setting-paypal-sandbox" <?= $paypalSandbox ? 'checked' : '' ?> style="transform:scale(1.2);">
                            <span>เปิดใช้งาน Sandbox (ใช้สำหรับทดสอบ ไม่หักเงินจริง)</span>
                        </label>
                    </div>
                </div>

                <div style="display:flex; gap:12px; align-items:center; margin-top:16px;">
                    <button type="button" class="btn-action-primary" onclick="savePayPalSettingsAction()" style="padding:10px 24px; font-size:13px; font-weight:700; background:linear-gradient(135deg, #0284c7, #00e5ff); color:#000;">
                        💾 บันทึกการตั้งค่า PayPal
                    </button>
                    <span id="paypal-save-status" style="font-size:12px; color:#38bdf8; font-weight:700; display:none;">
                        ✓ บันทึกข้อมูล PayPal สำเร็จแล้ว
                    </span>
                </div>
            </div>
        </section>

        <!-- ============================================================ -->
        <!-- TAB 3: Live Deploy Update & Version History -->
        <!-- ============================================================ -->
        <section id="tab-deploy" class="tab-pane">
            <div class="glass-card" style="background:linear-gradient(135deg, rgba(15,23,42,0.95), rgba(8,14,28,0.95)); border:2px solid rgba(0,229,255,0.4);">
                <div class="card-header-row">
                    <div class="card-title-text" style="color:#00e5ff;">
                        <span>🚀 Deploy Live Update (อัปเดตเวอร์ชันผ่านระบบ Live JSON Endpoint)</span>
                    </div>
                    <span style="font-size:11.5px; color:#38bdf8;">แอป iOS/Android จะดึงเวอร์ชันใหม่ทันทีโดยไม่ต้องลงแอปใหม่</span>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="deploy-version-input">กำหนดเวอร์ชันเป้าหมาย (Target Version):</label>
                        <input type="text" id="deploy-version-input" class="form-control" value="<?= htmlspecialchars($curVersion) ?>">
                    </div>

                    <div class="form-group">
                        <label for="deploy-note-input">บันทึกรายละเอียดการอัปเดต (Release Note):</label>
                        <input type="text" id="deploy-note-input" class="form-control" value="อัปเดตระบบเกมส์และปรับปรุงประสิทธิภาพความลื่นไหล">
                    </div>
                </div>

                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; flex-wrap:wrap; gap:10px;">
                    <label style="display:inline-flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;">
                        <input type="checkbox" id="deploy-force-cache" checked style="transform:scale(1.2);">
                        <span>บังคับล้างแคชเก่าในอุปกรณ์ผู้เล่น (Force Cache Buster)</span>
                    </label>

                    <button type="button" class="btn-deploy" onclick="submitDeployUpdateAction()" id="btn-deploy-submit">
                        <span>🚀 Deploy Update ทันที</span>
                    </button>
                </div>
            </div>
        </section>

        <!-- ============================================================ -->
        <!-- TAB 4: จัดการไอคอนแอป (App Icon Manager) -->
        <!-- ============================================================ -->
        <section id="tab-icon" class="tab-pane">
            <div class="glass-card" style="background:linear-gradient(135deg, rgba(15,23,42,0.95), rgba(8,14,28,0.95)); border:2px solid rgba(0,229,255,0.35);">
                <div class="card-header-row">
                    <div class="card-title-text" style="color:#00e5ff;">
                        <span>📱 เปลี่ยนและจัดการไอคอนแอป (iOS &amp; Web App Icon Manager)</span>
                    </div>
                    <span style="font-size:12px; color:#38bdf8;">กำหนดไอคอนขนาดมาตรฐาน 1024x1024 px สำหรับ iOS Home Screen และ Web Icon</span>
                </div>

                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:24px; margin-top:16px;">
                    <!-- Column 1: Current & Live Preview -->
                    <div style="background:rgba(2,6,23,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:14px; padding:20px; text-align:center;">
                        <h4 style="font-size:14px; color:#94a3b8; margin-bottom:16px; font-weight:700;">จำลองการแสดงผลบนหน้าจอ iPhone (iOS Home Screen Preview)</h4>
                        
                        <!-- iPhone App Icon Frame -->
                        <div style="display:inline-flex; flex-direction:column; align-items:center; gap:8px;">
                            <div style="width:110px; height:110px; border-radius:24px; overflow:hidden; box-shadow:0 12px 30px rgba(0,0,0,0.6), 0 0 20px rgba(0,229,255,0.3); border:1px solid rgba(255,255,255,0.2); position:relative; background:#0b1120;">
                                <img id="icon-preview-display" src="admin_dashboard.php?api=1&action=get_app_icon&v=<?= time() ?>" alt="App Icon" style="width:100%; height:100%; object-fit:cover; display:block;">
                            </div>
                            <span style="font-size:13px; font-weight:700; color:#f1f5f9; text-shadow:0 2px 4px rgba(0,0,0,0.8);">SnakeGame3D</span>
                            <span style="font-size:10px; color:#00e5ff; background:rgba(0,229,255,0.12); border:1px solid rgba(0,229,255,0.3); padding:2px 8px; border-radius:10px;">ขนาดมาตรฐาน 1024x1024 px</span>

                            <div style="display:flex; flex-wrap:wrap; justify-content:center; gap:8px; margin-top:8px;">
                                <a id="btn-download-icon" href="admin_dashboard.php?api=1&action=get_app_icon" download="AppIcon-512@2x.png" class="btn-link-action" style="font-size:11px; padding:6px 12px; border-color:rgba(0,229,255,0.4); color:#38bdf8; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
                                    <span>⬇️ ดาวน์โหลดไฟล์ไอคอน (1024x1024)</span>
                                </a>
                                <a id="btn-download-ios-zip" href="ios.zip?v=<?= time() ?>" download="ios.zip" class="btn-link-action" style="font-size:11px; padding:6px 12px; background:rgba(16,185,129,0.18); border-color:rgba(16,185,129,0.5); color:#34d399; text-decoration:none; display:inline-flex; align-items:center; gap:6px;">
                                    <span>📦 ดาวน์โหลด ios.zip (อัปเดตไอคอนแล้ว)</span>
                                </a>
                            </div>
                        </div>

                        <div style="margin-top:20px; padding:12px; border-radius:10px; background:rgba(15,23,42,0.8); border:1px solid rgba(255,255,255,0.06); font-size:12px; color:#94a3b8; text-align:left; line-height:1.6;">
                            <span style="color:#38bdf8; font-weight:700;">📍 ตำแหน่งไฟล์ในระบบ:</span><br>
                            • iOS Asset: <code style="color:#f59e0b;">ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png</code><br>
                            • Web / Safari Icon: <code style="color:#10b981;">apple-touch-icon.png</code> &amp; <code style="color:#10b981;">assets/images/app_icon.png</code>
                        </div>
                    </div>

                    <!-- Column 2: Upload & Save Controls -->
                    <div style="background:rgba(2,6,23,0.6); border:1px solid rgba(255,255,255,0.1); border-radius:14px; padding:20px; display:flex; flex-direction:column; justify-content:space-between;">
                        <div>
                            <h4 style="font-size:14px; color:#94a3b8; margin-bottom:12px; font-weight:700;">อัปโหลดรูปภาพไอคอนใหม่ (Upload New Icon)</h4>
                            
                            <!-- Dropzone -->
                            <div id="icon-dropzone" onclick="document.getElementById('icon-file-input').click()" style="border:2px dashed rgba(0,229,255,0.4); border-radius:12px; padding:24px 16px; text-align:center; cursor:pointer; background:rgba(0,229,255,0.03); transition:all 0.2s ease;">
                                <div style="font-size:36px; margin-bottom:8px;">🖼️</div>
                                <div style="font-size:13px; font-weight:700; color:#38bdf8;">คลิกเลือกไฟล์ หรือลากรูปมาวางที่นี่</div>
                                <div style="font-size:11px; color:#64748b; margin-top:4px;">รองรับไฟล์ PNG, JPG, WebP (แนะนำรูปสี่เหลี่ยมจัตุรัส 1024x1024)</div>
                            </div>
                            <input type="file" id="icon-file-input" accept="image/*" style="display:none;" onchange="handleIconFileSelect(this.files[0])">

                            <!-- Status & Preview feedback -->
                            <div id="icon-select-info" style="display:none; margin-top:12px; font-size:12px; color:#10b981; font-weight:700; align-items:center; gap:6px;">
                                <span>✅ โหลดรูปภาพสำเร็จ:</span> <span id="icon-file-name" style="color:#fff;"></span>
                            </div>

                            <canvas id="icon-canvas-processor" width="1024" height="1024" style="display:none;"></canvas>
                        </div>

                        <div style="margin-top:20px;">
                            <button type="button" id="btn-save-app-icon" class="btn-action-primary" style="width:100%; padding:14px; font-size:14px; border-radius:10px; display:flex; align-items:center; justify-content:center; gap:8px;" onclick="submitAppIconUpload()">
                                <span>💾 บันทึกและแทนที่ไอคอน iOS &amp; Web ทันที</span>
                            </button>
                            <span id="icon-upload-status" style="display:block; text-align:center; font-size:12px; font-weight:700; margin-top:8px;"></span>
                        </div>
                    </div>
                </div>

                <!-- Rebuild & Deployment Instructions Callout -->
                <div style="margin-top:20px; background:rgba(30, 41, 59, 0.7); border-left:4px solid #f59e0b; border-radius:10px; padding:16px 20px;">
                    <div style="font-size:14px; font-weight:800; color:#fbbf24; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
                        <span>⚠️ คำตอบข้อสงสัย: ต้อง Rebuild (Rebroid) ใหม่หรือไม่?</span>
                    </div>
                    <div style="font-size:13px; color:#cbd5e1; line-height:1.7;">
                        <p style="margin-bottom:8px;">
                            <strong>1. ไอคอนนี้เปลี่ยนได้ไหม?</strong>: <strong>เปลี่ยนได้แน่นอน 100% ครับ</strong> สามารถอัปโหลดรูปโลโก้เกมส์ใหม่ที่นี่ได้ทันที ระบบจะแปลงขนาดเป็น 1024x1024 ให้โดยอัตโนมัติ
                        </p>
                        <p style="margin-bottom:8px;">
                            <strong>2. เปลี่ยนในหน้า Admin ได้ทันทีไหม?</strong>: <strong>ได้ทันทีครับ</strong> เมื่อกดปุ่ม <em>"บันทึกและแทนที่ไอคอน"</em> ระบบหลังบ้านจะนำรูปภาพไปเซฟทับไฟล์ <code>AppIcon-512@2x.png</code> ในโฟลเดอร์โปรเจกต์ iOS ของคุณทันที
                        </p>
                        <p style="margin-bottom:0;">
                            <strong>3. ต้อง Rebuild ใหม่หรือไม่?</strong>: <span style="color:#fbbf24; font-weight:700;">จำเป็นต้อง Rebuild / Re-run ใน Xcode ใหม่อีก 1 ครั้งครับ</span><br>
                            <span style="font-size:12px; color:#94a3b8;">
                                💡 <em>เหตุผล:</em> ระบบความปลอดภัยของ Apple iOS บังคับให้ไอคอนหน้าจอโฮม (SpringBoard App Icon) ต้องถูก Compile ฝังอยู่ในตัวไฟล์แอปพลิเคชัน (.ipa / Binary Bundle) เท่านั้น จึงไม่สามารถเปลี่ยนทางอากาศ (OTA) ได้เหมือนรูปภาพในเกมส์<br>
                                🚀 <em>วิธีทำให้มีผลบน iPhone:</em> หลังกดบันทึก ให้เปิดโปรแกรม <strong>Xcode</strong> หรือรันคำสั่ง <code>npx cap sync ios</code> แล้วกด <strong>Run (▶)</strong> เพื่อติดตั้งลงเครื่อง iPhone อีกครั้ง ไอคอนบนหน้าจอโฮมจะเปลี่ยนเป็นรูปใหม่ทันทีครับ!
                            </span>
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- ============================================================ -->
        <!-- TAB 5: ตั้งค่าเสียงเปิดการ์ด & สุ่มเต๋า (Card & Dice Reveal Sound) -->
        <!-- ============================================================ -->
        <section id="tab-card-audio" class="tab-pane">
            <div class="glass-card" style="background:linear-gradient(135deg, rgba(15,23,42,0.96), rgba(8,14,28,0.98)); border:2px solid #fbbf24;">
                <div class="card-header-row">
                    <div class="card-title-text" style="color:#fde047;">
                        <span>⚡ ตั้งค่าการเปิดการ์ด / สุ่มการ์ด / สุ่มเต๋า ทีละใบ ("แซ๊บ แซ๊บ แซ๊บ แซ๊บ แซ๊บ")</span>
                    </div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <button type="button" class="btn-action-primary" onclick="testDashCardRevealSeq(1)" style="background:linear-gradient(135deg,#0ea5e9,#0284c7); color:#fff;">
                            🔊 ทดลองฟัง 1 ใบ (1 แซ๊บ)
                        </button>
                        <button type="button" class="btn-action-primary" onclick="testDashCardRevealSeq(5)" style="background:linear-gradient(135deg,#f59e0b,#d97706); color:#000;">
                            🎴 ทดลองเปิด 5 ใบ (5 แซ๊บ)
                        </button>
                        <button type="button" class="btn-deploy" onclick="saveDashCardRevealConfig()" style="padding:8px 18px; font-size:13px;">
                            💾 บันทึกการตั้งค่า
                        </button>
                    </div>
                </div>

                <p style="font-size:12.5px; color:#cbd5e1; margin:6px 0 18px 0;">
                    กำหนดจังหวะการเปิดการ์ดหรือสุ่มเต๋าทีละ 1 ใบ (ค่าเริ่มต้นห่างกัน <strong>0.5 วินาที</strong>) พร้อมเลือกเสียงเอฟเฟกต์ต่อใบ เช่น เปิด 5 ใบ ดัง 5 แซ๊บ หรืออัปโหลดไฟล์เสียงใหม่ได้ทันที
                </p>

                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:18px;">
                    <!-- 1. Sound Preset -->
                    <div style="background:rgba(2,6,23,0.65); border:1px solid rgba(255,255,255,0.12); border-radius:12px; padding:16px;">
                        <label style="font-size:13px; font-weight:800; color:#fde047; display:block; margin-bottom:8px;">🎵 เลือกรูปแบบเสียงเปิดการ์ดต่อใบ ("แซ๊บ!"):</label>
                        <select id="dash-card-preset" class="form-control" onchange="onDashCardPresetChange(this.value)" style="font-weight:700;">
                            <option value="zap_classic">⚡ เสียง "แซ๊บ!" สายฟ้าเปิดการ์ดต้นฉบับ (แนะนำ)</option>
                            <option value="zap_magic">✨ เสียง "แซ๊บ-วิ้ง!" เลเซอร์เวทมนตร์คาสิโน</option>
                            <option value="card_whip">🃏 เสียง "ฟึ่บ-แซ๊บ!" สะบัดเปิดการ์ดคมๆ</option>
                            <option value="coin_ping">💎 เสียง "ปิ๊ง-แซ๊บ!" คริสตัลเพชรเด้ง</option>
                            <option value="custom_file">🎶 ใช้ไฟล์เสียงที่อัปโหลดเองด้านขวา (.mp3 / .wav)</option>
                        </select>
                        <div style="margin-top:12px; display:flex; align-items:center; justify-content:space-between; font-size:12px; color:#94a3b8;">
                            <span>ไฟล์เสียงปัจจุบัน: <strong id="dash-card-cur-file" style="color:#38bdf8;">card_zap.mp3</strong></span>
                            <label style="display:inline-flex; align-items:center; gap:6px; color:#34d399; font-weight:700; cursor:pointer;">
                                <input type="checkbox" id="dash-card-enabled" checked style="width:16px; height:16px; accent-color:#10b981;"> เปิดใช้งานเสียง
                            </label>
                        </div>
                    </div>

                    <!-- 2. Interval (0.5s) & Volume -->
                    <div style="background:rgba(2,6,23,0.65); border:1px solid rgba(255,255,255,0.12); border-radius:12px; padding:16px;">
                        <label style="font-size:13px; font-weight:800; color:#38bdf8; display:flex; justify-content:space-between; margin-bottom:8px;">
                            <span>⏱️ ระยะเวลาเปิดการ์ดห่างกันต่อใบ:</span>
                            <strong id="dash-card-interval-lbl" style="color:#fde047;">0.50 วินาที / ใบ</strong>
                        </label>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <input type="number" id="dash-card-interval" class="form-control" min="0.1" max="3.0" step="0.05" value="0.5" oninput="document.getElementById('dash-card-interval-lbl').innerText = Number(this.value || 0.5).toFixed(2) + ' วินาที / ใบ'" style="width:100px; text-align:center; font-weight:900; color:#fde047;">
                            <button type="button" class="btn-link-action" onclick="setDashCardInterval(0.3)" style="font-size:11px; padding:6px 10px;">0.3 วิ</button>
                            <button type="button" class="btn-link-action" onclick="setDashCardInterval(0.5)" style="font-size:11px; padding:6px 10px; border-color:#fbbf24; color:#fde047;">0.5 วิ (มาตรฐาน)</button>
                            <button type="button" class="btn-link-action" onclick="setDashCardInterval(0.8)" style="font-size:11px; padding:6px 10px;">0.8 วิ</button>
                        </div>
                        <div style="margin-top:12px;">
                            <label style="font-size:12px; color:#cbd5e1; display:flex; justify-content:space-between;">
                                <span>🔉 ระดับความดังเสียง:</span>
                                <strong id="dash-card-vol-lbl" style="color:#fbbf24;">95%</strong>
                            </label>
                            <input type="range" id="dash-card-vol" min="10" max="100" step="5" value="95" oninput="document.getElementById('dash-card-vol-lbl').innerText = this.value + '%'" style="width:100%; cursor:pointer; margin-top:4px;">
                        </div>
                    </div>

                    <!-- 3. Custom Sound File Upload & 5-Card Sim -->
                    <div style="background:rgba(2,6,23,0.65); border:1px solid rgba(255,255,255,0.12); border-radius:12px; padding:16px;">
                        <label style="font-size:13px; font-weight:800; color:#f472b6; display:block; margin-bottom:8px;">📤 อัปโหลดไฟล์เสียงเปิดการ์ดใหม่ (.mp3 / .wav):</label>
                        <label style="display:flex; align-items:center; justify-content:center; gap:8px; background:linear-gradient(135deg,#ec4899,#db2777); color:#fff; padding:10px 14px; border-radius:9px; font-size:12.5px; font-weight:800; cursor:pointer;">
                            <span>📁 เลือกไฟล์เสียงอัปโหลดทับทันที</span>
                            <input type="file" accept=".mp3,.wav,.ogg,.m4a" style="display:none;" onchange="uploadDashCardSoundFile(this)">
                        </label>
                        <div style="margin-top:12px;">
                            <div style="font-size:11px; color:#94a3b8; margin-bottom:5px;">จำลองจังหวะเปิด 5 ใบ (1 -> 2 -> 3 -> 4 -> 5):</div>
                            <div id="dash-card-sim-row" style="display:grid; grid-template-columns:repeat(5, 1fr); gap:6px;">
                                <div class="dash-sim-slot" style="padding:6px 0; text-align:center; border-radius:7px; background:#1e293b; border:1.5px solid #475569; font-size:11px; font-weight:800; color:#94a3b8; transition:all 0.15s;">ใบที่ 1</div>
                                <div class="dash-sim-slot" style="padding:6px 0; text-align:center; border-radius:7px; background:#1e293b; border:1.5px solid #475569; font-size:11px; font-weight:800; color:#94a3b8; transition:all 0.15s;">ใบที่ 2</div>
                                <div class="dash-sim-slot" style="padding:6px 0; text-align:center; border-radius:7px; background:#1e293b; border:1.5px solid #475569; font-size:11px; font-weight:800; color:#94a3b8; transition:all 0.15s;">ใบที่ 3 🌟</div>
                                <div class="dash-sim-slot" style="padding:6px 0; text-align:center; border-radius:7px; background:#1e293b; border:1.5px solid #475569; font-size:11px; font-weight:800; color:#94a3b8; transition:all 0.15s;">ใบที่ 4</div>
                                <div class="dash-sim-slot" style="padding:6px 0; text-align:center; border-radius:7px; background:#1e293b; border:1.5px solid #475569; font-size:11px; font-weight:800; color:#94a3b8; transition:all 0.15s;">ใบที่ 5</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <!-- Custom Notification Popup Modal -->
    <div id="dash-popup-modal" class="popup-modal-overlay">
        <div class="popup-modal-card">
            <div id="dash-popup-icon" style="font-size: 42px; margin-bottom: 8px;">🎉</div>
            <div id="dash-popup-title" style="font-size: 17px; font-weight: 800; color: #fff; margin-bottom: 6px;">แจ้งเตือนสำเร็จ</div>
            <div id="dash-popup-message" style="font-size: 13px; color: #94a3b8; line-height: 1.6; margin-bottom: 18px;">รายละเอียดข้อความ</div>
            <button type="button" class="btn-action-primary" style="padding: 10px 24px; font-size: 13px;" onclick="closeDashPopup()">
                ตกลง / ปิดหน้าต่าง
            </button>
        </div>
    </div>

    <!-- Test Order Modal -->
    <div id="test-order-modal" class="popup-modal-overlay">
        <div class="popup-modal-card" style="width: min(94vw, 480px); text-align: left;">
            <div style="font-size: 16px; font-weight: 800; color: #00e5ff; margin-bottom: 12px; display:flex; justify-content:space-between; align-items:center;">
                <span>➕ สร้างบิลคำสั่งซื้อทดสอบ (Test Order)</span>
                <span onclick="closeTestOrderModal()" style="cursor:pointer; font-size:20px; color:#fff;">&times;</span>
            </div>

            <div class="form-group" style="margin-bottom:10px;">
                <label>เลือกแพ็กเกจเพชร:</label>
                <select id="modal-test-pkg" class="form-control">
                    <option value="dia_1000">1,000 เพชร — ราคา 10 บาท</option>
                    <option value="dia_promo_2plus1">โปรโมชัน 2 แถม 1 (ราคา 20 บาท ได้รับ 3,000 เพชร)</option>
                </select>
            </div>

            <div class="form-group" style="margin-bottom:10px;">
                <label>ชื่อผู้เล่น:</label>
                <input type="text" id="modal-test-user" class="form-control" value="เอ็นซีพี คอมพิวเตอร์">
            </div>

            <div class="form-group" style="margin-bottom:16px;">
                <label>ช่องทางการชำระเงิน:</label>
                <select id="modal-test-method" class="form-control">
                    <option value="promptpay">🇹🇭 PromptPay QR Code</option>
                    <option value="truemoney">🟠 TrueMoney Wallet</option>
                    <option value="credit_card">💳 บัตรเครดิต/เดบิต</option>
                    <option value="paypal">🌐 PayPal</option>
                </select>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:8px;">
                <button type="button" class="btn-link-action" onclick="closeTestOrderModal()">ยกเลิก</button>
                <button type="button" class="btn-action-primary" onclick="submitCreateTestOrder()">💾 ยืนยันสร้างบิล</button>
            </div>
        </div>
    </div>

    <script>
        if (!window.__dashResilientFetchInstalled) {
            window.__dashResilientFetchInstalled = true;
            if (typeof window.showToast !== 'function') {
                window.showToast = function(msg) {
                    let t = document.getElementById('dash-toast');
                    if (!t) {
                        t = document.createElement('div');
                        t.id = 'dash-toast';
                        t.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#10b981;color:#fff;padding:12px 20px;border-radius:10px;font-weight:700;z-index:999999;box-shadow:0 8px 24px rgba(0,0,0,0.5);display:none;';
                        document.body.appendChild(t);
                    }
                    t.innerText = String(msg ?? 'สำเร็จ');
                    t.style.display = 'block';
                    clearTimeout(window.__dashToastTimer);
                    window.__dashToastTimer = setTimeout(() => { t.style.display = 'none'; }, 3200);
                };
            }
            const _nativeFetch = window.fetch.bind(window);
            window.fetch = async function(input, init) {
                try {
                    return await _nativeFetch(input, init);
                } catch (err) {
                    await new Promise(r => setTimeout(r, 200));
                    const retryUrl = typeof input === 'string'
                        ? input + (input.includes('?') ? '&' : '?') + '_rt=' + Date.now()
                        : input;
                    return await _nativeFetch(retryUrl, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, init || {}));
                }
            };
        }
        // Tab Switcher
        function switchDashboardTab(tabId) {
            document.querySelectorAll('.dash-tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

            const activeBtn = Array.from(document.querySelectorAll('.dash-tab-btn')).find(b => b.getAttribute('onclick').includes(tabId));
            if (activeBtn) activeBtn.classList.add('active');

            const activePane = document.getElementById(tabId);
            if (activePane) activePane.classList.add('active');

            if (tabId === 'tab-orders') {
                loadOrdersList();
            }
        }

        // Show Custom Popup
        function showDashPopup(title, message, icon = '🎉') {
            document.getElementById('dash-popup-title').innerText = title;
            document.getElementById('dash-popup-message').innerText = message;
            document.getElementById('dash-popup-icon').innerText = icon;
            document.getElementById('dash-popup-modal').style.display = 'flex';
        }

        function closeDashPopup() {
            document.getElementById('dash-popup-modal').style.display = 'none';
        }

        function openTestOrderModal() {
            document.getElementById('test-order-modal').style.display = 'flex';
        }

        function closeTestOrderModal() {
            document.getElementById('test-order-modal').style.display = 'none';
        }

        // Load Orders List via AJAX
        let searchTimer = null;
        function debounceLoadOrders() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(loadOrdersList, 300);
        }

        async function loadOrdersList() {
            const status = document.getElementById('order-filter-status')?.value || 'ALL';
            const method = document.getElementById('order-filter-method')?.value || 'ALL';
            const search = document.getElementById('order-search-input')?.value || '';

            try {
                const res = await fetch(`admin_dashboard.php?api=1&action=get_orders&status=${encodeURIComponent(status)}&payment_method=${encodeURIComponent(method)}&search=${encodeURIComponent(search)}`)
                    .then(r => r.json());

                if (res && res.status === 'success') {
                    renderOrdersTable(res.orders || []);
                    renderStatsOverview(res.stats || {});
                }
            } catch (err) {
                console.error('loadOrdersList error:', err);
            }
        }

        function renderStatsOverview(stats) {
            document.getElementById('stat-total-revenue').innerText = '฿' + (stats.total_revenue || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 });
            document.getElementById('stat-today-revenue').innerText = 'วันนี้: ฿' + (stats.today_revenue || 0).toLocaleString('th-TH', { minimumFractionDigits: 2 });
            document.getElementById('stat-paid-orders').innerText = (stats.paid_count || 0) + ' บิล';
            document.getElementById('stat-pending-orders').innerText = 'รอดำเนินการ: ' + (stats.pending_count || 0) + ' บิล';
            document.getElementById('stat-total-diamonds').innerText = (stats.total_diamonds || 0).toLocaleString() + ' 💎';
        }

        function renderOrdersTable(orders) {
            const tbody = document.getElementById('orders-table-body');
            if (!tbody) return;

            if (orders.length === 0) {
                tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:28px; color:#94a3b8;">ไม่มีรายการคำสั่งซื้อตามเงื่อนไขที่เลือก</td></tr>`;
                return;
            }

            const methodBadges = {
                promptpay: '<span class="badge-paymethod" style="border-color:#38bdf8; color:#38bdf8;">🇹🇭 PromptPay</span>',
                credit_card: '<span class="badge-paymethod" style="border-color:#a855f7; color:#c084fc;">💳 บัตรเครดิต</span>',
                truemoney: '<span class="badge-paymethod" style="border-color:#f97316; color:#fb923c;">🟠 TrueMoney</span>',
                paypal: '<span class="badge-paymethod" style="border-color:#0284c7; color:#38bdf8;">🌐 PayPal</span>'
            };

            tbody.innerHTML = orders.map(o => {
                const totalDia = (parseInt(o.diamond_amount) + parseInt(o.bonus_diamonds || 0));
                const bonusText = o.bonus_diamonds > 0 ? ` <span style="color:#ffd700; font-size:11px;">(+โบนัส ${parseInt(o.bonus_diamonds).toLocaleString()})</span>` : '';
                const statusBadge = o.status === 'PAID'
                    ? '<span class="badge-status badge-paid">✓ สำเร็จ (PAID)</span>'
                    : '<span class="badge-status badge-pending">⏳ รอดำเนินการ</span>';

                const actionBtn = o.status === 'PAID'
                    ? '<span style="color:#10b981; font-size:11px; font-weight:700;">✓ เติมแล้ว</span>'
                    : `<button type="button" class="btn-action-primary" style="padding:4px 10px; font-size:11px; background:linear-gradient(135deg, #10b981, #059669); color:#fff; border-radius:6px; cursor:pointer;" onclick="approveOrderAction('${o.order_no}')">✅ อนุมัติ &amp; เติมเพชร</button>`;

                return `
                    <tr>
                        <td><strong style="color:#00e5ff;">${o.order_no}</strong></td>
                        <td>${o.username}</td>
                        <td>
                            <strong>${o.package_name}</strong>
                        </td>
                        <td><strong style="color:#38bdf8;">${totalDia.toLocaleString()} 💎</strong>${bonusText}</td>
                        <td><strong style="color:#34d399;">฿${parseFloat(o.amount_thb).toFixed(2)}</strong></td>
                        <td>${methodBadges[o.payment_method] || o.payment_method}</td>
                        <td>${statusBadge}</td>
                        <td style="font-family:monospace; color:#94a3b8;">${o.transaction_ref || '-'}</td>
                        <td style="font-size:11.5px; color:#94a3b8;">${o.created_at}</td>
                        <td>${actionBtn}</td>
                    </tr>
                `;
            }).join('');
        }

        async function approveOrderAction(orderNo) {
            if (!confirm(`คุณต้องการอนุมัติตัดยอดเงินและเติมเพชรให้บิล ${orderNo} ทันทีหรือไม่?`)) return;
            try {
                const res = await fetch('admin_dashboard.php?api=1&action=approve_order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ order_no: orderNo })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    showDashPopup('อนุมัติสำเร็จ!', res.message, '✅');
                    loadOrdersList();
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res?.message || ''));
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อ: ' + err.message);
            }
        }

        // Save WebView Domain
        async function saveWebviewDomainAction() {
            const domain = document.getElementById('setting-webview-domain')?.value.trim();
            if (!domain) {
                alert('กรุณากรอกโดเมนที่ถูกต้อง');
                return;
            }

            try {
                const res = await fetch('admin_dashboard.php?api=1&action=save_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ webview_domain: domain })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    document.getElementById('stat-webview-domain').innerText = domain;
                    showDashPopup('บันทึกโดเมนสำเร็จ!', `อัปเดตโดเมนหลัก WebView เป็น: ${domain}`);
                } else {
                    alert('เกิดข้อผิดพลาดในการบันทึก');
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        // Toggle Payment Gateway
        async function toggleGateway(gateway, isEnabled) {
            const box = document.getElementById(`gw-box-${gateway}`);
            const statusEl = document.getElementById(`gw-status-${gateway}`);

            if (box) {
                if (isEnabled) box.classList.add('enabled');
                else box.classList.remove('enabled');
            }
            if (statusEl) {
                statusEl.innerText = isEnabled ? 'เปิดใช้งานอยู่' : 'ปิดใช้งาน';
            }

            const payload = {};
            payload[`payment_${gateway}_enabled`] = isEnabled ? 1 : 0;

            try {
                await fetch('admin_dashboard.php?api=1&action=save_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            } catch (e) {
                console.error('toggleGateway error:', e);
            }
        }

        // Submit Deploy Update
        async function submitDeployUpdateAction() {
            const btn = document.getElementById('btn-deploy-submit');
            const origText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '⏳ กำลัง Deploy เวอร์ชันใหม่...';

            const targetVer = document.getElementById('deploy-version-input')?.value.trim();
            const note = document.getElementById('deploy-note-input')?.value.trim();
            const forceClear = document.getElementById('deploy-force-cache')?.checked;

            try {
                const res = await fetch('admin_dashboard.php?api=1&action=deploy_update', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        target_version: targetVer,
                        release_note: note,
                        force_clear_cache: forceClear
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    document.getElementById('stat-app-version').innerText = 'v' + res.version;
                    showDashPopup('🚀 Deploy Update สำเร็จ!', res.message, '🎉');
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (res?.message || 'ไม่สามารถ Deploy ได้'));
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            } finally {
                btn.disabled = false;
                btn.innerHTML = origText;
            }
        }

        // Create Test Order
        async function submitCreateTestOrder() {
            const pkg = document.getElementById('modal-test-pkg')?.value;
            const user = document.getElementById('modal-test-user')?.value.trim();
            const method = document.getElementById('modal-test-method')?.value;

            try {
                const res = await fetch('admin_dashboard.php?api=1&action=create_test_order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ package: pkg, username: user, payment_method: method })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    closeTestOrderModal();
                    await loadOrdersList();
                    showDashPopup('สร้างบิลสำเร็จ!', res.message, '🧾');
                } else {
                    alert('เกิดข้อผิดพลาด');
                }
            } catch (e) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        // -------------------------------------------------------------
        // PromptPay Functions & Live EMVCo QR Generator
        // -------------------------------------------------------------
        function generatePromptPayPayload(target, amount = null) {
            target = String(target || '').replace(/[^0-9]/g, '');
            if (!target) return '';
            let targetType = '01'; // 01 for mobile, 02 for national ID
            let formattedTarget = '';
            if (target.length >= 13) {
                targetType = '02';
                formattedTarget = target.substring(0, 13);
            } else {
                formattedTarget = '0066' + target.replace(/^0/, '');
            }
            const tag29 = '0016A000000677010111' + targetType + String(formattedTarget.length).padStart(2, '0') + formattedTarget;
            let payload = [
                '000201',
                amount ? '010212' : '010211',
                '29' + String(tag29.length).padStart(2, '0') + tag29,
                '5802TH',
                '5303764'
            ];
            if (amount) {
                const amtStr = Number(amount).toFixed(2);
                payload.push('54' + String(amtStr.length).padStart(2, '0') + amtStr);
            }
            const raw = payload.join('') + '6304';
            let crc = 0xFFFF;
            for (let i = 0; i < raw.length; i++) {
                crc ^= raw.charCodeAt(i) << 8;
                for (let j = 0; j < 8; j++) {
                    crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
                }
            }
            const crcHex = (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
            return raw + crcHex;
        }

        function updatePromptPayQrPreview() {
            const idInput = document.getElementById('setting-promptpay-id');
            const nameInput = document.getElementById('setting-promptpay-name');
            const rawId = idInput?.value.trim() || '';
            const rawName = nameInput?.value.trim() || '';

            const nameLabel = document.getElementById('pp-preview-label-name');
            const idLabel = document.getElementById('pp-preview-label-id');
            const imgEl = document.getElementById('pp-preview-img');

            if (nameLabel) nameLabel.innerText = rawName ? `ชื่อบัญชี: ${rawName}` : 'ชื่อบัญชี: (ยังไม่ได้ระบุ)';
            if (idLabel) idLabel.innerText = rawId ? `พร้อมเพย์: ${rawId}` : 'ยังไม่ได้ระบุหมายเลขพร้อมเพย์';

            if (!imgEl) return;
            const cleanId = rawId.replace(/[^0-9]/g, '');
            if (cleanId.length >= 9) {
                const emvPayload = generatePromptPayPayload(cleanId, 10.00);
                imgEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(emvPayload)}&margin=4`;
            } else {
                imgEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent('https://promptpay.ready')}&margin=4`;
            }
        }

        function updateShopeePayQrPreview() {
            const idInput = document.getElementById('setting-shopeepay-id');
            const nameInput = document.getElementById('setting-shopeepay-name');
            const qrUrlInput = document.getElementById('setting-shopeepay-qr-url');
            const rawId = idInput?.value.trim() || '';
            const rawName = nameInput?.value.trim() || '';
            const rawQr = qrUrlInput?.value.trim() || '';

            const nameLabel = document.getElementById('sp-preview-label-name');
            const idLabel = document.getElementById('sp-preview-label-id');
            const imgEl = document.getElementById('sp-preview-img');

            if (nameLabel) nameLabel.innerText = rawName ? `ชื่อบัญชี: ${rawName}` : 'ชื่อบัญชี: (ยังไม่ได้ระบุ)';
            if (idLabel) idLabel.innerText = rawId ? `Shopee ID: ${rawId}` : 'ยังไม่ได้ระบุ Shopee ID';

            if (!imgEl) return;
            if (rawQr) {
                imgEl.src = rawQr;
            } else if (rawId) {
                const qrTarget = `https://shopee.co.th/pay?merchant_id=${encodeURIComponent(rawId)}`;
                imgEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrTarget)}&margin=4`;
            } else {
                imgEl.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent('https://shopee.co.th/')}&margin=4`;
            }
        }

        async function saveShopeePaySettingsAction() {
            const spId = document.getElementById('setting-shopeepay-id')?.value.trim() || '';
            const spName = document.getElementById('setting-shopeepay-name')?.value.trim() || '';
            const spQrUrl = document.getElementById('setting-shopeepay-qr-url')?.value.trim() || '';
            const statusEl = document.getElementById('shopeepay-save-status');

            try {
                if (statusEl) {
                    statusEl.style.color = '#ffd700';
                    statusEl.innerText = 'กำลังบันทึก...';
                }

                const res = await fetch('admin_dashboard.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'save_settings',
                        shopeepay_id: spId,
                        shopeepay_name: spName,
                        shopeepay_qr_url: spQrUrl
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    if (statusEl) {
                        statusEl.style.color = '#34d399';
                        statusEl.innerText = '✅ บันทึก ShopeePay สำเร็จ!';
                        setTimeout(() => { if (statusEl) statusEl.innerText = ''; }, 3500);
                    }
                    showPopupModal('✅ สำเร็จ', 'บันทึกการตั้งค่า Shopee ID สำหรับรับเงินเรียบร้อยแล้ว');
                    updateShopeePayQrPreview();
                } else {
                    throw new Error(res?.message || 'ไม่สามารถบันทึกได้');
                }
            } catch(err) {
                if (statusEl) {
                    statusEl.style.color = '#ef4444';
                    statusEl.innerText = '❌ เกิดข้อผิดพลาด';
                }
                showPopupModal('❌ ผิดพลาด', err.message || 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        async function savePromptPaySettingsAction() {
            const ppId = document.getElementById('setting-promptpay-id')?.value.trim() || '';
            const ppName = document.getElementById('setting-promptpay-name')?.value.trim() || '';
            const ppBank = document.getElementById('setting-promptpay-bank')?.value.trim() || '';
            const statusEl = document.getElementById('promptpay-save-status');

            try {
                const res = await fetch('admin_dashboard.php?api=1&action=save_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        promptpay_id: ppId,
                        promptpay_name: ppName,
                        promptpay_bank: ppBank
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    if (statusEl) {
                        statusEl.style.display = 'inline';
                        setTimeout(() => { statusEl.style.display = 'none'; }, 4000);
                    }
                    updatePromptPayQrPreview(); updateShopeePayQrPreview();
                    showDashPopup('บันทึกสำเร็จ!', 'บันทึกข้อมูลบัญชีพร้อมเพย์สำหรับสร้าง QR Code เรียบร้อยแล้ว', '🇹🇭');
                } else {
                    alert('ไม่สามารถบันทึกได้: ' + (res?.message || ''));
                }
            } catch (e) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        // Save PayPal Gateway Settings
        async function savePayPalSettingsAction() {
            const email = document.getElementById('setting-paypal-email')?.value.trim() || '';
            const clientId = document.getElementById('setting-paypal-client-id')?.value.trim() || '';
            const currency = document.getElementById('setting-paypal-currency')?.value || 'THB';
            const sandbox = document.getElementById('setting-paypal-sandbox')?.checked ? 1 : 0;
            const statusEl = document.getElementById('paypal-save-status');

            try {
                const res = await fetch('admin_dashboard.php?api=1&action=save_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        paypal_email: email,
                        paypal_client_id: clientId,
                        paypal_currency: currency,
                        paypal_sandbox: sandbox
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    if (statusEl) {
                        statusEl.style.display = 'inline';
                        setTimeout(() => { statusEl.style.display = 'none'; }, 4000);
                    }
                    showDashPopup('บันทึกสำเร็จ!', 'บันทึกข้อมูลบัญชีรับเงิน PayPal Global เรียบร้อยแล้ว (เงินจะเข้าบัญชี PayPal นี้โดยตรง)', '🌐');
                } else {
                    alert('ไม่สามารถบันทึกได้: ' + (res?.message || ''));
                }
            } catch (e) {
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์');
            }
        }

        // -------------------------------------------------------------
        // App Icon Upload & Management Functions
        // -------------------------------------------------------------
        var _selectedIconData = null;

        function handleIconFileSelect(file) {
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function(e) {
                var img = new Image();
                img.onload = function() {
                    var canvas = document.getElementById('icon-canvas-processor');
                    if (!canvas) {
                        canvas = document.createElement('canvas');
                        canvas.id = 'icon-canvas-processor';
                        canvas.width = 1024;
                        canvas.height = 1024;
                        document.body.appendChild(canvas);
                    }
                    var ctx = canvas.getContext('2d');
                    ctx.fillStyle = '#f1fbfd';
                    ctx.fillRect(0, 0, 1024, 1024);

                    // Draw centered square crop/fit into 1024x1024 (opaque RGB for iOS AppIcon compliance)
                    var minDim = Math.min(img.width, img.height);
                    var sx = (img.width - minDim) / 2;
                    var sy = (img.height - minDim) / 2;
                    ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, 1024, 1024);
                    _selectedIconData = canvas.toDataURL('image/png', 0.98);

                    // Update UI preview
                    var prevImg = document.getElementById('icon-preview-display');
                    if (prevImg) prevImg.src = _selectedIconData;

                    var nameEl = document.getElementById('icon-file-name');
                    if (nameEl) nameEl.innerText = file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
                    var infoEl = document.getElementById('icon-select-info');
                    if (infoEl) infoEl.style.display = 'flex';

                    var statusEl = document.getElementById('icon-upload-status');
                    if (statusEl) {
                        statusEl.style.color = '#38bdf8';
                        statusEl.innerText = 'รูปภาพพร้อมบันทึก (แปลงเป็น 1024x1024 เรียบร้อยแล้ว)';
                    }
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }

        async function submitAppIconUpload() {
            var btn = document.getElementById('btn-save-app-icon');
            var statusEl = document.getElementById('icon-upload-status');
            if (!_selectedIconData) {
                alert('กรุณาเลือกหรือลากไฟล์รูปภาพไอคอนก่อนกดบันทึก');
                return;
            }

            try {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '⏳ กำลังประมวลผลและบันทึกไฟล์...';
                }
                if (statusEl) {
                    statusEl.style.color = '#38bdf8';
                    statusEl.innerText = 'กำลังอัปโหลดและเขียนไฟล์ลงโปรเจกต์ iOS & Web...';
                }

                var payload = {
                    api: 1,
                    action: 'upload_app_icon',
                    image_data: _selectedIconData
                };

                var res = await fetch('admin_dashboard.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(function(r) { return r.json(); });

                if (res && res.status === 'success') {
                    if (statusEl) {
                        statusEl.style.color = '#34d399';
                        statusEl.innerText = '✅ ' + res.message;
                    }
                    var prevImg = document.getElementById('icon-preview-display');
                    if (prevImg) prevImg.src = res.icon_url;
                    var dlBtn = document.getElementById('btn-download-icon');
                    if (dlBtn) dlBtn.href = res.icon_url;
                    var zipBtn = document.getElementById('btn-download-ios-zip');
                    if (zipBtn && res.ios_zip_url) zipBtn.href = res.ios_zip_url;

                    showDashPopup('🎉 บันทึกไอคอนและอัปเดต ios.zip สำเร็จ!', res.message + '\n\nสามารถกดปุ่ม "📦 ดาวน์โหลด ios.zip" เพื่อนำไปเปิดใน Xcode และกด Run ลงเครื่อง iPhone ได้ทันที', '📱');
                } else {
                    var errMsg = res ? res.message : 'Unknown error';
                    if (statusEl) {
                        statusEl.style.color = '#f87171';
                        statusEl.innerText = '❌ เกิดข้อผิดพลาด: ' + errMsg;
                    }
                    alert('เกิดข้อผิดพลาด: ' + errMsg);
                }
            } catch (err) {
                if (statusEl) {
                    statusEl.style.color = '#f87171';
                    statusEl.innerText = '❌ Network Error: ' + err.message;
                }
                alert('เกิดข้อผิดพลาดในการเชื่อมต่อ: ' + err.message);
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<span>💾 บันทึกและแทนที่ไอคอน iOS &amp; Web ทันที</span>';
                }
            }
        }

        // Setup Drag & Drop
        (function setupIconDropzone() {
            setTimeout(function() {
                var dz = document.getElementById('icon-dropzone');
                if (!dz) return;
                dz.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    dz.style.background = 'rgba(0, 229, 255, 0.15)';
                    dz.style.borderColor = '#00e5ff';
                });
                dz.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    dz.style.background = 'rgba(0, 229, 255, 0.03)';
                    dz.style.borderColor = 'rgba(0, 229, 255, 0.4)';
                });
                dz.addEventListener('drop', function(e) {
                    e.preventDefault();
                    dz.style.background = 'rgba(0, 229, 255, 0.03)';
                    dz.style.borderColor = 'rgba(0, 229, 255, 0.4)';
                    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
                        handleIconFileSelect(e.dataTransfer.files[0]);
                    }
                });
            }, 300);
        })();

        // Card Reveal Sound Studio (Admin Dashboard)
        let _dashCardSimTimers = [];
        let _dashCardEventsCache = {};

        async function loadDashCardRevealConfig() {
            try {
                const res = await fetch('api/audio_settings.php?action=get_config&t=' + Date.now()).then(r => r.json());
                if (res && res.status === 'success' && res.events) {
                    _dashCardEventsCache = res.events;
                    const ev = res.events['card_reveal'] || {};
                    const preset = ev.preset || 'zap_classic';
                    const intSec = (ev.interval_sec !== undefined && !isNaN(Number(ev.interval_sec))) ? Number(ev.interval_sec) : 0.5;
                    const volPct = Math.round(((ev.volume !== undefined ? Number(ev.volume) : 0.95) || 0.95) * 100);
                    const curFile = (Array.isArray(ev.files) && ev.files.length > 0) ? ev.files[0] : 'card_zap.mp3';

                    const pEl = document.getElementById('dash-card-preset');
                    const iEl = document.getElementById('dash-card-interval');
                    const iLbl = document.getElementById('dash-card-interval-lbl');
                    const vEl = document.getElementById('dash-card-vol');
                    const vLbl = document.getElementById('dash-card-vol-lbl');
                    const eEl = document.getElementById('dash-card-enabled');
                    const fEl = document.getElementById('dash-card-cur-file');

                    if (pEl) pEl.value = preset;
                    if (iEl) iEl.value = intSec;
                    if (iLbl) iLbl.innerText = intSec.toFixed(2) + ' วินาที / ใบ';
                    if (vEl) vEl.value = volPct;
                    if (vLbl) vLbl.innerText = volPct + '%';
                    if (eEl) eEl.checked = (ev.enabled !== false);
                    if (fEl) fEl.innerText = curFile;
                }
            } catch (e) {}
        }

        function setDashCardInterval(sec) {
            const iEl = document.getElementById('dash-card-interval');
            const iLbl = document.getElementById('dash-card-interval-lbl');
            if (iEl) iEl.value = sec;
            if (iLbl) iLbl.innerText = Number(sec).toFixed(2) + ' วินาที / ใบ';
        }

        function onDashCardPresetChange(preset) {
            const map = {
                'zap_classic': 'card_zap.mp3',
                'zap_magic': 'card_zap_magic.mp3',
                'card_whip': 'card_whip.mp3',
                'coin_ping': 'card_crystal.mp3'
            };
            const fEl = document.getElementById('dash-card-cur-file');
            if (fEl && map[preset]) fEl.innerText = map[preset];
            testDashCardRevealSeq(1);
        }

        function testDashCardRevealSeq(count = 5) {
            _dashCardSimTimers.forEach(t => clearTimeout(t));
            _dashCardSimTimers = [];

            const preset = document.getElementById('dash-card-preset')?.value || 'zap_classic';
            const intSec = Math.max(0.1, Math.min(3.0, Number(document.getElementById('dash-card-interval')?.value || 0.5)));
            const vol = Math.max(0.05, Math.min(1.0, Number(document.getElementById('dash-card-vol')?.value || 95) / 100));
            const map = {
                'zap_classic': 'card_zap.mp3',
                'zap_magic': 'card_zap_magic.mp3',
                'card_whip': 'card_whip.mp3',
                'coin_ping': 'card_crystal.mp3'
            };
            const ev = _dashCardEventsCache['card_reveal'] || {};
            const customFile = (Array.isArray(ev.files) && ev.files.length > 0) ? ev.files[0] : 'card_zap.mp3';
            const targetFile = map[preset] || customFile;

            const slots = document.querySelectorAll('#dash-card-sim-row .dash-sim-slot');
            slots.forEach(s => {
                s.style.background = '#1e293b';
                s.style.borderColor = '#475569';
                s.style.color = '#94a3b8';
                s.style.transform = 'scale(1)';
            });

            for (let i = 0; i < count; i++) {
                const tId = setTimeout(() => {
                    const isRare = (i === 2 && count >= 5);
                    try {
                        const a = new Audio('assets/audio/th/' + targetFile + '?t=' + Date.now());
                        a.volume = vol;
                        a.play().catch(() => {});
                        if (isRare) {
                            const r = new Audio('assets/audio/th/card_zap_rare.mp3?t=' + Date.now());
                            r.volume = vol;
                            r.play().catch(() => {});
                        }
                    } catch (e) {}

                    if (slots[i]) {
                        slots[i].style.background = isRare ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#0ea5e9,#0284c7)';
                        slots[i].style.borderColor = '#fde047';
                        slots[i].style.color = isRare ? '#000' : '#fff';
                        slots[i].style.transform = 'scale(1.08)';
                        setTimeout(() => { if (slots[i]) slots[i].style.transform = 'scale(1)'; }, 220);
                    }
                }, Math.round(i * intSec * 1000));
                _dashCardSimTimers.push(tId);
            }
        }

        async function saveDashCardRevealConfig() {
            const preset = document.getElementById('dash-card-preset')?.value || 'zap_classic';
            const intSec = Math.max(0.1, Math.min(3.0, Number(document.getElementById('dash-card-interval')?.value || 0.5)));
            const vol = Math.max(0.05, Math.min(1.0, Number(document.getElementById('dash-card-vol')?.value || 95) / 100));
            const enabled = Boolean(document.getElementById('dash-card-enabled')?.checked);

            try {
                const res = await fetch('api/audio_settings.php?action=save_card_reveal_config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        preset: preset,
                        interval_sec: intSec,
                        volume: vol,
                        enabled: enabled,
                        rare_enabled: enabled
                    })
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    if (res.events) _dashCardEventsCache = res.events;
                    showDashPopup('🎉 บันทึกตั้งค่าเสียงเปิดการ์ดสำเร็จ!', res.message, '⚡');
                } else {
                    alert((res && res.message) || 'บันทึกไม่สำเร็จ');
                }
            } catch (e) {
                alert('เกิดข้อผิดพลาดในการบันทึก');
            }
        }

        async function uploadDashCardSoundFile(inputEl) {
            if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
            const fd = new FormData();
            fd.append('audio_file', inputEl.files[0]);
            fd.append('event_key', 'card_reveal');
            fd.append('event_name', 'เสียงเปิดการ์ด / สุ่มเต๋าทีละใบ ("แซ๊บ!")');
            fd.append('event_type', 'sfx');
            fd.append('mode', 'replace');

            try {
                const res = await fetch('api/audio_settings.php?action=upload_audio', {
                    method: 'POST',
                    body: fd
                }).then(r => r.json());

                if (res && res.status === 'success') {
                    await loadDashCardRevealConfig();
                    testDashCardRevealSeq(1);
                    showDashPopup('🎵 อัปโหลดเสียงเปิดการ์ดสำเร็จ!', res.message, '🔊');
                } else {
                    alert((res && res.message) || 'อัปโหลดไม่สำเร็จ');
                }
            } catch (e) {
                alert('เกิดข้อผิดพลาดในการอัปโหลด');
            } finally {
                inputEl.value = '';
            }
        }

        // Initial Load on Ready
        document.addEventListener('DOMContentLoaded', () => {
            loadOrdersList();
            loadDashCardRevealConfig();
            updatePromptPayQrPreview(); updateShopeePayQrPreview();
            if (window.location.hash) {
                const targetTab = window.location.hash.replace('#', '');
                if (document.getElementById(targetTab)) {
                    switchDashboardTab(targetTab);
                }
            } else if (localStorage.getItem('admin_default_tab')) {
                const savedTab = localStorage.getItem('admin_default_tab');
                localStorage.removeItem('admin_default_tab');
                if (document.getElementById(savedTab)) {
                    switchDashboardTab(savedTab);
                }
            }
        });
    </script>
</body>
</html>
