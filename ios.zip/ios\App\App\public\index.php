<?php
declare(strict_types=1);

/**
 * index.php
 * Snake & Ladder 3D - Main Dynamic Entry Point, OAuth Instant Callback Router & Realtime OTA Cache Buster
 */

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Expires: 0');

// -------------------------------------------------------------------------
// 0. ดักจับ OAuth Callback (?code=...) บนฝั่ง Server ทันทีโดยไม่ต้องรอโหลดหน้าเว็บ 3D
// ป้องกันปัญหาเข้าสู่ระบบ Google / LINE รอบแรกไม่ผ่านหรือพารามิเตอร์หลุดระหว่างโหลดสคริปต์
// -------------------------------------------------------------------------
if (!empty($_GET['code']) && empty($_GET['token']) && empty($_GET['auth_token'])) {
    $code = (string)$_GET['code'];
    $state = (string)($_GET['state'] ?? '');
    $scope = (string)($_GET['scope'] ?? '');

    $isGoogle = str_starts_with($state, 'google_')
        || str_contains($scope, 'googleapis')
        || str_contains($scope, 'email')
        || isset($_GET['authuser'])
        || isset($_GET['prompt'])
        || isset($_GET['hd']);

    $callbackAction = $isGoogle ? 'google_callback' : 'line_callback';
    $qs = http_build_query([
        'action' => $callbackAction,
        'code'   => $code,
        'state'  => $state
    ], '', '&', PHP_QUERY_RFC3986);

    header('Location: api/auth.php?' . $qs);
    exit;
}

header('Content-Type: text/html; charset=utf-8');

require_once __DIR__ . '/config/database.php';

$otaJsonBuster = 0;
$otaJsonVersion = '1.0.0';
$otaJsonFile = __DIR__ . '/config/ota_version.json';
if (file_exists($otaJsonFile)) {
    $rawOta = @file_get_contents($otaJsonFile);
    if ($rawOta) {
        $parsedOta = json_decode($rawOta, true);
        if (is_array($parsedOta)) {
            if (!empty($parsedOta['cache_buster'])) {
                $otaJsonBuster = (int)$parsedOta['cache_buster'];
            }
            if (!empty($parsedOta['version'])) {
                $otaJsonVersion = (string)$parsedOta['version'];
            }
        }
    }
}

$defaultCacheBuster = $otaJsonBuster > 0 ? $otaJsonBuster : time();
$appVersion = $otaJsonVersion;

try {
    $db = getDbConnection();
    $res = $db->query("
        SELECT setting_key, setting_value 
        FROM system_settings 
        WHERE setting_key IN ('MOBILE_APP_CACHE_BUSTER', 'MOBILE_APP_VERSION', 'MOBILE_APP_MAINTENANCE', 'MOBILE_APP_MAINTENANCE_MSG')
    ");

    $settings = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }

    $dbCacheBuster = !empty($settings['MOBILE_APP_CACHE_BUSTER']) ? (int)$settings['MOBILE_APP_CACHE_BUSTER'] : 0;
    if ($dbCacheBuster >= $otaJsonBuster && $dbCacheBuster > 0) {
        $defaultCacheBuster = $dbCacheBuster;
        if (!empty($settings['MOBILE_APP_VERSION'])) {
            $appVersion = (string)$settings['MOBILE_APP_VERSION'];
        }
    } elseif ($otaJsonBuster > $dbCacheBuster) {
        $defaultCacheBuster = $otaJsonBuster;
        $busterStr = (string)$otaJsonBuster;
        $verStr = $otaJsonVersion;
        @$db->query("UPDATE system_settings SET setting_value = '" . $db->real_escape_string($busterStr) . "' WHERE setting_key = 'MOBILE_APP_CACHE_BUSTER'");
        @$db->query("UPDATE system_settings SET setting_value = '" . $db->real_escape_string($verStr) . "' WHERE setting_key = 'MOBILE_APP_VERSION'");
    }

    if (!empty($settings['MOBILE_APP_MAINTENANCE']) && ($settings['MOBILE_APP_MAINTENANCE'] === '1' || $settings['MOBILE_APP_MAINTENANCE'] === 'true')) {
        $msg = isset($settings['MOBILE_APP_MAINTENANCE_MSG']) ? $settings['MOBILE_APP_MAINTENANCE_MSG'] : 'ระบบกำลังปรับปรุงชั่วคราว โปรดกลับมาใหม่อีกครั้ง';
        echo '<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>ระบบกำลังปรับปรุง</title><style>body{background:#070b14;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;}.box{background:rgba(15,23,42,0.9);border:1.5px solid #00e5ff;padding:36px;border-radius:20px;max-width:480px;box-shadow:0 0 30px rgba(0,229,255,0.3);}</style></head><body><div class="box"><div style="font-size:56px;margin-bottom:12px;">🚧</div><h2 style="color:#00e5ff;margin-bottom:12px;">เซิร์ฟเวอร์กำลังปรับปรุงชั่วคราว</h2><p style="color:#94a3b8;line-height:1.6;">' . htmlspecialchars((string)$msg) . '</p><button onclick="location.reload()" style="margin-top:20px;background:#00e5ff;color:#000;font-weight:700;border:none;padding:12px 24px;border-radius:10px;cursor:pointer;">🔄 ลองใหม่อีกครั้ง</button></div></body></html>';
        exit;
    }
} catch (\Throwable $e) {
}

$indexPath = __DIR__ . '/index.html';
if (!file_exists($indexPath)) {
    die("Error: index.html not found.");
}

$html = file_get_contents($indexPath);
if ($html === false) {
    die("Error: Unable to read index.html.");
}

$replacedCss = preg_replace_callback(
    '/(<link[^>]+href=["\'])(css\/[a-zA-Z0-9_\-\.]+\.css)(?:\?v=([^"\']*))?(["\'])/i',
    function($matches) use ($defaultCacheBuster) {
        $fileMtime = (int)@filemtime(__DIR__ . '/' . $matches[2]);
        $inlineVer = (isset($matches[3]) && is_numeric($matches[3])) ? (int)$matches[3] : 0;
        $ver = max($defaultCacheBuster, $fileMtime, $inlineVer);
        return $matches[1] . $matches[2] . '?v=' . $ver . $matches[4];
    },
    $html
);
if ($replacedCss !== null) $html = $replacedCss;

$replacedJs = preg_replace_callback(
    '/(<script[^>]+src=["\'])(js\/[a-zA-Z0-9_\-\.]+\.js)(?:\?v=([^"\']*))?(["\'])/i',
    function($matches) use ($defaultCacheBuster) {
        $fileMtime = (int)@filemtime(__DIR__ . '/' . $matches[2]);
        $inlineVer = (isset($matches[3]) && is_numeric($matches[3])) ? (int)$matches[3] : 0;
        $ver = max($defaultCacheBuster, $fileMtime, $inlineVer);
        return $matches[1] . $matches[2] . '?v=' . $ver . $matches[4];
    },
    $html
);
if ($replacedJs !== null) $html = $replacedJs;

$replacedIcons = preg_replace_callback(
    '/(<link[^>]+href=["\'])((?:apple-touch-icon[a-zA-Z0-9_\-]*|favicon)\.png|manifest\.json)(?:\?v=([^"\']*))?(["\'])/i',
    function($matches) use ($defaultCacheBuster) {
        $fileMtime = (int)@filemtime(__DIR__ . '/' . $matches[2]);
        $inlineVer = (isset($matches[3]) && is_numeric($matches[3])) ? (int)$matches[3] : 0;
        $ver = max($defaultCacheBuster, $fileMtime, $inlineVer);
        return $matches[1] . $matches[2] . '?v=' . $ver . $matches[4];
    },
    $html
);
if ($replacedIcons !== null) $html = $replacedIcons;

if (strpos($html, '__GAME_OTA_VERSION__') !== false) {
    $r1 = preg_replace(
        '/window\.__GAME_OTA_VERSION__\s*=\s*["\'][^"\']*["\'];/i',
        'window.__GAME_OTA_VERSION__ = "' . $defaultCacheBuster . '";',
        $html
    );
    if ($r1 !== null) $html = $r1;

    $r2 = preg_replace(
        '/<meta\s+name=["\']game-ota-version["\']\s+content=["\'][^"\']*["\']>/i',
        '<meta name="game-ota-version" content="' . $defaultCacheBuster . '">',
        $html
    );
    if ($r2 !== null) $html = $r2;
} else {
    $versionTag = "\n    <meta name=\"game-ota-version\" content=\"{$defaultCacheBuster}\">\n    <script id=\"ota-version-tag\">window.__GAME_OTA_VERSION__ = \"{$defaultCacheBuster}\";</script>\n";
    $html = str_replace('<head>', '<head>' . $versionTag, $html);
}

// -------------------------------------------------------------------------
// 1. หากกลับมาจาก OAuth Redirect (?token=...&google_user=...) ให้ฝังข้อมูลลง localStorage
// ทันทีตั้งแต่ใน <head> ก่อนที่สคริปต์ใดๆ จะเริ่มทำงาน เพื่อให้เข้าเกมได้ทันทีตั้งแต่รอบแรก 100%
// -------------------------------------------------------------------------
$incomingToken = trim((string)($_GET['token'] ?? ($_GET['auth_token'] ?? '')));
if ($incomingToken !== '') {
    $incomingUserB64 = trim((string)($_GET['google_user'] ?? ''));
    $incomingProvider = strtolower(trim((string)($_GET['auth_provider'] ?? 'google')));
    $decodedUser = null;
    if ($incomingUserB64 !== '') {
        $rawJson = @base64_decode($incomingUserB64, true);
        if ($rawJson) {
            $parsed = json_decode($rawJson, true);
            if (is_array($parsed)) {
                $decodedUser = $parsed;
            }
        }
    }
    if (!$decodedUser) {
        $decodedUser = [
            'username'   => (string)($_GET['name'] ?? 'Google Player'),
            'name'       => (string)($_GET['name'] ?? 'Google Player'),
            'avatar_url' => (string)($_GET['picture'] ?? 'avatars/google_avatar.png'),
            'picture'    => (string)($_GET['picture'] ?? 'avatars/google_avatar.png'),
            'email'      => (string)($_GET['email'] ?? ''),
            'sub'        => (string)($_GET['sub'] ?? ''),
            'provider'   => $incomingProvider
        ];
    }

    $jsToken = json_encode($incomingToken, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $jsUser = json_encode($decodedUser, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $jsProvider = json_encode($incomingProvider, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $jsCacheVer = json_encode((string)$defaultCacheBuster, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $bootstrapScript = "\n    <script id=\"oauth-instant-bootstrap\">\n"
        . "    (function() {\n"
        . "        try {\n"
        . "            var tok = {$jsToken};\n"
        . "            var usr = {$jsUser};\n"
        . "            var prv = {$jsProvider};\n"
        . "            var ver = {$jsCacheVer};\n"
        . "            localStorage.setItem('snake_auth_token', tok);\n"
        . "            localStorage.setItem('game_session_token', tok);\n"
        . "            localStorage.setItem('snake_user_data', JSON.stringify(usr));\n"
        . "            localStorage.setItem('snake_auth_provider', prv);\n"
        . "            localStorage.setItem('snake_client_cache_version', ver);\n"
        . "            localStorage.setItem('snake_client_installed_version', ver);\n"
        . "            sessionStorage.setItem('snake_ota_applied_ver', ver);\n"
        . "            if (prv === 'google') {\n"
        . "                localStorage.setItem('snake_google_profile', JSON.stringify({\n"
        . "                    name: usr.name || usr.username || '',\n"
        . "                    picture: usr.picture || usr.avatar_url || '',\n"
        . "                    email: usr.email || '',\n"
        . "                    sub: usr.sub || usr.google_id || ''\n"
        . "                }));\n"
        . "            } else if (prv === 'line') {\n"
        . "                localStorage.setItem('snake_line_display_name', usr.name || usr.username || '');\n"
        . "            }\n"
        . "            window.__OAUTH_INSTANT_TOKEN__ = tok;\n"
        . "            window.__OAUTH_INSTANT_USER__ = usr;\n"
        . "        } catch (e) {}\n"
        . "    })();\n"
        . "    </script>\n";

    $html = str_replace('<head>', '<head>' . $bootstrapScript, $html);
}

echo $html;
