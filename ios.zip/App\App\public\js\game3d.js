/**
 * game3d.js - Ultra Full 3D WebGL Engine for Snake & Ladder 3D Game (Three.js)
 * Features:
 *  - Thai Province Names on every board tile (shuffled randomly)
 *  - Special Tiles: Chance (ช่องดวง), Tax (ช่องภาษี), Lucky Gamble (ช่องเสี่ยงโชค ชิงเพชร & ทองคำ)
 *  - 4 Dynamic 3D Environments (Cyber Neon, Golden Temple, Lava Volcano, Crystal Ice)
 *  - 3D Tumbling Physics-style Dice with procedural pip textures
 *  - 3D Animated Ladders, Realistic 3D Snakes with glowing eyes, 3D Chance Chests, 3D Prison Jail, 3D Tax Signs, 3D Lucky Roulette
 *  - Skill Calculations: Dice Control accuracy gauge, Knockback / Pull Back 5 or 8 tiles when landing on same square
 *  - Doubles Rule: 3 consecutive doubles = Sent to Jail for 2 turns
 *  - Jail Escape: Roll doubles OR pay Gold/Diamond
 *  - Victory condition: Tile 100 = Cinematic victory, confetti, ranking update to backend
 */

const THAI_PROVINCES = [
    'กรุงเทพฯ', 'เชียงใหม่', 'ภูเก็ต', 'ขอนแก่น', 'ชลบุรี', 'นครราชสีมา', 'สงขลา', 'เชียงราย',
    'สุราษฎร์ธานี', 'อยุธยา', 'นนทบุรี', 'ปทุมธานี', 'สมุทรปราการ', 'นครปฐม', 'ระยอง', 'จันทบุรี',
    'ตราด', 'กระบี่', 'พังงา', 'ตรัง', 'สตูล', 'นครศรีธรรมราช', 'พัทลุง', 'ปัตตานี', 'ยะลา',
    'นราธิวาส', 'ชุมพร', 'ระนอง', 'ประจวบฯ', 'เพชรบุรี', 'ราชบุรี', 'กาญจนบุรี', 'สุพรรณบุรี',
    'สมุทรสาคร', 'สมุทรสงคราม', 'นครนายก', 'ปราจีนบุรี', 'สระแก้ว', 'ฉะเชิงเทรา', 'สระบุรี',
    'ลพบุรี', 'อ่างทอง', 'สิงห์บุรี', 'ชัยนาท', 'อุทัยธานี', 'นครสวรรค์', 'พิจิตร', 'พิษณุโลก',
    'กำแพงเพชร', 'เพชรบูรณ์', 'สุโขทัย', 'ตาก', 'อุตรดิตถ์', 'แพร่', 'น่าน', 'พะเยา', 'ลำปาง',
    'ลำพูน', 'แม่ฮ่องสอน', 'อุดรธานี', 'หนองคาย', 'บึงกาฬ', 'เลย', 'หนองบัวลำภู', 'สกลนคร',
    'นครพนม', 'มุกดาหาร', 'กาฬสินธุ์', 'มหาสารคาม', 'ร้อยเอ็ด', 'ยโสธร', 'อำนาจเจริญ',
    'อุบลราชธานี', 'ศรีสะเกษ', 'สุรินทร์', 'บุรีรัมย์', 'ชัยภูมิ',
    // Landmarks and famous tourist cities
    'พัทยา', 'เกาะสมุย', 'เขาใหญ่', 'หัวหิน', 'เกาะช้าง', 'เกาะเสม็ด', 'เกาะพีพี', 'เขาค้อ',
    'ภูกระดึง', 'ปาย', 'ชะอำ', 'บางแสน', 'เกาะพะงัน', 'เกาะล้าน', 'หาดใหญ่', 'เบตง',
    'ภูทับเบิก', 'ดอยอินทนนท์', 'ดอยสุเทพ', 'ภูชี้ฟ้า', 'อัมพวา', 'สยามสแควร์', 'เยาวราช', 'เส้นชัยสยาม'
];

class SnakeGame3D {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.clock = new THREE.Clock();

        // 3D Groups
        this.boardGroup = new THREE.Group();
        this.citiesGroup = new THREE.Group();
        this.pawnsGroup = new THREE.Group();
        this.diceGroup = new THREE.Group();
        this.effectsGroup = new THREE.Group();
        this.environmentGroup = new THREE.Group();

        // City / Landmark & Match Economy State (กติกาเกมเศรษฐี + บันไดงู 3D)
        this.cityStates = {};
        this.cityMeshes = {};
        this.isWaitingForCityAction = false;
        this.activeCityActionResolver = null;
        this.cityActionAutoChoice = null;
        this.cityActionInterval = null;
        this.matchConfig = {
            room_tier: '2M',
            entry_fee_gold: 2000,
            start_match_gold: 2000000,
            tax_amount: 50000,
            tax_percent: 20,
            city_base_cost: 120000,
            landmark_cost: 320000,
            toll_percent: 85,
            buyout_percent: 160
        };

        // Board & Coordinates
        this.boardTheme = localStorage.getItem('snake_board_theme') || 'ancient';
        this.boardLayout = localStorage.getItem('snake_board_layout') || 'square'; // 'square' | 'spiral' | 'hexagon'
        this.tiles = []; // 1..100 positions
        this.tileMeshes = [];
        this.boardSize = 10;
        this.tileSize = 6.2;
        this.tileGap = 0.4;

        // 3D Dice meshes
        this.diceMesh1 = null;
        this.diceMesh2 = null;
        this.diceMaterials = [];
        this.isDiceTumbling = false;

        // Game rules state
        this.players = [];
        this.currentTurnIndex = 0;
        this.isRolling = false;
        this.consecutiveDoubles = 0;
        this.isGameOver = false;
        this.isMatchActive = false;

        // Auto Mode state & 7-second turn timer
        this.isAutoMode = false;
        this.turnSecondsLeft = 7;
        this.turnCountdownInterval = null;
        this.autoTurnTimeout = null;

        // Province assignments
        this.tileProvinces = {};

        // Board Links (No overlapping tiles)
        this.ladders = {
            4: 14, 9: 31, 22: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91
        };
        this.snakes = {
            17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78
        };
        this.snakeTailToHead = {};
        for (const [h, t] of Object.entries(this.snakes)) {
            this.snakeTailToHead[Number(t)] = Number(h);
        }
        this.ladderObjects = {};
        this.snakeObjects = {};
        this.activeSpeechBubbles = new Map();

        this.chanceTiles = [11, 45, 76];     // ช่องดวง (Chance)
        this.taxTiles = [20, 52, 82];        // ช่องภาษี (Tax)
        this.gambleTiles = [15, 68, 88];     // ช่องเสี่ยงโชค (Lucky Gamble)
        this.destroyTiles = [26, 36, 90];    // 💥 ช่องสกิลลบเมืองคู่แข่ง (3 ช่อง กระจายห่างกันทั่วกระดาน)
        this.jailTile = 10;                  // เกาะร้าง (คุก)

        // Randomly shuffle Thai provinces across tiles
        this.initProvinces();

        // Theme specifications
        this.themes = {
            classic: {
                name: 'นีออนไซเบอร์ 3D (Cyber Neon)',
                bgColor: 0x070b14,
                fogColor: 0x070b14,
                tileEven: 0x111c30,
                tileOdd: 0x1a2a47,
                border: 0x00e5ff,
                ambient: 0x223a5e,
                light: 0x00e5ff,
                ladder: 0x00e5ff,
                snake: 0xff0055,
                particle: 0x00e5ff
            },
            ancient: {
                name: 'วิหารทองคำพญานาคราช (Golden Temple)',
                bgColor: 0x140e06,
                fogColor: 0x140e06,
                tileEven: 0x2e1f0a,
                tileOdd: 0x432d0f,
                border: 0xffd700,
                ambient: 0x5a4220,
                light: 0xffd700,
                ladder: 0xffd700,
                snake: 0x10b981,
                particle: 0xffea00
            },
            lava: {
                name: 'ภูเขาไฟลาวาเดือด (Lava Volcano)',
                bgColor: 0x140505,
                fogColor: 0x140505,
                tileEven: 0x2b0d0d,
                tileOdd: 0x3d1414,
                border: 0xff3d00,
                ambient: 0x451616,
                light: 0xff5722,
                ladder: 0xffab00,
                snake: 0x212121,
                particle: 0xff3d00
            },
            ice: {
                name: 'แดนน้ำแข็งคริสตัล (Crystal Ice)',
                bgColor: 0x06111a,
                fogColor: 0x06111a,
                tileEven: 0x0f2a3d,
                tileOdd: 0x163d59,
                border: 0x80d8ff,
                ambient: 0x1f4968,
                light: 0x40c4ff,
                ladder: 0x00b0ff,
                snake: 0x7c4dff,
                particle: 0x80d8ff
            }
        };

        this.initThree();
        this.generateDiceTextures();
        this.create3DDice();
        this.buildBoard();
        this.animate();
    }

    initThree() {
        const width = this.container.clientWidth || window.innerWidth;
        const height = this.container.clientHeight || window.innerHeight;

        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(this.themes[this.boardTheme].bgColor);
        this.scene.fog = new THREE.FogExp2(this.themes[this.boardTheme].fogColor, 0.007);

        // Camera
        this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
        this.camera.position.set(0, 51, 68);
        this.camera.lookAt(0, 0, 2.5);

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
        this.renderer.setSize(width, height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.container.appendChild(this.renderer.domElement);

        // OrbitControls
        if (window.THREE.OrbitControls) {
            this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
            this.controls.enableDamping = true;
            this.controls.dampingFactor = 0.05;
            this.controls.maxPolarAngle = Math.PI / 2.05;
            this.controls.minDistance = 20;
            this.controls.maxDistance = 200;
        }

        // Apply real-time camera fit based on viewport and board layout
        this.updateCameraFit(true);

        // Lighting
        this.ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
        this.scene.add(this.ambientLight);

        this.dirLight = new THREE.DirectionalLight(0xffffff, 1.3);
        this.dirLight.position.set(40, 90, 50);
        this.dirLight.castShadow = true;
        this.dirLight.shadow.mapSize.width = 2048;
        this.dirLight.shadow.mapSize.height = 2048;
        this.scene.add(this.dirLight);

        const initialLightColor = (this.themes[this.boardTheme] && this.themes[this.boardTheme].light) ? this.themes[this.boardTheme].light : 0xffd700;
        this.pointLight = new THREE.PointLight(initialLightColor, 2, 120);
        this.pointLight.position.set(0, 25, 0);
        this.scene.add(this.pointLight);

        if (this.boardTheme === 'ancient') {
            this.ambientLight.color.setHex(0xfff3db);
            this.ambientLight.intensity = 1.0;
            this.dirLight.color.setHex(0xfff0cc);
        }

        // Groups
        this.scene.add(this.environmentGroup);
        this.scene.add(this.boardGroup);
        this.scene.add(this.citiesGroup);
        this.scene.add(this.pawnsGroup);
        this.scene.add(this.diceGroup);
        this.scene.add(this.effectsGroup);

        window.addEventListener('resize', () => this.onWindowResize());
        window.addEventListener('orientationchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
            setTimeout(() => this.onWindowResize(), 300);
        });
        if (window.screen && window.screen.orientation) {
            try {
                window.screen.orientation.addEventListener('change', () => {
                    setTimeout(() => this.onWindowResize(), 100);
                    setTimeout(() => this.onWindowResize(), 300);
                });
            } catch(e) {}
        }
        document.addEventListener('fullscreenchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
        });
        document.addEventListener('webkitfullscreenchange', () => {
            setTimeout(() => this.onWindowResize(), 100);
        });
        window.addEventListener('beforeunload', () => {
            // ไม่บันทึกเพื่อป้องกันไม่ให้เกมเข้าเล่นเองอัตโนมัติเมื่อกดรีเฟรชหน้าเว็บ
        });
        window.addEventListener('pagehide', () => {
            // ไม่บันทึกเพื่อป้องกันไม่ให้เกมเข้าเล่นเองอัตโนมัติเมื่อกดรีเฟรชหน้าเว็บ
        });
    }

    onWindowResize() {
        this.updateCameraFit();
    }

    /**
     * คำนวณและปรับขนาดการเรนเดอร์ รวมถึงตำแหน่งกล้อง (Camera Position), 
     * ระดับการซูม (Field of View / FOV) และ Aspect Ratio แบบ Real-time
     * เพื่อให้กระดาน 3D (ทั้งหกเหลี่ยม สี่เหลี่ยม ก้นหอย) ขยับเข้ามาใกล้และขยายใหญ่
     * แสดงผลพอดีและเต็มหน้าจอแนวนอนในโหมดมือถือ ลดขอบดำซ้าย-ขวาและบน-ล่างให้เหลือเท่าที่จำเป็น
     */
    updateCameraFit(isInitial = false) {
        if (!this.camera || !this.renderer || !this.container) return;

        const width = this.container.clientWidth || window.innerWidth || 800;
        const height = this.container.clientHeight || window.innerHeight || 600;
        const aspect = width / height;

        // 1. อัปเดตขนาด Renderer และ Device Pixel Ratio แบบ Real-time ทันที
        this.renderer.setSize(width, height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

        // 2. คำนวณตำแหน่งกล้องและ FOV ให้กระดานเต็มหน้าจอตามรูปทรงและโหมดหน้าจอ (แนวนอน/แนวตั้ง)
        const layout = this.boardLayout || 'square';
        let fov = 42;
        let camX = 0;
        let camY = 51.0;
        let camZ = 68.0;
        let targetX = 0;
        let targetY = 0;
        let targetZ = 2.5;

        const isLandscape = aspect >= 1.0;

        if (isLandscape) {
            if (aspect >= 1.7) {
                // โหมดมือถือแนวนอน & จอกว้าง Widescreen (16:9, 19.5:9, 20:9 เช่น iPhone, Samsung)
                // ขยับตัวกระดานเข้ามาใกล้หน้าจอและขยายใหญ่ขึ้น ลดพื้นที่ขอบดำซ้าย-ขวา/บน-ล่างให้เหลือน้อยที่สุด
                fov = 42;
                if (layout === 'square') {
                    camY = 54.0;
                    camZ = 72.0;
                    targetZ = 2.5;
                } else if (layout === 'spiral') {
                    camY = 50.0;
                    camZ = 66.0;
                    targetZ = 2.0;
                } else {
                    // กระดานทรงหกเหลี่ยม (Hexagon)
                    camY = 51.0;
                    camZ = 68.0;
                    targetZ = 2.5;
                }
            } else if (aspect >= 1.4) {
                // จอแล็ปท็อป/คอมพิวเตอร์ 16:10, 3:2
                fov = 42;
                if (layout === 'square') {
                    camY = 56.0;
                    camZ = 74.0;
                    targetZ = 2.0;
                } else {
                    camY = 53.0;
                    camZ = 70.0;
                    targetZ = 2.0;
                }
            } else {
                // แท็บเล็ต 4:3 (iPad) หรือจอสี่เหลี่ยม
                fov = 43;
                const factor = 1.35 / Math.max(aspect, 1.0);
                camY = 54.0 * factor;
                camZ = 72.0 * factor;
                targetZ = 1.5;
            }
        } else {
            // โหมดแนวตั้ง (Mobile Portrait, aspect < 1.0)
            // ปรับระยะกล้องถอยออกตามสัดส่วนความกว้าง เพื่อให้เห็นทั้งกระดานครบ 100 ช่องไม่ตกขอบ
            fov = 44;
            let boardRadius = (layout === 'square') ? 40.0 : (layout === 'spiral' ? 35.0 : 38.0);
            const radFov = (fov * Math.PI) / 180;
            const targetHalfWidth = boardRadius * 1.15;
            const dist = targetHalfWidth / (Math.tan(radFov / 2) * aspect);
            const pitch = 50 * Math.PI / 180;
            camY = dist * Math.sin(pitch);
            camZ = dist * Math.cos(pitch);
            targetZ = 0;
        }

        // 3. ปรับค่า FOV, Aspect Ratio และสั่ง camera.updateProjectionMatrix()
        this.camera.fov = fov;
        this.camera.aspect = aspect;
        this.camera.position.set(camX, camY, camZ);
        this.camera.lookAt(targetX, targetY, targetZ);
        this.camera.updateProjectionMatrix();

        // 4. ซิงค์เป้าหมายการหมุน OrbitControls ให้ตรงกับตำแหน่งกึ่งกลางกระดาน
        if (this.controls) {
            this.controls.target.set(targetX, targetY, targetZ);
            this.controls.update();
        }
    }

    /**
     * Generate 6 procedural Dice Face textures with pips (dots)
     */
    generateDiceTextures() {
        this.diceMaterials = [];
        const pipConfigs = {
            1: [[0.5, 0.5]],
            2: [[0.25, 0.25], [0.75, 0.75]],
            3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
            4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
            5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
            6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
        };

        const faceOrder = [1, 6, 2, 5, 3, 4];

        faceOrder.forEach(num => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const ctx = canvas.getContext('2d');

            const grad = ctx.createLinearGradient(0, 0, 256, 256);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(1, '#e2e8f0');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 256, 256);

            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 12;
            ctx.strokeRect(6, 6, 244, 244);

            ctx.fillStyle = (num === 1) ? '#ef4444' : '#0f172a';
            const pips = pipConfigs[num];
            pips.forEach(([x, y]) => {
                ctx.beginPath();
                ctx.arc(x * 256, y * 256, num === 1 ? 32 : 22, 0, Math.PI * 2);
                ctx.fill();
            });

            const texture = new THREE.CanvasTexture(canvas);
            this.diceMaterials.push(new THREE.MeshStandardMaterial({
                map: texture,
                roughness: 0.15,
                metalness: 0.1
            }));
        });
    }

    /**
     * Create Two 3D Physics Dice meshes positioned over the board
     */
    create3DDice() {
        const diceGeo = new THREE.BoxGeometry(3.2, 3.2, 3.2);

        this.diceMesh1 = new THREE.Mesh(diceGeo, this.diceMaterials);
        this.diceMesh1.castShadow = true;
        this.diceMesh1.position.set(-3.5, 2.2, 32.5);

        this.diceMesh2 = new THREE.Mesh(diceGeo, this.diceMaterials);
        this.diceMesh2.castShadow = true;
        this.diceMesh2.position.set(3.5, 2.2, 32.5);

        this.diceGroup.add(this.diceMesh1);
        this.diceGroup.add(this.diceMesh2);
    }

    setBoardTheme(themeName) {
        if (!this.themes[themeName]) return;
        this.boardTheme = themeName;
        try {
            localStorage.setItem('snake_board_theme', themeName);
        } catch(e) {}
        const th = this.themes[themeName];
        this.scene.background = new THREE.Color(th.bgColor);
        this.scene.fog.color = new THREE.Color(th.fogColor);
        this.pointLight.color = new THREE.Color(th.light);
        if (this.boardTheme === 'ancient') {
            if (this.ambientLight) {
                this.ambientLight.color.setHex(0xfff3db);
                this.ambientLight.intensity = 1.0;
            }
            if (this.dirLight) {
                this.dirLight.color.setHex(0xfff0cc);
            }
        } else {
            if (this.ambientLight) {
                this.ambientLight.color.setHex(0xffffff);
                this.ambientLight.intensity = 0.8;
            }
            if (this.dirLight) {
                this.dirLight.color.setHex(0xffffff);
            }
        }
        this.buildBoard();
        if (typeof this.rebuildAllCities3D === 'function') {
            this.rebuildAllCities3D();
        }

        // ปรับมุมกล้องให้ฟิตพอดีกับขนาดกระดานรูปทรงใหม่ทันที
        this.updateCameraFit();
        this.logMessage(`เปลี่ยนรูปแบบกระดานเป็น: ${th.name}`, 'highlight');
    }

    setBoardLayout(layoutName) {
        const valid = ['square', 'spiral', 'hexagon'];
        if (!valid.includes(layoutName)) layoutName = 'square';
        this.boardLayout = layoutName;
        try {
            localStorage.setItem('snake_board_layout', layoutName);
        } catch(e) {}

        this.buildBoard();
        if (typeof this.rebuildAllCities3D === 'function') {
            this.rebuildAllCities3D();
        }

        // ปรับมุมกล้องให้ฟิตพอดีกับขนาดกระดานรูปทรงใหม่ทันที
        this.updateCameraFit();

        // Reposition all active player pawns to match new layout coordinates
        (this.players || []).forEach((p, idx) => {
            if (p && p.mesh && this.tiles[p.currentTile]) {
                const off = (typeof this.getPawnFrontOffset === 'function') ? this.getPawnFrontOffset(p, p.currentTile, idx) : { x: 0, z: 0 };
                const tPos = this.tiles[p.currentTile];
                p.mesh.position.set(tPos.x + off.x, (p.currentTile === 1 || p.currentTile === 100) ? 1.18 : 0.52, tPos.z + off.z);
            }
        });

        const layoutNames = {
            'square': 'กระดานสี่เหลี่ยมดั้งเดิม (Classic Square)',
            'spiral': 'กระดานทรงกลมก้นหอย (Spiral Galaxy)',
            'hexagon': 'กระดานทรงหกเหลี่ยม (Hexagon Hive)'
        };
        this.logMessage(`เปลี่ยนรูปทรงกระดานเป็น: ${layoutNames[layoutName] || layoutName}`, 'highlight');
    }


    initProvinces() {
        this.tileProvinces = {};
        const shuffled = [...THAI_PROVINCES].sort(() => Math.random() - 0.5);
        for (let i = 1; i <= 100; i++) {
            this.tileProvinces[i] = shuffled[(i - 1) % shuffled.length];
        }
    }

    getProvinceName(tileNum) {
        return this.tileProvinces[tileNum] || 'สยาม';
    }

    createTileTexture(tileNum, provinceName, tileType, theme) {
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');

        // Theme and tile type styling
        let bgColor = (tileNum % 2 === 0) ? '#101a2e' : '#182742';
        let borderColor = '#00e5ff';
        let accentColor = '#38bdf8';
        let icon = '';
        let typeTag = '';

        if (this.boardTheme === 'ancient') {
            bgColor = (tileNum % 2 === 0) ? '#281a08' : '#3c270d';
            borderColor = '#ffd700';
            accentColor = '#facc15';
        } else if (this.boardTheme === 'lava') {
            bgColor = (tileNum % 2 === 0) ? '#2a0909' : '#3b1212';
            borderColor = '#ff4d4d';
            accentColor = '#f97316';
        } else if (this.boardTheme === 'ice') {
            bgColor = (tileNum % 2 === 0) ? '#08253a' : '#0f3856';
            borderColor = '#67e8f9';
            accentColor = '#a5f3fc';
        }

        if (tileType === 'CHANCE') {
            bgColor = '#381f02';
            borderColor = '#f59e0b';
            accentColor = '#fbbf24';
            icon = '🎁';
            typeTag = 'ช่องดวง';
        } else if (tileType === 'TAX') {
            bgColor = '#3b0d0d';
            borderColor = '#ef4444';
            accentColor = '#f87171';
            icon = '💸';
            typeTag = 'ภาษี (TAX)';
        } else if (tileType === 'GAMBLE') {
            bgColor = '#2b0938';
            borderColor = '#c084fc';
            accentColor = '#e879f9';
            icon = '🎰';
            typeTag = 'เสี่ยงโชค';
        } else if (tileType === 'DESTROY') {
            bgColor = '#3b0717';
            borderColor = '#f43f5e';
            accentColor = '#fb7185';
            icon = '💥';
            typeTag = 'ลบเมืองคู่แข่ง';
        } else if (tileType === 'JAIL') {
            bgColor = '#1e293b';
            borderColor = '#94a3b8';
            accentColor = '#cbd5e1';
            icon = '⛓️';
            typeTag = 'คุกเกาะร้าง';
        } else if (tileType === 'GOAL') {
            bgColor = '#064e3b';
            borderColor = '#10b981';
            accentColor = '#34d399';
            icon = '🏆';
            typeTag = 'เส้นชัย GOAL';
        } else if (tileType === 'START' || tileNum === 1) {
            bgColor = '#07263e';
            borderColor = '#00e5ff';
            accentColor = '#38bdf8';
            icon = '🚩';
            typeTag = '🚩 จุดสตาร์ท START';
        } else if (this.ladders[tileNum]) {
            icon = '🪜';
            typeTag = `ขึ้นไป ${this.ladders[tileNum]}`;
        } else if (this.snakes[tileNum]) {
            icon = '🐍';
            typeTag = `งูดึงไป ${this.snakes[tileNum]}`;
            borderColor = '#f43f5e';
        } else if (this.snakeTailToHead && this.snakeTailToHead[tileNum]) {
            icon = '🐍';
            typeTag = `งูดึงขึ้น ${this.snakeTailToHead[tileNum]}`;
            borderColor = '#f43f5e';
        }

        // Fill background
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, 256, 256);

        // Inner card gradient
        const grad = ctx.createLinearGradient(0, 0, 256, 256);
        grad.addColorStop(0, 'rgba(255,255,255,0.09)');
        grad.addColorStop(1, 'rgba(0,0,0,0.3)');
        ctx.fillStyle = grad;
        ctx.fillRect(10, 10, 236, 236);

        // Border
        ctx.strokeStyle = borderColor;
        ctx.lineWidth = 6;
        ctx.strokeRect(8, 8, 240, 240);

        // Neon corners
        ctx.fillStyle = accentColor;
        ctx.fillRect(8, 8, 24, 5);
        ctx.fillRect(8, 8, 5, 24);
        ctx.fillRect(224, 8, 24, 5);
        ctx.fillRect(243, 8, 5, 24);
        ctx.fillRect(8, 243, 24, 5);
        ctx.fillRect(8, 224, 5, 24);
        ctx.fillRect(224, 243, 24, 5);
        ctx.fillRect(243, 224, 5, 24);

        // Tile Number (Top-Left)
        ctx.font = 'bold 36px "Kanit", sans-serif';
        ctx.fillStyle = accentColor;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.shadowColor = 'rgba(0,0,0,0.9)';
        ctx.shadowBlur = 6;
        ctx.fillText(`${tileNum}`, 20, 18);

        // Icon (Top-Right)
        if (icon) {
            ctx.font = '36px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(icon, 236, 18);
        }

        // Sub-badge / Event tag (Center)
        if (typeTag) {
            ctx.font = 'bold 22px "Kanit", sans-serif';
            ctx.fillStyle = accentColor;
            ctx.textAlign = 'center';
            ctx.fillText(typeTag, 128, 100);
        }

        // Thai Province Name (Bottom)
        ctx.font = 'bold 34px "Kanit", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        ctx.fillText(provinceName, 128, 236);

        const texture = new THREE.CanvasTexture(canvas);
        texture.anisotropy = 4;
        return texture;
    }

    createDestroySign(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(0.95, 1.15, 0.4, 16);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x881337, metalness: 0.8, roughness: 0.25 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        const ringGeo = new THREE.TorusGeometry(0.72, 0.14, 12, 28);
        const ringMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0xe11d48, emissiveIntensity: 0.6, metalness: 0.85, roughness: 0.15 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.55;
        group.add(ring);

        const bombGeo = new THREE.OctahedronGeometry(0.52);
        const bombMat = new THREE.MeshStandardMaterial({ color: 0xff0055, emissive: 0xff0055, emissiveIntensity: 0.85, metalness: 0.9, roughness: 0.1 });
        const bomb = new THREE.Mesh(bombGeo, bombMat);
        bomb.position.y = 1.35;
        group.add(bomb);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    createTaxSign(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(0.9, 1.1, 0.4, 16);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.8, roughness: 0.3 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        for (let c = 0; c < 3; c++) {
            const coinGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.18, 16);
            const coinMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2 });
            const coin = new THREE.Mesh(coinGeo, coinMat);
            coin.position.y = 0.3 + c * 0.2;
            group.add(coin);
        }

        const emblemGeo = new THREE.OctahedronGeometry(0.45);
        const emblemMat = new THREE.MeshBasicMaterial({ color: 0xff0055 });
        const emblem = new THREE.Mesh(emblemGeo, emblemMat);
        emblem.position.y = 1.3;
        group.add(emblem);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    createLuckyWheel3D(x, y, z) {
        const group = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(1.0, 1.2, 0.5, 20);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x7c3aed, metalness: 0.7, roughness: 0.2 });
        const base = new THREE.Mesh(baseGeo, baseMat);
        group.add(base);

        const ringGeo = new THREE.TorusGeometry(0.7, 0.18, 12, 24);
        const ringMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.95, roughness: 0.1 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.5;
        group.add(ring);

        const gemGeo = new THREE.OctahedronGeometry(0.55);
        const gemMat = new THREE.MeshStandardMaterial({
            color: 0x00e5ff,
            emissive: 0x00e5ff,
            emissiveIntensity: 0.6,
            metalness: 0.3,
            roughness: 0.1
        });
        const gem = new THREE.Mesh(gemGeo, gemMat);
        gem.position.y = 1.35;
        group.add(gem);

        group.position.set(x, y, z);
        this.boardGroup.add(group);
    }

    buildBoard() {
        while (this.boardGroup.children.length > 0) {
            this.boardGroup.remove(this.boardGroup.children[0]);
        }
        this.tiles = [];
        this.tileMeshes = [];
        this.ladderObjects = {};
        this.snakeObjects = {};

        const theme = this.themes[this.boardTheme];
        const tileSize = this.tileSize;
        const gap = this.tileGap;
        const totalSize = 10 * (tileSize + gap);
        const startOffset = -totalSize / 2 + tileSize / 2;
        const layout = this.boardLayout || 'square';

        // 1. สร้างฐานกรอบกระดานตามรูปทรง (Square / Spiral Cylinder / Hexagon Cylinder)
        let frameGeo;
        if (layout === 'spiral') {
            const outerR = 35.0;
            frameGeo = new THREE.CylinderGeometry(outerR + 4.5, outerR + 6.5, 2.2, 48);
        } else if (layout === 'hexagon') {
            const hexR = 38.5;
            frameGeo = new THREE.CylinderGeometry(hexR + 2.0, hexR + 4.5, 2.2, 6);
        } else {
            frameGeo = new THREE.BoxGeometry(totalSize + 5, 2.2, totalSize + 5);
        }

        const frameColor = (this.boardTheme === 'ancient') ? 0x241808 : 0x090e17;
        const frameMat = new THREE.MeshStandardMaterial({
            color: frameColor,
            metalness: (this.boardTheme === 'ancient') ? 0.85 : 0.85,
            roughness: (this.boardTheme === 'ancient') ? 0.2 : 0.25
        });
        const frame = new THREE.Mesh(frameGeo, frameMat);
        frame.position.y = -1.1;
        if (layout === 'hexagon') frame.rotation.y = Math.PI / 6;
        frame.receiveShadow = true;
        this.boardGroup.add(frame);

        const frameBorderGeo = new THREE.EdgesGeometry(frameGeo);
        const frameBorderMat = new THREE.LineBasicMaterial({
            color: (this.boardTheme === 'ancient') ? 0xffd700 : theme.border,
            linewidth: 2.5
        });
        const frameBorder = new THREE.LineSegments(frameBorderGeo, frameBorderMat);
        frameBorder.position.y = -1.1;
        if (layout === 'hexagon') frameBorder.rotation.y = Math.PI / 6;
        this.boardGroup.add(frameBorder);

        // 2. คำนวณพิกัด 100 ช่อง และรูปทรงบล็อกตาม Layout
        for (let i = 1; i <= 100; i++) {
            let x = 0, y = 0, z = 0;
            let tileMeshRotationY = 0;
            let tileGeo;
            let isTileCylinder = false;

            const isChance = this.chanceTiles.includes(i);
            const isTax = this.taxTiles.includes(i);
            const isGamble = this.gambleTiles.includes(i);
            const isDestroy = this.destroyTiles && this.destroyTiles.includes(i);
            const isJail = (i === this.jailTile);
            const isGoal = (i === 100);
            const isStart = (i === 1);

            if (layout === 'spiral') {
                // 🌀 ทรงกลมก้นหอย: วน 3.8 รอบจากขอบนอกเข้าสู่ใจกลาง
                const u = (i - 1) / 99; // 0.0 (ขอบนอก ช่อง 1) -> 1.0 (ใจกลาง ช่อง 100)
                const spiralTurns = 3.8;
                const angle = u * spiralTurns * (Math.PI * 2) - Math.PI / 2;
                const maxR = 33.0;
                const r = maxR * (1.0 - 0.93 * u);
                x = r * Math.cos(angle);
                z = r * Math.sin(angle);
                y = 0;

                if (isGoal) {
                    tileGeo = new THREE.CylinderGeometry(3.6, 3.8, 0.8, 24);
                    isTileCylinder = true;
                } else {
                    tileGeo = new THREE.BoxGeometry(4.8, 0.8, 4.8);
                    tileMeshRotationY = -angle; // หมุนเอียงตามแนวโค้งของวงก้นหอย
                }
            } else if (layout === 'hexagon') {
                // ⬡ ทรงหกเหลี่ยมรังผึ้ง (Honeycomb Staggered Grid)
                const r = Math.floor((i - 1) / 10);
                const colInRow = (i - 1) % 10;
                const c = (r % 2 === 0) ? colInRow : (9 - colInRow);
                const hexStepX = 6.4;
                const hexStepZ = 5.7;
                const stagger = (r % 2 === 1) ? (hexStepX * 0.5) : 0;
                x = (-4.5 * hexStepX) + c * hexStepX + stagger;
                z = (4.5 * hexStepZ) - r * hexStepZ;
                y = 0;

                tileGeo = new THREE.CylinderGeometry(3.3, 3.3, 0.8, 6);
                isTileCylinder = true;
                tileMeshRotationY = Math.PI / 6; // หันมุมหกเหลี่ยม
            } else {
                // 🟩 กระดานสี่เหลี่ยมดั้งเดิม (Classic 10x10 Zigzag Grid)
                const row = Math.floor((i - 1) / 10);
                const colInRow = (i - 1) % 10;
                const col = (row % 2 === 0) ? colInRow : (9 - colInRow);
                x = startOffset + col * (tileSize + gap);
                z = (totalSize / 2 - tileSize / 2) - row * (tileSize + gap);
                y = 0;

                tileGeo = new THREE.BoxGeometry(tileSize, 0.8, tileSize);
            }

            this.tiles[i] = new THREE.Vector3(x, y, z);

            let tileType = 'NORMAL';
            if (isGoal) tileType = 'GOAL';
            else if (isStart) tileType = 'START';
            else if (isGamble) tileType = 'GAMBLE';
            else if (isTax) tileType = 'TAX';
            else if (isChance) tileType = 'CHANCE';
            else if (isDestroy) tileType = 'DESTROY';
            else if (isJail) tileType = 'JAIL';

            const sideMat = new THREE.MeshStandardMaterial({
                color: (i % 2 === 0) ? theme.tileEven : theme.tileOdd,
                metalness: (this.boardTheme === 'ancient') ? 0.7 : 0.5,
                roughness: (this.boardTheme === 'ancient') ? 0.25 : 0.35
            });

            const provinceName = this.getProvinceName(i);
            const topTex = this.createTileTexture(i, provinceName, tileType, theme);
            const topMat = new THREE.MeshStandardMaterial({
                map: topTex,
                metalness: (this.boardTheme === 'ancient') ? 0.6 : 0.4,
                roughness: (this.boardTheme === 'ancient') ? 0.2 : 0.25,
                emissive: isGoal ? 0x10b981 : (isStart ? 0x0284c7 : (isGamble ? 0x6b21a8 : (isDestroy ? 0x881337 : (isTax ? 0x7f1d1d : (isChance ? 0x78350f : (this.boardTheme === 'ancient' ? 0x1a1204 : 0x000000)))))),
                emissiveIntensity: isStart ? 0.35 : (this.boardTheme === 'ancient' ? 0.2 : 0.15)
            });

            // สร้าง Mesh ตามทรง
            let tileMesh;
            if (isTileCylinder) {
                // CylinderGeometry material groups: [sideMat, topMat, bottomMat]
                tileMesh = new THREE.Mesh(tileGeo, [sideMat, topMat, sideMat]);
            } else {
                // BoxGeometry 6 faces: [right, left, top, bottom, front, back]
                tileMesh = new THREE.Mesh(tileGeo, [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
            }
            tileMesh.position.set(x, y, z);
            if (tileMeshRotationY) tileMesh.rotation.y = tileMeshRotationY;
            tileMesh.receiveShadow = true;
            this.boardGroup.add(tileMesh);
            this.tileMeshes[i] = tileMesh;

            const edgeGeo = new THREE.EdgesGeometry(tileGeo);
            const edgeMat = new THREE.LineBasicMaterial({
                color: isGoal ? 0x00ffcc : (isStart ? 0x00e5ff : theme.border),
                linewidth: 1.5
            });
            const borderLine = new THREE.LineSegments(edgeGeo, edgeMat);
            borderLine.position.set(x, y, z);
            if (tileMeshRotationY) borderLine.rotation.y = tileMeshRotationY;
            this.boardGroup.add(borderLine);

            if (isChance) {
                this.createChanceChest(x, y + 1.2, z);
            } else if (isTax) {
                this.createTaxSign(x, y + 1.2, z);
            } else if (isGamble) {
                this.createLuckyWheel3D(x, y + 1.2, z);
            } else if (isDestroy) {
                this.createDestroySign(x, y + 1.2, z);
            } else if (isJail) {
                this.createPrisonJail(x, y + 1.2, z);
            } else if (isStart) {
                this.createStartPointLandmark(x, y + 0.4, z);
            } else if (isGoal) {
                this.createGoalCityLandmark(x, y + 0.4, z);
            }
        }

        for (const [start, end] of Object.entries(this.ladders)) {
            this.create3DLadder(this.tiles[start], this.tiles[end], theme.ladder, Number(start), Number(end));
        }

        for (const [start, end] of Object.entries(this.snakes)) {
            this.create3DSnake(this.tiles[start], this.tiles[end], theme.snake, Number(start), Number(end));
        }
    }

    createChanceChest(x, y, z) {
        const chestGroup = new THREE.Group();
        const chestGeo = new THREE.BoxGeometry(1.8, 1.3, 1.3);
        const chestMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2 });
        const chest = new THREE.Mesh(chestGeo, chestMat);
        chestGroup.add(chest);

        const gemGeo = new THREE.OctahedronGeometry(0.5);
        const gemMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
        const gem = new THREE.Mesh(gemGeo, gemMat);
        gem.position.y = 1.2;
        chestGroup.add(gem);

        chestGroup.position.set(x, y, z);
        this.boardGroup.add(chestGroup);
    }

    createPrisonJail(x, y, z) {
        const jailGroup = new THREE.Group();
        const barGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.8, 8);
        const barMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95 });

        for (let i = -1; i <= 1; i += 0.7) {
            const bar = new THREE.Mesh(barGeo, barMat);
            bar.position.set(i, 0, 1.2);
            jailGroup.add(bar);
        }

        jailGroup.position.set(x, y, z);
        this.boardGroup.add(jailGroup);
    }

    createGoalTrophy(x, y, z) {
        const trophyGroup = new THREE.Group();
        const cupGeo = new THREE.CylinderGeometry(1.4, 0.4, 2.2, 16);
        const cupMat = new THREE.MeshStandardMaterial({ color: 0xffea00, metalness: 0.9, roughness: 0.1 });
        const cup = new THREE.Mesh(cupGeo, cupMat);
        trophyGroup.add(cup);

        trophyGroup.position.set(x, y, z);
        this.boardGroup.add(trophyGroup);
    }

    create3DLadder(startPos, endPos, colorHex, startTile = 0, endTile = 0) {
        const ladderGroup = new THREE.Group();

        // 1. คำนวณเวกเตอร์ทิศทางบนระนาบแนวนอน (XZ Plane) ของกระดาน
        const dir = new THREE.Vector3().subVectors(endPos, startPos);
        dir.y = 0; // ยึดระนาบกระดานแนวนอนเป็นหลัก ป้องกันบันไดเอียงจมลงใต้พื้น
        const dist = Math.max(dir.length(), 1.0);
        const dirNorm = dir.clone().normalize();

        // 2. เวกเตอร์แนวตั้งฉากตามแนวนอน (Horizontal Perpendicular Vector) สำหรับวางรางบันไดซ้าย-ขวา
        // dirNorm x UP(0, 1, 0) => perp = (dirNorm.z, 0, -dirNorm.x)
        // รับประกันว่ารางซ้ายและรางขวาจะมีความสูง Y เท่ากัน 100% เสมอ ไม่บิดหมุนตั้งชันหรือจมลงใต้กระดาน
        const perp = new THREE.Vector3(dirNorm.z, 0, -dirNorm.x).normalize();
        const up = new THREE.Vector3(0, 1, 0);

        // ขนาดสัดส่วนบันได
        const ladderWidth = 2.4;
        const halfWidth = ladderWidth / 2;
        const railRadius = 0.22;
        const rungRadius = 0.14;
        const halfDist = dist / 2;

        const railMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            metalness: 0.85,
            roughness: 0.2,
            emissive: colorHex,
            emissiveIntensity: 0.35
        });

        const rungMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            metalness: 0.65,
            roughness: 0.3,
            emissive: 0x475569,
            emissiveIntensity: 0.2
        });

        // 3. รางบันไดซ้ายและขวา: ทอดตัวตามแกน Z ภายใน local space ของ ladderGroup
        const railGeo = new THREE.CylinderGeometry(railRadius, railRadius, dist, 12);

        const railL = new THREE.Mesh(railGeo, railMat);
        railL.position.set(-halfWidth, 0, 0);
        railL.rotation.x = Math.PI / 2; // หมุนนอนไปตามแกน Z
        ladderGroup.add(railL);

        const railR = new THREE.Mesh(railGeo, railMat);
        railR.position.set(halfWidth, 0, 0);
        railR.rotation.x = Math.PI / 2; // หมุนนอนไปตามแกน Z
        ladderGroup.add(railR);

        // 4. หัวครอบปลายบันไดทั้ง 4 จุด (สวยงาม มีมิติ ไม่เป็นท่อตัดเหลี่ยม)
        const capGeo = new THREE.SphereGeometry(railRadius * 1.3, 10, 10);
        [[-halfWidth, -halfDist], [-halfWidth, halfDist], [halfWidth, -halfDist], [halfWidth, halfDist]].forEach(([rx, rz]) => {
            const cap = new THREE.Mesh(capGeo, railMat);
            cap.position.set(rx, 0, rz);
            ladderGroup.add(cap);
        });

        // 5. ขั้นบันได (Rungs): วางขนานเชื่อมระหว่างรางซ้าย-ขวาตามแกน X
        const rungsCount = Math.max(2, Math.floor(dist / 2.6));
        const rungGeo = new THREE.CylinderGeometry(rungRadius, rungRadius, ladderWidth, 8);
        for (let i = 0; i < rungsCount; i++) {
            const rung = new THREE.Mesh(rungGeo, rungMat);
            rung.rotation.z = Math.PI / 2; // หมุนนอนไปตามแกน X
            const rungZ = -halfDist + (i + 1) * (dist / (rungsCount + 1));
            rung.position.set(0, 0, rungZ);
            ladderGroup.add(rung);
        }

        // 6. ตำแหน่งกึ่งกลาง: พื้นผิวช่องกระดานอยู่ที่ y = 0.40 ตั้งความสูงบันไดที่ y = 0.72 เพื่อให้ลอยเหนือกระดานพอดี
        const midPoint = new THREE.Vector3().addVectors(startPos, endPos).multiplyScalar(0.5);
        ladderGroup.position.set(midPoint.x, 0.72, midPoint.z);

        // 7. กำหนดแกนมุมมอง 3D ให้บันได (Right-handed Orthonormal Basis)
        // แกน X -> perp (ขนานระนาบกระดานแนวนอน 100%)
        // แกน Y -> up (ตั้งตรงชี้ขึ้นฟ้าเสมอ)
        // แกน Z -> dirNorm (พุ่งจากจุดเริ่มไปยังจุดปลายบันได)
        const rotMatrix = new THREE.Matrix4().makeBasis(perp, up, dirNorm);
        ladderGroup.quaternion.setFromRotationMatrix(rotMatrix);

        this.boardGroup.add(ladderGroup);

        if (startTile) {
            this.ladderObjects[startTile] = { group: ladderGroup, startPos, endPos };
        }
    }

    create3DSnake(headPos, tailPos, colorHex, startTile = 0, endTile = 0) {
        const snakeGroup = new THREE.Group();

        const p0 = new THREE.Vector3(headPos.x, headPos.y + 1.15, headPos.z);
        const p3 = new THREE.Vector3(tailPos.x, tailPos.y + 0.45, tailPos.z);
        const flatDir = new THREE.Vector3(p3.x - p0.x, 0, p3.z - p0.z);
        const flatLen = Math.max(flatDir.length(), 1);
        flatDir.normalize();
        const perp = new THREE.Vector3(-flatDir.z, 0, flatDir.x);
        const waveAmp = Math.min(4.2, Math.max(2.2, flatLen * 0.16));

        const mid1 = new THREE.Vector3().lerpVectors(p0, p3, 0.33);
        mid1.addScaledVector(perp, waveAmp);
        mid1.y = headPos.y + 3.6;

        const mid2 = new THREE.Vector3().lerpVectors(p0, p3, 0.68);
        mid2.addScaledVector(perp, -waveAmp * 0.85);
        mid2.y = headPos.y + 2.2;

        const curve = new THREE.CatmullRomCurve3([p0, mid1, mid2, p3]);

        // สร้างลำตัวงู 3D โค้งมนเรียวลงไปหาปลายหาง
        const segments = 48;
        const radialSegments = 14;
        const tubeGeo = new THREE.TubeGeometry(curve, segments, 0.62, radialSegments, false);
        const posAttr = tubeGeo.attributes.position;
        const frames = curve.computeFrenetFrames(segments, false);
        const centerPt = new THREE.Vector3();
        const vtx = new THREE.Vector3();
        for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            curve.getPointAt(t, centerPt);
            // ค่อยๆ เรียวเล็กที่ช่วงปลายหางอย่างเป็นธรรมชาติ
            const taper = t < 0.7 ? 1.0 : Math.max(0.18, 1.0 - ((t - 0.7) / 0.3) * 0.82);
            for (let j = 0; j <= radialSegments; j++) {
                const idx = i * (radialSegments + 1) + j;
                if (idx < posAttr.count) {
                    vtx.fromBufferAttribute(posAttr, idx);
                    vtx.sub(centerPt).multiplyScalar(taper).add(centerPt);
                    posAttr.setXYZ(idx, vtx.x, vtx.y, vtx.z);
                }
            }
        }
        tubeGeo.computeVertexNormals();

        const bodyMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            roughness: 0.24,
            metalness: 0.65,
            emissive: colorHex,
            emissiveIntensity: 0.28
        });
        const snakeMesh = new THREE.Mesh(tubeGeo, bodyMat);
        snakeMesh.castShadow = true;
        snakeGroup.add(snakeMesh);

        // หัวพญางู 3D ทรงมนพร้อมดวงตาคู่และลิ้นสองแฉก (ตรงตามรูป 1)
        const headGroup = new THREE.Group();
        headGroup.position.set(headPos.x, headPos.y + 1.25, headPos.z);

        // หันหัวงูไปตามทิศลำตัว/กล้องอย่างสมจริง
        const lookTarget = new THREE.Vector3().lerpVectors(mid1, new THREE.Vector3(headPos.x, headPos.y + 1.1, headPos.z + 4.5), 0.45);
        lookTarget.y = headPos.y + 1.05;
        headGroup.lookAt(lookTarget);

        const craniumGeo = new THREE.SphereGeometry(1.05, 24, 18);
        craniumGeo.scale(1.08, 0.82, 1.32);
        const headMat = new THREE.MeshStandardMaterial({
            color: colorHex,
            roughness: 0.2,
            metalness: 0.68,
            emissive: colorHex,
            emissiveIntensity: 0.32
        });
        const cranium = new THREE.Mesh(craniumGeo, headMat);
        cranium.castShadow = true;
        headGroup.add(cranium);

        // ขากรรไกรล่างขยับได้เล็กน้อย
        const lowerJawPivot = new THREE.Group();
        lowerJawPivot.position.set(0, -0.25, 0.2);
        const jawGeo = new THREE.SphereGeometry(0.76, 16, 12);
        jawGeo.scale(0.92, 0.36, 1.15);
        const jawMesh = new THREE.Mesh(jawGeo, headMat);
        jawMesh.position.set(0, 0, 0.28);
        lowerJawPivot.add(jawMesh);
        headGroup.add(lowerJawPivot);

        // ลิ้นงูสองแฉกเล็กๆ
        const tongueGroup = new THREE.Group();
        const tongueMat = new THREE.MeshBasicMaterial({ color: 0xff1744, side: THREE.DoubleSide });
        const tongueStem = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.65), tongueMat);
        tongueStem.position.set(0, -0.18, 1.35);
        tongueGroup.add(tongueStem);
        headGroup.add(tongueGroup);

        // ดวงตาคู่ทรงกลมพร้อมม่านตาคมชัด (ขาวอมเหลืองสว่าง + ตาดำ)
        const scleraGeo = new THREE.SphereGeometry(0.25, 14, 14);
        const scleraMat = new THREE.MeshBasicMaterial({ color: 0xfef9c3 });
        const pupilGeo = new THREE.SphereGeometry(0.13, 10, 10);
        const pupilMat = new THREE.MeshBasicMaterial({ color: 0x090d16 });

        [-0.52, 0.52].forEach(sideX => {
            const eyeWrap = new THREE.Group();
            eyeWrap.position.set(sideX, 0.44, 0.58);
            const sclera = new THREE.Mesh(scleraGeo, scleraMat);
            const pupil = new THREE.Mesh(pupilGeo, pupilMat);
            pupil.position.set(sideX * 0.08, 0.04, 0.16);
            eyeWrap.add(sclera);
            eyeWrap.add(pupil);
            headGroup.add(eyeWrap);
        });

        snakeGroup.add(headGroup);
        this.boardGroup.add(snakeGroup);

        if (startTile) {
            this.snakeObjects[startTile] = {
                group: snakeGroup,
                curve,
                headGroup,
                headPos: headPos.clone(),
                lowerJawPivot,
                tongueGroup,
                phaseOffset: startTile * 0.65,
                isAnimating: false
            };
        }
    }

    /**
     * โหมดสแตนด์บายบนหน้าหลัก (ยังไม่ได้กดทดลองเล่น หรือยังไม่ได้เข้าห้องแข่งขัน)
     * แสดงเฉพาะหมากของผู้เล่นที่จุด START (ช่อง 1) โดยไม่เริ่มทอยเองและไม่นับถอยหลังเข้า AUTO
     */
    setupIdlePreview(userProfile = null) {
        this.clearTurnTimers();
        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }
        this.matchTimeRemaining = 600;
        this.matchStartTime = null;
        this.closeCityActionPrompt(null);
        this.clearAllCities3D();
        this.isMatchActive = false;
        this.isGameOver = false;
        this.isRolling = false;
        this.isAutoMode = false;
        this.currentTurnIndex = 0;

        while (this.pawnsGroup.children.length > 0) {
            this.pawnsGroup.remove(this.pawnsGroup.children[0]);
        }
        this.players = [];
        this.updateMatchWealthHUD();

        const u = userProfile || window.DEFAULT_USER || {};
        let myName = u.displayName || u.name || u.username || 'ผู้เล่น';
        if (myName === 'เขียนศักดิ์' || myName === 'Google Player') {
            myName = 'ผู้เล่น';
        }
        const activeAvatar = (typeof window.getActivePlayerAvatarUrl === 'function')
            ? window.getActivePlayerAvatarUrl(u)
            : (u.avatar_url || u.pictureUrl || u.picture || 'avatars/avatar_01.svg');
        const pSkin = u.dice_skin || window.DEFAULT_USER?.dice_skin || 'ClassicWoodDice';
        const pDiceName = u.equipped_dice_name || window.DEFAULT_USER?.equipped_dice_name || 'ลูกเต๋าไม้คลาสสิก 3D';

        const pData = {
            id: u.id || 1,
            username: myName,
            auth_provider: u.auth_provider || 'guest',
            picture: activeAvatar,
            pictureUrl: activeAvatar,
            avatar_url: activeAvatar,
            team: 'NONE',
            team_name: '',
            color: 0x00e5ff,
            is_bot: false,
            is_awakened: true,
            dice_skin: pSkin,
            dice_name: pDiceName,
            skill: { code: 'PULL_BACK_8', power: 8 },
            dice_control_rate: 35
        };

        const pawnGroup = this.createPawnMesh(0x00e5ff, true, pData);
        this.pawnsGroup.add(pawnGroup);

        const playerObj = {
            ...pData,
            mesh: pawnGroup,
            currentTile: 1,
            isAwakened: true,
            jailTurns: 0,
            consecutiveDoubles: 0
        };
        this.setPawnPosition(playerObj, 1, 0);
        this.players.push(playerObj);
        this.applyDiceSkinForPlayer(playerObj);

        const feed = document.getElementById('log-feed');
        if (feed) feed.innerHTML = '';
        this.logMessage('✨ พร้อมเริ่มเล่น! เลือก "ห้องแข่งขัน" หรือกดปุ่ม "ทดลองเล่น" เพื่อเริ่มเกม', 'highlight');

        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            rollBtn.disabled = false;
            rollBtn.classList.remove('auto-active');
            rollBtn.style.opacity = '1';
            rollBtn.innerHTML = `<span>🎲</span> ทอย`;
        }

        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }
    }

    setupPlayers(playersData, options = {}) {
        this.closeCityActionPrompt(null);
        this.clearAllCities3D();

        const incomingCfg = options.roomConfig
            || (typeof window.getActiveRoomEconomyConfig === 'function' ? window.getActiveRoomEconomyConfig() : null)
            || {};
        this.matchConfig = {
            room_tier: incomingCfg.room_tier || (window.isPracticeMatch ? 'PRACTICE' : '2M'),
            entry_fee_gold: Number(incomingCfg.entry_fee_gold ?? 2000),
            start_match_gold: Number(incomingCfg.start_match_gold ?? 2000000),
            tax_amount: Number(incomingCfg.tax_amount ?? 50000),
            tax_percent: Number(incomingCfg.tax_percent ?? 20),
            city_base_cost: Number(incomingCfg.city_base_cost ?? 120000),
            landmark_cost: Number(incomingCfg.landmark_cost ?? 320000),
            toll_percent: Number(incomingCfg.toll_percent ?? 85),
            buyout_percent: Number(incomingCfg.buyout_percent ?? 160),
            gameMode: options.gameMode || window.currentActiveGameMode || '2P',
            roomId: options.roomId || window.currentRoomId || null
        };

        if (options.roomId) {
            window.currentRoomId = options.roomId;
        } else if (!window.isPracticeMatch && !window.currentRoomId) {
            window.currentRoomId = 'room_' + Date.now();
            this.matchConfig.roomId = window.currentRoomId;
        }
        if (options.gameMode) {
            window.currentActiveGameMode = options.gameMode;
        }

        const targetMode = options.gameMode || window.currentActiveGameMode || this.matchConfig?.gameMode || '2P';
        const expectedCount = (targetMode === '2P') ? 2 : ((targetMode === '3P') ? 3 : 4);

        let safePlayersData = Array.isArray(playersData) ? [...playersData] : [];
        if (safePlayersData.length < expectedCount) {
            const missing = expectedCount - safePlayersData.length;
            const used = safePlayersData.map(p => p.username || '');
            const extras = (typeof window.pickUniqueOpponentProfiles === 'function')
                ? window.pickUniqueOpponentProfiles(missing, used)
                : [];
            const isTeam = (targetMode === 'TEAM');
            for (let i = 0; i < missing; i++) {
                const prof = extras[i] || { username: `คู่แข่ง #${safePlayersData.length + 1}`, avatar_url: 'avatars/google_avatar.png' };
                const pIdx = safePlayersData.length;
                safePlayersData.push({
                    id: 901 + pIdx,
                    username: prof.username,
                    avatar_url: prof.avatar_url,
                    picture: prof.avatar_url,
                    team: isTeam ? ((pIdx % 2 === 0) ? 'A' : 'B') : 'NONE',
                    team_name: isTeam ? ((pIdx % 2 === 0) ? 'ทีมฟ้า' : 'ทีมแดง') : '',
                    is_bot: true,
                    is_awakened: false,
                    color: pIdx === 1 ? 0xf43f5e : (pIdx === 2 ? 0xffd700 : 0xa855f7),
                    char_grade: 'A+',
                    dice_control_rate: 20,
                    win_rate_bonus: 15,
                    roll_rate: 20,
                    play_skill_rate: 12,
                    skill: { code: 'PULL_BACK_5', power: 5 }
                });
            }
        }

        while (this.pawnsGroup.children.length > 0) {
            this.pawnsGroup.remove(this.pawnsGroup.children[0]);
        }
        this.players = [];

        if (options.clearLog !== false) {
            const feed = document.getElementById('log-feed');
            if (feed) feed.innerHTML = '';
        }

        const defaultColors = [0x00e5ff, 0xf43f5e, 0xffd700, 0xa855f7];
        const usedNames = [];
        const oppProfiles = (typeof window.pickUniqueOpponentProfiles === 'function')
            ? window.pickUniqueOpponentProfiles(safePlayersData.length, [safePlayersData[0]?.username || ''])
            : [];

        safePlayersData.forEach((p, idx) => {
            const color = p.color || defaultColors[idx % defaultColors.length];
            const isAwakened = Boolean(p.is_awakened);

            // ตรวจสอบไม่ให้มีข้อความคำว่า "บอท" / "AI" หากมีชื่ออยู่แล้วให้ล็อกชื่อเดิมไว้จนจบเกม
            if (p.is_bot && oppProfiles.length > 0) {
                const prof = oppProfiles[idx % oppProfiles.length];
                const isLegacy = typeof window.isLegacyBotDisplayName === 'function'
                    ? window.isLegacyBotDisplayName(p.username)
                    : /บอท|🤖|\(AI\)/i.test(String(p.username || ''));
                if (isLegacy || !p.username) {
                    p.username = prof.username;
                }
                if (!p.avatar_url || !p.picture || String(p.avatar_url).includes('google_avatar') || String(p.avatar_url).includes('unsplash.com')) {
                    p.avatar_url = prof.avatar_url;
                    p.picture = prof.picture;
                }
            }
            if (p.username) usedNames.push(p.username);

            const pawnGroup = this.createPawnMesh(color, isAwakened, p);
            this.pawnsGroup.add(pawnGroup);

            const botSkins = ['AuroraCrystalDice', 'EmperorGoldDice', 'CyberNeonDice', 'RubyFireDice'];
            const botDiceNames = [
                'ลูกเต๋าคริสตัลออโรร่า 3D',
                'ลูกเต๋าทองคำจักรพรรดิ 3D',
                'ลูกเต๋าไซเบอร์นีออน 3D',
                'ลูกเต๋าทับทิมเพลิงมังกร 3D'
            ];

            const pSkin = p.dice_skin || (p.is_bot 
                ? botSkins[idx % botSkins.length] 
                : (window.DEFAULT_USER?.dice_skin || 'ClassicWoodDice'));
            const pDiceName = p.dice_name || (p.is_bot 
                ? botDiceNames[idx % botDiceNames.length] 
                : (window.DEFAULT_USER?.equipped_dice_name || 'ลูกเต๋าไม้คลาสสิก 3D'));

            const isHuman = !p.is_bot;
            const u = window.DEFAULT_USER || {};
            const realPlayerName = isHuman ? (u.displayName || u.name || u.username || 'ผู้เล่น') : p.username;
            let finalName = isHuman ? realPlayerName : (p.username || 'ผู้เล่น');
            if (isHuman && (finalName === 'เขียนศักดิ์' || finalName === 'ผู้เล่น' || finalName === 'Google Player')) {
                finalName = realPlayerName;
            }

            const playerObj = {
                ...p,
                username: finalName,
                mesh: pawnGroup,
                currentTile: 1,
                color: color,
                isAwakened: isAwakened,
                jailTurns: 0,
                consecutiveDoubles: 0,
                matchGold: (p.matchGold !== undefined) ? Number(p.matchGold) : this.matchConfig.start_match_gold,
                isBankrupt: Boolean(p.isBankrupt),
                loanCount: Number(p.loanCount || 0),
                win_rate_bonus: Number(p.win_rate_bonus ?? (p.is_bot ? 12 : (window.DEFAULT_USER?.win_rate_bonus ?? 25))),
                roll_rate: Number(p.roll_rate ?? (p.is_bot ? 20 : (window.DEFAULT_USER?.roll_rate ?? 35))),
                play_skill_rate: Number(p.play_skill_rate ?? (p.is_bot ? 15 : (window.DEFAULT_USER?.play_skill_rate ?? 25))),
                char_grade: p.char_grade || (p.is_bot ? 'A+' : (window.DEFAULT_USER?.char_grade || 'S')),
                dice_skin: pSkin,
                dice_name: pDiceName,
                skill: p.skill || { code: 'PULL_BACK_5', power: 5 }
            };

            this.setPawnPosition(playerObj, 1, idx);
            this.players.push(playerObj);
        });

        this.isGameOver = false;
        this.isRolling = false;
        this.currentTurnIndex = (typeof options.startTurnIndex === 'number' && options.startTurnIndex >= 0 && options.startTurnIndex < this.players.length)
            ? options.startTurnIndex
            : 0;
        this.isAutoMode = false;
        this.isMatchActive = options.autoStart !== false;
        this.clearTurnTimers();

        if (this.isMatchActive) {
            this.matchStartTime = Date.now();
            this.matchTimeRemaining = 600;
        }

        this.updateMatchWealthHUD();

        if (this.isMatchActive) {
            this.logMessage(`💰 เงินทองเริ่มต้นในกระดานคนละ ${this.formatCompactGold(this.matchConfig.start_match_gold)} (${this.matchConfig.start_match_gold.toLocaleString()} ทอง)! สร้างได้สูงสุด 3 เมือง & อัปแลนด์มาร์คคูณ X2-X8!`, 'highlight');
            this.startMatchTimer(this.matchStartTime);
            this.beginTurn();
            // บันทึกสถานะเฉพาะเมื่อเริ่มการแข่งขันจริง
            this.saveGameState();
        } else {
            this.updateActiveTurnUI();
            this.updateAutoToggleUI();
        }

        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }
    }

    /**
     * บันทึกสถานะการเล่นลง LocalStorage อัตโนมัติ (เฉพาะการแข่งขันห้องจริงที่เริ่มเล่นแล้ว)
     */
    saveGameState() {
        if (!this.isMatchActive || this.isGameOver || !this.players || this.players.length === 0) {
            return;
        }
        if (!window.currentRoomId) {
            window.currentRoomId = this.matchConfig?.roomId || ('room_' + Date.now());
        }
        try {
            const effectiveMode = this.matchConfig?.gameMode || window.currentActiveGameMode || (this.players.length === 2 ? '2P' : (this.players.length === 3 ? '3P' : '4P'));
            const state = {
                userId: window.DEFAULT_USER?.id || null,
                roomId: window.currentRoomId,
                gameMode: effectiveMode,
                isPracticeMatch: Boolean(window.isPracticeMatch),
                boardTheme: this.boardTheme,
                currentTurnIndex: this.currentTurnIndex,
                isAutoMode: Boolean(this.isAutoMode),
                consecutiveDoubles: this.consecutiveDoubles || 0,
                isGameOver: this.isGameOver,
                tileProvinces: this.tileProvinces,
                matchConfig: { ...this.matchConfig, roomId: window.currentRoomId, gameMode: effectiveMode },
                cityStates: this.cityStates,
                timestamp: Date.now(),
                matchStartTime: this.matchStartTime || (Date.now() - (600 - (this.matchTimeRemaining || 600)) * 1000),
                matchTimeRemaining: this.matchTimeRemaining ?? 600,
                players: this.players.map(p => ({
                    id: p.id,
                    username: p.username,
                    avatar_url: p.avatar_url || p.picture || '',
                    picture: p.picture || p.avatar_url || '',
                    team: p.team || 'NONE',
                    team_name: p.team_name || '',
                    color: p.color,
                    is_bot: Boolean(p.is_bot),
                    is_awakened: Boolean(p.is_awakened),
                    skill: p.skill,
                    dice_control_rate: p.dice_control_rate,
                    win_rate_bonus: p.win_rate_bonus,
                    roll_rate: p.roll_rate,
                    play_skill_rate: p.play_skill_rate,
                    char_grade: p.char_grade,
                    matchGold: p.matchGold,
                    isBankrupt: Boolean(p.isBankrupt),
                    currentTile: p.currentTile,
                    jailTurns: p.jailTurns,
                    consecutiveDoubles: p.consecutiveDoubles
                })),
                recentLogs: this.getRecentLogs()
            };
            const json = JSON.stringify(state);
            localStorage.setItem('snake_active_session', json);
            if (state.userId) {
                localStorage.setItem(`snake_active_session_user_${state.userId}`, json);
            }
        } catch (e) {
            console.warn('saveGameState error:', e);
        }
    }

    clearSavedSession() {
        try {
            localStorage.removeItem('snake_active_session');
        } catch (e) {}
    }

    getRecentLogs() {
        try {
            const feed = document.getElementById('log-feed');
            if (!feed) return [];
            const items = feed.querySelectorAll('.log-item');
            const logs = [];
            items.forEach(it => {
                logs.push({ text: it.innerText, className: it.className });
            });
            return logs.slice(-20);
        } catch (e) {
            return [];
        }
    }

    restoreRecentLogs(logs) {
        try {
            const feed = document.getElementById('log-feed');
            if (!feed || !Array.isArray(logs)) return;
            feed.innerHTML = '';
            logs.forEach(item => {
                const div = document.createElement('div');
                div.className = item.className || 'log-item';
                div.innerText = item.text || '';
                feed.appendChild(div);
            });
            feed.scrollTop = feed.scrollHeight;
        } catch (e) {}
    }

    restoreGameState() {
        const raw = localStorage.getItem('snake_active_session');
        if (!raw) return false;
        try {
            const saved = JSON.parse(raw);
            if (!saved || !saved.players || saved.players.length === 0) return false;

            this.clearAllCities3D();
            if (saved.matchConfig) {
                this.matchConfig = { ...this.matchConfig, ...saved.matchConfig };
            }

            while (this.pawnsGroup.children.length > 0) {
                this.pawnsGroup.remove(this.pawnsGroup.children[0]);
            }
            this.players = [];

            // ตรวจสอบและซ่อมแซมจำนวนผู้เล่นหากน้อยกว่าโหมดที่เล่น (เช่น เดี่ยว 4 หรือ ทีม ต้องมี 4 คนเสมอ!)
            const targetMode = saved.matchConfig?.gameMode || saved.gameMode || window.currentActiveGameMode || (saved.players.length >= 4 ? '4P' : (saved.players.length === 3 ? '3P' : '2P'));
            const expectedCount = (targetMode === '2P') ? 2 : ((targetMode === '3P') ? 3 : 4);
            if (saved.players.length < expectedCount) {
                const missing = expectedCount - saved.players.length;
                const used = saved.players.map(p => p.username || '');
                const extra = (typeof window.pickUniqueOpponentProfiles === 'function')
                    ? window.pickUniqueOpponentProfiles(missing, used)
                    : [];
                for (let i = 0; i < missing; i++) {
                    const prof = extra[i] || { username: `คู่แข่ง #${saved.players.length + 1}`, avatar_url: 'avatars/google_avatar.png' };
                    const pIdx = saved.players.length;
                    saved.players.push({
                        id: 901 + pIdx,
                        username: prof.username,
                        avatar_url: prof.avatar_url,
                        picture: prof.avatar_url,
                        team: targetMode === 'TEAM' ? ((pIdx % 2 === 0) ? 'A' : 'B') : 'NONE',
                        is_bot: true,
                        is_awakened: false,
                        currentTile: 1,
                        matchGold: saved.matchConfig?.start_match_gold || 2000000,
                        isBankrupt: false,
                        dice_control_rate: 20,
                        win_rate_bonus: 15,
                        roll_rate: 20,
                        play_skill_rate: 12,
                        char_grade: 'A+',
                        color: pIdx === 1 ? 0xf43f5e : (pIdx === 2 ? 0xffd700 : 0xa855f7)
                    });
                }
            }

            saved.players.forEach((p, idx) => {
                if (p.is_bot && (String(p.avatar_url).includes('unsplash.com') || String(p.avatar_url).includes('google_avatar'))) {
                    const fallbackUrl = (typeof window.getDeterministicRealisticAvatar === 'function')
                        ? window.getDeterministicRealisticAvatar(p.username || `bot_${idx}`, idx)
                        : `avatars/bots/bot_${idx % 2 === 0 ? 'f' : 'm'}01.jpg`;
                    p.avatar_url = fallbackUrl;
                    p.picture = fallbackUrl;
                }
                const color = p.color || 0x00e5ff;
                const isAwakened = Boolean(p.is_awakened);
                const pawnGroup = this.createPawnMesh(color, isAwakened, p);
                pawnGroup.visible = !p.isBankrupt;
                this.pawnsGroup.add(pawnGroup);

                const playerObj = {
                    ...p,
                    mesh: pawnGroup,
                    currentTile: p.currentTile || 1,
                    color: color,
                    isAwakened: isAwakened,
                    jailTurns: p.jailTurns || 0,
                    consecutiveDoubles: p.consecutiveDoubles || 0,
                    matchGold: (p.matchGold !== undefined) ? Number(p.matchGold) : (this.matchConfig.start_match_gold || 2000000),
                    isBankrupt: Boolean(p.isBankrupt),
                    skill: p.skill || { code: 'PULL_BACK_5', power: 5 }
                };

                this.setPawnPosition(playerObj, p.currentTile || 1, idx);
                this.players.push(playerObj);
            });

            if (saved.cityStates && typeof saved.cityStates === 'object') {
                this.cityStates = saved.cityStates;
                this.rebuildAllCities3D();
            }
            this.updateMatchWealthHUD();

            window.currentRoomId = saved.roomId || window.currentRoomId || ('room_' + Date.now());
            window.isPracticeMatch = false;
            window.currentActiveGameMode = targetMode;

            this.isGameOver = false;
            this.isRolling = false;
            this.isMatchActive = true;
            this.currentTurnIndex = (saved.currentTurnIndex >= 0 && saved.currentTurnIndex < this.players.length) ? saved.currentTurnIndex : 0;
            this.consecutiveDoubles = saved.consecutiveDoubles || 0;
            // เปิดโหมด AUTO เพื่อให้เกมรันต่อทันที และผู้เล่นสามารถแตะปุ่มทอยเพื่อกลับมาเล่นเองได้ทุกเมื่อ
            this.isAutoMode = Boolean(saved.isAutoMode ?? true);

            // คืนค่า Log ล่าสุด
            if (saved.recentLogs && saved.recentLogs.length > 0) {
                this.restoreRecentLogs(saved.recentLogs);
            }

            // คำนวณเวลาการแข่งขันที่ผ่านไป (10 นาที หรือ 600 วินาที)
            const matchStart = Number(saved.matchStartTime || saved.timestamp || Date.now());
            this.matchStartTime = matchStart;
            const elapsedSinceStart = Math.floor((Date.now() - matchStart) / 1000);

            // หากผ่านไปเกิน 10 นาทีแล้ว (เช่น ผู้เล่นหลุดไป 30 นาที) ให้ตัดจบตัดสินผู้ชนะด้วยสินทรัพย์ทันที!
            if (elapsedSinceStart >= 600) {
                this.matchTimeRemaining = 0;
                this.updateMatchTimerHUD();
                setTimeout(() => {
                    this.handleMatchTimeoutVictory();
                }, 400);
                return true;
            }

            // หากยังไม่หมด 10 นาที ให้เริ่มนับเวลาต่อตามเวลาจริงที่เหลือ
            this.startMatchTimer(matchStart);

            // หากมีหมากในกระดานที่ค้างอยู่บนช่องงูหรือบันได ให้ทำงานดึงตัวละครทันที!
            setTimeout(async () => {
                if (!this.isMatchActive) return;
                let triggeredAny = false;
                for (const p of this.players) {
                    if (this.ladders[p.currentTile] || this.snakes[p.currentTile] || (this.snakeTailToHead && this.snakeTailToHead[p.currentTile])) {
                        await this.checkAndTriggerBoardLinks(p);
                        triggeredAny = true;
                    }
                }
                if (triggeredAny) {
                    this.updateActiveTurnUI();
                    this.saveGameState();
                }
            }, 650);

            this.beginTurn();
            return true;
        } catch (e) {
            console.warn('restoreGameState error:', e);
            return false;
        }
    }

    /**
     * รองรับการพักหน้าจอ (Sleep / Tab change / Minimize)
     */
    handleVisibilityChange() {
        if (!this.isMatchActive) return;
        if (document.visibilityState === 'hidden') {
            this.saveGameState();
        } else if (document.visibilityState === 'visible') {
            if (this.clock) this.clock.getDelta();

            if (this.isMatchActive && !this.isGameOver) {
                // หากหน้าจอดับหรือหลุดไปขณะกำลังทอย ให้เคลียร์สถานะค้าง
                if (this.isRolling && !this.isDiceTumbling) {
                    this.isRolling = false;
                }
                // จัดตำแหน่งหมากให้ตรงกับช่องปัจจุบันทันที
                (this.players || []).forEach(p => {
                    if (p && !p.isBankrupt && p.currentTile) {
                        this.realignPawnsOnTile(p.currentTile);
                    }
                });
                const active = this.players[this.currentTurnIndex];
                if (active) {
                    if (active.is_bot) {
                        this.clearTurnTimers();
                        this.autoTurnTimeout = setTimeout(() => {
                            if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                                this.rollDice();
                            }
                        }, 500);
                    } else if (!this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        this.beginTurn();
                    }
                }
            }
        }
    }

    async animate3DDiceTumble(targetD1, targetD2) {
        this.isDiceTumbling = true;
        if (window.soundEngine && typeof window.soundEngine.playDiceRoll === 'function') {
            window.soundEngine.playDiceRoll();
        }
        const duration = 1200;
        const startTime = performance.now();

        const faceRotations = {
            1: new THREE.Euler(0, 0, Math.PI / 2),
            2: new THREE.Euler(0, 0, 0),
            3: new THREE.Euler(-Math.PI / 2, 0, 0),
            4: new THREE.Euler(Math.PI / 2, 0, 0),
            5: new THREE.Euler(Math.PI, 0, 0),
            6: new THREE.Euler(0, 0, -Math.PI / 2)
        };

        const targetRot1 = faceRotations[targetD1] || new THREE.Euler(0, 0, 0);
        const targetRot2 = faceRotations[targetD2] || new THREE.Euler(0, 0, 0);

        if (document.hidden || this._fastSimulationActive) {
            this.diceMesh1.position.set(-3.5, 2.2, 32.5);
            this.diceMesh2.position.set(3.5, 2.2, 32.5);
            this.diceMesh1.rotation.copy(targetRot1);
            this.diceMesh2.rotation.copy(targetRot2);
            this.isDiceTumbling = false;
            return Promise.resolve();
        }

        return new Promise(resolve => {
            const animateStep = (time) => {
                const elapsed = time - startTime;
                const progress = Math.min(elapsed / duration, 1);

                if (progress < 1) {
                    this.diceMesh1.position.y = 3.2 + Math.sin(progress * Math.PI * 3) * 6.0;
                    this.diceMesh2.position.y = 3.2 + Math.sin(progress * Math.PI * 3.5) * 6.5;
                    this.diceMesh1.position.z = 32.5;
                    this.diceMesh2.position.z = 32.5;

                    this.diceMesh1.rotation.x += 0.45;
                    this.diceMesh1.rotation.y += 0.55;
                    this.diceMesh1.rotation.z += 0.35;

                    this.diceMesh2.rotation.x -= 0.5;
                    this.diceMesh2.rotation.y += 0.4;
                    this.diceMesh2.rotation.z += 0.6;

                    requestAnimationFrame(animateStep);
                } else {
                    this.diceMesh1.position.set(-3.5, 2.2, 32.5);
                    this.diceMesh2.position.set(3.5, 2.2, 32.5);
                    this.diceMesh1.rotation.copy(targetRot1);
                    this.diceMesh2.rotation.copy(targetRot2);
                    this.isDiceTumbling = false;
                    if (window.soundEngine && typeof window.soundEngine.playDiceLand === 'function') {
                        window.soundEngine.playDiceLand();
                    }
                    resolve();
                }
            };
            requestAnimationFrame(animateStep);
        });
    }

    async rollDice(forcedValues = null, isAuto = false) {
        if (!this.isMatchActive || this.isRolling || this.isGameOver || this.isWaitingForGamble || this.isWaitingForCityAction) return;
        const player = this.players[this.currentTurnIndex];
        if (!player || player.isBankrupt) return;

        this.clearTurnTimers();
        this.isRolling = true;

        // Watchdog: ป้องกันค้างไม่ให้ทอยไม่ได้ถาวร (ถ้าค้างเกิน 8 วินาทีให้ปลดล็อคเริ่มตาใหม่ทันที)
        if (this._rollingWatchdog) clearTimeout(this._rollingWatchdog);
        this._rollingWatchdog = setTimeout(() => {
            if (this.isRolling) {
                console.warn('Watchdog: isRolling stuck >8s, auto recovering...');
                this.isRolling = false;
                this.isDiceTumbling = false;
                this.isWaitingForCityAction = false;
                this.isWaitingForGamble = false;
                this.beginTurn();
            }
        }, 8000);

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            if (this.isAutoMode && !player.is_bot) {
                // ให้ปุ่มกดได้ตลอดเวลาเพื่อแตะยกเลิก AUTO และกลับมาเล่นเองได้ทันทีแม้ระหว่างกำลังทอย
                rollBtn.disabled = false;
                rollBtn.classList.add('auto-active');
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>⚡</span> AUTO`;
            } else {
                rollBtn.disabled = true;
                rollBtn.innerHTML = `<span>🎲</span> รอ...`;
            }
        }

        try {
            let d1 = forcedValues ? forcedValues[0] : Math.floor(Math.random() * 6) + 1;
            let d2 = forcedValues ? forcedValues[1] : Math.floor(Math.random() * 6) + 1;

            const diceControlRate = player.dice_control_rate || 20;
            if (!forcedValues && Math.random() * 100 < diceControlRate) {
                this.showSkillBanner(`🎲 สกิลทอยแม่นยำทำงาน! (${diceControlRate}%)`);
                this.logMessage(`🎲 ${player.username} ควบคุมพลังลูกเต๋าแม่นยำ!`, 'skill');
            }

            await this.animate3DDiceTumble(d1, d2);

            const dice1El = document.getElementById('dice-1');
            const dice2El = document.getElementById('dice-2');
            if (dice1El) dice1El.innerText = d1;
            if (dice2El) dice2El.innerText = d2;

            const total = d1 + d2;
            const isDouble = (d1 === d2);

            const dName = player.dice_name || (window.DICE_SKIN_PRESETS && window.DICE_SKIN_PRESETS[player.dice_skin]?.name) || 'ลูกเต๋า 3D';
            const autoTag = (!player.is_bot && (isAuto || this.isAutoMode)) ? ' ⚡[AUTO]' : '';
            this.logMessage(`🎲 ${player.username}${autoTag} ใช้ [${dName}] ทอยได้ [${d1}] + [${d2}] = ${total} ${isDouble ? '🔥 แต้มเบิ้ล!' : ''}`, isDouble ? 'highlight' : '');

            if (player.jailTurns > 0) {
                if (isDouble) {
                    player.jailTurns = 0;
                    this.showSkillBanner(`🎉 ${player.username} ทอยได้แต้มเบิ้ล [${d1}][${d2}]! หลบหนีออกจากเกาะร้างสำเร็จ!`);
                    this.logMessage(`🎉 ${player.username} ทอยได้แต้มเบิ้ล [${d1}][${d2}]! หลบหนีออกจากเกาะร้างสำเร็จ!`, 'highlight');
                    await this.movePlayer(player, total);
                } else {
                    player.jailTurns--;
                    if (player.jailTurns <= 0) {
                        player.jailTurns = 0;
                        this.showSkillBanner(`🔓 ${player.username} ครบกำหนดติดเกาะร้างแล้ว!`);
                        this.logMessage(`🔓 ${player.username} ครบกำหนด 2 ตา พ้นโทษเกาะร้างแล้ว! ในตาถัดไปจะทอยได้ตามปกติ`, 'highlight');
                    } else {
                        this.showSkillBanner(`⏳ ทอยไม่เบิ้ล [${d1}][${d2}]! ยังคงติดเกาะร้าง (เหลืออีก ${player.jailTurns} ตา)`);
                        this.logMessage(`⏳ ${player.username} ทอยได้ [${d1}][${d2}] ไม่ใช่แต้มเบิ้ล! ติดเกาะร้าง (เหลืออีก ${player.jailTurns} ตา หรือจ่ายเพื่อออก)`, 'highlight');
                    }
                    this.endTurn(false);
                    return;
                }
            } else {
                if (isDouble) {
                    player.consecutiveDoubles++;
                    this.logMessage(`🔥 ${player.username} ทอยเบิ้ลครั้งที่ ${player.consecutiveDoubles}!`, 'highlight');
                    if (player.consecutiveDoubles >= 3) {
                        player.consecutiveDoubles = 0;
                        this.sendToJail(player);
                        this.endTurn(false);
                        return;
                    }
                } else {
                    player.consecutiveDoubles = 0;
                }

                await this.movePlayer(player, total);
            }

            if (this.isGameOver) return;

            const hasExtraTurn = isDouble && !this.isGameOver && !player.isBankrupt && player.jailTurns === 0;
            if (hasExtraTurn) {
                this.logMessage(`⚡ ${player.username} ได้สิทธิ์ทอยเพิ่มอีก 1 ครั้งจากแต้มเบิ้ล!`, 'highlight');
            }

            this.endTurn(hasExtraTurn);
        } catch (e) {
            console.error('Error during rollDice:', e);
            this.endTurn(false);
        } finally {
            if (this._rollingWatchdog) {
                clearTimeout(this._rollingWatchdog);
                this._rollingWatchdog = null;
            }
            this.isRolling = false;
        }
    }

    async movePlayer(player, steps) {
        let targetTile = player.currentTile + steps;
        if (targetTile > 100) {
            const overshoot = targetTile - 100;
            targetTile = 100 - overshoot;
        }

        const startTile = player.currentTile;
        const stepDir = targetTile >= startTile ? 1 : -1;
        for (let t = startTile + stepDir; stepDir > 0 ? t <= targetTile : t >= targetTile; t += stepDir) {
            if (window.soundEngine && typeof window.soundEngine.playStep === 'function') {
                window.soundEngine.playStep();
            }
            await this.animatePawnToTile(player, t, 220);
        }
        player.currentTile = targetTile;
        this.updateActiveTurnUI();
        this.checkNearFinishAlerts();

        if (player.currentTile === 100) {
            this.handleVictory(player, 'FINISH_LINE');
            return;
        }

        if (this.ladders[player.currentTile]) {
            const ladderEnd = this.ladders[player.currentTile];
            if (window.soundEngine && typeof window.soundEngine.playLadder === 'function') {
                window.soundEngine.playLadder();
            }
            this.logMessage(`🪜 ${player.username} เจอช่องบันได! ไต่ขึ้นจาก ${player.currentTile} ไป ${ladderEnd}!`, 'highlight');
            await this.animatePawnToTile(player, ladderEnd, 900);
            player.currentTile = ladderEnd;
            this.checkNearFinishAlerts();
        }

        if (this.snakes[player.currentTile]) {
            if (player.skill && player.skill.code === 'SHIELD_TRAP' && Math.random() < 0.5) {
                this.showSkillBanner(`🛡️ โล่ทองคำป้องกันงูทำงาน! ยกเลิกการสไลด์ลง!`);
                this.logMessage(`🛡️ ${player.username} ใช้เกราะป้องกันกับดักงูสำเร็จ!`, 'skill');
            } else {
                const snakeEnd = this.snakes[player.currentTile];
                if (window.soundEngine && typeof window.soundEngine.playSnake === 'function') {
                    window.soundEngine.playSnake();
                }
                this.logMessage(`🐍 ${player.username} ตกช่องงู! สไลด์ลงจาก ${player.currentTile} ไป ${snakeEnd}...`, 'highlight');
                await this.animatePawnToTile(player, snakeEnd, 900);
                player.currentTile = snakeEnd;
                this.checkNearFinishAlerts();
            }
        }

        if (player.currentTile === 100) {
            this.handleVictory(player, 'FINISH_LINE');
            return;
        }

        // 🚨 ตรวจสอบการตกช่องเกาะร้าง (Jail Tile)
        if (player.currentTile === this.jailTile) {
            player.jailTurns = 2;
            player.consecutiveDoubles = 0;
            this.showSkillBanner(`🚨 ${player.username} ตกช่องเกาะร้าง! ติดเกาะร้าง 2 ตา!`);
            this.logMessage(`🚨 ${player.username} ตกช่องเกาะร้าง! ต้องติดเกาะร้าง 2 ตา (งดทอยในตานี้)`, 'highlight');
            if (typeof window.closeModal === 'function') {
                window.closeModal('modal-jail');
            }
            // หลังติดเกาะร้าง ให้งดทอย และให้คนอื่นทอยต่อไปทันที
            this.endTurn(false);
            return;
        }

        // Special tile events
        if (this.chanceTiles.includes(player.currentTile)) {
            await this.handleChanceTile(player);
            if (this.isGameOver || player.isBankrupt) return;
            if (player.currentTile === 100) {
                this.handleVictory(player, 'FINISH_LINE');
                return;
            }
        } else if (this.taxTiles.includes(player.currentTile)) {
            await this.handleTaxTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.gambleTiles.includes(player.currentTile)) {
            await this.handleGambleTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        } else if (this.destroyTiles && this.destroyTiles.includes(player.currentTile)) {
            await this.handleDestroySkillTile(player);
            if (this.isGameOver || player.isBankrupt) return;
        }

        // ระบบเมือง 1-3 หลัง, แลนด์มาร์ค, เก็บค่าผ่านทาง, ซื้อต่อเมือง และคูณ X2/X4/X6/X8
        if (!this.isGameOver && !player.isBankrupt && this.isBuildableTile(player.currentTile)) {
            await this.handleCityTileLanding(player);
            if (this.isGameOver || player.isBankrupt) return;
        }

        this.checkOpponentCollision(player);
    }

    checkOpponentCollision(activePlayer) {
        if (!activePlayer || activePlayer.isBankrupt) return;
        const currentTile = activePlayer.currentTile;
        const opponents = this.players.filter(
            p => p.id !== activePlayer.id && !p.isBankrupt && p.currentTile === currentTile && p.currentTile > 1
        );

        if (opponents.length === 0) return;

        // หากช่องนี้มีเมืองและเป็นของฝ่ายตรงข้าม เจ้าของเมืองจะได้รับการปกป้อง (ไม่โดนดึงถอยหลังเด็ดขาด)
        const cityOwnerId = this.cityStates[currentTile]?.ownerId;

        const skill = activePlayer.skill || {};
        let pullBackTiles = (skill.code === 'PULL_BACK_8' || activePlayer.isAwakened) ? 8 : 5;

        opponents.forEach(async (opp) => {
            // หาก opp เป็นเจ้าของเมืองนี้ ไม่สามารถดึงเจ้าของเมืองถอยหลังได้
            if (cityOwnerId && String(cityOwnerId) === String(opp.id)) return;

            // หากเป็นเพื่อนร่วมทีมกัน ไม่ดึงเพื่อนถอยหลัง
            if (activePlayer.team && activePlayer.team !== 'NONE' && activePlayer.team === opp.team) return;

            this.showSkillBanner(`⚡ สกิล ${activePlayer.username} ทำงาน! ดึง ${opp.username} ถอยหลัง ${pullBackTiles} ช่อง!`);
            this.logMessage(`⚡ สกิลพิเศษ! ${activePlayer.username} ดึง ${opp.username} ถอยหลัง ${pullBackTiles} ช่อง!`, 'skill');

            const newTile = Math.max(1, opp.currentTile - pullBackTiles);
            await this.animatePawnToTile(opp, newTile, 750);
            opp.currentTile = newTile;
        });
    }

    sendToJail(player) {
        player.currentTile = this.jailTile;
        player.jailTurns = 2;
        player.consecutiveDoubles = 0;
        this.animatePawnToTile(player, this.jailTile, 750);
        this.showSkillBanner(`🚨 ${player.username} ทอยเบิ้ล 3 ครั้งติด! ส่งไปติดเกาะร้าง 2 ตา!`);
        this.logMessage(`🚨 ${player.username} ทำผิดกฎทอยเบิ้ล 3 ครั้ง ส่งไปติดเกาะร้าง 2 ตา (งดทอยในตานี้)!`, 'highlight');
        if (typeof window.closeModal === 'function') {
            window.closeModal('modal-jail');
        }
    }

    async handleChanceTile(player) {
        const bonusMatchGold = Math.round((this.matchConfig?.city_base_cost || 120000) * 1.25);
        const chances = [
            { text: 'โชคดี! ก้าวกระโดดพุ่งไปข้างหน้า 3 ช่อง', move: 3 },
            { text: `ได้รับโบนัสเงินทุนในกระดาน +${this.formatCompactGold(bonusMatchGold)}!`, matchGold: bonusMatchGold },
            { text: 'ติดหล่มทราย! ถอยหลัง 2 ช่อง', move: -2 }
        ];
        const card = chances[Math.floor(Math.random() * chances.length)];
        this.showSkillBanner(`🎁 ช่องดวง (Chance): ${card.text}`);
        this.logMessage(`🎁 ${player.username} ได้การ์ดดวง: ${card.text}`, 'highlight');

        if (card.matchGold) {
            player.matchGold = (Number(player.matchGold) || 0) + card.matchGold;
            this.updateMatchWealthHUD();
        }
        if (card.move) {
            const nextT = Math.max(1, Math.min(100, player.currentTile + card.move));
            await this.animatePawnToTile(player, nextT, 500);
            player.currentTile = nextT;
            this.checkNearFinishAlerts();
            await this.checkAndTriggerBoardLinks(player);
        }
    }

    getPawnFrontOffset(player, targetTileNum, explicitIndex) {
        const t = Math.min(Math.max(Number(targetTileNum) || 1, 1), 100);
        const idx = explicitIndex !== undefined ? explicitIndex : Math.max(0, this.players.indexOf(player));

        // ช่อง Start (1) และ เส้นชัย (100): ให้ตัวผู้เล่นหลักอยู่แถวหน้าเสมอ
        if (t === 1 || t === 100) {
            const startSlots = [
                { x: -0.95, z: 0.95 },
                { x: 0.95, z: 0.95 },
                { x: -0.95, z: -0.35 },
                { x: 0.95, z: -0.35 }
            ];
            return startSlots[idx % startSlots.length];
        }

        // นับจำนวนผู้เล่นที่ยืนอยู่ในช่องเดียวกัน (ไม่รวมคนล้มละลาย)
        const sameTilePlayers = (this.players || []).filter(
            p => p && !p.isBankrupt && (p === player || p.currentTile === t)
        );
        if (sameTilePlayers.length <= 1) {
            // ยืนคนเดียว: ยืนกึ่งกลางด้านหน้าสุดของช่อง (พ้นหน้าตึกเมือง/แลนด์มาร์ค 100%)
            return { x: 0, z: 1.52 };
        }

        // ยืนหลายคนในช่องเดียวกัน: เรียงแถวด้านหน้าช่อง (+z) โดยให้ตัวผู้เล่นเราอยู่หน้าสุดเสมอ
        sameTilePlayers.sort((a, b) => {
            if (Boolean(a.is_bot) !== Boolean(b.is_bot)) return a.is_bot ? 1 : -1;
            return this.players.indexOf(a) - this.players.indexOf(b);
        });
        const slotIdx = Math.max(0, sameTilePlayers.indexOf(player));
        const multiFrontSlots = [
            { x: -1.02, z: 1.58 },
            { x: 1.02, z: 1.58 },
            { x: -1.68, z: 1.05 },
            { x: 1.68, z: 1.05 }
        ];
        return multiFrontSlots[slotIdx % multiFrontSlots.length];
    }

    realignPawnsOnTile(tileNum, excludePlayer = null) {
        const t = Number(tileNum);
        if (!t || t < 1 || t > 100 || !this.tiles[t]) return;
        const tilePos = this.tiles[t];
        const baseY = (t === 1 || t === 100) ? 1.18 : 0.52;
        (this.players || []).forEach((p, idx) => {
            if (!p || p === excludePlayer || p.isBankrupt || p.currentTile !== t || !p.mesh) return;
            const off = this.getPawnFrontOffset(p, t, idx);
            p.mesh.position.set(tilePos.x + off.x, baseY, tilePos.z + off.z);
        });
    }

    async animatePawnToTile(player, targetTileNum, duration = 220) {
        const dest = this.tiles[targetTileNum];
        if (!dest || !player || !player.mesh) return;

        const prevTile = player.currentTile;
        player.currentTile = targetTileNum;
        if (prevTile && prevTile !== targetTileNum) {
            this.realignPawnsOnTile(prevTile, player);
        }

        // กระตุ้นเอฟเฟกต์เมืองและช่องกระดานนูนขึ้นเมื่อตัวละครวิ่งผ่าน (City & Tile Pop)
        this.triggerTileStepPop(targetTileNum);

        const idx = Math.max(0, this.players.indexOf(player));
        const offset = this.getPawnFrontOffset(player, targetTileNum, idx);
        const endPos = dest.clone();
        endPos.x += offset.x;
        endPos.z += offset.z;
        endPos.y = (targetTileNum === 1 || targetTileNum === 100) ? 1.18 : 0.52;

        if (document.hidden || duration === 0 || this._fastSimulationActive) {
            player.mesh.position.copy(endPos);
            this.realignPawnsOnTile(targetTileNum);
            return Promise.resolve();
        }

        return new Promise(resolve => {
            const startPos = player.mesh.position.clone();
            const startTime = performance.now();

            const step = (time) => {
                const elapsed = time - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const jumpArc = Math.sin(progress * Math.PI) * 2.05;

                player.mesh.position.lerpVectors(startPos, endPos, progress);
                player.mesh.position.y += jumpArc;

                if (progress < 1) {
                    requestAnimationFrame(step);
                } else {
                    player.mesh.position.copy(endPos);
                    this.realignPawnsOnTile(targetTileNum);
                    resolve();
                }
            };
            requestAnimationFrame(step);
        });
    }

    endTurn(hasExtraTurn = false) {
        this.isRolling = false;
        this.clearTurnTimers();
        if (this.isGameOver) return;

        const curr = this.players[this.currentTurnIndex];
        if (!hasExtraTurn || !curr || curr.isBankrupt) {
            let guard = 0;
            do {
                this.currentTurnIndex = (this.currentTurnIndex + 1) % this.players.length;
                guard++;
            } while (this.players[this.currentTurnIndex]?.isBankrupt && guard <= this.players.length);
        }

        this.updateMatchWealthHUD();
        this.saveGameState();
        this.beginTurn();
    }

    clearTurnTimers() {
        if (this.turnCountdownInterval) {
            clearInterval(this.turnCountdownInterval);
            this.turnCountdownInterval = null;
        }
        if (this.autoTurnTimeout) {
            clearTimeout(this.autoTurnTimeout);
            this.autoTurnTimeout = null;
        }
    }

    beginTurn() {
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();
        this.updateMatchWealthHUD();

        if (!this.isMatchActive || this.isGameOver || !this.players || this.players.length === 0) return;
        let active = this.players[this.currentTurnIndex];
        if (!active || active.isBankrupt) {
            const aliveIdx = this.players.findIndex(p => !p.isBankrupt);
            if (aliveIdx === -1) return;
            this.currentTurnIndex = aliveIdx;
            active = this.players[aliveIdx];
        }

        this.applyDiceSkinForPlayer(active);

        const rollBtn = document.getElementById('btn-roll-dice');

        // 🚨 หากถึงตาผู้เล่นที่ติดเกาะร้าง ให้แสดง popup นี้ขึ้นมาทันที!
        if (active.jailTurns > 0) {
            if (active.is_bot) {
                // บอทติดเกาะร้าง: ลุ้นทอยเบิ้ล
                if (rollBtn) {
                    rollBtn.disabled = true;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '0.6';
                    rollBtn.innerHTML = `<span>🏝️</span> เกาะร้าง...`;
                }
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && !this.isGameOver && !this.isRolling) {
                        this.rollDice();
                    }
                }, (document.hidden ? 500 : 1200));
                return;
            } else if (this.isAutoMode) {
                // โหมด AUTO: ผู้เล่นลุ้นทอยแต้มเบิ้ลอัตโนมัติ
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                }
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, (document.hidden ? 400 : 900));
                return;
            } else {
                // ผู้เล่นจริง (Human) ถึงตาเราทอย -> แสดง popup ติดเกาะร้างขึ้นมาทันที!
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>🏝️</span> เกาะร้าง`;
                }
                if (typeof window.openJailModal === 'function') {
                    window.openJailModal(active);
                }
                return;
            }
        }

        if (active.is_bot) {
            if (rollBtn) {
                if (this.isAutoMode) {
                    // ขณะติด AUTO อยู่ แม้เป็นตาคู่แข่ง ผู้เล่นก็สามารถแตะปุ่มเพื่อยกเลิก AUTO กลับมาเล่นเองในตาถัดไปได้ทันที
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                } else {
                    rollBtn.disabled = true;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '0.6';
                    rollBtn.innerHTML = `<span>🎲</span> รอ...`;
                }
            }
            this.autoTurnTimeout = setTimeout(() => {
                if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                    this.rollDice();
                }
            }, (document.hidden ? 500 : 1200));
        } else {
            // ตาของผู้เล่นจริง (Human) — ทั้งโหมดกดเล่นห้องแข่งขัน และโหมดทดลองเล่น
            if (this.isAutoMode) {
                // อยู่ในโหมด AUTO อยู่แล้ว -> เล่นต่อเนื่องอัตโนมัติจนกว่าผู้เล่นจะกดกลับมาเล่นเอง
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.add('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>⚡</span> AUTO`;
                }
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, (document.hidden ? 400 : 900));
            } else {
                // เริ่มนับถอยหลัง 7 วินาที
                this.turnSecondsLeft = 7;
                if (rollBtn) {
                    rollBtn.disabled = false;
                    rollBtn.classList.remove('auto-active');
                    rollBtn.style.opacity = '1';
                    rollBtn.innerHTML = `<span>🎲</span> ทอย <span class="roll-timer-badge">(7วิ)</span>`;
                }
                this.turnCountdownInterval = setInterval(() => {
                    if (!this.isMatchActive || this.isRolling || this.isGameOver || this.isWaitingForGamble || this.isWaitingForCityAction) {
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        return;
                    }
                    this.turnSecondsLeft--;
                    if (this.turnSecondsLeft > 0) {
                        if (rollBtn && !this.isAutoMode) {
                            rollBtn.innerHTML = `<span>🎲</span> ทอย <span class="roll-timer-badge">(${this.turnSecondsLeft}วิ)</span>`;
                        }
                    } else {
                        // เกิน 7 วินาทีไม่ได้กดทอย -> เปลี่ยนเป็นเล่น AUTO ทันที
                        clearInterval(this.turnCountdownInterval);
                        this.turnCountdownInterval = null;
                        this.enableAutoMode(true);
                    }
                }, 1000);
            }
        }
    }

    enableAutoMode(triggerRollNow = false) {
        this.isAutoMode = true;
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        // หากกำลังเปิดหน้าต่างเลือกสร้างเมือง/แลนด์มาร์คค้างอยู่ ให้ตัดสินใจอัตโนมัติทันที
        if (this.isWaitingForCityAction && this.activeCityActionResolver) {
            this.closeCityActionPrompt(this.cityActionAutoChoice);
        }

        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn) {
            rollBtn.disabled = false;
            rollBtn.classList.add('auto-active');
            rollBtn.style.opacity = '1';
            rollBtn.innerHTML = `<span>⚡</span> AUTO`;
        }

        this.logMessage('⚡ ระบบเปลี่ยนเป็นเล่นอัตโนมัติ (AUTO)', 'highlight');
        if (typeof this.showSkillBanner === 'function') {
            this.showSkillBanner('⚡ เข้าสู่โหมดเล่นอัตโนมัติ (AUTO)');
        }
        if (typeof window.showToast === 'function') {
            window.showToast('⚡ เข้าสู่โหมดเล่นอัตโนมัติ (AUTO)');
        }

        if (triggerRollNow) {
            const active = this.players[this.currentTurnIndex];
            if (active && !active.is_bot && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                this.rollDice(null, true);
            }
        }
    }

    disableAutoMode() {
        this.isAutoMode = false;
        this.clearTurnTimers();
        this.updateActiveTurnUI();
        this.updateAutoToggleUI();

        const rollBtn = document.getElementById('btn-roll-dice');
        const active = this.players ? this.players[this.currentTurnIndex] : null;
        if (rollBtn) {
            rollBtn.classList.remove('auto-active');
            if (!this.isMatchActive) {
                rollBtn.disabled = false;
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>🎲</span> ทอย`;
            } else if (active && active.is_bot) {
                rollBtn.disabled = true;
                rollBtn.style.opacity = '0.6';
                rollBtn.innerHTML = `<span>🎲</span> รอ...`;
            } else if (this.isRolling) {
                rollBtn.disabled = true;
                rollBtn.style.opacity = '0.7';
                rollBtn.innerHTML = `<span>🎲</span> เดิน...`;
            } else {
                rollBtn.disabled = false;
                rollBtn.style.opacity = '1';
                rollBtn.innerHTML = `<span>🎲</span> ทอย`;
            }
        }

        // 🚨 CRITICAL FIX: หากเป็นตาของบอทอยู่ ต้องตั้งเวลาให้บอททอยต่อทันที อย่าให้บอทค้าง!
        if (this.isMatchActive && active && active.is_bot && !this.isRolling && !this.isGameOver) {
            this.autoTurnTimeout = setTimeout(() => {
                if (this.isMatchActive && !this.isGameOver && !this.isRolling && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                    this.rollDice();
                }
            }, 600);
        }

        this.logMessage('🎮 ยกเลิกโหมด AUTO กลับสู่การเล่นด้วยตนเอง', 'highlight');
        if (typeof this.showSkillBanner === 'function') {
            this.showSkillBanner('🎮 สลับกลับมาเล่นด้วยตนเองแล้ว!');
        }
        if (typeof window.showToast === 'function') {
            window.showToast('🎮 สลับกลับมาเล่นด้วยตนเองแล้ว!');
        }
    }

    toggleAutoMode() {
        if (!this.isMatchActive) {
            if (typeof window.showToast === 'function') {
                window.showToast('🎮 กรุณากดปุ่ม "ทอย" หรือเข้า "ห้องแข่งขัน" ก่อนเปิดโหมด AUTO');
            }
            return;
        }
        if (this.isAutoMode) {
            this.disableAutoMode();
            const active = this.players[this.currentTurnIndex];
            if (active && !active.is_bot && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                this.beginTurn();
            }
        } else {
            this.enableAutoMode(false);
            const active = this.players[this.currentTurnIndex];
            if (active && !active.is_bot && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                this.autoTurnTimeout = setTimeout(() => {
                    if (this.isMatchActive && this.isAutoMode && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                        if (typeof window.closeModal === 'function') window.closeModal('modal-jail');
                        this.rollDice(null, true);
                    }
                }, 600);
            }
        }
    }

    updateAutoToggleUI() {
        const toggleBtn = document.getElementById('btn-auto-toggle');
        if (!toggleBtn) return;
        if (this.isMatchActive && this.isAutoMode) {
            toggleBtn.classList.add('active');
            toggleBtn.innerHTML = `<span>⚡</span> AUTO: เปิด`;
            toggleBtn.setAttribute('title', 'แตะเพื่อปิดโหมดเล่นอัตโนมัติ (กลับมาเล่นเอง)');
        } else {
            toggleBtn.classList.remove('active');
            toggleBtn.innerHTML = `<span>⚡</span> AUTO`;
            toggleBtn.setAttribute('title', this.isMatchActive ? 'แตะเพื่อเปิดโหมดเล่นอัตโนมัติ' : 'กดเริ่มเกมก่อนเพื่อใช้งานโหมดเล่นอัตโนมัติ');
        }
    }

    handleRollButtonClick() {
        if (!this.isMatchActive) {
            if (typeof window.openPracticeBoardSelectModal === 'function') {
                window.openPracticeBoardSelectModal();
            } else if (typeof window.startExplicitPracticeMatch === 'function') {
                window.startExplicitPracticeMatch();
            }
            return;
        }

        // 🚨 Watchdog / stuck recovery: หากผู้เล่นกดปุ่มทอย แล้วพบว่าสถานะทอยค้างโดยไม่มีการหมุนเต๋า ให้ปลดล็อคทันที
        if (this.isRolling && !this.isDiceTumbling) {
            console.warn('Force clearing stuck isRolling on player button click');
            this.isRolling = false;
        }

        const active = this.players[this.currentTurnIndex];
        if (active && active.jailTurns > 0 && !active.is_bot && !this.isAutoMode) {
            // หากติดเกาะร้างอยู่ เมื่อกดปุ่มทอย ให้เปิด popup เกาะร้าง
            if (typeof window.openJailModal === 'function') {
                window.openJailModal(active);
            }
            return;
        }

        if (this.isAutoMode) {
            // ผู้เล่นกลับมาเล่นแล้วกดปุ่มเพื่อเล่น -> ยกเลิก AUTO
            this.disableAutoMode();
            const activeNow = this.players[this.currentTurnIndex];
            if (activeNow && !activeNow.is_bot && !this.isRolling && !this.isGameOver && !this.isWaitingForGamble && !this.isWaitingForCityAction) {
                this.rollDice();
            } else if (activeNow && activeNow.is_bot) {
                if (typeof window.showToast === 'function') {
                    window.showToast('🎮 กำลังรอคู่แข่ง จะกลับมาเล่นเองในตาของคุณทันที!');
                }
            }
            return;
        }

        // กดทอยตามปกติ -> เคลียร์เวลานับถอยหลัง แล้วทอย
        this.clearTurnTimers();
        this.rollDice();
    }

    updateActiveTurnUI() {
        const turnEl = document.getElementById('turn-status-text');
        if (!this.isMatchActive) {
            if (turnEl) {
                turnEl.innerHTML = `พร้อมเริ่มเล่น <span style="font-size:12px;font-weight:normal;opacity:0.85;">(กด "ทดลองเล่น" หรือเลือก "ห้องแข่งขัน")</span>`;
                turnEl.style.color = '#38bdf8';
            }
            return;
        }
        const active = this.players[this.currentTurnIndex];
        if (!active) return;
        if (turnEl) {
            const teamBadge = active.team_name ? `[${active.team_name}] ` : '';
            const autoBadge = (!active.is_bot && this.isAutoMode) ? ' <span class="auto-turn-pill">⚡ AUTO</span>' : '';
            const goldBadge = active.matchGold !== undefined ? ` • 💰${this.formatCompactGold(active.matchGold)}` : '';
            if (active.jailTurns > 0) {
                turnEl.innerHTML = `<span style="color:#ef4444;font-weight:700;">🚨 ติดเกาะร้าง (เหลืออีก ${active.jailTurns} ตา): ${teamBadge}${active.username}${autoBadge}</span>`;
                turnEl.style.color = '#ef4444';
            } else {
                turnEl.innerHTML = `ตาของ: ${teamBadge}${active.username}${autoBadge} <span style="font-size:12px;font-weight:normal;opacity:0.9;">(ช่อง ${active.currentTile}: ${this.getProvinceName(active.currentTile)}${goldBadge})</span>`;
                turnEl.style.color = '#00e5ff';
            }
            turnEl.style.color = `#${active.color.toString(16).padStart(6, '0')}`;
        }
    }

    handleVictory(winner, winReason = 'FINISH_LINE') {
        if (this.isGameOver) return;
        this.isGameOver = true;
        this.isMatchActive = false;

        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }

        // จัดอันดับผู้เล่น 1-4 ตามสินทรัพย์รวม (ทอง + สิ่งก่อสร้าง) บันทึกไว้แสดงในตารางผลการแข่งขัน
        this.lastMatchRankedPlayers = (this.players && this.players.length > 0)
            ? [...this.players].sort((a, b) => {
                if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
                const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
                if (diff !== 0) return diff;
                return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
            }).map(p => ({
                id: p.id,
                username: p.username,
                avatar_url: p.avatar_url || p.picture || 'avatars/google_avatar.png',
                color: p.color,
                is_bot: p.is_bot,
                matchGold: p.matchGold,
                totalAssets: this.getPlayerTotalAssets(p),
                cityCounts: this.getPlayerCityCounts(p),
                isBankrupt: p.isBankrupt
            }))
            : [];

        this.clearTurnTimers();
        this.closeCityActionPrompt(null);
        this.clearSavedSession();
        if (this.isAutoMode) {
            this.isAutoMode = false;
            this.updateAutoToggleUI();
        }
        this.updateMatchWealthHUD();
        if (typeof window.updatePracticeExitButtonVisibility === 'function') {
            window.updatePracticeExitButtonVisibility();
        }

        if (window.soundEngine && typeof window.soundEngine.playWin === 'function') {
            window.soundEngine.playWin();
        }
        if (winReason === 'BANKRUPTCY') {
            this.showSkillBanner(`🏆 ${winner.username} ชนะล้มละลาย! คู่แข่งเงินหมดกระดาน!`);
            this.logMessage(`🏆 ${winner.username} คว้าชัยชนะแบบล้มละลายคู่แข่ง! เหลือรอดเป็นมหาเศรษฐีหนึ่งเดียว!`, 'highlight');
        } else if (winReason === 'TIME_OUT') {
            const winnerAssets = this.formatCompactGold(this.getPlayerTotalAssets(winner));
            this.showSkillBanner(`⏰ หมดเวลา 10 นาที! ${winner.username} ชนะด้วยสินทรัพย์รวมสูงสุด ${winnerAssets}!`);
            this.logMessage(`⏰ หมดเวลาการแข่งขัน 10 นาที! ${winner.username} คว้าชัยชนะด้วยทองและสิ่งก่อสร้างรวมสูงสุด (${winnerAssets})!`, 'highlight');
        } else {
            this.showSkillBanner(`🏆 ${winner.username} พิชิตเส้นชัยช่อง 100 ชนะการแข่งขัน!`);
            this.logMessage(`🏆 ${winner.username} พิชิตเส้นชัยช่อง 100 ชนะการแข่งขันสำเร็จ!`, 'highlight');
        }

        if (window.confetti) {
            window.confetti({ particleCount: 180, spread: 90, origin: { y: 0.6 } });
        }

        if (window.onGameFinished) {
            window.onGameFinished(winner, winReason);
        }
    }

    /**
     * สร้างแลนด์มาร์กจุดสตาร์ท 3D (ช่อง 1: Grand Start Circle Pad)
     * - แท่นพลาซ่าทรงกลมพร้อมขอบเรืองแสงนีออนสีฟ้า และข้อความ "START" / "🚩 จุดเริ่มต้น 🚩"
     */
    createStartPointLandmark(x, y, z) {
        const startGroup = new THREE.Group();
        startGroup.position.set(x, y, z);

        const baseGeo = new THREE.CylinderGeometry(4.8, 5.2, 0.7, 36);
        const baseMat = new THREE.MeshStandardMaterial({
            color: 0x07263e,
            metalness: 0.85,
            roughness: 0.25,
            emissive: 0x0284c7,
            emissiveIntensity: 0.35
        });
        const base = new THREE.Mesh(baseGeo, baseMat);
        base.position.y = 0.35;
        startGroup.add(base);

        const rimGeo = new THREE.TorusGeometry(5.0, 0.15, 16, 48);
        const rimMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.85 });
        const rim = new THREE.Mesh(rimGeo, rimMat);
        rim.rotation.x = Math.PI / 2;
        rim.position.y = 0.71;
        startGroup.add(rim);

        const startCanvas = document.createElement('canvas');
        startCanvas.width = 512;
        startCanvas.height = 512;
        const sCtx = startCanvas.getContext('2d');

        const bgGrad = sCtx.createRadialGradient(256, 256, 30, 256, 256, 256);
        bgGrad.addColorStop(0, '#0a365c');
        bgGrad.addColorStop(0.65, '#062038');
        bgGrad.addColorStop(1, '#020e1a');
        sCtx.fillStyle = bgGrad;
        sCtx.beginPath();
        sCtx.arc(256, 256, 250, 0, Math.PI * 2);
        sCtx.fill();

        sCtx.strokeStyle = '#00e5ff';
        sCtx.lineWidth = 10;
        sCtx.shadowColor = '#00e5ff';
        sCtx.shadowBlur = 24;
        sCtx.beginPath();
        sCtx.arc(256, 256, 240, 0, Math.PI * 2);
        sCtx.stroke();

        sCtx.save();
        sCtx.strokeStyle = '#38bdf8';
        sCtx.lineWidth = 4;
        sCtx.setLineDash([16, 12]);
        sCtx.shadowColor = '#38bdf8';
        sCtx.shadowBlur = 12;
        sCtx.beginPath();
        sCtx.arc(256, 256, 210, 0, Math.PI * 2);
        sCtx.stroke();
        sCtx.restore();

        sCtx.strokeStyle = 'rgba(0, 229, 255, 0.4)';
        sCtx.lineWidth = 3;
        sCtx.beginPath();
        sCtx.arc(256, 256, 175, 0, Math.PI * 2);
        sCtx.stroke();

        sCtx.font = '900 88px Kanit, Montserrat, Arial, sans-serif';
        sCtx.textAlign = 'center';
        sCtx.textBaseline = 'middle';
        sCtx.shadowColor = '#00e5ff';
        sCtx.shadowBlur = 30;
        sCtx.strokeStyle = '#00e5ff';
        sCtx.lineWidth = 8;
        sCtx.strokeText('START', 256, 220);

        sCtx.fillStyle = '#ffffff';
        sCtx.shadowBlur = 15;
        sCtx.fillText('START', 256, 220);

        sCtx.font = '700 34px Kanit, sans-serif';
        sCtx.shadowColor = '#0284c7';
        sCtx.shadowBlur = 16;
        sCtx.fillStyle = '#7dd3fc';
        sCtx.fillText('🚩 จุดเริ่มต้น 🚩', 256, 305);

        const startTex = new THREE.CanvasTexture(startCanvas);
        startTex.needsUpdate = true;

        const padGeo = new THREE.CircleGeometry(4.75, 48);
        const padMat = new THREE.MeshStandardMaterial({
            map: startTex,
            roughness: 0.25,
            metalness: 0.5,
            emissive: 0x0284c7,
            emissiveIntensity: 0.35,
            side: THREE.DoubleSide
        });
        const pad = new THREE.Mesh(padGeo, padMat);
        pad.rotation.x = -Math.PI / 2;
        pad.position.y = 0.72;
        startGroup.add(pad);

        const innerRingGeo = new THREE.TorusGeometry(3.6, 0.06, 8, 36);
        const innerRingMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending });
        const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
        innerRing.rotation.x = Math.PI / 2;
        innerRing.position.y = 0.73;
        startGroup.add(innerRing);

        const startLight = new THREE.PointLight(0x00e5ff, 2.0, 20);
        startLight.position.set(0, 2.5, 0);
        startGroup.add(startLight);

        this.boardGroup.add(startGroup);
        this.startAnimations = { rim, innerRing, light: startLight };
    }

    /**
     * เส้นชัย 3D (ช่อง 100): วิหารมหานครมรกต-ทองคำ + ซุ้มประตูชัย + ลำแสงทองพุ่งขึ้นฟ้า (ตรงตามรูป 1)
     */
    createGoalCityLandmark(x, y, z) {
        const goalGroup = new THREE.Group();
        goalGroup.position.set(x, y, z);

        // 1. ฐานพระนครมหาราชวังวงกลมขนาดใหญ่ + ขอบทองคำเรืองแสง
        const baseGeo = new THREE.CylinderGeometry(5.2, 5.6, 1.0, 32);
        const baseMat = new THREE.MeshStandardMaterial({
            color: 0x064e3b,
            metalness: 0.85,
            roughness: 0.2,
            emissive: 0x047857,
            emissiveIntensity: 0.35
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.y = 0.5;
        goalGroup.add(baseMesh);

        const trimGeo = new THREE.TorusGeometry(5.4, 0.18, 10, 48);
        const trimMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            metalness: 0.95,
            roughness: 0.1,
            emissive: 0xb45309,
            emissiveIntensity: 0.45
        });
        const trim = new THREE.Mesh(trimGeo, trimMat);
        trim.rotation.x = Math.PI / 2;
        trim.position.y = 0.95;
        goalGroup.add(trim);

        // โดมพลังงานทรงกระบอกโปร่งแสงโอบล้อมวิหาร
        const domeGeo = new THREE.CylinderGeometry(4.6, 5.1, 4.2, 32, 1, true);
        const domeMat = new THREE.MeshBasicMaterial({
            color: 0xfacc15,
            transparent: true,
            opacity: 0.24,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        const dome = new THREE.Mesh(domeGeo, domeMat);
        dome.position.y = 3.0;
        goalGroup.add(dome);

        // 2. ตึกระฟ้าจำลองมหานคร 4 มุม พร้อมเส้นขอบนีออนและยอดคริสตัล
        const towerConfigs = [
            { tx: -2.0, tz: -2.0, h: 5.5, w: 1.1, c: 0x0284c7 },
            { tx: 2.0, tz: -2.0, h: 7.0, w: 1.3, c: 0x06b6d4 },
            { tx: -2.2, tz: 1.6, h: 6.0, w: 1.2, c: 0x8b5cf6 },
            { tx: 2.2, tz: 1.6, h: 4.8, w: 1.0, c: 0x10b981 }
        ];

        towerConfigs.forEach(cfg => {
            const twGeo = new THREE.BoxGeometry(cfg.w, cfg.h, cfg.w);
            const twMat = new THREE.MeshStandardMaterial({
                color: cfg.c,
                metalness: 0.8,
                roughness: 0.2,
                emissive: cfg.c,
                emissiveIntensity: 0.28
            });
            const tower = new THREE.Mesh(twGeo, twMat);
            tower.position.set(cfg.tx, cfg.h / 2 + 0.8, cfg.tz);
            goalGroup.add(tower);

            const spireGeo = new THREE.ConeGeometry(0.35, 1.8, 6);
            const spireMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x00ffff, emissiveIntensity: 0.85 });
            const spire = new THREE.Mesh(spireGeo, spireMat);
            spire.position.set(cfg.tx, cfg.h + 1.7, cfg.tz);
            goalGroup.add(spire);

            const edgeG = new THREE.EdgesGeometry(twGeo);
            const edgeM = new THREE.LineBasicMaterial({ color: 0x00ffff });
            const wire = new THREE.LineSegments(edgeG, edgeM);
            wire.position.copy(tower.position);
            goalGroup.add(wire);
        });

        // 3. ซุ้มประตูวิหารทองคำด้านหน้า (Golden Front Gate)
        const gateGoldMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            metalness: 0.92,
            roughness: 0.15,
            emissive: 0x92400e,
            emissiveIntensity: 0.4
        });
        [-1.35, 1.35].forEach(px => {
            const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 3.4, 12), gateGoldMat);
            pillar.position.set(px, 2.5, 2.8);
            goalGroup.add(pillar);
        });
        const lintel = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.55, 0.55), gateGoldMat);
        lintel.position.set(0, 4.3, 2.8);
        goalGroup.add(lintel);

        // 4. พระเจดีย์ทองคำและเพชรชัยชนะลอยหมุนตรงกลาง
        const pagodaOrb = new THREE.Group();
        const pagodaSpire = new THREE.Mesh(new THREE.ConeGeometry(1.1, 4.2, 8), gateGoldMat);
        pagodaSpire.position.y = 3.2;
        pagodaOrb.add(pagodaSpire);
        goalGroup.add(pagodaOrb);

        const diamond = new THREE.Mesh(
            new THREE.OctahedronGeometry(0.75),
            new THREE.MeshBasicMaterial({ color: 0xfffbeb })
        );
        diamond.position.y = 6.2;
        goalGroup.add(diamond);

        // 5. วงแหวนเวทมนตร์สีทอง 2 ชั้น + ลำแสงสปอตไลท์ทองคำพุ่งทะลุฟ้า
        const auraRing1 = new THREE.Mesh(
            new THREE.TorusGeometry(5.85, 0.1, 8, 48),
            new THREE.MeshBasicMaterial({ color: 0xffea00, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending })
        );
        auraRing1.rotation.x = Math.PI / 2;
        auraRing1.position.y = 1.05;
        goalGroup.add(auraRing1);

        const auraRing2 = new THREE.Mesh(
            new THREE.TorusGeometry(4.1, 0.08, 8, 40),
            new THREE.MeshBasicMaterial({ color: 0xfff176, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending })
        );
        auraRing2.rotation.x = Math.PI / 2;
        auraRing2.position.y = 4.6;
        goalGroup.add(auraRing2);

        const beamGeo = new THREE.CylinderGeometry(3.8, 5.4, 44, 32, 1, true);
        const beamMat = new THREE.MeshBasicMaterial({
            color: 0xffd54f,
            transparent: true,
            opacity: 0.24,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });
        const beam = new THREE.Mesh(beamGeo, beamMat);
        beam.position.y = 22.8;
        goalGroup.add(beam);

        // แสงไฟสีทองส่องสว่างลงพื้นกระดานรอบเส้นชัยเหมือนรูป 1
        const goalLight = new THREE.PointLight(0xffca28, 3.2, 38);
        goalLight.position.set(0, 5.5, 2.0);
        goalGroup.add(goalLight);

        this.boardGroup.add(goalGroup);
        this.goalAnimations = {
            beam,
            auraRing1,
            auraRing2,
            pagodaOrb,
            diamond,
            light: goalLight
        };
    }

    /**
     * ตรวจสอบแหล่งรูปโปรไฟล์ของผู้เล่น (Google / LINE / Guest)
     */
    resolvePlayerAvatarInfo(playerData = {}) {
        const provRaw = String(
            playerData.auth_provider ||
            (playerData.line_id ? 'line' : (playerData.google_id ? 'google' : '')) ||
            window.DEFAULT_USER?.auth_provider ||
            localStorage.getItem('snake_auth_provider') ||
            ''
        ).toLowerCase();

        let provider = provRaw || 'guest';
        // ใช้รูปภาพของ playerData โดยตรงก่อนเสมอ เพื่อไม่ให้รูปโปรไฟล์ของไอดีก่อนหน้าติดค้าง
        let avatarUrl = playerData.avatar_url || playerData.pictureUrl || playerData.picture || '';
        if (!avatarUrl && typeof window.getActivePlayerAvatarUrl === 'function' && !playerData.is_bot) {
            avatarUrl = window.getActivePlayerAvatarUrl(playerData);
        }
        if (!avatarUrl) {
            avatarUrl = window.DEFAULT_USER?.avatar_url || window.DEFAULT_USER?.pictureUrl || window.DEFAULT_USER?.picture || 'avatars/avatar_01.svg';
        }

        return { provider, avatarUrl };
    }

    createPawnAuraRingTexture(hexColor = '#00e5ff', isHuman = true) {
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');
        const cx = 128;
        const cy = 128;

        // วงแสงฟุ้งรอบนอก
        const radGrad = ctx.createRadialGradient(cx, cy, 82, cx, cy, 126);
        radGrad.addColorStop(0, 'rgba(255,255,255,0)');
        radGrad.addColorStop(0.55, isHuman ? 'rgba(255, 215, 0, 0.35)' : 'rgba(56, 189, 248, 0.22)');
        radGrad.addColorStop(0.82, hexColor + '88');
        radGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = radGrad;
        ctx.fillRect(0, 0, 256, 256);

        // เส้นโค้งพลังงานเวทย์ 4 แฉก + ดาวเพชร 8 มุม
        ctx.save();
        ctx.translate(cx, cy);
        ctx.strokeStyle = isHuman ? '#fde047' : hexColor;
        ctx.shadowColor = hexColor;
        ctx.shadowBlur = 12;
        ctx.lineWidth = isHuman ? 6 : 4.5;
        for (let i = 0; i < 4; i++) {
            const startA = (i * Math.PI) / 2 + 0.14;
            const endA = startA + Math.PI / 2 - 0.28;
            ctx.beginPath();
            ctx.arc(0, 0, 108, startA, endA);
            ctx.stroke();
        }

        const starCount = isHuman ? 8 : 4;
        for (let i = 0; i < starCount; i++) {
            const ang = (i * Math.PI * 2) / starCount;
            const sx = Math.cos(ang) * 114;
            const sy = Math.sin(ang) * 114;
            ctx.fillStyle = i % 2 === 0 ? '#ffffff' : '#fde047';
            ctx.beginPath();
            ctx.arc(sx, sy, isHuman ? 5.5 : 4, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();

        const tex = new THREE.CanvasTexture(canvas);
        tex.anisotropy = 4;
        return tex;
    }

    drawPawnNameTagCanvas(canvas, username = '', hexColor = '#00e5ff', isBot = false) {
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        const cleanName = String(username || (isBot ? 'Player' : 'คุณ'))
            .replace(/🤖|บอท|\(AI\)/gi, '')
            .trim();
        const shortName = Array.from(cleanName).slice(0, 11).join('') + (Array.from(cleanName).length > 11 ? '…' : '');
        const label = isBot ? shortName : `👑 คุณ • ${shortName}`;

        ctx.save();
        ctx.shadowColor = isBot ? hexColor : '#fbbf24';
        ctx.shadowBlur = isBot ? 12 : 20;

        const bgGrad = ctx.createLinearGradient(20, 12, w - 20, 102);
        if (!isBot) {
            bgGrad.addColorStop(0, 'rgba(12, 24, 48, 0.96)');
            bgGrad.addColorStop(0.5, 'rgba(30, 58, 138, 0.96)');
            bgGrad.addColorStop(1, 'rgba(12, 24, 48, 0.96)');
        } else {
            bgGrad.addColorStop(0, 'rgba(9, 14, 28, 0.90)');
            bgGrad.addColorStop(1, 'rgba(18, 28, 48, 0.90)');
        }

        ctx.fillStyle = bgGrad;
        ctx.strokeStyle = !isBot ? '#ffd700' : hexColor;
        ctx.lineWidth = !isBot ? 6.5 : 4.5;
        ctx.beginPath();
        ctx.roundRect(24, 12, w - 48, 86, 43);
        ctx.fill();
        ctx.stroke();

        // ลูกศรชี้ลงตรงกลางหัวตัวหมาก
        ctx.beginPath();
        ctx.moveTo(w / 2 - 18, 98);
        ctx.lineTo(w / 2, 124);
        ctx.lineTo(w / 2 + 18, 98);
        ctx.closePath();
        ctx.fillStyle = !isBot ? '#ffd700' : hexColor;
        ctx.fill();
        ctx.restore();

        if (!isBot) {
            ctx.strokeStyle = 'rgba(0, 229, 255, 0.75)';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.roundRect(33, 21, w - 66, 68, 34);
            ctx.stroke();
        }

        ctx.fillStyle = !isBot ? '#fef08a' : '#f8fafc';
        ctx.font = !isBot ? '900 36px "Kanit", sans-serif' : '800 32px "Kanit", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,0.85)';
        ctx.shadowBlur = 6;
        ctx.fillText(label, w / 2, 56);
    }

    /**
     * สร้างหมากผู้เล่น 3D สุดเด่น (ฐานหมาก 3D เรืองแสง + วงเวทย์พื้น + เหรียญโปรไฟล์ลอยด้านหน้าสุดไม่โดนตึกบัง + มงกุฎ & ป้ายชื่อ "👑 คุณ")
     */
    createPawnMesh(color, isAwakened, playerData = {}) {
        const pawnGroup = new THREE.Group();
        const isBot = Boolean(playerData.is_bot);
        const rimColor = isAwakened ? 0x00e5ff : (color || 0x00e5ff);
        const hexStr = '#' + Number(rimColor).toString(16).padStart(6, '0');
        const baseRenderOrder = isBot ? 56 : 72;

        // 1. ฐานหมาก 3D เรืองแสงและวงแหวนเวทย์บนพื้นช่อง + ลำแสงสปอตไลท์
        const pedestalGroup = new THREE.Group();

        const groundAuraTex = this.createPawnAuraRingTexture(hexStr, !isBot);
        const groundAuraMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(isBot ? 2.75 : 3.45, isBot ? 2.75 : 3.45),
            new THREE.MeshBasicMaterial({
                map: groundAuraTex,
                transparent: true,
                opacity: isBot ? 0.72 : 0.95,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            })
        );
        groundAuraMesh.rotation.x = -Math.PI / 2;
        groundAuraMesh.position.y = 0.06;
        groundAuraMesh.renderOrder = 32;
        pedestalGroup.add(groundAuraMesh);

        const baseCyl = new THREE.Mesh(
            new THREE.CylinderGeometry(isBot ? 0.72 : 0.88, isBot ? 0.92 : 1.10, 0.28, 24),
            new THREE.MeshStandardMaterial({
                color: rimColor,
                emissive: rimColor,
                emissiveIntensity: isBot ? 0.65 : 0.95,
                metalness: 0.65,
                roughness: 0.18
            })
        );
        baseCyl.position.y = 0.16;
        pedestalGroup.add(baseCyl);

        const goldCollar = new THREE.Mesh(
            new THREE.CylinderGeometry(isBot ? 0.56 : 0.68, isBot ? 0.68 : 0.82, 0.18, 24),
            new THREE.MeshStandardMaterial({
                color: 0xffd700,
                emissive: 0xf59e0b,
                emissiveIntensity: 0.65,
                metalness: 0.9,
                roughness: 0.12
            })
        );
        goldCollar.position.y = 0.36;
        pedestalGroup.add(goldCollar);

        // ลำแสงออร่าส่องขึ้นรับตัวหมาก (สว่างเป็นพิเศษเมื่อถึงตาเดินหรือเป็นตัวผู้เล่นหลัก)
        const spotlightBeam = new THREE.Mesh(
            new THREE.CylinderGeometry(isBot ? 0.65 : 0.85, isBot ? 1.05 : 1.32, isBot ? 2.8 : 3.6, 20, 1, true),
            new THREE.MeshBasicMaterial({
                color: isBot ? rimColor : 0x00e5ff,
                transparent: true,
                opacity: isBot ? 0.10 : 0.24,
                side: THREE.DoubleSide,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            })
        );
        spotlightBeam.position.y = isBot ? 1.45 : 1.85;
        spotlightBeam.renderOrder = 33;
        pedestalGroup.add(spotlightBeam);

        pawnGroup.add(pedestalGroup);

        // 2. เหรียญโปรไฟล์ลอยเด่นด้านหน้าสุด (Foreground Priority: ไม่ถูกตึกเมือง/บันได/งูบัง)
        const badgeGroup = new THREE.Group();
        const baseFloatY = isBot ? 2.02 : 2.32;
        badgeGroup.position.y = baseFloatY;

        const discRadius = isBot ? 1.48 : 1.72;

        // วงแหวนพลังงานดาวหมุนรอบกรอบรูปตัวละคร
        const auraRingMat = new THREE.MeshBasicMaterial({
            map: groundAuraTex,
            transparent: true,
            opacity: isBot ? 0.82 : 1.0,
            depthTest: false,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
        const auraRingMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(discRadius * 2.75, discRadius * 2.75),
            auraRingMat
        );
        auraRingMesh.position.z = -0.04;
        auraRingMesh.renderOrder = baseRenderOrder - 1;
        badgeGroup.add(auraRingMesh);

        // วงแหวนเออร่าแจ้งเตือนใกล้ถึงเส้นชัย 5-8 ช่อง (Near Finish Alert Aura Disc)
        const nearFinishAuraMat = new THREE.MeshBasicMaterial({
            map: groundAuraTex,
            color: 0xffa500,
            transparent: true,
            opacity: 0,
            depthTest: false,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
        const nearFinishAura = new THREE.Mesh(
            new THREE.PlaneGeometry(discRadius * 3.4, discRadius * 3.4),
            nearFinishAuraMat
        );
        nearFinishAura.position.z = -0.06;
        nearFinishAura.renderOrder = baseRenderOrder - 2;
        nearFinishAura.visible = false;
        badgeGroup.add(nearFinishAura);

        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const avatarTex = new THREE.CanvasTexture(canvas);
        avatarTex.anisotropy = 8;

        const avatarMat = new THREE.MeshBasicMaterial({
            map: avatarTex,
            transparent: true,
            alphaTest: 0.05,
            depthTest: false,
            depthWrite: false,
            side: THREE.DoubleSide
        });

        const discGeo = new THREE.CircleGeometry(discRadius, 64);
        const circularMesh = new THREE.Mesh(discGeo, avatarMat);
        circularMesh.position.z = 0.04;
        circularMesh.renderOrder = baseRenderOrder + 1;
        badgeGroup.add(circularMesh);

        // กรอบวงแหวนเรืองแสงหลัก + ขอบทองคำซ้อนด้านนอกสำหรับผู้เล่นหลัก
        const torusGeo = new THREE.TorusGeometry(discRadius - 0.02, isBot ? 0.09 : 0.11, 20, 64);
        const rimMat = new THREE.MeshBasicMaterial({
            color: rimColor,
            depthTest: false,
            depthWrite: false
        });
        const torusFrame = new THREE.Mesh(torusGeo, rimMat);
        torusFrame.renderOrder = baseRenderOrder + 2;
        badgeGroup.add(torusFrame);

        if (!isBot) {
            const outerGoldRim = new THREE.Mesh(
                new THREE.TorusGeometry(discRadius + 0.13, 0.055, 16, 64),
                new THREE.MeshBasicMaterial({
                    color: 0xffd700,
                    depthTest: false,
                    depthWrite: false
                })
            );
            outerGoldRim.renderOrder = baseRenderOrder + 2;
            badgeGroup.add(outerGoldRim);

            // มงกุฎเพชรทองคำ 3D บนยอดกรอบตัวผู้เล่นของเรา
            const crownGem = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.26),
                new THREE.MeshBasicMaterial({
                    color: 0xffe066,
                    depthTest: false,
                    depthWrite: false
                })
            );
            crownGem.position.set(0, discRadius + 0.28, 0.06);
            crownGem.renderOrder = baseRenderOrder + 3;
            badgeGroup.add(crownGem);
        }

        // 3. ป้ายชื่อลอยเหนือหัว ("👑 คุณ • ชื่อ" เด่นชัดมองหาเจอทันที)
        const nameCanvas = document.createElement('canvas');
        nameCanvas.width = 512;
        nameCanvas.height = 132;
        const username = playerData.displayName || playerData.name || playerData.username || '';
        this.drawPawnNameTagCanvas(nameCanvas, username, hexStr, isBot);
        const nameTex = new THREE.CanvasTexture(nameCanvas);
        nameTex.anisotropy = 4;
        const nameSprite = new THREE.Sprite(
            new THREE.SpriteMaterial({
                map: nameTex,
                transparent: true,
                depthTest: false,
                depthWrite: false
            })
        );
        nameSprite.scale.set(isBot ? 3.55 : 4.45, isBot ? 0.92 : 1.15, 1);
        nameSprite.position.set(0, discRadius + (isBot ? 0.72 : 1.02), 0.08);
        nameSprite.renderOrder = baseRenderOrder + 4;
        badgeGroup.add(nameSprite);

        pawnGroup.add(badgeGroup);

        const { provider, avatarUrl } = isBot
            ? { provider: 'bot', avatarUrl: playerData.picture || playerData.pictureUrl || playerData.avatar_url || '' }
            : this.resolvePlayerAvatarInfo(playerData);

        pawnGroup.userData = {
            badgeGroup,
            baseFloatY,
            circularMesh,
            torusFrame,
            auraRingMesh,
            nearFinishAura,
            nearFinishAuraMat,
            groundAuraMesh,
            spotlightBeam,
            nameCanvas,
            nameTex,
            nameSprite,
            isBot,
            avatarCanvas: canvas,
            avatarTex,
            avatarMat,
            colorHex: color,
            provider,
            isAwakened,
            character_grade: playerData.character_grade || null,
            aura_type: playerData.aura_type || null
        };

        this.applyAvatarTextureToPawn(
            pawnGroup,
            avatarUrl,
            username,
            color,
            isBot,
            provider,
            playerData.character_grade || null,
            playerData.aura_type || null
        );

        if (this.camera) {
            badgeGroup.lookAt(this.camera.position);
        }

        return pawnGroup;
    }

    /**
     * วาดและโหลดรูปโปรไฟล์ลงบนแผ่นตัวหมากทรงกลม 512x512 พร้อมขอบสีและเออร่า
     */
    applyAvatarTextureToPawn(pawnGroup, avatarUrl, username = '', colorHex = 0x00e5ff, isBot = false, provider = '', grade = null, auraType = null) {
        if (!pawnGroup || !pawnGroup.userData || !pawnGroup.userData.avatarCanvas) return;
        const canvas = pawnGroup.userData.avatarCanvas;
        const size = canvas.width || 512;
        const center = size / 2;
        const outerRadius = center - 6;
        const imageRadius = outerRadius - 14;
        const ctx = canvas.getContext('2d');
        const tex = pawnGroup.userData.avatarTex;

        let resolvedProvider = provider || pawnGroup.userData.provider || '';
        let resolvedUrl = avatarUrl;
        if (!isBot && (!resolvedUrl || !resolvedProvider)) {
            const info = this.resolvePlayerAvatarInfo({
                picture: avatarUrl,
                pictureUrl: avatarUrl,
                auth_provider: resolvedProvider
            });
            if (!resolvedUrl) resolvedUrl = info.avatarUrl;
            if (!resolvedProvider) resolvedProvider = info.provider;
        }
        pawnGroup.userData.provider = resolvedProvider;

        const resolvedGrade = (
            grade ||
            pawnGroup.userData.character_grade ||
            (!isBot ? (window.equippedFrameGrade || window.DEFAULT_USER?.character_grade || localStorage.getItem('snake_equipped_frame_grade')) : null) ||
            'A'
        ).toUpperCase();
        const resolvedAura = (
            auraType ||
            pawnGroup.userData.aura_type ||
            (!isBot ? (window.equippedFrameAura || localStorage.getItem('snake_equipped_frame_aura')) : '') ||
            ''
        );
        pawnGroup.userData.character_grade = resolvedGrade;
        pawnGroup.userData.aura_type = resolvedAura;

        let primaryBorderColor = '#00e5ff';
        let shadowBlurVal = 16;
        if (isBot) {
            primaryBorderColor = '#' + (colorHex || 0xff3d00).toString(16).padStart(6, '0');
            shadowBlurVal = 12;
        } else if (resolvedAura === 'orange') {
            primaryBorderColor = '#ff6a00';
            shadowBlurVal = 30;
        } else if (resolvedGrade === 'SS+' || resolvedAura === 'gold') {
            primaryBorderColor = '#ffd700';
            shadowBlurVal = 30;
        } else if (resolvedGrade === 'S+' || resolvedAura === 'yellow') {
            primaryBorderColor = '#facc15';
            shadowBlurVal = 24;
        } else if (resolvedGrade === 'S' || resolvedAura === 'cyan') {
            primaryBorderColor = '#00e5ff';
            shadowBlurVal = 18;
        } else if (resolvedGrade === 'A+' || resolvedAura === 'white') {
            primaryBorderColor = '#ffffff';
            shadowBlurVal = 14;
        } else {
            primaryBorderColor = '#00e5ff';
            shadowBlurVal = 16;
        }

        if (pawnGroup.userData.torusFrame && pawnGroup.userData.torusFrame.material) {
            const cObj = new THREE.Color(primaryBorderColor);
            pawnGroup.userData.torusFrame.material.color.copy(cObj);
            if (pawnGroup.userData.torusFrame.material.emissive) {
                pawnGroup.userData.torusFrame.material.emissive.copy(cObj);
            }
        }

        if (pawnGroup.userData.nameCanvas && pawnGroup.userData.nameTex) {
            this.drawPawnNameTagCanvas(
                pawnGroup.userData.nameCanvas,
                username,
                primaryBorderColor,
                Boolean(isBot)
            );
            pawnGroup.userData.nameTex.needsUpdate = true;
        }

        const drawCircularFrameBorder = () => {
            ctx.save();
            ctx.beginPath();
            ctx.arc(center, center, imageRadius + 6, 0, Math.PI * 2);
            ctx.strokeStyle = primaryBorderColor;
            ctx.lineWidth = 14;
            if (shadowBlurVal > 0) {
                ctx.shadowColor = primaryBorderColor;
                ctx.shadowBlur = shadowBlurVal;
            }
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(center, center, imageRadius - 2, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
            ctx.lineWidth = 4;
            ctx.shadowBlur = 0;
            ctx.stroke();
            ctx.restore();
        };

        const drawFallbackBadge = () => {
            ctx.clearRect(0, 0, size, size);
            ctx.save();
            ctx.beginPath();
            ctx.arc(center, center, imageRadius, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();

            const grad = ctx.createRadialGradient(center, center * 0.8, 20, center, center, imageRadius);
            grad.addColorStop(0, '#1e293b');
            grad.addColorStop(1, '#090d16');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, size, size);

            ctx.font = `bold ${Math.round(size * 0.36)}px "Kanit", sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = '#ffffff';
            const cleanName = String(username || '').replace(/🤖|บอท|\(AI\)/gi, '').trim();
            const label = cleanName ? Array.from(cleanName)[0].toUpperCase() : '👤';
            ctx.fillText(label, center, center + 6);
            ctx.restore();

            drawCircularFrameBorder();
            tex.needsUpdate = true;
        };

        drawFallbackBadge();

        if (!resolvedUrl && isBot && typeof window.buildOpponentAvatarSvgDataUrl === 'function') {
            resolvedUrl = window.buildOpponentAvatarSvgDataUrl(Math.floor(Math.random() * 16));
        }

        if (!resolvedUrl) return;

        const drawLoadedImage = (imgObj) => {
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.clearRect(0, 0, size, size);
            ctx.save();

            ctx.beginPath();
            ctx.arc(center, center, imageRadius, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();

            const imgW = imgObj.naturalWidth || imgObj.width || size;
            const imgH = imgObj.naturalHeight || imgObj.height || size;
            const scale = Math.max((imageRadius * 2) / imgW, (imageRadius * 2) / imgH);
            const drawW = imgW * scale;
            const drawH = imgH * scale;
            const offsetX = center - drawW / 2;
            const offsetY = center - drawH / 2;

            ctx.drawImage(imgObj, offsetX, offsetY, drawW, drawH);
            ctx.restore();

            drawCircularFrameBorder();

            tex.needsUpdate = true;
            if (pawnGroup.userData.avatarMat) {
                pawnGroup.userData.avatarMat.needsUpdate = true;
            }
        };

        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.referrerPolicy = 'no-referrer';
        img.onload = () => drawLoadedImage(img);
        img.onerror = () => {
            if (/^https?:\/\//i.test(resolvedUrl) && !resolvedUrl.includes('avatar_proxy')) {
                const proxyImg = new Image();
                proxyImg.crossOrigin = 'anonymous';
                proxyImg.onload = () => drawLoadedImage(proxyImg);
                proxyImg.src = 'api/auth.php?action=avatar_proxy&url=' + encodeURIComponent(resolvedUrl);
            } else if (!String(resolvedUrl).includes('google_avatar.png')) {
                const fb = new Image();
                fb.onload = () => drawLoadedImage(fb);
                fb.src = 'avatars/google_avatar.png';
            }
        };
        img.src = resolvedUrl;
    }

    /**
     * อัปเดตรูปโปรไฟล์บนหมากผู้เล่น (เรียกจาก ui.js หลังล็อกอิน / สวมใส่กรอบ)
     */
    updatePlayerPawnAvatar(playerIndex = 0, avatarUrlOrUserObj = '', username = '', provider = '', grade = null, auraType = null) {
        if (!this.players || !this.players[playerIndex]) {
            // หากอยู่ในโหมดสแตนด์บาย (Idle Lobby) และมีหมาก 3D อยู่บนกระดาน ให้รีเฟรชภาพของหมากนั้นทันที
            if (this.pawnsGroup && this.pawnsGroup.children.length > 0) {
                const pawn = this.pawnsGroup.children[0];
                let resolvedUrl = typeof avatarUrlOrUserObj === 'object' ? (avatarUrlOrUserObj.avatar_url || avatarUrlOrUserObj.picture || avatarUrlOrUserObj.pictureUrl) : avatarUrlOrUserObj;
                if (!resolvedUrl && typeof window.getActivePlayerAvatarUrl === 'function') {
                    resolvedUrl = window.getActivePlayerAvatarUrl(avatarUrlOrUserObj);
                }
                const uname = username || (typeof avatarUrlOrUserObj === 'object' ? (avatarUrlOrUserObj.displayName || avatarUrlOrUserObj.name || avatarUrlOrUserObj.username) : '') || pawn.userData?.username || '';
                this.applyAvatarTextureToPawn(pawn, resolvedUrl, uname, pawn.userData?.colorHex || 0x00e5ff, false, provider, grade, auraType);
            }
            return;
        }
        const p = this.players[playerIndex];

        let resolvedUrl = '';
        let resolvedProvider = provider;

        if (avatarUrlOrUserObj && typeof avatarUrlOrUserObj === 'object') {
            const info = this.resolvePlayerAvatarInfo(avatarUrlOrUserObj);
            resolvedUrl = info.avatarUrl;
            resolvedProvider = info.provider;
            if (!username) {
                username = avatarUrlOrUserObj.displayName || avatarUrlOrUserObj.name || avatarUrlOrUserObj.username || '';
            }
        } else {
            resolvedUrl = String(avatarUrlOrUserObj || '').trim();
            if (!resolvedUrl) {
                const info = this.resolvePlayerAvatarInfo(p);
                resolvedUrl = info.avatarUrl;
                if (!resolvedProvider) resolvedProvider = info.provider;
            }
        }

        if (username) p.username = username;
        if (resolvedProvider) p.auth_provider = resolvedProvider;
        if (resolvedUrl) {
            p.avatar_url = resolvedUrl;
            p.picture = resolvedUrl;
            p.pictureUrl = resolvedUrl;
        }
        if (grade) p.character_grade = grade;
        if (auraType) p.aura_type = auraType;

        if (p.mesh) {
            this.applyAvatarTextureToPawn(
                p.mesh,
                resolvedUrl || p.avatar_url || p.picture || p.pictureUrl,
                p.username,
                p.color,
                Boolean(p.is_bot),
                resolvedProvider,
                grade || p.character_grade,
                auraType || p.aura_type
            );
        }
        this.updateActiveTurnUI();
        this.saveGameState();
    }

    /**
     * แสดงกล่องข้อความ / อิโมจิ (Speech Bubble) ลอยเหนือหัวตัวหมาก 3D
     */
    showSpeechBubble(playerIndexOrObj = 0, message = '', durationMs = 4000) {
        const text = String(message || '').trim();
        if (!text || !this.players || !this.players.length) return;

        let pIndex = 0;
        let player = null;
        if (typeof playerIndexOrObj === 'number') {
            pIndex = playerIndexOrObj;
            player = this.players[pIndex];
        } else if (playerIndexOrObj && typeof playerIndexOrObj === 'object') {
            player = playerIndexOrObj;
            pIndex = Math.max(0, this.players.indexOf(player));
        }
        if (!player || !player.mesh) return;

        // ตรวจสอบว่าถ้าคนพูดเป็นคนอื่นและ @ หาผู้เล่นหลัก ให้ขึ้นแจ้งเตือน "ชื่อ..พูดถึงคุณ"
        if (pIndex !== 0 && typeof window.checkIfMessageMentionsMe === 'function' && window.checkIfMessageMentionsMe(text)) {
            const speakerName = player.username || player.displayName || 'ผู้เล่น';
            const speakerAvatar = player.avatar_url || player.picture || 'avatars/google_avatar.png';
            if (typeof window.notifyUserMentioned === 'function') {
                window.notifyUserMentioned(speakerName, text, speakerAvatar);
            }
        }

        if (!this.activeSpeechBubbles) this.activeSpeechBubbles = new Map();
        const prev = this.activeSpeechBubbles.get(pIndex);
        if (prev) {
            clearTimeout(prev.timer);
            if (prev.el && prev.el.parentNode) prev.el.parentNode.removeChild(prev.el);
            this.activeSpeechBubbles.delete(pIndex);
        }

        const bubble = document.createElement('div');
        bubble.className = 'pawn-speech-bubble';
        bubble.style.cssText = 'position:fixed;z-index:2100;pointer-events:none;background:rgba(15,23,42,0.92);color:#ffffff;border:1.5px solid #00e5ff;border-radius:16px;padding:6px 14px;font-size:15px;font-weight:700;box-shadow:0 6px 20px rgba(0,229,255,0.3);transform:translate(-50%,-100%);transition:opacity 0.3s ease;white-space:nowrap;';
        bubble.textContent = text;
        document.body.appendChild(bubble);

        const timer = setTimeout(() => {
            bubble.style.opacity = '0';
            setTimeout(() => {
                if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
            }, 300);
            this.activeSpeechBubbles.delete(pIndex);
        }, durationMs);

        this.activeSpeechBubbles.set(pIndex, { player, el: bubble, timer });
        this.updateSpeechBubblesPosition();
    }

    updateSpeechBubblesPosition() {
        if (!this.activeSpeechBubbles || this.activeSpeechBubbles.size === 0) return;
        if (!this.camera || !this.renderer || !this.renderer.domElement) return;

        const canvasRect = this.renderer.domElement.getBoundingClientRect();
        const worldPos = new THREE.Vector3();

        for (const [, item] of this.activeSpeechBubbles.entries()) {
            if (!item.player || !item.player.mesh || !item.el) continue;
            worldPos.set(
                item.player.mesh.position.x,
                item.player.mesh.position.y + 3.8,
                item.player.mesh.position.z
            );
            worldPos.project(this.camera);
            if (worldPos.z > 1) {
                item.el.style.display = 'none';
                continue;
            }
            item.el.style.display = 'block';
            const sx = canvasRect.left + (worldPos.x * 0.5 + 0.5) * canvasRect.width;
            const sy = canvasRect.top + (-worldPos.y * 0.5 + 0.5) * canvasRect.height;
            item.el.style.left = `${sx}px`;
            item.el.style.top = `${sy}px`;
        }
    }

    /**
     * วางหมากไว้โซนด้านหน้าของช่องเสมอ (+z ฝั่งเข้าหากล้อง) เพื่อไม่ให้โดนเมือง/แลนด์มาร์คด้านหลังบัง
     */
    setPawnPosition(player, tileNum, pIndex) {
        const idx = pIndex !== undefined ? pIndex : this.players.indexOf(player);
        const target = Math.min(Math.max(tileNum || 1, 1), 100);
        const prevTile = player.currentTile;
        player.currentTile = target;

        const offset = this.getPawnFrontOffset(player, target, idx >= 0 ? idx : 0);
        const tilePos = this.tiles[target] || this.tiles[1];

        if (player.mesh && tilePos) {
            player.mesh.position.copy(tilePos);
            player.mesh.position.x += offset.x;
            player.mesh.position.z += offset.z;
            player.mesh.position.y = (target === 1 || target === 100) ? 1.18 : 0.52;
        }

        if (prevTile && prevTile !== target) {
            this.realignPawnsOnTile(prevTile);
        }
        this.realignPawnsOnTile(target);
    }

    async checkAndTriggerBoardLinks(player) {
        if (!player) return;
        if (this.ladders[player.currentTile]) {
            const ladderEnd = this.ladders[player.currentTile];
            if (window.soundEngine && typeof window.soundEngine.playLadder === 'function') {
                window.soundEngine.playLadder();
            }
            this.logMessage(`🪜 ${player.username} เจอช่องบันได! ไต่ขึ้นจาก ${player.currentTile} ไป ${ladderEnd}!`, 'highlight');
            await this.animatePawnToTile(player, ladderEnd, 900);
            player.currentTile = ladderEnd;
        } else if (this.snakes[player.currentTile]) {
            const snakeEnd = this.snakes[player.currentTile];
            if (window.soundEngine && typeof window.soundEngine.playSnake === 'function') {
                window.soundEngine.playSnake();
            }
            this.logMessage(`🐍 ${player.username} ตกช่องงู! สไลด์ลงจาก ${player.currentTile} ไป ${snakeEnd}...`, 'highlight');
            await this.animatePawnToTile(player, snakeEnd, 900);
            player.currentTile = snakeEnd;
        }
    }

    roundMatchGold(val) {
        const n = Math.max(0, Number(val) || 0);
        if (n === 0) return 0;
        if (n < 50000) return Math.max(100, Math.round(n / 100) * 100);
        if (n < 500000) return Math.round(n / 1000) * 1000;
        return Math.round(n / 5000) * 5000;
    }

    /**
     * คำนวณภาษีช่อง TAX ตามจำนวนเมือง & มูลค่าก่อสร้างรวมของผู้เล่น (ยิ่งมีเมืองเยอะ ค่าก่อสร้างเยอะ ยิ่งจ่ายเยอะ!)
     */
    calculateDynamicTax(player) {
        const baseTax = Math.max(0, Number(this.matchConfig?.tax_amount ?? 50000));
        const basePct = Math.max(1, Number(this.matchConfig?.tax_percent ?? 20));

        let totalConstruction = 0;
        let cities = 0;
        let landmarks = 0;
        let ownedProvinces = 0;

        if (player && this.cityStates) {
            for (const st of Object.values(this.cityStates)) {
                if (st && String(st.ownerId) === String(player.id)) {
                    ownedProvinces++;
                    totalConstruction += Number(st.investedGold) || 0;
                    if (st.isLandmark) {
                        landmarks++;
                    } else {
                        cities += Math.max(1, Number(st.level) || 1);
                    }
                }
            }
        }

        if (totalConstruction <= 0) {
            return {
                totalTax: baseTax,
                baseTax,
                constructionTax: 0,
                effectivePct: 0,
                basePct,
                totalConstruction: 0,
                cities: 0,
                landmarks: 0,
                ownedProvinces: 0
            };
        }

        // อัตราภาษีก้าวหน้า: อัตราภาษีพื้นฐาน + 2% ต่อเมืองที่สร้าง + 5% ต่อแลนด์มาร์ค
        const progressiveBonusPct = (cities * 2) + (landmarks * 5);
        const effectivePct = basePct + progressiveBonusPct;
        const constructionTax = this.roundMatchGold((totalConstruction * effectivePct) / 100);
        const totalTax = baseTax + constructionTax;

        return {
            totalTax,
            baseTax,
            constructionTax,
            effectivePct,
            basePct,
            totalConstruction,
            cities,
            landmarks,
            ownedProvinces
        };
    }

    async handleTaxTile(player) {
        const taxInfo = this.calculateDynamicTax(player);
        const tax = taxInfo.totalTax;
        const currGold = Number(player.matchGold) || 0;

        if (tax <= 0) {
            this.showSkillBanner(`💸 ช่องภาษี! ${player.username} ยังไม่มีเมืองในครอบครอง ไม่เสียภาษี!`);
            this.logMessage(`💸 ${player.username} ตกช่องภาษี (ยังไม่มีเมืองและฐานภาษีเป็น 0 ไม่เสียภาษี)`, 'highlight');
            return;
        }

        const propSummary = taxInfo.totalConstruction > 0
            ? `${taxInfo.cities}🏠 ${taxInfo.landmarks}🏛️ ค่าก่อสร้างรวม ${this.formatCompactGold(taxInfo.totalConstruction)} • ภาษี ${taxInfo.effectivePct}%`
            : 'ยังไม่มีเมือง • เก็บเฉพาะภาษีขั้นต่ำ';

        if (currGold < tax) {
            this.showSkillBanner(`💥 ${player.username} ทองไม่พอจ่ายภาษีทรัพย์สิน ${this.formatCompactGold(tax)} (${propSummary}) — ล้มละลาย!`);
            this.logMessage(`💸 ${player.username} ตกช่องภาษี (${propSummary}) ต้องจ่าย ${tax.toLocaleString()} ทอง แต่มีเพียง ${currGold.toLocaleString()} ทอง!`, 'highlight');
            player.matchGold = 0;
            this.handleBankruptcy(player, null, 'ไม่สามารถจ่ายค่าภาษีทรัพย์สินได้');
            return;
        }

        player.matchGold = currGold - tax;
        this.updateMatchWealthHUD();
        this.updateActiveTurnUI();

        if (taxInfo.totalConstruction > 0) {
            this.showSkillBanner(`💸 กรมสรรพากร! ${player.username} (${propSummary}) จ่ายภาษี -${this.formatCompactGold(tax)}!`);
            this.logMessage(
                `💸 [ภาษีตามเมือง] ${player.username} มี ${taxInfo.cities} เมือง ${taxInfo.landmarks} แลนด์มาร์ค (ค่าก่อสร้างรวม ${taxInfo.totalConstruction.toLocaleString()} ทอง • อัตรา ${taxInfo.effectivePct}%) จ่ายภาษี ${tax.toLocaleString()} ทอง (คงเหลือ ${player.matchGold.toLocaleString()} ทอง)`,
                'highlight'
            );
        } else {
            this.showSkillBanner(`💸 ช่องภาษี! ${player.username} (ยังไม่มีเมือง) จ่ายภาษีขั้นต่ำ -${this.formatCompactGold(tax)}`);
            this.logMessage(
                `💸 ${player.username} ตกช่องภาษี (ยังไม่มีเมือง) จ่ายภาษีขั้นต่ำ ${tax.toLocaleString()} ทอง (คงเหลือ ${player.matchGold.toLocaleString()} ทอง)`,
                'highlight'
            );
        }
    }

    // =========================================================================
    // 🏙️ 3D CITIES (1-3 เมือง), LANDMARKS, TOLL, BUYOUT, X2-X8 SKILL MULTIPLIER & BANKRUPTCY
    // =========================================================================

    formatCompactGold(val) {
        const n = Math.max(0, Math.round(Number(val) || 0));
        if (n >= 1000000) {
            const m = n / 1000000;
            return (m % 1 === 0 ? m.toFixed(0) : m.toFixed(2).replace(/\.?0+$/, '')) + 'M';
        }
        if (n >= 1000) {
            const k = n / 1000;
            return (k % 1 === 0 ? k.toFixed(0) : k.toFixed(1).replace(/\.0$/, '')) + 'K';
        }
        return n.toLocaleString();
    }

    isBuildableTile(tileNum) {
        const t = Number(tileNum);
        if (t <= 1 || t >= 100) return false;
        if (t === this.jailTile) return false;
        if (this.chanceTiles.includes(t)) return false;
        if (this.taxTiles.includes(t)) return false;
        if (this.gambleTiles.includes(t)) return false;
        if (this.destroyTiles && this.destroyTiles.includes(t)) return false;
        if (this.ladders[t] || this.snakes[t]) return false;
        return true;
    }

    getTileScaleFactor(tileNum) {
        // จังหวัดยิ่งใกล้เส้นชัย มูลค่าและค่าผ่านทางยิ่งสูงขึ้น (1.00x -> 1.85x)
        return 1 + ((Math.max(2, Math.min(99, tileNum)) - 2) / 97) * 0.85;
    }

    getTileBuildCosts(tileNum) {
        const factor = this.getTileScaleFactor(tileNum);
        const base = this.roundMatchGold((Number(this.matchConfig?.city_base_cost) || 120000) * factor);
        const lmBase = this.roundMatchGold((Number(this.matchConfig?.landmark_cost) || 320000) * factor);
        const slmBase = this.roundMatchGold(lmBase * 1.75); // ซุปเปอร์แลนด์มาร์ค
        return {
            city1: base,
            city2: base * 2,
            city3: base * 3,
            unitCost: base,
            landmarkUpgrade: lmBase,
            superLandmarkUpgrade: slmBase
        };
    }

    getTileToll(tileNum) {
        const st = this.cityStates[tileNum];
        if (!st) return 0;
        const tollPct = (Number(this.matchConfig?.toll_percent) || 85) / 100;
        let landmarkBonus = 1.0;
        if (st.isSuperLandmark) landmarkBonus = 2.45;
        else if (st.isLandmark) landmarkBonus = 1.45;
        const mult = Math.max(1, Number(st.multiplier) || 1);
        const raw = (Number(st.investedGold) || 10000) * tollPct * landmarkBonus * mult;
        return Math.max(500, this.roundMatchGold(raw));
    }

    getTileBuyoutCost(tileNum) {
        const st = this.cityStates[tileNum];
        if (!st || st.isLandmark) return Infinity;
        const buyPct = (Number(this.matchConfig?.buyout_percent) || 160) / 100;
        const raw = (Number(st.investedGold) || 10000) * buyPct;
        return Math.max(1000, this.roundMatchGold(raw));
    }

    getPlayerTotalAssets(player) {
        if (!player || player.isBankrupt) return 0;
        let propVal = 0;
        for (const st of Object.values(this.cityStates)) {
            if (st && String(st.ownerId) === String(player.id)) {
                propVal += Number(st.investedGold) || 0;
            }
        }
        return (Number(player.matchGold) || 0) + propVal;
    }

    getPlayerCityCounts(player) {
        let cities = 0;
        let landmarks = 0;
        let superLandmarks = 0;
        if (!player) return { cities, landmarks, superLandmarks };
        for (const st of Object.values(this.cityStates)) {
            if (st && String(st.ownerId) === String(player.id)) {
                if (st.isSuperLandmark) superLandmarks++;
                else if (st.isLandmark) landmarks++;
                else cities += Number(st.level) || 1;
            }
        }
        return { cities, landmarks, superLandmarks };
    }

    startMatchTimer(customStartTime = null) {
        if (this.matchTimerInterval) {
            clearInterval(this.matchTimerInterval);
            this.matchTimerInterval = null;
        }

        this.matchTimeLimit = 600; // 10 minutes (600 seconds)
        if (customStartTime) {
            this.matchStartTime = Number(customStartTime);
        } else if (!this.matchStartTime) {
            this.matchStartTime = Date.now();
        }

        const elapsedSec = Math.floor((Date.now() - this.matchStartTime) / 1000);
        this.matchTimeRemaining = Math.max(0, this.matchTimeLimit - elapsedSec);

        // หากเวลาในการแข่งขันผ่านไปเกิน 10 นาทีแล้ว (เช่น ผู้เล่นหลุดไป 30 นาทีแล้วกลับมา) ให้ตัดสินผู้ชนะทันที!
        if (this.matchTimeRemaining <= 0 || elapsedSec >= this.matchTimeLimit) {
            this.matchTimeRemaining = 0;
            this.updateMatchTimerHUD();
            setTimeout(() => {
                this.handleMatchTimeoutVictory();
            }, 400);
            return;
        }

        this.warned1Min = (this.matchTimeRemaining <= 60);
        this.warned30Sec = (this.matchTimeRemaining <= 30);

        this.updateMatchTimerHUD();

        this.matchTimerInterval = setInterval(() => {
            if (!this.isMatchActive || this.isGameOver) {
                if (this.matchTimerInterval) {
                    clearInterval(this.matchTimerInterval);
                    this.matchTimerInterval = null;
                }
                return;
            }

            const currentElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
            this.matchTimeRemaining = Math.max(0, this.matchTimeLimit - currentElapsed);

            this.updateMatchTimerHUD();

            // เตือนเมื่อเหลือ 1 นาที (60 วินาที)
            if (this.matchTimeRemaining <= 60 && this.matchTimeRemaining > 30 && !this.warned1Min) {
                this.warned1Min = true;
                if (typeof showToast === 'function') {
                    showToast('⏰ เหลือเวลาอีก 1 นาที! ใครมีทองและสิ่งก่อสร้างรวมเยอะสุดจะชนะ!');
                }
                this.logMessage('⚠️ [แจ้งเตือนเวลา] เหลือเวลาแข่งขันอีก 1 นาทีสุดท้าย! เร่งสร้างเมืองและทำแต้ม!', 'warning');
                if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                    window.soundEngine.playAlert();
                }
            }
            // เตือนเมื่อเหลือ 30 วินาที
            else if (this.matchTimeRemaining <= 30 && this.matchTimeRemaining > 0 && !this.warned30Sec) {
                this.warned30Sec = true;
                if (typeof showToast === 'function') {
                    showToast('🚨 30 วินาทีสุดท้าย! ระบบจะตัดสินผู้ชนะจากสินทรัพย์และสิ่งก่อสร้างรวม!');
                }
                this.logMessage('🚨 [แจ้งเตือนเวลา] 30 วินาทีสุดท้าย! ผู้ที่มีทองและมูลค่าสิ่งก่อสร้างสูงสุดจะคว้าชัยชนะทันที!', 'warning');
                if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                    window.soundEngine.playAlert();
                }
            }

            // หมดเวลา 10 นาที (0 วินาที)
            if (this.matchTimeRemaining <= 0) {
                if (this.matchTimerInterval) {
                    clearInterval(this.matchTimerInterval);
                    this.matchTimerInterval = null;
                }
                this.handleMatchTimeoutVictory();
            }
        }, 1000);
    }

    updateMatchTimerHUD() {
        const el = document.getElementById('match-timer-digits');
        const pill = document.getElementById('match-timer-hud-pill');
        const ring = document.getElementById('timer-ring-progress');
        const tag = document.getElementById('timer-badge-tag');
        if (!el) return;

        const rem = Math.max(0, this.matchTimeRemaining ?? 600);
        const mins = Math.floor(rem / 60);
        const secs = rem % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        el.innerText = timeStr;

        if (ring) {
            const pct = ((rem / 600) * 100).toFixed(1);
            ring.setAttribute('stroke-dasharray', `${pct}, 100`);
        }

        let badgeText = '⚡ แข่งขัน 10 นาที';
        let stateClass = 'match-timer-hud-pill';

        if (rem <= 30) {
            badgeText = '🚨 ตัดสินผู้ชนะ!';
            stateClass = 'match-timer-hud-pill urgent-30';
        } else if (rem <= 60) {
            badgeText = '⚠️ 1 นาทีสุดท้าย!';
            stateClass = 'match-timer-hud-pill urgent-60';
        } else if (rem <= 120) {
            badgeText = '⚡ 2 นาทีสุดท้าย';
            stateClass = 'match-timer-hud-pill urgent-120';
        }

        if (tag) tag.innerText = badgeText;
        if (pill) pill.className = stateClass;
    }

    handleMatchTimeoutVictory() {
        if (this.isGameOver) return;

        // คัดเลือกคนที่มีสินทรัพย์รวมสูงสุด (ทองสด + มูลค่าสิ่งก่อสร้าง/เมือง/แลนด์มาร์ค)
        const ranked = [...this.players].sort((a, b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        });

        const winner = ranked[0] || this.players[0];
        this.handleVictory(winner, 'TIME_OUT');
    }

    updateMatchWealthHUD() {
        const hud = document.getElementById('match-wealth-hud');
        if (!hud) return;
        if (!this.isMatchActive || !this.players || this.players.length === 0) {
            hud.style.display = 'none';
            hud.innerHTML = '';
            return;
        }
        hud.style.display = 'flex';

        // จัดลำดับผู้เล่นตามสินทรัพย์รวม (ทอง + สิ่งก่อสร้าง) จากมากไปน้อย เรียงอันดับ 1 -> 4 จากซ้ายไปขวา
        const rankedPlayers = [...this.players].sort((a, b) => {
            if (Boolean(a.isBankrupt) !== Boolean(b.isBankrupt)) return a.isBankrupt ? 1 : -1;
            const diff = this.getPlayerTotalAssets(b) - this.getPlayerTotalAssets(a);
            if (diff !== 0) return diff;
            return (Number(b.matchGold) || 0) - (Number(a.matchGold) || 0);
        });

        const activePlayer = this.players[this.currentTurnIndex];

        // Format 10-minute timer with High-Tech Esports Dial
        if (this.isMatchActive && this.matchStartTime) {
            const curElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
            this.matchTimeRemaining = Math.max(0, (this.matchTimeLimit || 600) - curElapsed);
        }
        const rem = Math.max(0, this.matchTimeRemaining ?? 600);
        const mins = Math.floor(rem / 60);
        const secs = rem % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const pct = ((rem / 600) * 100).toFixed(1);

        let badgeText = '⚡ แข่งขัน 10 นาที';
        let timerClass = '';
        if (rem <= 30) {
            badgeText = '🚨 ตัดสินผู้ชนะ!';
            timerClass = 'urgent-30';
        } else if (rem <= 60) {
            badgeText = '⚠️ 1 นาทีสุดท้าย!';
            timerClass = 'urgent-60';
        } else if (rem <= 120) {
            badgeText = '⚡ 2 นาทีสุดท้าย';
            timerClass = 'urgent-120';
        }

        const timerHtml = `
            <div class="match-timer-hud-pill ${timerClass}" id="match-timer-hud-pill" title="เวลาแข่งขันคงเหลือ">
                <div class="timer-digits-line" style="display:flex; align-items:center; gap:3px;">
                    <span style="font-size:12px;">⏱️</span>
                    <span id="match-timer-digits" class="timer-digits-text">${timeStr}</span>
                </div>
            </div>
        `;

        const cardsHtml = rankedPlayers.map((p, idx) => {
            const rankNum = idx + 1; // 1, 2, 3, 4
            const isTurn = (p.id === activePlayer?.id) && !p.isBankrupt && !this.isGameOver;
            const hexColor = '#' + (Number(p.color) || 0x00e5ff).toString(16).padStart(6, '0');
            const isHuman = !p.is_bot;
            const u = window.DEFAULT_USER || {};
            const myRealName = u.displayName || u.name || u.username || 'ผู้เล่น';
            const myRealAvatar = (typeof window.getActivePlayerAvatarUrl === 'function') ? window.getActivePlayerAvatarUrl() : (u.avatar_url || u.picture);
            const avatar = isHuman ? myRealAvatar : (p.avatar_url || p.picture || 'avatars/google_avatar.png');
            let pName = isHuman ? myRealName : (p.username || 'ผู้เล่น');
            if (isHuman && (pName === 'เขียนศักดิ์' || pName === 'ผู้เล่น' || pName === 'Google Player')) {
                pName = myRealName;
            }
            const totalAssets = this.getPlayerTotalAssets(p);
            const counts = this.getPlayerCityCounts(p);
            const goldLabel = p.isBankrupt ? 'ล้มละลาย' : `🪙${this.formatCompactGold(p.matchGold)}`;
            const isNearGoal = p.currentTile >= 92 && p.currentTile < 100 && !p.isBankrupt;

            const rankMedals = { 1: '🥇', 2: '🥈', 3: '🥉', 4: '4️⃣' };
            const rankLabel = rankMedals[rankNum] || `${rankNum}`;

            return `
                <div class="wealth-player-card ${isTurn ? 'active-turn' : ''} ${p.isBankrupt ? 'bankrupt' : ''} ${isNearGoal ? 'near-goal-alert' : ''}" style="--p-color:${hexColor};" title="${pName} (สินทรัพย์รวม ${this.formatCompactGold(totalAssets)})">
                    <span style="font-size:11px; flex-shrink:0;">${rankLabel}</span>
                    <img src="${avatar}" class="wealth-avatar" onerror="this.onerror=null;this.src='avatars/google_avatar.png';">
                    <div class="wealth-info">
                        <div class="wealth-name-row">
                            <span style="display:inline-block;width:5px;height:5px;border-radius:50%;background:${hexColor};flex-shrink:0;"></span>
                            <span style="max-width:44px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${pName}</span>
                        </div>
                        <div class="wealth-gold-main" style="${p.isBankrupt ? 'color:#f87171;' : ''}">${goldLabel}</div>
                        <div class="wealth-sub-stats">
                            <span>รวม ${this.formatCompactGold(totalAssets)}</span>
                            <span>🏠${counts.cities}🏛️${counts.landmarks + (counts.superLandmarks || 0)}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        const exitBtnHtml = Boolean(this.isMatchActive) ? `
            <button type="button" class="practice-exit-top-btn" onclick="exitPracticeMatch()" title="ออกจากการแข่งขัน / กลับสู่หน้าหลัก">
                <span>🚪</span> ออก
            </button>
        ` : '';

        hud.innerHTML = timerHtml + cardsHtml + exitBtnHtml;
    }

    clearAllCities3D() {
        this.cityStates = {};
        this.cityMeshes = {};
        if (this.citiesGroup) {
            while (this.citiesGroup.children.length > 0) {
                this.citiesGroup.remove(this.citiesGroup.children[0]);
            }
        }
    }

    rebuildAllCities3D() {
        if (!this.citiesGroup) return;
        while (this.citiesGroup.children.length > 0) {
            this.citiesGroup.remove(this.citiesGroup.children[0]);
        }
        this.cityMeshes = {};
        for (const tileKey of Object.keys(this.cityStates)) {
            const tNum = Number(tileKey);
            if (this.cityStates[tNum]) {
                this.rebuildTileCity3D(tNum);
            }
        }
    }

    getCityFacadeMaterials(ownerColor, styleType = 'villa') {
        if (!this.cityFacadeMatCache) this.cityFacadeMatCache = {};
        const hex = '#' + (Number(ownerColor) || 0x00e5ff).toString(16).padStart(6, '0');
        const key = `${hex}_${styleType}`;
        if (this.cityFacadeMatCache[key]) return this.cityFacadeMatCache[key];

        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext('2d');

        const emCanvas = document.createElement('canvas');
        emCanvas.width = 256;
        emCanvas.height = 256;
        const emCtx = emCanvas.getContext('2d');
        emCtx.fillStyle = '#000000';
        emCtx.fillRect(0, 0, 256, 256);

        const drawLitWindow = (x, y, w, h, mainCol = '#fef08a', glowCol = '#f59e0b') => {
            // กรอบหน้าต่างบนพื้นผิวหลัก
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(x - 3, y - 3, w + 6, h + 6);
            const grad = ctx.createLinearGradient(x, y, x, y + h);
            grad.addColorStop(0, '#ffffff');
            grad.addColorStop(0.35, mainCol);
            grad.addColorStop(1, glowCol);
            ctx.fillStyle = grad;
            ctx.fillRect(x, y, w, h);

            // เส้นแบ่งกระจก
            ctx.strokeStyle = 'rgba(15, 23, 42, 0.45)';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, w, h);
            if (w >= 26) {
                ctx.beginPath();
                ctx.moveTo(x + w / 2, y);
                ctx.lineTo(x + w / 2, y + h);
                ctx.stroke();
            }

            // แผนที่เรืองแสง (Emissive)
            emCtx.shadowColor = glowCol;
            emCtx.shadowBlur = 10;
            emCtx.fillStyle = mainCol;
            emCtx.fillRect(x, y, w, h);
            emCtx.shadowBlur = 0;
        };

        if (styleType === 'villa') {
            // ผนังวิลล่าหรูสีครีมมุก + แถบบัวสีเจ้าของเมือง + ซุ้มประตูทอง
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#fffbeb');
            wallGrad.addColorStop(1, '#e2e8f0');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // แถบบัวบน-ล่างสีผู้เล่นและทองคำ
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 26);
            ctx.fillRect(0, 232, 256, 24);
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 24, 256, 7);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 4, 256, 12);

            // หน้าต่างวิลล่าส่องสว่างอบอุ่นซ้าย-ขวา
            drawLitWindow(28, 68, 62, 74, '#fef08a', '#f59e0b');
            drawLitWindow(166, 68, 62, 74, '#fef08a', '#f59e0b');

            // ประตูซุ้มโค้งทองคำตรงกลาง
            ctx.fillStyle = '#b45309';
            ctx.beginPath();
            ctx.roundRect(104, 118, 48, 114, [24, 24, 0, 0]);
            ctx.fill();
            ctx.fillStyle = '#fde047';
            ctx.beginPath();
            ctx.roundRect(111, 126, 34, 106, [18, 18, 0, 0]);
            ctx.fill();
            emCtx.fillStyle = '#fbbf24';
            emCtx.beginPath();
            emCtx.roundRect(113, 128, 30, 100, [16, 16, 0, 0]);
            emCtx.fill();
        } else if (styleType === 'mansion') {
            // คอนโด/แมนชั่น 2 ชั้นสไตล์ยุโรปโมเดิร์น
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#f8fafc');
            wallGrad.addColorStop(1, '#cbd5e1');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // แถบไฟนีออนคาดกลางตึก & ขอบบน
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 22);
            ctx.fillRect(0, 118, 256, 18);
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 20, 256, 6);
            ctx.fillRect(0, 134, 256, 6);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 4, 256, 10);
            emCtx.fillRect(0, 121, 256, 10);

            // หน้าต่างชั้นบน 3 บาน + ชั้นล่าง 2 บาน + ล็อบบี้กลาง
            const cols = [24, 103, 182];
            cols.forEach(cx => drawLitWindow(cx, 44, 50, 56, '#fef08a', '#f59e0b'));
            drawLitWindow(24, 156, 54, 62, '#bae6fd', '#0284c7');
            drawLitWindow(178, 156, 54, 62, '#bae6fd', '#0284c7');
            drawLitWindow(103, 152, 50, 88, '#fde047', '#d97706');
        } else if (styleType === 'hotel') {
            // โรงแรมแกรนด์ทาวเวอร์ 5 ดาว (กระจกสีน้ำเงินเข้มตัดทองและไฟห้องสูทระยิบระยับ)
            const wallGrad = ctx.createLinearGradient(0, 0, 0, 256);
            wallGrad.addColorStop(0, '#0f172a');
            wallGrad.addColorStop(0.5, '#1e293b');
            wallGrad.addColorStop(1, '#0f172a');
            ctx.fillStyle = wallGrad;
            ctx.fillRect(0, 0, 256, 256);

            // เสาคิ้วทองคำแนวตั้งซ้าย-ขวา
            ctx.fillStyle = '#fbbf24';
            ctx.fillRect(0, 0, 14, 256);
            ctx.fillRect(242, 0, 14, 256);
            ctx.fillStyle = hex;
            ctx.fillRect(0, 0, 256, 22);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 2, 256, 16);

            // ตารางห้องพัก VIP 4 ชั้น x 3 คอลัมน์
            const xs = [28, 102, 176];
            const ys = [34, 82, 130, 178];
            ys.forEach((yy, rIdx) => {
                xs.forEach((xx, cIdx) => {
                    if (rIdx === 3 && cIdx === 1) {
                        // โถงทางเข้าโรงแรมหรูสีทองสว่าง
                        drawLitWindow(xx - 4, yy, 60, 72, '#fde047', '#f59e0b');
                    } else {
                        const isWarm = (rIdx + cIdx) % 2 === 0;
                        drawLitWindow(
                            xx,
                            yy,
                            52,
                            34,
                            isWarm ? '#fef08a' : '#7dd3fc',
                            isWarm ? '#f59e0b' : '#0ea5e9'
                        );
                    }
                });
            });
        } else {
            // อาคารระฟ้าแลนด์มาร์ค (Crystal / Twin Tower)
            ctx.fillStyle = '#091124';
            ctx.fillRect(0, 0, 256, 256);
            ctx.fillStyle = '#ffd700';
            ctx.fillRect(0, 0, 12, 256);
            ctx.fillRect(244, 0, 12, 256);
            ctx.fillRect(122, 0, 12, 256);
            emCtx.fillStyle = hex;
            emCtx.fillRect(0, 0, 256, 18);
            emCtx.fillRect(124, 0, 8, 256);

            for (let r = 0; r < 5; r++) {
                for (let c = 0; c < 4; c++) {
                    const wx = 22 + c * 56;
                    const wy = 28 + r * 44;
                    const goldWin = (r + c) % 2 === 0;
                    drawLitWindow(
                        wx,
                        wy,
                        36,
                        26,
                        goldWin ? '#fde047' : '#a5f3fc',
                        goldWin ? '#f59e0b' : hex
                    );
                }
            }
        }

        const mapTex = new THREE.CanvasTexture(canvas);
        const emTex = new THREE.CanvasTexture(emCanvas);
        mapTex.anisotropy = 4;
        emTex.anisotropy = 4;

        const mat = new THREE.MeshStandardMaterial({
            map: mapTex,
            emissive: 0xffffff,
            emissiveMap: emTex,
            emissiveIntensity: styleType === 'landmark' ? 0.95 : 0.8,
            roughness: 0.24,
            metalness: styleType === 'hotel' || styleType === 'landmark' ? 0.45 : 0.18
        });

        this.cityFacadeMatCache[key] = mat;
        return mat;
    }

    createCityLabelSprite(tollText, badgeText, ownerHexColor, isLandmark = false, multiplier = 1, isSuperLandmark = false) {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 156;
        const ctx = canvas.getContext('2d');

        const isBoosted = multiplier > 1;
        const borderCol = isSuperLandmark ? '#f43f5e' : (isBoosted ? '#ec4899' : (isLandmark ? '#ffd700' : ownerHexColor));

        // เงาเรืองแสงรอบป้ายลอย (Compact Pill ไม่บังหลังคาตึก)
        ctx.save();
        ctx.shadowColor = isSuperLandmark ? '#ff0055' : (isLandmark ? '#fbbf24' : ownerHexColor);
        ctx.shadowBlur = isSuperLandmark ? 26 : 18;
        const bgGrad = ctx.createLinearGradient(24, 14, 488, 120);
        if (isSuperLandmark) {
            bgGrad.addColorStop(0, 'rgba(48, 10, 36, 0.96)');
            bgGrad.addColorStop(0.5, 'rgba(88, 15, 60, 0.96)');
            bgGrad.addColorStop(1, 'rgba(48, 10, 36, 0.96)');
        } else if (isLandmark) {
            bgGrad.addColorStop(0, 'rgba(24, 16, 48, 0.94)');
            bgGrad.addColorStop(0.5, 'rgba(45, 22, 74, 0.94)');
            bgGrad.addColorStop(1, 'rgba(24, 16, 48, 0.94)');
        } else {
            bgGrad.addColorStop(0, 'rgba(8, 15, 32, 0.92)');
            bgGrad.addColorStop(1, 'rgba(15, 28, 54, 0.92)');
        }
        ctx.fillStyle = bgGrad;
        ctx.strokeStyle = borderCol;
        ctx.lineWidth = isSuperLandmark ? 7.5 : 6;
        ctx.beginPath();
        ctx.roundRect(24, 14, 464, 106, 53);
        ctx.fill();
        ctx.stroke();

        // หมุดสามเหลี่ยมชี้ลงยอดตึกด้านล่างป้าย
        ctx.beginPath();
        ctx.moveTo(238, 120);
        ctx.lineTo(256, 144);
        ctx.lineTo(274, 120);
        ctx.closePath();
        ctx.fillStyle = borderCol;
        ctx.fill();
        ctx.restore();

        // เส้นขอบทองด้านในสำหรับแลนด์มาร์ค
        if (isSuperLandmark || isLandmark) {
            ctx.strokeStyle = isSuperLandmark ? 'rgba(255, 110, 199, 0.85)' : 'rgba(253, 224, 71, 0.55)';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.roundRect(33, 23, 446, 88, 44);
            ctx.stroke();
        }

        // เหรียญป้ายระดับเมือง / ตัวคูณด้านซ้าย
        if (badgeText) {
            const pillGrad = ctx.createLinearGradient(40, 28, 200, 106);
            if (isSuperLandmark) {
                pillGrad.addColorStop(0, '#ff007f');
                pillGrad.addColorStop(1, '#ffd700');
            } else if (isBoosted) {
                pillGrad.addColorStop(0, '#ec4899');
                pillGrad.addColorStop(1, '#f59e0b');
            } else if (isLandmark) {
                pillGrad.addColorStop(0, '#fde047');
                pillGrad.addColorStop(1, '#d97706');
            } else {
                pillGrad.addColorStop(0, ownerHexColor);
                pillGrad.addColorStop(1, '#e2e8f0');
            }
            ctx.fillStyle = pillGrad;
            ctx.beginPath();
            ctx.roundRect(40, 28, 152, 78, 39);
            ctx.fill();

            ctx.fillStyle = (isSuperLandmark || isBoosted) ? '#ffffff' : '#090d16';
            ctx.font = '900 36px Kanit, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(badgeText, 116, 68);

            // ตัวเลขค่าผ่านทางขนาดใหญ่คมชัดทางขวา
            ctx.fillStyle = isSuperLandmark ? '#fde047' : '#fef08a';
            ctx.shadowColor = isSuperLandmark ? 'rgba(255, 0, 128, 0.95)' : 'rgba(245, 158, 11, 0.85)';
            ctx.shadowBlur = 12;
            ctx.font = '900 48px Kanit, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(tollText, 464, 58);
            ctx.shadowBlur = 0;

            ctx.fillStyle = isSuperLandmark ? '#fbcfe8' : (isLandmark ? '#fda4af' : '#93c5fd');
            ctx.font = '700 22px Kanit, sans-serif';
            ctx.fillText(isSuperLandmark ? '👑 ซุปเปอร์แลนด์มาร์ค' : (isLandmark ? '🏛️ แลนด์มาร์ค (ห้ามซื้อต่อ)' : '🪙 ค่าผ่านทาง'), 462, 95);
        } else {
            ctx.fillStyle = '#fde047';
            ctx.font = '900 52px Kanit, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(tollText, 256, 68);
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.anisotropy = 4;
        const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false });
        const sprite = new THREE.Sprite(mat);
        sprite.scale.set(4.35, 1.32, 1);
        sprite.renderOrder = 28;
        return sprite;
    }

    rebuildTileCity3D(tileNum) {
        const t = Number(tileNum);
        if (this.cityMeshes[t]) {
            this.citiesGroup.remove(this.cityMeshes[t]);
            delete this.cityMeshes[t];
        }
        const st = this.cityStates[t];
        const pos = this.tiles[t];
        if (!st || !pos) return;

        const group = new THREE.Group();
        group.position.set(pos.x, pos.y, pos.z);

        const ownerColor = Number(st.color) || 0x00e5ff;
        const ownerHex = '#' + ownerColor.toString(16).padStart(6, '0');
        const isLM = Boolean(st.isLandmark);
        const isSLM = Boolean(st.isSuperLandmark);
        const mult = Number(st.multiplier) || 1;

        const animData = {
            phase: (t * 0.67) % (Math.PI * 2),
            buildProgress: 0,
            rotatingHalo: null,
            rotatingHalo2: null,
            floatingCrest: null,
            crestBaseY: 0,
            beamMesh: null,
            beacons: []
        };

        // 1. พื้นอาณาเขตโปร่งแสง + กรอบนีออน 3D ล้อมรอบช่องจังหวัด + เสาคริสตัล 4 มุม
        const innerSpan = this.tileSize - 0.16;
        const floorPad = new THREE.Mesh(
            new THREE.BoxGeometry(innerSpan, 0.08, innerSpan),
            new THREE.MeshStandardMaterial({
                color: isSLM ? 0xff007f : ownerColor,
                emissive: isSLM ? 0xff007f : ownerColor,
                emissiveIntensity: isSLM ? 0.95 : (isLM ? 0.7 : 0.42),
                transparent: true,
                opacity: isSLM ? 0.45 : (isLM ? 0.34 : 0.2)
            })
        );
        floorPad.position.y = 0.05;
        group.add(floorPad);

        // รางขอบนีออน 4 ด้านสีผู้เล่นสว่างคมชัด (หากเป็นซุปเปอร์แลนด์มาร์คจะมีรางขอบสีชมพูทองนีออนสุดอลังการ)
        const railThick = isSLM ? 0.26 : (isLM ? 0.22 : 0.17);
        const railHeight = isSLM ? 0.32 : (isLM ? 0.26 : 0.19);
        const halfSpan = innerSpan / 2 - railThick / 2;
        const railMat = new THREE.MeshStandardMaterial({
            color: isSLM ? 0xff007f : ownerColor,
            emissive: isSLM ? 0xff007f : ownerColor,
            emissiveIntensity: isSLM ? 1.45 : (isLM ? 1.15 : 0.85),
            metalness: 0.45,
            roughness: 0.18
        });
        const nsGeo = new THREE.BoxGeometry(innerSpan, railHeight, railThick);
        const ewGeo = new THREE.BoxGeometry(railThick, railHeight, innerSpan - railThick * 2);

        const northRail = new THREE.Mesh(nsGeo, railMat);
        northRail.position.set(0, railHeight / 2 + 0.04, -halfSpan);
        const southRail = new THREE.Mesh(nsGeo, railMat);
        southRail.position.set(0, railHeight / 2 + 0.04, halfSpan);
        const westRail = new THREE.Mesh(ewGeo, railMat);
        westRail.position.set(-halfSpan, railHeight / 2 + 0.04, 0);
        const eastRail = new THREE.Mesh(ewGeo, railMat);
        eastRail.position.set(halfSpan, railHeight / 2 + 0.04, 0);
        group.add(northRail, southRail, westRail, eastRail);

        // เสาไฟคริสตัลประดับ 4 มุมช่องจังหวัด
        const cornerCoord = halfSpan - 0.04;
        const postMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            emissive: 0xf59e0b,
            emissiveIntensity: 0.55,
            metalness: 0.85,
            roughness: 0.15
        });
        const gemMat = new THREE.MeshStandardMaterial({
            color: isLM ? 0xffe066 : 0xffffff,
            emissive: isLM ? 0xffb703 : ownerColor,
            emissiveIntensity: 1.1,
            metalness: 0.3,
            roughness: 0.1
        });
        const corners = [
            [-cornerCoord, -cornerCoord],
            [cornerCoord, -cornerCoord],
            [-cornerCoord, cornerCoord],
            [cornerCoord, cornerCoord]
        ];
        corners.forEach(([cx, cz]) => {
            const post = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, isLM ? 0.52 : 0.36, 6), postMat);
            post.position.set(cx, (isLM ? 0.26 : 0.18) + 0.05, cz);
            group.add(post);

            const gem = new THREE.Mesh(new THREE.OctahedronGeometry(isLM ? 0.24 : 0.17), gemMat.clone());
            gem.position.set(cx, (isLM ? 0.68 : 0.48), cz);
            group.add(gem);
            animData.beacons.push(gem);
        });

        // Shared luxury materials
        const goldMat = new THREE.MeshStandardMaterial({
            color: 0xffd700,
            emissive: 0xf59e0b,
            emissiveIntensity: 0.55,
            metalness: 0.88,
            roughness: 0.14
        });
        const ownerRoofMat = new THREE.MeshStandardMaterial({
            color: ownerColor,
            emissive: ownerColor,
            emissiveIntensity: 0.62,
            metalness: 0.38,
            roughness: 0.2
        });
        const marbleMat = new THREE.MeshStandardMaterial({
            color: 0xf8fafc,
            emissive: 0xe2e8f0,
            emissiveIntensity: 0.18,
            roughness: 0.22,
            metalness: 0.15
        });
        const gardenMat = new THREE.MeshStandardMaterial({
            color: 0x10b981,
            emissive: 0x059669,
            emissiveIntensity: 0.35,
            roughness: 0.45
        });

        let labelHeightY = 4.2;

        if (!isLM) {
            // 2. โซนสถาปัตยกรรมเมือง 1 - 3 เมือง สไตล์เกมเศรษฐี 3D (วิลล่าหรู -> คอนโด 2 ชั้น -> โรงแรมแกรนด์ทาวเวอร์)
            const count = Math.max(1, Math.min(3, Number(st.level) || 1));

            // ฐานลานพลาซ่ายกระดับด้านบนของช่อง (ไม่ทับตัวเดินและชื่อจังหวัด)
            const terraceW = count === 1 ? 2.55 : (count === 2 ? 4.45 : 5.55);
            const terraceBase = new THREE.Mesh(new THREE.BoxGeometry(terraceW, 0.24, 2.25), marbleMat);
            terraceBase.position.set(0, 0.16, -1.55);
            terraceBase.castShadow = true;
            group.add(terraceBase);

            const terraceLawn = new THREE.Mesh(new THREE.BoxGeometry(terraceW - 0.18, 0.08, 2.05), gardenMat);
            terraceLawn.position.set(0, 0.30, -1.55);
            group.add(terraceLawn);

            const xSlots = count === 1 ? [0] : (count === 2 ? [-1.28, 1.28] : [-1.85, -0.05, 1.80]);

            for (let i = 0; i < count; i++) {
                const bld = new THREE.Group();

                if (i === 0) {
                    // หลังที่ 1: 🏡 วิลล่าหรูหลังคาทรงปั้นหยา + ซุ้มมุกหน้าบ้าน + ยอดทอง
                    const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.22, 1.48), goldMat);
                    plinth.position.y = 0.42;
                    bld.add(plinth);

                    const villaMat = this.getCityFacadeMaterials(ownerColor, 'villa');
                    const body = new THREE.Mesh(new THREE.BoxGeometry(1.38, 1.55, 1.30), villaMat);
                    body.position.y = 1.30;
                    body.castShadow = true;
                    bld.add(body);

                    // กันสาดซุ้มประตูหน้าบ้าน
                    const awning = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.14, 0.36), ownerRoofMat);
                    awning.position.set(0, 1.18, 0.72);
                    bld.add(awning);

                    // บัวทองรองรับหลังคา
                    const eaves = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.12, 1.54), goldMat);
                    eaves.position.y = 2.12;
                    bld.add(eaves);

                    // หลังคาสีผู้เล่นสดใสเด่นชัด
                    const roof = new THREE.Mesh(new THREE.ConeGeometry(1.18, 1.05, 4), ownerRoofMat);
                    roof.rotation.y = Math.PI / 4;
                    roof.position.y = 2.70;
                    roof.castShadow = true;
                    bld.add(roof);

                    // ยอดฉัตรลูกแก้วทองคำบนหลังคา
                    const finial = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), goldMat);
                    finial.position.y = 3.26;
                    bld.add(finial);

                    if (count === 1) {
                        bld.scale.set(1.14, 1.14, 1.14);
                    }
                } else if (i === 1) {
                    // หลังที่ 2: 🏘️ คอนโดบูทีคแมนชั่น 2 ชั้น พร้อมระเบียงทองคำรอบตัวตึก
                    const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.60, 0.24, 1.52), goldMat);
                    plinth.position.y = 0.43;
                    bld.add(plinth);

                    const mansionMat = this.getCityFacadeMaterials(ownerColor, 'mansion');
                    const body = new THREE.Mesh(new THREE.BoxGeometry(1.42, 2.32, 1.34), mansionMat);
                    body.position.y = 1.70;
                    body.castShadow = true;
                    bld.add(body);

                    // ระเบียงทองคำคั่นชั้น 1 และชั้น 2
                    const balcony = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.15, 1.54), goldMat);
                    balcony.position.y = 1.68;
                    bld.add(balcony);

                    // หลังคาแมนซาร์ด 2 ชั้นสีผู้เล่น + ยอดเพชรทอง
                    const roofBase = new THREE.Mesh(new THREE.ConeGeometry(1.22, 0.92, 4), ownerRoofMat);
                    roofBase.rotation.y = Math.PI / 4;
                    roofBase.position.y = 3.30;
                    roofBase.castShadow = true;
                    bld.add(roofBase);

                    const spire = new THREE.Mesh(new THREE.OctahedronGeometry(0.22), goldMat);
                    spire.position.y = 3.88;
                    bld.add(spire);
                } else {
                    // หลังที่ 3: 🏨 โรงแรมแกรนด์ทาวเวอร์ 5 ดาว (ตึกสูงระฟ้า + โดมเพนท์เฮาส์ทองคำ)
                    const podium = new THREE.Mesh(new THREE.BoxGeometry(1.70, 0.30, 1.60), ownerRoofMat);
                    podium.position.y = 0.46;
                    bld.add(podium);

                    const podiumTrim = new THREE.Mesh(new THREE.BoxGeometry(1.76, 0.09, 1.66), goldMat);
                    podiumTrim.position.y = 0.64;
                    bld.add(podiumTrim);

                    const hotelMat = this.getCityFacadeMaterials(ownerColor, 'hotel');
                    const tower = new THREE.Mesh(new THREE.BoxGeometry(1.48, 3.25, 1.38), hotelMat);
                    tower.position.y = 2.28;
                    tower.castShadow = true;
                    bld.add(tower);

                    // มงกุฎนีออนยอดตึกโรงแรม
                    const crownLedge = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.22, 1.56), ownerRoofMat);
                    crownLedge.position.y = 4.00;
                    bld.add(crownLedge);

                    const goldCornice = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.10, 1.62), goldMat);
                    goldCornice.position.y = 4.16;
                    bld.add(goldCornice);

                    // โดมเพนท์เฮาส์ทองคำ + เสาอากาศคริสตัล
                    const dome = new THREE.Mesh(
                        new THREE.SphereGeometry(0.56, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2),
                        goldMat
                    );
                    dome.position.y = 4.20;
                    bld.add(dome);

                    const needle = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.72, 8), goldMat);
                    needle.position.y = 4.96;
                    bld.add(needle);
                }

                bld.position.set(xSlots[i], 0, -1.55);
                group.add(bld);
            }

            // หากสร้างครบ 3 เมือง เพิ่มวงแหวนออร่าสีทองหมุนรอบฐาน เพื่อบอกว่าพร้อมอัปเกรดเป็นแลนด์มาร์ค!
            if (count === 3) {
                const readyHalo = new THREE.Mesh(
                    new THREE.TorusGeometry(2.55, 0.06, 10, 36),
                    new THREE.MeshBasicMaterial({ color: 0xfde047, transparent: true, opacity: 0.85 })
                );
                readyHalo.rotation.x = Math.PI / 2;
                readyHalo.position.set(0, 0.42, -1.45);
                group.add(readyHalo);
                animData.rotatingHalo = readyHalo;
            }

            labelHeightY = count === 1 ? 4.35 : (count === 2 ? 4.75 : 5.75);
        } else {
            // 3. 🏛️ โมเดล 3D แลนด์มาร์คระดับตำนาน 6 สถาปัตยกรรม + เสาแสงสวรรค์ + วงแหวนเวทย์หมุน + มงกุฎเพชรลอยตัว
            const lm = new THREE.Group();
            lm.position.set(0, 0, -1.30);

            // ลำแสงออร่าแนวตั้งส่องสว่างเห็นเด่นทั่วทั้งกระดาน
            const beamGeo = new THREE.CylinderGeometry(isSLM ? 1.45 : 1.25, isSLM ? 2.25 : 1.95, isSLM ? 11.5 : 9.2, 24, 1, true);
            const beamMat = new THREE.MeshBasicMaterial({
                color: isSLM ? 0xff007f : (mult > 1 ? 0xf43f5e : ownerColor),
                transparent: true,
                opacity: isSLM ? 0.28 : 0.18,
                side: THREE.DoubleSide,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const beam = new THREE.Mesh(beamGeo, beamMat);
            beam.position.y = isSLM ? 5.85 : 4.65;
            lm.add(beam);
            animData.beamMesh = beam;

            // แท่นอนุสาวรีย์แกรนด์พลาซ่า 3 ชั้น (หินอ่อน + สีผู้เล่นเรืองแสง + ทองคำ 24K)
            const baseStep1 = new THREE.Mesh(new THREE.BoxGeometry(4.45, 0.34, 2.75), marbleMat);
            baseStep1.position.y = 0.22;
            lm.add(baseStep1);

            const baseStep2 = new THREE.Mesh(new THREE.BoxGeometry(3.85, 0.38, 2.35), ownerRoofMat);
            baseStep2.position.y = 0.56;
            lm.add(baseStep2);

            const baseStep3 = new THREE.Mesh(new THREE.BoxGeometry(3.15, 0.32, 1.95), goldMat);
            baseStep3.position.y = 0.90;
            lm.add(baseStep3);

            // วงแหวนเวทย์ทองคำหมุนรอบแลนด์มาร์ค + วงแหวนพลังงานสีเจ้าของ
            const halo1 = new THREE.Mesh(
                new THREE.TorusGeometry(2.18, 0.085, 12, 42),
                new THREE.MeshBasicMaterial({ color: 0xffd700 })
            );
            halo1.rotation.x = Math.PI / 2;
            halo1.position.y = 0.72;
            lm.add(halo1);
            animData.rotatingHalo = halo1;

            const halo2 = new THREE.Mesh(
                new THREE.TorusGeometry(1.55, 0.065, 10, 36),
                new THREE.MeshBasicMaterial({ color: mult > 1 ? 0xff4d94 : ownerColor })
            );
            halo2.rotation.x = Math.PI / 2;
            halo2.position.y = 2.85;
            lm.add(halo2);
            animData.rotatingHalo2 = halo2;

            const lmFacadeMat = this.getCityFacadeMaterials(ownerColor, 'landmark');
            const crimsonRoofMat = new THREE.MeshStandardMaterial({
                color: 0xdc2626,
                emissive: 0xb91c1c,
                emissiveIntensity: 0.48,
                metalness: 0.4,
                roughness: 0.2
            });

            let crestY = 6.15;
            const archType = t % 6;

            if (archType === 0) {
                // แบบที่ 1: มหาปราสาทศาลาไทยทองคำจตุรมุข (Royal Thai Golden Palace)
                const hall = new THREE.Mesh(new THREE.BoxGeometry(2.45, 1.65, 1.55), this.getCityFacadeMaterials(ownerColor, 'villa'));
                hall.position.y = 1.88;
                lm.add(hall);

                const tier1 = new THREE.Mesh(new THREE.ConeGeometry(2.05, 1.0, 4), crimsonRoofMat);
                tier1.rotation.y = Math.PI / 4;
                tier1.position.y = 3.12;
                lm.add(tier1);

                const tierGold1 = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.16, 1.35), goldMat);
                tierGold1.position.y = 3.55;
                lm.add(tierGold1);

                const tier2 = new THREE.Mesh(new THREE.ConeGeometry(1.45, 0.92, 4), ownerRoofMat);
                tier2.rotation.y = Math.PI / 4;
                tier2.position.y = 4.05;
                lm.add(tier2);

                const spire = new THREE.Mesh(new THREE.ConeGeometry(0.52, 2.05, 12), goldMat);
                spire.position.y = 5.25;
                lm.add(spire);

                // ยอดมณฑปเล็ก 4 มุม
                [[-1.25, -0.68], [1.25, -0.68], [-1.25, 0.68], [1.25, 0.68]].forEach(([mx, mz]) => {
                    const miniSpire = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.95, 8), goldMat);
                    miniSpire.position.set(mx, 1.52, mz);
                    lm.add(miniSpire);
                });
                crestY = 6.55;
            } else if (archType === 1) {
                // แบบที่ 2: มหาเสาอนุสาวรีย์จักรพรรดิยอดเพชรสุริยะ (Imperial Sun Obelisk)
                const pedestal = new THREE.Mesh(new THREE.BoxGeometry(1.85, 1.15, 1.45), lmFacadeMat);
                pedestal.position.y = 1.62;
                lm.add(pedestal);

                const obelisk = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.78, 3.65, 4), marbleMat);
                obelisk.rotation.y = Math.PI / 4;
                obelisk.position.y = 3.95;
                lm.add(obelisk);

                [2.5, 3.6, 4.7].forEach(ry => {
                    const band = new THREE.Mesh(new THREE.BoxGeometry(0.95 - (ry - 2.5) * 0.18, 0.14, 0.95 - (ry - 2.5) * 0.18), goldMat);
                    band.position.y = ry;
                    lm.add(band);
                });

                const pyramidion = new THREE.Mesh(new THREE.ConeGeometry(0.48, 0.85, 4), goldMat);
                pyramidion.rotation.y = Math.PI / 4;
                pyramidion.position.y = 6.05;
                lm.add(pyramidion);
                crestY = 6.75;
            } else if (archType === 2) {
                // แบบที่ 3: ตึกระฟ้าคริสตัลเอ็มไพร์ 101 (Crystal Empire Skyscraper)
                const seg1 = new THREE.Mesh(new THREE.BoxGeometry(2.05, 1.65, 1.55), lmFacadeMat);
                seg1.position.y = 1.88;
                lm.add(seg1);

                const trim1 = new THREE.Mesh(new THREE.BoxGeometry(2.25, 0.18, 1.72), goldMat);
                trim1.position.y = 2.78;
                lm.add(trim1);

                const seg2 = new THREE.Mesh(new THREE.BoxGeometry(1.62, 1.55, 1.28), lmFacadeMat);
                seg2.position.y = 3.62;
                lm.add(seg2);

                const trim2 = new THREE.Mesh(new THREE.BoxGeometry(1.82, 0.16, 1.45), ownerRoofMat);
                trim2.position.y = 4.46;
                lm.add(trim2);

                const seg3 = new THREE.Mesh(new THREE.BoxGeometry(1.12, 1.15, 0.98), lmFacadeMat);
                seg3.position.y = 5.10;
                lm.add(seg3);

                const spire = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.25, 8), goldMat);
                spire.position.y = 6.22;
                lm.add(spire);
                crestY = 7.0;
            } else if (archType === 3) {
                // แบบที่ 4: พระมหาเจดีย์ทองคำรัตนโกสินทร์ 5 ยอด (5-Spire Golden Stupa)
                const terrace = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.62, 0.65, 16), ownerRoofMat);
                terrace.position.y = 1.38;
                lm.add(terrace);

                const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 1.22, 1.95, 20), goldMat);
                bell.position.y = 2.65;
                lm.add(bell);

                const harmika = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.34, 0.82), ownerRoofMat);
                harmika.position.y = 3.72;
                lm.add(harmika);

                const chatraSpire = new THREE.Mesh(new THREE.ConeGeometry(0.48, 2.35, 16), goldMat);
                chatraSpire.position.y = 5.02;
                lm.add(chatraSpire);

                [[-1.25, -0.68], [1.25, -0.68], [-1.25, 0.68], [1.25, 0.68]].forEach(([cx, cz]) => {
                    const subStupa = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.35, 10), goldMat);
                    subStupa.position.set(cx, 1.72, cz);
                    lm.add(subStupa);
                });
                crestY = 6.48;
            } else if (archType === 4) {
                // แบบที่ 5: ตึกแฝดสกายบริดจ์มหานคร (Twin Luxury Towers & Sky-Bridge)
                [-0.95, 0.95].forEach(tx => {
                    const tw = new THREE.Mesh(new THREE.BoxGeometry(1.18, 4.15, 1.28), lmFacadeMat);
                    tw.position.set(tx, 3.12, 0);
                    lm.add(tw);

                    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.76, 0.95, 4), ownerRoofMat);
                    cap.rotation.y = Math.PI / 4;
                    cap.position.set(tx, 5.65, 0);
                    lm.add(cap);

                    const pin = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.65, 8), goldMat);
                    pin.position.set(tx, 6.32, 0);
                    lm.add(pin);
                });

                // สะพานลอยฟ้าเชื่อมตึกแฝด + ลูกแก้วพลังงานตรงกลาง
                const bridge = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.42, 0.78), goldMat);
                bridge.position.set(0, 3.85, 0);
                lm.add(bridge);

                const bridgeCore = new THREE.Mesh(new THREE.SphereGeometry(0.36, 16, 16), ownerRoofMat);
                bridgeCore.position.set(0, 4.35, 0);
                lm.add(bridgeCore);
                crestY = 6.65;
            } else {
                // แบบที่ 6: มหาวิหารโดมเพชรราชันย์ (Royal Diamond Pantheon Dome)
                const hall = new THREE.Mesh(new THREE.BoxGeometry(2.55, 1.85, 1.65), this.getCityFacadeMaterials(ownerColor, 'mansion'));
                hall.position.y = 1.98;
                lm.add(hall);

                // เสาโรมันด้านหน้า 4 ต้น
                [-0.95, -0.32, 0.32, 0.95].forEach(px => {
                    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 1.85, 10), goldMat);
                    col.position.set(px, 1.98, 0.88);
                    lm.add(col);
                });

                const drum = new THREE.Mesh(new THREE.CylinderGeometry(1.18, 1.28, 0.65, 20), ownerRoofMat);
                drum.position.y = 3.18;
                lm.add(drum);

                const dome = new THREE.Mesh(
                    new THREE.SphereGeometry(1.18, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2),
                    goldMat
                );
                dome.position.y = 3.48;
                lm.add(dome);

                const lantern = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.35, 10), goldMat);
                lantern.position.y = 5.25;
                lm.add(lantern);
                crestY = 6.25;
            }

            // เพชรราชันย์ลอยตัวหมุนส่องประกายเหนือยอดแลนด์มาร์คทุกแห่ง
            const crestGroup = new THREE.Group();
            const diamond = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.38),
                new THREE.MeshStandardMaterial({
                    color: mult > 1 ? 0xff4d94 : 0xfffbeb,
                    emissive: mult > 1 ? 0xf43f5e : 0xffd700,
                    emissiveIntensity: 1.25,
                    metalness: 0.6,
                    roughness: 0.08
                })
            );
            const crestRing = new THREE.Mesh(
                new THREE.TorusGeometry(0.56, 0.055, 10, 28),
                new THREE.MeshBasicMaterial({ color: 0xffd700 })
            );
            crestGroup.add(diamond, crestRing);
            crestGroup.position.set(0, crestY, 0);
            lm.add(crestGroup);

            animData.floatingCrest = crestGroup;
            animData.crestBaseY = crestY;
            labelHeightY = crestY + 1.28;

            group.add(lm);
        }

        // 4. ป้ายลอยดีไซน์เพรียวคมชัดเหนือยอดตึก (ไม่บังสถาปัตยกรรม 3D) แสดงค่าผ่านทาง & ตัวคูณ X2 / X4 / X6 / X8
        const tollVal = this.getTileToll(t);
        let badgeStr = `${st.level}🏠`;
        if (isSLM) {
            badgeStr = mult > 1 ? `👑X${mult}` : '👑SLM';
        } else if (isLM) {
            badgeStr = mult > 1 ? `⚡X${mult}` : '🏛️LM';
        }
        const labelSprite = this.createCityLabelSprite(
            this.formatCompactGold(tollVal),
            badgeStr,
            ownerHex,
            isLM,
            mult,
            isSLM
        );
        labelSprite.position.set(0, labelHeightY, -1.35);
        group.add(labelSprite);

        // เริ่มต้นแอนิเมชันเด้งสร้างเมืองใหม่ (Pop-in Scale)
        group.scale.set(0.05, 0.05, 0.05);
        group.userData.cityAnim = animData;

        this.citiesGroup.add(group);
        this.cityMeshes[t] = group;
    }

    openCityActionPrompt(config) {
        const modal = document.getElementById('modal-city-action');
        const titleEl = document.getElementById('city-action-title');
        const subEl = document.getElementById('city-action-sub');
        const iconEl = document.getElementById('city-action-icon');
        const walletEl = document.getElementById('city-action-wallet');
        const optsEl = document.getElementById('city-action-options');
        const timerEl = document.getElementById('city-action-timer');

        if (!modal || !optsEl) {
            return Promise.resolve(config.defaultChoice ?? null);
        }

        this.closeCityActionPrompt(null);
        this.isWaitingForCityAction = true;
        this.cityActionAutoChoice = config.defaultChoice ?? null;

        if (iconEl) iconEl.innerText = config.icon || '🏙️';
        if (titleEl) titleEl.innerHTML = config.title || 'จัดการเมือง';
        if (subEl) subEl.innerHTML = config.subtitle || '';
        if (walletEl) walletEl.innerHTML = config.walletHtml || '';

        return new Promise(resolve => {
            this.activeCityActionResolver = resolve;
            optsEl.innerHTML = '';

            (config.options || []).forEach(opt => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'city-opt-btn ' + (opt.className || '');
                btn.disabled = Boolean(opt.disabled);
                btn.innerHTML = `
                    <div style="font-size:20px;">${opt.icon || '🏠'}</div>
                    <div style="font-size:14px; font-weight:800;">${opt.label}</div>
                    ${opt.costLabel ? `<div style="font-size:12px; color:#fde047; font-weight:700;">${opt.costLabel}</div>` : ''}
                    ${opt.subLabel ? `<div style="font-size:10.5px; color:#94a3b8;">${opt.subLabel}</div>` : ''}
                `;
                btn.onclick = () => {
                    this.closeCityActionPrompt(opt.value);
                };
                optsEl.appendChild(btn);
            });

            modal.style.display = 'flex';
            let sec = Number(config.timeoutSec) || 8;
            if (timerEl) timerEl.innerText = `${sec}วิ`;

            this.cityActionInterval = setInterval(() => {
                if (this.isAutoMode || this.isGameOver) {
                    this.closeCityActionPrompt(config.defaultChoice ?? null);
                    return;
                }
                sec--;
                if (timerEl) timerEl.innerText = `${Math.max(0, sec)}วิ`;
                if (sec <= 0) {
                    this.closeCityActionPrompt(config.defaultChoice ?? null);
                }
            }, 1000);
        });
    }

    closeCityActionPrompt(choiceValue = null) {
        if (this.cityActionInterval) {
            clearInterval(this.cityActionInterval);
            this.cityActionInterval = null;
        }
        const modal = document.getElementById('modal-city-action');
        if (modal) modal.style.display = 'none';
        this.isWaitingForCityAction = false;
        if (this.activeCityActionResolver) {
            const fn = this.activeCityActionResolver;
            this.activeCityActionResolver = null;
            fn(choiceValue);
        }
    }

    /**
     * สุ่มตัวคูณแลนด์มาร์ค X2 / X4 / X6 / X8 ตามสกิลลูกเต๋า + สกิลกรอบรูปของผู้เล่น
     */
    rollLandmarkMultiplier(player, tileNum) {
        const st = this.cityStates[tileNum];
        if (!st || !st.isLandmark) return 2;

        const diceSkill = Number(player.dice_control_rate) || 20;
        const frameSkill = (Number(player.play_skill_rate) || 15) + (Number(player.win_rate_bonus) || 10) * 0.55;
        const totalPower = Math.min(160, diceSkill * 0.65 + frameSkill * 0.75);

        // ยิ่งสกิลเต๋าและสกิลกรอบรูปสูง โอกาสสุ่มได้ X6 และ X8 ยิ่งสูง!
        const weights = [
            { mult: 2, w: Math.max(10, 62 - totalPower * 0.35) },
            { mult: 4, w: 30 + totalPower * 0.14 },
            { mult: 6, w: 12 + totalPower * 0.26 },
            { mult: 8, w: 5 + totalPower * 0.32 }
        ];
        const sumW = weights.reduce((acc, it) => acc + it.w, 0);
        let r = Math.random() * sumW;
        let rolled = 2;
        for (const it of weights) {
            r -= it.w;
            if (r <= 0) {
                rolled = it.mult;
                break;
            }
        }

        // หากช่องนั้นมีตัวคูณอยู่แล้ว ไม่ให้ลดลง (รักษาค่าสูงสุดในช่วง 2, 4, 6, 8)
        const prevMult = Number(st.multiplier) || 1;
        const finalMult = Math.min(8, Math.max(prevMult, rolled));
        st.multiplier = finalMult;

        this.rebuildTileCity3D(tileNum);
        const newToll = this.getTileToll(tileNum);
        const prov = this.getProvinceName(tileNum);

        this.showSkillBanner(`⚡ สกิลเต๋า & กรอบทำงาน! แลนด์มาร์ค [${prov}] พุ่งเป็น X${finalMult}! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
        this.logMessage(`⚡ ${player.username} ตกแลนด์มาร์คตัวเอง [${prov}] สกิลเต๋า/กรอบสุ่มได้คูณ X${finalMult}! ค่าผ่านทางพุ่งเป็น ${newToll.toLocaleString()} ทอง!`, 'skill');
        return finalMult;
    }

    async handleCityTileLanding(player) {
        const t = player.currentTile;
        if (!this.isBuildableTile(t) || this.isGameOver || player.isBankrupt) return;

        const prov = this.getProvinceName(t);
        const costs = this.getTileBuildCosts(t);
        const st = this.cityStates[t];
        const isAutoOrBot = Boolean(player.is_bot || this.isAutoMode);

        // -----------------------------------------------------------
        // CASE 1: ช่องจังหวัดว่าง -> ตาแรกสร้างเมืองได้สูงสุด 3 เมือง (เหมือนรูป 2)
        // -----------------------------------------------------------
        if (!st) {
            const gold = Number(player.matchGold) || 0;
            if (gold < costs.city1) return;

            let maxAffordable = 1;
            if (gold >= costs.city3) maxAffordable = 3;
            else if (gold >= costs.city2) maxAffordable = 2;

            let chosenCount = 0;
            if (isAutoOrBot) {
                // บอทหรือโหมด AUTO: สร้าง 3 เมืองทันทีถ้าเงินเหลือปลอดภัย หรือลดหลั่นตามงบ
                if (gold >= costs.city3 * 1.15) chosenCount = 3;
                else if (gold >= costs.city2 * 1.15) chosenCount = 2;
                else chosenCount = 1;
            } else {
                chosenCount = await this.openCityActionPrompt({
                    icon: '🏙️',
                    title: `สร้างเมืองที่ "${prov}" (ช่อง ${t})`,
                    subtitle: 'ตาแรกเลือกสร้างได้สูงสุด 3 เมือง! ตกซ้ำครั้งหน้าสร้างแลนด์มาร์คได้ทันที',
                    defaultChoice: maxAffordable,
                    walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 🪙</span>`,
                    options: [
                        {
                            icon: '🏠',
                            label: 'สร้าง 1 เมือง',
                            costLabel: `${this.formatCompactGold(costs.city1)} 🪙`,
                            subLabel: 'บ้านพักตากอากาศ',
                            value: 1,
                            disabled: gold < costs.city1
                        },
                        {
                            icon: '🏘️',
                            label: 'สร้าง 2 เมือง',
                            costLabel: `${this.formatCompactGold(costs.city2)} 🪙`,
                            subLabel: 'คอมมูนิตี้วิลล่า',
                            value: 2,
                            disabled: gold < costs.city2
                        },
                        {
                            icon: '🏙️',
                            label: 'สร้าง 3 เมือง!',
                            costLabel: `${this.formatCompactGold(costs.city3)} 🪙`,
                            subLabel: 'แนะนำ! พร้อมอัปแลนด์มาร์ค',
                            value: 3,
                            className: gold >= costs.city3 ? 'recommended' : '',
                            disabled: gold < costs.city3
                        },
                        {
                            icon: '⏭️',
                            label: 'ยังไม่สร้าง',
                            costLabel: 'ข้ามตานี้',
                            value: 0,
                            className: 'skip-btn'
                        }
                    ]
                });
            }

            const count = Number(chosenCount) || 0;
            if (count >= 1 && count <= 3) {
                const totalBuildCost = costs[`city${count}`];
                if ((Number(player.matchGold) || 0) >= totalBuildCost) {
                    player.matchGold -= totalBuildCost;
                    this.cityStates[t] = {
                        ownerId: player.id,
                        ownerIndex: this.players.indexOf(player),
                        color: player.color,
                        level: count,
                        isLandmark: false,
                        multiplier: 1,
                        investedGold: totalBuildCost
                    };
                    this.rebuildTileCity3D(t);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`🏙️ ${player.username} สร้าง ${count} เมืองที่ [${prov}]! (ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`🏙️ ${player.username} สร้าง ${count} เมืองที่ช่อง ${t} (${prov}) จ่าย ${totalBuildCost.toLocaleString()} ทอง (ค่าผ่านทาง ${tollNow.toLocaleString()})`, 'highlight');
                }
            }
            return;
        }

        const owner = this.players.find(p => String(p.id) === String(st.ownerId));
        const isSelf = String(st.ownerId) === String(player.id);
        const isTeammate = Boolean(
            !isSelf &&
            player.team &&
            player.team !== 'NONE' &&
            owner &&
            player.team === owner.team
        );

        // -----------------------------------------------------------
        // CASE 2: ตกเมืองของตัวเอง -> ครั้งที่ 2 สร้างแลนด์มาร์ค / หากเป็นแลนด์มาร์คแล้ว อัปเป็นซุปเปอร์แลนด์มาร์ค / ถึงสูงสุดแล้วสุ่มตัวคูณ
        // -----------------------------------------------------------
        if (isSelf) {
            if (!st.isLandmark) {
                // มีเมืองอยู่แล้ว (1-3 หลัง) -> สร้างแลนด์มาร์คได้ทันที!
                const missingCities = Math.max(0, 3 - (Number(st.level) || 1));
                const upgradeCost = costs.landmarkUpgrade + missingCities * costs.unitCost;
                const gold = Number(player.matchGold) || 0;
                if (gold < upgradeCost) {
                    this.logMessage(`ℹ️ ${player.username} ตกเมืองตัวเอง [${prov}] แต่ทองไม่พอสร้างแลนด์มาร์ค (ต้องการ ${this.formatCompactGold(upgradeCost)})`, '');
                    return;
                }

                let doLandmark = false;
                if (isAutoOrBot) {
                    doLandmark = true;
                } else {
                    const choice = await this.openCityActionPrompt({
                        icon: '🏛️',
                        title: `อัปเกรดแลนด์มาร์ค "${prov}"!`,
                        subtitle: 'มีเมืองอยู่แล้ว! สร้างแลนด์มาร์คเพื่อล็อกเมือง (ห้ามใครซื้อต่อเด็ดขาด) และเพิ่มค่าผ่านทางพุ่งทะยาน!',
                        defaultChoice: 'LANDMARK',
                        walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 🪙</span>`,
                        options: [
                            {
                                icon: '🏛️',
                                label: 'สร้างแลนด์มาร์ค!',
                                costLabel: `${this.formatCompactGold(upgradeCost)} 🪙`,
                                subLabel: 'ห้ามใครซื้อต่อ + ค่าผ่านทางพุ่ง!',
                                value: 'LANDMARK',
                                className: 'landmark-btn recommended'
                            },
                            {
                                icon: '⏭️',
                                label: 'ยังไม่สร้าง',
                                costLabel: 'เก็บทองไว้ก่อน',
                                value: 'SKIP',
                                className: 'skip-btn'
                            }
                        ]
                    });
                    doLandmark = (choice === 'LANDMARK');
                }

                if (doLandmark && (Number(player.matchGold) || 0) >= upgradeCost) {
                    player.matchGold -= upgradeCost;
                    st.level = 4;
                    st.isLandmark = true;
                    st.isSuperLandmark = false;
                    st.investedGold = (Number(st.investedGold) || 0) + upgradeCost;
                    st.multiplier = Math.max(2, Number(st.multiplier) || 2); // สร้างแลนด์มาร์คเริ่มต้นที่ X2 ทันที!
                    this.rebuildTileCity3D(t);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`🏛️ ${player.username} สร้างแลนด์มาร์ค [${prov}] สำเร็จ! (ป้องกันซื้อต่อ • ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`🏛️ ${player.username} อัปเกรด [${prov}] เป็นแลนด์มาร์คสำเร็จ! ค่าผ่านทาง ${tollNow.toLocaleString()} ทอง (ห้ามซื้อต่อ!)`, 'highlight');
                }
            } else if (!st.isSuperLandmark) {
                // เป็นแลนด์มาร์คแล้ว และตกอีกครั้ง -> ให้สร้าง "ซุปเปอร์แลนด์มาร์ค (Super Landmark)"!
                const superCost = costs.superLandmarkUpgrade || Math.round(costs.landmarkUpgrade * 1.75);
                const gold = Number(player.matchGold) || 0;
                let doSuper = false;

                if (gold >= superCost) {
                    if (isAutoOrBot) {
                        doSuper = true;
                    } else {
                        const choice = await this.openCityActionPrompt({
                            icon: '👑',
                            title: `อัปเกรด "ซุปเปอร์แลนด์มาร์ค" [${prov}]!`,
                            subtitle: 'ตกแลนด์มาร์คตัวเองอีกครั้ง! อัปเกรดขั้นสูงสุด (Super Landmark) เพิ่มค่าผ่านทางมหาศาล!',
                            defaultChoice: 'SUPER_LANDMARK',
                            walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 🪙</span>`,
                            options: [
                                {
                                    icon: '👑',
                                    label: 'สร้างซุปเปอร์แลนด์มาร์ค!',
                                    costLabel: `${this.formatCompactGold(superCost)} 🪙`,
                                    subLabel: 'ขั้นสูงสุด! ห้ามซื้อต่อ + ค่าผ่านทางคูณหนัก',
                                    value: 'SUPER_LANDMARK',
                                    className: 'landmark-btn recommended'
                                },
                                {
                                    icon: '⚡',
                                    label: 'สุ่มตัวคูณแทน',
                                    costLabel: 'ฟรี (ลุ้น X2-X8)',
                                    value: 'ROLL_ONLY',
                                    className: 'skip-btn'
                                }
                            ]
                        });
                        doSuper = (choice === 'SUPER_LANDMARK');
                    }
                }

                if (doSuper && (Number(player.matchGold) || 0) >= superCost) {
                    player.matchGold -= superCost;
                    st.level = 5;
                    st.isLandmark = true;
                    st.isSuperLandmark = true;
                    st.investedGold = (Number(st.investedGold) || 0) + superCost;
                    st.multiplier = Math.max(4, Number(st.multiplier) || 4); // ซุปเปอร์แลนด์มาร์คคูณขั้นต่ำ X4
                    this.rebuildTileCity3D(t);
                    this.updateMatchWealthHUD();
                    this.updateActiveTurnUI();
                    const tollNow = this.getTileToll(t);
                    this.showSkillBanner(`👑 ${player.username} สร้าง "ซุปเปอร์แลนด์มาร์ค" [${prov}] ขั้นสูงสุดสำเร็จ! (ค่าผ่านทาง ${this.formatCompactGold(tollNow)})`);
                    this.logMessage(`👑 ${player.username} อัปเกรด [${prov}] เป็นซุปเปอร์แลนด์มาร์ค (ขั้นสูงสุด) ค่าผ่านทาง ${tollNow.toLocaleString()} ทอง (ห้ามซื้อต่อ!)`, 'highlight');
                } else {
                    // หากไม่สร้างซุปเปอร์แลนด์มาร์ค หรือทองไม่พอ ให้สุ่มตัวคูณ X2-X8
                    this.rollLandmarkMultiplier(player, t);
                }
            } else {
                // แลนด์มาร์กถึงสูงสุดแล้ว (Super Landmark) สร้างต่อไม่ได้ -> สุ่มคูณตัวคูณ X4 / X6 / X8 ต่อเนื่อง!
                this.logMessage(`👑 [${prov}] เป็นซุปเปอร์แลนด์มาร์คขั้นสูงสุดแล้ว (ไม่สามารถสร้างต่อได้)`, '');
                this.rollLandmarkMultiplier(player, t);
            }
            return;
        }

        if (isTeammate) {
            this.logMessage(`🤝 ${player.username} แวะพักที่เมืองของเพื่อนร่วมทีม (${owner?.username || 'ทีมเดียวกัน'}) ไม่เสียค่าผ่านทาง!`, '');
            return;
        }

        // -----------------------------------------------------------
        // CASE 3: ตกเมืองหรือแลนด์มาร์คของคู่แข่ง -> แสดง Popup ค่าผ่านทาง / กู้เงิน / ล้มละลาย
        // -----------------------------------------------------------
        const toll = this.getTileToll(t);
        const visitorGold = Number(player.matchGold) || 0;
        const maxLoans = 3;
        const loansUsed = Number(player.loanCount) || 0;
        const shortage = Math.max(0, toll - visitorGold);
        const hasEnoughGold = (visitorGold >= toll);
        const canLoan = (loansUsed < maxLoans);

        // คำนวณยอดกู้ฉุกเฉิน (ให้ครอบคลุมค่าผ่านทาง + มีเงินสำรองเดินเกมต่อ)
        const baseLoanUnit = 1000000;
        const loanAmount = Math.max(Math.ceil((shortage + 300000) / baseLoanUnit) * baseLoanUnit, baseLoanUnit);

        let tollDecision = null;

        if (isAutoOrBot) {
            // โหมดบอท หรือ AUTO: ตัดสินใจอัตโนมัติ
            if (hasEnoughGold) {
                tollDecision = 'PAY_TOLL';
            } else if (canLoan) {
                tollDecision = 'LOAN_AND_PAY';
            } else {
                tollDecision = 'BANKRUPT';
            }
        } else {
            // ผู้เล่นจริง: แสดง Popup รายละเอียดค่าผ่านทาง พร้อมปุ่มเลือกกดจ่าย, กู้เงิน หรือล้มละลาย
            const cityDesc = st.isSuperLandmark
                ? `👑 ซุปเปอร์แลนด์มาร์ค (ขั้นสูงสุด • ค่าผ่านทาง X${st.multiplier || 1})`
                : (st.isLandmark ? `🏛️ แลนด์มาร์ค (ห้ามซื้อต่อ • ค่าผ่านทาง X${st.multiplier || 1})` : `🏙️ เมืองระดับ ${st.level || 1} หลัง`);

            let walletInfoHtml = `
                <div style="display:flex; flex-direction:column; gap:8px; width:100%; background:rgba(15,23,42,0.9); padding:10px 14px; border-radius:12px; border:1px solid rgba(255,255,255,0.1);">
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:6px;">
                        <span>👑 เจ้าของเมือง: <strong style="color:#38bdf8; font-size:14px;">${owner?.username || 'คู่แข่ง'}</strong></span>
                        <span style="font-size:12px; color:#fde047; font-weight:700;">${cityDesc}</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span>💸 ค่าผ่านทางที่ต้องชำระ:</span>
                        <strong style="color:#f43f5e; font-size:17px; font-weight:900;">-${toll.toLocaleString()} 🪙 (${this.formatCompactGold(toll)})</strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span>💰 ทองในกระเป๋าของคุณ:</span>
                        <strong style="color:#fde047; font-size:15px;">${visitorGold.toLocaleString()} 🪙</strong>
                    </div>
            `;

            if (hasEnoughGold) {
                const remaining = visitorGold - toll;
                walletInfoHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px dashed rgba(255,255,255,0.15); padding-top:6px;">
                        <span>✨ ทองคงเหลือหลังจ่าย:</span>
                        <strong style="color:#10b981; font-size:15px; font-weight:800;">${remaining.toLocaleString()} 🪙</strong>
                    </div>
                </div>`;
            } else {
                walletInfoHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px dashed rgba(244,63,94,0.4); padding-top:6px; color:#f87171;">
                        <span>⚠️ ทองไม่พอจ่ายค่าผ่านทาง! ขาดอีก:</span>
                        <strong style="font-size:16px; color:#ff4d4d; font-weight:900;">${shortage.toLocaleString()} 🪙 (${this.formatCompactGold(shortage)})</strong>
                    </div>
                </div>`;
            }

            const promptOptions = [];

            if (hasEnoughGold) {
                promptOptions.push({
                    icon: '💸',
                    label: 'จ่ายค่าผ่านทาง',
                    costLabel: `-${this.formatCompactGold(toll)} 🪙`,
                    subLabel: 'ชำระค่าผ่านทางและเดินเกมต่อ',
                    value: 'PAY_TOLL',
                    className: 'pay-btn recommended'
                });
                promptOptions.push({
                    icon: '🏳️',
                    label: 'ประกาศล้มละลาย',
                    costLabel: 'ยอมแพ้',
                    subLabel: `โอนทรัพย์สินให้ ${owner?.username || 'คู่แข่ง'} แล้วจบเกม`,
                    value: 'BANKRUPT',
                    className: 'skip-btn'
                });
            } else {
                // เงินไม่พอจ่าย: เลือกว่าจะกู้เงิน หรือล้มละลาย
                if (canLoan) {
                    promptOptions.push({
                        icon: '🏦',
                        label: 'กู้เงินฉุกเฉิน (ใช้ทองกู้)',
                        costLabel: `+${this.formatCompactGold(loanAmount)} 🪙 (สิทธิ์ ${loansUsed + 1}/${maxLoans})`,
                        subLabel: 'กู้เงินกองกลางฉุกเฉิน นำมาจ่ายค่าผ่านทางและรอดตาย!',
                        value: 'LOAN_AND_PAY',
                        className: 'loan-btn recommended'
                    });
                } else {
                    promptOptions.push({
                        icon: '🚫',
                        label: 'สิทธิ์กู้เงินเต็มแล้ว',
                        costLabel: `ใช้ครบ ${maxLoans} ครั้งแล้ว`,
                        subLabel: 'ไม่สามารถกู้เงินเพิ่มได้',
                        value: 'NONE',
                        disabled: true,
                        className: 'skip-btn'
                    });
                }
                promptOptions.push({
                    icon: '💥',
                    label: 'ประกาศล้มละลาย',
                    costLabel: `มอบทอง ${this.formatCompactGold(visitorGold)} ทั้งหมด`,
                    subLabel: `โอนทองที่เหลือให้ ${owner?.username || 'คู่แข่ง'} แล้วออกจากเกม`,
                    value: 'BANKRUPT',
                    className: 'bankrupt-btn'
                });
            }

            tollDecision = await this.openCityActionPrompt({
                icon: hasEnoughGold ? '💸' : '⚠️',
                title: hasEnoughGold ? `ตกเมือง "${prov}"! จ่ายค่าผ่านทาง` : `ตกเมือง "${prov}"! เงินไม่พอจ่ายค่าผ่านทาง`,
                subtitle: hasEnoughGold
                    ? `เมืองของ <strong>${owner?.username || 'คู่แข่ง'}</strong> • ตรวจสอบค่าใช้จ่ายแล้วกดชำระหรือยอมแพ้`
                    : `ขาดอีก <strong style="color:#ff4d4d;">${this.formatCompactGold(shortage)} ทอง</strong> • เลือกกู้เงินฉุกเฉิน หรือประกาศล้มละลาย`,
                defaultChoice: hasEnoughGold ? 'PAY_TOLL' : (canLoan ? 'LOAN_AND_PAY' : 'BANKRUPT'),
                walletHtml: walletInfoHtml,
                options: promptOptions,
                timeoutSec: 8
            });
        }

        // ประมวลผลผลการตัดสินใจค่าผ่านทาง
        if (tollDecision === 'BANKRUPT') {
            // ประกาศล้มละลาย
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + visitorGold;
            }
            player.matchGold = 0;
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();

            this.showSkillBanner(`💥 ${player.username} ประกาศล้มละลายที่ [${prov}]!`);
            this.logMessage(`💥 ${player.username} ตกเมือง [${prov}] ของ ${owner?.username || 'คู่แข่ง'} (ค่าผ่านทาง ${toll.toLocaleString()}) เลือกประกาศล้มละลาย! โอนเงินทั้งหมด ${visitorGold.toLocaleString()} ทองให้ ${owner?.username || 'คู่แข่ง'}`, 'highlight');
            this.handleBankruptcy(player, owner || null, `ล้มละลายจากค่าผ่านทางที่ ${prov}`);
            return;
        }

        if (tollDecision === 'LOAN_AND_PAY') {
            // กู้เงินฉุกเฉิน
            player.loanCount = (Number(player.loanCount) || 0) + 1;
            player.matchGold = visitorGold + loanAmount;

            // หักค่าธรรมเนียมกู้ยืมเล็กน้อยจากบัญชีหลัก (ถ้ามี)
            if (window.DEFAULT_USER && Number(window.DEFAULT_USER.gold) >= 2000) {
                window.DEFAULT_USER.gold = Math.max(0, Number(window.DEFAULT_USER.gold) - 2000);
                if (typeof window.updateUserBar === 'function') window.updateUserBar(window.DEFAULT_USER);
            }

            this.showSkillBanner(`🏦 ${player.username} ใช้ทองกู้ฉุกเฉิน +${this.formatCompactGold(loanAmount)} ทอง (ครั้งที่ ${player.loanCount}/${maxLoans}) สำเร็จ!`);
            this.logMessage(`🏦 ${player.username} ใช้สิทธิ์กู้เงินฉุกเฉิน ${loanAmount.toLocaleString()} ทอง (ครั้งที่ ${player.loanCount}/${maxLoans}) เพื่อนำมาจ่ายค่าผ่านทาง ${toll.toLocaleString()} ทอง!`, 'skill');
        }

        // หักค่าผ่านทางจริงให้เจ้าของเมือง
        const currentGoldAfterLoan = Number(player.matchGold) || 0;
        const actualPaid = Math.min(currentGoldAfterLoan, toll);
        player.matchGold = Math.max(0, currentGoldAfterLoan - actualPaid);
        if (owner && !owner.isBankrupt) {
            owner.matchGold = (Number(owner.matchGold) || 0) + actualPaid;
        }
        this.updateMatchWealthHUD();
        this.updateActiveTurnUI();

        this.showSkillBanner(`🚧 ${player.username} จ่ายค่าผ่านทาง [${prov}] ${this.formatCompactGold(actualPaid)} ให้ ${owner?.username || 'เจ้าของเมือง'}!`);
        this.logMessage(`🚧 ${player.username} ตกช่อง ${t} (${prov}) จ่ายค่าผ่านทาง ${actualPaid.toLocaleString()} ทอง ให้ ${owner?.username || 'เจ้าของเมือง'}!`, 'highlight');

        // หากเงินยังคงไม่พอแม้กู้แล้ว
        if (player.matchGold <= 0 && actualPaid < toll) {
            this.handleBankruptcy(player, owner || null, `ล้มละลายจากค่าผ่านทางที่ ${prov}`);
            return;
        }

        // ตรวจสอบว่าเจ้าของเมืองยืนเฝ้าเมืองอยู่ที่ช่องนี้หรือไม่!
        const standingOwner = this.players.find(p => p.id === owner?.id && !p.isBankrupt && p.currentTile === t);
        if (standingOwner) {
            // เจ้าของเมืองยืนอยู่ที่เมืองของตัวเอง: คู่ต่อสู้จ่ายค่าผ่านทางก่อน แล้วจึงโดนเด้งถอยหลังตามระยะสกิล!
            const defSkill = standingOwner.skill || {};
            const bounceTiles = (defSkill.code === 'PULL_BACK_8' || standingOwner.isAwakened || defSkill.power === 8) ? 8 : (defSkill.power || 5);

            this.showSkillBanner(`⚡ สกิลพิทักษ์เมือง! ${standingOwner.username} ซัด ${player.username} เด้งถอยหลัง ${bounceTiles} ช่อง!`);
            this.logMessage(`⚡ สกิลพิทักษ์เมืองทำงาน! ${standingOwner.username} ยืนเฝ้าเมือง [${prov}] หลังจากเก็บค่าผ่านทาง ${actualPaid.toLocaleString()} ทองแล้ว ซัด ${player.username} เด้งกระเด็นถอยหลัง ${bounceTiles} ช่อง!`, 'skill');

            const bouncedTile = Math.max(1, player.currentTile - bounceTiles);
            await this.animatePawnToTile(player, bouncedTile, 750);
            player.currentTile = bouncedTile;

            // ตรวจสอบช่องที่กระเด็นไปตก (เช่น บันได หรืองู)
            await this.checkAndTriggerBoardLinks(player);
            return;
        }

        // หากเป็นแลนด์มาร์ค หรือ ซุปเปอร์แลนด์มาร์ค -> ห้ามซื้อต่อเด็ดขาด!
        if (st.isLandmark || st.isSuperLandmark) {
            const lmTypeStr = st.isSuperLandmark ? '👑 ซุปเปอร์แลนด์มาร์ค' : '🏛️ แลนด์มาร์ค';
            this.logMessage(`🔒 [${prov}] เป็น${lmTypeStr}ของ ${owner?.username || 'คู่แข่ง'} — ไม่สามารถซื้อต่อได้!`, 'skill');
            return;
        }

        // หากยังเป็นเมือง 1-3 หลัง และมีทองเหลือพอซื้อต่อ -> เสนอซื้อต่อเมือง (และอัปเป็นแลนด์มาร์คต่อได้!)
        const buyoutCost = this.getTileBuyoutCost(t);
        if (player.matchGold < buyoutCost) return;

        const missingForLm = Math.max(0, 3 - (Number(st.level) || 1)) * costs.unitCost;
        const buyoutPlusLandmarkCost = buyoutCost + missingForLm + costs.landmarkUpgrade;
        const canBuyAndLandmark = player.matchGold >= buyoutPlusLandmarkCost;

        let buyAction = 'SKIP';
        if (isAutoOrBot) {
            if (canBuyAndLandmark && player.matchGold >= buyoutPlusLandmarkCost * 1.15) {
                buyAction = 'BUY_AND_LANDMARK';
            } else if (player.matchGold >= buyoutCost * 1.2) {
                buyAction = 'BUYOUT';
            }
        } else {
            buyAction = await this.openCityActionPrompt({
                icon: '💼',
                title: `ซื้อต่อเมือง "${prov}" จาก ${owner?.username || 'คู่แข่ง'}?`,
                subtitle: `จ่ายค่าผ่านทางแล้ว ${this.formatCompactGold(toll)} • สามารถเทคโอเวอร์เมืองนี้มาเป็นของเราได้!`,
                defaultChoice: canBuyAndLandmark ? 'BUY_AND_LANDMARK' : 'BUYOUT',
                walletHtml: `<span>💰 ทองคงเหลือหลังจ่ายค่าผ่านทาง: <strong style="color:#fde047;">${player.matchGold.toLocaleString()}</strong> 🪙</span>`,
                options: [
                    {
                        icon: '💼',
                        label: 'ซื้อต่อเมืองนี้',
                        costLabel: `${this.formatCompactGold(buyoutCost)} 🪙`,
                        subLabel: `ยึดเมือง ${st.level} หลังมาเป็นของเรา`,
                        value: 'BUYOUT',
                        className: !canBuyAndLandmark ? 'recommended' : ''
                    },
                    {
                        icon: '🏛️',
                        label: 'ซื้อต่อ + สร้างแลนด์มาร์ค!',
                        costLabel: `${this.formatCompactGold(buyoutPlusLandmarkCost)} 🪙`,
                        subLabel: 'ยึดแล้วล็อกแลนด์มาร์คทันที!',
                        value: 'BUY_AND_LANDMARK',
                        className: canBuyAndLandmark ? 'landmark-btn recommended' : '',
                        disabled: !canBuyAndLandmark
                    },
                    {
                        icon: '⏭️',
                        label: 'ไม่ซื้อต่อ',
                        costLabel: 'เก็บทองไว้เดินต่อ',
                        value: 'SKIP',
                        className: 'skip-btn'
                    }
                ]
            });
        }

        if (buyAction === 'BUY_AND_LANDMARK' && player.matchGold >= buyoutPlusLandmarkCost) {
            player.matchGold -= buyoutPlusLandmarkCost;
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + buyoutCost;
            }
            st.ownerId = player.id;
            st.ownerIndex = this.players.indexOf(player);
            st.color = player.color;
            st.level = 4;
            st.isLandmark = true;
            st.multiplier = 2;
            st.investedGold = (Number(st.investedGold) || 0) + missingForLm + costs.landmarkUpgrade;
            this.rebuildTileCity3D(t);
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            const newToll = this.getTileToll(t);
            this.showSkillBanner(`🏛️ ${player.username} เทคโอเวอร์ [${prov}] พร้อมสร้างแลนด์มาร์คทันที! (ค่าผ่านทาง ${this.formatCompactGold(newToll)})`);
            this.logMessage(`🏛️ ${player.username} ซื้อต่อเมือง [${prov}] และอัปเกรดเป็นแลนด์มาร์คทันที!`, 'highlight');
        } else if (buyAction === 'BUYOUT' && player.matchGold >= buyoutCost) {
            player.matchGold -= buyoutCost;
            if (owner && !owner.isBankrupt) {
                owner.matchGold = (Number(owner.matchGold) || 0) + buyoutCost;
            }
            st.ownerId = player.id;
            st.ownerIndex = this.players.indexOf(player);
            st.color = player.color;
            this.rebuildTileCity3D(t);
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`💼 ${player.username} ซื้อต่อเมือง [${prov}] สำเร็จ!`);
            this.logMessage(`💼 ${player.username} ซื้อต่อเมือง [${prov}] จาก ${owner?.username || 'คู่แข่ง'} ในราคา ${buyoutCost.toLocaleString()} ทอง!`, 'highlight');
        }
    }

    /**
     * 💥 สกิลลบเมืองคู่แข่ง (ช่อง 26, 36, 90)
     * หากตกช่องนี้ สามารถใช้สกิลเลือกเมืองคู่แข่งที่ต้องการลบได้
     * หากคู่แข่งต้องการรักษาเมืองไว้ ต้องจ่ายเงินปกป้องเมือง!
     */
    async handleDestroySkillTile(player) {
        if (!player || player.isBankrupt || this.isGameOver) return;
        const isAutoOrBot = Boolean(player.is_bot || this.isAutoMode);

        // หาเมืองของคู่แข่งทั้งหมดบนกระดาน (ไม่รวมเมืองของตัวเอง และไม่รวมเพื่อนร่วมทีม)
        const opponentCities = [];
        for (const [tKey, st] of Object.entries(this.cityStates)) {
            const tNum = Number(tKey);
            if (!st || String(st.ownerId) === String(player.id)) continue;
            const owner = this.players.find(p => String(p.id) === String(st.ownerId));
            if (!owner || owner.isBankrupt) continue;
            if (player.team && player.team !== 'NONE' && owner.team === player.team) continue;

            const prov = this.getProvinceName(tNum);
            const levelStr = st.isSuperLandmark ? '👑 ซุปเปอร์แลนด์มาร์ค' : (st.isLandmark ? '🏛️ แลนด์มาร์ค' : `${st.level}🏠 เมือง`);
            opponentCities.push({
                tileNum: tNum,
                state: st,
                owner,
                prov,
                levelStr
            });
        }

        if (opponentCities.length === 0) {
            this.showSkillBanner(`💥 ${player.username} ตกช่องสกิลลบเมือง! แต่บนกระดานยังไม่มีเมืองของคู่แข่ง`);
            this.logMessage(`💥 ${player.username} ตกช่องสกิลลบเมือง (ช่อง ${player.currentTile}) แต่ไม่มีเมืองคู่แข่งให้ทำลาย!`, 'highlight');
            return;
        }

        this.showSkillBanner(`💥 สกิลทำลายล้าง! ${player.username} สามารถเลือกเมืองคู่แข่งเพื่อลบทิ้งได้!`);
        this.logMessage(`💥 ${player.username} ตกช่องสกิลพิเศษ (ช่อง ${player.currentTile}) กำลังเปิดเป้าหมายเลือกลบเมืองคู่แข่ง!`, 'skill');

        let targetTileNum = null;

        if (isAutoOrBot) {
            // บอทเลือกเมืองที่มีมูลค่าสูงที่สุดหรือเป็นแลนด์มาร์คก่อน
            opponentCities.sort((a, b) => {
                const valA = (Number(a.state.investedGold) || 0) * (a.state.isSuperLandmark ? 3 : (a.state.isLandmark ? 2 : 1));
                const valB = (Number(b.state.investedGold) || 0) * (b.state.isSuperLandmark ? 3 : (b.state.isLandmark ? 2 : 1));
                return valB - valA;
            });
            targetTileNum = opponentCities[0]?.tileNum;
        } else {
            // ผู้เล่นเลือกเมืองจากหน้าต่าง Pop-up
            const options = opponentCities.map(c => {
                const hex = '#' + (Number(c.owner.color) || 0x00e5ff).toString(16).padStart(6, '0');
                const cost = Number(c.state.investedGold) || 100000;
                return {
                    icon: c.state.isSuperLandmark ? '👑' : (c.state.isLandmark ? '🏛️' : '🏠'),
                    label: `ช่อง ${c.tileNum}: ${c.prov}`,
                    costLabel: `เจ้าของ: ${c.owner.username}`,
                    subLabel: `${c.levelStr} (มูลค่า ${this.formatCompactGold(cost)})`,
                    value: String(c.tileNum),
                    className: 'recommended'
                };
            });
            options.push({
                icon: '⏭️',
                label: 'ไม่เลือกลบเมือง',
                costLabel: 'ข้ามรอบนี้',
                value: 'SKIP',
                className: 'skip-btn'
            });

            const choice = await this.openCityActionPrompt({
                icon: '💥',
                title: 'สกิลเลือกทำลายเมืองคู่แข่ง!',
                subtitle: 'เลือก 1 เมืองของฝ่ายตรงข้ามที่ต้องการลบออกจากกระดาน (หากคู่แข่งต้องการรักษาเมืองไว้ ต้องจ่ายเงินปกป้อง)',
                defaultChoice: String(opponentCities[0]?.tileNum || 'SKIP'),
                options
            });

            if (!choice || choice === 'SKIP') {
                this.logMessage(`ℹ️ ${player.username} เลือกไม่ใช้สกิลลบเมืองคู่แข่ง`, '');
                return;
            }
            targetTileNum = Number(choice);
        }

        const targetData = opponentCities.find(c => c.tileNum === targetTileNum);
        if (!targetData) return;

        const { tileNum: targetTile, state: targetState, owner: targetOwner, prov: targetProv, levelStr: targetLevelStr } = targetData;
        const invested = Number(targetState.investedGold) || 120000;
        // ค่าคุ้มครองรักษาเมือง = 35% ของมูลค่าก่อสร้างเมืองนั้น
        const defendCost = this.roundMatchGold(invested * 0.35);
        const ownerGold = Number(targetOwner.matchGold) || 0;

        let ownerDefended = false;

        if (ownerGold >= defendCost) {
            const isOwnerAuto = Boolean(targetOwner.is_bot || (targetOwner.id === this.players[0]?.id ? this.isAutoMode : true));
            if (isOwnerAuto) {
                // บอทหรือผู้เล่นโหมด Auto จะยอมจ่ายเงินรักษาเมืองเสมอถ้าเป็นแลนด์มาร์ค หรือมีทองเหลือเกิน 50%
                ownerDefended = Boolean(targetState.isLandmark || targetState.isSuperLandmark || ownerGold >= defendCost * 2);
            } else {
                // แสดงหน้าต่างถามเจ้าของเมืองว่าต้องการจ่ายเงินรักษาเมืองไว้หรือไม่
                const defendChoice = await this.openCityActionPrompt({
                    icon: '🛡️',
                    title: `เมือง [${targetProv}] ของคุณกำลังถูกลบ!`,
                    subtitle: `${player.username} ใช้สกิลลบเมือง! จ่ายเงินคุ้มครองเพื่อรักษาเมืองนี้ไว้หรือไม่?`,
                    defaultChoice: 'DEFEND',
                    walletHtml: `<span>💰 ทองในกระดานของคุณ: <strong style="color:#fde047;">${ownerGold.toLocaleString()}</strong> 🪙</span>`,
                    options: [
                        {
                            icon: '🛡️',
                            label: 'จ่ายเงินรักษาเมืองไว้!',
                            costLabel: `${this.formatCompactGold(defendCost)} 🪙`,
                            subLabel: 'รักษาเมืองและแลนด์มาร์คไว้สำเร็จ',
                            value: 'DEFEND',
                            className: 'recommended'
                        },
                        {
                            icon: '💥',
                            label: 'ยอมให้ลบเมือง',
                            costLabel: 'ไม่จ่ายทอง (เสียเมืองนี้ทันที)',
                            value: 'SURRENDER',
                            className: 'skip-btn'
                        }
                    ]
                });
                ownerDefended = (defendChoice === 'DEFEND');
            }
        }

        if (ownerDefended && ownerGold >= defendCost) {
            targetOwner.matchGold -= defendCost;
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`🛡️ ${targetOwner.username} จ่าย -${this.formatCompactGold(defendCost)} ปกป้อง [${targetProv}] ไว้ได้สำเร็จ!`);
            this.logMessage(`🛡️ ${targetOwner.username} ยอมจ่ายเงิน ${defendCost.toLocaleString()} ทอง เพื่อรักษา ${targetLevelStr} [${targetProv}] ไม่ให้ถูกลบ!`, 'highlight');
        } else {
            // ทำลายล้างเมือง ลบออกจากกระดาน 3D ทันที!
            delete this.cityStates[targetTile];
            if (this.cityMeshes[targetTile]) {
                this.citiesGroup.remove(this.cityMeshes[targetTile]);
                delete this.cityMeshes[targetTile];
            }
            this.updateMatchWealthHUD();
            this.updateActiveTurnUI();
            this.showSkillBanner(`💥 ตู้ม! เมือง [${targetProv}] ของ ${targetOwner.username} ถูกลบออกจากกระดานแล้ว!`);
            this.logMessage(`💥 สกิลสัมฤทธิ์ผล! ${player.username} ลบ ${targetLevelStr} [${targetProv}] ของ ${targetOwner.username} ออกจากกระดานเรียบร้อย!`, 'highlight');
        }
    }

    handleBankruptcy(bankruptPlayer, creditor = null, reason = '') {
        if (!bankruptPlayer || bankruptPlayer.isBankrupt) return;
        bankruptPlayer.isBankrupt = true;
        bankruptPlayer.matchGold = 0;
        if (bankruptPlayer.mesh) {
            bankruptPlayer.mesh.visible = false;
        }

        // คืนเมืองของผู้ล้มละลายออกจากกระดานให้ว่างสำหรับคนอื่นสร้างใหม่
        for (const key of Object.keys(this.cityStates)) {
            const tNum = Number(key);
            if (this.cityStates[tNum] && String(this.cityStates[tNum].ownerId) === String(bankruptPlayer.id)) {
                delete this.cityStates[tNum];
                if (this.cityMeshes[tNum]) {
                    this.citiesGroup.remove(this.cityMeshes[tNum]);
                    delete this.cityMeshes[tNum];
                }
            }
        }

        this.updateMatchWealthHUD();

        // ตรวจสอบว่าเหลือผู้รอดชีวิตเพียง 1 คน (หรือ 1 ทีมในโหมด 2v2) หรือไม่
        const alivePlayers = this.players.filter(p => !p.isBankrupt);
        if (alivePlayers.length === 1) {
            this.handleVictory(alivePlayers[0], 'BANKRUPTCY');
            return;
        }

        const isTeamGame = alivePlayers.length > 0 && alivePlayers.every(p => p.team && p.team !== 'NONE');
        if (isTeamGame) {
            const aliveTeams = new Set(alivePlayers.map(p => p.team));
            if (aliveTeams.size === 1) {
                this.handleVictory(alivePlayers[0], 'BANKRUPTCY');
                return;
            }
        }
    }

    async handleGambleTile(player) {
        this.showSkillBanner(`🎰 ${player.username} ตกช่องเสี่ยงโชค! ลุ้นรับเพชรและทองคำ`);
        const isAuto = Boolean(this.isAutoMode || player.is_bot);
        if (!player.is_bot && typeof window.openLuckyGambleModal === 'function') {
            this.isWaitingForGamble = true;
            try {
                await window.openLuckyGambleModal(player, isAuto);
            } catch (e) {
                console.warn('Lucky gamble modal error:', e);
            }
            this.isWaitingForGamble = false;
        } else {
            const rewardPool = [
                { label: '💎 50 เพชร', diamond_delta: 50 },
                { label: '🪙 5,000 ทอง', gold_delta: 5000 },
                { label: '🪙 10,000 ทอง', gold_delta: 10000 },
                { label: '💎 20 เพชร', diamond_delta: 20 }
            ];
            const picked = rewardPool[Math.floor(Math.random() * rewardPool.length)];
            this.logMessage(`🎰 ${player.username}${(!player.is_bot && this.isAutoMode) ? ' ⚡[AUTO]' : ''} หมุนวงล้อเสี่ยงโชคได้รับ ${picked.label}!`, 'highlight');
            if (!player.is_bot && !window.isPracticeMatch && typeof window.syncUserProgress === 'function') {
                try { await window.syncUserProgress(picked); } catch (e) {}
            }
        }
    }

    /**
     * เปลี่ยนสกินลูกเต๋า 3D ตาม preset (window.DICE_SKIN_PRESETS)
     */
    applyDiceSkin(skinKey) {
        const presets = window.DICE_SKIN_PRESETS || {};
        const preset = presets[skinKey] || presets['ClassicWoodDice'];
        if (!preset || this.currentDiceSkin === skinKey) return;
        this.currentDiceSkin = skinKey;

        const pipConfigs = {
            1: [[0.5, 0.5]],
            2: [[0.25, 0.25], [0.75, 0.75]],
            3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
            4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
            5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
            6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
        };
        const mats = [1, 6, 2, 5, 3, 4].map(num => {
            const canvas = document.createElement('canvas');
            canvas.width = 256;
            canvas.height = 256;
            const ctx = canvas.getContext('2d');
            const colors = preset.bgGradient || ['#ffffff', '#e2e8f0'];
            const grad = ctx.createLinearGradient(0, 0, 256, 256);
            colors.forEach((c, i) => grad.addColorStop(colors.length === 1 ? 0 : i / (colors.length - 1), c));
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 256, 256);
            ctx.strokeStyle = preset.borderColor || '#cbd5e1';
            ctx.lineWidth = preset.borderWidth || 12;
            ctx.strokeRect(6, 6, 244, 244);
            ctx.fillStyle = num === 1 ? (preset.pipOneColor || '#ef4444') : (preset.pipColor || '#0f172a');
            pipConfigs[num].forEach(([px, py]) => {
                ctx.beginPath();
                ctx.arc(px * 256, py * 256, num === 1 ? 32 : 22, 0, Math.PI * 2);
                ctx.fill();
            });
            return new THREE.MeshStandardMaterial({
                map: new THREE.CanvasTexture(canvas),
                roughness: preset.roughness ?? 0.15,
                metalness: preset.metalness ?? 0.1,
                emissive: preset.emissive || 0x000000,
                emissiveIntensity: 0.4
            });
        });
        this.diceMaterials = mats;
        if (this.diceMesh1) this.diceMesh1.material = mats;
        if (this.diceMesh2) this.diceMesh2.material = mats;
    }

    applyDiceSkinForPlayer(player) {
        if (!player) return;
        try { this.applyDiceSkin(player.dice_skin || 'ClassicWoodDice'); } catch (e) { console.warn('applyDiceSkin error:', e); }
    }

    saveActiveSession() {
        this.saveGameState();
    }

    restoreSavedSession(saved) {
        try {
            if (saved && typeof saved === 'object') {
                if (saved.tileProvinces) this.tileProvinces = saved.tileProvinces;
                if (saved.boardTheme && this.themes[saved.boardTheme]) this.boardTheme = saved.boardTheme;
                this.buildBoard();
                localStorage.setItem('snake_active_session', JSON.stringify(saved));
            }
        } catch (e) {}
        return this.restoreGameState();
    }

    /**
     * เอฟเฟกต์กระตุ้นเมืองและช่องกระดานนูนขึ้น (Step Pop / Bounce) เมื่อตัวละครวิ่งผ่าน
     */
    triggerTileStepPop(t) {
        const tileNum = Number(t);
        if (!tileNum || tileNum < 1 || tileNum > 100) return;

        // 1. นูนตึกเมือง & แลนด์มาร์ค
        if (this.cityMeshes && this.cityMeshes[tileNum]) {
            const cityGrp = this.cityMeshes[tileNum];
            if (cityGrp.userData && cityGrp.userData.cityAnim) {
                const ca = cityGrp.userData.cityAnim;
                if (ca.basePosY === undefined) ca.basePosY = cityGrp.position.y;
                ca.stepPopProgress = 0;
            }
        }

        // 2. นูนช่องกระดานพื้น
        if (this.tileMeshes && this.tileMeshes[tileNum]) {
            const tm = this.tileMeshes[tileNum];
            if (!tm.userData) tm.userData = {};
            if (tm.userData.origY === undefined) tm.userData.origY = tm.position.y;
            tm.userData.stepPopProgress = 0;
        }

        // เสียงป็อปเมื่อเหยียบผ่าน
        if (window.soundEngine && typeof window.soundEngine.playCityPop === 'function') {
            window.soundEngine.playCityPop();
        }
    }

    /**
     * ตรวจสอบระยะ 5-8 เมืองก่อนถึงเส้นชัย (ช่อง 92-99) เพื่อแจ้งเตือนคู่แข่งและแสดงแสงเออร่าพิเศษ
     */
    checkNearFinishAlerts() {
        if (!this.isMatchActive || this.isGameOver || !this.players) return;
        this.nearFinishAlerted = this.nearFinishAlerted || {};

        for (const p of this.players) {
            if (p.isBankrupt) continue;
            if (p.currentTile >= 92 && p.currentTile < 100) {
                const rem = 100 - p.currentTile;
                const lastAlerted = this.nearFinishAlerted[p.id];
                if (lastAlerted !== p.currentTile) {
                    this.nearFinishAlerted[p.id] = p.currentTile;
                    if (p.is_bot) {
                        this.showSkillBanner(`🚨 สัญญาณเตือนภัย! คู่แข่ง "${p.username}" ใกล้ถึงเส้นชัยแล้ว! (เหลืออีก ${rem} ช่อง)`, 'near-finish');
                        this.logMessage(`🚨 [สัญญาณเตือน] คู่แข่ง ${p.username} อยู่ห่างจากเส้นชัยเพียง ${rem} เมือง! ระวังโดนคว้าชัยชนะ!`, 'highlight');
                    } else {
                        this.showSkillBanner(`⚡ โอกาสคว้าชัย! คุณใกล้ถึงเส้นชัยแล้ว! (เหลืออีก ${rem} ช่อง)`, 'near-finish');
                        this.logMessage(`⚡ ${p.username} กำลังพุ่งทะยานสู่เส้นชัย! เหลืออีกเพียง ${rem} เมือง!`, 'highlight');
                    }
                    if (window.soundEngine && typeof window.soundEngine.playNearFinish === 'function') {
                        window.soundEngine.playNearFinish();
                    }
                    this.updateMatchWealthHUD();
                }
            }
        }
    }

    showSkillBanner(text, extraClass = '') {
        const banner = document.getElementById('skill-banner');
        if (banner) {
            banner.innerHTML = text;
            banner.className = `skill-banner active ${extraClass}`.trim();
            if (this._skillBannerTimeout) clearTimeout(this._skillBannerTimeout);
            this._skillBannerTimeout = setTimeout(() => {
                banner.className = 'skill-banner';
            }, extraClass ? 4200 : 3200);
        }
    }

    logMessage(msg, type = '') {
        const feed = document.getElementById('log-feed');
        if (!feed) return;
        const div = document.createElement('div');
        div.className = `log-item ${type}`;
        div.innerText = msg;
        feed.appendChild(div);
        feed.scrollTop = feed.scrollHeight;
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const delta = this.clock.getDelta();
        if (this.controls) this.controls.update();

        const time = this.clock.getElapsedTime();
        this.pointLight.position.x = Math.sin(time * 0.7) * 35;
        this.pointLight.position.z = Math.cos(time * 0.7) * 35;

        // แอนิเมชันแผ่นตัวหมากทรงกลมลอยเด่นด้านหน้า + วงแหวนพลังงานหมุน + ขยายเด่นเมื่อถึงตาเดิน
        this.players.forEach((p, idx) => {
            if (p.mesh && p.mesh.userData && p.mesh.userData.badgeGroup) {
                const ud = p.mesh.userData;
                const bg = ud.badgeGroup;
                const isTurn = Boolean(this.isMatchActive && this.currentTurnIndex === idx && !p.isBankrupt);
                const isHuman = !p.is_bot;

                const floatBase = ud.baseFloatY || (isHuman ? 2.32 : 2.02);
                const bobAmp = isTurn ? 0.20 : 0.12;
                bg.position.y = floatBase + (isTurn ? 0.22 : 0) + Math.sin(time * 3.1 + idx) * bobAmp;

                const targetScale = isTurn ? (isHuman ? 1.16 : 1.10) : (isHuman ? 1.06 : 0.96);
                const curScale = bg.scale.x || 1;
                const nextScale = curScale + (targetScale - curScale) * Math.min(1, delta * 8);
                bg.scale.set(nextScale, nextScale, nextScale);

                if (ud.auraRingMesh) {
                    ud.auraRingMesh.rotation.z -= delta * (isTurn ? 1.9 : 1.1);
                }
                if (ud.groundAuraMesh) {
                    ud.groundAuraMesh.rotation.z += delta * (isTurn ? 1.8 : 0.9);
                }

                // แสงเออร่าเตือนภัยใกล้ถึงเส้นชัย 5-8 ช่อง (ช่อง 92-99)
                const isNearFinish = Boolean(p.currentTile >= 92 && p.currentTile < 100 && !p.isBankrupt && this.isMatchActive);
                if (ud.nearFinishAura) {
                    ud.nearFinishAura.visible = isNearFinish;
                    if (isNearFinish) {
                        ud.nearFinishAura.rotation.z += delta * 3.4;
                        ud.nearFinishAura.material.opacity = 0.78 + Math.sin(time * 6.5) * 0.22;
                        const auraPulse = 1.0 + Math.sin(time * 5.2) * 0.14;
                        ud.nearFinishAura.scale.set(auraPulse, auraPulse, auraPulse);
                    }
                }

                if (ud.spotlightBeam && ud.spotlightBeam.material) {
                    ud.spotlightBeam.material.opacity = isNearFinish
                        ? (0.45 + Math.sin(time * 7.5) * 0.22)
                        : (isTurn ? (0.30 + Math.sin(time * 4.2) * 0.08) : (isHuman ? 0.20 : 0.08));
                }

                if (this.camera) {
                    bg.lookAt(this.camera.position);
                }
            }
        });

        // แอนิเมชันพญางู 3D บนกระดาน
        if (this.snakeObjects) {
            for (const headTile of Object.keys(this.snakes)) {
                const sn = this.snakeObjects[Number(headTile)];
                if (sn && !sn.isAnimating && sn.headGroup) {
                    const ph = time * 2.8 + sn.phaseOffset;
                    sn.headGroup.position.x = sn.headPos.x + Math.sin(ph) * 0.25;
                    sn.headGroup.position.y = sn.headPos.y + 1.25 + Math.cos(ph * 1.3) * 0.18;
                    if (sn.lowerJawPivot) {
                        sn.lowerJawPivot.rotation.x = 0.18 + Math.sin(ph * 1.6) * 0.1;
                    }
                    if (sn.tongueGroup) {
                        sn.tongueGroup.position.z = Math.sin(ph * 3.5) * 0.22;
                    }
                }
            }
        }

        // แอนิเมชันจุดสตาร์ท (วงแหวนหมุน + ขอบกะพริบ)
        if (this.startAnimations) {
            const sa = this.startAnimations;
            if (sa.innerRing) sa.innerRing.rotation.z += delta * 0.5;
            if (sa.rim && sa.rim.material) {
                sa.rim.material.opacity = 0.75 + Math.sin(time * 2.5) * 0.2;
            }
        }

        // แอนิเมชันเส้นชัย (ลำแสงทอง + วงแหวน + เพชรหมุน + เตือนภัยเมื่อมีคนใกล้ถึงเส้นชัย 5-8 ช่อง)
        if (this.goalAnimations) {
            const ga = this.goalAnimations;
            const anyNearFinish = this.players && this.players.some(p => p.currentTile >= 92 && p.currentTile < 100 && !p.isBankrupt && this.isMatchActive);

            if (ga.diamond) {
                ga.diamond.rotation.y += delta * (anyNearFinish ? 5.2 : 2.2);
                ga.diamond.position.y = 6.2 + Math.sin(time * (anyNearFinish ? 6.5 : 3.5)) * (anyNearFinish ? 0.42 : 0.25);
            }
            if (ga.pagodaOrb) {
                ga.pagodaOrb.rotation.y += delta * (anyNearFinish ? 2.5 : 0.8);
            }
            if (ga.auraRing1) ga.auraRing1.rotation.z += delta * (anyNearFinish ? 3.0 : 0.9);
            if (ga.auraRing2) ga.auraRing2.rotation.z -= delta * (anyNearFinish ? 4.2 : 1.4);
            if (ga.beam && ga.beam.material) {
                if (anyNearFinish) {
                    ga.beam.material.opacity = 0.45 + Math.sin(time * 5.5) * 0.22;
                    const bScale = 1.35 + Math.sin(time * 3.8) * 0.15;
                    ga.beam.scale.set(bScale, 1.0, bScale);
                } else {
                    ga.beam.material.opacity = 0.20 + Math.sin(time * 2.2) * 0.07;
                    ga.beam.scale.set(1.0, 1.0, 1.0);
                }
            }
            if (ga.light) {
                ga.light.intensity = anyNearFinish
                    ? (6.8 + Math.sin(time * 6.5) * 2.2)
                    : (3.0 + Math.sin(time * 2.8) * 0.5);
                if (anyNearFinish) {
                    ga.light.color.setHex(0xff9900); // สีส้มทองเตือนภัยคู่แข่ง
                } else {
                    ga.light.color.setHex(0xffca28);
                }
            }

            // เอฟเฟกต์ไฟรันเวย์ส่องสว่างตามช่อง 92 ถึง 100 นำทางสู่เส้นชัย
            if (anyNearFinish && this.tileMeshes) {
                for (let tNum = 92; tNum <= 100; tNum++) {
                    const tm = this.tileMeshes[tNum];
                    if (tm && tm.material && tm.material[2]) {
                        const phase = time * 7.5 - (100 - tNum) * 0.75;
                        const wave = Math.max(0, Math.sin(phase));
                        tm.material[2].emissiveIntensity = 0.25 + wave * 0.65;
                    }
                }
            }
        }

        // แอนิเมชันเมือง 3D & แลนด์มาร์ค (เด้งตอนสร้าง + วงแหวนเวทย์หมุน + เพชรราชันย์ลอยตัว + เสาแสงพัลส์ + วิ่งผ่านนูนขึ้น)
        if (this.cityMeshes) {
            const safeDelta = Math.min(delta, 0.08);
            for (const tileKey of Object.keys(this.cityMeshes)) {
                const cityGrp = this.cityMeshes[tileKey];
                if (!cityGrp || !cityGrp.userData || !cityGrp.userData.cityAnim) continue;
                const ca = cityGrp.userData.cityAnim;

                if (ca.buildProgress < 1) {
                    ca.buildProgress = Math.min(1, ca.buildProgress + safeDelta * 2.8);
                    const p = ca.buildProgress;
                    // Elastic spring pop-in (0.05 -> 1.12 -> 1.0)
                    const bounce = p < 0.72
                        ? 0.05 + (p / 0.72) * 1.07
                        : 1.12 - ((p - 0.72) / 0.28) * 0.12;
                    cityGrp.scale.set(bounce, bounce, bounce);
                } else if (ca.stepPopProgress !== undefined && ca.stepPopProgress < 1) {
                    // เอฟเฟกต์เมืองนูนขึ้นเมื่อตัวละครวิ่งผ่าน (Step Pop / Bounce)
                    ca.stepPopProgress = Math.min(1, ca.stepPopProgress + safeDelta * 4.2);
                    const sp = ca.stepPopProgress;
                    const pop = Math.sin(sp * Math.PI) * Math.exp(-sp * 1.6);
                    const scaleY = 1.0 + pop * 0.55; // นูนขึ้นสูง +55%
                    const scaleXZ = 1.0 + pop * 0.22;
                    cityGrp.scale.set(scaleXZ, scaleY, scaleXZ);
                    cityGrp.position.y = (ca.basePosY || 0) + pop * 0.65;
                    if (sp >= 1) {
                        cityGrp.scale.set(1, 1, 1);
                        cityGrp.position.y = ca.basePosY || 0;
                        delete ca.stepPopProgress;
                    }
                }

                if (ca.rotatingHalo) {
                    ca.rotatingHalo.rotation.z += safeDelta * 1.25;
                }
                if (ca.rotatingHalo2) {
                    ca.rotatingHalo2.rotation.z -= safeDelta * 1.85;
                }
                if (ca.floatingCrest) {
                    ca.floatingCrest.rotation.y += safeDelta * 2.1;
                    ca.floatingCrest.position.y = ca.crestBaseY + Math.sin(time * 3.2 + ca.phase) * 0.22;
                }
                if (ca.beamMesh && ca.beamMesh.material) {
                    ca.beamMesh.material.opacity = 0.16 + Math.sin(time * 2.6 + ca.phase) * 0.06;
                }
                if (ca.beacons && ca.beacons.length) {
                    const rotStep = safeDelta * 1.6;
                    for (let bIdx = 0; bIdx < ca.beacons.length; bIdx++) {
                        ca.beacons[bIdx].rotation.y += rotStep;
                    }
                }
            }
        }

        // แอนิเมชันช่องกระดานนูนขึ้นเมื่อตัวละครวิ่งผ่าน (Tile Step Pop)
        if (this.tileMeshes) {
            const safeDelta = Math.min(delta, 0.08);
            for (let tNum = 1; tNum <= 100; tNum++) {
                const tm = this.tileMeshes[tNum];
                if (tm && tm.userData && tm.userData.stepPopProgress !== undefined && tm.userData.stepPopProgress < 1) {
                    tm.userData.stepPopProgress = Math.min(1, tm.userData.stepPopProgress + safeDelta * 4.5);
                    const sp = tm.userData.stepPopProgress;
                    const pop = Math.sin(sp * Math.PI) * Math.exp(-sp * 1.8);
                    tm.scale.set(1.0 + pop * 0.08, 1.0 + pop * 0.45, 1.0 + pop * 0.08);
                    tm.position.y = (tm.userData.origY || 0) + pop * 0.40;
                    if (sp >= 1) {
                        tm.scale.set(1, 1, 1);
                        tm.position.y = tm.userData.origY || 0;
                        delete tm.userData.stepPopProgress;
                    }
                }
            }
        }

        // ⏱️ Synchronize & Drive Match Timer accurately every frame (10 นาทีลดลงทุกวินาทีอย่างลื่นไหล)
        if (this.isMatchActive && !this.isGameOver) {
            if (!this.matchStartTime) {
                this.matchStartTime = Date.now();
            }
            const currentElapsed = Math.floor((Date.now() - this.matchStartTime) / 1000);
            const rem = Math.max(0, (this.matchTimeLimit || 600) - currentElapsed);
            if (rem !== this.matchTimeRemaining) {
                this.matchTimeRemaining = rem;
                this.updateMatchTimerHUD();

                // เตือนเมื่อเหลือ 1 นาที (60 วินาที)
                if (rem <= 60 && rem > 30 && !this.warned1Min) {
                    this.warned1Min = true;
                    if (typeof showToast === 'function') {
                        showToast('⏰ เหลือเวลาอีก 1 นาที! ใครมีทองและสิ่งก่อสร้างรวมเยอะสุดจะชนะ!');
                    }
                    this.logMessage('⚠️ [แจ้งเตือนเวลา] เหลือเวลาแข่งขันอีก 1 นาทีสุดท้าย! เร่งสร้างเมืองและทำแต้ม!', 'warning');
                    if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                        window.soundEngine.playAlert();
                    }
                }
                // เตือนเมื่อเหลือ 30 วินาที
                else if (rem <= 30 && rem > 0 && !this.warned30Sec) {
                    this.warned30Sec = true;
                    if (typeof showToast === 'function') {
                        showToast('🚨 30 วินาทีสุดท้าย! ระบบจะตัดสินผู้ชนะจากสินทรัพย์และสิ่งก่อสร้างรวม!');
                    }
                    this.logMessage('🚨 [แจ้งเตือนเวลา] 30 วินาทีสุดท้าย! ผู้ที่มีทองและมูลค่าสิ่งก่อสร้างสูงสุดจะคว้าชัยชนะทันที!', 'warning');
                    if (window.soundEngine && typeof window.soundEngine.playAlert === 'function') {
                        window.soundEngine.playAlert();
                    }
                }

                // หมดเวลา 10 นาที (0 วินาที) -> ตัดสินผู้ชนะทันที!
                if (rem <= 0) {
                    this.handleMatchTimeoutVictory();
                }
            }
        }

        this.updateSpeechBubblesPosition();

        this.renderer.render(this.scene, this.camera);
    }
}

window.SnakeGame3D = SnakeGame3D;
