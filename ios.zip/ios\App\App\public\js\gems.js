/**
 * js/gems.js
 * Gem & Jewelry Client Controller
 * Manages Player Gem Inventory, Card Grade Slots (S=1, S+=2, SS+=3), 
 * Equip/Unequip, and Shadow Gacha Event Modals
 */

window.playerGemsData = {
    ownedGems: [],
    equippedSlots: [null, null, null],
    slotLimit: 3,
    activeCardGrade: 'SS+'
};

// ซิงก์อัญมณีเริ่มต้นทันทีหากมีข้อมูลใน __OAUTH_INSTANT_USER__ หรือ DEFAULT_USER
(function initInstantEquippedGems() {
    const instantGems = (window.__OAUTH_INSTANT_USER__ && Array.isArray(window.__OAUTH_INSTANT_USER__.equipped_gems))
        ? window.__OAUTH_INSTANT_USER__.equipped_gems
        : ((window.DEFAULT_USER && Array.isArray(window.DEFAULT_USER.equipped_gems)) ? window.DEFAULT_USER.equipped_gems : []);
    if (instantGems.length > 0) {
        instantGems.forEach(g => {
            if (g && g.slot_index >= 1 && g.slot_index <= 3) {
                window.playerGemsData.equippedSlots[g.slot_index - 1] = g;
            }
        });
        if (window.DEFAULT_USER) {
            window.DEFAULT_USER.equipped_gems = instantGems;
        }
        const gameInst = window.game || window.game3D;
        if (gameInst && typeof gameInst.updatePlayerGems === 'function') {
            gameInst.updatePlayerGems(instantGems);
        }
        if (window.clanHouse && typeof window.clanHouse.updatePlayerGems === 'function') {
            window.clanHouse.updatePlayerGems(instantGems);
        }
    }
})();

// Global SVG Preview & Grade Emblem Generators (ใช้ร่วมกันทุกหน้าสุ่ม/คลัง)
function adjustColorBrightness(hex, percent) {
    hex = (hex || '#ffd700').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let num = parseInt(hex, 16);
    let r = (num >> 16) + Math.round(255 * (percent / 100));
    let g = ((num >> 8) & 0x00FF) + Math.round(255 * (percent / 100));
    let b = (num & 0x0000FF) + Math.round(255 * (percent / 100));
    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
window.adjustColorBrightness = adjustColorBrightness;

// Parse any date string as Thailand Time (Asia/Bangkok / UTC+7)
window.parseThaiDate = function (dateStr) {
    if (!dateStr) return null;
    let s = String(dateStr).trim();
    const mdyMatch = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(AM|PM))?)?$/i);
    if (mdyMatch) {
        let [_, m, d, y, h, min, sec, ampm] = mdyMatch;
        let hour = h ? parseInt(h, 10) : 0;
        if (ampm) {
            ampm = ampm.toUpperCase();
            if (ampm === 'PM' && hour < 12) hour += 12;
            if (ampm === 'AM' && hour === 12) hour = 0;
        }
        return new Date(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10), hour, min ? parseInt(min, 10) : 0, sec ? parseInt(sec, 10) : 0);
    }
    let iso = s.replace(' ', 'T');
    if (!iso.includes('+') && !iso.includes('Z')) {
        if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(iso)) {
            iso += ':00+07:00';
        } else if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(iso)) {
            iso += '+07:00';
        } else {
            iso = iso.replace(/-/g, '/');
        }
    }
    const d = new Date(iso);
    return isNaN(d.getTime()) ? null : d;
};

// Check if a Thailand date string has passed
window.isThaiDateExpired = function (dateStr) {
    if (!dateStr) return false;
    const d = window.parseThaiDate(dateStr);
    return d ? (Date.now() > d.getTime()) : false;
};

window.formatEventDateRangeShort = function (startStr, endStr) {
    if (!endStr) return '';
    try {
        const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        const sD = window.parseThaiDate(startStr);
        const eD = window.parseThaiDate(endStr);
        if (!eD) return '';

        const getParts = (d) => {
            const parts = new Intl.DateTimeFormat('en-US', {
                timeZone: 'Asia/Bangkok',
                month: 'numeric',
                day: 'numeric'
            }).formatToParts(d);
            let day = '', m = 1;
            for (const p of parts) {
                if (p.type === 'day') day = p.value;
                if (p.type === 'month') m = parseInt(p.value, 10);
            }
            return { day, month: m, monthName: thaiMonths[m - 1] };
        };

        const eP = getParts(eD);
        if (sD) {
            const sP = getParts(sD);
            if (sP.monthName === eP.monthName) {
                return `${sP.day} - ${eP.day} ${eP.monthName}`;
            }
            return `${sP.day} ${sP.monthName} - ${eP.day} ${eP.monthName}`;
        }
        return `ถึง ${eP.day} ${eP.monthName}`;
    } catch (_) {
        return '';
    }
};

window.formatEventDateLong = function (dateStr) {
    if (!dateStr || dateStr === '-') dateStr = '2026-11-16 14:50:00';
    try {
        const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        const d = (typeof window.parseThaiDate === 'function' ? window.parseThaiDate(dateStr) : null) || new Date(String(dateStr).replace('T', ' ').replace(/-/g, '/'));
        if (!d || isNaN(d.getTime())) return String(dateStr);
        const parts = new Intl.DateTimeFormat('en-US', {
            timeZone: 'Asia/Bangkok',
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            hour12: false
        }).formatToParts(d);
        let day = '', month = 1, year = 0, hour = '', min = '';
        for (const p of parts) {
            if (p.type === 'day') day = p.value;
            if (p.type === 'month') month = parseInt(p.value, 10);
            if (p.type === 'year') year = parseInt(p.value, 10) + 543;
            if (p.type === 'hour') hour = p.value.padStart(2, '0');
            if (p.type === 'minute') min = p.value.padStart(2, '0');
        }
        return `${day} ${months[month - 1] || ''} ${year} เวลา ${hour}:${min} น.`;
    } catch (_) {
        return String(dateStr);
    }
};

window.generateGemSvgPreview = function (shape = 'pentagon', grade = 'SS+', size = 52, customColor = null, auraType = 'pulse', particleFx = 'spark', auraIntensity = 'high', showGradeText = true) {
    const s = String(shape || 'pentagon').toLowerCase();
    const g = String(grade || 'SS+').toUpperCase();
    const aura = String(auraType || 'pulse').toLowerCase();
    const pfx = String(particleFx || 'spark').toLowerCase();
    const intensity = String(auraIntensity || 'high').toLowerCase();

    let mainColor = customColor;
    if (!mainColor) {
        if (g === 'SS+') mainColor = '#c084fc'; // Purple
        if (g === 'ZZ+') mainColor = '#f43f5e'; // Crimson-Gold Prismatic
        else if (g === 'ZZ') mainColor = '#10b981'; // Emerald Neon
        else if (g === 'SS+') mainColor = '#c084fc'; // Purple
        else if (g === 'S+') mainColor = '#00e5ff'; // Cyan
        else mainColor = '#ffd700'; // Gold
    }

    let glowColor = mainColor + 'cc';
    let innerColor = adjustColorBrightness(mainColor, 40);
    let facetColor = adjustColorBrightness(mainColor, -40);

    const randId = 'cg_' + Math.random().toString(36).substr(2, 6);

    // Intensity factors
    let blurRadius = intensity === 'ultra' ? 14 : (intensity === 'high' ? 8 : 4);
    let dropShadowSpread = intensity === 'ultra' ? '0 0 22px ' + mainColor + ', 0 0 35px ' + glowColor : (intensity === 'high' ? '0 0 14px ' + glowColor : '0 0 7px ' + glowColor);
    let auraOpacity = intensity === 'ultra' ? 1.0 : (intensity === 'high' ? 0.85 : 0.6);

    // Aura SVG Layer
    let auraMarkup = '';
    if (aura === 'pulse') {
        auraMarkup = `
            <g class="gem-fx-pulse" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="42" fill="none" stroke="${mainColor}" stroke-width="2" stroke-dasharray="4 4" opacity="0.6">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="8s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="36" fill="${mainColor}" opacity="0.22" filter="url(#glow_${randId})">
                    <animate attributeName="r" values="32;42;32" dur="2s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.15;0.35;0.15" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="28" fill="${innerColor}" opacity="0.3" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'fire') {
        auraMarkup = `
            <g class="gem-fx-fire" opacity="${auraOpacity}">
                <path d="M50,8 Q60,30 68,26 Q78,40 68,58 Q78,72 65,82 Q50,94 35,82 Q22,72 32,58 Q22,40 32,26 Q40,30 50,8 Z" fill="url(#fire_grad_${randId})" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="scale" values="1;1.08;0.98;1" keyTimes="0;0.35;0.7;1" dur="1.4s" repeatCount="indefinite" transform-origin="50 50"/>
                </path>
                <circle cx="50" cy="50" r="38" fill="none" stroke="#f59e0b" stroke-width="1.8" opacity="0.5" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'electric') {
        auraMarkup = `
            <g class="gem-fx-electric" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="40" fill="none" stroke="#38bdf8" stroke-width="1.2" opacity="0.4"/>
                <polyline points="50,10 54,28 66,32 56,44 68,60 50,56 46,74 38,58 28,62 38,46 26,34 40,30 50,10" fill="none" stroke="#e0f2fe" stroke-width="2.2" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.2;0.9;0.3;1" dur="0.8s" repeatCount="indefinite"/>
                </polyline>
                <polyline points="48,16 60,34 46,48 62,64 44,82" fill="none" stroke="#67e8f9" stroke-width="1.6" opacity="0.7">
                    <animate attributeName="opacity" values="0.2;0.9;0.1;1;0.4" dur="0.6s" repeatCount="indefinite"/>
                </polyline>
            </g>
        `;
    } else if (aura === 'cosmic') {
        auraMarkup = `
            <g class="gem-fx-cosmic" opacity="${auraOpacity}">
                <ellipse cx="50" cy="50" rx="44" ry="24" fill="none" stroke="url(#cosmic_grad_${randId})" stroke-width="2.5" transform="rotate(-30 50 50)" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="-30 50 50" to="330 50 50" dur="6s" repeatCount="indefinite"/>
                </ellipse>
                <ellipse cx="50" cy="50" rx="44" ry="24" fill="none" stroke="${mainColor}" stroke-width="1.5" stroke-dasharray="6 8" transform="rotate(35 50 50)">
                    <animateTransform attributeName="transform" type="rotate" from="35 50 50" to="-325 50 50" dur="8s" repeatCount="indefinite"/>
                </ellipse>
                <circle cx="50" cy="50" r="36" fill="${facetColor}" opacity="0.35" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'rainbow') {
        auraMarkup = `
            <g class="gem-fx-rainbow" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="41" fill="none" stroke="url(#rainbow_grad_${randId})" stroke-width="3.5" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="34" fill="none" stroke="url(#rainbow_grad_${randId})" stroke-width="1.8" stroke-dasharray="8 6" opacity="0.8">
                    <animateTransform attributeName="transform" type="rotate" from="360 50 50" to="0 50 50" dur="3s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    } else if (aura === 'vortex') {
        auraMarkup = `
            <g class="gem-fx-vortex" opacity="${auraOpacity}">
                <path d="M50,50 Q65,25 80,30 Q92,42 85,60 Q72,82 50,75 Q28,70 20,50 Q18,30 35,18 Q55,10 75,20" fill="none" stroke="${mainColor}" stroke-width="2.5" stroke-dasharray="10 5" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="3.5s" repeatCount="indefinite"/>
                </path>
                <circle cx="50" cy="50" r="32" fill="${mainColor}" opacity="0.25" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'divine') {
        auraMarkup = `
            <g class="gem-fx-divine" opacity="${auraOpacity}">
                <g filter="url(#glow_${randId})">
                    <polygon points="50,6 55,38 88,24 62,48 94,50 62,54 88,76 55,62 50,94 45,62 12,76 38,54 6,50 38,48 12,24 45,38" fill="url(#divine_grad_${randId})" opacity="0.75">
                        <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="12s" repeatCount="indefinite"/>
                    </polygon>
                </g>
                <circle cx="50" cy="50" r="35" fill="#fef08a" opacity="0.2" filter="url(#glow_${randId})"/>
            </g>
        `;
    } else if (aura === 'dark') {
        auraMarkup = `
            <g class="gem-fx-dark" opacity="${auraOpacity}">
                <circle cx="50" cy="50" r="42" fill="#090514" stroke="#e11d48" stroke-width="2" stroke-dasharray="5 5" opacity="0.9">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="-360 50 50" dur="7s" repeatCount="indefinite"/>
                </circle>
                <circle cx="50" cy="50" r="34" fill="#180026" opacity="0.7" filter="url(#glow_${randId})">
                    <animate attributeName="r" values="30;38;30" dur="2.2s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    }

    // Particle FX Layer
    let particleMarkup = '';
    if (pfx === 'spark') {
        particleMarkup = `
            <g class="gem-pfx-spark">
                <polygon points="20,18 22,23 27,25 22,27 20,32 18,27 13,25 18,23" fill="#ffffff" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.2;1;0.2" dur="1.2s" repeatCount="indefinite"/>
                    <animateTransform attributeName="transform" type="scale" values="0.8;1.3;0.8" dur="1.2s" repeatCount="indefinite" transform-origin="20 25"/>
                </polygon>
                <polygon points="80,22 82,26 86,28 82,30 80,34 78,30 74,28 78,26" fill="#fef08a" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite"/>
                    <animateTransform attributeName="transform" type="scale" values="1.2;0.7;1.2" dur="1.5s" repeatCount="indefinite" transform-origin="80 28"/>
                </polygon>
                <polygon points="82,72 83.5,75 87,76.5 83.5,78 82,81 80.5,78 77,76.5 80.5,75" fill="#67e8f9" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.3;1;0.3" dur="1.8s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="18,74 20,77 24,79 20,81 18,85 16,81 12,79 16,77" fill="${innerColor}" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.8;0.2;0.8" dur="1.4s" repeatCount="indefinite"/>
                </polygon>
            </g>
        `;
    } else if (pfx === 'orbit_ring') {
        particleMarkup = `
            <g class="gem-pfx-orbit">
                <ellipse cx="50" cy="50" rx="42" ry="16" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-dasharray="6 12" transform="rotate(-25 50 50)" opacity="0.8" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="-25 50 50" to="335 50 50" dur="4s" repeatCount="indefinite"/>
                </ellipse>
                <circle cx="88" cy="40" r="3" fill="#ffffff" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="12" cy="60" r="2.5" fill="${innerColor}" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite"/>
                </circle>
            </g>
        `;
    } else if (pfx === 'crystal_shard') {
        particleMarkup = `
            <g class="gem-pfx-shards">
                <polygon points="16,36 20,32 24,36 20,42" fill="${innerColor}" stroke="#fff" stroke-width="0.8" opacity="0.9" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="translate" values="0,0; 2,-6; 0,0" dur="2s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="80,62 84,58 88,62 84,68" fill="${facetColor}" stroke="#fff" stroke-width="0.8" opacity="0.9" filter="url(#glow_${randId})">
                    <animateTransform attributeName="transform" type="translate" values="0,0; -3,6; 0,0" dur="2.4s" repeatCount="indefinite"/>
                </polygon>
                <polygon points="76,28 79,24 83,28 79,33" fill="${mainColor}" stroke="#fff" stroke-width="0.8" opacity="0.85">
                    <animateTransform attributeName="transform" type="translate" values="0,0; 3,-4; 0,0" dur="1.8s" repeatCount="indefinite"/>
                </polygon>
            </g>
        `;
    } else if (pfx === 'energy_stream') {
        particleMarkup = `
            <g class="gem-pfx-stream">
                <line x1="36" y1="88" x2="36" y2="12" stroke="url(#stream_grad_${randId})" stroke-width="2" opacity="0.75" stroke-dasharray="8 12">
                    <animate attributeName="stroke-dashoffset" from="40" to="0" dur="1.2s" repeatCount="indefinite"/>
                </line>
                <line x1="64" y1="88" x2="64" y2="12" stroke="url(#stream_grad_${randId})" stroke-width="2" opacity="0.75" stroke-dasharray="8 12">
                    <animate attributeName="stroke-dashoffset" from="40" to="0" dur="1.5s" repeatCount="indefinite"/>
                </line>
                <line x1="50" y1="92" x2="50" y2="8" stroke="#ffffff" stroke-width="1.4" opacity="0.6" stroke-dasharray="12 16">
                    <animate attributeName="stroke-dashoffset" from="56" to="0" dur="1s" repeatCount="indefinite"/>
                </line>
            </g>
        `;
    } else if (pfx === 'flare_burst') {
        particleMarkup = `
            <g class="gem-pfx-flare">
                <circle cx="50" cy="50" r="22" fill="none" stroke="#ffffff" stroke-width="2.5" opacity="0.8">
                    <animate attributeName="r" values="16;44;16" dur="1.8s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.9;0;0.9" dur="1.8s" repeatCount="indefinite"/>
                </circle>
                <line x1="15" y1="50" x2="85" y2="50" stroke="#ffffff" stroke-width="2" opacity="0.75" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.4" dur="1.2s" repeatCount="indefinite"/>
                </line>
                <line x1="50" y1="15" x2="50" y2="85" stroke="#ffffff" stroke-width="2" opacity="0.75" filter="url(#glow_${randId})">
                    <animate attributeName="opacity" values="0.4;1;0.4" dur="1.2s" repeatCount="indefinite"/>
                </line>
            </g>
        `;
    }

    let shapeMarkup = '';
    if (s === 'triangle') {
        shapeMarkup = `
            <polygon points="50,12 88,80 12,80" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,12 50,56 12,80" fill="${facetColor}" opacity="0.65"/>
            <polygon points="50,12 88,80 50,56" fill="${innerColor}" opacity="0.55"/>
            <polygon points="12,80 50,56 88,80" fill="${facetColor}" opacity="0.85"/>
            <circle cx="50" cy="54" r="3.5" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    } else if (s === 'square' || s === 'diamond') {
        shapeMarkup = `
            <polygon points="50,10 90,50 50,90 10,50" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,26 74,50 50,74 26,50" fill="${innerColor}" opacity="0.5" stroke="#ffffff" stroke-width="1.2"/>
            <line x1="50" y1="10" x2="50" y2="26" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="90" y1="50" x2="74" y2="50" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="50" y1="90" x2="50" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <line x1="10" y1="50" x2="26" y2="50" stroke="#ffffff" stroke-width="1.5" opacity="0.8"/>
            <circle cx="45" cy="45" r="3.5" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    } else if (s === 'star') {
        shapeMarkup = `
            <polygon points="50,5 64,36 98,36 70,57 81,91 50,70 19,91 30,57 2,36 36,36" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2" filter="url(#glow_${randId})"/>
            <polygon points="50,24 59,42 79,42 63,54 69,74 50,61 31,74 37,54 21,42 41,42" fill="${innerColor}" opacity="0.55" stroke="#ffffff" stroke-width="1"/>
            <circle cx="50" cy="50" r="3.5" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    } else {
        // Pentagon
        shapeMarkup = `
            <polygon points="50,10 88,38 74,86 26,86 12,38" fill="url(#gem_grad_${randId})" stroke="${mainColor}" stroke-width="2.5" filter="url(#glow_${randId})"/>
            <polygon points="50,30 72,48 64,74 36,74 28,48" fill="${innerColor}" opacity="0.45" stroke="#ffffff" stroke-width="1.2"/>
            <line x1="50" y1="10" x2="50" y2="30" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="88" y1="38" x2="72" y2="48" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="74" y1="86" x2="64" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="26" y1="86" x2="36" y2="74" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <line x1="12" y1="38" x2="28" y2="48" stroke="#ffffff" stroke-width="1.5" opacity="0.75"/>
            <circle cx="50" cy="52" r="4" fill="#ffffff" filter="url(#glow_${randId})"/>
        `;
    }

    return `
        <svg viewBox="0 0 100 100" width="${size}" height="${size}" style="filter: drop-shadow(${dropShadowSpread}); vertical-align: middle; overflow: visible;">
            <defs>
                <filter id="glow_${randId}" x="-30%" y="-30%" width="160%" height="160%">
                    <feGaussianBlur stdDeviation="${blurRadius / 3}" result="blur" />
                    <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
                <linearGradient id="gem_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="${innerColor}" stop-opacity="0.95" />
                    <stop offset="50%" stop-color="${mainColor}" stop-opacity="0.85" />
                    <stop offset="100%" stop-color="${facetColor}" stop-opacity="0.95" />
                </linearGradient>
                <linearGradient id="fire_grad_${randId}" x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stop-color="#ef4444" stop-opacity="0.8" />
                    <stop offset="50%" stop-color="#f59e0b" stop-opacity="0.9" />
                    <stop offset="100%" stop-color="#fef08a" stop-opacity="0.95" />
                </linearGradient>
                <linearGradient id="cosmic_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#a855f7" />
                    <stop offset="50%" stop-color="#38bdf8" />
                    <stop offset="100%" stop-color="#ec4899" />
                </linearGradient>
                <linearGradient id="rainbow_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#ef4444" />
                    <stop offset="20%" stop-color="#f97316" />
                    <stop offset="40%" stop-color="#facc15" />
                    <stop offset="60%" stop-color="#10b981" />
                    <stop offset="80%" stop-color="#06b6d4" />
                    <stop offset="100%" stop-color="#8b5cf6" />
                </linearGradient>
                <linearGradient id="divine_grad_${randId}" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#ffffff" />
                    <stop offset="50%" stop-color="#fde047" />
                    <stop offset="100%" stop-color="#eab308" />
                </linearGradient>
                <linearGradient id="stream_grad_${randId}" x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stop-color="${mainColor}" stop-opacity="0.1" />
                    <stop offset="100%" stop-color="#ffffff" stop-opacity="0.9" />
                </linearGradient>
                <linearGradient id="grade_txt_grad_${randId}" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#ffffff" />
                    <stop offset="45%" stop-color="#ffffff" />
                    <stop offset="100%" stop-color="${mainColor}" />
                </linearGradient>
            </defs>
            ${auraMarkup}
            ${shapeMarkup}
            ${particleMarkup}
            ${showGradeText ? `<text x="50" y="${s === 'triangle' ? 67 : 58}" text-anchor="middle" font-family="'Arial Black','Segoe UI Black',Impact,sans-serif" font-weight="900" font-style="italic" font-size="${g.length >= 3 ? 25 : (g.length === 2 ? 29 : 33)}" fill="url(#grade_txt_grad_${randId})" stroke="rgba(0,0,0,0.92)" stroke-width="4.5" paint-order="stroke fill" style="filter:drop-shadow(0 0 4px ${mainColor}) drop-shadow(0 2px 3px rgba(0,0,0,0.95)); pointer-events:none; user-select:none;">${g}</text>` : ''}
        </svg>
    `;
};

window.gradeEmblemInnerHtml = function (grade) {
    const g = String(grade || '').toUpperCase().trim().replace(/[<>&"]/g, '');
    const m = g.match(/^([A-Z]+)(\+*)$/);
    if (!m) return g;
    return m[1] + (m[2] ? `<span class="ge-plus">${m[2]}</span>` : '');
};

window.gradeEmblemHtml = function (grade, color = '#f59e0b', fontPx = 28) {
    const fs = String(grade || '').length >= 3 ? Math.round(fontPx * 0.78) : fontPx;
    return `<div class="grade-emblem" style="--gc:${color}; font-size:${fs}px;"><span class="ge-txt">${window.gradeEmblemInnerHtml(grade)}</span></div>`;
};

/**
 * 💎 เรนเดอร์การ์ดรูปโปรไฟล์พร้อมถาดอัญมณี 3 ช่องด้านขวาตามภาพต้นแบบเกมเศรษฐี 100%
 * รองรับทั้ง Desktop, แท็บเล็ต, และมือถือ (iOS / Android)
 */
window.renderCardWithGemTrayHtml = function (member, options = {}) {
    if (!member) return '';
    const avatarUrl = member.avatar_url || member.picture || member.avatarUrl || 'avatars/google_avatar.png';
    const grade = String(member.character_grade || member.grade || (member.level >= 20 ? 'SS+' : (member.level >= 12 ? 'S+' : (member.level >= 6 ? 'S' : 'A')))).toUpperCase();
    const level = member.level || 1;
    const isOnline = Boolean(member.is_online);
    const size = Number(options.size) || 48; // ขนาดของการ์ดรูปตัวละคร
    const gems = Array.isArray(member.equipped_gems) ? member.equipped_gems : (Array.isArray(member.equippedGems) ? member.equippedGems : []);

    let auraClass = 'aura-ss-plus';
    if (grade === 'SS+') auraClass = 'aura-ss-plus';
    else if (grade === 'S+') auraClass = 'aura-s-plus';
    else if (grade === 'S') auraClass = 'aura-s';
    else if (grade === 'A+' || grade === 'A') auraClass = 'aura-a-plus';
    else auraClass = 'aura-default';

    // ถาดอัญมณี 3 ช่องด้านขวา แสดงผลตลอดเวลา 100% ตามภาพต้นแบบ
    const slotClasses = ['slot-blue', 'slot-red', 'slot-gold'];
    const defaultShapes = ['triangle', 'square', 'pentagon'];
    const defaultColors = ['#38bdf8', '#ef4444', '#f59e0b'];
    const boxSize = Math.max(13, Math.round(size * 0.28));
    let boxesHtml = '';

    for (let idx = 0; idx < 3; idx++) {
        const g = (Array.isArray(gems) && gems[idx]) ? gems[idx] : null;
        if (!g) {
            boxesHtml += `
                <div class="side-gem-socket-box ${slotClasses[idx]}" title="ช่องที่ ${idx + 1} (ว่าง)" style="width:${boxSize}px; height:${boxSize}px; opacity:0.4; border-style:dashed; box-shadow:none;">
                    <span style="font-size:${Math.max(8, Math.round(boxSize * 0.45))}px; color:rgba(148,163,184,0.5); line-height:1;">•</span>
                </div>
            `;
            continue;
        }
        const shape = g.shape || defaultShapes[idx];
        const gGrade = g.grade || 'S';
        const gColor = g.gem_color || (idx === 0 ? '#c084fc' : (idx === 1 ? '#00e5ff' : '#ffd700'));
        const gAura = g.aura_type || 'pulse';
        const gPfx = g.particle_fx || 'spark';
        const gName = g.name || 'อัญมณีประจำช่อง';
        const gSkill = g.skill_name ? ` [${g.skill_name}]` : '';

        const svgIcon = (typeof window.generateGemSvgPreview === 'function')
            ? window.generateGemSvgPreview(shape, gGrade, boxSize - 2, gColor, gAura, gPfx, 'high')
            : '💎';

        boxesHtml += `
            <div class="side-gem-socket-box ${slotClasses[idx]}" title="${gName} (${gGrade})${gSkill}" style="width:${boxSize}px; height:${boxSize}px;">
                ${svgIcon}
            </div>
        `;
    }

    const gemColumnHtml = `
        <div class="side-gem-sockets-column" style="gap:${Math.max(1.5, Math.round(size * 0.04))}px; padding:2px ${Math.max(2, Math.round(size * 0.05))}px;">
            ${boxesHtml}
        </div>
    `;

    return `
        <div class="card-with-gems-container">
            <div class="clan-member-avatar-wrap ${auraClass}" style="width:${size}px; height:${size}px;">
                <span class="avatar-grade-tag ${grade}">${grade}</span>
                <img src="${avatarUrl}" class="clan-member-avatar-img" onerror="this.src='avatars/google_avatar.png';">
                <span class="card-level-badge">Lv.${level}</span>
                <span style="position:absolute; bottom:-2px; right:-2px; width:10px; height:10px; border-radius:50%; background:${isOnline ? '#10b981' : '#64748b'}; border:2px solid #0f172a;" title="${isOnline ? 'ออนไลน์' : 'ออฟไลน์'}"></span>
            </div>
            ${gemColumnHtml}
        </div>
    `;
};

// 1. OPEN GEM INVENTORY MODAL
window.openGemInventory = async function () {
    if (typeof openModal === 'function') {
        openModal('modal-gem-inventory');
    } else {
        const el = document.getElementById('modal-gem-inventory');
        if (el) el.style.display = 'flex';
    }
    await window.loadPlayerGems();
};

// 2. LOAD USER GEMS & SLOTS FROM API
window.loadPlayerGems = async function () {
    const userId = (window.DEFAULT_USER && window.DEFAULT_USER.id && Number(window.DEFAULT_USER.id) > 0) ? Number(window.DEFAULT_USER.id) : null;
    if (!userId) {
        window.playerGemsData = {
            ownedGems: [],
            equippedSlots: [null, null, null],
            slotLimit: 3,
            activeCardGrade: 'SS+'
        };
        window.currentInspectedGem = null;
        if (typeof window.renderGemSlotsUI === 'function') window.renderGemSlotsUI();
        if (typeof window.renderGemInventoryListUI === 'function') window.renderGemInventoryListUI();
        if (typeof window.renderInventoryGemsUI === 'function') window.renderInventoryGemsUI([], 'SS+', 3);
        if (typeof window.renderGemInspectionBox === 'function') window.renderGemInspectionBox();
        return;
    }
    const slotsWrap = document.getElementById('gem-equipped-slots-row');
    const listWrap = document.getElementById('gem-owned-list-container');

    if (slotsWrap) {
        slotsWrap.innerHTML = `<div style="color:#94a3b8; font-size:12px; padding:10px;">⏳ กำลังโหลดช่องอัญมณี...</div>`;
    }
    if (listWrap) {
        listWrap.innerHTML = `<div style="color:#94a3b8; font-size:12px; padding:20px; text-align:center;">⏳ กำลังโหลดคลังอัญมณี...</div>`;
    }

    try {
        const res = await fetch(`api/equipment_service.php?action=get_user_equipment&user_id=${userId}`);
        const json = await res.json();

        if (json.status === 'success') {
            const grade = json.character_grade || 'SS+';
            const limit = json.slot_limit || (grade === 'SS+' ? 3 : (grade === 'S+' ? 2 : (grade === 'S' ? 1 : 0)));

            window.playerGemsData.activeCardGrade = grade;
            window.playerGemsData.slotLimit = limit;

            // Filter all gems (support both json.equipment and json.owned_items)
            const allItems = json.equipment || json.owned_items || [];
            const gems = allItems.filter(eq => eq.shape !== null && eq.shape !== undefined);
            window.playerGemsData.ownedGems = gems;

            // Slot mappings
            window.playerGemsData.equippedSlots = [null, null, null];
            gems.forEach(g => {
                if (g.is_equipped == 1 && g.slot_index >= 1 && g.slot_index <= 3) {
                    window.playerGemsData.equippedSlots[g.slot_index - 1] = g;
                }
            });

            window.renderGemSlotsUI();
            window.renderGemInventoryListUI();
            if (typeof window.renderInventoryGemsUI === 'function') {
                window.renderInventoryGemsUI(window.playerGemsData.ownedGems, window.playerGemsData.activeCardGrade, window.playerGemsData.slotLimit);
            }
            if (typeof window.renderGemInspectionBox === 'function') {
                window.renderGemInspectionBox();
            }
            if (typeof window.renderFrameInspectionBox === 'function' && window.currentInspectedFrame) {
                window.renderFrameInspectionBox(window.currentInspectedFrame);
            }

            // Sync with 3D board orbit & 3D clan house
            const equippedList = window.playerGemsData.equippedSlots.filter(Boolean);
            if (window.DEFAULT_USER) {
                window.DEFAULT_USER.equipped_gems = equippedList;
            }
            const gameInstance = window.game || window.game3D;
            if (gameInstance && typeof gameInstance.updatePlayerGems === 'function') {
                gameInstance.updatePlayerGems(equippedList);
            }
            if (window.clanHouse && typeof window.clanHouse.updatePlayerGems === 'function') {
                window.clanHouse.updatePlayerGems(equippedList);
            }
        }
    } catch (err) {
        console.error('loadPlayerGems error:', err);
    }
};

// Helper: ดึงรายการอัญมณีที่สวมใส่จริงของผู้เล่นหลัก
window.getEquippedGemsList = function () {
    if (window.playerGemsData) {
        if (Array.isArray(window.playerGemsData.equippedSlots)) {
            const list = window.playerGemsData.equippedSlots.filter(Boolean);
            if (list.length > 0) return list;
        } else if (window.playerGemsData.equippedSlots && typeof window.playerGemsData.equippedSlots === 'object') {
            const list = Object.values(window.playerGemsData.equippedSlots).filter(Boolean);
            if (list.length > 0) return list;
        }
        if (Array.isArray(window.playerGemsData.ownedGems)) {
            const list = window.playerGemsData.ownedGems.filter(g => Number(g.is_equipped) === 1);
            if (list.length > 0) return list;
        }
    }
    if (Array.isArray(window.latestGemsList)) {
        const list = window.latestGemsList.filter(g => Number(g.is_equipped) === 1);
        if (list.length > 0) return list;
    }
    if (Array.isArray(window.DEFAULT_USER?.equipped_gems) && window.DEFAULT_USER.equipped_gems.length > 0) {
        return window.DEFAULT_USER.equipped_gems;
    }
    return [];
};

// Helper: Extract canonical skill signatures from a gem object (detects duplicate skills even across different shapes)
window.getGemSkillSignaturesJS = function (gem) {
    if (!gem) return [];
    const sigs = [];
    const skillName = String(gem.skill_name || '').trim();
    const skillDesc = String(gem.skill_description || '').trim();
    const skillCat = String(gem.skill_category || '').trim().toUpperCase();

    if (skillName) {
        const normName = skillName.toLowerCase().replace(/[0-9%.\s()\-\+:!\[\]\/]+/g, '');
        if (normName) sigs.push('name:' + normName);
    }

    let fx = {};
    if (gem.skill_effects_json) {
        try {
            fx = (typeof gem.skill_effects_json === 'string') ? JSON.parse(gem.skill_effects_json) : gem.skill_effects_json;
        } catch (_) { }
    }

    const text = (skillName + ' ' + skillDesc + ' ' + skillCat).toLowerCase();
    if (fx.shield_on_roll || /สร้างโล่|โล่|เกราะ|shield/.test(text)) sigs.push('fx:shield_on_roll');
    if (fx.immune_kick || /ป้องกันการเตะ|กันเตะ|ไม่โดนดึง|ต้านการเตะ/.test(text)) sigs.push('fx:immune_kick');
    if (fx.immune_steal || /ป้องกันการดูดเงิน|กันดูดเงิน|กันขโมย/.test(text)) sigs.push('fx:immune_steal');
    if (fx.immune_snake || /ป้องกันงู|คุ้มกันหัวงู|กันงู/.test(text) || skillCat === 'SHIELD_SNAKE') sigs.push('fx:immune_snake');
    if (fx.pass_kick || /เตะคู่แข่ง|ผลักคู่แข่ง|เตะส่งข้ามมิติ|ผลักไส|ก้าวผ่าน|สะบัดหาง|ดีดตัว/.test(text) || (skillCat === 'PASS_OPPONENT_KICK' && !/ในแถว|ทั้งแถว|ดูดดาว|ดึงดูดคู่แข่ง/.test(text))) sigs.push('fx:pass_kick');
    if (fx.steal_gold || /ขโมยทอง|ดูดเงิน|ปล้นทอง|ดูดทรัพย์/.test(text) || skillCat === 'STEAL_GOLD') sigs.push('fx:steal_gold');
    if (fx.toll_discount || /ส่วนลดค่าผ่านทาง|ลดค่าผ่านทาง|ยกเว้นค่าผ่านทาง/.test(text) || skillCat === 'TOLL_DISCOUNT') sigs.push('fx:toll_discount');
    if (fx.dice_double || /ทอยเบิ้ล|ดับเบิ้ล/.test(text) || skillCat === 'DICE_DOUBLE') sigs.push('fx:dice_double');
    if (fx.pull_opponents_4 || fx.pull_opponents_6 || fx.pull_opponents_line || /ในแถว|ทั้งแถว|ดึงคู่แข่ง|ดูดคู่แข่ง|ดูดดาว|4 ช่อง|6 ช่อง/.test(text)) sigs.push('fx:pull_opponents');
    if (fx.black_hole_generator || /หลุมดำ|black hole/.test(text)) sigs.push('fx:black_hole_generator');
    if (fx.instant_landmark_3city || /3 เมือง|3เมือง|เสกแลนด์มาร์ค/.test(text)) sigs.push('fx:instant_landmark_3city');
    if (fx.toll_multiplier_random || /คูณ 12|คูณ12|x12|ตัวคูณ|คูณ 8|คูณ 2/.test(text)) sigs.push('fx:toll_multiplier_random');
    if (/ยกเมือง|กั้นทาง|ปราการ|กำแพงเมือง/.test(text) || skillCat === 'BLOCK_CITY') sigs.push('fx:block_city');
    if (/จ่ายค่าผ่านทาง 2 เท่า|ค่าผ่านทางทวีคูณ|เก็บค่าผ่านทางสองเท่า/.test(text) || skillCat === 'FORCE_PAY_TOLL') sigs.push('fx:force_pay_toll');

    if (skillCat && skillCat !== 'CUSTOM' && sigs.length <= 1) {
        sigs.push('cat:' + skillCat);
    }

    return Array.from(new Set(sigs));
};

window.areGemSkillsDuplicate = function (gemA, gemB) {
    if (!gemA || !gemB) return false;
    if (gemA.item_id && gemB.item_id && Number(gemA.item_id) === Number(gemB.item_id)) return true;
    const sigsA = window.getGemSkillSignaturesJS(gemA);
    const sigsB = window.getGemSkillSignaturesJS(gemB);
    return sigsA.some(s => sigsB.includes(s));
};

window.validateGemEquipRules = function (targetGem, equippedList = null) {
    if (!targetGem) return { valid: false, message: 'ไม่พบข้อมูลอัญมณี' };
    const shapeLabels = { triangle: 'สามเหลี่ยม (🔺)', square: 'สี่เหลี่ยม (🔷)', pentagon: 'ห้าเหลี่ยม (⬠)' };
    const eqGems = Array.isArray(equippedList)
        ? equippedList.filter(Boolean)
        : ((window.playerGemsData && Array.isArray(window.playerGemsData.equippedSlots))
            ? window.playerGemsData.equippedSlots.filter(Boolean)
            : (Array.isArray(window.latestGemsList) ? window.latestGemsList.filter(x => Number(x.is_equipped) === 1) : []));

    const targetId = Number(targetGem.user_eq_id || targetGem.id || 0);
    const targetShape = String(targetGem.shape || 'triangle').toLowerCase();
    const targetShapeLabel = shapeLabels[targetShape] || targetShape;

    for (const eq of eqGems) {
        const eqId = Number(eq.user_eq_id || eq.id || 0);
        if (eqId === targetId) continue;

        const eqShape = String(eq.shape || '').toLowerCase();
        const eqShapeLabel = shapeLabels[eqShape] || eqShape;
        const eqSlot = eq.slot_index || 1;

        // กฎที่ 1: ห้ามสวมใส่อัญมณีรูปทรงซ้ำกัน (ใส่ได้อย่างละ 1 ชิ้นเท่านั้น)
        if (eqShape && eqShape === targetShape) {
            return {
                valid: false,
                reasonType: 'SHAPE',
                conflictGem: eq,
                badgeText: `⚠️ รูปทรง${shapeLabels[targetShape] ? targetShapeLabel.split(' ')[0] : targetShape}ใส่แล้ว (ช่อง ${eqSlot})`,
                message: `❌ ไม่สามารถสวมใส่ซ้ำรูปทรงได้!\n\nคุณได้สวมใส่อัญมณีรูปทรง${targetShapeLabel} ("${eq.name}") อยู่แล้วในช่องที่ ${eqSlot}\n\n📌 กฎอัญมณี: รูปทรงสามเหลี่ยม, สี่เหลี่ยม, ห้าเหลี่ยม สวมใส่ได้อย่างละ 1 ชิ้นเท่านั้น กรุณาถอดชิ้นเดิมออกก่อนหากต้องการเปลี่ยน`
            };
        }

        // กฎที่ 2: ห้ามสวมใส่อัญมณีที่มีสกิลซ้ำกัน แม้รูปทรงต่างกันก็ตาม
        if (window.areGemSkillsDuplicate(targetGem, eq)) {
            return {
                valid: false,
                reasonType: 'SKILL',
                conflictGem: eq,
                badgeText: `🚫 สกิลซ้ำกับช่องที่ ${eqSlot}`,
                message: `❌ ไม่สามารถสวมใส่สกิลซ้ำกันได้!\n\nอัญมณี "${targetGem.name}" (${targetShapeLabel}) มีสกิล "${targetGem.skill_name || 'สกิลอัญมณี'}" ซ้ำกับ "${eq.name}" (${eqShapeLabel}) ที่สวมใส่อยู่ในช่องที่ ${eqSlot}\n\n📌 กฎอัญมณี: ห้ามสวมใส่อัญมณีที่มีสกิลซ้ำกัน แม้จะมีรูปทรงต่างกันก็ตาม`
            };
        }
    }

    return { valid: true, reasonType: null, conflictGem: null, badgeText: '', message: '' };
};

// Helper: คำนวณ % สกิลตามเลเวลอัญมณี (Lv.1 -> Lv.30)
window.getGemLevelScaledRate = function (baseRate, maxRate, level = 1) {
    const lv = Math.max(1, Math.min(30, parseInt(level, 10) || 1));
    const maxR = Math.max(1, Math.min(100, parseFloat(maxRate) || 90));
    const baseR = (baseRate !== undefined && baseRate !== null && !isNaN(parseFloat(baseRate)))
        ? Math.max(1, Math.min(maxR, parseFloat(baseRate)))
        : Math.max(10, Math.round(maxR * 0.45));
    if (lv >= 30) return Math.round(maxR);
    return Math.round(baseR + ((maxR - baseR) * (lv - 1)) / 29);
};

window.getGemSkillsWithScaledRates = function (gem) {
    if (!gem) return [];
    const lv = Math.max(1, Math.min(30, parseInt(gem.level, 10) || 1));
    const grade = String(gem.grade || 'S').toUpperCase();
    const maxSlots = (grade === 'ZZ+') ? 3 : ((grade === 'ZZ' || grade === 'SS+') ? 2 : 1);
    let parsedFx = {};
    if (gem.skill_effects_json) {
        try {
            parsedFx = typeof gem.skill_effects_json === 'string' ? JSON.parse(gem.skill_effects_json) : gem.skill_effects_json;
        } catch (e) { }
    }
    const rawSkills = (parsedFx && Array.isArray(parsedFx.skills) && parsedFx.skills.length > 0)
        ? parsedFx.skills
        : [{
            category: gem.skill_category || 'CUSTOM',
            name: gem.skill_name || 'สกิลอัญมณี',
            description: gem.skill_description || '',
            base_rate: parsedFx?.base_rate,
            max_rate: parseFloat(gem.trigger_rate_percent || 90)
        }];
    return rawSkills.slice(0, maxSlots).map(sk => {
        const maxR = parseFloat(sk.max_rate ?? gem.trigger_rate_percent ?? 90);
        const curPct = window.getGemLevelScaledRate(sk.base_rate ?? parsedFx?.base_rate, maxR, lv);
        return {
            category: sk.category || 'CUSTOM',
            name: sk.name || gem.skill_name || 'สกิลอัญมณี',
            description: sk.description || gem.skill_description || '',
            current_rate: curPct,
            max_rate: Math.round(maxR)
        };
    });
};

window.getGemUpgradeDiamondCost = function (lv, grade = 'S') {
    if (typeof window.getItemUpgradeDiamondCost === 'function') {
        return window.getItemUpgradeDiamondCost('gem', grade, lv);
    }
    const l = Math.max(1, parseInt(lv, 10) || 1);
    const g = String(grade || 'S').toUpperCase().trim();
    const gr = window.GAME_RULES || {};
    const mRow = gr.upgrade_diamond_matrix?.gem?.[g];
    if (mRow) {
        const tk = l < 10 ? 't1' : (l < 20 ? 't2' : (l < 29 ? 't3' : 't4'));
        if (mRow[tk] !== undefined) return Math.max(0, Number(mRow[tk]));
    }
    const t1 = gr.gem_upgrade_dia_t1 !== undefined ? Math.max(0, Number(gr.gem_upgrade_dia_t1)) : 100;
    const t2 = gr.gem_upgrade_dia_t2 !== undefined ? Math.max(0, Number(gr.gem_upgrade_dia_t2)) : 150;
    const t3 = gr.gem_upgrade_dia_t3 !== undefined ? Math.max(0, Number(gr.gem_upgrade_dia_t3)) : 200;
    const t4 = gr.gem_upgrade_dia_t4 !== undefined ? Math.max(0, Number(gr.gem_upgrade_dia_t4)) : 500;
    return l < 10 ? t1 : (l < 20 ? t2 : (l < 29 ? t3 : t4));
};

window.upgradeGemAction = async function (userEqId, skipConfirm = false, targetLevel = null) {
    const allGems = [
        ...((window.playerGemsData && window.playerGemsData.ownedGems) || []),
        ...(Array.isArray(window.latestGemsList) ? window.latestGemsList : [])
    ];
    const targetGem = allGems.find(g => Number(g.user_eq_id || g.id) === Number(userEqId));
    const lvl = Math.max(1, Math.min(30, parseInt(targetGem?.level, 10) || 1));
    const gemGrade = targetGem?.grade || 'S';
    const gemName = targetGem?.name || 'อัญมณีมหาเวทย์';
    const costDia = window.getGemUpgradeDiamondCost(lvl, gemGrade);

    const reqAwaken = (window.GAME_RULES && window.GAME_RULES.special_awakening_config && window.GAME_RULES.special_awakening_config.req_qty_lv30)
        ? Number(window.GAME_RULES.special_awakening_config.req_qty_lv30)
        : 5;

    if (!skipConfirm) {
        const doUpgrade = () => window.upgradeGemAction(userEqId, true, null);
        const doUpgradeTo29 = () => window.upgradeGemAction(userEqId, true, 29);
        let totalTo29 = 0;
        if (lvl < 29) {
            for (let l = lvl; l < 29; l++) {
                totalTo29 += window.getGemUpgradeDiamondCost(l, gemGrade);
            }
        }
        if (lvl === 29 && typeof window.showAwakeningLv30ConfirmModal === 'function') {
            window.showAwakeningLv30ConfirmModal({
                itemCat: 'gem',
                itemName: gemName,
                itemGrade: gemGrade,
                costDia,
                reqQty: reqAwaken
            }, doUpgrade);
        } else if (typeof window.showPurchaseConfirmModal === 'function') {
            window.showPurchaseConfirmModal({
                headerIcon: '💎',
                headerTitle: 'ยืนยันราคาอัปเกรดอัญมณี',
                icon: '💎',
                badgeText: `อัปเกรด Lv.${lvl} ➔ Lv.${lvl + 1}`,
                title: `อัปเกรด ${gemName}`,
                subtitle: `เพิ่มระดับอัญมณีเป็น Lv.${lvl + 1}/30 เพื่อเพิ่มโอกาสติดสกิล`,
                currency: 'DIAMOND',
                price: costDia,
                confirmLabel: 'ยืนยันอัปเกรด',
                extraBtn: (lvl < 29) ? {
                    label: '⚡ อัปทันทีถึง Lv.29',
                    price: totalTo29,
                    onConfirm: doUpgradeTo29
                } : null
            }, doUpgrade);
        } else if (typeof window.showInGameConfirm === 'function') {
            window.showInGameConfirm(`ยืนยันการใช้ 💎 ${costDia} เพชร เพื่ออัปเกรด "${gemName}" เป็น Lv.${lvl + 1} หรือไม่?`, doUpgrade, '💎 ยืนยันการอัปเกรด', '💎');
        } else {
            doUpgrade();
        }
        return;
    }

    if (window._upgradingGemLock) return;
    window._upgradingGemLock = true;
    try {
        const uid = Number((typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER?.id) || localStorage.getItem('snake_user_id') || 0);
        const bUrl = (window.apiClient && window.apiClient.baseUrl) ? window.apiClient.baseUrl : '';
        const payload = { user_id: uid, user_eq_id: Number(userEqId) };
        if (targetLevel !== null && targetLevel !== undefined) payload.target_level = Number(targetLevel);
        const res = await fetch(`${bUrl}api/equipment_service.php?action=upgrade_gem`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(r => r.json()).catch(() => null);

        if (!res || res.status !== 'success') {
            const msg = res?.message || 'ไม่สามารถอัปเกรดอัญมณีได้';
            if (typeof window.showToast === 'function') window.showToast(msg);
            else alert(msg);
            return;
        }
        if (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER && res.diamond !== undefined) {
            DEFAULT_USER.diamond = Number(res.diamond);
        }
        if (typeof window.updateUserBar === 'function' && typeof DEFAULT_USER !== 'undefined') window.updateUserBar(DEFAULT_USER);
        if (typeof window.updateLobbyCurrencyHUD === 'function') window.updateLobbyCurrencyHUD();
        const gemObj = (window.playerGemsData?.ownedGems || []).find(g => Number(g.user_eq_id) === Number(userEqId));
        if (gemObj) gemObj.level = Number(res.level);
        const eqObj = (window.playerGemsData?.equippedSlots || []).find(g => g && Number(g.user_eq_id) === Number(userEqId));
        if (eqObj) eqObj.level = Number(res.level);
        if (Array.isArray(window.latestGemsList)) {
            const invObj = window.latestGemsList.find(g => Number(g.user_eq_id || g.id) === Number(userEqId));
            if (invObj) invObj.level = Number(res.level);
        }
        if (window.currentInspectedGem && Number(window.currentInspectedGem.user_eq_id || window.currentInspectedGem.id) === Number(userEqId)) {
            window.currentInspectedGem.level = Number(res.level);
        }
        if (window.soundEngine && typeof window.soundEngine.playCoins === 'function') window.soundEngine.playCoins();
        if (lvl === 29 && typeof window.playAwakeningLv30Ceremony === 'function') {
            window.playAwakeningLv30Ceremony({ itemCat: 'gem', itemName: gemName, itemGrade: gemGrade, costDia, reqQty: reqAwaken });
        } else if (typeof window.showToast === 'function') {
            window.showToast(res.message);
        }
        if (typeof window.renderGemSlotsUI === 'function') window.renderGemSlotsUI();
        if (typeof window.renderGemInventoryListUI === 'function') window.renderGemInventoryListUI();
        if (typeof window.renderInventoryGemsUI === 'function') {
            window.renderInventoryGemsUI(window.latestGemsList || window.playerGemsData?.ownedGems);
        }
    } finally {
        window._upgradingGemLock = false;
    }
};

// 3. RENDER GEM SLOTS (S=1, S+=2, SS+=3)
window.renderGemSlotsUI = function () {
    const slotsWrap = document.getElementById('gem-equipped-slots-row');
    const gradeBadge = document.getElementById('gem-active-card-grade-badge');
    if (!slotsWrap) return;

    const { slotLimit, activeCardGrade, equippedSlots } = window.playerGemsData;

    if (gradeBadge) {
        gradeBadge.innerText = `การ์ดปัจจุบัน [${activeCardGrade}] สวมใส่ได้ ${slotLimit} ช่อง (รูปทรงละ 1 ชิ้น • ห้ามสกิลซ้ำ)`;
        gradeBadge.style.color = (activeCardGrade === 'SS+') ? '#c084fc' : (activeCardGrade === 'S+' ? '#00e5ff' : '#ffd700');
    }

    const shapeLabels = { triangle: 'สามเหลี่ยม', square: 'สี่เหลี่ยม', pentagon: 'ห้าเหลี่ยม' };

    let html = '';
    for (let i = 1; i <= 3; i++) {
        const isUnlocked = (i <= slotLimit);
        const equippedGem = equippedSlots[i - 1];

        if (!isUnlocked) {
            // Locked slot
            html += `
                <div style="flex:1; min-width:90px; background:rgba(0,0,0,0.5); border:1.5px dashed rgba(255,255,255,0.15); border-radius:12px; padding:10px 8px; text-align:center; opacity:0.55;">
                    <div style="font-size:22px; margin-bottom:2px;">🔒</div>
                    <div style="font-size:10px; color:#94a3b8; font-weight:700;">ช่องที่ ${i} (ล็อค)</div>
                    <div style="font-size:9.5px; color:#64748b; margin-top:2px;">ต้องการการ์ด ${i === 2 ? 'S+' : 'SS+'}</div>
                </div>
            `;
        } else if (equippedGem) {
            const gColor = equippedGem.gem_color || '#a78bfa';
            const svgIcon = (typeof window.generateGemSvgPreview === 'function')
                ? window.generateGemSvgPreview(equippedGem.shape || 'pentagon', equippedGem.grade || 'SS+', 34, gColor, equippedGem.aura_type || 'pulse', equippedGem.particle_fx || 'spark', 'high')
                : '💎';
            const sName = shapeLabels[String(equippedGem.shape || '').toLowerCase()] || 'อัญมณี';
            const eqLv = Math.max(1, Math.min(30, parseInt(equippedGem.level, 10) || 1));
            const eqSkills = window.getGemSkillsWithScaledRates(equippedGem);
            const eqSkillLine = eqSkills.map(s => `${s.name} (${s.current_rate}%)`).join(' • ');
            html += `
                <div style="flex:1; min-width:90px; background:linear-gradient(135deg, rgba(139,92,246,0.25), rgba(59,130,246,0.15)); border:1.5px solid ${gColor}; border-radius:12px; padding:10px 8px; text-align:center; box-shadow:0 0 14px ${gColor}44; position:relative;">
                    <span style="position:absolute; top:5px; right:6px; font-size:9px; font-weight:900; background:rgba(15,23,42,0.85); color:#38bdf8; border:1px solid #38bdf8; border-radius:6px; padding:1px 5px;">Lv.${eqLv}/30</span>
                    <div style="width:36px; height:36px; margin:0 auto; display:flex; align-items:center; justify-content:center; filter:drop-shadow(0 0 8px ${gColor});">${svgIcon}</div>
                    <div style="font-size:9.5px; color:#c4b5fd; font-weight:800; margin-top:2px;">[${equippedGem.grade || 'S'}] รูปทรง${sName}</div>
                    <div style="font-size:11px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:1px;">${equippedGem.name}</div>
                    <div style="font-size:9.5px; color:#facc15; font-weight:700; line-height:1.25; margin-top:2px;" title="${eqSkillLine}">${eqSkills.map((s, si) => `<div>${eqSkills.length > 1 ? `${si + 1}. ` : ''}${s.name} (${s.current_rate}%)</div>`).join('')}</div>
                    <button type="button" onclick="unequipGemAction(${equippedGem.user_eq_id})" style="margin-top:6px; font-size:10px; background:rgba(239,68,68,0.2); border:1px solid #ef4444; color:#ef4444; border-radius:6px; padding:2px 8px; cursor:pointer;">
                        ถอดออก
                    </button>
                </div>
            `;
        } else {
            // Unlocked empty slot
            html += `
                <div style="flex:1; min-width:90px; background:rgba(139,92,246,0.06); border:1.5px dashed #8b5cf6; border-radius:12px; padding:10px 8px; text-align:center;">
                    <div style="font-size:24px; color:#8b5cf6;">➕</div>
                    <div style="font-size:11px; color:#c4b5fd; font-weight:700;">ช่องที่ ${i} (ว่าง)</div>
                    <div style="font-size:9.5px; color:#94a3b8; margin-top:2px;">รูปทรง/สกิลไม่ซ้ำ</div>
                </div>
            `;
        }
    }
    slotsWrap.innerHTML = html;
};

// 4. RENDER OWNED GEMS INVENTORY
window.renderGemInventoryListUI = function () {
    const listWrap = document.getElementById('gem-owned-list-container');
    if (!listWrap) return;

    const gems = window.playerGemsData.ownedGems || [];
    if (gems.length === 0) {
        listWrap.innerHTML = `
            <div style="text-align:center; padding:30px 10px; color:#94a3b8; width:100%;">
                <div style="font-size:36px; margin-bottom:8px;">💎</div>
                <div style="font-size:13px; font-weight:700; color:#cbd5e1;">คุณยังไม่มีอัญมณีในคลัง</div>
                <div style="font-size:11.5px; margin-top:4px;">เปิดสุ่มหากิจกรรมอัญมณี หรือคราฟต์จากไอเทมเงาได้ทันที!</div>
                <button type="button" class="btn btn-warning" onclick="openGemGachaEventModal()" style="margin-top:14px; background:linear-gradient(135deg, #f59e0b, #d97706); color:#000; font-weight:800; font-size:12px; padding:6px 16px; border-radius:8px; border:none; cursor:pointer;">
                    ✨ ไปสุ่มอัญมณีผ่านเงา
                </button>
            </div>
        `;
        return;
    }

    const shapeIcons = { triangle: '🔺 สามเหลี่ยม', square: '🔷 สี่เหลี่ยม', pentagon: '⬠ ห้าเหลี่ยม' };

    listWrap.innerHTML = gems.map(g => {
        const isEquipped = (g.is_equipped == 1);
        const icon = shapeIcons[g.shape] || (g.shape || '💎');
        const gColor = g.gem_color || '#a855f7';
        const svgIcon = (typeof window.generateGemSvgPreview === 'function')
            ? window.generateGemSvgPreview(g.shape || 'pentagon', g.grade || 'S', 36, gColor, g.aura_type || 'pulse', g.particle_fx || 'spark', 'high')
            : icon.split(' ')[0];
        const ruleCheck = !isEquipped ? window.validateGemEquipRules(g) : { valid: true };
        const gemLv = Math.max(1, Math.min(30, parseInt(g.level, 10) || 1));
        const upgCost = window.getGemUpgradeDiamondCost(gemLv, g.grade || 'S');
        const scaledSkills = window.getGemSkillsWithScaledRates(g);
        const skillsHtml = scaledSkills.map((sk, idx) => `
            <div style="font-size:11px; color:#fbbf24; font-weight:700; margin-top:2px;">
                ${scaledSkills.length > 1 ? `สกิล ${idx + 1}: ` : ''}${sk.name} <span style="color:#38bdf8;">(${sk.current_rate}% • Lv.${gemLv})</span>
            </div>
            ${sk.description ? `<div style="font-size:10px; color:#94a3b8; line-height:1.25;">${sk.description}</div>` : ''}
        `).join('');

        return `
            <div style="background:rgba(15,23,42,0.8); border:1px solid ${isEquipped ? '#8b5cf6' : (ruleCheck.valid ? 'rgba(255,255,255,0.1)' : 'rgba(239,68,68,0.35)')}; border-radius:10px; padding:10px 12px; display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:8px;">
                <div style="display:flex; align-items:center; gap:10px; min-width:0; flex:1;">
                    <div style="width:40px; height:40px; display:flex; align-items:center; justify-content:center; flex-shrink:0; filter:drop-shadow(0 0 6px ${gColor});">${svgIcon}</div>
                    <div style="min-width:0; flex:1;">
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                            <strong style="color:#fff; font-size:13px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${g.name}</strong>
                            <span style="font-size:10px; background:rgba(139,92,246,0.25); color:#c4b5fd; padding:1px 6px; border-radius:4px; font-weight:700;">${g.grade || 'S'}</span>
                            <span style="font-size:10px; background:rgba(56,189,248,0.18); color:#38bdf8; border:1px solid rgba(56,189,248,0.45); padding:1px 6px; border-radius:4px; font-weight:800;">Lv.${gemLv}/30</span>
                            <span style="font-size:10px; color:#a78bfa; font-weight:700;">${icon}</span>
                            ${!isEquipped && !ruleCheck.valid ? `<span style="font-size:9.5px; background:rgba(239,68,68,0.18); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; padding:1px 6px; border-radius:6px; font-weight:800;">${ruleCheck.badgeText}</span>` : ''}
                        </div>
                        ${skillsHtml}
                    </div>
                </div>
                <div style="flex-shrink:0; display:flex; flex-direction:column; gap:5px; align-items:flex-end;">
                    ${gemLv < 30
                ? `<button type="button" onclick="upgradeGemAction(${g.user_eq_id})" style="padding:4px 10px; font-size:10.5px; background:linear-gradient(135deg,#f59e0b,#d97706); border:none; color:#000; border-radius:6px; cursor:pointer; font-weight:900;">⬆️ อัปเกรด (💎 ${upgCost.toLocaleString()})</button>`
                : `<span style="font-size:10px; background:rgba(250,204,21,0.18); color:#fde047; border:1px solid #facc15; border-radius:6px; padding:2px 8px; font-weight:800;">MAX Lv.30</span>`
            }
                    ${isEquipped
                ? `<button type="button" onclick="unequipGemAction(${g.user_eq_id})" style="padding:5px 12px; font-size:11px; background:rgba(239,68,68,0.2); border:1px solid #ef4444; color:#ef4444; border-radius:6px; cursor:pointer; font-weight:700;">ถอดออก</button>`
                : `<button type="button" onclick="equipGemToFirstEmptySlot(${g.user_eq_id})" style="padding:5px 14px; font-size:11px; background:${ruleCheck.valid ? 'linear-gradient(135deg,#8b5cf6,#6d28d9)' : 'rgba(100,116,139,0.35)'}; border:${ruleCheck.valid ? 'none' : '1px solid rgba(239,68,68,0.5)'}; color:${ruleCheck.valid ? '#fff' : '#fca5a5'}; border-radius:6px; cursor:pointer; font-weight:700;">${ruleCheck.valid ? 'สวมใส่ ➔' : '🚫 ใส่ซ้ำไม่ได้'}</button>`
            }
                </div>
            </div>
        `;
    }).join('');
};

// 5. EQUIP GEM ACTION (Enforces 1 gem per shape + no duplicate skill)
window.equipGemToFirstEmptySlot = async function (userEqId) {
    const { slotLimit, equippedSlots } = window.playerGemsData;
    const allGems = (window.playerGemsData && Array.isArray(window.playerGemsData.ownedGems) && window.playerGemsData.ownedGems.length > 0)
        ? window.playerGemsData.ownedGems
        : (Array.isArray(window.latestGemsList) ? window.latestGemsList : []);
    const targetGem = allGems.find(g => Number(g.user_eq_id || g.id) === Number(userEqId));

    if (targetGem) {
        const ruleCheck = window.validateGemEquipRules(targetGem, equippedSlots);
        if (!ruleCheck.valid) {
            if (typeof window.showInGameAlert === 'function') {
                window.showInGameAlert(ruleCheck.message, 'ไม่สามารถสวมใส่อัญมณีซ้ำได้', '⚠️');
            } else if (typeof window.showToast === 'function') {
                window.showToast(ruleCheck.message);
            } else {
                alert(ruleCheck.message);
            }
            return;
        }
    }

    let targetSlot = -1;
    for (let i = 0; i < slotLimit; i++) {
        if (!equippedSlots[i]) {
            targetSlot = i + 1;
            break;
        }
    }
    if (targetSlot === -1) {
        const fullMsg = `❌ ช่องสวมใส่อัญมณีเต็มแล้ว (${slotLimit}/${slotLimit} ช่อง)\nกรุณาถอดอัญมณีในช่องเดิมออกก่อนสวมใส่ชิ้นใหม่`;
        if (typeof window.showInGameAlert === 'function') {
            window.showInGameAlert(fullMsg, 'ช่องสวมใส่อัญมณีเต็ม', '⚠️');
        } else {
            alert(fullMsg);
        }
        return;
    }

    const userId = (window.DEFAULT_USER && window.DEFAULT_USER.id && Number(window.DEFAULT_USER.id) > 0) ? Number(window.DEFAULT_USER.id) : null;
    if (!userId) {
        if (typeof showToast === 'function') showToast('กรุณาเข้าสู่ระบบก่อนดำเนินการ');
        return;
    }
    try {
        const res = await fetch('api/equipment_service.php?action=equip_gem', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: userId,
                user_eq_id: userEqId,
                slot_index: targetSlot
            })
        });
        const json = await res.json();
        if (json.status === 'success') {
            if (typeof showToast === 'function') showToast(json.message || 'สวมใส่อัญมณีเรียบร้อย');
            await window.loadPlayerGems();
            if (typeof window.loadInventoryData === 'function') {
                window.loadInventoryData();
            }
        } else {
            if (typeof window.showInGameAlert === 'function') {
                window.showInGameAlert(json.message || 'ไม่สามารถสวมใส่ได้', 'ไม่สามารถสวมใส่อัญมณีได้', '⚠️');
            } else {
                alert(json.message || 'ไม่สามารถสวมใส่ได้');
            }
        }
    } catch (err) {
        console.error('equipGem error:', err);
    }
};

// 6. UNEQUIP GEM ACTION
window.unequipGemAction = async function (userEqId) {
    const userId = (window.DEFAULT_USER && window.DEFAULT_USER.id && Number(window.DEFAULT_USER.id) > 0) ? Number(window.DEFAULT_USER.id) : null;
    if (!userId) {
        if (typeof showToast === 'function') showToast('กรุณาเข้าสู่ระบบก่อนดำเนินการ');
        return;
    }
    try {
        const res = await fetch('api/equipment_service.php?action=unequip_gem', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: userId,
                user_eq_id: userEqId
            })
        });
        const json = await res.json();
        if (json.status === 'success') {
            if (typeof showToast === 'function') showToast('ถอดอัญมณีเรียบร้อยแล้ว');
            await window.loadPlayerGems();
            if (typeof window.loadInventoryData === 'function') {
                window.loadInventoryData();
            }
        }
    } catch (err) {
        console.error('unequipGem error:', err);
    }
};

// Helper: Get user's current diamonds accurately from DEFAULT_USER or header DOM
window.getPlayerDiamondAmount = function () {
    let dia = 0;
    if (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) {
        dia = Number(DEFAULT_USER.diamond ?? DEFAULT_USER.diamonds ?? 0);
    }
    if (!dia) {
        const barEl = document.getElementById('bar-diamond');
        if (barEl) {
            const txt = (barEl.innerText || barEl.textContent || '');
            const parsed = parseInt(txt.replace(/[^0-9]/g, ''), 10);
            if (!isNaN(parsed) && parsed > 0) dia = parsed;
        }
    }
    return dia;
};

// Helper: Get user's current gold accurately from DEFAULT_USER or header DOM
window.getPlayerGoldAmount = function () {
    let gold = 0;
    if (typeof DEFAULT_USER !== 'undefined' && DEFAULT_USER) {
        gold = Number(DEFAULT_USER.gold ?? DEFAULT_USER.money ?? 0);
    }
    if (!gold) {
        const barEl = document.getElementById('bar-gold');
        if (barEl) {
            const txt = (barEl.innerText || barEl.textContent || '');
            const parsed = parseInt(txt.replace(/[^0-9]/g, ''), 10);
            if (!isNaN(parsed) && parsed > 0) gold = parsed;
        }
    }
    return gold;
};

// Helper: Sync wallet pills in gem gacha event modal immediately
window.syncGemEventWalletDisplay = function () {
    const dia = window.getPlayerDiamondAmount();
    const gold = window.getPlayerGoldAmount();
    const diaEl = document.getElementById('gem-event-user-dia');
    const goldEl = document.getElementById('gem-event-user-gold');
    if (diaEl) diaEl.innerText = dia.toLocaleString();
    if (goldEl) goldEl.innerText = gold.toLocaleString();
};

// 7. GEM GACHA MODAL CONTROLLER (Full Separated Event Page — like Frame/Dice)
window.openGemGachaEventModal = async function () {
    closeModal('modal-event-frame');
    closeModal('modal-event-dice');
    if (typeof openModal === 'function') {
        openModal('modal-gem-gacha');
    } else {
        const el = document.getElementById('modal-gem-gacha');
        if (el) el.style.display = 'flex';
    }

    // ⚡ Update diamonds & gold immediately so they NEVER show 0!
    window.syncGemEventWalletDisplay();

    // ⚡ Show instant loader in body so it's never a dark blank void!
    const body = document.getElementById('gem-event-body');
    if (body && !body.innerHTML.trim()) {
        body.innerHTML = `
            <div style="grid-column: 1 / -1; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:360px; color:#c4b5fd; text-align:center;">
                <div style="font-size:42px; margin-bottom:12px; filter:drop-shadow(0 0 16px #a78bfa);">💎</div>
                <div style="font-size:15px; font-weight:800; color:#fff;">กำลังตรวจสอบข้อมูลกิจกรรมอัญมณี...</div>
                <div style="font-size:11.5px; color:#94a3b8; margin-top:4px;">โปรดรอสักครู่</div>
            </div>
        `;
    }

    await window.loadGemGachaEventUI();
};

function formatGemDateTimeThai(str) {
    if (!str) return '';
    const d = window.parseThaiDate(str);
    if (!d) return str;
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Bangkok',
        month: 'numeric',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        hour12: false
    }).formatToParts(d);
    let day = '', m = 1, hour = '', min = '';
    for (const p of parts) {
        if (p.type === 'day') day = p.value;
        if (p.type === 'month') m = parseInt(p.value, 10);
        if (p.type === 'hour') hour = p.value.padStart(2, '0');
        if (p.type === 'minute') min = p.value.padStart(2, '0');
    }
    return `${day} ${months[m - 1] || ''} ${hour}:${min} น.`;
}

window.loadGemGachaEventUI = async function () {
    // 1. Immediately update wallet pills
    window.syncGemEventWalletDisplay();

    try {
        const res = await fetch('api/equipment_service.php?action=get_gem_gacha_event&_t=' + Date.now());
        const json = await res.json();
        const ev = (json && json.status === 'success' && json.event) ? json.event : null;
        const targetItem = json ? json.target_item : null;

        // Determine live status: check both API status and client timestamps
        let isLive = Boolean(json && json.is_live);
        let isExpired = Boolean(json && json.is_expired);
        let isUpcoming = Boolean(json && json.is_upcoming);
        let statusState = json ? (json.status_state || 'NO_EVENT') : 'NO_EVENT';

        // Strict client-side date validation as safety check
        if (!ev || ev.is_active == 0) {
            isLive = false;
            isExpired = true;
            statusState = (!ev) ? 'NO_EVENT' : 'INACTIVE';
        } else {
            const now = Date.now();
            if (ev.end_date) {
                const endD = window.parseThaiDate(ev.end_date);
                if (endD && now > endD.getTime()) {
                    isLive = false;
                    isExpired = true;
                    statusState = 'EXPIRED';
                }
            }
            if (ev.start_date) {
                const startD = window.parseThaiDate(ev.start_date);
                if (startD && now < startD.getTime()) {
                    isLive = false;
                    isUpcoming = true;
                    statusState = 'UPCOMING';
                }
            }
        }

        window._gemGachaEventData = {
            event: ev,
            target_item: targetItem,
            isLive: isLive,
            statusState: statusState,
            user_shadows: json.user_shadows || {}
        };
        window.activeGemGachaCost = (ev && ev.cost_diamond) ? ev.cost_diamond : 100;

        // Update header title
        const bannerEl = document.getElementById('gem-gacha-event-banner-title');
        if (bannerEl) {
            bannerEl.innerText = (ev && ev.event_name) ? ev.event_name : 'กิจกรรมสุ่มอัญมณีมหาเวทย์';
        }

        // Update topbar ribbon pill
        const ribbonEl = document.getElementById('gem-event-ribbon-tag');
        if (ribbonEl) {
            if (!isLive) {
                if (isUpcoming) {
                    ribbonEl.innerText = 'SOON';
                    ribbonEl.style.background = 'linear-gradient(135deg, #0284c7, #0ea5e9)';
                    ribbonEl.style.boxShadow = '0 0 12px rgba(56, 189, 248, 0.45)';
                } else if (isExpired) {
                    ribbonEl.innerText = 'EXPIRED';
                    ribbonEl.style.background = 'linear-gradient(135deg, #dc2626, #ef4444)';
                    ribbonEl.style.boxShadow = '0 0 10px rgba(239, 68, 68, 0.4)';
                } else {
                    ribbonEl.innerText = 'CLOSED';
                    ribbonEl.style.background = '#64748b';
                    ribbonEl.style.boxShadow = 'none';
                }
            } else {
                ribbonEl.innerText = 'EVENT';
                ribbonEl.style.background = 'linear-gradient(135deg, #7c3aed, #a855f7)';
                ribbonEl.style.boxShadow = '0 0 12px rgba(168, 85, 247, 0.45)';
            }
        }

        // Update timer / countdown badge
        const countdownEl = document.getElementById('gem-event-countdown');
        const timerWrap = document.getElementById('gem-event-timer-wrap');
        if (countdownEl) {
            if (!isLive) {
                if (statusState === 'EXPIRED') {
                    countdownEl.innerHTML = '<span style="color:#ef4444; font-weight:800;">สิ้นสุดกิจกรรมแล้ว</span>';
                    if (timerWrap) {
                        timerWrap.style.borderColor = 'rgba(239,68,68,0.5)';
                        timerWrap.style.background = 'rgba(239,68,68,0.12)';
                    }
                } else if (statusState === 'UPCOMING') {
                    const sStr = ev && ev.start_date ? formatGemDateTimeThai(ev.start_date) : '';
                    countdownEl.innerHTML = `<span style="color:#38bdf8; font-weight:800;">เริ่ม ${sStr}</span>`;
                    if (timerWrap) {
                        timerWrap.style.borderColor = 'rgba(56,189,248,0.5)';
                        timerWrap.style.background = 'rgba(56,189,248,0.12)';
                    }
                } else {
                    countdownEl.innerHTML = '<span style="color:#94a3b8; font-weight:700;">ยังไม่มีกิจกรรม</span>';
                    if (timerWrap) {
                        timerWrap.style.borderColor = 'rgba(148,163,184,0.35)';
                        timerWrap.style.background = 'rgba(148,163,184,0.12)';
                    }
                }
            } else {
                if (ev && (ev.start_date || ev.end_date)) {
                    const sStr = formatGemDateTimeThai(ev.start_date);
                    const eStr = formatGemDateTimeThai(ev.end_date);
                    countdownEl.innerText = (sStr && eStr) ? `${sStr} – ${eStr}` : (sStr ? `เริ่ม ${sStr}` : `สิ้นสุด ${eStr}`);
                } else {
                    countdownEl.innerText = 'กำลังจัดกิจกรรม...';
                }
                if (timerWrap) {
                    timerWrap.style.borderColor = 'rgba(255,215,0,0.35)';
                    timerWrap.style.background = 'rgba(0,0,0,0.55)';
                }
            }
        }

        // Update wallet display again
        window.syncGemEventWalletDisplay();

        // Update sidebar subtitle
        const gemSub = document.getElementById('card-event-gem-sub');
        // ซ่อนป้าย EVENT บนการ์ดเมนูเมื่ออีเวนต์หมดเวลา/ยังไม่เปิด
        const gemBadge = document.querySelector('.card-event-gem .card-badge');
        if (gemBadge) gemBadge.style.display = isLive ? '' : 'none';
        if (gemSub) {
            if (!isLive) {
                gemSub.innerText = isExpired ? '[หมดเวลา]' : (isUpcoming ? '[เร็วๆ นี้]' : '[ปิดกิจกรรม]');
            } else if (targetItem && targetItem.name) {
                gemSub.innerText = `[${targetItem.grade || 'SS+'}] ${targetItem.name.substring(0, 10)}`;
            }
        }

        // Render appropriate UI (Active Pack Grid vs Closed Notice Screen)
        if (isLive) {
            window.renderGemEventSeparatedUI(ev, targetItem);
        } else {
            window.renderGemEventClosedNoticeUI(ev, targetItem, statusState, json ? json.status_message : '');
        }
    } catch (err) {
        console.warn('loadGemGachaEventUI error:', err);
        window.syncGemEventWalletDisplay();
        const countdownEl = document.getElementById('gem-event-countdown');
        if (countdownEl) {
            countdownEl.innerHTML = '<span style="color:#ef4444; font-weight:800;">🛑 สิ้นสุดกิจกรรมแล้ว</span>';
        }
        window._gemGachaEventData = { isLive: false, statusState: 'NO_EVENT' };
        window.renderGemEventClosedNoticeUI(null, null, 'NO_EVENT', 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์กิจกรรมได้');
    }
};

// 7.1 RENDER NOTICE SCREEN WHEN EVENT HAS EXPIRED OR NO ACTIVE EVENT
window.renderGemEventClosedNoticeUI = function (ev, targetItem, state, statusMsg) {
    const body = document.getElementById('gem-event-body');
    if (!body) return;

    if (window._gemNoticeInterval) {
        clearInterval(window._gemNoticeInterval);
        window._gemNoticeInterval = null;
    }

    let badgeText = '🛑 สิ้นสุดกิจกรรมแล้ว (หมดเวลา)';
    let badgeBg = 'linear-gradient(135deg, #ef4444, #991b1b)';
    let titleText = 'กิจกรรมสุ่มอัญมณีสิ้นสุดลงแล้ว';
    let timeDetailHtml = '';
    let descText = 'กิจกรรมนี้ได้หมดเวลาลงแล้ว ขออภัยในความไม่สะดวก ขอให้ผู้เล่นติดตามอีเวนต์รอบใหม่เร็วๆ นี้ หรือเข้าร่วมอีเวนต์อื่นๆ ด้านล่าง!';
    let countdownHtml = '';
    let icon = '⏳';
    let borderColor = 'rgba(239, 68, 68, 0.45)';
    let auraColor = 'rgba(239, 68, 68, 0.2)';

    const eStr = ev && ev.end_date ? formatGemDateTimeThai(ev.end_date) : '';
    const sStr = ev && ev.start_date ? formatGemDateTimeThai(ev.start_date) : '';

    if (state === 'EXPIRED') {
        badgeText = '🛑 สิ้นสุดกิจกรรมแล้ว (หมดเวลา)';
        titleText = ev && ev.event_name ? ev.event_name : 'กิจกรรมสุ่มอัญมณีสิ้นสุดลงแล้ว';
        timeDetailHtml = eStr
            ? `<div style="font-size:11px; color:#f1f5f9; font-weight:700; margin-bottom:4px;">กิจกรรมนี้ได้สิ้นสุดระยะเวลาลงแล้ว เมื่อวันที่ <span style="display:inline-block; margin:0 3px; padding:1px 8px; background:rgba(239,68,68,0.18); border:1px solid rgba(239,68,68,0.45); border-radius:6px; color:#fca5a5; font-weight:900; font-size:10.5px;">${eStr}</span></div>`
            : '';
        descText = 'ขอขอบคุณผู้เล่นทุกท่านที่เข้าร่วมสนุก โปรดติดตามกิจกรรมสุ่มอัญมณีและของรางวัลสุดพรีเมียมรอบถัดไปเร็วๆ นี้!';
    } else if (state === 'UPCOMING') {
        badgeText = '⏳ เร็วๆ นี้ • เตรียมตัวให้พร้อม';
        badgeBg = 'linear-gradient(135deg, #0284c7, #0ea5e9)';
        icon = '⏰';
        borderColor = 'rgba(56, 189, 248, 0.45)';
        auraColor = 'rgba(56, 189, 248, 0.22)';
        titleText = ev && ev.event_name ? ev.event_name : 'กิจกรรมสุ่มอัญมณีเร็วๆ นี้';
        timeDetailHtml = sStr
            ? `<div style="font-size:11px; color:#f1f5f9; font-weight:700; margin-bottom:4px;">กิจกรรมสุดพิเศษจะเริ่มเปิดให้ร่วมสนุกในวันที่ <span style="display:inline-block; margin:0 3px; padding:1px 8px; background:rgba(56,189,248,0.18); border:1px solid rgba(56,189,248,0.45); border-radius:6px; color:#38bdf8; font-weight:900; font-size:10.5px;">${sStr}</span></div>`
            : '<div style="font-size:11px; color:#f1f5f9; font-weight:700; margin-bottom:4px;">กิจกรรมจะเปิดให้ร่วมสนุกเร็วๆ นี้</div>';
        descText = '💎 เตรียมเพชรและทองของคุณให้พร้อม! แล้วมาร่วมสัมผัสความยิ่งใหญ่ ลุ้นรับอัญมณีระดับเทพพร้อมสะสมเงาลึกลับไปด้วยกัน';

        if (ev && ev.start_date) {
            const startD = window.parseThaiDate(ev.start_date);
            let diffSec = startD ? Math.floor((startD.getTime() - Date.now()) / 1000) : 0;
            if (diffSec > 0) {
                const formatRem = (sec) => {
                    const d = Math.floor(sec / 86400);
                    const h = Math.floor((sec % 86400) / 3600);
                    const m = Math.floor((sec % 3600) / 60);
                    const s = sec % 60;
                    return (d > 0 ? d + ' วัน ' : '') + `${h} ชม. ${m} นาที ${s} วิ`;
                };
                countdownHtml = `
                    <div id="gem-notice-countdown-pill" style="display:inline-flex; align-items:center; gap:6px; background:rgba(15,23,42,0.85); border:1px solid rgba(56,189,248,0.4); padding:3px 12px; border-radius:16px; font-size:10.5px; color:#bae6fd; font-weight:700; box-shadow:0 0 12px rgba(56,189,248,0.25); margin-bottom:6px;">
                        <span style="display:inline-block; width:6px; height:6px; border-radius:50%; background:#38bdf8; box-shadow:0 0 6px #38bdf8;"></span>
                        <span>นับถอยหลัง:</span>
                        <strong id="gem-notice-countdown-val" style="color:#38bdf8; font-weight:900;">${formatRem(diffSec)}</strong>
                    </div>
                `;
                window._gemNoticeInterval = setInterval(() => {
                    diffSec = Math.max(0, diffSec - 1);
                    const valEl = document.getElementById('gem-notice-countdown-val');
                    if (valEl) valEl.innerText = formatRem(diffSec);
                    if (diffSec <= 0) {
                        clearInterval(window._gemNoticeInterval);
                        window._gemNoticeInterval = null;
                        if (typeof window.loadGemGachaEventUI === 'function') {
                            window.loadGemGachaEventUI();
                        }
                    }
                }, 1000);
            }
        }
    } else {
        badgeText = '🔒 ยังไม่มีกิจกรรมเปิดใช้งาน';
        badgeBg = 'linear-gradient(135deg, #64748b, #334155)';
        icon = '💎';
        borderColor = 'rgba(148, 163, 184, 0.35)';
        auraColor = 'rgba(148, 163, 184, 0.15)';
        titleText = 'ขณะนี้ยังไม่มีกิจกรรมสุ่มอัญมณี';
        timeDetailHtml = '<div style="font-size:11px; color:#f1f5f9; font-weight:700; margin-bottom:4px;">ขณะนี้ยังไม่มีกิจกรรมสุ่มอัญมณีเปิดให้บริการ</div>';
        descText = 'ทีมงานกำลังเตรียมกิจกรรมสุ่มอัญมณีมหาเวทย์รอบใหม่สุดอลังการ!<br>คุณยังสามารถตรวจสอบและสวมใส่อัญมณีในคลัง หรือเข้าร่วมอีเวนต์กรอบรูปและลูกเต๋า 3D ได้ทันที';
    }

    const gemShape = targetItem && targetItem.shape ? targetItem.shape : 'triangle';
    const shapeIcons = { triangle: '🔺', square: '🔷', pentagon: '⬠' };
    const shapeIcon = shapeIcons[gemShape] || '💎';

    let itemStatusHtml = '';
    if (state === 'UPCOMING') {
        itemStatusHtml = '<span style="color:#38bdf8; font-weight:700;">✨ เตรียมเปิดให้สุ่มเมื่อเริ่มกิจกรรม</span>';
    } else if (state === 'EXPIRED') {
        itemStatusHtml = '<span style="color:#f87171; font-weight:700;">🛑 ปิดรับการสุ่มแล้ว (สิ้นสุดกิจกรรม)</span>';
    } else {
        itemStatusHtml = '<span style="color:#94a3b8; font-weight:700;">🔒 ขณะนี้ยังไม่เปิดรับการสุ่ม</span>';
    }

    const titleGrad = state === 'UPCOMING'
        ? 'linear-gradient(135deg, #ffffff 40%, #7dd3fc 100%)'
        : (state === 'EXPIRED'
            ? 'linear-gradient(135deg, #ffffff 40%, #fca5a5 100%)'
            : 'linear-gradient(135deg, #ffffff 40%, #cbd5e1 100%)');

    body.innerHTML = `
        <div class="event-closed-notice-panel" style="grid-column: 1 / -1; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:unset; height:100%; max-height:100%; padding:8px 14px; text-align:center; background:radial-gradient(circle at 50% 35%, ${auraColor}, rgba(15,23,42,0.96)); border:1.5px solid ${borderColor}; border-radius:14px; box-shadow:0 0 25px ${auraColor}; position:relative; overflow-y:auto; box-sizing:border-box;">
            <!-- Ambient Glow -->
            <div style="position:absolute; width:220px; height:220px; border-radius:50%; background:radial-gradient(circle, ${auraColor}, transparent 70%); pointer-events:none;"></div>

            <!-- Big Glowing Icon -->
            <div style="width:40px; height:40px; min-width:40px; min-height:40px; border-radius:50%; background:radial-gradient(circle, rgba(255,255,255,0.08), rgba(0,0,0,0.6)); border:2px solid ${borderColor}; display:flex; align-items:center; justify-content:center; font-size:22px; box-shadow:0 0 16px ${auraColor}; margin-bottom:5px;">
                ${icon}
            </div>

            <!-- Status Pill Badge -->
            <div style="display:inline-flex; align-items:center; gap:5px; background:${badgeBg}; color:#fff; font-size:9.5px; font-weight:900; padding:2px 12px; border-radius:999px; letter-spacing:0.3px; box-shadow:0 2px 8px rgba(0,0,0,0.4); margin-bottom:5px;">
                ${badgeText}
            </div>

            <!-- Main Title -->
            <h2 style="font-size:14.5px; font-weight:900; background:${titleGrad}; -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin:0 0 3px 0; letter-spacing:0.3px; filter:drop-shadow(0 2px 6px rgba(0,0,0,0.6));">
                ${titleText}
            </h2>

            <!-- Detail Message -->
            ${timeDetailHtml}

            <!-- Live Countdown if any -->
            ${countdownHtml}

            <p style="font-size:9.5px; color:#94a3b8; max-width:460px; line-height:1.35; margin:0 auto 6px;">
                ${descText}
            </p>

            <!-- Target Reward Preview (if any) -->
            ${targetItem ? `
                <div style="display:flex; align-items:center; gap:10px; background:linear-gradient(135deg, rgba(30,41,59,0.7), rgba(15,23,42,0.85)); border:1.5px solid ${borderColor}; border-radius:10px; padding:5px 12px; margin-bottom:8px; max-width:380px; width:100%; box-shadow:0 4px 14px rgba(0,0,0,0.35); text-align:left; box-sizing:border-box;">
                    <div style="width:32px; height:32px; min-width:32px; border-radius:8px; background:radial-gradient(circle, ${auraColor}, rgba(0,0,0,0.6)); border:1.5px solid ${borderColor}; display:flex; align-items:center; justify-content:center; font-size:17px; box-shadow:0 0 10px ${auraColor}; flex-shrink:0;">
                        ${shapeIcon}
                    </div>
                    <div style="min-width:0; flex:1;">
                        <div style="font-size:9px; color:#94a3b8; font-weight:700; display:flex; align-items:center; gap:5px;">
                            <span>อัญมณีประจำอีเวนต์:</span>
                            <span style="background:linear-gradient(135deg, #ef4444, #b91c1c); color:#fff; font-size:8.5px; font-weight:900; padding:0.5px 5px; border-radius:3px;">${targetItem.grade || 'SS+'}</span>
                        </div>
                        <div style="font-size:12px; font-weight:800; color:#f8fafc; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:1px;">
                            ${targetItem.name}
                        </div>
                        <div style="font-size:9px; margin-top:1px;">
                            ${itemStatusHtml}
                        </div>
                    </div>
                </div>
            ` : ''}

            <!-- Recommended Actions Navigation -->
            <div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:center; max-width:480px; width:100%;">
                <button type="button" class="btn" onclick="closeModal('modal-gem-gacha'); openFrameEventModal();" style="flex:1; min-width:110px; background:linear-gradient(135deg, #d97706, #b45309); color:#fff; font-weight:800; font-size:10.5px; padding:6px 10px; border-radius:8px; border:none; cursor:pointer; box-shadow:0 3px 10px rgba(217,119,6,0.35); transition:transform 0.15s ease;">
                    👑 ไปหน้าอีเวนต์กรอบรูป
                </button>
                <button type="button" class="btn" onclick="closeModal('modal-gem-gacha'); openDiceEventModal();" style="flex:1; min-width:110px; background:linear-gradient(135deg, #0284c7, #0369a1); color:#fff; font-weight:800; font-size:10.5px; padding:6px 10px; border-radius:8px; border:none; cursor:pointer; box-shadow:0 3px 10px rgba(2,132,199,0.35); transition:transform 0.15s ease;">
                    🎲 ไปหน้าอีเวนต์เต๋า 3D
                </button>
                <button type="button" class="btn" onclick="closeModal('modal-gem-gacha'); openGemInventory();" style="flex:1; min-width:110px; background:linear-gradient(135deg, #8b5cf6, #6d28d9); color:#fff; font-weight:800; font-size:10.5px; padding:6px 10px; border-radius:8px; border:none; cursor:pointer; box-shadow:0 3px 10px rgba(139,92,246,0.35); transition:transform 0.15s ease;">
                    💎 คลังอัญมณีของฉัน
                </button>
            </div>
        </div>
    `;
};

window.renderGemEventSeparatedUI = function (ev, targetItem) {
    const body = document.getElementById('gem-event-body');
    if (!body) return;

    const now = Date.now();
    const isExpired = Boolean(
        (window._gemGachaEventData && window._gemGachaEventData.statusState === 'EXPIRED') ||
        (ev && (ev.is_expired || ev.is_active == 0 || (ev.end_date && window.isThaiDateExpired(ev.end_date))))
    );

    const costSingle = Math.max(10, parseInt(ev.cost_diamond || 100, 10));
    const costEvent5 = Math.round(costSingle * 5 * 0.9);
    const costPremium5 = Math.round(costSingle * 5 * 1.45);
    const costPremium10 = Math.round(costSingle * 10 * 1.35);

    // Target gem info
    const gem = targetItem || { name: 'อัญมณีมหาเวทย์', grade: 'SS+', skill_name: 'สกิลพิเศษ', trigger_rate_percent: 90 };
    const gemName = gem.name || 'อัญมณีมหาเวทย์';
    const gemGrade = gem.grade || 'SS+';
    const gemSkill = gem.skill_name || gem.skill_category || 'สกิลพิเศษ';
    const gemRate = parseFloat(gem.trigger_rate_percent || 90);
    const gemShape = gem.shape || 'pentagon';
    const gemColor = gem.gem_color || (gemGrade === 'SS+' ? '#ff4444' : gemGrade === 'S+' ? '#00e5ff' : '#ffd700');

    // Shadow rates from event
    const r1 = parseFloat(ev.shadow_rate_1 || 90);
    const r2 = parseFloat(ev.shadow_rate_2 || 80);
    const r3 = parseFloat(ev.shadow_rate_3 || 70);
    const r4 = parseFloat(ev.shadow_rate_4 || 50);
    const r5 = parseFloat(ev.shadow_rate_5 || 10);

    // Parse custom 5-tier shadow config generated by AI / admin (supporting both object by slot and array)
    let shadowPieces = [];
    if (ev && ev.shadow_config_json) {
        try {
            const rawCfg = (typeof ev.shadow_config_json === 'string') ? JSON.parse(ev.shadow_config_json) : ev.shadow_config_json;
            if (Array.isArray(rawCfg) && rawCfg.length === 5) {
                shadowPieces = rawCfg;
            } else if (rawCfg && typeof rawCfg === 'object' && !Array.isArray(rawCfg)) {
                const slots = ['black', 'red', 'orange', 'blue', 'gold'];
                shadowPieces = slots.map((sKey, sIdx) => {
                    const item = rawCfg[sKey] || {};
                    const defCols = { black: '#64748b', red: '#ef4444', orange: '#ff7b00', blue: '#38bdf8', gold: '#ffd700' };
                    const defGrades = { black: 'A', red: 'A', orange: 'A', blue: 'A+', gold: 'S' };
                    const defRates = { black: 90, red: 80, orange: 70, blue: 50, gold: 10 };
                    const defReqs = { black: 15, red: 15, orange: 15, blue: 10, gold: 4 };
                    return {
                        slot: sIdx + 1,
                        slot_key: sKey,
                        name: item.name || `เงา${sKey === 'black' ? 'ดำ' : (sKey === 'red' ? 'แดง' : (sKey === 'orange' ? 'ส้ม' : (sKey === 'blue' ? 'ฟ้า' : 'ทอง')))} ${item.grade || defGrades[sKey]}`,
                        grade: item.grade || defGrades[sKey],
                        shape: gemShape,
                        color: item.color || defCols[sKey] || '#a855f7',
                        aura: item.aura_type || item.aura || 'none',
                        intensity: item.aura_intensity || item.intensity || 100,
                        rate: item.rate !== undefined ? item.rate : defRates[sKey],
                        req_count: item.req !== undefined ? item.req : defReqs[sKey]
                    };
                });
            }
        } catch (e) {
            console.warn('parse ev.shadow_config_json err:', e);
        }
    }
    if (!Array.isArray(shadowPieces) || shadowPieces.length !== 5) {
        shadowPieces = [
            { slot: 1, slot_key: 'black', name: 'เงาดำ A', grade: 'A', shape: gemShape, color: '#64748b', aura: 'none', intensity: 100, rate: r1, req_count: 15 },
            { slot: 2, slot_key: 'red', name: 'เงาแดง A', grade: 'A', shape: gemShape, color: '#ef4444', aura: 'none', intensity: 100, rate: r2, req_count: 15 },
            { slot: 3, slot_key: 'orange', name: 'เงาส้ม A', grade: 'A', shape: gemShape, color: '#ff7b00', aura: 'none', intensity: 100, rate: r3, req_count: 15 },
            { slot: 4, slot_key: 'blue', name: 'เงาฟ้า A+', grade: 'A+', shape: gemShape, color: '#38bdf8', aura: 'none', intensity: 100, rate: r4, req_count: 10 },
            { slot: 5, slot_key: 'gold', name: 'เงาทอง S', grade: 'S', shape: gemShape, color: '#ffd700', aura: 'none', intensity: 100, rate: r5, req_count: 4 }
        ];
    }
    const featuredSlot = parseInt((ev && ev.featured_shadow_slot) || 5, 10) || 5;
    const featuredShadowObj = shadowPieces.find(s => parseInt(s.slot, 10) === featuredSlot) || shadowPieces[4];

    const isRealImg = gem.icon_url && (gem.icon_url.startsWith('http') || gem.icon_url.startsWith('data:image') || gem.icon_url.startsWith('uploads/'));
    const heroGemSvg = window.generateGemSvgPreview(gemShape, gemGrade, 48, gemColor);

    function getGemClientShadowAuraStyle(aura, color, intensity) {
        const baseColor = color || '#a855f7';
        const factor = Math.max(0.3, Math.min(2.5, (intensity || 100) / 100));
        const glow1 = Math.round(6 * factor);
        const glow2 = Math.round(14 * factor);

        let bg = `radial-gradient(circle at 50% 50%, ${baseColor}33 0%, rgba(15,23,42,0.92) 75%)`;
        let boxShadow = `0 0 ${glow1}px ${baseColor}, 0 0 ${glow2}px ${baseColor}88`;

        if (aura === 'none') {
            boxShadow = `0 2px 6px rgba(0,0,0,0.5)`;
            bg = 'rgba(15,23,42,0.85)';
        } else if (aura === 'cyan') {
            boxShadow = `0 0 ${glow1}px #00e5ff, 0 0 ${glow2}px rgba(0,229,255,0.6)`;
            bg = `radial-gradient(circle, rgba(0,229,255,0.25) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'purple') {
            boxShadow = `0 0 ${glow1}px #c084fc, 0 0 ${glow2}px rgba(168,85,247,0.6)`;
            bg = `radial-gradient(circle, rgba(168,85,247,0.25) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'gold') {
            boxShadow = `0 0 ${glow1}px #ffd700, 0 0 ${glow2}px rgba(245,158,11,0.65)`;
            bg = `radial-gradient(circle, rgba(255,215,0,0.3) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'crimson') {
            boxShadow = `0 0 ${glow1}px #ef4444, 0 0 ${glow2}px rgba(220,38,38,0.6)`;
            bg = `radial-gradient(circle, rgba(239,68,68,0.28) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'orange') {
            boxShadow = `0 0 ${glow1}px #f97316, 0 0 ${glow2}px rgba(249,115,22,0.6)`;
            bg = `radial-gradient(circle, rgba(249,115,22,0.28) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'neon') {
            boxShadow = `0 0 ${glow1}px #10b981, 0 0 ${glow2}px rgba(16,185,129,0.6)`;
            bg = `radial-gradient(circle, rgba(16,185,129,0.25) 0%, rgba(15,23,42,0.92) 75%)`;
        } else if (aura === 'rainbow') {
            boxShadow = `0 0 ${glow1}px #f43f5e, 0 0 ${glow2}px #38bdf888`;
            bg = `radial-gradient(circle, rgba(244,63,94,0.25) 0%, rgba(56,189,248,0.2) 50%, rgba(15,23,42,0.92) 75%)`;
        }

        return `background:${bg}; box-shadow:${boxShadow}; border:1.5px solid ${baseColor};`;
    }

    const missingCount = shadowPieces.filter((s, idx) => {
        const sCode = 'SHADOW_GEM_' + (idx + 1);
        const owned = (window._gemGachaEventData && window._gemGachaEventData.user_shadows && window._gemGachaEventData.user_shadows[sCode]) || 0;
        const req = s.req_count || (idx === 4 ? 4 : (idx === 3 ? 10 : 15));
        return owned < req;
    }).length;
    const canExchangeAll = (missingCount === 0);

    window._latestGemEventTarget = gem;
    body.innerHTML = `
        <!-- Left Showcase & Horizontal Shadow Exchange (Exact matching Frame Gacha!) -->
        <div class="event-hero-panel">
            <div>
                <div class="event-hero-poster">
                    <div class="event-hero-emblem" onclick="if(typeof window.openEventTargetLargePreviewModal==='function') window.openEventTargetLargePreviewModal('GEM', window._latestGemEventTarget)" title="🔍 คลิกดูรูปใหญ่พร้อมเอฟเฟกต์" style="position:relative; width:60px; height:60px; border-radius:12px; border:2px solid ${gemColor}; background:radial-gradient(circle at 50% 50%, ${gemColor}44 0%, #050811 85%); box-shadow:0 0 18px ${gemColor}88; display:flex; align-items:center; justify-content:center; flex-shrink:0; overflow:hidden; cursor:pointer;">
                        ${isRealImg
            ? `<img src="${gem.icon_url}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" style="width:48px; height:48px; object-fit:contain; border-radius:8px;">
                               <div style="display:none; width:100%; height:100%; align-items:center; justify-content:center;">${heroGemSvg}</div>`
            : `<div style="display:flex; width:100%; height:100%; align-items:center; justify-content:center;">${heroGemSvg}</div>`
        }
                        <span style="position:absolute; top:2px; left:2px; background:rgba(0,0,0,0.65); color:#fff; font-size:8.5px; padding:1px 3px; border-radius:4px; z-index:6;">🔍</span>
                    </div>
                    <div style="min-width:0; flex:1;">
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                            <span style="background:linear-gradient(135deg,${gemColor},#7c3aed); color:#fff; font-size:10px; font-weight:900; padding:2px 7px; border-radius:5px; box-shadow:0 0 8px ${gemColor}66;">${gemGrade}</span>
                            <span style="font-size:10px; color:#fde047; font-weight:800;">รางวัลใหญ่ประจำอีเวนต์อัญมณี</span>
                            ${Boolean((window._gemGachaEventData && window._gemGachaEventData.user_has_target_gem) || (ev && ev.user_has_target_gem)) ? `<span style="background:linear-gradient(135deg,#10b981,#059669); color:#fff; font-size:9.5px; font-weight:900; padding:2px 7px; border-radius:5px; box-shadow:0 0 8px rgba(16,185,129,0.6); display:inline-flex; align-items:center; gap:3px;">🎉 มีในคลังแล้ว</span>` : ''}
                        </div>
                        <div style="font-size:clamp(15px,1.9vw,20px); font-weight:900; color:#fff; margin-top:3px; text-shadow:0 2px 8px rgba(0,0,0,0.8); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${gemName}</div>
                        ${(typeof window.getGemSkillsWithScaledRates === 'function' ? window.getGemSkillsWithScaledRates(gem) : [{ name: gemSkill, max_rate: gemRate }]).map((sk, sIdx, arr) => `
                            <div style="font-size:11px; color:${sIdx === 0 ? '#bae6fd' : '#fde68a'}; margin-top:2px; line-height:1.3; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">⚡ ${arr.length > 1 ? `สกิล ${sIdx + 1}: ` : 'สกิล: '}${sk.name} (สูงสุด ${sk.max_rate || gemRate}%)</div>
                        `).join('')}
                    </div>
                </div>

                <!-- Horizontal Shadow Progress Strip (Exact matching Frame Gacha!) -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <span style="font-size:11px; font-weight:800; color:#fde68a;">✨ สะสมการ์ดเงาแลกอัญมณี (แนวนอน):</span>
                    ${isExpired
            ? `<span style="background:rgba(239,68,68,0.25); border:1px solid rgba(239,68,68,0.6); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">🛑 กิจกรรมหมดเวลา (ไม่สามารถแลกได้)</span>`
            : (canExchangeAll
                ? `<button type="button" class="btn-lgr-exchange-sparkle frame-sparkle" onclick="window.exchangeGemEventReward()" title="เงาครบแล้ว! กดแลกรับอัญมณีทันที">
                               <span class="btn-sparkle-star">✨</span>
                               <span class="btn-text">ครบพร้อมแลก! (กดแลกทันที)</span>
                               <span class="btn-sparkle-tag">FREE</span>
                           </button>`
                : `<span style="background:rgba(239,68,68,0.2); border:1px solid rgba(239,68,68,0.5); color:#fca5a5; font-size:10px; font-weight:800; padding:2px 8px; border-radius:10px;">ขาดอีก ${missingCount} ชนิด</span>`
            )
        }
                </div>

                <div class="shadow-5card-grid">
                    ${shadowPieces.map((s, idx) => {
            const isFeatured = (parseInt(s.slot, 10) === featuredSlot || idx === 4);
            const sShape = gemShape || s.shape || 'pentagon';
            const sCode = 'SHADOW_GEM_' + (idx + 1);
            const ownedCount = (window._gemGachaEventData && window._gemGachaEventData.user_shadows && window._gemGachaEventData.user_shadows[sCode]) || 0;
            const reqCount = s.req_count || (idx === 4 ? 4 : (idx === 3 ? 10 : 15));
            const isReady = ownedCount >= reqCount;
            const svgPreview = window.generateGemSvgPreview(sShape, s.grade, 34, s.color);
            const dateBadgeText = window.formatEventDateRangeShort ? window.formatEventDateRangeShort(ev?.start_date, ev?.end_date) : '';

            return `
                            <div class="shadow-card-admin-item"
                                 onclick="showShadowDetailModal(${idx})"
                                 title="คลิกดูรายละเอียด: ${s.name} (${s.grade}) สะสม ${ownedCount}/${reqCount}${ev?.end_date ? ` • หมดอายุ ${ev.end_date}` : ''}"
                                 style="${isFeatured ? 'border-color:#ffd700; box-shadow:0 0 12px rgba(255,215,0,0.5);' : `border-color:${s.color}66;`}">
                                
                                <!-- Live Preview Box พร้อมเกรดตรงกลาง เช่น A, A+ สวยเด่น พอดีกับข้างใน -->
                                <div class="shadow-card-admin-thumb"
                                     style="border:1.5px solid ${s.color}; background:radial-gradient(circle at 50% 50%, ${s.color}44 0%, #050811 85%); box-shadow:0 0 10px ${s.color}55;">
                                    
                                    <!-- Background 3D Gem Shape Watermark -->
                                    <div style="position:absolute; width:100%; height:100%; display:flex; align-items:center; justify-content:center; pointer-events:none; opacity:0.65; z-index:1;">
                                        ${svgPreview}
                                    </div>

                                    <!-- Center Grade Emblem -->
                                    ${window.gradeEmblemHtml(s.grade, s.color, s.grade === 'A+' ? 18 : (s.grade === 'A' ? 20 : 18))}

                                    <!-- Corner Badge -->
                                    <span style="position:absolute; bottom:2px; right:2px; background:${s.color}; color:#000; font-size:7.5px; font-weight:900; padding:0.5px 3.5px; border-radius:3px; border:1px solid #fff; z-index:6; line-height:1.1;">
                                        ${s.grade}
                                    </span>

                                    ${isFeatured ? `<div style="position:absolute; top:2px; right:2px; font-size:10px; filter:drop-shadow(0 0 3px #ffd700); z-index:6;">👑</div>` : ''}
                                </div>

                                <!-- Shadow Name -->
                                <div class="shadow-card-admin-name" style="color:${s.color};">
                                    ${s.name}
                                </div>

                                <!-- Event Date Range / Expiration Badge -->
                                <div class="shadow-card-date-badge ${isExpired ? 'is-expired' : ''}">
                                    ${isExpired ? '🛑 หมดอายุ' : (dateBadgeText ? `📅 ${dateBadgeText}` : '📅 ประจำอีเวนต์')}
                                </div>

                                <!-- Owned / Req Badge (แสดงจำนวน เช่น 50/15 คมชัด สวยงาม) -->
                                <div class="shadow-card-admin-qty ${isReady ? 'is-ready' : 'is-missing'}">
                                    ${isReady ? '<span style="font-size:9px;">✓</span>' : ''}<span>${ownedCount}/${reqCount}</span>
                                </div>
                            </div>
                        `;
        }).join('')}
                </div>
                ${typeof window.buildEventSpecialAwakeningBannerHtml === 'function' ? window.buildEventSpecialAwakeningBannerHtml('gem', Number(window._gemGachaEventData?.user_shadows?.['SPECIAL_GEM_CARD'] ?? window.latestMaterialsMap?.['SPECIAL_GEM_CARD'] ?? 0)) : ''}
            </div>

            <!-- Exchange Target Gem Card (Exact matching Frame / Dice Gacha!) -->
            <div class="event-target-card gem-card ${canExchangeAll && !isExpired ? 'ready-to-exchange' : 'not-ready'}" style="margin-top:6px; padding:10px;">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
                    <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                        <div style="width:36px; height:36px; border-radius:10px; background:radial-gradient(circle, ${gemColor}44 0%, #050811 85%); border:2px solid ${gemColor}; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                            ${window.generateGemSvgPreview(gemShape, gemGrade, 28, gemColor)}
                        </div>
                        <div style="min-width:0;">
                            <div style="font-size:12px; font-weight:900; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">💎 ${gemName}</div>
                            <div style="font-size:10px; color:#cbd5e1;">${isExpired ? '🛑 กิจกรรมนี้สิ้นสุดลงแล้ว การ์ดเงาหมดอายุ ไม่สามารถแลกรับได้' : (canExchangeAll ? 'สะสมเงาครบแล้ว กดแลกรับอัญมณีแท้ได้ทันที!' : 'สะสมเงาให้ครบทั้ง 5 สีเพื่อปลดล็อกปุ่มแลก')}</div>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn-lgr-exchange-hero ${canExchangeAll && !isExpired ? 'is-ready' : 'is-disabled'}"
                    style="${canExchangeAll && !isExpired ? `background:linear-gradient(135deg, ${gemColor}, #f59e0b); border-color:#fde047; box-shadow:0 0 16px rgba(245,158,11,0.65);` : ''}"
                    onclick="${canExchangeAll && !isExpired ? 'window.exchangeGemEventReward()' : ''}"
                    ${canExchangeAll && !isExpired ? '' : 'disabled'}>
                    <span class="hero-shine-sweep"></span>
                    <span class="hero-btn-content">
                        ${isExpired ? '🛑 กิจกรรมสิ้นสุดแล้ว (การ์ดเงาหมดอายุ)' : (canExchangeAll ? `✨ 💎 กดแลกรับ [${gemName}] ทันที! ⚡ ✨` : `🔒 เงายังไม่ครบ (ขาดอีก ${missingCount} ชนิด)`)}
                    </span>
                </button>
            </div>
        </div>

        <!-- Right 6 Gem Gacha Pack Cards Grid (Exact matching Frame / Dice Gacha!) -->
        <div class="event-packs-grid">
            <div class="gacha-pack-shop-card is-special" onclick="rollGemGacha(1)">
                <div class="pack-card-header-bar">แพ็คอัญมณีพิเศษ (+1)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil" style="border-color:#a78bfa; background:rgba(139,92,246,0.15);"><span class="mini-foil-icon">💎</span><span class="mini-foil-qty">1</span></div>
                    <div class="pack-card-desc">สุ่มอัญมณีหรือเงาอัญมณี<br>พิเศษ (+1 ชิ้น)</div>
                </div>
                <div class="pack-card-price-btn">💎 ${costSingle.toLocaleString()}</div>
            </div>

            <div class="gacha-pack-shop-card" onclick="rollGemGacha(1, 'GOLD')">
                <div class="pack-card-header-bar">ชุดอัญมณีทั่วไป (+1)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🌑</span><span class="mini-foil-qty">1</span></div>
                    <div class="pack-card-desc">สุ่มเงาอัญมณี<br>ระดับ A ~ A+ (1 ชิ้น)</div>
                </div>
                <div class="pack-card-price-btn">💰 30,000</div>
            </div>

            <div class="gacha-pack-shop-card" onclick="rollGemGacha(5, 'GOLD')">
                <div class="pack-card-header-bar">ชุดอัญมณีทั่วไป (+5)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil gold-foil"><span class="mini-foil-icon">🌑</span><span class="mini-foil-qty">5</span></div>
                    <div class="pack-card-desc">สุ่มเงาอัญมณี<br>แบบคุ้มค่า 5 ชิ้นรวด!</div>
                </div>
                <div class="pack-card-price-btn">💰 120,000</div>
            </div>

            <div class="gacha-pack-shop-card is-event-hot" onclick="rollGemGacha(5)">
                <span class="pack-card-event-flag">EVENT</span>
                <div class="pack-card-header-bar">แพ็คอัญมณีพิเศษ (+5)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil" style="border-color:#a78bfa; background:rgba(139,92,246,0.15);"><span class="mini-foil-icon">💎</span><span class="mini-foil-qty">5</span></div>
                    <div class="pack-card-desc">แพ็คอีเวนต์ยอดนิยม!<br>เปิดสุ่มอัญมณี 5 ชิ้น (ลด 10%)</div>
                </div>
                <div class="pack-card-price-btn">💎 ${costEvent5.toLocaleString()}</div>
            </div>

            <div class="gacha-pack-shop-card is-premium" onclick="rollGemGacha(5, 'DIAMOND', 'PREMIUM')">
                <div class="pack-card-header-bar">ชุดอัญมณีพรีเมียม (+5)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil" style="border-color:#e879f9; background:rgba(232,121,249,0.15);"><span class="mini-foil-icon">✨</span><span class="mini-foil-qty">5</span></div>
                    <div class="pack-card-desc">เรตอัปเงาชั้น 4-5<br>& ลุ้นอัญมณีจริง 5 ชิ้น</div>
                </div>
                <div class="pack-card-price-btn">💎 ${costPremium5.toLocaleString()}</div>
            </div>

            <div class="gacha-pack-shop-card is-premium" onclick="rollGemGacha(10, 'DIAMOND', 'PREMIUM')">
                <span class="pack-card-event-flag">HOT</span>
                <div class="pack-card-header-bar">ชุดอัญมณีพรีเมียม (+10)</div>
                <div class="pack-card-mid">
                    <div class="pack-mini-foil" style="border-color:#f472b6; background:rgba(244,114,182,0.15);"><span class="mini-foil-icon">🔥</span><span class="mini-foil-qty">10</span></div>
                    <div class="pack-card-desc">แพ็คใหญ่จุใจ 10 ชิ้น<br>โอกาสออกอัญมณีแท้สูงสุด!</div>
                </div>
                <div class="pack-card-price-btn">💎 ${costPremium10.toLocaleString()}</div>
            </div>
        </div>
    `;
};

window.openGemEventRatesInfoPopup = async function () {
    let data = window._gemGachaEventData;
    if (!data || !data.event) {
        try {
            const res = await fetch('api/equipment_service.php?action=get_gem_gacha_event');
            const json = await res.json();
            if (json && json.status === 'success') {
                window._gemGachaEventData = json;
                data = json;
            }
        } catch (e) {
            console.warn('fetch gem event rate info err:', e);
        }
    }
    if (typeof window.openGachaDropRateModal === 'function') {
        window.openGachaDropRateModal('GEM', 'SPECIAL');
        return;
    }
};

// Auto load gem gacha event info on startup
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(window.loadGemGachaEventUI, 1200);
    });
} else {
    setTimeout(window.loadGemGachaEventUI, 1200);
}


// 8.1 SHADOW DETAIL MODAL (คลิกดูรายละเอียดเงา & จำนวนสะสม)
window.showShadowDetailModal = function (idx) {
    const ev = window._gemGachaEventData?.event;
    const targetItem = window._gemGachaEventData?.target_item;
    const targetName = targetItem?.name || 'อัญมณีมหาเวทย์';
    const targetShape = targetItem?.shape || 'pentagon';
    const content = document.getElementById('gem-shadow-detail-content');
    if (!content) return;

    let shadowPieces = [];
    if (ev && ev.shadow_config_json) {
        try {
            const rawCfg = (typeof ev.shadow_config_json === 'string') ? JSON.parse(ev.shadow_config_json) : ev.shadow_config_json;
            if (Array.isArray(rawCfg) && rawCfg.length === 5) {
                shadowPieces = rawCfg;
            } else if (rawCfg && typeof rawCfg === 'object' && !Array.isArray(rawCfg)) {
                const slots = ['black', 'red', 'orange', 'blue', 'gold'];
                shadowPieces = slots.map((sKey, sIdx) => {
                    const item = rawCfg[sKey] || {};
                    const defCols = { black: '#64748b', red: '#ef4444', orange: '#ff7b00', blue: '#38bdf8', gold: '#ffd700' };
                    const defGrades = { black: 'A', red: 'A', orange: 'A', blue: 'A+', gold: 'S' };
                    const defRates = { black: 90, red: 80, orange: 70, blue: 50, gold: 10 };
                    const defReqs = { black: 15, red: 15, orange: 15, blue: 10, gold: 4 };
                    return {
                        slot: sIdx + 1,
                        slot_key: sKey,
                        name: item.name || `เงา${sKey === 'black' ? 'ดำ' : (sKey === 'red' ? 'แดง' : (sKey === 'orange' ? 'ส้ม' : (sKey === 'blue' ? 'ฟ้า' : 'ทอง')))} ${item.grade || defGrades[sKey]}`,
                        grade: item.grade || defGrades[sKey],
                        shape: targetShape,
                        color: item.color || defCols[sKey] || '#a855f7',
                        aura: item.aura_type || item.aura || 'none',
                        intensity: item.aura_intensity || item.intensity || 100,
                        rate: item.rate !== undefined ? item.rate : defRates[sKey],
                        req_count: item.req !== undefined ? item.req : defReqs[sKey]
                    };
                });
            }
        } catch (e) { }
    }
    if (!Array.isArray(shadowPieces) || shadowPieces.length !== 5) {
        shadowPieces = [
            { slot: 1, slot_key: 'black', name: 'เงาดำ A', grade: 'A', shape: targetShape, color: '#64748b', aura: 'none', rate: 90, req_count: 15 },
            { slot: 2, slot_key: 'red', name: 'เงาแดง A', grade: 'A', shape: targetShape, color: '#ef4444', aura: 'none', rate: 80, req_count: 15 },
            { slot: 3, slot_key: 'orange', name: 'เงาส้ม A', grade: 'A', shape: targetShape, color: '#ff7b00', aura: 'none', rate: 70, req_count: 15 },
            { slot: 4, slot_key: 'blue', name: 'เงาฟ้า A+', grade: 'A+', shape: targetShape, color: '#38bdf8', aura: 'none', rate: 50, req_count: 10 },
            { slot: 5, slot_key: 'gold', name: 'เงาทอง S', grade: 'S', shape: targetShape, color: '#ffd700', aura: 'none', rate: 10, req_count: 4 }
        ];
    }

    const s = shadowPieces[idx] || shadowPieces[0];
    const sCode = 'SHADOW_GEM_' + (idx + 1);
    const ownedCount = (window._gemGachaEventData && window._gemGachaEventData.user_shadows && window._gemGachaEventData.user_shadows[sCode]) || 0;
    const reqCount = s.req_count || (idx === 4 ? 4 : (idx === 3 ? 10 : 15));
    const pct = Math.min(100, Math.round((ownedCount / Math.max(1, reqCount)) * 100));
    const isReady = ownedCount >= reqCount;
    let gemStartDate = ev?.start_date;
    let gemEndDate = ev?.end_date;
    if (!gemStartDate || !gemEndDate) {
        const gemSt = window.latestEventsStatus ? window.latestEventsStatus['GEM'] : null;
        if (gemSt) {
            gemStartDate = gemStartDate || gemSt.start_date;
            gemEndDate = gemEndDate || gemSt.end_date;
        }
    }
    if (!gemStartDate) gemStartDate = '2026-11-16 14:50:00';
    if (!gemEndDate) gemEndDate = '2026-11-25 23:59:59';

    const isGemLive = Boolean((window._gemGachaEventData && window._gemGachaEventData.isLive) || (ev && ev.is_active == 1) || (window.latestEventsStatus && window.latestEventsStatus['GEM'] && !window.latestEventsStatus['GEM'].is_expired));
    const isExpired = isGemLive ? false : Boolean(ev && (ev.is_expired || (ev.end_date && window.isThaiDateExpired(ev.end_date))));
    const dateRangeShort = window.formatEventDateRangeShort ? window.formatEventDateRangeShort(gemStartDate, gemEndDate) : '';

    const topIconHtml = window.generateGemSvgPreview(s.shape || targetShape, s.grade, 34, s.color);

    content.innerHTML = `
        <!-- Live Preview Card (Compact) -->
        <div style="position:relative; width:136px; max-width:80%; height:48px; margin:0 auto 6px auto; border-radius:9px; border:1.5px solid ${s.color}; display:flex; align-items:center; justify-content:center; overflow:hidden; background:radial-gradient(circle at 50% 50%, ${s.color}44 0%, #050811 85%); box-shadow:0 0 14px ${s.color}66, inset 0 0 10px ${s.color}33;">
            <div style="position:absolute; width:100%; height:100%; display:flex; align-items:center; justify-content:center; pointer-events:none; opacity:0.3; z-index:1;">
                ${topIconHtml}
            </div>
            <div class="grade-emblem" style="--gc:${s.color}; font-size:24px; z-index:5; font-family:'Kanit',sans-serif; font-weight:900; line-height:1; letter-spacing:-0.5px;">
                <span class="ge-txt" style="color:#ffffff; text-shadow:0 0 10px ${s.color}, 0 2px 4px rgba(0,0,0,0.9); font-weight:900;">${window.gradeEmblemInnerHtml ? window.gradeEmblemInnerHtml(s.grade) : s.grade}</span>
            </div>
            <span class="sh-grade-pill" style="position:absolute; bottom:3px; right:3px; background:${s.color}; color:#000; font-size:8px; font-weight:900; padding:1px 4px; border-radius:4px; border:1px solid #fff; z-index:6; line-height:1;">
                ${s.grade}
            </span>
            ${(idx === 4 || s.grade === 'S' || s.grade === 'S+' || s.grade === 'SS+') ? `
                <div style="position:absolute; top:2px; right:3px; font-size:10px; filter:drop-shadow(0 0 4px #ffd700); z-index:6;">👑</div>
            ` : ''}
        </div>

        <!-- Tag Pill -->
        <div style="display:inline-block; padding:1.5px 10px; border-radius:6px; background:${s.color}22; border:1px solid ${s.color}; color:${s.color}; font-size:9.5px; font-weight:900; letter-spacing:0.2px;">
            [${s.grade}] ชิ้นส่วนเงาอันดับ ${idx + 1}
        </div>

        <!-- Shadow Title -->
        <div style="margin:3px 0 5px 0; color:#fff; font-size:13.5px; font-weight:900; line-height:1.2; text-shadow:0 2px 5px rgba(0,0,0,0.8);">
            ${s.name}
        </div>
        
        <!-- Progress Container -->
        <div style="background:rgba(10,15,30,0.75); border:1px solid rgba(255,255,255,0.12); border-radius:9px; padding:6px 9px; text-align:left;">
            <div style="display:flex; justify-content:space-between; align-items:center; font-size:10px; margin-bottom:4px;">
                <span style="color:#e2e8f0; font-weight:800;">จำนวนที่ครอบครอง:</span>
                <span style="color:#38bdf8; font-weight:900; font-size:11.5px;">${ownedCount} / ${reqCount} ชิ้น</span>
            </div>
            <div style="width:100%; height:6px; border-radius:3px; background:rgba(255,255,255,0.1); overflow:hidden;">
                <div style="width:${pct}%; height:100%; background:linear-gradient(90deg, #38bdf8 0%, #a855f7 100%); border-radius:3px;"></div>
            </div>
            <div style="margin-top:4px; font-size:9.5px; font-weight:800; color:${isReady ? '#4ade80' : '#94a3b8'}; line-height:1.25;">
                ${isReady ? '🎉 สะสมครบแล้ว! พร้อมหลอมแลกรับอัญมณีแท้' : `⏳ ขาดอีก ${reqCount - ownedCount} ชิ้น เพื่อแลกรับ [${targetName}]`}
            </div>
        </div>

        <!-- Event Period & Rules Box -->
        <div style="margin-top:5px; background:rgba(15,23,42,0.8); border:1px solid ${isExpired ? '#ef4444' : 'rgba(16,185,129,0.45)'}; border-radius:9px; padding:6px 9px; text-align:left; font-size:9.5px; line-height:1.3;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
                <span style="color:#94a3b8; font-weight:800;">📅 ระยะเวลากิจกรรม:</span>
                <span style="color:${isExpired ? '#f87171' : '#34d399'}; font-weight:900;">
                    ${isExpired ? '🛑 สิ้นสุดแล้ว' : '🔥 กำลังจัดกิจกรรม'}
                </span>
            </div>
            <div style="color:#cbd5e1; font-size:9px;">
                ${window.formatEventDateLong(gemStartDate)} – ${window.formatEventDateLong(gemEndDate)}
            </div>
        </div>

        <!-- Confirm Button -->
        <button type="button" onclick="closeModal('modal-gem-shadow-detail')" style="width:100%; margin-top:7px; padding:6px 10px; border-radius:8px; background:linear-gradient(135deg, #a855f7, #7c3aed); color:#fff; font-weight:900; font-size:11.5px; border:none; cursor:pointer; box-shadow:0 0 12px rgba(168,85,247,0.45);">
            ตกลง
        </button>
    `;

    openModal('modal-gem-shadow-detail');
};

// 8. ROLL GEM GACHA (Full Animated Video-Style Popup & Purchase Confirmation)
window.rollGemGacha = async function (count = 1, currency = 'DIAMOND', tier = 'SPECIAL', skipConfirm = false) {
    if (!window._gemGachaEventData || !window._gemGachaEventData.isLive) {
        alert('🛑 ขออภัย! ขณะนี้ไม่มีกิจกรรมสุ่มอัญมณีที่เปิดใช้งาน หรือกิจกรรมได้สิ้นสุดระยะเวลาลงแล้ว');
        return;
    }

    const userId = (window.DEFAULT_USER && window.DEFAULT_USER.id && Number(window.DEFAULT_USER.id) > 0) ? Number(window.DEFAULT_USER.id) : null;
    if (!userId) {
        if (typeof showInGameAlert === 'function') showInGameAlert('กรุณาเข้าสู่ระบบก่อนสุ่มอัญมณี', 'เข้าสู่ระบบ', '⚠️');
        return;
    }
    const costPerPull = window.activeGemGachaCost || 100;
    const currUpper = String(currency || 'DIAMOND').toUpperCase();
    const tierUpper = String(tier || 'SPECIAL').toUpperCase();

    let totalCost = 0;
    if (currUpper === 'GOLD') {
        totalCost = count >= 5 ? 120000 : (30000 * count);
    } else if (tierUpper === 'PREMIUM') {
        totalCost = count >= 10 ? Math.round(costPerPull * 10 * 1.35) : Math.round(costPerPull * 5 * 1.45);
    } else {
        totalCost = count >= 5 ? Math.round(costPerPull * count * 0.9) : (costPerPull * count);
    }

    const costLabel = (currUpper === 'GOLD') ? '💰 ' + totalCost.toLocaleString() : '💎 ' + totalCost.toLocaleString();

    let packTitle = 'แพ็คอัญมณีพิเศษ (+' + count + ' ชิ้น)';
    let packDesc = 'สุ่มอัญมณีหรือเงาอัญมณีพิเศษ (+' + count + ' ชิ้น)';
    let packIcon = '💎';
    if (currUpper === 'GOLD') {
        packTitle = 'ชุดอัญมณีทั่วไป (+' + count + ' ชิ้น)';
        packDesc = 'สุ่มเงาอัญมณีระดับ A ~ A+ (' + count + ' ชิ้น)';
        packIcon = '🌑';
    } else if (tierUpper === 'PREMIUM') {
        packTitle = count >= 10 ? 'ชุดอัญมณีพรีเมียม (+10)' : 'ชุดอัญมณีพรีเมียม (+5)';
        packDesc = 'เรตอัปเงาขั้น 4-5 & ลุ้นอัญมณีจริง ' + count + ' ชิ้น';
        packIcon = count >= 10 ? '🔥' : '✨';
    }

    if (!skipConfirm && typeof window.showPurchaseConfirmModal === 'function') {
        window.showPurchaseConfirmModal({
            headerIcon: currUpper === 'GOLD' ? '💰' : '💎',
            headerTitle: 'ยืนยันราคาเปิดแพ็คอัญมณีมหาเวทย์',
            icon: packIcon,
            badgeText: 'เปิดแพ็ค ' + count + ' ชิ้น',
            title: packTitle,
            subtitle: packDesc,
            currency: currUpper,
            price: totalCost,
            confirmLabel: 'ยืนยันเปิดอัญมณี'
        }, () => {
            if (typeof window.closeGachaVideoPopup === 'function') window.closeGachaVideoPopup();
            window.rollGemGacha(count, currency, tier, true);
        });
        return;
    }

    try {
        const res = await fetch('api/equipment_service.php?action=draw_gem_gacha', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, count: count, currency: currUpper, pack_tier: tierUpper })
        });
        const json = await res.json();
        if (json.status === 'success') {
            if (json.user) {
                if (window.DEFAULT_USER) {
                    if (json.user.diamond !== undefined) window.DEFAULT_USER.diamond = Number(json.user.diamond);
                    if (json.user.gold !== undefined) window.DEFAULT_USER.gold = Number(json.user.gold);
                    if (typeof updateUserBar === 'function') updateUserBar(window.DEFAULT_USER);
                }
            }
            if (json.user_shadows && window._gemGachaEventData) {
                window._gemGachaEventData.user_shadows = json.user_shadows;
                if (json.user_shadows['SPECIAL_GEM_CARD'] !== undefined) {
                    window.latestMaterialsMap = window.latestMaterialsMap || {};
                    window.latestMaterialsMap['SPECIAL_GEM_CARD'] = Number(json.user_shadows['SPECIAL_GEM_CARD'] || 0);
                }
                window.renderGemEventSeparatedUI(window._gemGachaEventData.event, window._gemGachaEventData.target_item);
            }
            window.syncGemEventWalletDisplay();

            if (typeof window.openVideoStyleGachaPopup === 'function') {
                window.lastGachaPullMeta = {
                    source: 'GEM',
                    category: 'GEM',
                    count: count,
                    currency: currUpper,
                    packTier: tierUpper,
                    displayCost: costLabel
                };
                window.openVideoStyleGachaPopup(json.drops || [], 'GEM', count, costLabel);
            } else {
                if (typeof showToast === 'function') showToast(json.message || 'สุ่มอัญมณีสำเร็จ!');
            }
        } else {
            if (typeof showInGameAlert === 'function') {
                showInGameAlert(json.message || 'ทรัพยากรไม่เพียงพอสำหรับการสุ่ม', 'แจ้งเตือน', '⚠️');
            } else {
                alert(json.message || 'เกิดข้อผิดพลาดในการสุ่ม');
            }
        }
    } catch (err) {
        console.error('rollGemGacha error:', err);
        if (typeof showInGameAlert === 'function') {
            showInGameAlert(err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'แจ้งเตือนการสุ่ม', '⚠️');
        }
    }
};


// 9. EXCHANGE 5 SHADOW GEMS FOR EVENT TARGET GEM
window.exchangeGemEventReward = async function () {
    const userId = (window.DEFAULT_USER && window.DEFAULT_USER.id && Number(window.DEFAULT_USER.id) > 0) ? Number(window.DEFAULT_USER.id) : null;
    if (!userId) {
        if (typeof showInGameAlert === 'function') showInGameAlert('กรุณาเข้าสู่ระบบก่อนแลกรับอัญมณี', 'เข้าสู่ระบบ', '⚠️');
        return;
    }
    try {
        const res = await fetch('api/equipment_service.php?action=exchange_gem_gacha_event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId })
        });
        const json = await res.json();
        if (json.status === 'success') {
            if (typeof showInGameAlert === 'function') {
                showInGameAlert(json.message, 'แลกรับอัญมณีสำเร็จ!', '🎉');
            } else if (typeof showToast === 'function') {
                showToast(json.message);
            } else {
                alert(json.message);
            }
            if (json.user_shadows && window._gemGachaEventData) {
                window._gemGachaEventData.user_shadows = json.user_shadows;
                if (json.user_shadows['SPECIAL_GEM_CARD'] !== undefined) {
                    window.latestMaterialsMap = window.latestMaterialsMap || {};
                    window.latestMaterialsMap['SPECIAL_GEM_CARD'] = Number(json.user_shadows['SPECIAL_GEM_CARD'] || 0);
                }
                window.renderGemEventSeparatedUI(window._gemGachaEventData.event, window._gemGachaEventData.target_item);
            }
            if (typeof window.loadUserEquipment === 'function') {
                window.loadUserEquipment(userId);
            }
            if (typeof window.loadPlayerGems === 'function') {
                await window.loadPlayerGems();
            }
            if (typeof window.loadInventoryData === 'function') {
                await window.loadInventoryData();
            }
        } else {
            if (typeof showInGameAlert === 'function') {
                showInGameAlert(json.message || 'แลกรับไม่สำเร็จ', 'แจ้งเตือน', '⚠️');
            } else {
                alert(json.message);
            }
        }
    } catch (e) {
        console.error('exchangeGemEventReward error:', e);
    }
};
