import UIKit
import Capacitor
import WebKit

class SSLBypassNavigationDelegate: NSObject, WKNavigationDelegate {
    weak var originalDelegate: WKNavigationDelegate?
    weak var viewController: CustomBridgeViewController?

    init(original: WKNavigationDelegate?, viewController: CustomBridgeViewController?) {
        self.originalDelegate = original
        self.viewController = viewController
        super.init()
    }

    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let serverTrust = challenge.protectionSpace.serverTrust {
            // Accept SSL certificate from server (self-signed, aaPanel, or internal domain)
            completionHandler(.useCredential, URLCredential(trust: serverTrust))
            return
        }
        if let original = originalDelegate, original.responds(to: #selector(WKNavigationDelegate.webView(_:didReceive:completionHandler:))) {
            original.webView?(webView, didReceive: challenge, completionHandler: completionHandler)
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        let host = webView.url?.host?.lowercased() ?? ""
        if host.contains("google.com") || host.contains("line.me") {
            webView.scrollView.isScrollEnabled = true
            webView.scrollView.bounces = true
        }
        if let original = originalDelegate, original.responds(to: #selector(WKNavigationDelegate.webView(_:didFinish:))) {
            original.webView?(webView, didFinish: navigation)
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("❌ Navigation failed: \(error.localizedDescription)")
        let nsError = error as NSError
        if nsError.code == NSURLErrorCancelled {
            return
        }
        
        let errorHtml = """
        <!DOCTYPE html>
        <html lang="th">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
            <title>SnakeGame3D</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { background: radial-gradient(circle at center, #1e1b4b 0%, #0b0f19 100%); color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; padding: 24px; text-align: center; }
                .card { background: rgba(15, 23, 42, 0.85); border: 1.5px solid rgba(0, 229, 255, 0.4); border-radius: 20px; padding: 28px; max-width: 440px; box-shadow: 0 0 35px rgba(0, 229, 255, 0.25); }
                .icon { font-size: 52px; margin-bottom: 12px; }
                h2 { color: #00e5ff; font-size: 20px; font-weight: 800; margin-bottom: 10px; }
                p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 22px; }
                button { background: linear-gradient(135deg, #00e5ff, #0284c7); color: #000; font-weight: 800; border: none; padding: 12px 28px; border-radius: 12px; font-size: 15px; cursor: pointer; box-shadow: 0 4px 15px rgba(0, 229, 255, 0.4); }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="icon">🎲</div>
                <h2>เข้าสู่ระบบเกมไม่สำเร็จ</h2>
                <p>ไม่สามารถเชื่อมต่อไปยังเซิร์ฟเวอร์เกมได้<br><small style="color:#64748b;">\(error.localizedDescription)</small></p>
                <button onclick="location.href='https://pmix01.thddns.net:7175/home/snake/'">🔄 ลองเชื่อมต่อใหม่</button>
            </div>
        </body>
        </html>
        """
        webView.loadHTMLString(errorHtml, baseURL: nil)
    }

    override func forwardingTarget(for aSelector: Selector!) -> Any? {
        return originalDelegate
    }

    override func responds(to aSelector: Selector!) -> Bool {
        if aSelector == #selector(WKNavigationDelegate.webView(_:didReceive:completionHandler:)) ||
           aSelector == #selector(WKNavigationDelegate.webView(_:didFinish:)) ||
           aSelector == #selector(WKNavigationDelegate.webView(_:didFailProvisionalNavigation:withError:)) {
            return true
        }
        return originalDelegate?.responds(to: aSelector) ?? super.responds(to: aSelector)
    }
}

class CustomBridgeViewController: CAPBridgeViewController {
    private var sslProxy: SSLBypassNavigationDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        let darkColor = UIColor(red: 7/255, green: 11/255, blue: 20/255, alpha: 1.0)
        self.view.backgroundColor = darkColor
        self.webView?.backgroundColor = darkColor
        self.webView?.scrollView.backgroundColor = darkColor
        self.webView?.isOpaque = false

        // Use standard Mobile Safari User-Agent so Google OAuth & 2FA work without WebView restrictions
        self.webView?.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"

        // Inject helper script for Google/LINE OAuth screens:
        // 1. Auto-recover immediately if Google shows Error 400 after 2-Step Verification
        // 2. Enable smooth scrolling & provide a floating "Back to Game" button on external OAuth pages
        let oauthHelperJs = """
        (function() {
            var host = (window.location && window.location.hostname) ? window.location.hostname.toLowerCase() : '';
            if (host.indexOf('google.com') !== -1 || host.indexOf('line.me') !== -1) {
                document.documentElement.style.overflowY = 'auto';
                document.documentElement.style.webkitOverflowScrolling = 'touch';
                if (document.body) {
                    document.body.style.overflowY = 'auto';
                }
                var titleText = document.title || '';
                var bodyText = document.body ? (document.body.innerText || '') : '';
                if (host.indexOf('google.com') !== -1 && (titleText.indexOf('Error 400') !== -1 || bodyText.indexOf('400. That') !== -1 || bodyText.indexOf('malformed') !== -1)) {
                    window.location.replace('https://pmix01.thddns.net:7175/home/snake/api/auth.php?action=login&provider=google&auto_resume=' + Date.now());
                    return;
                }
                if (!document.getElementById('snake-oauth-back-btn') && document.body) {
                    var btn = document.createElement('button');
                    btn.id = 'snake-oauth-back-btn';
                    btn.innerHTML = '⬅ กลับหน้าเกม';
                    btn.style.cssText = 'position:fixed;top:12px;left:12px;z-index:2147483647;background:rgba(15,23,42,0.92);color:#00e5ff;border:1.5px solid #00e5ff;border-radius:20px;padding:6px 14px;font-size:13px;font-weight:700;font-family:sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.4);cursor:pointer;';
                    btn.onclick = function() {
                        window.location.href = 'https://pmix01.thddns.net:7175/home/snake/';
                    };
                    document.body.appendChild(btn);
                }
            }
        })();
        """
        let userScript = WKUserScript(source: oauthHelperJs, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        self.webView?.configuration.userContentController.addUserScript(userScript)

        if let currentDelegate = self.webView?.navigationDelegate {
            let proxy = SSLBypassNavigationDelegate(original: currentDelegate, viewController: self)
            self.sslProxy = proxy
            self.webView?.navigationDelegate = proxy
        }
    }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        // Keep screen awake while game is active
        UIApplication.shared.isIdleTimerDisabled = true

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = CustomBridgeViewController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        UIApplication.shared.isIdleTimerDisabled = true

        // When returning from Gmail 2-Step Verification app back to SnakeGame3D,
        // check if Google OAuth page hit Error 400 and auto-complete login immediately
        if let bridgeVC = window?.rootViewController as? CustomBridgeViewController,
           let webView = bridgeVC.webView,
           let host = webView.url?.host?.lowercased(),
           host.contains("google.com") {
            let resumeJs = """
            (function() {
                var t = document.title || '';
                var b = document.body ? (document.body.innerText || '') : '';
                if (t.indexOf('Error 400') !== -1 || b.indexOf('400. That') !== -1 || b.indexOf('malformed') !== -1) {
                    window.location.replace('https://pmix01.thddns.net:7175/home/snake/api/auth.php?action=login&provider=google&resume_2fa=' + Date.now());
                }
            })();
            """
            webView.evaluateJavaScript(resumeJs, completionHandler: nil)
        }
    }

    func sceneWillResignActive(_ scene: UIScene) {
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}
